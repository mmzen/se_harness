from pathlib import Path
import hashlib,json,os,subprocess,sys,time,types
from release022_ctl import REPO,OUT,EVALUATOR
root=OUT/'package-checks';old=OUT/'package-checks.json'
result=json.loads((OUT/'package-checks-final.json' if (OUT/'package-checks-final.json').exists() else old).read_text());rows=result['commands']
backup=OUT/'package-checks-direct-sdist-attempt.json'
if not backup.exists(): backup.write_bytes(old.read_bytes())
env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true',GIT_CONFIG_KEY_1='safe.directory',GIT_CONFIG_VALUE_1=REPO.as_posix());env.pop('PYTHONPATH',None)
def run(label,args,cwd=root):
 completed=[r for r in rows if r['label']==label and r['exit_code']==0]
 if completed:
  assert completed[-1]['argv']==list(map(str,args))
  return types.SimpleNamespace(stdout=completed[-1]['stdout'],stderr=completed[-1]['stderr'],returncode=0)
 start=time.time();p=subprocess.run(list(map(str,args)),cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=1200)
 rows.append(dict(label=label,argv=list(map(str,args)),cwd=str(cwd),exit_code=p.returncode,seconds=round(time.time()-start,2),stdout=p.stdout,stderr=p.stderr))
 (OUT/'package-resume-progress.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(label,p.returncode,flush=True)
 if p.returncode: raise RuntimeError(label+': '+p.stderr[-1500:]+' '+p.stdout[-1000:])
 return p
try:
 bp=root/'build-env/Scripts/python.exe';py=root/'wheel-env/Scripts/python.exe'
 # Index-style package selection gives no direct-file PEP 610 wheel claim.
 # Use the already-built sdist without a network or provenance-file modification.
 run('install-sdist-index-selection',[bp,'-m','pip','install','--force-reinstall','--no-index','--no-deps','--no-build-isolation','--no-binary=se-harness','--find-links',root/'sdist','se-harness==0.22.0'])
 run('sdist-index-identity',[bp,'-I','-m','se_harness','identity','--role','candidate-package','--expected-version','0.22.0','--expected-root',root/'build-env','--checkout-root',REPO,'--candidate-commit',result['candidate'],'--require-isolated-python','--json'])
 run('sdist-index-init',[bp,'-I','-m','se_harness','init',root/'sdist-index-minimal','--project-name','Sdist index qualification'])
 run('sdist-index-doctor',[bp,'-I','-m','se_harness','doctor',root/'sdist-index-minimal'])
 run('sdist-index-validate',[bp,'-I','-m','se_harness','validate',root/'sdist-index-minimal','--json'])
 unchanged=run('provenance-regression-comparison',[r'C:\Program Files\Git\cmd\git.exe','-c','safe.directory='+REPO.as_posix(),'-C',REPO,'diff','--name-only','v0.21.0',result['candidate'],'--','se_harness/evaluator_identity.py']);assert not unchanged.stdout.strip()
 for n in (1,2):
  run('upgrade-safe-'+str(n),[EVALUATOR,'-B','-m','repository_tools.upgrade_rehearsal','--repository',REPO,'--predecessor-python',EVALUATOR,'--successor-python',py,'--output',root/f'upgrade-safe-{n}','--workspace',root,'--timings'],REPO)
 a=json.loads((root/'upgrade-safe-1/upgrade-rehearsal-result.json').read_text());b=json.loads((root/'upgrade-safe-2/upgrade-rehearsal-result.json').read_text())
 assert a['overall_result']==b['overall_result']=='pass' and a['semantic_sha256']==b['semantic_sha256']
 result['upgrade_semantic_sha256']=a['semantic_sha256']
 result['passed']=True;result.pop('error',None)
 result['limits']=['A direct local .tar.gz installation fails initialization because the PEP 610 archive reader accepts wheel provenance only. That reader is unchanged from v0.21.0. The sdist selected by name/version from a local index passes init, doctor and validate. No direct-sdist support or defect correction is claimed.','Initial bare identity invocation lacked required role/version/root arguments; corrected invocation passes. Original command results remain retained.','Qualification builds are non-promotable. Exact release bytes remain bound by the separate pinned two-build replay.']
except Exception as e: result['error']=str(e);result['passed']=False
(OUT/'package-checks-final.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='commands'},indent=2));raise SystemExit(0 if result['passed'] else 1)
