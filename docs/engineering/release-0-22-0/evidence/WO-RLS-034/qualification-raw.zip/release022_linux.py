from pathlib import Path
import hashlib,json,subprocess,sys
from release022_ctl import BASE,OUT,REPO
git=r'C:\Program Files\Git\cmd\git.exe'
prefix=[git,'-c','core.longpaths=true','-c','safe.directory='+REPO.as_posix(),'-C',str(REPO)]
candidate=subprocess.check_output([*prefix,'rev-parse','HEAD'],text=True).strip()
bundle=OUT/('linux-'+candidate[:12]+'.bundle')
subprocess.run([*prefix,'bundle','create',str(bundle),'work/release-0-22-0','--tags'],check=True,capture_output=True)
wheel=Path(r'C:\Users\mathi\.codex\plugins\cache\se-harness\verity-plane\0.2.4\packages\se_harness-0.21.0-py3-none-any.whl')
def linux(p): return '/mnt/c/'+p.as_posix()[3:]
program=r'''import hashlib,json,os,pathlib,platform,subprocess,sys,tempfile,time
inputs=json.load(sys.stdin);stage=pathlib.Path(tempfile.mkdtemp(prefix='release022-'));source=stage/'source';rows=[]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',PIP_NO_INDEX='1',SE_HARNESS_TEST_SCALE='full');env.pop('PYTHONPATH',None)
def run(label,args,cwd=stage):
 start=time.time();p=subprocess.run(list(map(str,args)),cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=1800)
 rows.append(dict(label=label,argv=list(map(str,args)),cwd=str(cwd),exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=round(time.time()-start,2)))
 if p.returncode: raise RuntimeError(label+': '+p.stdout[-2500:]+'\n'+p.stderr[-1000:])
 return p
result={'candidate':inputs['candidate'],'platform':platform.platform(),'scale':'full','commands':rows,'passed':False}
try:
 assert hashlib.sha256(pathlib.Path(inputs['wheel']).read_bytes()).hexdigest()==inputs['wheel_sha256']
 run('clone',['git','clone','--branch','work/release-0-22-0',inputs['bundle'],source])
 run('source-origin',['git','remote','set-url','origin','https://github.com/mmzen/se_harness.git'],source)
 assert run('identity',['git','rev-parse','HEAD'],source).stdout.strip()==inputs['candidate']
 run('venv',[sys.executable,'-m','venv',stage/'runtime'])
 py=stage/'runtime/bin/python'
 run('install-released-evaluator',[py,'-m','pip','install','--no-index','--no-deps',inputs['wheel']])
 run('full',[py,'-B','scripts/run_tests.py','--workers','4','--scale','full'],source)
 run('package-assembly',[py,'-B','-m','unittest','discover','-s','tests/plugin_integration/package_assembly','-p','test_*.py'],source)
 run('distributions',[py,'-B','scripts/validate_release_distributions.py','--root','.'],source)
 result['passed']=True
except Exception as e: result['error']=str(e)
print(json.dumps(result));sys.exit(0 if result['passed'] else 1)
'''
args=[r'C:\Windows\System32\wsl.exe','-d','Ubuntu-24.04','--exec','python3','-c',program]
p=subprocess.run(args,input=json.dumps({'candidate':candidate,'bundle':linux(bundle),'wheel':linux(wheel),'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest()}),cwd=BASE,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=2400)
try: result=json.loads(p.stdout)
except ValueError: result={'stdout':p.stdout,'stderr':p.stderr}
name='linux-'+candidate[:12]+'.json'
(OUT/name).write_text(json.dumps({'exit_code':p.returncode,'result':result},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'exit_code':p.returncode,'candidate':candidate,'passed':result.get('passed'),'error':result.get('error'),'file':name,'checks':[(r['label'],r['exit_code']) for r in result.get('commands',[])]}))
raise SystemExit(p.returncode)
