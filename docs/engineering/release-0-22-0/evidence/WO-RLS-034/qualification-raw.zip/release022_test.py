import json,os,subprocess,sys,time
from release022_ctl import REPO,OUT,EVALUATOR
label,*args=sys.argv[1:]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',PYTHONNOUSERSITE='1',SE_HARNESS_TEST_SCALE='full',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true')
env.pop('PYTHONPATH',None)
argv=[str(EVALUATOR),'-B','-X','utf8',*args]
started=time.time()
p=subprocess.run(argv,cwd=REPO,env=env,capture_output=True,text=True,encoding='utf-8')
(OUT/(label+'.stdout.txt')).write_text(p.stdout,encoding='utf-8')
(OUT/(label+'.stderr.txt')).write_text(p.stderr,encoding='utf-8')
result={'argv':argv,'cwd':str(REPO),'exit_code':p.returncode,'seconds':round(time.time()-started,2),'scale':'full','stdout':label+'.stdout.txt','stderr':label+'.stderr.txt'}
(OUT/(label+'.run.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
print(p.stdout[-3000:]);print(p.stderr[-3000:])
raise SystemExit(p.returncode)
