import hashlib,json,subprocess
from release022_ctl import REPO,OUT,BASE
prior=OUT/'linux-2c5becd195a2.json'
observed=json.loads(prior.read_text())['result']
source=next(x['cwd'] for x in observed['commands'] if x['label']=='distributions')
bundle=OUT/'linux-release-history.bundle'
git=r'C:\Program Files\Git\cmd\git.exe'
subprocess.run([git,'-c','core.longpaths=true','-c','safe.directory='+REPO.as_posix(),'-C',str(REPO),'bundle','create',str(bundle),'--tags'],check=True,capture_output=True)
program='''import json,subprocess,sys,pathlib
i=json.load(sys.stdin);rows=[]
for args in [['git','fetch',i['bundle'],'refs/tags/*:refs/tags/*'],[str(pathlib.Path(i['source']).parent/'runtime/bin/python'),'-B','scripts/validate_release_distributions.py','--root','.']]:
 p=subprocess.run(args,cwd=i['source'],capture_output=True,text=True)
 rows.append(dict(argv=args,cwd=i['source'],exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr))
 if p.returncode: break
print(json.dumps({'passed':all(r['exit_code']==0 for r in rows),'commands':rows}))
sys.exit(0 if all(r['exit_code']==0 for r in rows) else 1)
'''
p=subprocess.run([r'C:\Windows\System32\wsl.exe','-d','Ubuntu-24.04','--exec','python3','-c',program],input=json.dumps({'source':source,'bundle':'/mnt/c/'+bundle.as_posix()[3:]}),cwd=BASE,capture_output=True,text=True,encoding='utf-8')
result={'candidate':observed['candidate'],'prior_raw_sha256':hashlib.sha256(prior.read_bytes()).hexdigest(),'correction':'Restore historical version tags to the disposable clone; candidate and product files unchanged. Repeat distribution validation only.','result':json.loads(p.stdout),'exit_code':p.returncode}
(OUT/'linux-2c5becd195a2-history-retry.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2));raise SystemExit(p.returncode)
