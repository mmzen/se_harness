from pathlib import Path
import hashlib,json,os,subprocess,sys,tarfile,time,types
from release022_ctl import REPO,OUT,EVALUATOR,BASE
root=OUT/'package-checks';root.mkdir(exist_ok=True)
git=r'C:\Program Files\Git\cmd\git.exe'
C='2c5becd195a2bb910fead659bc2f2131ca3b7ef6';M='62bc0e8e7548ac34556e0e926f685816fb23cef0'
wheel=OUT/'ci-wheel/se_harness-0.22.0-py3-none-any.whl';WH='d76acdd67ff5180e226e461c8df54765f720408f3e61511783d46a8f370a16e1'
env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true');env.pop('PYTHONPATH',None)
prior=OUT/'package-checks.json'
rows=json.loads(prior.read_text())['commands'] if prior.exists() else []
if prior.exists():
    backup=OUT/'package-checks-first-attempt.json'
    if not backup.exists(): backup.write_bytes(prior.read_bytes())
result={'candidate':C,'ci_merge':M,'wheel':str(wheel),'wheel_sha256':WH,'role':'Non-promotable qualification wheel; final release archives come only from the exact pinned replay.','commands':rows,'passed':False}
def run(label,args,cwd=root):
    completed=[r for r in rows if r['label']==label and r['exit_code']==0]
    if completed:
        assert completed[-1]['argv']==list(map(str,args))
        return types.SimpleNamespace(stdout=completed[-1]['stdout'],stderr=completed[-1]['stderr'],returncode=0)
    start=time.time();p=subprocess.run(list(map(str,args)),cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=1200)
    rows.append(dict(label=label,argv=list(map(str,args)),cwd=str(cwd),exit_code=p.returncode,seconds=round(time.time()-start,2),stdout=p.stdout,stderr=p.stderr))
    (OUT/'package-checks-progress.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(label,p.returncode,flush=True)
    if p.returncode: raise RuntimeError(label+': '+p.stderr[-2000:]+' '+p.stdout[-1000:])
    return p
try:
    assert hashlib.sha256(wheel.read_bytes()).hexdigest()==WH
    diff=run('ci-tree-equivalence',[git,'-c','safe.directory='+REPO.as_posix(),'-C',REPO,'diff','--name-only',C,M]);assert not diff.stdout.strip()
    run('released-package-qualification',[EVALUATOR,'-I','-m','se_harness','qualify','candidate-package','--candidate-wheel',wheel,'--candidate-commit',C,'--candidate-wheel-sha256',WH,'--verifier-wheel-sha256','13d401f5a0c94444dc3cf31c6f2863d23b77beb4b2c33756734b493606ad6789','--checkout-root',REPO,'--output',root/'qualification.json','--json'])
    run('wheel-venv',[sys.executable,'-m','venv',root/'wheel-env'])
    py=root/'wheel-env/Scripts/python.exe'
    run('install-wheel',[py,'-m','pip','install','--no-index','--no-deps',wheel])
    run('wheel-identity',[py,'-I','-m','se_harness','identity','--role','candidate-package','--expected-version','0.22.0','--expected-root',root/'wheel-env','--checkout-root',REPO,'--candidate-commit',C,'--require-isolated-python','--json'])
    run('initialize-minimal',[py,'-I','-m','se_harness','init',root/'minimal','--project-name','Release qualification'])
    run('doctor-minimal',[py,'-I','-m','se_harness','doctor',root/'minimal'])
    run('validate-minimal',[py,'-I','-m','se_harness','validate',root/'minimal','--json'])
    run('build-venv',[sys.executable,'-m','venv',root/'build-env'])
    bp=root/'build-env/Scripts/python.exe'
    run('build-tools',[bp,'-m','pip','install','--disable-pip-version-check','--only-binary=:all:','--require-hashes','-r',REPO/'release/build-toolchain.lock'])
    run('source-export',[git,'-c','safe.directory='+REPO.as_posix(),'-C',REPO,'archive','--format=tar','--output',root/'source.tar',C])
    source=root/'source';source.mkdir()
    with tarfile.open(root/'source.tar') as a: a.extractall(source,filter='data')
    run('qualification-sdist',[bp,'-m','build','--sdist','--no-isolation','--outdir',root/'sdist'],source)
    sdist=root/'sdist/se_harness-0.22.0.tar.gz'
    result['sdist_sha256']=hashlib.sha256(sdist.read_bytes()).hexdigest()
    run('install-sdist',[bp,'-m','pip','install','--no-index','--no-deps','--no-build-isolation',sdist])
    run('sdist-identity',[bp,'-I','-m','se_harness','identity','--role','candidate-package','--expected-version','0.22.0','--expected-root',root/'build-env','--checkout-root',REPO,'--candidate-commit',C,'--require-isolated-python','--json'])
    run('sdist-init',[bp,'-I','-m','se_harness','init',root/'sdist-minimal','--project-name','Sdist qualification'])
    run('sdist-doctor',[bp,'-I','-m','se_harness','doctor',root/'sdist-minimal'])
    for attempt in (1,2):
        run('upgrade-'+str(attempt),[EVALUATOR,'-B','-m','repository_tools.upgrade_rehearsal','--repository',REPO,'--predecessor-python',EVALUATOR,'--successor-python',py,'--output',root/f'upgrade-{attempt}','--workspace',root,'--timings'],REPO)
    a=json.loads((root/'upgrade-1/upgrade-rehearsal-result.json').read_text());b=json.loads((root/'upgrade-2/upgrade-rehearsal-result.json').read_text())
    assert a['overall_result']==b['overall_result']=='pass' and a['semantic_sha256']==b['semantic_sha256']
    result['upgrade_semantic_sha256']=a['semantic_sha256'];result['passed']=True
except Exception as e: result['error']=str(e)
(OUT/'package-checks.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='commands'},indent=2));raise SystemExit(0 if result['passed'] else 1)
