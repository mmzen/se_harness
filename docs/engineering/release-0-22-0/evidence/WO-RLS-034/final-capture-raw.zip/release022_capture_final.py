from pathlib import Path
import hashlib,json,os,subprocess,sys
from release022_ctl import REPO,OUT,EVALUATOR,BASE
C=json.loads((OUT/'final-candidate.json').read_text())['candidate']
if (OUT/'final-capture.json').exists():
    previous=json.loads((OUT/'final-capture.json').read_text())
    assert previous.get('operation',{}).get('outcome')=='blocked'
    assert not (REPO/'docs/engineering/release-0-22-0/verification-records/VREC-SEH-032.md').exists()
    attempt=1
    while (OUT/f'capture-attempt-{attempt}.json').exists(): attempt+=1
    for source,suffix in [('final-capture.json','.json'),('final-capture-checks.json','-checks.json'),('final-capture-inputs.json','-inputs.json'),('final-external-checks.json','-receipt.json')]:
        (OUT/f'capture-attempt-{attempt}{suffix}').write_bytes((OUT/source).read_bytes())
manual=json.loads((OUT/'final-manual-run.json').read_text())['result']
linux=json.loads((OUT/f'linux-{C[:12]}.json').read_text())['result']
pr=json.loads((OUT/'final-pr-ci.json').read_text())['result']
receipt={'candidate':C,'manual_run':manual,'candidate_replay':json.loads((OUT/'final-hosted-candidate/release-build-replay.json').read_text()),'record_replay':json.loads((OUT/'final-hosted-record/release-build-replay.json').read_text()),'record_qualification':json.loads((OUT/'final-hosted-record/complete-candidate-qualification.json').read_text()),'linux':linux,'pr':pr,'capture_driver_sha256':hashlib.sha256((BASE/'release022_capture_checks.py').read_bytes()).hexdigest()}
if (OUT/'final-capture-checks.json').exists():
    prior_rows=json.loads((OUT/'final-capture-checks.json').read_text())
    if len(prior_rows)>=2 and prior_rows[0]['exit_code']==prior_rows[1]['exit_code']==0:
        assert json.loads(prior_rows[0]['stdout'])['target']['commit']==C
        assert prior_rows[1]['argv'][-5:]==['scripts/run_tests.py','--workers','4','--scale','full']
        receipt['previous_windows_source_checks']=prior_rows[:2]
        receipt['source_reuse_reason']='Both checks passed during the preceding capture at the same immutable candidate. Only the package-assembly test interpreter is corrected; no source or candidate inputs changed.'
assert manual['headSha']==C and manual['conclusion']=='success' and linux['candidate']==C and linux['passed'] and pr['headRefOid']==C
rf=OUT/'final-external-checks.json';rf.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
evidence=[]
for p in (REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-034').iterdir():
 if p.is_file(): evidence.append(p.relative_to(REPO).as_posix())
evidence.extend([
 'docs/engineering/harness-simplification/evidence/WO-KIS-010/review.md',
 'docs/engineering/harness-simplification/evidence/WO-KIS-012/review.md',
 'docs/engineering/harness-simplification/evidence/WO-KIS-013/review.md',
 'docs/engineering/release-orchestration/evidence/WO-RLO-014/implementation-review.md',
 'docs/engineering/release-orchestration/evidence/WO-RLO-015/implementation-review.md',
 'docs/engineering/release-orchestration/evidence/WO-RLO-016/README.md',
 'docs/engineering/release-orchestration/evidence/WO-RLO-016/configuration-proposal.json',
 'docs/engineering/release-orchestration/evidence/WO-RLO-016/main-rules.json',
 'docs/engineering/release-orchestration/evidence/WO-RLO-016/pages-environment.json',
 'docs/engineering/release-orchestration/evidence/WO-RLO-016/pypi-branches.json',
 'docs/engineering/release-orchestration/evidence/WO-RLO-016/pypi-environment.json'
])
assessment=json.loads((REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-034/qualification-assessment.json').read_text())
env=dict(os.environ,GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true',GIT_CONFIG_KEY_1='core.autocrlf',GIT_CONFIG_VALUE_1='false',PYTHONUTF8='1')
git=r'C:\Program Files\Git\cmd\git.exe'
assert not subprocess.check_output([git,'-C',str(REPO),'status','--porcelain=v1'],env=env,text=True).strip()
assert not subprocess.check_output([git,'-C',str(REPO),'log','--all','--format=%H','--','**/verification-records/VREC-SEH-032.md'],env=env,text=True).strip()
args=[str(EVALUATOR),'-I','-m','se_harness','capture-verification',str(REPO),'--id','VREC-SEH-032','--owner','Codex','--domain','release-0-22-0','--candidate-commit',C,'--json']
for row in assessment['members']: args+=['--work-order',row['id']]
for id in assessment['verifications']: args+=['--verification',id]
hashes=[]
for f in sorted(evidence):
 raw=(REPO/f).read_bytes();hashes.append({'path':f,'sha256':hashlib.sha256(raw).hexdigest()});args+=['--evidence',f]
args+=['--test-command',str(OUT/'clean-source-env/Scripts/python.exe'),'-B','-X','utf8',str(BASE/'release022_capture_checks.py'),C,str(rf),hashlib.sha256(rf.read_bytes()).hexdigest()]
(OUT/'final-capture-inputs.json').write_text(json.dumps({'argv':args,'evidence':hashes},indent=2)+'\n',encoding='utf-8')
p=subprocess.run(args,cwd=BASE,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
(OUT/'final-capture.json').write_text(p.stdout,encoding='utf-8');(OUT/'final-capture.stderr.txt').write_text(p.stderr,encoding='utf-8')
try: result=json.loads(p.stdout);brief={k:result[k] for k in ('operation','restitution','errors') if k in result}
except ValueError: brief={'stdout_tail':p.stdout[-2000:]}
print(json.dumps({'exit_code':p.returncode,'result':brief,'stderr':p.stderr[-2500:]},indent=2));raise SystemExit(p.returncode)
