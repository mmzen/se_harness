"""Final candidate checks; used only by released capture-verification."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
C,receipt_file,expected_digest=sys.argv[1:]
raw=Path(receipt_file).read_bytes();assert hashlib.sha256(raw).hexdigest()==expected_digest
r=json.loads(raw);assert r['candidate']==C
run=r['manual_run'];assert run['headSha']==C and run['event']=='workflow_dispatch' and run['status']=='completed' and run['conclusion']=='success'
replay=r['candidate_replay'];assert replay['candidate']['commit']==C and replay['manifest']['commit']==C and replay['manifest']['version']=='0.22.0'
assert len(replay['builds'])==2
for key in ('wheel_sha256','sdist_sha256'): assert replay['builds'][0][key]==replay['builds'][1][key]==replay['manifest'][key]
previous=r['record_replay'];assert previous['release_record']=='RLS-SEH-031' and previous['state']=='exact' and previous['candidate']['commit']=='4031f0fa4b5c4a95651bd928a110d8b2d94f9775'
assert r['record_qualification']['passed']
assert r['linux']['passed'] and r['linux']['candidate']==C
assert r['pr']['headRefOid']==C
assert all(x.get('status')=='COMPLETED' and x.get('conclusion') in ('SUCCESS','SKIPPED','NEUTRAL') for x in r['pr']['statusCheckRollup'])
env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',SE_HARNESS_TEST_SCALE='full')
env.pop('PYTHONPATH',None)
# Capture's LF normalization is for formal snapshots, not Windows Git fixtures.
for k in list(env):
 if k=='GIT_CONFIG_COUNT' or k.startswith(('GIT_CONFIG_KEY_','GIT_CONFIG_VALUE_')): env.pop(k)
env.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true')
head=subprocess.run(['git','rev-parse','HEAD'],capture_output=True,text=True,check=True,env=env).stdout.strip();assert head==C
rows=[]
source_prior=r.get('previous_windows_source_checks')
if source_prior:
 assert len(source_prior)==2 and all(row['exit_code']==0 for row in source_prior)
 assert json.loads(source_prior[0]['stdout'])['target']['commit']==C
 assert source_prior[1]['argv'][-5:]==['scripts/run_tests.py','--workers','4','--scale','full']
 print(json.dumps({'reused_same_candidate_source_checks':source_prior,'reason':r['source_reuse_reason']}),flush=True)
commands=[
 ['-m','se_harness','qualify','complete-candidate','.','--candidate-commit',C,'--json'],
 *([] if source_prior else [['scripts/run_tests.py','--workers','4','--scale','full']]),
 ['-m','unittest','discover','-s','tests/plugin_integration/package_assembly','-p','test_*.py'],
 ['scripts/validate_release_distributions.py','--root','.'],
 ['-m','se_harness','--help']
]
for args in commands:
 runtime=(r'C:\Users\mathi\.codex\plugins\data\verity-plane-se-harness\evaluators\0.21.0\13d401f5a0c94444dc3cf31c6f2863d23b77beb4b2c33756734b493606ad6789\Scripts\python.exe' if args[:2]==['-m','unittest'] else sys.executable)
 argv=[runtime,'-B','-X','utf8',*args]
 p=subprocess.run(argv,cwd=Path.cwd(),env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=1800)
 row={'argv':argv,'cwd':str(Path.cwd()),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr};rows.append(row)
 Path(receipt_file).with_name('final-capture-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(row),flush=True)
 assert p.returncode==0
print(json.dumps({'candidate':C,'receipt_sha256':expected_digest,'hosted_and_linux_evidence':r,'limits':'Installed qualification uses a source-equivalent non-promotable package. Direct-file sdist provenance is unsupported; named/index-selected source install passes. Native host/public delivery remains downstream. No human verification or release decision is supplied.'}),flush=True)
