"""Current availability edits only, under approved WO-RLS-036."""
from release022_ctl import REPO,OUT
import json
PUBLIC='7d30907f15bd7e06fb632e1ebf4e88e01b68726c'
WHEEL='44543f242ed19bb30cfd65da415372a87508a6e439204d7f3e37f9f45aefe4e4'
for kind in ('fresh','update'):
    assert json.loads((OUT/'public025'/f'{kind}-route.json').read_text())['status']=='pass'
    assert json.loads((OUT/'public025'/f'setup-{kind}-result.json').read_text())['status']=='pass'
def edit(name,fn):
    path=REPO/name;old=path.read_text(encoding='utf-8');new=fn(old)
    assert old!=new,name
    path.write_text(new,encoding='utf-8',newline='\n')
def section(s,start,end,new):
    assert s.count(start)==1 and s.count(end)==1,(start,end)
    a=s.index(start);b=s.index(end,a);return s[:a]+new.strip()+'\n\n'+s[b:]
limits='Claude Code installation/update and native session tests, and Codex Windows desktop tests, were not run for this release and remain unverified under DEC-RLS-005/006. Both distributed packages were byte-checked.'
evidence='docs/engineering/release-0-22-0/evidence/WO-RLS-036/README.md'
def root(s):
    s=section(s,'Observed public delivery (2026-10-02):','Startup/compaction hooks',f'''Observed public delivery (2026-10-03): Plugin **0.2.5** bundles released **SE Harness 0.22.0**. Codex CLI fresh installation, update from 0.2.4 and offline setup passed. [Public evidence]({evidence}) records exact identities and limits.

{limits}''')
    s=section(s,'### In preparation: 0.22.0 / plugin 0.2.5','## Released 0.21.0: fewer repository files','''### Published 0.22.0 / plugin 0.2.5

The [release package](docs/engineering/release-0-22-0/README.md) brings clearer
approval and verification requests, a PR before verification, and complete-release
preparation and recovery. Evaluator 0.22.0 and plugin 0.2.5 are public.

The single-approval release route still requires separate adoption and reviewed
provider configuration. This repository remains governed by 0.21.0. Documentation
integration and final release-marker closeout remain in progress.''')
    s=s.replace('## Released 0.21.0: fewer repository files','## Fewer repository files')
    s=section(s,'Claude native session tests remain unverified, with their WO-RLS-033 omission','See [migration]',limits)
    return s
edit('README.md',root)
def installation(s):
    s=section(s,'## Preparing 0.22.0 / 0.2.5','## Select the distribution',f'''## Published 0.22.0 / 0.2.5

Plugin 0.2.5 with evaluator 0.22.0 is public at
`{PUBLIC}`. VREC-PLG-032 verifies local package qualification.
Codex CLI fresh installation and update from the preserved public 0.2.4
installation passed. All 29 installed files match the qualified package.
Offline setup, exact evaluator identity, two-file initialization, resource lookup
and reuse passed on both routes.

{limits}

See the [public observations](../engineering/release-0-22-0/evidence/WO-RLS-036/README.md).
Installing a plugin does not upgrade a project's selected harness.''')
    s=s.replace('4031f0fa4b5c4a95651bd928a110d8b2d94f9775','abbec12ac5524c8adfb28693f846dd59de88f759').replace('7e366438165a40a14783bac650a2887e7ec8bc75',PUBLIC)
    s=s.replace('names plugin 0.2.4, evaluator 0.21.0','names plugin 0.2.5, evaluator 0.22.0').replace('13d401f5a0c94444dc3cf31c6f2863d23b77beb4b2c33756734b493606ad6789',WHEEL)
    s=s.replace('Default 0.21.0\ninitialization','Default 0.22.0\ninitialization').replace('On\n0.21.0 the entry','On\n0.21.0 and later the entry')
    s=section(s,'## Qualification limits','Model sessions require usable host authentication.',f'''## Qualification limits

Public fresh/update observations use Codex CLI 0.159.2. Installed bytes and
offline setup passed on both routes. Native debug prompt-input confirms skill
discovery; it does not prove hook execution or a model session.

VREC-PLG-032 retains exact-package Codex CLI/app-server qualification for startup,
activation, manual and automatic compaction, resume, session isolation and repeated
work. Those results apply to the same 29 file digests and host version observed
on the public routes. This is reuse of matching qualification evidence, not a
claim that authenticated model sessions ran in the fresh or update profiles.
Fresh profiles still need normal hook trust.

{limits}''')
    s=s.replace('released plugin 0.2.4 with evaluator 0.21.0','released plugin 0.2.5 with evaluator 0.22.0').replace('the selected 0.21.0 default','the selected 0.22.0 default')
    return s
edit('docs/notes/plugin-installation-guide.md',installation)
for path in ('plugins/verity-plane/codex/README.md','plugins/verity-plane/claude-code/README.md'):
    edit(path,lambda s:section(s,'Plugin 0.2.5 targets evaluator 0.22.0.','Development archives cannot',f'''Plugin 0.2.5 with evaluator 0.22.0 is published at
`{PUBLIC}`. VREC-PLG-032 verifies the qualified package.
Source documentation updates do not rewrite the published bytes or inventories.
{limits}'''))
edit('release/plugin-marketplace/README.md',lambda s:section(s,'This source is part of','## Install from Git',f'''Plugin 0.2.5 with evaluator 0.22.0 is published at
`{PUBLIC}`. Its PACKAGE-IDENTITY.json and assembly inventories
record exact source, wheel and package digests. Use them to compare installed files.
Source documentation updates do not replace the published package's original bytes.
Plugin updates do not adopt a repository's evaluator.

{limits}'''))
edit('docs/notes/plugin-marketplace-publication.md',lambda s:section(s,'## Current release work','## Assemble committed inputs',f'''## Current public release

[REL-SEH-034](../engineering/release-0-22-0/release/REL-SEH-034.md) records the
evaluator 0.22.0 / plugin 0.2.5 delivery. Human mmzen verified VREC-PLG-032.
WO-RLS-035 published the qualified tree at `{PUBLIC}`;
independent public readback matches all 69 files and the exact released wheel.

[WO-RLS-036 observations](../engineering/release-0-22-0/evidence/WO-RLS-036/README.md)
record Codex CLI public fresh installation, update from 0.2.4 and offline setup.
Current guidance integration and release-marker closeout remain in progress.
{limits}

This rollout uses the existing delivery route under selected evaluator 0.21.0.
The complete-release route still needs separate adoption and provider configuration.
Earlier release records retain their original results and decisions.'''))
def developer(s):
    s=s.replace('Candidate source in this checkout reports release-candidate version 0.22.0; it is not a published release.','Development source in this checkout reports 0.22.0; the exact release is public under RLS-SEH-032. Source execution does not establish released-evaluator identity.')
    s=section(s,'Agent skills and native instruction delivery come','Use the [plugin installation guide]',f'''Agent skills and native instruction delivery come from each host's installed
Verity Plane plugin. Public plugin 0.2.5 bundles evaluator 0.22.0 at marketplace
commit `{PUBLIC}`. Publication does not update a user's local
plugin or a repository's evaluator. WO-HUP-003 selected 0.21.0 here.
[Current public observations](../engineering/release-0-22-0/evidence/WO-RLS-036/README.md)
record Codex CLI routes and the explicitly untested Claude and desktop surfaces.''')
    s=section(s,'The [approved 0.22.0 package]','The prospective ','''The [0.22.0 package](../engineering/release-0-22-0/README.md) has published
evaluator 0.22.0 and plugin 0.2.5 under selected evaluator 0.21.0. WO-RLS-035
retains marketplace qualification/publication; WO-RLS-036 retains public-route
checks, current guidance and the remaining delivery closeout. Repository adoption
and provider configuration remain separate.''')
    return s
edit('docs/notes/developing-se-harness.md',developer)
def completion(s):
    s=s.replace('prepares the supporting product. WO-RLS-034 owns evaluator preparation;','has published the supporting product. WO-RLS-034 owns evaluator preparation;')
    s=s.replace('**Availability:** This source implements a future route. It is not active in the\nreleased 0.21.0 evaluator or plugin 0.2.4. Release and adopt the supporting product\nfirst. Apply the separately reviewed provider configuration before offering this\nroute as ready.','**Availability:** Evaluator 0.22.0 and plugin 0.2.5 contain this route. This\nrepository still selects 0.21.0, so the route is not active here. Adopt the\nsupporting release and apply the separately reviewed provider configuration\nbefore offering this route as ready.')
    s=s.replace('## Current 0.21.0 delivery',f'''## Current 0.22.0 delivery

Evaluator 0.22.0 and plugin 0.2.5 are public. The marketplace commit is
`{PUBLIC}`. [Public observations](../engineering/release-0-22-0/evidence/WO-RLS-036/README.md)
record exact package bytes, Codex CLI fresh/update routes and offline setup.
{limits}
Overall delivery is incomplete until documentation is verified, merged and read
back, and the authorized latest/last promotion has been observed.

## Historical 0.21.0 delivery''')
    return s
edit('docs/notes/release-delivery-completion.md',completion)
edit('docs/notes/harness-installation-and-upgrades.md',lambda s:section(s,'SE Harness 0.21.0 and plugin 0.2.4 are public.','<a id="minimal-installation-successor-candidate">','''SE Harness 0.22.0 and plugin 0.2.5 are public. This repository remains on
released evaluator 0.21.0 and the external-resource layout adopted under
WO-HUP-003. That adoption retired 44 selected resource copies. Publication
does not change the selection; adopting 0.22.0 requires separate approved work.
See the [current public observations](../engineering/release-0-22-0/evidence/WO-RLS-036/README.md),
including untested Claude Code and Codex Windows desktop routes.'''))
edit('docs/notes/harnessctl-reference.md',lambda s:s.replace('successor candidate command, unavailable in the governing 0.20.0 evaluator','available in the governing 0.21.0 evaluator and published 0.22.0').replace('## Released resource lookup (successor candidate)','## Released resource lookup').replace('The 0.21.0 release provides this command for repositories selecting the\n`released-resources-v1` layout. It is unavailable in this repository\'s selected\n0.20.0 evaluator. Use the independently installed candidate only for candidate\nqualification; it does not govern this repository or adopt the new layout.','Released 0.21.0 and 0.22.0 provide this command for repositories selecting the\n`released-resources-v1` layout. This repository uses its independently installed\n0.21.0 evaluator. Publishing 0.22.0 does not change that selection.'))
edit('docs/engineering/plugin-integration/README.md',lambda s:section(s,'## Next package: plugin 0.2.5','## Current public package: plugin 0.2.4',f'''## Current public package: plugin 0.2.5

Evaluator 0.22.0 and both plugin 0.2.5 packages are public at
`{PUBLIC}`. VREC-PLG-032 verifies qualification.
[WO-RLS-036 observations](../release-0-22-0/evidence/WO-RLS-036/README.md) record
Codex CLI public fresh/update routes and offline setup. Current documentation
integration and release-marker closeout remain in progress.
{limits}''').replace('## Current public package: plugin 0.2.4','## Historical public package: plugin 0.2.4'))
edit('docs/engineering/README.md',lambda s:s.replace('approved release preparation for\n  evaluator 0.22.0 and plugin 0.2.5, including all five delivery surfaces.','published evaluator 0.22.0 and plugin 0.2.5;\n  [public checks and remaining closeout](release-0-22-0/evidence/WO-RLS-036/README.md) cover all five delivery surfaces.'))
def tests(s):
    return s.replace('Published identities come from RLS-SEH-031','Published identities come from RLS-SEH-032').replace('EVALUATOR = "0.21.0"','EVALUATOR = "0.22.0"').replace('13d401f5a0c94444dc3cf31c6f2863d23b77beb4b2c33756734b493606ad6789',WHEEL).replace('release-0-21-0/releases/RLS-SEH-031.md','release-0-22-0/releases/RLS-SEH-032.md').replace('release-0-21-0/evidence/WO-RLS-033/publication.json','release-0-22-0/evidence/WO-RLS-036/publication-receipt.json').replace('"RLS-SEH-031", "released"','"RLS-SEH-032", "released"')
edit('tests/plugin_integration/package_assembly/test_refresh_guidance.py',tests)
print('Updated current publication claims within WO-RLS-036; frozen package/evidence bytes preserved.')
