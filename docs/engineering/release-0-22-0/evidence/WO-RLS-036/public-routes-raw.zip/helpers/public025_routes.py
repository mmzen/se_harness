"""Actual public Codex CLI fresh and 0.2.4 update routes in disposable profiles."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,tempfile
WORK=Path(__file__).resolve().parent
OUT=WORK/'release022/public025';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(WORK/'iar-demo-tools'))
from run_demo import child_env
EXE=r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe'
PUBLIC='7d30907f15bd7e06fb632e1ebf4e88e01b68726c'
PREVIOUS='7e366438165a40a14783bac650a2887e7ec8bc75'
SOURCE='https://github.com/mmzen/se_harness#plugin-marketplace'
kind=sys.argv[1];assert kind in ('fresh','update','setup-fresh','setup-update')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(label,result):
    p=OUT/(label+'.json');assert not p.exists(),p
    p.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
def invoke(label,args,base,env,allowed=(0,)):
    argv=list(map(str,args));observed=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=subprocess.run(argv,cwd=base,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=240)
    save(label,{'observed_at':observed,'argv':argv,'cwd':str(base),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    print(json.dumps({'operation':label,'exit_code':p.returncode}),flush=True)
    assert p.returncode in allowed,(label,p.stderr[-1200:],p.stdout[-600:])
    return p.stdout
if kind.startswith('setup-'):
    route=json.loads((OUT/(kind[6:]+'-route.json')).read_text())
    plugin=Path(route['installed_path'])
    identity=json.loads((WORK/'release022/plugin025-marketplace/PACKAGE-IDENTITY.json').read_text())['evaluator']
    base=Path(tempfile.mkdtemp(prefix='p025s-'));target=base/'repository';target.mkdir();data=base/'data'
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
    def call(label,args,allowed=(0,)):return invoke(kind+'-'+label,args,base,env,allowed)
    wheel=plugin/'packages'/identity['archive'];assert sha(wheel)==identity['archive_sha256']
    call('initial',[sys.executable,'-I',plugin/'scripts/setup.py','--target',target,'--data-root',data,'--wheel',wheel],(1,2))
    py=data/'evaluators'/identity['version']/identity['archive_sha256']/'Scripts/python.exe';assert py.is_file()
    result=json.loads(call('identity',[py,'-I','-m','se_harness','identity','--role','released-evaluator','--expected-version',identity['version'],'--expected-root',py.parent.parent,'--checkout-root',target,'--evaluator-payload-sha256',identity['payload_sha256'],'--evaluator-wheel-sha256',identity['archive_sha256'],'--require-isolated-python','--json']));assert result['passed']
    assert not list(target.iterdir())
    call('init-preview',[py,'-I','-m','se_harness','init',target,'--project-name','Public plugin fixture','--dry-run','--json'])
    call('init',[py,'-I','-m','se_harness','init',target,'--project-name','Public plugin fixture','--json'])
    assert {p.name for p in target.iterdir()}=={'.engineering-harness.toml','.engineering-harness.lock'}
    call('doctor',[py,'-I','-m','se_harness','doctor',target,'--json'])
    resources=json.loads(call('resources',[py,'-I','-m','se_harness','resources',target,'--resource','ENGINEERING_HARNESS.md','--content','--json']))
    call('reuse',[sys.executable,'-I',plugin/'scripts/setup.py','--target',target,'--data-root',data,'--wheel',wheel])
    save(kind+'-result',{'status':'pass','host':'codex','kind':kind[6:],'public_revision':PUBLIC,'target':str(target),'data':str(data),'python':str(py),'wheel_sha256':identity['archive_sha256'],'evaluator_version':identity['version'],'default_files':sorted(p.name for p in target.iterdir()),'native_session_claim':False})
    sys.exit(0)
if kind=='fresh':
    base=Path(tempfile.mkdtemp(prefix='p025f-'))
else:
    old=json.loads((WORK/'public024-evidence-1002/fresh-codex-route.json').read_text())
    base=Path(old['profile']);assert base==WORK/'public024-fresh-1002'
env=child_env(base,'codex')
env.update(GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true',GIT_CONFIG_KEY_1='core.autocrlf',GIT_CONFIG_VALUE_1='false',PYTHONDONTWRITEBYTECODE='1')
for key in ('CODEX_HOME','CLAUDE_CONFIG_DIR','APPDATA','LOCALAPPDATA','TEMP'):Path(env[key]).mkdir(parents=True,exist_ok=True)
def native(label,args):return invoke(kind+'-'+label,[EXE,*args],base,env)
def market(label):return next(x for x in json.loads(native(label,['plugin','marketplace','list','--json']))['marketplaces'] if x['name']=='se-harness')
def installed(label):return next(x for x in json.loads(native(label,['plugin','list','--marketplace','se-harness','--json']))['installed'] if x['pluginId']=='verity-plane@se-harness')
def revision(cache,label):return invoke(kind+'-'+label,['git','-c','safe.directory='+cache.as_posix(),'-C',cache,'rev-parse','HEAD'],base,env).strip()
version=native('version',['--version']).strip()
report={'host':'codex','kind':kind,'host_version':version,'profile':str(base),'source':SOURCE,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
if kind=='fresh':
    assert not any(x['name']=='se-harness' for x in json.loads(native('before',['plugin','marketplace','list','--json']))['marketplaces'])
    native('add',['plugin','marketplace','add','mmzen/se_harness','--ref','plugin-marketplace','--json'])
else:
    prior=installed('before');assert prior['version']=='0.2.4',prior
    source=market('source-before');cache=Path(source['root']);assert revision(cache,'revision-before')==PREVIOUS
    oldpath=Path(old['installed_path']);assert oldpath.resolve().is_relative_to(base.resolve())
    assert all(sha(oldpath/name)==digest for name,digest in old['files'].items())
    report.update(starting_version='0.2.4',starting_revision=PREVIOUS,starting_source=SOURCE,starting_plugin=prior,starting_installed_path=str(oldpath),starting_files=old['files'],starting_method='Preserved actual public installation from WO-RLS-033; installed inventory checked before update.')
    native('refresh',['plugin','marketplace','upgrade','se-harness','--json'])
response=json.loads(native('install' if kind=='fresh' else 'update',['plugin','add','verity-plane@se-harness','--json']))
row=installed('after');assert row['version']=='0.2.5',row
source=market('source-after');cache=Path(source['root']);assert cache.resolve().is_relative_to(base.resolve()) and revision(cache,'revision-after')==PUBLIC
path=Path(response['installedPath']);assert path.resolve().is_relative_to(base.resolve())
package=WORK/'release022/plugin025-marketplace/packages/codex/verity-plane'
files={p.relative_to(package).as_posix():sha(p) for p in package.rglob('*') if p.is_file()}
assert all(sha(path/name)==digest for name,digest in files.items())
assert {p.relative_to(path).as_posix() for p in path.rglob('*') if p.is_file()}==set(files)
active=native('active',['debug','prompt-input','List installed Verity Plane skills.']);assert 'harness-orient' in active
report.update(status='pass',revision=PUBLIC,marketplace=source,plugin=row,installed_path=str(path),files=files,content_sha256=hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest(),plugin_version='0.2.5',evaluator_version='0.22.0',all_installed_bytes_match=True,active_method='Native debug prompt-input; no model session or desktop pass inferred.')
save(kind+'-route',report)
print(json.dumps({'route':kind,'status':'pass','files':len(files)}),flush=True)
