"""Publish only the byte-checked plugin 0.2.5 descendant; never force refs."""
from pathlib import Path
import datetime,hashlib,io,json,os,subprocess,sys,tarfile,tomllib,urllib.request
from release022_ctl import REPO,OUT
GIT=r'C:\Program Files\Git\cmd\git.exe'
GH=r'C:\Program Files\GitHub CLI\gh.exe'
G=[GIT,'-c','core.longpaths=true','-c','core.autocrlf=false','-c','safe.directory='+REPO.as_posix(),'-C',str(REPO)]
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true',GIT_CONFIG_KEY_1='core.autocrlf',GIT_CONFIG_VALUE_1='false')
MARKET=OUT/'plugin025-marketplace'
OLD='7e366438165a40a14783bac650a2887e7ec8bc75'
DEST='https://github.com/mmzen/se_harness.git'
REF='refs/heads/plugin-marketplace'
IDENTITY='b3ce06c6f4ac9bdfed7ffd26eb16683e260814c82d7dba188f78a0180c8a4e61'
WHEEL='44543f242ed19bb30cfd65da415372a87508a6e439204d7f3e37f9f45aefe4e4'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def save(label,data):
    path=OUT/(label+'.json');assert not path.exists(),path
    path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
def run(label,argv,cwd=REPO):
    p=subprocess.run([str(x) for x in argv],cwd=cwd,env=ENV,capture_output=True,text=True,encoding='utf-8')
    result={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':[str(x) for x in argv],'cwd':str(cwd),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    save(label,result);assert p.returncode==0,(label,p.stderr)
    return result
def g(*args,env=ENV,input=None):return subprocess.check_output(G+list(args),env=env,input=input)
def record():
    path=REPO/'docs/engineering/release-0-22-0/verification-records/VREC-PLG-032.md'
    rec=tomllib.loads(path.read_text(encoding='utf-8').split('+++',2)[1])
    assert rec['status']=='verified' and rec['verified_by']=='mmzen'
    assert rec['commit']=='164286460d77c94e173ff12d9133ba95ef9c8692'
    return rec,sha(path.read_bytes())
identity_bytes=(MARKET/'PACKAGE-IDENTITY.json').read_bytes()
assert sha(identity_bytes)==IDENTITY
identity=json.loads(identity_bytes)
expected={**identity['files'],'PACKAGE-IDENTITY.json':IDENTITY}
assert identity['plugin_version']=='0.2.5' and identity['evaluator']['archive_sha256']==WHEEL
assert g('remote','get-url','--push','origin').decode().strip()==DEST
rec,record_sha=record()
mode=sys.argv[1]
if mode=='prepare':
    assert not (OUT/'plugin025-publication-prepared.json').exists()
    checked=run('plugin025-publication-package-check',read(OUT/'plugin025-check.run.json')['argv'])
    result=json.loads(checked['stdout']);assert result['accepted'] and result['identity_sha256']==IDENTITY
    actual={p.relative_to(MARKET).as_posix():p for p in MARKET.rglob('*') if p.is_file()}
    assert set(actual)==set(expected)
    for name,p in actual.items():
        assert not p.is_symlink() and p.resolve().is_relative_to(MARKET.resolve())
        assert sha(p.read_bytes())==expected[name],name
    index=OUT/'plugin025-publication.index';assert not index.exists()
    env=dict(ENV,GIT_INDEX_FILE=str(index))
    g('read-tree','--empty',env=env)
    for name in sorted(expected):
        oid=g('hash-object','-w','--stdin',input=actual[name].read_bytes()).decode().strip()
        g('update-index','--add','--cacheinfo','100644,'+oid+','+name,env=env)
    tree=g('write-tree',env=env).decode().strip()
    commit=g('commit-tree',tree,'-p',OLD,'-m','Publish Verity Plane 0.2.5 with released SE Harness 0.22.0').decode().strip()
    ref='refs/heads/prepared/marketplace-0.2.5'
    assert not g('for-each-ref','--format=%(refname)',ref).strip()
    g('update-ref',ref,commit,'0'*40)
    plan={'destination':DEST,'ref':REF,'expected_old_commit':OLD,'prepared_commit':commit,'tree':tree,'retained_local_ref':ref,'source_commit':identity['source']['revision'],'release_revision':identity['evaluator']['release_revision'],'verification':'VREC-PLG-032','verified_candidate':rec['commit'],'verification_record_sha256':record_sha,'plugin_version':'0.2.5','evaluator_version':'0.22.0','package_identity_sha256':IDENTITY,'wheel_sha256':WHEEL,'file_count':len(expected),'authority':'Retained mmzen release-execution request and approved REL-SEH-034 / WO-RLS-035; verification I verify VREC-PLG-032.','omissions':['Claude Code host routes untested','Codex Windows desktop untested'],'changed_paths':g('diff','--name-status',OLD,commit).decode().splitlines(),'status':'Prepared locally; no remote mutation.'}
    save('plugin025-publication-prepared',plan)
    print(json.dumps(plan));sys.exit(0)
plan=read(OUT/'plugin025-publication-prepared.json');new=plan['prepared_commit']
assert plan['verification_record_sha256']==record_sha
assert plan['destination']==DEST and plan['ref']==REF and plan['expected_old_commit']==OLD
assert g('rev-parse',new+'^').decode().strip()==OLD
assert g('rev-parse',new+'^{tree}').decode().strip()==plan['tree']
entries={row.split('\t',1)[1]:row.split('\t',1)[0].split() for row in g('ls-tree','-r',new).decode().splitlines()}
assert set(entries)==set(expected)
for path,(file_mode,kind,oid) in entries.items():
    assert (file_mode,kind)==('100644','blob')
    assert sha(g('cat-file','blob',oid))==expected[path],path
if mode=='publish':
    assert not (OUT/'plugin025-publication-receipt.json').exists()
    gate=read(OUT/'plugin025-marketplace-preaction.json')
    assert gate['operation']['outcome']=='completed' and gate['compliance']['status']=='pass'
    controls=json.loads(run('plugin025-publication-controls',[GH,'api','repos/mmzen/se_harness/rulesets/23468315'])['stdout'])
    assert controls['enforcement']=='active' and not controls['bypass_actors']
    assert controls['conditions']['ref_name']['include']==[REF]
    assert {'non_fast_forward','deletion'}<={r['type'] for r in controls['rules']}
    before=run('plugin025-publication-before',G+['ls-remote','origin',REF]);assert before['stdout'].strip().split()==[OLD,REF]
    pushed=run('plugin025-publication-push',G+['push','origin',new+':'+REF])
    after=run('plugin025-publication-after',G+['ls-remote','origin',REF]);assert after['stdout'].strip().split()==[new,REF]
    save('plugin025-publication-receipt',{'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plan':plan,'controls':controls,'before':before,'push':pushed,'after':after,'status':'Published; independent public archive comparison follows.'})
    print(json.dumps({'published_commit':new,'status':'Published; public byte readback follows.'}))
elif mode=='readback':
    assert (OUT/'plugin025-publication-receipt.json').exists()
    before=run('plugin025-public-readback-before',G+['ls-remote','origin',REF]);assert before['stdout'].strip().split()==[new,REF]
    url='https://codeload.github.com/mmzen/se_harness/tar.gz/refs/heads/plugin-marketplace'
    with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'SE-Harness-publication-readback'}),timeout=60) as response:
        data=response.read();http=response.status;resolved=response.url
    archive=OUT/'plugin025-public-marketplace.tar.gz';assert not archive.exists();archive.write_bytes(data)
    actual={};roots=set()
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tar:
        for member in tar.getmembers():
            if member.isdir():continue
            assert member.isfile() and not member.issym() and not member.islnk()
            root,path=member.name.split('/',1);roots.add(root)
            assert path not in actual and '..' not in path.split('/')
            actual[path]=sha(tar.extractfile(member).read())
    assert len(roots)==1 and actual==expected
    after=run('plugin025-public-readback-after',G+['ls-remote','origin',REF]);assert after['stdout'].strip().split()==[new,REF]
    result={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'result':'pass','url':url,'resolved_url':resolved,'http_status':http,'public_commit':new,'plugin_version':'0.2.5','evaluator_version':'0.22.0','package_identity_sha256':IDENTITY,'wheel_sha256':WHEEL,'file_count':len(actual),'files':actual,'all_public_bytes_match_verified_distribution':True,'archive_sha256':sha(data),'archive_bytes':len(data),'expected_source':'Previously verified local package inventory, independent of downloaded bytes.','native_public_installation_claim':False,'pending_work_order':'WO-RLS-036','omissions':plan['omissions']}
    save('plugin025-public-readback',result)
    print(json.dumps({k:result[k] for k in ('result','public_commit','file_count','all_public_bytes_match_verified_distribution')}))
else:raise ValueError(mode)
