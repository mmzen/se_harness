import copy,datetime,hashlib,json,subprocess,sys
from release022_ctl import REPO,OUT
root=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-036'
previous=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-035/delivery-plan-v2.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def write(name,data):
    p=root/name;assert not p.exists(),p;p.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8');return p
def refs(*paths):return [{'path':p.relative_to(REPO).as_posix(),'sha256':sha(p)} for p in paths]
report=read(root/'public-routes.json');plan=read(previous);surfaces={r['id']:r for r in plan['surfaces']}
market=surfaces['marketplace'];market['expected']['public_revision']=report['public_commit']
for host,folder in (('codex','codex'),('claude-code','claude')):
    package=OUT/'plugin025-marketplace/packages'/folder/'verity-plane'
    files={p.relative_to(package).as_posix():sha(p) for p in package.rglob('*') if p.is_file()}
    market['expected'][host+'_content_sha256']=hashlib.sha256(json.dumps(files,sort_keys=True,separators=(',',':')).encode()).hexdigest()
market['next_action']='Published exact packages; Codex CLI public fresh/update routes and setup passed. Preserve the explicit Claude and desktop omissions.'
market['inventory_method']='SHA-256 of UTF-8 JSON of all package-relative file SHA-256 values, sorted keys and compact separators. Independent qualification files supply expected values; native installed files are compared separately.'
surfaces['documentation']['next_action']='Verify and integrate the current guidance, then read the exact merged documents back.'
surfaces['release_markers']['next_action']='After documentation and required observations, apply the retained latest/last grant using exact targets and old-ref checks.'
plan['previous_plan']={'path':previous.relative_to(REPO).as_posix(),'sha256':sha(previous)}
plan['identity_update']='Bind observed public revision and use the recorded installed-file inventory algorithm for content identities; previous assembly-inventory file hashes remain in the preceding plan.'
planpath=write('delivery-plan-v3.json',plan)
now=datetime.datetime.now(datetime.timezone.utc).isoformat();obs=[]
for surface in plan['surfaces']:
    ident=copy.deepcopy(surface['expected']);sid=surface['id']
    row={'id':sid,'status':'pending' if sid in ('documentation','release_markers') else 'pass','observed_at':now,'source':surface['destination'],'identity':ident,'evidence':{}}
    if sid=='evaluator':
        row['evidence']={k:refs(root/'public-routes.json',root/'public-routes-raw.zip') for k in ('publisher','public_install')}
    elif sid=='marketplace':
        row['evidence']={'assembly':refs(root/'publication-receipt.json'),'qualification':refs(REPO/'docs/engineering/release-0-22-0/verification-records/VREC-PLG-032.md',REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-035/qualification-review.md'),'public_ref':refs(root/'public-readback.json')}
        row['routes']=[]
        for kind in ('fresh','update'):
            source=report['routes'][kind]
            assert source['content_sha256']==ident['codex_content_sha256']
            route={k:source[k] for k in ('host','host_version','kind','status','observed_at','revision','plugin_version','content_sha256','evaluator_version')}
            route.update(source=surface['destination'],wheel_sha256=ident['wheel_sha256'],evidence=refs(root/'public-routes.json',root/'public-routes-raw.zip'))
            if kind=='update':route.update(starting_version=source['starting_version'],starting_source=surface['destination'])
            row['routes'].append(route);row['evidence']['codex_'+('fresh_install' if kind=='fresh' else 'update')]=refs(root/'public-routes.json',root/'public-routes-raw.zip')
    elif sid=='demonstration':row['evidence']={'deployment':refs(root/'public-routes.json',root/'public-routes-raw.zip')}
    obs.append(row)
rls=REPO/'docs/engineering/release-0-22-0/releases/RLS-SEH-032.md'
obspath=write('delivery-observations-v3.json',{'schema':'se-harness-delivery-observations/v1','plan_sha256':sha(planpath),'observed_at':now,'release':{'record':'RLS-SEH-032','status':'released','source':'https://github.com/mmzen/se_harness/blob/01ec43c86c9d30949295c07ac91c742be91e713a/docs/engineering/release-0-22-0/releases/RLS-SEH-032.md','observed_at':now,'evidence':refs(rls,root/'public-routes.json')},'surfaces':obs})
argv=[sys.executable,'-B','scripts/check_release_delivery.py','--plan',str(planpath),'--observations',str(obspath),'--evidence-root',str(REPO),'--json']
p=subprocess.run(argv,cwd=REPO,capture_output=True,text=True,encoding='utf-8');result=json.loads(p.stdout)
write('delivery-result-v3.json',result)
(OUT/'public025-delivery-check.json').write_text(json.dumps({'argv':argv,'cwd':str(REPO),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2),encoding='utf-8')
assert p.returncode==1 and result['status']=='incomplete',(p.returncode,result,p.stderr)
print(json.dumps({'exit_code':p.returncode,'status':result['status'],'surfaces':result.get('surfaces'),'reason':'Documentation integration and release markers remain outstanding.'},indent=2))
