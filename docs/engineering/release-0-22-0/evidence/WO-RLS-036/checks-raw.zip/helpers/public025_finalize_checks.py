import hashlib,json,subprocess,sys,tomllib
from release022_ctl import REPO,OUT
root=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-036'
git=r'C:\Program Files\Git\cmd\git.exe'
path='docs/engineering/release-0-22-0/work-orders/WO-RLS-036.md';base='73abb4902fe819a6d4f11ce160dbe96a90249122'
raw=subprocess.check_output([git,'-C',str(REPO),'show',base+':'+path]);record=tomllib.loads(raw.decode().split('+++',2)[1])
assert record['status']=='approved' and record['lifecycle_events'][-1]['decided_by']=='mmzen'
authority=root/'marker-authority.json';assert not authority.exists()
authority.write_text(json.dumps({'source_commit':base,'source_path':path,'source_sha256':hashlib.sha256(raw).hexdigest(),'approval_event':record['lifecycle_events'][-1],'approved_body':raw.decode().split('+++',2)[2],'meaning':'Retained human release-execution grant; no marker mutation, new approval or changed scope.'},indent=2)+'\n',encoding='utf-8')
obs_path=root/'delivery-observations-v4.json';obs=json.loads(obs_path.read_text())
(OUT/'public025-observations-v4-draft-before-binding-correction.json').write_bytes(obs_path.read_bytes())
row=next(r for r in obs['surfaces'] if r['id']=='release_markers')
row['evidence']['authorization']=[{'path':authority.relative_to(REPO).as_posix(),'sha256':hashlib.sha256(authority.read_bytes()).hexdigest()}]
obs_path.write_text(json.dumps(obs,indent=2)+'\n',encoding='utf-8')
argv=[sys.executable,'-B','scripts/check_release_delivery.py','--plan',str(root/'delivery-plan-v3.json'),'--observations',str(obs_path),'--evidence-root',str(REPO),'--json']
p=subprocess.run(argv,cwd=REPO,capture_output=True,text=True,encoding='utf-8');assert p.returncode==1
(OUT/'public025-result-v4-draft-before-binding-correction.json').write_bytes((root/'delivery-result-v4.json').read_bytes())
(root/'delivery-result-v4.json').write_text(p.stdout,encoding='utf-8')
(OUT/'public025-delivery-check-final.json').write_text(json.dumps({'argv':argv,'cwd':str(REPO),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2),encoding='utf-8')
argv=[sys.executable,'-B','-X','utf8',str(OUT.parent/'public025_checks.py')]
p=subprocess.run(argv,cwd=REPO,capture_output=True,text=True,encoding='utf-8')
(OUT/'public025-focused-checks.json').write_text(json.dumps({'argv':argv,'cwd':str(REPO),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2),encoding='utf-8')
print(p.stdout);assert p.returncode==0,p.stderr
