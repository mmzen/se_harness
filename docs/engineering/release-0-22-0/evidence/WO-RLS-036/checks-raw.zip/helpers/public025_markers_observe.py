import json,hashlib,subprocess,sys
from release022_ctl import REPO,OUT
root=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-036'
latest=json.loads((OUT/'public025-latest-before.json').read_text());last=json.loads((OUT/'public025-last-before.json').read_text())
assert latest['exit_code']==last['exit_code']==0 and last['result']['object']['type']=='commit'
dest=root/'markers-before.json';assert not dest.exists()
dest.write_text(json.dumps({'latest':latest,'last':last,'effect':'Read-only; neither marker changed.'},indent=2)+'\n',encoding='utf-8')
def ref(p):return {'path':p.relative_to(REPO).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
obs=json.loads((root/'delivery-observations-v3.json').read_text())
row=next(r for r in obs['surfaces'] if r['id']=='release_markers')
row['identity']={'latest':latest['result']['tag_name'],'last':last['result']['object']['sha']}
row['observed_at']=last['observed_at']
row['evidence']={'authorization':[ref(REPO/'docs/engineering/release-0-22-0/work-orders/WO-RLS-036.md'),ref(REPO/'docs/engineering/release-0-22-0/release/REL-SEH-034.md')],'readback':[ref(dest)]}
op=root/'delivery-observations-v4.json';assert not op.exists();op.write_text(json.dumps(obs,indent=2)+'\n',encoding='utf-8')
argv=[sys.executable,'-B','scripts/check_release_delivery.py','--plan',str(root/'delivery-plan-v3.json'),'--observations',str(op),'--evidence-root',str(REPO),'--json']
p=subprocess.run(argv,cwd=REPO,capture_output=True,text=True,encoding='utf-8');result=json.loads(p.stdout)
assert p.returncode==1 and result['status']=='incomplete'
(root/'delivery-result-v4.json').write_text(p.stdout,encoding='utf-8')
(OUT/'public025-delivery-check-v4.json').write_text(json.dumps({'argv':argv,'cwd':str(REPO),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2),encoding='utf-8')
print(json.dumps({'status':result['status'],'surfaces':[{k:r[k] for k in ('id','status')} for r in result['surfaces']]}))
