"""Focused documentation, public receipt and evidence-binding checks."""
from pathlib import Path
import hashlib,importlib.util,json,posixpath,re,subprocess,sys,zipfile
REPO=Path.cwd();root=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-036'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report=read(root/'public-routes.json')
archive=root/report['raw_archive']['path'];assert sha(archive)==report['raw_archive']['sha256']
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(report['raw_archive']['entries'])
    for name,digest in report['raw_archive']['entries'].items():assert hashlib.sha256(z.read(name)).hexdigest()==digest,name
assert report['public_commit']=='7d30907f15bd7e06fb632e1ebf4e88e01b68726c'
assert report['routes']['fresh']['files']==report['routes']['update']['files']==report['native_evidence']['matching_package_files']
assert report['routes']['update']['starting_version']=='0.2.4'
assert report['omissions']['claude_code']==report['omissions']['codex_windows_desktop']=='not tested / unverified'
for kind in ('fresh','update'):assert report['routes'][kind]['status']==report['setup'][kind]['status']=='pass'
sources=['README.md','docs/engineering/README.md','docs/engineering/plugin-integration/README.md','docs/notes/developing-se-harness.md','docs/notes/harness-installation-and-upgrades.md','docs/notes/harnessctl-reference.md','docs/notes/plugin-installation-guide.md','docs/notes/plugin-marketplace-publication.md','docs/notes/release-delivery-completion.md']
spec=importlib.util.spec_from_file_location('refresh_guidance',REPO/'tests/plugin_integration/package_assembly/test_refresh_guidance.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
files={name:(REPO/name).read_bytes() for name in sources}
for name in sources:
    for target in re.findall(r'\[[^]]*\]\(([^)]+)\)',files[name].decode()):
        if re.match(r'(?:https?://|mailto:|#)',target):continue
        path=posixpath.normpath(posixpath.join(posixpath.dirname(name),target.partition('#')[0]))
        if (REPO/path).is_file():files[path]=(REPO/path).read_bytes()
        elif (REPO/path).is_dir():files[path]=b''
findings=m.link_findings(files,sources);print(json.dumps({'source_link_findings':findings}),flush=True);assert not findings
argv=[sys.executable,'-B','-X','utf8','-m','unittest','tests.test_progressive_documentation','tests.plugin_integration.package_assembly.test_refresh_guidance']
p=subprocess.run(argv,cwd=REPO,capture_output=True,text=True,encoding='utf-8');print(json.dumps({'argv':argv,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}),flush=True);assert p.returncode==0
argv=[sys.executable,'-B','scripts/check_release_delivery.py','--plan',str(root/'delivery-plan-v3.json'),'--observations',str(root/'delivery-observations-v4.json'),'--evidence-root',str(REPO),'--json']
p=subprocess.run(argv,cwd=REPO,capture_output=True,text=True,encoding='utf-8');result=json.loads(p.stdout)
states={r['id']:r['status'] for r in result['surfaces']}
assert p.returncode==1 and result['status']=='incomplete'
assert all(states[k]=='satisfied' for k in ('evaluator','marketplace','demonstration'))
assert states['documentation']=='pending' and states['release_markers'] in ('pending','failed')
assert all(f['code'] not in ('digest','unreadable') for r in result['surfaces'] for f in r['findings']),result
print(json.dumps({'delivery_exit':p.returncode,'delivery_status':result['status'],'surfaces':states,'assessment':'Correctly incomplete until documentation integration/readback and latest/last promotion. No host re-tests or external mutation.'}),flush=True)
