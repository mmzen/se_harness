import hashlib,json,subprocess,sys,tomllib,zipfile
from pathlib import Path
from claude025_followup_ctl import REPO,OUT,WORK,run
E=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-038'
G=[r'C:\Program Files\Git\cmd\git.exe','-c','core.longpaths=true','-c','core.autocrlf=false','-c','safe.directory='+REPO.as_posix(),'-C',str(REPO)]
def git(*args):return subprocess.check_output(G+list(args),text=True,encoding='utf8').strip()
context=json.loads((OUT/'completed-context.json').read_text())
assert context['state']['after'][0]['status']=='implemented'
assert context['instruction_discovery']['status']=='available'
print(json.dumps(context['restitution'],indent=2))
assert context['procedure']['id']=='PROC-WO-PREPARE-VREC'
history=git('log','--all','--format=','--name-only','--','docs/engineering/**/VREC-RLS-*.md')
ident='VREC-RLS-001'
assert ident not in history and not list(REPO.glob('docs/engineering/**/'+ident+'.md'))
vrec={'id':ident,'path':'docs/engineering/release-0-22-0/verification-records/'+ident+'.md','evaluator_path':'docs/engineering/release-0-22-0/evidence/'+ident+'-evaluator.json','local_ref_history_paths':history.splitlines()}
(OUT/'selected-vrec.json').write_text(json.dumps(vrec,indent=2)+'\n',encoding='utf8',newline='\n')
archive=E/'completion-raw.zip';assert not archive.exists()
labels=['handoff-packet','review-preflight','implementation-handoff','completion-preview','completion-apply','completed-context','selected-vrec']
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for label in labels:
        for suffix in ['.json','-invocation.json']:
            p=OUT/(label+suffix)
            if p.exists():z.writestr(p.name,p.read_bytes())
    z.writestr('capture-driver.py',Path(__file__).read_bytes())
review=json.loads((OUT/'reviewed-package.json').read_text())
for path,want in review['historical_records'].items():assert hashlib.sha256((REPO/path).read_bytes()).hexdigest()==want,path
subprocess.run([sys.executable,'-B','-X','utf8',str(WORK/'claude025_followup_commit.py'),'verification-candidate','Record Claude 0.2.5 follow-up evidence and correct current coverage'],check=True)
candidate=json.loads((OUT/'verification-candidate.json').read_text())['commit']
args=['--id',ident,'--work-order','WO-RLS-038','--verification','VER-RLS-002','--owner','Codex','--domain','release-0-22-0']
evidence=[]
for p in sorted(E.rglob('*')):
    if p.is_file():evidence.append(p.relative_to(REPO).as_posix())
for p in evidence:args+=['--evidence',p]
code,data=run('verification-capture','capture-verification',*args)
assert code==0 and data['operation']['outcome']=='completed',data
record=tomllib.loads((REPO/vrec['path']).read_text().split('+++')[1])
assert record['status']=='ready' and record['commit']==candidate
assert (REPO/vrec['evaluator_path']).exists()
print(json.dumps({'candidate':candidate,'vrec':record,'evidence_count':len(evidence)},indent=2))
