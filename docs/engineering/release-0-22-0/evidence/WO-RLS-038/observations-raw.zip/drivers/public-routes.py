"""Post-release Claude route observations; no source or formal-record changes."""
from pathlib import Path
import datetime, hashlib, json, subprocess, sys, tempfile

WORK = Path(__file__).resolve().parent
OUT = WORK / 'claude025-followup-20261003'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(WORK / 'iar-demo-tools'))
from run_demo import child_env

EXE = r'C:\Users\mathi\.local\bin\claude.exe'
PUBLIC = '7d30907f15bd7e06fb632e1ebf4e88e01b68726c'
PREVIOUS = '7e366438165a40a14783bac650a2887e7ec8bc75'
SOURCE = 'https://github.com/mmzen/se_harness#plugin-marketplace'
kind = sys.argv[1]
assert kind in ('fresh', 'update')
old = json.loads((WORK / 'public024-evidence-1002/fresh-claude-route.json').read_text())
base = Path(tempfile.mkdtemp(prefix='c025f-')) if kind == 'fresh' else Path(old['profile'])
env = child_env(base, 'claude')
env.update(GIT_CONFIG_COUNT='2', GIT_CONFIG_KEY_0='core.longpaths', GIT_CONFIG_VALUE_0='true', GIT_CONFIG_KEY_1='core.autocrlf', GIT_CONFIG_VALUE_1='false', PYTHONDONTWRITEBYTECODE='1')
for key in ('CODEX_HOME', 'CLAUDE_CONFIG_DIR', 'APPDATA', 'LOCALAPPDATA', 'TEMP'):
    Path(env[key]).mkdir(parents=True, exist_ok=True)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(label, result):
    p = OUT / (kind + '-' + label + '.json')
    assert not p.exists(), p
    p.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')

def invoke(label, args):
    args = list(map(str, args))
    stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = subprocess.run(args, cwd=base, env=env, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=180)
    save(label, {'argv': args, 'cwd': str(base), 'observed_at': stamp, 'exit_code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr})
    print(json.dumps({'route': kind, 'operation': label, 'exit_code': p.returncode}), flush=True)
    assert p.returncode == 0, (label, p.stderr[-1200:], p.stdout[-600:])
    return p.stdout

def native(label, args):
    return invoke(label, [EXE, *args])

def market(label):
    return next(x for x in json.loads(native(label, ['plugin', 'marketplace', 'list', '--json'])) if x['name'] == 'se-harness')

def installed(label):
    return next(x for x in json.loads(native(label, ['plugin', 'list', '--json'])) if x['id'] == 'verity-plane@se-harness')

def revision(cache, label):
    return invoke(label, ['git', '-c', 'safe.directory=' + cache.as_posix(), '-C', cache, 'rev-parse', 'HEAD']).strip()

report = {'host': 'claude', 'kind': kind, 'profile': str(base), 'source': SOURCE,
          'authorization': 'Human mmzen: Ok, go for the tests. Post-release observations only.',
          'observed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'incomplete'}
try:
    report['host_version'] = native('version', ['--version']).strip()
    if kind == 'fresh':
        assert not any(x['name'] == 'se-harness' for x in json.loads(native('before', ['plugin', 'marketplace', 'list', '--json'])))
        native('add', ['plugin', 'marketplace', 'add', 'mmzen/se_harness@plugin-marketplace'])
    else:
        prior = installed('before')
        assert prior['version'] == '0.2.4', prior
        source = market('source-before')
        assert source['repo'] == 'mmzen/se_harness' and source['ref'] == 'plugin-marketplace'
        cache = Path(source['installLocation'])
        assert cache.resolve().is_relative_to(base.resolve())
        assert revision(cache, 'revision-before') == PREVIOUS
        prior_path = Path(prior['installPath'])
        assert prior_path.resolve().is_relative_to(base.resolve())
        assert all(sha(prior_path / name) == digest for name, digest in old['files'].items())
        report.update(starting_version='0.2.4', starting_revision=PREVIOUS, starting_inventory=old['files'])
        native('refresh', ['plugin', 'marketplace', 'update', 'se-harness'])
    source = market('source-selected')
    cache = Path(source['installLocation'])
    assert cache.resolve().is_relative_to(base.resolve())
    assert revision(cache, 'revision-selected') == PUBLIC, 'Public version changed: do not assume old expected bytes.'
    native('install' if kind == 'fresh' else 'update', ['plugin', 'install' if kind == 'fresh' else 'update', 'verity-plane@se-harness', '--json'])
    row = installed('after')
    assert row['version'] == '0.2.5' and row['enabled'] is True, row
    path = Path(row['installPath'])
    assert path.resolve().is_relative_to(base.resolve())
    package = WORK / 'release022/plugin025-marketplace/packages/claude/verity-plane'
    expected = {p.relative_to(package).as_posix(): sha(p) for p in package.rglob('*') if p.is_file()}
    observed = {p.relative_to(path).as_posix(): sha(p) for p in path.rglob('*') if p.is_file()}
    assert observed == expected, 'Installed package differs from qualified bytes.'
    details = native('details', ['plugin', 'details', 'verity-plane@se-harness'])
    assert 'harness-orient' in details
    report.update(status='pass', revision=PUBLIC, plugin=row, installed_path=str(path), files=observed,
                  content_sha256=hashlib.sha256(json.dumps(observed, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
                  plugin_version='0.2.5', evaluator_version='0.22.0', file_count=len(observed),
                  all_installed_bytes_match=True, native_conversation_claim=False)
except Exception as exc:
    report.update(status='failed', error=str(exc))
finally:
    save('route', report)
print(json.dumps({k: report[k] for k in ('host', 'kind', 'status', 'error', 'file_count') if k in report}), flush=True)
raise SystemExit(0 if report['status'] == 'pass' else 1)
