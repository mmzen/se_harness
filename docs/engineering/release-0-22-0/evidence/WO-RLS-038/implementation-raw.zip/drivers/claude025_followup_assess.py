"""Retain the substantive checks required by approved VER-RLS-002."""
import datetime, hashlib, json, os, re, subprocess, sys, tomllib, zipfile
from pathlib import Path
from claude025_followup_ctl import WORK, REPO, OUT

E = REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-038'
sha = lambda b: hashlib.sha256(b).hexdigest()
obs = json.loads((E/'observations.json').read_text())
result = {'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'contract':'VER-RLS-002','work_order':'WO-RLS-038','checks':[]}
def passed(name, **details): result['checks'].append({'name':name,'status':'pass',**details})
assert sha((E/'observations-raw.zip').read_bytes()) == obs['raw_archive']['sha256']
z = zipfile.ZipFile(E/'observations-raw.zip')
assert set(z.namelist()) == set(obs['raw_archive']['entries'])
for name, want in obs['raw_archive']['entries'].items(): assert sha(z.read(name)) == want, name
original = json.loads(z.read('assessment-original.json'))
for section in ('reports','test_drivers','route_command_evidence'):
    for source in original[section]: assert sha(Path(source['path']).read_bytes()) == source['sha256'],source['path']
passed('Archive and original-source byte preservation', archive_sha256=obs['raw_archive']['sha256'],entries=len(z.namelist()))
release = tomllib.loads((REPO/'docs/engineering/release-0-22-0/releases/RLS-SEH-032.md').read_text().split('+++')[1])
assert release['distribution']['wheel_sha256'] == obs['evaluator']['archive_sha256']
qualified = json.loads((REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-035/qualification-v2.json').read_text())
qz = zipfile.ZipFile(REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-035/raw.zip')
invbytes = qz.read('assembly/packages/claude/verity-plane/assembly-inventory.json')
assert sha(invbytes) == qualified['host_inventory_sha256']['claude']
inv = json.loads(invbytes)
expected = {k:v['sha256'] for k,v in inv['files'].items()}
expected['assembly-inventory.json'] = sha(invbytes)
native = json.loads(z.read('native-delivery.json'))
boundaries = json.loads(z.read('native-boundaries.json'))
fresh = json.loads(z.read('routes/fresh-route.json'))
update = json.loads(z.read('routes/update-route.json'))
for d, key in ((native,'package_files'),(boundaries,'package_files'),(fresh,'files'),(update,'files')):
    assert d[key] == expected
assert len(expected) == 29
assert fresh['revision'] == update['revision'] == obs['public_revision']
assert update['starting_version'] == '0.2.4' and update['starting_revision'] == '7e366438165a40a14783bac650a2887e7ec8bc75'
assert qualified['candidate_commit'] == native['source_commit'] == boundaries['source_commit'] == obs['source_commit']
passed('Independent qualification and released-wheel identity',file_count=29,public_revision=obs['public_revision'],qualification_inventory_sha256=sha(invbytes),wheel_sha256=release['distribution']['wheel_sha256'])

def hook_contexts(stage, name=None):
    events = [e for e in stage['events'] if e.get('subtype')=='hook_response' and (name is None or e.get('hook_name')==name)]
    values=[]
    for event in events:
        assert event['exit_code']==0 and event['outcome']=='success'
        values.append(json.loads(event['stdout'])['hookSpecificOutput']['additionalContext'])
    return values
def check_entry(context, digest=obs['entry_sha256'], version='0.22.0'):
    start = context.index('# Engineering Harness for ')
    entry = context[start:]
    assert sha(entry.encode()) == digest, (sha(entry.encode()),digest)
    assert 'Selected release: '+version+';' in context
    assert '## After compaction' in entry
    return sha(entry.encode())
compactions=[]
for d in (native,boundaries):
    assert d['repository_preserved']
    for stage in d['stages']:
        assert stage['exit_code']==0 and not stage['provider_errors'],stage['phase']
        for trigger in stage['compaction_triggers']:
            native_events=[e for e in stage['events'] if e.get('subtype')=='compact_boundary']
            assert any(e['compact_metadata']['trigger']==trigger for e in native_events)
            contexts=hook_contexts(stage,'SessionStart:compact')
            assert contexts,stage['phase']
            if stage['phase']!='B-legacy-compaction':
                check_entry(contexts[-1])
            else:
                assert 'SE Harness 0.20.0' in contexts[-1] and '## After compaction' in contexts[-1]
            compactions.append({'phase':stage['phase'],'trigger':trigger,'hook':'SessionStart:compact','session':stage['session_id']})
assert {x['trigger'] for x in compactions} == {'manual','auto'}
stages={s['phase']:s for s in native['stages']}
assert '# Select the working repository' in hook_contexts(stages['fresh-startup'])[0]
for name in ('fresh-selected-code-review','after-automatic'):check_entry(hook_contexts(stages[name])[0])
bs={s['phase']:s for s in boundaries['stages']}
assert bs['A-bootstrap']['session_id'] != bs['B-bootstrap']['session_id']
for name in ('A-current-compaction','B-current-after-switch','A-unchanged-after-switch','A-unchanged-after-clear','A-restored'):
    check_entry(hook_contexts(bs[name])[-1])
assert '# Select the working repository' in hook_contexts(bs['B-cleared'])[0]
missing='\n'.join(hook_contexts(bs['A-missing-checkout']))
assert 'gap' in missing.lower() and '# Engineering Harness for ' not in missing
passed('Actual native compaction events and complete selected entries',compactions=compactions)
passed('Startup/resume, independent sessions, switch/clear and gap recovery',stages=len(native['stages'])+len(boundaries['stages']),fixture_files_preserved=True)
for path,want in obs['original_records']['files_sha256'].items():assert sha((REPO/path).read_bytes())==want,path
passed('Historical decisions, risks, release and verification records unchanged',files_sha256=obs['original_records']['files_sha256'])
guides=[p for p in json.loads((OUT/'planned-paths.json').read_text()) if p=='README.md' or p.startswith('docs/notes/') or p.endswith('/README.md')]
links=[]
for path in guides:
    for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',(REPO/path).read_text(encoding='utf8')):
        bare=target.split('#',1)[0]
        if not bare or '://' in bare or bare.startswith('mailto:'):continue
        resolved=(REPO/path).parent/bare
        assert resolved.exists(),(path,target)
        links.append({'source':path,'target':target})
passed('Local links in changed guides and evidence index',checked=len(links),links=links)
secret=re.compile(rb'(?i)"(?:access_token|refresh_token|code_verifier|client_secret)"\s*:\s*"[^"\s]+"|Bearer\s+[A-Za-z0-9._-]{20,}|sk-ant-[A-Za-z0-9_-]+')
for name in z.namelist():assert not secret.search(z.read(name)),name
passed('Credential-value pattern scan of retained raw observations',scope='Known secret-value patterns; no credential files included')
result['status']='pass'
(OUT/'substantive-assessment.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'assessment':'pass','checks':len(result['checks'])}))

argv=[sys.executable,'-B','-X','utf8','-m','unittest','tests.test_progressive_documentation','tests.plugin_integration.package_assembly.test_refresh_guidance']
env=dict(os.environ,GIT_CONFIG_COUNT='3',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true',GIT_CONFIG_KEY_1='core.autocrlf',GIT_CONFIG_VALUE_1='false',GIT_CONFIG_KEY_2='safe.directory',GIT_CONFIG_VALUE_2=REPO.as_posix())
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(argv,cwd=REPO,env=env,capture_output=True,text=True,encoding='utf8')
receipt={'argv':argv,'cwd':str(REPO),'started_at':start,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
(OUT/'focused-tests.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'test_exit':p.returncode,'result':p.stderr[-1200:]}))
assert p.returncode==0
