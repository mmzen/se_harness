"""Transient evaluator driver for the Claude post-release evidence proposal."""
from pathlib import Path
import json, os, subprocess, sys
WORK = Path(__file__).resolve().parent
REPO = WORK / 'release030-main'
OUT = WORK / 'claude025-followup-20261003' / 'preparation'
OUT.mkdir(parents=True, exist_ok=True)
PY = Path(r'C:\Users\mathi\.codex\plugins\data\verity-plane-se-harness\evaluators\0.22.0\44543f242ed19bb30cfd65da415372a87508a6e439204d7f3e37f9f45aefe4e4\Scripts\python.exe')
def run(label, command, *args):
    path = OUT / (label + '.json')
    assert not path.exists(), path
    env = dict(os.environ, GIT_CONFIG_COUNT='3', GIT_CONFIG_KEY_0='core.longpaths', GIT_CONFIG_VALUE_0='true', GIT_CONFIG_KEY_1='core.autocrlf', GIT_CONFIG_VALUE_1='false', GIT_CONFIG_KEY_2='safe.directory', GIT_CONFIG_VALUE_2=REPO.as_posix())
    argv = [str(PY), '-I', '-m', 'se_harness', command, str(REPO), *args, '--json']
    p = subprocess.run(argv, cwd=WORK, env=env, capture_output=True, text=True, encoding='utf-8')
    path.write_text(p.stdout, encoding='utf-8')
    (OUT / (label + '-invocation.json')).write_text(json.dumps({'argv':argv,'cwd':str(WORK),'exit_code':p.returncode,'stderr':p.stderr},indent=2)+'\n', encoding='utf-8')
    data = json.loads(p.stdout) if p.stdout else {}
    summary = {k:data[k] for k in ('operation','outcome','changes','errors','error_count','warning_count','allocated_id','path','ready','status') if k in data}
    print(json.dumps({'label':label,'exit_code':p.returncode,'saved':str(path),'result':summary or {'keys':list(data)}},indent=2))
    return p.returncode, data
if __name__ == '__main__':
    raise SystemExit(run(*sys.argv[1:])[0])
