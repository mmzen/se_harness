"""Apply the human's reviewed package approval using released evaluator 0.22.0."""
import hashlib, json, tomllib
from claude025_followup_ctl import OUT, REPO, run

review=json.loads((OUT/'reviewed-package.json').read_text())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for group in ('artifacts','evidence','historical_records'):
    for path,want in review[group].items(): assert digest(REPO/path)==want,(group,path)
reason='Human mmzen replied "I approve" to the prepared package request: choose record-tested-subset for DEC-RLS-007 and DEC-RLS-008; approve WO-RLS-038 and VER-RLS-002 with required commit-bound verification; correct the six scoped guidance files while preserving remaining gaps and historical records; permit ordinary pushes from work/claude-025-evidence-followup and a draft PR to mmzen/se_harness:main, including the later verification-decision push. Verification acceptance and merge remain separate. Codex applies the human decision.'
for ident in ('DEC-RLS-007','DEC-RLS-008'):
    path='docs/engineering/release-0-22-0/decisions/'+ident+'.md'
    code,current=run(ident+'-approved-context','check','--artifact',ident)
    assert code==0 and current['state']['after'][0]['status']=='open'
    args=['--artifact',ident,'--option','record-tested-subset','--decision','mmzen','--reason',reason+' Reviewed SHA-256 '+review['artifacts'][path]+'.']
    code,preview=run(ident+'-preview','decide',*args); assert code==0,preview
    assert digest(REPO/path)==review['artifacts'][path]
    code,applied=run(ident+'-apply','decide',*args,'--apply'); assert code==0,applied
    assert tomllib.loads((REPO/path).read_text().split('+++')[1])['status']=='decided'
    for old,want in review['historical_records'].items(): assert digest(REPO/old)==want,old
wo=REPO/'docs/engineering/release-0-22-0/work-orders/WO-RLS-038.md'
assert digest(wo)==review['artifacts'][wo.relative_to(REPO).as_posix()]
text=wo.read_text(encoding='utf-8')
assert '[assurance]' not in text
text=text.replace('\n[execution_scope]\n','\n[assurance]\ncommit_bound_verification = "required"\nrationale = "Human mmzen confirmed required commit-bound verification because current support and risk-assessment claims rely on the correctness of the retained evidence and its interpretation."\ndecided_by = "mmzen"\n\n[execution_scope]\n',1)
wo.write_text(text,encoding='utf-8')
approved_inputs={p:digest(REPO/p) for p in review['artifacts'] if '/decisions/' not in p}
(OUT/'approval-bound-inputs.json').write_text(json.dumps({'human':'mmzen','answer':'I approve','reason':reason,'reviewed':review,'transition_input_sha256':approved_inputs},indent=2)+'\n',encoding='utf-8')
args=[]
for ident in ('VER-RLS-002','WO-RLS-038'):
    path=next(p for p in approved_inputs if p.endswith('/'+ident+'.md'))
    args+=['--set',ident+'=approved','--decision',ident+'=mmzen','--reason',ident+'='+reason+' Reviewed SHA-256 '+review['artifacts'][path]+'; transition input SHA-256 '+approved_inputs[path]+'. Only confirmed assurance metadata was added to the WO.']
code,preview=run('package-approval-preview','transition',*args); assert code==0,preview
for path,want in approved_inputs.items():assert digest(REPO/path)==want,path
code,applied=run('package-approval-apply','transition',*args,'--apply'); assert code==0,applied
for path in approved_inputs:assert tomllib.loads((REPO/path).read_text().split('+++')[1])['status']=='approved'
for path,want in review['historical_records'].items():assert digest(REPO/path)==want,path
print(json.dumps({'human':'mmzen','decisions':'decided','work_and_verification':'approved','historical_records_unchanged':True}))
