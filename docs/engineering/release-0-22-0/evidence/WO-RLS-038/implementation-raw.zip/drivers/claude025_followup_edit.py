"""Apply only the approved current-guidance correction."""
import hashlib, json, tomllib
from claude025_followup_ctl import REPO, OUT

D = 'docs/engineering/release-0-22-0'
wo = tomllib.loads((REPO/D/'work-orders/WO-RLS-038.md').read_text().split('+++')[1])
assert wo['status'] == 'in_progress'
review = json.loads((OUT/'reviewed-package.json').read_text())
for path, want in review['historical_records'].items():
    assert hashlib.sha256((REPO/path).read_bytes()).hexdigest() == want, path

old = 'Claude Code installation/update and native session tests, and Codex Windows desktop tests, were not run for this release and remain unverified under DEC-RLS-005/006. Both distributed packages were byte-checked.'
links = {
    'README.md': D+'/evidence/WO-RLS-038/README.md',
    'docs/engineering/plugin-integration/README.md': '../release-0-22-0/evidence/WO-RLS-038/README.md',
    'docs/notes/plugin-installation-guide.md': '../engineering/release-0-22-0/evidence/WO-RLS-038/README.md',
    'docs/notes/plugin-marketplace-publication.md': '../engineering/release-0-22-0/evidence/WO-RLS-038/README.md',
    'docs/notes/release-delivery-completion.md': '../engineering/release-0-22-0/evidence/WO-RLS-038/README.md',
}
for path, link in links.items():
    p = REPO/path
    data = p.read_text(encoding='utf-8')
    assert data.count(old) == (2 if 'installation-guide' in path else 1), path
    new = f'''[Claude follow-up (2026-10-03)]({link}): on Windows, Claude Code 2.1.273
passed public fresh installation and update from 0.2.4, plus startup, activation,
resume, manual/automatic compaction and session-isolation checks for plugin 0.2.5
and evaluator 0.22.0. The native test package matches all 29 public package files.
Codex Windows desktop, the full Claude work-order walkthrough and the earlier
long-path case remain unverified. DEC-RLS-007/008 record the bounded follow-up;
the original release omissions and accepted risks under DEC-RLS-005/006 remain
historical records.'''
    data = data.replace(old, new)
    if path == 'docs/engineering/plugin-integration/README.md':
        data = data.replace('Codex CLI public fresh/update routes and offline setup. Current documentation\nintegration and release-marker closeout remain in progress.',
                            'Codex CLI public fresh/update routes and offline setup. The retained\n[delivery closeout](../release-0-22-0/evidence/WO-RLS-036/closeout.md)\nconfirms documentation integration and release-marker completion.\n')
    if path == 'docs/notes/plugin-marketplace-publication.md':
        data = data.replace('Current guidance integration and release-marker closeout remain in progress.',
                            'The retained [delivery closeout](../engineering/release-0-22-0/evidence/WO-RLS-036/closeout.md)\nconfirms guidance integration and release-marker completion.\n')
        data = data.replace('This rollout uses the existing delivery route under selected evaluator 0.21.0.\nThe complete-release route still needs separate adoption and provider configuration.',
                            'This rollout used the existing delivery route under selected evaluator 0.21.0.\nThe repository now selects 0.22.0; the complete-release route still needs\nreviewed provider configuration.')
    p.write_text(data, encoding='utf-8', newline='\n')

p = REPO/D/'README.md'
data = p.read_text(encoding='utf-8')
historical = data[data.index('## Original preparation record'):]
current = '''# Release 0.22.0

## Current delivery status

Evaluator **0.22.0** is published on GitHub and PyPI under RLS-SEH-032.
Plugin **0.2.5** is public at `7d30907f15bd7e06fb632e1ebf4e88e01b68726c`.
The retained [delivery closeout](evidence/WO-RLS-036/closeout.md) records all five
declared surfaces satisfied, including documentation integration and latest/last
markers. That result uses the original release scope and accepted omissions.

## Claude follow-up — 2026-10-03

[WO-RLS-038 observations](evidence/WO-RLS-038/README.md) supplement that release
evidence. On Windows, Claude Code 2.1.273 passed public fresh installation and
update from 0.2.4, plus startup, activation after cloning, resume, manual/automatic
compaction, session isolation and unavailable-checkout recovery. The native test
package and both public routes contain the same 29 files for plugin 0.2.5 and
evaluator 0.22.0. Native runs used `--plugin-dir` and short disposable paths.

[DEC-RLS-007](decisions/DEC-RLS-007.md) and
[DEC-RLS-008](decisions/DEC-RLS-008.md) record mmzen's decision to retain this
tested subset. Codex Windows desktop, the full Claude work-order walkthrough
and the earlier long-path case remain unverified. mmzen owns their follow-up
before the next plugin release or any broader support claim.

[DEC-RLS-005](decisions/DEC-RLS-005.md),
[DEC-RLS-006](decisions/DEC-RLS-006.md), their accepted risks and all original
verification/release evidence remain unchanged. The original expired-authentication
failure remains historical evidence. These later passes do not close those risks,
alter the release plan or supply a new human verification decision.

'''
p.write_text(current+historical, encoding='utf-8', newline='\n')

p = REPO/D/'evidence/WO-RLS-038/README.md'
data = p.read_text(encoding='utf-8')
data = data.replace('This is a supplement to the release evidence. DEC-RLS-007/008 remain open,\nWO-RLS-038 and VER-RLS-002 remain draft, and no new assurance verdict is recorded.',
'''This supplements the original release evidence. Human mmzen selected
`record-tested-subset` in DEC-RLS-007/008 and approved WO-RLS-038 and VER-RLS-002
with required commit-bound verification. The implementation and evidence are
prepared for that separate human verification; this report supplies no verdict.''')
data = data.replace('| Existing records | Proposed follow-up | Remaining coverage |', '| Existing records | Recorded follow-up | Remaining coverage |')
data = data.replace('DEC-RLS-007 permits exact native subset claims after its human decision.', 'DEC-RLS-007 records mmzen\'s decision to retain the exact tested native subset.')
data = data.replace('DEC-RLS-008 permits exact public fresh/update claims after its human decision.', 'DEC-RLS-008 records mmzen\'s decision to retain the exact public fresh/update results.')
data = data.replace('a broader support claim. Review the two decision proposals and the bounded\nwork/verification package before updating current guidance. This evidence does\nnot itself alter the release\'s delivery plan or human acceptance.',
'''a broader support claim. The [verification review](verification-review.md)
maps the retained checks to VER-RLS-002. Current guidance links this supplement;
human verification of its exact candidate remains a separate decision. This
evidence does not alter the release's delivery plan or prior human acceptance.''')
p.write_text(data, encoding='utf-8', newline='\n')
for path, want in review['historical_records'].items():
    assert hashlib.sha256((REPO/path).read_bytes()).hexdigest() == want, path
print(json.dumps({'updated_current_guides':6,'historical_records_unchanged':True}))
