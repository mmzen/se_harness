"""Retain current qualification separately from its earlier pending report."""
from pathlib import Path
import datetime,hashlib,json,zipfile
from release022_ctl import BASE,OUT,REPO
dest=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-035'
assert not (dest/'qualification-v2.json').exists()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
previous=read(dest/'qualification.json'); result=json.loads(json.dumps(previous))
workflow=read(OUT/'plugin025-workflow-assessment.json');assert workflow['passed']
before=read(OUT/'plugin025-workflow/restore.json')['installed']
after=json.loads(read(OUT/'plugin025-workflow/installed-restore.json')['stdout'])['installed']
assert before==after
result.update(kind='Qualification assessment for human verification; no acceptance or public marketplace claim',observed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),overall_qualification='complete_with_recorded_host_omissions',previous_report={'path':'qualification.json','sha256':sha(dest/'qualification.json')})
result['human_instruction']={'text':'you can continue, claude and codex desktop won’t be tested: to be indicated.','decisions':['DEC-RLS-005','DEC-RLS-006'],'meaning':'Omitted hosts remain not run / unverified. Separate human verification is still required.'}
for row in result['checks']:
    if row['name'] in ('Claude native authenticated qualification','Codex Windows desktop qualification'):
        row['status']='not_assessed';row['disposition']='Explicit current-release omission: DEC-RLS-005; public routes DEC-RLS-006.'
    elif row['name']=='Native repeated new/resumed work and delivery handoff':
        row.update(status='passed',reason='Observed in native Codex CLI on selected 0.22.0 and legacy 0.20.0 with completed new drafts, one start event, exact-text execution, handoff and delivery boundary.',evidence=['plugin025-workflow-assessment.json','workflow/successor-execute-3/report.json','workflow/legacy-execute/report.json'])
    elif row['name'].startswith('VREC-PLG-032'):
        row.update(status='pending_human_verification',reason='This assessment is preparation evidence, not a human verdict.')
result['preserved_failures'] += [
    'Native drafting initially put unconfirmed assurance in metadata; E019 refused the missing decided_by. The draft was corrected to retain the proposed classification in prose without inventing a decision.',
    'One resumed native tool command contained undefined executable/repository values. The exact command was declined; it made no fixture changes. A new turn used explicit supplied paths.',
    'The 0.22.0 start preview raised FileNotFoundError for the separate new draft\'s absent future evidence_paths file. The published evaluator was not changed. Keeping that future destination in the unapproved draft body, without a nonexistent retained-evidence reference, allowed the workflow to proceed. The original crash remains a release limitation.'
]
result['native_workflow']={'assessment':'plugin025-workflow-assessment.json','disposable_profile_restored':True,'no_external_probe_publication':True,'fixture_authority':'Synthetic test inputs only; no production approvals inferred.','open_follow_up':'RISK-RLS-006: missing draft evidence can crash an unrelated transition.'}
result['delivery_plan']={'path':'delivery-plan-v2.json','sha256':sha(dest/'delivery-plan-v2.json')}
result['next_actions']=['Prepare VREC-PLG-032 against the clean committed evidence candidate.','Publish its review PR before requesting human verification.','After verification, publish only the qualified marketplace descendant under matching existing authority.','Then perform WO-RLS-036 with the explicitly disclosed untested host routes.']
entries={}
for p in (OUT/'plugin025-workflow').rglob('*'):
    if p.is_file() and p.name!='pending-command.json':entries['workflow/'+p.relative_to(OUT/'plugin025-workflow').as_posix()]=p
for name in ['plugin025-workflow-assessment.json','plugin025-deviation-preview.json','plugin025-deviation-apply.json','plugin025-deviation-readback.json','plugin025-public-deviation-preview.json','plugin025-public-deviation-apply.json','plugin025-public-deviation-readback.json','plugin025-plan-boundary.json','plugin025-disposition-validation.json','plugin025-updated-scope.json','plugin025-draft-evidence-risk-create.json']:
    entries[name]=OUT/name
for name in ['plugin025_cli_walkthrough.py','plugin025_review_command.py','plugin025_assess_workflow.py','plugin025_disposition.py','plugin025_plan_boundary.py','plugin025_retain_final.py','plugin025_capture_checks.py','plugin025_capture.py']:
    entries['probes/'+name]=BASE/name
assert all(p.is_file() for p in entries.values())
with zipfile.ZipFile(dest/'native-workflow-raw.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(entries.items()):z.writestr(name,p.read_bytes())
result['additional_raw_archive']={'path':'native-workflow-raw.zip','sha256':sha(dest/'native-workflow-raw.zip'),'entries':{n:sha(p) for n,p in sorted(entries.items())}}
(dest/'qualification-v2.json').write_bytes((json.dumps(result,indent=2,ensure_ascii=False)+'\n').encode())
assessment='''# Plugin 0.2.5 qualification for verification

Both packages match the public evaluator 0.22.0 wheel. Package checks pass on
Windows and Linux. Native Codex CLI checks pass within the conditions below.
**Claude Code host tests and Codex Windows desktop tests are not run / unverified.**
Human mmzen instructed continuation with these omissions disclosed. DEC-RLS-005
and DEC-RLS-006 record that current-release decision and its paired risks.

## What the evidence establishes

| Contract / criterion | Observed result |
| --- | --- |
| VER-RLS-034: exact packages | Released-input builder and independent checker passed; both archives and inventories bind the public wheel. |
| Package and delivery suites | Windows: 62 tests, 2 skips. Linux: 62 tests, 1 skip. Skips remain visible. |
| VER-IAR-021: bootstrap and activation | Native Codex CLI starts above the checkout, then selects the exact cloned fixture and complete entry. |
| Native delivery and recovery | Codex CLI startup, manual and actual automatic compaction, and resume passed with retained session/resource identity. |
| Release/session isolation | Two selected releases, interleaved native sessions, explicit switch/clear and unavailable selection passed. |
| Portable failure boundaries | Both platforms passed the 41-step adapter checks, including expected refusals. Unit checks cover contention, atomic selection and invalid resources; these are not native host evidence. |
| Repeated work and delivery boundary | Native Codex CLI created a new draft and completed authorized existing work in both 0.22.0 and 0.20.0 fixtures. Exact notes, lifecycle history, local commits, handoff and empty remote refs were independently checked. |
| Claude and Codex desktop | Not assessed under the recorded current-release omissions; no verified-host claim. |
| VER-RLS-034: delivery inputs | The versioned five-surface plan retains exact source/wheel/package identities, prior plan digest and explicit tested-host boundary. |
| Full source qualification | Reuse verified VREC-SEH-032 for immutable source abbec12ac5524c8adfb28693f846dd59de88f759. No source or package bytes changed here. |

## Failures and limits

The original [progress report](review.md) and [raw archive](raw.zip) remain intact.
They retain PyPI index latency, the failed long-path Claude context check, the
first Linux environment prerequisite failure and expired Claude OAuth.
The same packages passed portable checks in a shorter temporary directory;
the failing long-path configuration is not claimed supported.

The native workflow also exposed a published-evaluator limitation: a separate
draft with a missing file in `evidence_paths` caused an unrelated start preview
to crash. The draft now describes the future file in its body and adds no
retained-evidence reference before the file exists. The normal workflow passed
under that condition. No published evaluator or accepted definition was changed.
The original crash and recovery are retained in RISK-RLS-006 for follow-up; no
acceptance of that separate risk is inferred. One command with undefined paths
was declined before execution, then retried with explicit paths. The new draft's
unconfirmed assurance classification stayed in prose rather than fabricated
decision metadata. These observations are not hidden by the successful retries.

The CLI test used synthetic fixture approvals and local bare remotes. It made
no public push or PR. Its disposable profile's original plugin was restored.
No credentials or ordinary host settings are included in retained evidence.

## Evidence and next decision

[qualification-v2.json](qualification-v2.json) maps results to exact raw hashes.
[native-workflow-raw.zip](native-workflow-raw.zip) retains the native event traces,
reviewed commands, fixture effects and independent assessment.
[delivery-plan-v2.json](delivery-plan-v2.json) names Codex CLI as native public-route
coverage while retaining both distributed packages and byte checks.

Prepare VREC-PLG-032 for this committed evidence, publish its review PR and
request the human verification decision. This report supplies no such verdict.
Marketplace publication, public-route checks and latest/last remain outstanding.
'''
(dest/'qualification-review.md').write_bytes(assessment.encode())
print(json.dumps({'path':str(dest),'raw_bytes':(dest/'native-workflow-raw.zip').stat().st_size,'raw_sha256':sha(dest/'native-workflow-raw.zip')}))
