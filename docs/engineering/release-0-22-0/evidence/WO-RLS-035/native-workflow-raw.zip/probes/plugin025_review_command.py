"""Record root-agent review of one displayed native test command; no persistent grant."""
import json,sys
from pathlib import Path
phase,digest=sys.argv[1:3]
decision=sys.argv[3] if len(sys.argv)>3 else 'accept'
assert decision in {'accept','decline'}
assert phase in {'successor-proposal','successor-execute','successor-execute-2','successor-execute-3','legacy-execute'}
root=Path(__file__).resolve().parent/'release022/plugin025-workflow'/phase
pending=json.loads((root/'pending-command.json').read_text(encoding='utf-8'))
assert pending['sha256']==digest
target=root/(digest+'.decision.json');assert not target.exists()
reason='Root agent reviewed the exact displayed command against the existing WO-RLS-035 disposable test authority. One command only; no persistent exec policy amendment.' if decision=='accept' else 'Rejected: command uses undefined executable and repository; recover the exact paths from the supplied fixture inputs before requesting execution.'
target.write_text(json.dumps({'sha256':digest,'decision':decision,'reason':reason}),encoding='utf-8')
print(digest)
