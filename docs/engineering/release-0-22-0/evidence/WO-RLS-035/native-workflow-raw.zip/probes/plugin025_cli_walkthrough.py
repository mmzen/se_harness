"""Disposable native workflow qualification; no product authority or publication."""
from pathlib import Path
import hashlib, importlib.util, json, os, shutil, subprocess, sys, time

WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(WORK/'iar-demo-tools'))
from acceptance_native import Codex, extract_codex, save
from run_demo import child_env
BASE = Path(json.loads((WORK/'iar-demo-tools/prepared-demo.json').read_text())['demo'])
ROOT = Path(r'C:\Users\mathi\AppData\Local\Temp\p025-flow')
OUT = WORK/'release022/plugin025-workflow'
PY = r'C:\Users\mathi\AppData\Local\Python\pythoncore-3.14-64\python.exe'
GIT = r'C:\Program Files\Git\cmd\git.exe'
EXE = r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe'
ENV = child_env(BASE, 'codex')
DATA = Path(ENV['CODEX_HOME'])/'plugins/data/verity-plane-se-harness'
PLUGIN = Path(ENV['CODEX_HOME'])/'plugins/cache/se-harness/verity-plane/0.2.5'
MARKET = WORK/'release022/plugin025-marketplace'
REPO = WORK/'release030-main'

def call(label, argv, cwd=ROOT, env=None, expected=0):
    dest=OUT/(label+'.json'); assert not dest.exists(), dest
    p=subprocess.run([str(a) for a in argv], cwd=cwd, env=env or ENV,
        capture_output=True, text=True, encoding='utf-8', timeout=120)
    save(dest, {'argv':[str(a) for a in argv], 'cwd':str(cwd), 'exit_code':p.returncode,
        'stdout':p.stdout, 'stderr':p.stderr})
    print(json.dumps({'label':label,'exit_code':p.returncode}), flush=True)
    assert p.returncode==expected, p.stdout[-1800:]+p.stderr[-1800:]
    return p.stdout

def install(mode):
    if mode=='install-first':
        ROOT.mkdir(exist_ok=False);OUT.mkdir(exist_ok=False)
        before=json.loads(call('installed-before',[EXE,'plugin','list','--marketplace','se-harness','--json']))['installed']
        assert len(before)==1
        save(OUT/'restore.json',{'installed':before,'source':before[0]['marketplaceSource']['source']})
        market=MARKET
    else: market=json.loads((OUT/'restore.json').read_text())['source']
    call('plugin-'+mode,[EXE,'-c','marketplaces.se-harness.source='+json.dumps(str(market)),'plugin','add','verity-plane@se-harness','--json'])
    after=json.loads(call('installed-'+mode,[EXE,'plugin','list','--marketplace','se-harness','--json']))['installed']
    if mode=='install-first':
        expected=MARKET/'packages/codex/verity-plane'
        matches={p.relative_to(expected).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()==hashlib.sha256((PLUGIN/p.relative_to(expected)).read_bytes()).hexdigest() for p in expected.rglob('*') if p.is_file()}
        save(OUT/'installed-file-checks.json',matches);assert all(matches.values())
    else: assert after==json.loads((OUT/'restore.json').read_text())['installed']

def prepare():
    import io,zipfile
    old=json.loads((WORK/'reconcile-minimal-20261001/rls032-workflow/fixtures.json').read_text())
    fixtures={}
    for name in ('successor','legacy'):
        fixture=old[name];original=Path(fixture['repo']);repo=ROOT/name;repo.mkdir(exist_ok=False)
        argv=[GIT,'-c','safe.directory='+original.as_posix(),'-C',original,'archive','--format=zip',fixture['baseline']]
        result=subprocess.run(list(map(str,argv)),capture_output=True,check=True)
        with zipfile.ZipFile(io.BytesIO(result.stdout)) as z:
            assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
            z.extractall(repo)
        save(OUT/(name+'-seed.json'),{'source':str(original),'commit':fixture['baseline'],'archive_sha256':hashlib.sha256(result.stdout).hexdigest(),'purpose':'Synthetic prior fixture authority, never product authority.'})
        if name=='successor':
            py=DATA/'evaluators/0.22.0/44543f242ed19bb30cfd65da415372a87508a6e439204d7f3e37f9f45aefe4e4/Scripts/python.exe'
            assert py.is_file()
            call('successor-upgrade-preview',[py,'-I','-m','se_harness','upgrade',repo,'--json'])
            call('successor-upgrade-apply',[py,'-I','-m','se_harness','upgrade',repo,'--apply','--json'])
        else: py=Path(fixture['python'])
        identity=json.loads((repo/'.engineering-harness.lock').read_text())['evaluator']
        assert identity['version']==('0.22.0' if name=='successor' else '0.20.0')
        env=ENV.copy();env.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=repo.as_posix())
        remote=ROOT/(name+'-remote.git');call(name+'-remote-init',[GIT,'init','--bare',remote])
        for label,args in [('init',['init','-b','main']),('name',['config','user.name','Fixture Executor']),('email',['config','user.email','fixture@example.invalid']),('bytes',['config','core.autocrlf','false']),('origin',['remote','add','origin',str(remote)]),('stage',['add','--all']),('commit',['commit','-m','Preserved synthetic native workflow fixture'])]:
            call(name+'-'+label,[GIT,'-C',repo,*args],env=env)
        baseline=call(name+'-baseline',[GIT,'-C',repo,'rev-parse','HEAD'],env=env).strip()
        call(name+'-validate',[py,'-I','-m','se_harness','validate',repo,'--json'],env=env)
        call(name+'-context',[py,'-I','-m','se_harness','check',repo,'--artifact','WO-FLW-001','--json'],env=env)
        call(name+'-preflight',[py,'-I','-m','se_harness','preflight',repo,'--work-order','WO-FLW-001','--phase','start','--json'],env=env)
        fixtures[name]={'repo':str(repo),'python':str(py),'version':identity['version'],'baseline':baseline,'destination':str(remote),'head_ref':'refs/heads/workflow-demo','base_ref':'refs/heads/main','synthetic_authority':True,'initial_state':'approved' if name=='successor' else 'in_progress'}
    save(OUT/'fixtures.json',fixtures)

def native(phase):
    fixtures=json.loads((OUT/'fixtures.json').read_text())
    name='legacy' if phase.startswith('legacy') else 'successor'; f=fixtures[name]
    dest=OUT/phase;dest.mkdir(exist_ok=False)
    manifest={'demo':str(BASE),'host_executables':{'codex':EXE}}
    client=Codex(manifest,dest,review_commands=True)
    hooks=client.rpc('hooks/list',{'cwds':[str(ROOT)]})
    assert all(h['trustStatus']=='trusted' for row in hooks['data'] for h in row['hooks'] if h.get('pluginId')=='verity-plane@se-harness')
    save(dest/'hooks.json',hooks)
    def wait_turn(thread):
        deadline=time.monotonic()+1800
        while time.monotonic()<deadline:
            v=client.receive(max(.1,deadline-time.monotonic()))
            if v.get('method')=='turn/completed' and v.get('params',{}).get('threadId')==thread:
                assert v['params']['turn']['status']=='completed',v['params']['turn'].get('error')
                return
        raise TimeoutError('native walkthrough turn')
    client.wait_turn=wait_turn
    config={'marketplaces.se-harness.source':str(MARKET),'marketplaces.se-harness.source_type':'local','features.multi_agent':False,
        'sandbox_workspace_write.writable_roots':[str(ROOT),str(DATA)]}
    try:
        session=OUT/'session.json'
        if session.exists():
            thread=json.loads(session.read_text())['thread_id']
            client.rpc('thread/resume',{'threadId':thread,'cwd':str(ROOT),'excludeTurns':True,'sandbox':'workspace-write','config':config})
        else:
            result=client.rpc('thread/start',{'cwd':str(ROOT),'sandbox':'workspace-write','config':config})
            thread=result['thread']['id'];save(session,{'thread_id':thread})
        common=f'''Native CLI qualification of WO-RLS-035 in disposable fixtures only. No product checkout edits, real approvals, subagents, credential reads, saved host setting changes, external network actions, pushes or PRs. Host cwd remains {ROOT}. Use the newest plugin instructions and selected evaluator. If Windows sandbox launch fails, request exact per-command escalation; the driver reviews commands individually. Do not request persistent rules. The synthetic fixture approvals are deliberate test inputs, not a real person's decision or production authority. Repository: {f['repo']}. Its private evaluator is {f['python']}, invoked with -I -m se_harness, from outside the repository. Use Git {GIT}; if Git safe.directory is needed, use a per-command -c safe.directory for this exact fixture. Fixture baseline {f['baseline']}. Do not alter accepted definitions. '''
        if phase.endswith('proposal'):
            prompt=common+f'''Activate this exact repository through the installed setup skill at {PLUGIN/'skills/setup/SKILL.md'}, using host session ID {thread} and private data {DATA}. Then follow the selected release's authoring procedure to prepare ONE NEW draft work order (do not change WO-FLW-001). Requested outcome: a future fixture reader gets notes/future.txt containing `planned` and one LF. Scope only that note, the new work-order record and its evidence directory. Reuse the existing accepted definitions when applicable. Read the discovered work-order template and authoring checklist. Use create-artifact dry-run then its allocated ID. Complete the draft and validate it. No implementation, approval or lifecycle transition of the new draft. Keep transient planning notes outside the repository. End with created ID/path, governing release, actual checks, and exact next human decision. A template alone is not a completed proposal.'''
        elif '-execute' in phase:
            prompt=common+f'''Continue the synthetic already-approved WO-FLW-001 to its permitted local implementation completion. The test's supplied existing approval is exactly the fixture's recorded scope and not_required assurance classification; this grants local execution and commits only. Follow fresh check, required discovered instructions, start/preflight/scope checks, implement notes/note.txt, retain the actual exact-text test result, complete Git-derived handoff and any permitted completion transition. Do not edit the other draft work order or seed definitions. Use baseline {f['baseline']} for the complete implementation diff. The separate new draft was prepared before implementation; account for its preparation separately without hiding actual paths or inventing authority. If that creates a real scope finding, report it and stop the affected action. Make a local candidate commit only for authorized execution paths. Retain the handoff JSON as docs/engineering/product/evidence/WO-FLW-001/handoff.json. Finally inspect the evaluator's next step and the delivery procedure. State exact candidate commit, destination {f['destination']}, proposed head {f['head_ref']} and base {f['base_ref']}, and the required human push/PR authority. Do not publish or claim verification acceptance. Return a concise structured report with evidence paths and blockers.'''
        else:
            prompt=common+Path(sys.argv[2]).read_text(encoding='utf-8')
        prompt+=' Keep the fixture draft concise: fill required content without repeating harness policy or test-host instructions. Reuse unchanged resource instructions already retained in context, but read the newly selected fixture records. These corrected fixtures use domain-coded IDs and have independently passed start preflight. Earlier invalid fixtures and their failures remain retained; do not modify them.'
        prompt+=' Tool-runtime variables from an earlier turn may be undefined after app-server resume. Use the exact literal repository and executable paths supplied in THIS prompt, or initialize and verify variables in this turn. The preceding successor-execute attempt was declined only because its actual command was & undefined ... undefined; no correct-path command was declined and no fixture write occurred.'
        if phase=='successor-execute-3':
            prompt+=' Specific recovery before execution: the preceding attempt found that a future evidence_paths entry in the unapproved WO-FLW-002 triggers FileNotFoundError during an unrelated transition. The driver retains this real evaluator defect; do not suppress or repair the product. You may correct ONLY that new draft by removing its evidence_paths metadata reference to the absent future observations.md. Keep the exact future evidence location, criteria and procedure in its existing body. Do not create fake evidence, change scope, approve the draft or alter accepted definitions. This overrides the earlier instruction to leave this one draft wholly byte-identical; after this correction preserve it. Validate and retry the normal WO-FLW-001 start/execute/handoff flow. Report the limitation and recovery explicitly.'
        if name=='legacy' and '-execute' in phase:
            prompt+=' Before resuming WO-FLW-001, explicitly activate this legacy fixture through setup using session '+thread+' and private data '+str(DATA)+'. Follow its own 0.20.0 authoring procedure to preview, create and complete ONE new draft work order for notes/future.txt containing planned plus one LF, just as in the successor proposal. The new draft must stay unapproved and its note absent. Then resume the existing in_progress WO-FLW-001 without another start, preserving the newly prepared draft. Reuse unchanged instructions already in context; read this selected release and records as required.'
            prompt+=' For the new unapproved draft, keep future evidence destinations in its body; do not reference nonexistent evidence files in evidence_paths metadata. This preserves the observed transition limitation without inventing completed evidence.'
        client.phase=phase
        client.rpc('turn/start',{'threadId':thread,'cwd':str(ROOT),'input':[{'type':'text','text':prompt}]})
        client.wait_turn(thread)
        contexts,replies=extract_codex(client.events)
        save(dest/'report.json',{'phase':phase,'thread_id':thread,'surface':'Codex CLI app-server, desktop unverified','contexts':contexts,'replies':replies,'fixture':f})
        print(json.dumps({'phase':phase,'replies':replies}),flush=True)
    except Exception as exc:
        save(dest/'error.json',{'error':str(exc)});raise
    finally:client.close()

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='prepare':prepare()
    elif mode.startswith(('install','restore')):install(mode)
    else:native(mode)
