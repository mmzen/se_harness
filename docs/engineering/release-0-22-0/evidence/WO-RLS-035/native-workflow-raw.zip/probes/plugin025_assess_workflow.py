"""Independently inspect native fixture effects and retain bounded evidence."""
from pathlib import Path
import hashlib,json,subprocess,tomllib,zipfile
from release022_ctl import OUT

base=OUT/'plugin025-workflow'
fixtures=json.loads((base/'fixtures.json').read_text())
git=r'C:\Program Files\Git\cmd\git.exe'
rows=[]
for name,f in fixtures.items():
    repo=Path(f['repo']); prefix=[git,'-c','core.longpaths=true','-c','safe.directory='+repo.as_posix(),'-C',str(repo)]
    def command(label,args):
        p=subprocess.run([str(a) for a in args],cwd=repo.parent,capture_output=True,text=True,encoding='utf-8')
        row={'label':label,'argv':list(map(str,args)),'cwd':str(repo.parent),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
        rows.append(row);assert p.returncode==0,row
        return p.stdout.strip()
    head=command(name+'-head',prefix+['rev-parse','HEAD'])
    assert head != f['baseline']
    status=command(name+'-status',prefix+['status','--porcelain=v1'])
    assert not status,status
    changed=command(name+'-paths',prefix+['diff','--name-only',f['baseline'],'HEAD']).splitlines()
    assert changed and all(p=='notes/note.txt' or p.startswith(('docs/engineering/product/work-orders/','docs/engineering/product/evidence/WO-FLW-001/')) for p in changed),changed
    assert (repo/'notes/note.txt').read_bytes()==b'after\n'
    assert not (repo/'notes/future.txt').exists()
    wo=tomllib.loads((repo/'docs/engineering/product/work-orders/WO-FLW-001.md').read_text().split('+++',2)[1])
    assert wo['status']=='implemented',wo
    events=wo['lifecycle_events'];assert sum(x['to']=='in_progress' for x in events)==1
    assert sum(x['to']=='implemented' for x in events)==1
    draft=tomllib.loads((repo/'docs/engineering/product/work-orders/WO-FLW-002.md').read_text().split('+++',2)[1])
    assert draft['status']=='draft' and not draft.get('lifecycle_events')
    formal=json.loads(command(name+'-check',[f['python'],'-I','-m','se_harness','check',repo,'--artifact','WO-FLW-001','--json']))
    assert formal['restitution']['next']['procedure_id']=='PROC-FOCUS-SELECTED'
    assert wo['assurance']['commit_bound_verification']=='not_required'
    refs=command(name+'-remote-refs',[git,'-c','safe.directory='+Path(f['destination']).as_posix(),'--git-dir',f['destination'],'for-each-ref','--format=%(refname) %(objectname)'])
    assert not refs,'Probe must not publish even to its local bare target'
    (base/(name+'-independent.json')).write_text(json.dumps({'candidate':head,'baseline':f['baseline'],'status':status,'changed_paths':changed,'state':wo['status'],'draft_state':draft['status'],'start_event_count':1,'remote_refs':refs,'next':formal['restitution']['next'],'destination':f['destination']},indent=2),encoding='utf-8')
    with zipfile.ZipFile(base/(name+'-fixture-effects.zip'),'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in changed:
            target=repo/p
            if target.is_file():z.writestr(p,target.read_bytes())
result={'passed':True,'surface':'Codex CLI only','commands':rows,'claim':'Actual new draft, approved/resumed execution, local commits, exact note, retained handoff and delivery boundary on both selected releases; no external publication.'}
(OUT/'plugin025-workflow-assessment.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({'passed':True,'commands':len(rows)}))
