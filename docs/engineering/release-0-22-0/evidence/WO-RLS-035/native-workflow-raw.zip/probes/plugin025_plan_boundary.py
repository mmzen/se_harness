"""Version the delivery coverage under the two supplied human decisions."""
import hashlib, importlib.util, json, tomllib
from release022_ctl import REPO, OUT

root = REPO/'docs/engineering/release-0-22-0'
dest = root/'evidence/WO-RLS-035/delivery-plan-v2.json'
assert not dest.exists()
decisions = {}
for artifact in ('DEC-RLS-005', 'DEC-RLS-006'):
    path = root/'decisions'/f'{artifact}.md'
    data = tomllib.loads(path.read_text(encoding='utf-8').split('+++', 2)[1])
    assert data['status']=='decided' and data['disposition']['option']=='accept'
    assert data['disposition']['decided_by']=='mmzen'
    decisions[artifact] = {'path':path.relative_to(REPO).as_posix(), 'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
source = root/'evidence/WO-RLS-035/delivery-plan.json'
plan = json.loads(source.read_text(encoding='utf-8'))
plan['review']['reference'] += ' Current-release host omissions recorded by mmzen in DEC-RLS-005 and DEC-RLS-006.'
plan['previous_plan'] = {'path':source.relative_to(REPO).as_posix(), 'sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
plan['accepted_host_omissions'] = {
    'decisions':decisions,
    'human_instruction':'you can continue, claude and codex desktop won’t be tested: to be indicated.',
    'claude_code':'Host installation/update and native session qualification not run / unverified. Earlier expired-authentication failure retained.',
    'codex_windows_desktop':'Not run / unverified. Codex CLI is a separate tested surface.',
    'scope':'Plugin 0.2.5 and evaluator 0.22.0 only; both distributed package byte checks remain required.',
    'revisit':'Before the next plugin release or before claiming an omitted host route verified, whichever occurs first.'
}
for surface in plan['surfaces']:
    if surface['id']=='marketplace':
        surface['hosts']=['codex']
        surface['distributed_hosts']=['codex','claude-code']
        surface['required_observations']=[x for x in surface['required_observations'] if not x.startswith('claude-code_')]
        surface['next_action']='Complete remaining Codex CLI qualification and VREC-PLG-032 review; publish the exact descendant package only after human verification. Claude and Codex Windows desktop stay untested under DEC-RLS-005/006.'
        surface['host_coverage']='hosts lists required native public-route observations; distributed_hosts lists package contents. Both package inventories and public bytes must match.'
spec=importlib.util.spec_from_file_location('delivery_plan_checker',REPO/'scripts/check_release_delivery.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.validate_plan(plan)
dest.write_bytes((json.dumps(plan,indent=2,ensure_ascii=False)+'\n').encode('utf-8'))
result={'path':dest.relative_to(REPO).as_posix(),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'schema_validation':'passed','delivery_completion':'not_assessed'}
(OUT/'plugin025-plan-boundary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
