import hashlib,json,sys
from release022_ctl import OUT,REPO,run

stage=sys.argv[1]
decision=sys.argv[2] if len(sys.argv)>2 else 'DEC-RLS-005'
assert decision in {'DEC-RLS-005','DEC-RLS-006'}
label='plugin025-deviation' if decision=='DEC-RLS-005' else 'plugin025-public-deviation'
path=REPO/('docs/engineering/release-0-22-0/decisions/'+decision+'.md')
reason=('Human mmzen: "you can continue, claude and codex desktop won’t be tested: to be indicated." '
        'This records the current-release decision for WO-RLS-035 and exact plugin 0.2.5: retain Claude Code native tests '
        'and Codex Windows desktop tests as not run/unverified and disclose the remaining host-specific uncertainty. '
        'Codex applies the supplied human decision; required Codex CLI checks, verification acceptance and publication controls remain separate.')
if decision=='DEC-RLS-006':
    reason=('Human mmzen: "you can continue, claude and codex desktop won’t be tested: to be indicated." '
            'This records the current-release decision for WO-RLS-036 and exact plugin 0.2.5: Claude host installation/update '
            'and native session tests, and Codex Windows desktop tests, are not run/unverified and must be disclosed. '
            'Retain both public package byte checks; name Codex CLI only as verified-host coverage. The remaining uncertainty '
            'is retained in RISK-RLS-005. Required Codex CLI checks, human verification and publication controls remain separate.')
args=['--artifact',decision,'--option','accept','--decision','mmzen','--reason',reason,
      '--revisit','Before the next plugin release or before claiming either omitted host route verified, whichever occurs first.']
review=OUT/(label+'-input.json')
digest=hashlib.sha256(path.read_bytes()).hexdigest()
if stage=='preview':
    assert not review.exists()
    review.write_text(json.dumps({'sha256':digest,'args':args},indent=2),encoding='utf-8')
elif stage=='apply':
    previous=json.loads(review.read_text(encoding='utf-8'));assert previous=={'sha256':digest,'args':args}
    args+=['--apply']
else:raise ValueError(stage)
rc,result=run(label+'-'+stage,'decide',*args)
raise SystemExit(rc)
