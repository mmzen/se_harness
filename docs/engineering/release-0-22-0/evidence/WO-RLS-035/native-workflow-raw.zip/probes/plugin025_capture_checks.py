"""Assess the committed package-evidence candidate; no host retests or decisions."""
from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys,tomllib,zipfile
candidate=sys.argv[1]; repo=Path.cwd()
git=r'C:\Program Files\Git\cmd\git.exe'
assert subprocess.check_output([git,'rev-parse','HEAD'],text=True).strip()==candidate
root=repo/'docs/engineering/release-0-22-0'; evidence=root/'evidence/WO-RLS-035'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
report=read(evidence/'qualification-v2.json')
assert report['overall_qualification']=='complete_with_recorded_host_omissions'
assert report['plugin_version']=='0.2.5' and report['candidate_commit']=='abbec12ac5524c8adfb28693f846dd59de88f759'
for key in ('raw_archive','additional_raw_archive'):
    manifest=report[key];p=evidence/manifest['path'];assert sha(p.read_bytes())==manifest['sha256']
    with zipfile.ZipFile(p) as z:
        assert set(z.namelist())==set(manifest['entries'])
        for name,digest in manifest['entries'].items():assert sha(z.read(name))==digest,name
        if key=='additional_raw_archive':
            assert json.loads(z.read('plugin025-workflow-assessment.json'))['passed']
            for fixture in ('successor','legacy'):
                row=json.loads(z.read('workflow/'+fixture+'-independent.json'))
                assert row['state']=='implemented' and row['draft_state']=='draft' and row['start_event_count']==1 and row['remote_refs']==''
omitted={row['name'] for row in report['checks'] if row['status']=='not_assessed'}
assert omitted=={'Claude native authenticated qualification','Codex Windows desktop qualification'}
assert report['native_workflow']['disposable_profile_restored']
for identifier in ('DEC-RLS-005','DEC-RLS-006'):
    record=tomllib.loads((root/'decisions'/f'{identifier}.md').read_text(encoding='utf-8').split('+++',2)[1])
    assert record['status']=='decided' and record['disposition']['option']=='accept' and record['disposition']['decided_by']=='mmzen'
plan=read(evidence/'delivery-plan-v2.json')
spec=importlib.util.spec_from_file_location('delivery',repo/'scripts/check_release_delivery.py'); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.validate_plan(plan)
market=next(row for row in plan['surfaces'] if row['id']=='marketplace')
assert market['hosts']==['codex'] and set(market['distributed_hosts'])=={'codex','claude-code'}
for item in plan['accepted_host_omissions']['decisions'].values():assert sha((repo/item['path']).read_bytes())==item['sha256']
base=Path(__file__).resolve().parent; out=base/'release022'
original=read(out/'plugin025-check.run.json'); argv=original['argv']
# Existing content checker is rerun at the exact capture checkout, preserving its immutable release inputs.
p=subprocess.run(argv,cwd=repo,capture_output=True,text=True,encoding='utf-8',timeout=180)
print(json.dumps({'argv':argv,'cwd':str(repo),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}),flush=True)
assert p.returncode==0
print(json.dumps({'candidate':candidate,'retained_archive_hashes':'passed','independent_fixture_assessment':'passed','package_content_recheck':'passed','delivery_plan':'valid','omissions':sorted(omitted),'limitation':'No host tests rerun here. This binds retained exact-input observations and disclosed limitations, not human assurance.'}),flush=True)
