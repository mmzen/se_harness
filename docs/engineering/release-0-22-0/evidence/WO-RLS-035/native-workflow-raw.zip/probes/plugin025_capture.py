import hashlib,json,os,subprocess,sys
from release022_ctl import BASE,OUT,REPO,EVALUATOR
candidate=sys.argv[1];identifier='VREC-PLG-032'
assert not (REPO/f'docs/engineering/release-0-22-0/verification-records/{identifier}.md').exists()
env=dict(os.environ,GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true',GIT_CONFIG_KEY_1='core.autocrlf',GIT_CONFIG_VALUE_1='false')
git=r'C:\Program Files\Git\cmd\git.exe'
assert not subprocess.check_output([git,'-C',str(REPO),'status','--porcelain=v1'],env=env,text=True).strip()
assert not subprocess.check_output([git,'-C',str(REPO),'log','--all','--format=%H','--',f'**/verification-records/{identifier}.md'],env=env,text=True).strip()
domain='docs/engineering/release-0-22-0/'
files=sorted(p.relative_to(REPO).as_posix() for p in (REPO/domain/'evidence/WO-RLS-035').iterdir() if p.is_file())
files += [domain+'decisions/DEC-RLS-005.md',domain+'decisions/DEC-RLS-006.md',domain+'risks/RISK-RLS-004.md',domain+'risks/RISK-RLS-005.md',domain+'README.md',domain+'verification-records/VREC-SEH-032.md']
files += [domain+'risks/RISK-RLS-006.md']
args=[str(EVALUATOR),'-I','-m','se_harness','capture-verification',str(REPO),'--id',identifier,'--owner','Codex','--domain','release-0-22-0','--candidate-commit',candidate,'--work-order','WO-RLS-035','--verification','VER-RLS-034','--verification','VER-IAR-021','--json']
for path in files:args+=['--evidence',path]
args+=['--test-command',r'C:\Users\mathi\AppData\Local\Python\pythoncore-3.14-64\python.exe','-B','-X','utf8',str(BASE/'plugin025_capture_checks.py'),candidate]
(OUT/'plugin025-capture-inputs.json').write_text(json.dumps({'argv':args,'evidence':{p:hashlib.sha256((REPO/p).read_bytes()).hexdigest() for p in files}},indent=2),encoding='utf-8')
p=subprocess.run(args,cwd=BASE,env=env,capture_output=True,text=True,encoding='utf-8')
(OUT/'plugin025-capture.json').write_text(p.stdout,encoding='utf-8');(OUT/'plugin025-capture.stderr.txt').write_text(p.stderr,encoding='utf-8')
r=json.loads(p.stdout) if p.stdout else {};print(json.dumps({'exit_code':p.returncode,**{k:r[k] for k in ('operation','restitution','errors') if k in r},'stderr':p.stderr[-1500:]},indent=2));raise SystemExit(p.returncode)
