"""Use the existing acceptance procedure against the exact released-input packages."""
import json
from pathlib import Path
import runpy
import shutil
import sys

WORK = Path(__file__).resolve().parent
REPO = WORK / 'release030-main'
MARKET = WORK / 'release022/plugin025-marketplace'
module = runpy.run_path(str(REPO / 'tests/plugin_integration/progressive_discovery/run_resource_acceptance.py'), run_name='plugin025_portable')

def use_qualified_packages(root, wheel, output):
    shutil.copytree(MARKET / 'packages', output)

module['main'].__globals__['develop'] = use_qualified_packages
module['main']()
