import datetime, json, os, platform, subprocess, time
from release022_ctl import EVALUATOR, OUT, REPO
argv=[str(EVALUATOR),'-B','-X','utf8','-m','unittest',
 'tests.plugin_integration.package_assembly.test_package_assembly',
 'tests.plugin_integration.package_assembly.test_marketplace',
 'tests.plugin_integration.package_assembly.test_refresh_guidance',
 'tests.plugin_integration.progressive_discovery.test_delivery',
 'tests.plugin_integration.progressive_discovery.test_activation',
 'tests.plugin_integration.test_simple_plugin']
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true');env.pop('PYTHONPATH',None)
started=datetime.datetime.now(datetime.timezone.utc).isoformat();begin=time.monotonic()
p=subprocess.run(argv,cwd=REPO,env=env,capture_output=True,text=True,encoding='utf-8')
row=dict(argv=argv,cwd=str(REPO),started=started,platform=platform.platform(),evaluator='0.21.0',exit_code=p.returncode,seconds=round(time.monotonic()-begin,2),stdout=p.stdout,stderr=p.stderr)
target=OUT/'plugin025-unit-selected-windows.json';assert not target.exists()
target.write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in row.items() if k not in ('stdout','stderr')}));print(p.stderr[-1800:])
raise SystemExit(p.returncode)
