"""Retain observed release progress; makes no acceptance or completion decision."""
import datetime, hashlib, json, zipfile
from pathlib import Path
from release022_ctl import BASE, OUT, REPO

dest=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-035'
assert not dest.exists(), 'Do not overwrite a retained observation'
def read(path): return json.loads(path.read_text(encoding='utf-8'))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name,value): (dest/name).write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
receipt=read(OUT/'production032-result-attempt3-receipt.json')
public=receipt['files']['public-install-qualification.json']
published=receipt['files']['release-result.json']
assert public['passed'] and all(x['passed'] for x in public['checks'])
expected=public['evaluator']['archive_sha256']
wheel=OUT/'public032-github/se_harness-0.22.0-py3-none-any.whl'
index_wheel=OUT/'public032-pypi'/wheel.name
assert sha(wheel)==sha(index_wheel)==expected
assert all(published['stages'][s]['state']=='exact' for s in ['github','pypi','pages','public_install'])
native=read(OUT/'plugin025-trusted-native-codex.json')
boundary=read(OUT/'plugin025-boundaries-native-codex.json')
assert native['passed'] and native['automatic_compaction_observed'] and native['repository_preserved']
assert native['restored'] and boundary['restored']
linux=read(OUT/'plugin025-linux-prepared.json');assert linux['result']['passed']
windows=read(OUT/'plugin025-unit-selected-windows.json');assert windows['exit_code']==0
short_run=read(OUT/'plugin025-adapter-short-windows.run.json')
short_report=Path(short_run['argv'][-1])/'report.json'
short=read(short_report);assert short['passed']
claude=read(OUT/'plugin025-native-claude.json');assert not claude['passed']
market=OUT/'plugin025-marketplace';identity=read(market/'PACKAGE-IDENTITY.json')
parent=read(OUT/'plugin025-marketplace-parent.json')['result']['object']['sha']
observed=datetime.datetime.now(datetime.timezone.utc).isoformat()

def contexts(report):
    values=[]
    for row in report['steps']:
        try: data=json.loads(row['stdout'])
        except (ValueError,KeyError):continue
        text=data.get('content') or data.get('hookSpecificOutput',{}).get('additionalContext')
        if text and 'Selected release: 0.22.0' in text:
            values.append({'label':row['label'],'utf16_units':len(text.encode('utf-16-le'))//2})
    return values

progress={
 'kind':'Qualification progress; no verification acceptance or release completion',
 'observed_at':observed,'work_order':'WO-RLS-035','state':'in_progress',
 'overall_qualification':'pending','marketplace_publication':'not_performed',
 'release_record':'RLS-SEH-032','candidate_commit':published['release']['candidate_commit'],
 'governance_commit':published['release']['governance_commit'],
 'governing_evaluator':'0.21.0','plugin_version':'0.2.5',
 'evaluator':public['evaluator'],'package_identity_sha256':sha(market/'PACKAGE-IDENTITY.json'),
 'marketplace_parent_observed':parent,
 'host_inventory_sha256':{host:sha(market/f'packages/{host}/verity-plane/assembly-inventory.json') for host in ['codex','claude']},
 'checks':[
  {'name':'Released-input assembly and independent check','status':'passed','evidence':['plugin025-build.run.json','plugin025-check.run.json']},
  {'name':'Windows package/delivery unit tests using selected evaluator','status':'passed','tests':62,'skips':2,'evidence':['plugin025-unit-selected-windows.json']},
  {'name':'Linux package/delivery unit tests using selected evaluator','status':'passed','tests':62,'skips':1,'evidence':['plugin025-linux-prepared.json']},
  {'name':'Windows portable adapter checks, short data path','status':'passed','steps':41,'evidence':['portable-short-windows-report.json']},
  {'name':'Linux portable adapter checks','status':'passed','steps':41,'evidence':['plugin025-linux-prepared.json']},
  {'name':'Codex native bootstrap, activation, manual/automatic compaction, resume','status':'passed','host_version':native['version'],'evidence':['plugin025-trusted-native-codex.json']},
  {'name':'Codex native interleaved sessions, release switch, clear and unavailable selection','status':'passed' if boundary['passed'] else 'failed','error':boundary.get('error'),'evidence':['plugin025-boundaries-native-codex.json']},
  {'name':'Claude native authenticated qualification','status':'pending','reason':'OAuth session expired and could not be refreshed','evidence':['plugin025-native-claude.json']},
  {'name':'Codex Windows desktop qualification','status':'pending','reason':'No native desktop trace for the exact package; CLI results are not a substitute.'},
  {'name':'Native repeated new/resumed work and delivery handoff','status':'pending','reason':'Not executed for the exact 0.22.0 resource and plugin 0.2.5 inputs; retain for qualification continuation.'},
  {'name':'VREC-PLG-032 preparation and human verification','status':'not_started','reason':'Required qualification remains incomplete.'}
 ],
 'preserved_failures':[
  'Initial and second public-install attempts could not yet find 0.22.0 on the PyPI index. Third attempt independently installed and verified it.',
  'The first Windows portable test used long workspace paths. Claude refused 10052 UTF-16 units against its existing 10000-unit bound. The identical package passed in a shorter temporary directory; no limit or policy was changed.',
  'The first Linux unit run had no installed evaluator for the isolated payload-hash subprocess. A fresh isolated environment with exact selected 0.21.0 passed; source and assertions were unchanged.',
  'Claude auth status reported logged in, but the actual request failed with expired OAuth. No refresh or waiver was inferred.'
 ],
 'windows_delivered_context_sizes':contexts(short),
 'human_instruction':{'text':'Not now—keep those checks pending','meaning':'Claude authentication and Codex Windows desktop checks remain unverified. No risk acceptance, waiver or completion is recorded.'},
 'next_actions':['Refresh disposable Claude profile authentication when the human is available.','Complete the remaining native qualification, including desktop and repeated-work handoff, for the exact package.','Finish WO-RLS-035 evidence and prepare/publish the verification review before asking for human verification.','Publish marketplace only after required qualification and human verification; then run WO-RLS-036 public checks and marker promotion.']
}

raw_names=[
 'production032-artifacts-final.json','production032-result-attempt3-receipt.json','production032-pypi-download.run.json',
 'production032-observe-log.json','production032-observation-retry.json','production032-retry-result.json','production032-observation-retry3.json',
 'plugin025-build.run.json','plugin025-check.run.json','plugin025-marketplace-parent.json','plugin025-expected-identity.json',
 'plugin025-unit-windows.run.json','plugin025-unit-selected-windows.json','plugin025-linux.json','plugin025-linux-prepared.json',
 'plugin025-adapter-windows.run.json','plugin025-adapter-short-windows.run.json','plugin025-auth-codex.json','plugin025-auth-claude.json',
 'plugin025-trusted-native-codex.json','plugin025-boundaries-native-codex.json','plugin025-native-claude.json',
 'plugin025-resume-context.json','plugin025-start-preflight.json','plugin025-start-preview.json','plugin025-start-apply.json','plugin025-planned-scope.json'
]
entries={name:OUT/name for name in raw_names}
attempt2=read(OUT/'production032-observe-attempt2.json')
attempt2_lines=[line for line in attempt2['result'].splitlines() if line.startswith('Retain public release observations\t')]
assert any('No matching distribution found for se-harness==0.22.0' in line for line in attempt2_lines)
attempt2_path=OUT/'production032-observe-attempt2-only.log'
attempt2_path.write_bytes(('\n'.join(attempt2_lines)+'\n').encode('utf-8'))
entries[attempt2_path.name]=attempt2_path
entries['portable-short-windows-report.json']=short_report
entries['portable-long-windows-report.json']=OUT/'plugin025-adapter-windows/report.json'
for folder in ['production032-results','production032-results-attempt3']:
    for path in (OUT/folder).rglob('*'):
        if path.is_file():entries[folder+'/'+path.relative_to(OUT/folder).as_posix()]=path
for path in market.rglob('assembly-inventory.json'):
    entries['assembly/'+path.relative_to(market).as_posix()]=path
entries['assembly/PACKAGE-IDENTITY.json']=market/'PACKAGE-IDENTITY.json'
for folder in ['plugin025-trusted-native-codex-events','plugin025-boundaries-events']:
    for path in (OUT/folder).rglob('native-events.jsonl'):
        entries['native/'+path.relative_to(OUT).as_posix()]=path
for name in ['plugin025_portable.py','plugin025_linux.py','plugin025_unit_selected.py','plugin025_native_codex.py','plugin025_native_claude.py','plugin025_native_boundaries.py','plugin025_retain_progress.py']:
    entries['probes/'+name]=BASE/name
assert all(path.is_file() for path in entries.values())
dest.mkdir(parents=True)
with zipfile.ZipFile(dest/'raw.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,path in sorted(entries.items()): z.writestr(name,path.read_bytes())
progress['raw_archive']={'path':'raw.zip','sha256':sha(dest/'raw.zip'),'entries':{name:sha(path) for name,path in sorted(entries.items())}}
write('qualification.json',progress)
write('public-evaluator.json',dict(observed_at=observed,github_download_sha256=sha(wheel),pypi_index_download_sha256=sha(index_wheel),successful_workflow_result=published,public_install_qualification=public,workflow_artifact_id=receipt['artifact_id'],earlier_failed_attempts_preserved=True))
plan_path=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-034/delivery-plan.json'
plan=read(plan_path)
plan['release'].update(record='RLS-SEH-032',wheel_sha256=expected)
for surface in plan['surfaces']:
    if surface['id']=='evaluator':
        surface['expected'].update(record='RLS-SEH-032',wheel_sha256=expected)
        surface['next_action']='Exact publication and public installation observed; preserve receipts.'
    elif surface['id']=='marketplace':
        surface['expected'].update(source_commit=identity['source']['revision'],wheel_sha256=expected,codex_content_sha256=progress['host_inventory_sha256']['codex'],**{'claude-code_content_sha256':progress['host_inventory_sha256']['claude']})
        surface['next_action']='Finish required native qualification, obtain verification of VREC-PLG-032, then recheck the marketplace parent before the authorized descendant publication.'
    elif surface['id']=='demonstration': surface['expected']['governance_commit']=published['release']['governance_commit']
    elif surface['id']=='release_markers': surface['expected']['last']=published['release']['candidate_commit']
write('delivery-plan.json',plan)
review=f'''# Plugin 0.2.5 qualification progress

Evaluator 0.22.0 is published. Plugin qualification remains incomplete.
WO-RLS-035 stays `in_progress`; VREC-PLG-032 has not been prepared or verified.
The marketplace and latest/last markers have not been changed by this work.

## Published evaluator

- [GitHub release](https://github.com/mmzen/se_harness/releases/tag/v0.22.0)
- [PyPI 0.22.0](https://pypi.org/project/se-harness/0.22.0/)
- [Publisher](https://github.com/mmzen/se_harness/actions/runs/37096141972)
- [Demo site](https://www.verityplane.ai/)

The publisher's third observation passed all five public-install checks. GitHub,
PyPI and Pages report exact identities. Independent GitHub and PyPI-index wheel
downloads both match `{expected}`. The first two observation attempts failed
while PyPI had not exposed the version in its index; those failures are preserved.
No privileged publication step was repeated.

Candidate: `{published['release']['candidate_commit']}`.
Governance snapshot: `{published['release']['governance_commit']}`.
The approved wheel, sdist, release tag and released record were not rebuilt or replaced.

## Observed checks

| Check | Result |
| --- | --- |
| Both exact released-input packages and independent content check | Passed |
| Windows focused suite with selected 0.21.0 checker | 62 tests; 2 skipped |
| Linux focused suite with selected 0.21.0 checker | 62 tests; 1 skipped |
| Portable adapter walkthrough | 41 steps passed on each platform |
| Codex CLI startup, activation, manual/automatic compaction and resume | Passed with full entry |
| Codex CLI session isolation and selection boundaries | {'Passed' if boundary['passed'] else 'Failed; see retained report'} |
| Claude authenticated native checks | Pending: expired OAuth |
| Codex Windows desktop | Pending: no exact-package desktop trace |
| Native new/resumed work and delivery handoff | Pending: not yet executed for these inputs |
| Human verification / public marketplace / public fresh and update tests | Pending |

The unit suite skips are retained in raw outputs. Portable checks exercise real
installed wheels but simulated host events; they do not establish native support.
Codex CLI {native['version']} delivered the complete expected entry and preserved
the fixture checkout. The disposable profile's prior plugin was restored.
Native tests used existing test authentication; no credentials were retained.

## Limits and failures

Claude's existing bound is 10,000 UTF-16 units for the full delivered context,
including paths. The long workspace test needed 10,052 and was correctly refused.
The identical packages passed from a shorter temporary directory. This result
does not establish support for the failed long-path configuration. No policy was
truncated, bound increased or package changed.

The first Linux test environment lacked the installed evaluator needed by its
isolated payload-hash subprocess. Preparing an isolated selected 0.21.0 environment
resolved that test prerequisite. Source and assertions were unchanged.

Claude's status command reported logged in, but its live request failed:
`Failed to authenticate: OAuth session expired and could not be refreshed`.
The human replied: **“Not now—keep those checks pending.”** Claude and desktop
remain unverified. This is not a waiver or risk acceptance.

## Retained evidence and continuation

[qualification.json](qualification.json) contains the result matrix, identities,
native claims, raw-file hashes and remaining actions. [raw.zip](raw.zip) retains
actual commands, failures, successful reruns and native traces.
[public-evaluator.json](public-evaluator.json) retains the successful publication
and independent public-install observations. [delivery-plan.json](delivery-plan.json)
is the next version of WO-RLS-034's approved five-surface plan; the earlier plan
is preserved unchanged with SHA-256 `{sha(plan_path)}`. Public marketplace revision
and documentation closeout remain unset because their work is not complete.

The observed marketplace parent is `{parent}`; read it again before publication.
Continue exact-package native qualification when the human can refresh Claude
authentication and assist with the desktop check. Complete the repeated-work and
delivery-handoff criteria. Then finish the work-order checks, prepare VREC-PLG-032,
publish the review and request the reserved human verification decision.
Existing release execution authority remains recorded; no new publication grant
is requested. WO-RLS-036 follows with public-route checks and latest/last promotion.
'''
(dest/'review.md').write_bytes(review.encode('utf-8'))
print(json.dumps({'path':str(dest),'qualification':'pending','raw_files':len(entries),'raw_bytes':(dest/'raw.zip').stat().st_size,'raw_sha256':sha(dest/'raw.zip')},indent=2))
