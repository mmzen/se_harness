import json, subprocess, sys
from release022_ctl import OUT

def linux(path):
    return '/mnt/c/' + path.as_posix()[3:]

program = r'''import datetime,json,os,pathlib,platform,runpy,shutil,subprocess,sys,tempfile,time
inputs=json.load(sys.stdin); stage=pathlib.Path(tempfile.mkdtemp(prefix='p025-')); source=stage/'source'; rows=[]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1');env.pop('PYTHONPATH',None)
def run(label,args,cwd=stage):
 start=time.monotonic();p=subprocess.run(list(map(str,args)),cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace')
 rows.append(dict(label=label,argv=list(map(str,args)),cwd=str(cwd),exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=round(time.monotonic()-start,2)))
 if p.returncode: raise RuntimeError(label+': '+p.stderr[-3500:])
 return p
result=dict(candidate=inputs['candidate'],platform=platform.platform(),runtime=sys.version,started=datetime.datetime.now(datetime.timezone.utc).isoformat(),stage=str(stage),commands=rows,passed=False)
try:
 run('clone',['git','clone',inputs['bundle'],source])
 run('candidate',['git','checkout',inputs['candidate']],source)
 run('restore-public-origin',['git','remote','set-url','origin','https://github.com/mmzen/se_harness.git'],source)
 assert run('identity',['git','rev-parse','HEAD'],source).stdout.strip()==inputs['candidate']
 run('test-venv',[sys.executable,'-m','venv',stage/'test-env'])
 test_python=stage/'test-env/bin/python'
 run('install-test-runtime',[test_python,'-I','-m','pip','install','--no-index','--no-deps',inputs['governor_wheel']])
 run('focused',[test_python,'-B','-m','unittest','tests.plugin_integration.package_assembly.test_package_assembly','tests.plugin_integration.package_assembly.test_marketplace','tests.plugin_integration.package_assembly.test_refresh_guidance','tests.plugin_integration.progressive_discovery.test_delivery','tests.plugin_integration.progressive_discovery.test_activation','tests.plugin_integration.test_simple_plugin'],source)
 wrapper=stage/'portable.py'
 wrapper.write_text("import runpy,shutil\nfrom pathlib import Path\nm=runpy.run_path("+repr(str(source/'tests/plugin_integration/progressive_discovery/run_resource_acceptance.py'))+",run_name='p025_portable')\ndef use_packages(root,wheel,output):\n shutil.copytree("+repr(inputs['packages'])+",output)\nm['main'].__globals__['develop']=use_packages\nm['main']()\n")
 run('exact-package-adapter',[test_python,'-B',wrapper,'--wheel',inputs['wheel'],'--expected-identity',inputs['identity'],'--legacy-wheel',inputs['legacy'],'--output',stage/'adapter'],source)
 result['adapter']=json.loads((stage/'adapter/report.json').read_text())
 result['passed']=True
except Exception as e: result['error']=str(e)
print(json.dumps(result));sys.exit(0 if result['passed'] else 1)
'''
inputs = dict(candidate='abbec12ac5524c8adfb28693f846dd59de88f759', bundle=linux(OUT/'linux-abbec12ac552.bundle'),
              governor_wheel=linux(OUT.parent/'reconcile-minimal-20261001/rls031-public-readback/se_harness-0.21.0-py3-none-any.whl'),
              packages=linux(OUT/'plugin025-marketplace/packages'), wheel=linux(OUT/'public032-github/se_harness-0.22.0-py3-none-any.whl'),
              identity=linux(OUT/'plugin025-expected-identity.json'), legacy=linux(OUT.parent/'plg030-public-inputs/se_harness-0.20.0-py3-none-any.whl'))
p=subprocess.run([r'C:\Windows\System32\wsl.exe','-d','Ubuntu-24.04','--exec','python3','-c',program],input=json.dumps(inputs),capture_output=True,text=True,encoding='utf-8',errors='replace')
try: result=json.loads(p.stdout)
except ValueError: result=dict(stdout=p.stdout,stderr=p.stderr)
destination=OUT/'plugin025-linux-prepared.json'
assert not destination.exists()
destination.write_text(json.dumps(dict(exit_code=p.returncode,result=result),indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(exit_code=p.returncode,passed=result.get('passed'),error=result.get('error'),checks=[(r['label'],r['exit_code']) for r in result.get('commands',[])])))
sys.exit(p.returncode)
