"""Temporary exact-wheel native probes; only disposable profiles and fixtures."""
from pathlib import Path
import sys,json,subprocess,hashlib,os,base64,zipfile,io,tempfile,re,datetime
WORK=Path(__file__).resolve().parent
OUT=WORK/'release022'
sys.path.insert(0,str(WORK/'iar-demo-tools'))
from run_demo import child_env
from acceptance_native import Codex,extract_codex,save
BASE=Path(json.loads((WORK/'iar-demo-tools/prepared-demo.json').read_text())['demo'])
EXES={'codex':{'executable':r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe'},'claude':{'executable':r'C:\Users\mathi\.local\bin\claude.exe'}}
mode=sys.argv[1]
report={'host':mode,'claims':'Native CLI/app-server only; desktop remains unverified.','commands':[],'stages':[],'passed':False}
dest=OUT/('plugin025-native-'+mode+(('-'+sys.argv[2]) if len(sys.argv)>2 else '')+'.json');assert not dest.exists()
env=child_env(BASE,mode)
root=Path(tempfile.mkdtemp(prefix='p025n-'));parent=root/'w';parent.mkdir()
report['root']=str(root)
inputs=json.loads((OUT/'plugin025-native-inputs.json').read_text());expected=inputs['expected']
package=root/'package'
with zipfile.ZipFile(io.BytesIO(base64.b64decode(inputs[mode]))) as z:
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
    z.extractall(package)
plugin=package/'verity-plane';wheel=plugin/'packages'/expected['archive_name']
assert hashlib.sha256(wheel.read_bytes()).hexdigest()==expected['archive_sha256']
with zipfile.ZipFile(wheel) as z:
    n=next(n for n in z.namelist() if n.endswith('/ENGINEERING_HARNESS.md.tpl'))
    entry=z.read(n).decode().replace('{{PROJECT_NAME}}','Plugin qualification').replace('{{HARNESS_VERSION}}',expected['version'])
digest=hashlib.sha256(entry.encode()).hexdigest();report['entry_sha256']=digest;report['wheel']=expected
report['package_files']={p.relative_to(plugin).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in plugin.rglob('*') if p.is_file()}
def flush():save(dest,report)
def run(label,argv,allowed=(0,),use_env=env):
    argv=list(map(str,argv));r=subprocess.run(argv,cwd=parent,env=use_env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180)
    report['commands'].append({'label':label,'argv':argv,'cwd':str(parent),'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});flush()
    assert r.returncode in allowed,(label,r.stdout[-1200:],r.stderr[-1200:])
    return r.stdout
def assess(contexts):
    assert any(c.endswith(entry) and digest in c for c in contexts),[c[:180] for c in contexts]
def prepare_and_activate(session,data):
    remote=root/'source';remote.mkdir()
    raw=run('prepare-exact-evaluator',[sys.executable,'-I',plugin/'scripts/setup.py','--target',remote,'--data-root',data,'--wheel',wheel],allowed=(1,2))
    found=re.search(r'^Evaluator Python: (.+)$',raw,re.M);assert found
    py=Path(found[1].strip())
    run('fixture-init',[py,'-I','-m','se_harness','init',remote,'--project-name','Plugin qualification','--integration','git','--json'])
    for args in [['init'],['add','.'],['-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','-m','Disposable exact-wheel selection']]:
        run('fixture-git',['git','-C',remote,*args])
    repo=parent/'clone'
    run('clone-after-startup',['git','clone',remote,repo]);assert not (repo/'ENGINEERING_HARNESS.md').exists()
    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in repo.iterdir() if p.is_file()}
    activation=json.loads(run('activate-observed-session',[sys.executable,'-I',plugin/'scripts/activate.py','--host',mode,'--session-id',session,'--data-root',data,'--target',repo]))
    assert activation['status']=='available';assess([activation['content']])
    report['selection']={'session_id':session,'data':str(data),'repository':str(repo),'before':before}
    return repo,before

# Fresh-session recovery: ordinary read-only prompts, unchanged candidate/model.
report['authorization'] = 'Human mmzen: Approve package and required verification, including WO-RLS-035/VER-RLS-034; qualify the final release inputs with existing authorized disposable test profiles.'
report['diagnostic_changes'] = ['new native session and disposable checkout', 'ordinary code/data questions instead of metadata/acknowledgement probes', 'documented auto-compact window only; no percentage override']
report['started_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
report['source_commit'] = 'abbec12ac5524c8adfb28693f846dd59de88f759'
report['repository_head'] = report['source_commit']
report['timing_documentation'] = 'https://code.claude.com/docs/en/model-config#set-the-auto-compact-window'
repo=None;before=None

def native(phase,prompt,session=None):
    argv=[EXES['claude']['executable'],'--print','--verbose','--output-format','stream-json','--include-hook-events','--tools','','--strict-mcp-config','--permission-prompts','none','--setting-sources','project','--settings','{}','--plugin-dir',str(plugin),'--model','sonnet']
    if session: argv += ['--resume',session]
    local=dict(env)
    overrides={'CLAUDE_CODE_AUTO_COMPACT_WINDOW':'100000'} if session else {}
    local.update(overrides)
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        r=subprocess.run(argv,input=prompt,cwd=parent,env=local,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=240)
        stdout,stderr,rc=r.stdout,r.stderr,r.returncode
    except subprocess.TimeoutExpired as exc:
        stdout=exc.stdout or '';stderr=exc.stderr or ''
        if isinstance(stdout,bytes):stdout=stdout.decode('utf-8',errors='replace')
        if isinstance(stderr,bytes):stderr=stderr.decode('utf-8',errors='replace')
        rc=124
    contexts=[];events=[];replies=[];ident=None;models=[]
    for line in stdout.splitlines():
        try:e=json.loads(line)
        except ValueError:continue
        if e.get('session_id'):ident=e['session_id']
        if e.get('type')=='system' and e.get('subtype')=='init':
            models.append(e.get('model'));events.append(e)
        if e.get('subtype')=='hook_response':
            events.append(e)
            try:c=json.loads(e.get('output','{}')).get('hookSpecificOutput',{}).get('additionalContext')
            except ValueError:c=None
            if c:contexts.append(c)
        if e.get('subtype')=='compact_boundary':events.append(e)
        if e.get('type')=='assistant':replies += [c['text'] for c in e.get('message',{}).get('content',[]) if c.get('type')=='text']
        if e.get('type')=='result':events.append(e)
    errors=[e.get('result') for e in events if e.get('is_error')]
    triggers=[e.get('compact_metadata',{}).get('trigger') for e in events if e.get('subtype')=='compact_boundary']
    stage={'phase':phase,'started_at':started,'argv':argv,'stdin':prompt,'cwd':str(parent),'environment_overrides':overrides,'exit_code':rc,'session_id':ident,'contexts':contexts,'events':events,'replies':replies,'models':models,'provider_errors':errors,'compaction_triggers':triggers,'stderr':stderr}
    report['stages'].append(stage);flush()
    print(json.dumps({'phase':phase,'exit_code':rc,'model':models,'compaction_triggers':triggers,'errors':errors}),flush=True)
    assert rc==0 and ident and not errors,{'phase':phase,'exit_code':rc,'errors':errors}
    if session:assert ident==session,('session changed',ident,session)
    return ident,contexts,events

try:
    report['version']=run('host-version',[EXES['claude']['executable'],'--version']).strip()
    assert report['version']=='2.1.273 (Claude Code)', 'Host version changed: inspect before qualifying'
    session,contexts,_=native('fresh-startup','In Python, what does sorted([3, 1, 2]) return? Answer in one sentence. Do not use tools.')
    assert any('# Select the working repository' in c for c in contexts)
    text='\n'.join(contexts)
    declared=re.findall(r'(?m)^Plugin data: (.+)$',text);assert len(declared)==1
    data=Path(declared[0]);assert data.is_relative_to(Path(env['CLAUDE_CONFIG_DIR'])/'plugins/data') and session in text
    repo,before=prepare_and_activate(session,data)
    _,contexts,events=native('fresh-selected-code-review','Review this Python function for empty-list behavior: def average(values): return sum(values) / len(values). State the edge case and one suitable correction in two sentences. Do not use tools or edit files.',session)
    assess(contexts)
    _,contexts,_=native('manual-compaction','/compact',session)
    assess(contexts)
    report['automatic_compaction_observed']=False
    # Bounded ordinary analysis of generated, non-sensitive inventory data.
    # Distinct batches grow conversation context; no manual compact command is used.
    for batch in range(1,7):
        rows=['sku,category,quantity,unit_price']
        categories=['notebook','pencil','folder','envelope']
        for i in range(1600):
            index=(batch-1)*1600+i
            rows.append(f'SKU-{index:06d},{categories[i%4]},{1+i%40},{1+i%12}.{i%100:02d}')
        prompt=('Check this synthetic stationery inventory CSV without using tools or editing files. '
                'Report the column names, the first and last SKU, and whether quantities contain a negative value. '
                'Keep the answer to three short bullets.\n\n'+'\n'.join(rows))
        _,contexts,events=native('inventory-batch-'+str(batch),prompt,session)
        assess(contexts)
        if any(e.get('subtype')=='compact_boundary' and e.get('compact_metadata',{}).get('trigger')=='auto' for e in events):
            report['automatic_compaction_observed']=True
            break
    if not report['automatic_compaction_observed']:
        _,contexts,events=native('automatic-final-observation','Give one sentence explaining why an empty input list needs explicit handling in an average function. Do not use tools or edit files.',session)
        assess(contexts)
        report['automatic_compaction_observed']=any(e.get('subtype')=='compact_boundary' and e.get('compact_metadata',{}).get('trigger')=='auto' for e in events)
    assert report['automatic_compaction_observed'],'Bounded run ended without a native automatic-compaction event'
    _,contexts,_=native('after-automatic','What is the average of [2, 4, 6]? Answer in one sentence. Do not use tools or edit files.',session)
    assess(contexts)
    report['passed']=True
except Exception as exc:
    report['error']=str(exc)
finally:
    if repo is not None:
        after={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in repo.iterdir() if p.is_file()}
        report['repository_preserved']=before==after
        if not report['repository_preserved']:report['passed']=False
    report['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    flush()
print(json.dumps({'passed':report['passed'],'error':report.get('error'),'report':str(dest)}),flush=True)
raise SystemExit(0 if report['passed'] else 1)
