import hashlib,json,subprocess,tomllib,zipfile
from pathlib import Path
from claude025_followup_ctl import REPO,OUT,WORK,run
E=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-039'
G=[r'C:\Program Files\Git\cmd\git.exe','-c','core.longpaths=true','-c','core.autocrlf=false','-c','safe.directory='+REPO.as_posix(),'-C',str(REPO)]
def git(*args):return subprocess.check_output(G+list(args),text=True,encoding='utf8').strip()
assert git('branch','--show-current')=='work/claude-025-evidence-followup'
ctx=json.loads((OUT/'correction-completed-context.json').read_text())
assert ctx['state']['after'][0]['status']=='implemented' and ctx['procedure']['id']=='PROC-WO-PREPARE-VREC'
history=git('log','--all','--format=','--name-only','--','docs/engineering/**/VREC-RLS-*.md')
ident='VREC-RLS-002'
assert ident not in history and not list(REPO.glob('docs/engineering/**/'+ident+'.md'))
selected={'id':ident,'path':'docs/engineering/release-0-22-0/verification-records/'+ident+'.md','evaluator_path':'docs/engineering/release-0-22-0/evidence/'+ident+'-evaluator.json','local_ref_history_paths':history.splitlines()}
(OUT/'correction-selected-vrec.json').write_text(json.dumps(selected,indent=2)+'\n',encoding='utf8',newline='\n')
archive=E/'completion-raw.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for name in ['handoff-packet','review-preflight','implementation-handoff','completion-preview','completion-apply','completed-context','selected-vrec']:
        for suffix in ['.json','-invocation.json']:
            p=OUT/('correction-'+name+suffix)
            if p.exists():z.writestr(p.name,p.read_bytes())
    z.writestr('capture-driver.py',Path(__file__).read_bytes())
    z.writestr('completion-driver.py',(WORK/'claude025_readme_correction_complete.py').read_bytes())
    z.writestr('driver-recovery.json',json.dumps({'observation':'The evidence command wrote its packet successfully. A transient wrapper then incorrectly required its checkpoint-free compliance projection to be pass. Readback confirmed the completed write and current in_progress state. The wrapper assertion was corrected and only unapplied preflight, handoff and completion operations were resumed. No harness refusal was overridden and the packet write was not replayed.'},indent=2)+'\n')
wo=tomllib.loads((REPO/'docs/engineering/release-0-22-0/work-orders/WO-RLS-039.md').read_text().split('+++')[1])
allowed=wo['execution_scope']['paths']
paths=set(git('diff','--name-only','HEAD').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())
assert paths and all(any(p==s or s.endswith('/') and p.startswith(s) for s in allowed) for p in paths),paths
assert hashlib.sha256((REPO/'README.md').read_bytes()).hexdigest()=='a991e5946ad1252ff7ea1a346611954bca6c1536c6b9a4dd1f98c3d2e72a7282'
prior='docs/engineering/release-0-22-0/verification-records/VREC-RLS-001.md'
assert (REPO/prior).read_bytes()==subprocess.check_output(G+['show','f8f318008b99499af553e4400fdf59d938588b2d:'+prior])
git('diff','--check');git('add','--',*sorted(paths))
print(git('commit','-m','Keep the Claude follow-up within the README word limit','-m','Harness-Work-Order: WO-RLS-039'))
candidate=git('rev-parse','HEAD');assert not git('status','--porcelain')
(OUT/'correction-verification-candidate.json').write_text(json.dumps({'commit':candidate,'paths':sorted(paths)},indent=2)+'\n',encoding='utf8',newline='\n')
args=['--id',ident,'--work-order','WO-RLS-038','--work-order','WO-RLS-039','--verification','VER-RLS-002','--verification','VER-RLS-003','--owner','Codex','--domain','release-0-22-0']
evidence=[]
for n in ['WO-RLS-038','WO-RLS-039']:
    for p in sorted((E.parent/n).rglob('*')):
        if p.is_file():evidence.append(p.relative_to(REPO).as_posix())
for p in evidence:args+=['--evidence',p]
rc,d=run('correction-verification-capture','capture-verification',*args)
assert rc==0 and d['operation']['outcome']=='completed',d
record=tomllib.loads((REPO/selected['path']).read_text().split('+++')[1])
assert record['status']=='ready' and record['commit']==candidate
assert (REPO/selected['evaluator_path']).exists()
print(json.dumps({'candidate':candidate,'record':record,'evidence_count':len(evidence)},indent=2))
