import json
from claude025_followup_ctl import OUT,run
assert json.loads((OUT/'correction-rechecked-assessment.json').read_text())['checks'][-1]['name']=='full-recheck'
assert json.loads((OUT/'correction-rechecked-assessment.json').read_text())['checks'][-1]['exit_code']==0
steps=[
 ('correction-review-preflight','preflight',['--work-order','WO-RLS-039','--phase','review']),
 ('correction-implementation-handoff','check',['--artifact','WO-RLS-039','--checkpoint','handoff','--from-git','f8f318008b99499af553e4400fdf59d938588b2d']),
]
reason='WO-RLS-039=Completed the exact approved README paragraph correction: 644 words, retained evidence link and limits; unchanged focused and full source tests, released validation, review preflight and complete Git-derived handoff passed. Original records and evidence are preserved. Codex records implementation completion under mmzen approval; human verification remains separate.'
steps += [('correction-completion-preview','transition',['--set','WO-RLS-039=implemented','--decision','WO-RLS-039=Codex','--reason',reason]),('correction-completion-apply','transition',['--set','WO-RLS-039=implemented','--decision','WO-RLS-039=Codex','--reason',reason,'--apply']),('correction-completed-context','check',['--artifact','WO-RLS-039'])]
for label,cmd,args in steps:
    rc,d=run(label,cmd,*args)
    assert rc==0,(label,d)
    if 'compliance' in d and cmd=='transition':assert d['compliance']['status']=='pass',(label,d['restitution'])
    if label=='correction-implementation-handoff':assert d['compliance']['status']=='pass',d['restitution']
    if label=='correction-completed-context':assert d['state']['after'][0]['status']=='implemented';print(json.dumps(d['restitution'],indent=2))
