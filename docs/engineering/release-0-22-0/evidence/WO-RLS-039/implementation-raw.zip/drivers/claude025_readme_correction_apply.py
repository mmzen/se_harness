import hashlib, json, subprocess
from claude025_followup_ctl import REPO, OUT, run
G=[r'C:\Program Files\Git\cmd\git.exe','-c','core.longpaths=true','-c','core.autocrlf=false','-c','safe.directory='+REPO.as_posix(),'-C',str(REPO)]
paths=set(subprocess.check_output(G+['ls-files','--others','--exclude-standard'],text=True).splitlines())
paths.update(subprocess.check_output(G+['diff','--name-only','HEAD'],text=True).splitlines())
e='docs/engineering/release-0-22-0/evidence/WO-RLS-039/'
paths.update(['README.md',*(e+x for x in ['implementation-checks.json','implementation-raw.zip','handoff.json','WO-RLS-039-handoff.md','completion-raw.zip','verification-review.md'])])
args=['--artifact','WO-RLS-039','--checkpoint','scope','--changes-complete']
for p in sorted(paths):args.extend(['--changed-path',p])
rc,data=run('correction-implementation-scope','check',*args)
assert rc==0 and data['compliance']['status']=='pass',data.get('findings')
target=REPO/'README.md'; proposal=OUT/'proposed-readme.md'
assert hashlib.sha256(target.read_bytes()).hexdigest()=='d1023665b76acf55c3035c39f7857f4f4375e74975794e17e956d7ee0cb50107'
assert hashlib.sha256(proposal.read_bytes()).hexdigest()=='a991e5946ad1252ff7ea1a346611954bca6c1536c6b9a4dd1f98c3d2e72a7282'
target.write_bytes(proposal.read_bytes())
print(json.dumps({'applied':str(target),'words':len(target.read_text().split()),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}))
