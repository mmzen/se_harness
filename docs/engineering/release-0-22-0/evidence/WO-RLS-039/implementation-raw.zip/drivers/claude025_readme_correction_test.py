import datetime,difflib,hashlib,json,os,re,subprocess,sys,tomllib
from claude025_followup_ctl import REPO,OUT
E=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-039'
review=json.loads((OUT/'readme-correction-reviewed-inputs.json').read_text())
wo=tomllib.loads((REPO/'docs/engineering/release-0-22-0/work-orders/WO-RLS-039.md').read_text().split('+++')[1]);assert wo['status']=='in_progress'
text=(REPO/'README.md').read_text(encoding='utf8')
assert (REPO/'README.md').read_bytes()==(OUT/'proposed-readme.md').read_bytes()
assert hashlib.sha256((REPO/'README.md').read_bytes()).hexdigest()==review['proposal_readme_sha256']
assert len(text.split())==644 and len(text.splitlines())<=200 and len(re.findall(r'(?m)^## ',text))<=7
G=[r'C:\Program Files\Git\cmd\git.exe','-c','core.longpaths=true','-c','core.autocrlf=false','-c','safe.directory='+REPO.as_posix(),'-C',str(REPO)]
base='f8f318008b99499af553e4400fdf59d938588b2d'
old=subprocess.check_output(G+['show',base+':README.md']).decode()
patch=''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),fromfile='a/README.md',tofile='b/README.md'))
assert patch==(E/'proposed-readme.patch').read_text()
changed=subprocess.check_output(G+['diff','--name-only','HEAD'],text=True).splitlines()
assert changed==['README.md'],changed
for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)',text):
    target=target.split('#',1)[0]
    if target and '://' not in target: assert (REPO/target).exists(),target
original=json.loads((REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-038/observations.json').read_text())
for path,want in original['original_records']['files_sha256'].items():assert hashlib.sha256((REPO/path).read_bytes()).hexdigest()==want,path
vrec='docs/engineering/release-0-22-0/verification-records/VREC-RLS-001.md'
assert (REPO/vrec).read_bytes()==subprocess.check_output(G+['show',base+':'+vrec])
prior=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-038'
for p in sorted(prior.iterdir()):
    if p.is_file():assert p.read_bytes()==subprocess.check_output(G+['show',base+':'+p.relative_to(REPO).as_posix()])
env=dict(os.environ,GIT_CONFIG_COUNT='3',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true',GIT_CONFIG_KEY_1='core.autocrlf',GIT_CONFIG_VALUE_1='false',GIT_CONFIG_KEY_2='safe.directory',GIT_CONFIG_VALUE_2=REPO.as_posix(),PYTHONDONTWRITEBYTECODE='1')
summary={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'work_order':'WO-RLS-039','contract':'VER-RLS-003','base':base,'readme_sha256':hashlib.sha256((REPO/'README.md').read_bytes()).hexdigest(),'words':len(text.split()),'lines':len(text.splitlines()),'h2_headings':len(re.findall(r'(?m)^## ',text)),'approved_patch_matches':True,'prior_evidence_and_records_unchanged':True,'local_links_resolve':True,'checks':[]}
for name,args in [('focused',['-B','-X','utf8','-m','unittest','tests.test_public_onboarding','tests.test_progressive_documentation','tests.plugin_integration.package_assembly.test_refresh_guidance']),('full',['-B','-X','utf8','scripts/run_tests.py','--workers','4','--scale','full'])]:
    dest=OUT/('correction-'+name+'-tests.json');assert not dest.exists()
    argv=[sys.executable,*args];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=subprocess.run(argv,cwd=REPO,env=env,capture_output=True,text=True,encoding='utf8')
    receipt={'argv':argv,'cwd':str(REPO),'python':sys.version,'started_at':start,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    dest.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8',newline='\n')
    summary['checks'].append({'name':name,'exit_code':p.returncode,'receipt':dest.name,'summary':(p.stderr or p.stdout)[-1600:]})
    print(json.dumps(summary['checks'][-1]),flush=True)
    (OUT/'correction-substantive-assessment.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8',newline='\n')
    assert p.returncode==0,name
print('All required local checks passed.',flush=True)
