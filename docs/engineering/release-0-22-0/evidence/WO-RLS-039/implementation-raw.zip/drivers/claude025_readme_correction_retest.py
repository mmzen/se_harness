import datetime,json,os,subprocess,sys
from claude025_followup_ctl import REPO,OUT
env=dict(os.environ,GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true',GIT_CONFIG_KEY_1='safe.directory',GIT_CONFIG_VALUE_1=REPO.as_posix(),PYTHONDONTWRITEBYTECODE='1')
for key in ['GIT_CONFIG_KEY_2','GIT_CONFIG_VALUE_2']:env.pop(key,None)
observed=subprocess.check_output([r'C:\Program Files\Git\cmd\git.exe','config','--show-origin','--get','core.autocrlf'],env=env,text=True).strip()
summary=json.loads((OUT/'correction-substantive-assessment.json').read_text())
summary['initial_full_suite']={'receipt':'correction-full-tests.json','result':'1262 tests, one release-plan digest error, 22 skips','cause':'The transient driver forced core.autocrlf=false for every test fixture. The affected fixture writes platform text then hashes LF strings and relies on normal Git normalization. The driver is corrected to leave normal Git configuration intact; no repository file, test or assertion changes.'}
summary['checks']=[x for x in summary['checks'] if x['name']!='full']
for name,args in [('environment-recheck',['-m','unittest','tests.test_release_orchestration.CompleteReleaseTests.test_resolver_binds_one_real_git_review_and_refuses_later_plan_changes']),('full-recheck',['scripts/run_tests.py','--workers','4','--scale','full'])]:
    dest=OUT/('correction-'+name+'.json');assert not dest.exists()
    argv=[sys.executable,'-B','-X','utf8',*args];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=subprocess.run(argv,cwd=REPO,env=env,capture_output=True,text=True,encoding='utf8')
    result={'argv':argv,'cwd':str(REPO),'python':sys.version,'started_at':start,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{'core.autocrlf':observed,'overrides':['core.longpaths=true','safe.directory='+REPO.as_posix()]},'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    dest.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n')
    item={'name':name,'exit_code':p.returncode,'receipt':dest.name,'summary':p.stdout[-2200:]+'\n'+p.stderr[-1200:]}
    print(json.dumps(item),flush=True)
    summary['checks'].append(item)
    (OUT/'correction-rechecked-assessment.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8',newline='\n')
    assert p.returncode==0,name
