import hashlib,json,tomllib
from claude025_followup_ctl import OUT,REPO,run
review=json.loads((OUT/'readme-correction-reviewed-inputs.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for path,want in review['artifacts'].items():assert sha(REPO/path)==want,path
assert sha(REPO/'README.md')==review['readme_current_sha256']
assert sha(OUT/'proposed-readme.md')==review['proposal_readme_sha256']
reason='Human mmzen replied I approve to the reviewed WO-RLS-039 and VER-RLS-003 request: shorten only the new README paragraph from 690 to 644 total words, preserve its evidence link and unverified areas, run unchanged documentation tests and the full suite, and prepare required commit-bound verification. Approval also covers correction and later verification-decision pushes to existing PR 533, mmzen/se_harness, work/claude-025-evidence-followup to main. Human acceptance of the corrected candidate and merge remain separate. Codex applies this decision.'
wo=REPO/'docs/engineering/release-0-22-0/work-orders/WO-RLS-039.md'
t=wo.read_text(encoding='utf8');assert '[assurance]' not in t
t=t.replace('\n[execution_scope]\n','\n[assurance]\ncommit_bound_verification = "required"\nrationale = "Human mmzen confirmed that integration and public guidance rely on correct presentation and coverage claims; the corrected candidate requires commit-bound verification."\ndecided_by = "mmzen"\n\n[execution_scope]\n',1)
wo.write_text(t,encoding='utf8',newline='\n')
inputs={path:sha(REPO/path) for path in review['artifacts']}
(OUT/'correction-approval-inputs.json').write_text(json.dumps({'human':'mmzen','answer':'I approve','reason':reason,'reviewed':review,'transition_inputs':inputs},indent=2)+'\n',encoding='utf8',newline='\n')
args=[]
for ident in ['VER-RLS-003','WO-RLS-039']:
    path=next(p for p in inputs if p.endswith('/'+ident+'.md'))
    args+=['--set',ident+'=approved','--decision',ident+'=mmzen','--reason',ident+'='+reason+' Reviewed SHA-256 '+review['artifacts'][path]+'; transition input SHA-256 '+inputs[path]+'. Only confirmed WO assurance metadata was added.']
code,data=run('correction-approval-preview','transition',*args);assert code==0,data
for path,want in inputs.items():assert sha(REPO/path)==want,path
code,data=run('correction-approval-apply','transition',*args,'--apply');assert code==0,data
for path in inputs:assert tomllib.loads((REPO/path).read_text().split('+++')[1])['status']=='approved'
code,data=run('correction-start-preflight','preflight','--work-order','WO-RLS-039','--phase','start');assert code==0 and data['ready'],data
args=['--set','WO-RLS-039=in_progress','--decision','WO-RLS-039=Codex','--reason','WO-RLS-039=Codex starts the bounded approved README correction; approved scope and required verification are unchanged.']
code,data=run('correction-start-preview','transition',*args);assert code==0,data
code,data=run('correction-start-apply','transition',*args,'--apply');assert code==0,data
assert tomllib.loads(wo.read_text().split('+++')[1])['status']=='in_progress'
print('Approval and work start applied; README not yet changed.')
