import hashlib,json,subprocess,sys,zipfile
from claude025_followup_ctl import REPO,OUT,WORK
E=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-039'
assessment=json.loads((OUT/'correction-rechecked-assessment.json').read_text())
assert len(assessment['checks'])==3 and all(x['exit_code']==0 for x in assessment['checks'])
validation=json.loads((OUT/'correction-implementation-validation.json').read_text());assert validation['error_count']==0
G=[r'C:\Program Files\Git\cmd\git.exe','-c','core.longpaths=true','-c','core.autocrlf=false','-c','safe.directory='+REPO.as_posix(),'-C',str(REPO)]
p=subprocess.run(G+['diff','--check'],capture_output=True,text=True);assert p.returncode==0
(OUT/'correction-diff-check.json').write_text(json.dumps({'argv':G+['diff','--check'],'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr},indent=2)+'\n')
origin_argv=[sys.executable,'-B','-c','import se_harness,sys; print(sys.executable); print(se_harness.__file__)']
origin=subprocess.run(origin_argv,cwd=REPO,capture_output=True,text=True);assert origin.returncode==0
assert str(REPO/'se_harness'/'__init__.py') in origin.stdout
(OUT/'correction-source-origin.json').write_text(json.dumps({'argv':origin_argv,'cwd':str(REPO),'exit_code':origin.returncode,'stdout':origin.stdout,'stderr':origin.stderr},indent=2)+'\n')
archive=E/'implementation-raw.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.glob('correction-*.json')):z.writestr(p.name,p.read_bytes())
    for n in ['claude025_readme_correction_apply.py','claude025_readme_correction_test.py','claude025_readme_correction_retest.py','claude025_readme_correction_approve.py','claude025_readme_correction_retain.py','claude025_followup_ctl.py']:z.writestr('drivers/'+n,(WORK/n).read_bytes())
old=REPO/'docs/engineering/release-0-22-0/evidence/WO-RLS-038'
summary={**assessment,'status':'pass','released_validation':{'version':'0.22.0','errors':0,'warnings':validation['warning_count']},'diff_check':'pass','original_ci_failure':'ci-failure.log','archive':{'path':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'reused_native_evidence':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(old.iterdir()) if p.is_file()},'review':{'REQ-DST-069':'Pass: 644 words, 104 physical lines, seven H2 headings; exact approved paragraph patch and links checked; all other README bytes preserved.','REQ-RLO-020':'Pass: Windows installation, update and session checks are bounded by the linked dated evidence. Codex desktop, the full Claude workflow and long paths remain unverified; historical decisions and accepted risks remain unchanged.','REQ-IAR-030 / REQ-RLO-019':'Reuse byte-identical WO-RLS-038 observations and assessment. No product, package, host or native input changed. This correction adds no host coverage.'},'limitations':['Codex Windows desktop remains unverified','Full Claude author/work-order execution/delivery workflow remains unverified','Earlier long-path failure remains unverified','Native tests used --plugin-dir, disabled tools and short paths; installation profiles are linked by package byte identity','Original accepted risks and decisions remain unchanged'],'ci':'The prior Linux README-budget failure is retained. New remote CI is required before reporting merge readiness.'}
(E/'implementation-checks.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8',newline='\n')
report='''# Verification review: concise Claude follow-up

The README correction changes only the approved Claude follow-up paragraph.
The README now has 644 words, 104 lines and seven level-two headings, within
the accepted limits of 650 words, 200 lines and seven headings. It preserves
the evidence link and all three unverified areas. No product or test change
was needed.

## Requirement assessment

| Requirement | Result and evidence |
| --- | --- |
| REQ-DST-069 | Pass. The actual README matches the approved patch. Counts and links pass; all other content, commands and images are preserved. |
| REQ-RLO-020 | Pass. The paragraph states the observed Windows subset and links the dated report. All remaining gaps and historical authority are explicit. The five other corrected guides are unchanged from WO-RLS-038. |
| REQ-IAR-030 | The passing native instruction-delivery assessment from WO-RLS-038 is reused without changing its observations or inputs. This correction adds no native coverage. |
| REQ-RLO-019 | The matching public fresh/update inventories and independent 29-file package comparison from WO-RLS-038 are reused unchanged. |

[Implementation checks](implementation-checks.json) retain the actual word count,
file digests, focused and full-suite results, validation and preservation checks.
[Raw results](implementation-raw.zip) retain commands, runtimes, output and the
approval/scope results. [The previous CI failure](ci-failure.log) and
[the reviewed patch](proposed-readme.patch) show the defect and its correction.
The failure came from exceeding the existing 650-word limit; the test and
accepted budget are unchanged.

All 44 focused tests pass. The full-suite result is recorded in the linked
checks with its actual skips. Released evaluator 0.22.0 validation has zero
errors and 61 existing warnings. Handoff and completion results are retained
in completion-raw.zip before candidate capture. Hosted CI is assessed after
publication and must pass before reporting the correction as merge-ready.

The first local full run had one release-plan fixture error among 1,262 tests
with 22 skips. The transient test driver forced core.autocrlf=false into every
fixture, preventing the platform-written plan from being normalized to the
LF bytes expected by that fixture. Removing that driver override preserves
the normal workstation configuration and each fixture's own settings. The
specific failing test and full suite were rerun unchanged; both attempts are
retained. No repository code, test or setting was changed to resolve it.

The original [Claude assessment](../WO-RLS-038/verification-review.md), every
WO-RLS-038 evidence file, WO-RLS-038 itself, and VREC-RLS-001 remain unchanged.
VREC-RLS-001 retains its human decision for its original candidate. A fresh
combined record covers WO-RLS-038/039 and VER-RLS-002/003 at the corrected commit.
Its exact record and candidate will be linked in PR #533 before verification.

## Limits and decision

Codex Windows desktop, the full Claude author/work-order execution/delivery
walkthrough and the earlier long-path failure remain unverified. Native tests
used short paths, tools disabled and --plugin-dir; separately observed public
installation profiles had matching package bytes. Existing risks stay accepted
and open for follow-up under DEC-RLS-005/006; DEC-RLS-007/008 bound the supplement.
This review does not add a host test, close a risk or alter the released package.

The correction uses one paragraph and existing tests. Detailed coverage stays
in the linked evidence, avoiding duplication in the public entry. The approved
scope is sufficient; no broader implementation or architecture is needed.

Human verification of the corrected candidate and merge remain separate.
'''
(E/'verification-review.md').write_text(report,encoding='utf8',newline='\n')
print(json.dumps({'assessment':'pass','archive_bytes':archive.stat().st_size,'checks':summary['checks']}))
