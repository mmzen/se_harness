+++
id = "WO-FLW-002"
type = "work_order"
title = "Provide the planned fixture note"
status = "draft"
owners = ["owner"]
created = "2026-10-16"
updated = "2026-10-16"

[execution_scope]
paths = ["notes/future.txt", "docs/engineering/product/work-orders/WO-FLW-002.md", "docs/engineering/product/evidence/WO-FLW-002/"]

[relations]
implements = ["REQ-FLW-001"]
specifications = ["SPEC-FLW-001"]
architecture = ["ARCH-FLW-001"]
verification = ["VER-FLW-001"]
+++

# Work Order: Provide the planned fixture note

## Objective

A future fixture reader can read notes/future.txt containing exactly `planned` followed by one LF: UTF-8 bytes 70 6c 61 6e 6e 65 64 0a, without a BOM.

## In scope

Create the selected note, maintain this work-order record, and retain its verification evidence.

## Out of scope

Other notes, accepted definitions, runtime behavior, configuration, packaging, CI, and external publication.

## Authorized decision envelope

After approval, Codex may choose the local write and check commands within the declared paths and act as the actual executor for start and completion. Changes to acceptance text, scope, definitions, or assurance classification require the accountable human's decision.

## Constraints

Reuse the accepted local filesystem layout and linked definitions unchanged. Keep this proposal in draft until reviewed.

## Expected change surface

- notes/future.txt: the new reader-facing note; absent in the inspected fixture.
- docs/engineering/product/work-orders/WO-FLW-002.md: this proposal and its later execution record.
- docs/engineering/product/evidence/WO-FLW-002/: retain commands, output and exit codes for this work.

The inspected notes/note.txt and WO-FLW-001 are unrelated and remain unchanged. The accepted REQ, SPEC, ARCH and VER cover this note without amendments. No callers, runtime, tests, packaging or CI files exist in this fixture that need adjustment. A direct exact-content check suffices; no new test framework or documentation is needed. No generated destination is unresolved.

## Required verification

Apply VER-FLW-001 to REQ-FLW-001 on Windows: read notes/future.txt as UTF-8 and compare with the acceptance text above. Also compare raw bytes with the eight specified bytes to detect BOM or newline differences. Missing files, decoding errors or any mismatch fail. Codex records the command, output and exit code. Run the selected evaluator's validation and required scope checks.

## Evidence to record

Retain the exact-content check and evaluator results under docs/engineering/product/evidence/WO-FLW-002/, including command, output and exit code. Evidence is produced during future authorized execution.

## Proposed assurance classification

Propose `required`: later acceptance of the note relies on the correctness of newly written content and its evidence; this work does more than transport an existing decision. Human confirmation is pending. No decided assurance table is recorded.

## Stop and escalate conditions

Stop if the note already contains conflicting content, a check fails, a required path falls outside scope, or the accepted definitions no longer cover the outcome. Resolve the assurance classification before approval.

## Completion report format

Codex reports the actual note content, changed paths, commands and results, evidence location, limitations, final lifecycle state and evaluator-reported next accountable decision.
