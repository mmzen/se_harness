+++
id = "WO-FLW-001"
type = "work_order"
title = "WO-FLW-001"
status = "approved"
owners = ["owner"]
created = "2026-08-11"
updated = "2026-08-11"
evidence_paths = ["docs/engineering/product/evidence/WO-FLW-001/observations.md"]

[assurance]
commit_bound_verification = "not_required"
rationale = "Disposable explanatory note only, with exact text check; no product behavior or authority change."
decided_by = "engineering-owner"

[execution_scope]
paths = ["notes/note.txt", "docs/engineering/product/work-orders/", "docs/engineering/product/evidence/WO-FLW-001/"]

[relations]
implements = ["REQ-FLW-001"]
specifications = ["SPEC-FLW-001"]
architecture = ["ARCH-FLW-001"]
verification = ["VER-FLW-001"]
[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-09-30T00:00:00Z"
decided_by = "engineering-owner"
reason = "Synthetic fixture approval, not production authority."
scope_paths = ["notes/note.txt", "docs/engineering/product/work-orders/", "docs/engineering/product/evidence/WO-FLW-001/"]

+++

# WO-FLW-001

## Fixture scope

Replace notes/note.txt with exactly `after` followed by one LF. Retain the required check output under the declared evidence directory. The work-orders directory also covers transport of the separately prepared new draft; this grants no approval or implementation authority for that draft.

## Simulated existing approval

This is synthetic fixture history for WO-RLS-046 qualification, not a real person or a product approval. The test scenario supplies existing approval by engineering-owner for this exact scope and not_required classification. Start, local edits, local commits, checks and completion are included. Push, PR, release and actual external actions are excluded.
