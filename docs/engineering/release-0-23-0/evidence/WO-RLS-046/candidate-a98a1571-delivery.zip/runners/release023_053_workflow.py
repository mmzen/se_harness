"""Current-package native work-to-delivery rehearsal in two disposable checkouts."""
from pathlib import Path
import json,sys,tempfile
W=Path(__file__).parent;D=W/'release023-053-qualification/delivery'
location=D/'workflow-location.json'
if not location.exists():
    root=Path(tempfile.mkdtemp(prefix='r2353flow-'))
    location.write_text(json.dumps({'root':str(root)},indent=2)+'\n')
root=Path(json.loads(location.read_text())['root'])
s=(W/'r221_fix043_codex_workflow.py').read_text()
changes={
 'from acceptance_native import Codex, extract_codex, save':'from release023_053_delivery_support import Codex, extract_codex, save',
 "BASE = Path(json.loads((WORK/'iar-demo-tools/prepared-demo.json').read_text())['demo'])":"BASE = Path(json.loads((WORK/'release023-053-qualification/delivery/codex-short-profile.json').read_text())['root'])",
 "ROOT = Path(r'C:\\Users\\mathi\\AppData\\Local\\Temp\\r221-fix043-flow')":'ROOT = Path('+repr(str(root))+')',
 "OUT = WORK/'r221-fix043-20261005/native-workflow'":"OUT = WORK/'release023-053-qualification/delivery/native-workflow'",
 'a51e250fa15c740a':'2e5e00daee91c61d',
 "MARKET = WORK/'r221-fix043-20261005/plugin026-marketplace'":"MARKET = Path(json.loads((WORK/'release023-053-qualification/delivery/codex-short-ready-for-trust.json').read_text())['marketplace'])",
 "REPO = WORK/'r221'":"REPO = WORK/'hag221proposal'",
 '0.2.6':'0.2.7', '0.22.1':'0.23.0',
 '41aa3f93f126c1f7cbb9efb6b31d5bb3ad755358e37069699d21bfee9be39475':'f2fbc394a65da29fcdb02eb6994dc08e7bc8ad6248b8ddad440021c68e583e16',
 'WO-RLS-041':'WO-RLS-046',
 "print(json.dumps({'phase':phase,'replies':replies}),flush=True)":"print(json.dumps({'phase':phase,'completed':True,'report':str(dest/'report.json')}),flush=True)"
}
for a,b in changes.items():
    assert a in s,a
    s=s.replace(a,b)
assert not sys.argv[1].startswith(('install','restore')),'Reuse only the already reviewed isolated package.'
exec(compile(s,'current-disposable-workflow','exec'),{'__file__':__file__,'__name__':'__main__'})
