"""Read-only native hook registration and trust diagnostics."""
import json,sys
from pathlib import Path
W=Path(__file__).parent;O=W/'release023-053-qualification/delivery'
sys.path.insert(0,str(W/'iar-demo-tools'))
from release023_053_delivery_support import Codex,save
R=json.loads((O/'plugin027-trusted-native-codex.json').read_text())
E=O/'codex-hook-inspection';E.mkdir(exist_ok=False)
client=Codex({'demo':str(O/'private-profiles'),'host_executables':{'codex':r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\2e5e00daee91c61d\codex.exe'}},E)
try:
    result=client.rpc('hooks/list',{'cwds':[str(Path(R['root'])/'w')]})
    save(E/'hooks.json',result);print(json.dumps(result,indent=2))
finally:client.close()
