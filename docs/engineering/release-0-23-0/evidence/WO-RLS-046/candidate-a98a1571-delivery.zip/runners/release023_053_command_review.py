"""Apply one manually reviewed native permission request; never a persistent rule."""
from pathlib import Path
import json,sys
D=Path(__file__).parent/'release023-053-qualification/delivery/native-workflow'/sys.argv[1]
r=json.loads((D/'pending-command.json').read_text());assert r['sha256']==sys.argv[2]
assert sys.argv[3] in ('accept','decline')
with (D/(r['sha256']+'.decision.json')).open('x',encoding='utf-8') as f:
 json.dump({'sha256':r['sha256'],'decision':sys.argv[3],'reason':sys.argv[4]},f,indent=2)
print('Recorded one exact command decision.')
