"""Run the existing native isolation/switching cases with the exact current plugin."""
from pathlib import Path
import json,sys,time
W=Path(__file__).parent;O=W/'release023-053-qualification/delivery'
deadline=time.monotonic()+600
result=O/'plugin027-trusted-native-short-codex.json'
while time.monotonic()<deadline:
    if result.exists() and json.loads(result.read_text()).get('passed'):break
    time.sleep(2)
assert json.loads(result.read_text())['passed']
s=(W/'r221_fix043_boundaries_codex.py').read_text()
changes={
"OUT=WORK/'r221-fix043-20261005'":"OUT=WORK/'release023-053-qualification/delivery'",
"BASE=Path(json.loads((WORK/'iar-demo-tools/prepared-demo.json').read_text())['demo'])":"BASE=Path(json.loads((OUT/'codex-short-profile.json').read_text())['root'])",
'from acceptance_native import Codex,extract_codex,save':'from release023_053_delivery_support import Codex,extract_codex,save',
'a51e250fa15c740a':'2e5e00daee91c61d','plugin026':'plugin027','0.2.6':'0.2.7',
"prefix='p026b-'":"prefix='r2353bounds-'",
"restore=installed[0]['marketplaceSource']['source']":"restore=None",
"market=OUT/'plugin027-marketplace'":"market=Path(json.loads((OUT/'codex-short-ready-for-trust.json').read_text())['marketplace'])",
"run('install-exact-package',[exe,'-c','marketplaces.se-harness.source='+json.dumps(str(market)),'plugin','add','verity-plane@se-harness','--json'])":"# Exact already installed package is checked below; no installation replay."
}
for a,b in changes.items():assert a in s,a;s=s.replace(a,b)
sys.argv=[__file__,'codex']
exec(compile(s,'current-native-delivery-boundaries','exec'),{'__file__':__file__,'__name__':'__main__'})
