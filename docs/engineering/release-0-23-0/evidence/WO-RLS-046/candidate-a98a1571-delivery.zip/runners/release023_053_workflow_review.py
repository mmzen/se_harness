"""Retain independent proposal-only observations, without claiming the full cycle."""
import hashlib,json,subprocess,tomllib
from pathlib import Path
W=Path(__file__).parent;D=W/'release023-053-qualification/delivery/native-workflow'
O=D/'successor-proposal';report=json.loads((O/'report.json').read_text());f=report['fixture'];R=Path(f['repo'])
git=lambda *a:subprocess.check_output(['git','-c','safe.directory='+str(R),'-C',str(R),*a],text=True).strip()
assert git('rev-parse','HEAD')==f['baseline']
assert not git('diff',f['baseline'],'--name-only')
new=git('ls-files','--others','--exclude-standard').splitlines()
path='docs/engineering/product/work-orders/WO-FLW-002.md'
assert new==[path],new
raw=(R/path).read_bytes();meta=tomllib.loads(raw.decode().split('+++')[1])
assert meta['status']=='draft' and 'assurance' not in meta and 'lifecycle_events' not in meta
assert meta['relations']['implements']==['REQ-FLW-001']
assert not (R/'notes/future.txt').exists()
original_note=subprocess.check_output(['git','-c','safe.directory='+str(R),'-C',str(R),'show',f['baseline']+':notes/note.txt'])
assert (R/'notes/note.txt').read_bytes()==original_note
rows=[json.loads(x) for x in (O/'native-events.jsonl').read_text().splitlines()]
items=[(i+1,x['notification']['params']['item']) for i,x in enumerate(rows) if x.get('notification',{}).get('method')=='item/completed']
commands=[(i,x) for i,x in items if x.get('type')=='commandExecution']
failures=[{'event_line':i,'exit_code':x.get('exitCode'),'status':x.get('status'),'command':x.get('command'),'output':x.get('aggregatedOutput')} for i,x in commands if x.get('exitCode') not in (None,0) or x.get('status')=='failed']
dest=O/'fixture-readback';dest.mkdir()
for p in R.rglob('*.md'):
 if '.git' in p.relative_to(R).parts:continue
 target=dest/p.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
assessment={'candidate':'a98a1571292f5bbf34cd2c7cff0af793d00fa12f','scope':'Proposal only; not full work-to-delivery or complete instruction-compliance qualification.','proposal_boundary_passed':True,'independent_observations':{'baseline_unchanged':f['baseline'],'only_untracked_file':path,'new_artifact_sha256':hashlib.sha256(raw).hexdigest(),'new_state':'draft','no_decided_assurance':True,'no_new_lifecycle_events':True,'no_implementation':True,'existing_note_unchanged':True},'visible_completed_commands':len(commands),'exact_total_claimed':False,'failures':failures,'content_review':'New draft states the exact requested bytes, allowed paths, governing links, check and evidence, with required assurance explicitly proposed rather than decided. No execution or publication authority inferred.','fixture_problem':{'record':'WO-FLW-001','classification':'not_required','finding':'Historical synthetic note-implementation approval conflicts with current required assurance policy. Do not use it as an execution happy path.','preserved':True,'execution_attempted':False,'next':'Prepare fresh correctly classified fixtures; preserve this original fixture and proposal trace.'},'timing_limit':'Per-command review waits are inside the observed session; no authoring-performance or desktop claim.'}
(O/'independent-assessment.json').write_text(json.dumps(assessment,indent=2)+'\n')
print(json.dumps({'proposal_boundary_passed':True,'commands_observed':len(commands),'failed_commands':len(failures),'full_cycle':'pending'}))
