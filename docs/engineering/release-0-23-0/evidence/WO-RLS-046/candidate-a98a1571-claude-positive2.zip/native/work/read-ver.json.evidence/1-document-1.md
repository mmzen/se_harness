+++
id = "VER-P3-001"
type = "verification"
title = "Assert exact greeting by independent string comparison"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert exact greeting by independent string comparison

## Independence

The expected value `Hello rehearsal` is fixed by REQ-P3-900 acceptance criteria
and SPEC-P3-900 rule P3-GREET-900. The pass condition derives from the
requirement statement, not from candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Exact string equality assertion via `assert-greeting` | `greeting()` returns the string `Hello rehearsal` (exit 0 with `exact greeting passed`) |

## Acceptance scenarios

Run `assert-greeting` against the candidate fixture on the native test host.
The assertion compares the return value of `greeting()` to the independently
derived expected string `Hello rehearsal`.

- **Platform:** Native test host (Windows), using the selected `client_python`.
- **Evaluator:** se_harness 0.22.1 (archive SHA-256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`).
- **Pass:** Exit status 0 and stdout contains `exact greeting passed`.
- **Fail:** Nonzero exit status.

## Evidence retention

Retain the assertion record at
`docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-assertion.json`.
The record captures the command, exit status, stdout, stderr and elapsed time.
