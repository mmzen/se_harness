"""Run the existing packaged walkthrough against the current candidate tuple."""
from pathlib import Path
W=Path(__file__).parent
source=(W/'release023_050_sandbox.py').read_text()
source=source.replace('release023-050-qualification','release023-054-qualification').replace('release023-050-execution','release023-054-execution')
source=source.replace('PORT=18823','PORT=18925').replace("'--restore-port','18724'","'--restore-port','18926'")
exec(compile(source,str(W/'release023_050_sandbox.py'),'exec'),{'__name__':'__main__'})
