+++
id = "VER-P3-901"
type = "verification"
title = "Assert the exact rehearsal greeting by independent comparison"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert the exact rehearsal greeting by independent comparison

## Independence

The expected value `Hello rehearsal` is stated by the acceptance criteria in REQ-P3-900 and by rule P3-GREET-900 in SPEC-P3-900. The pass condition compares the candidate function output against this independently fixed string. No candidate output determines the expected result.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | `assert-greeting` on the native test host (Windows, `client_python`) | `greeting()` returns a value exactly equal to the string `Hello rehearsal`. Exit 0 with `exact greeting passed`. Evaluator: 0.22.1. |

## Acceptance scenarios

Run `assert-greeting --record <new-evidence-path>` using the approved shell prefix on the native test host. Before execution, confirm that the source digest matches the selected `greeting_sha256`. The tool calls `greeting()` once and compares the return value to `Hello rehearsal` using exact string equality.

**Pass:** Exit code 0 and stdout contains `exact greeting passed`.

**Fail:** Nonzero exit code.

## Evidence retention

Retain the assertion record at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-assertion.json`. The record contains the command, working directory, exit status, stdout, stderr, and elapsed time. Platform: native test host (Windows). Evaluator: 0.22.1.
