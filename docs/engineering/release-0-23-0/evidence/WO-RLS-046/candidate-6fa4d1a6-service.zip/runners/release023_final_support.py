"""Use existing qualification helpers against the final committed candidate."""
from pathlib import Path
import sys
W=Path(__file__).parent
mode=sys.argv.pop(1)
if mode=='sdist':
    name='release023_054_windows_sdist.py'
    text=(W/name).read_text().replace('release023-054-qualification','release023-final').replace('release023-054-execution/candidate-head.txt','release023-final/candidate-source.txt')
elif mode=='sandbox':
    name='release023_050_sandbox.py'
    text=(W/name).read_text().replace('release023-050-qualification','release023-final').replace('release023-050-execution/candidate-head.txt','release023-final/candidate-source.txt')
    text=text.replace('PORT=18823','PORT=18927').replace("'--restore-port','18724'","'--restore-port','18928'")
else:raise ValueError(mode)
exec(compile(text,str(W/name),'exec'),{'__name__':'__main__','__file__':str(W/name)})
