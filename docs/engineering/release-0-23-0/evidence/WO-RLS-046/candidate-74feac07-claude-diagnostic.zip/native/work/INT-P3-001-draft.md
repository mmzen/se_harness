+++
id = "INT-P3-001"
type = "intent"
title = "Adapt the rehearsal greeting for a new audience"
status = "draft"
owners = ["test-owner"]
created = "2026-10-13"
updated = "2026-10-13"
outcome = "A new audience receives a greeting adapted from the existing rehearsal greeting."

[relations]
+++

# Adapt the rehearsal greeting for a new audience

## In plain words

The current rehearsal greeting serves one audience. A different audience needs an adapted form of that greeting.

## Problem

The rehearsal fixture provides a single fixed greeting, `Hello rehearsal`, governed by INT-P3-900 and REQ-P3-900. Only the original test operator audience uses this greeting. A new audience needs a greeting adapted to their context, and no such adapted greeting exists today.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| The new audience observes an adapted greeting | not measured | The adapted greeting is returned when requested | Operator inspection after delivery |

## Not this

- Changes to the existing `Hello rehearsal` greeting or its governing definitions (INT-P3-900, REQ-P3-900)
- Real product, release or deployment decisions
- External effects beyond the greeting adaptation
