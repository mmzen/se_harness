+++
id = "VER-P3-901"
type = "verification"
title = "Alternative independent greeting assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative independent greeting assertion

## Independence

The expected result `Hello rehearsal` derives from REQ-P3-900 acceptance criterion and SPEC-P3-900 rule P3-GREET-900. The pass condition is fixed by those definitions. No candidate output contributes to the expected value.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Exact greeting equality assertion via `assert-greeting` | `greeting()` returns exactly `Hello rehearsal` |

## Acceptance scenarios

Run the `assert-greeting` execution tool against the source fixture at the verified candidate commit. Before execution, confirm that `src/greeting.py` matches the selected `greeting_sha256` (`dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`).

The assertion tool calls `greeting()` once and compares the returned string to `Hello rehearsal` using exact equality. Exit 0 with `exact greeting passed` in stdout records a pass. A nonzero exit records a failure.

Platform: native test host via `client_python`.
Evaluator: se_harness 0.22.1 (`archive_sha256: cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`).

## Evidence retention

Retain the `assert-greeting` record at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-assertion.json`. The record contains the exact command, exit status, stdout, stderr and elapsed time.

## Residual uncertainty

This contract covers only the exact string equality check for REQ-P3-900. It does not assert return type, encoding or performance characteristics beyond what the requirement states.
