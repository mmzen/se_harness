"""Print only visible instruction reads and explanations, never private reasoning."""
import json,sys
from pathlib import Path
trial=sys.argv[1] if sys.argv[1].startswith('codex-reads') else sys.argv[1]+'-full'
root=Path(__file__).parent/'release023-054-qualification/native'/trial/'native'
found=[]; first=None
for line,raw in enumerate((root/'events.jsonl').read_text(encoding='utf-8').splitlines(),1):
    try:e=json.loads(raw)
    except ValueError:continue
    item=e.get('item',{})
    if e.get('type')=='item.completed':
        if item.get('type')=='agent_message' and first is None:first={'line':line,'text':item.get('text')}
        if item.get('type')=='command_execution' and any(x in item.get('command','') for x in ('COMMUNICATION','hosted-context.md')):
            found.append({'line':line,'command':item['command'],'exit':item.get('exit_code'),'output':item.get('aggregated_output','')[:550]})
    for b in e.get('message',{}).get('content',[]) if isinstance(e.get('message'),dict) else []:
        if not isinstance(b,dict):continue
        if b.get('type')=='text' and e.get('type')=='assistant' and first is None:first={'line':line,'text':b.get('text')}
        if b.get('type')=='tool_use' and b.get('name') in ('Read','Bash') and any(x in json.dumps(b.get('input',{})) for x in ('COMMUNICATION','hosted-context.md')):
            found.append({'line':line,'id':b.get('id'),'name':b.get('name'),'input':b.get('input')})
print(json.dumps({'first_explanation':first,'selected_reads':[x for x in found if x['line']<80]},indent=2))
