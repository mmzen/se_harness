"""Retain this candidate's independent semantic review, with observed limits."""
import hashlib,json,sys
from pathlib import Path
W=Path(__file__).parent;Q=W/'release023-054-qualification/native';host=sys.argv[1];r=Q/(host+'-full');n=r/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
mechanical=load(r/'mechanical-assessment.json')
assert host=='claude','Codex review must also assess its separate read case before final verdict.'
calls={};completed=[];first=None
for line,raw in enumerate((n/'events.jsonl').read_text().splitlines(),1):
    try:e=json.loads(raw)
    except ValueError:continue
    for b in e.get('message',{}).get('content',[]) if isinstance(e.get('message'),dict) else []:
        if not isinstance(b,dict):continue
        if b.get('type')=='tool_use':calls[b['id']]={'line':line,'name':b['name'],'input':b.get('input',{})}
        if b.get('type')=='text' and e.get('type')=='assistant' and first is None:first=line
        if b.get('type')=='tool_result' and b.get('tool_use_id') in calls:
            c=calls[b['tool_use_id']]
            if c['name']=='Bash' and 'instructions --section "docs/engineering/harness/COMMUNICATION.md#communication"' in c['input'].get('command',''):
                assert not b.get('is_error');completed.append({'call_line':c['line'],'result_line':line,'call_id':b['tool_use_id']})
assert completed and all(x['result_line']<first for x in completed)
cases={
 'NQ-01':{'result':'pass','review':'The exact hosted setup pointer and released communication section were read before the first explanation. Selected client/governor, fixture and test-only scope were identified; explicit reads are not automatic delivery.'},
 'NQ-02':{'result':'pass','review':'New definitions state the operator, missing test record, exact greeting, independently fixed expectation, bounded work and evidence. The observed assertion and candidate digest support the synthetic decisions. Eleven accepted operations replay successfully; definition approval was batched. Imported records remain unchanged.'},
 'NQ-03':{'result':'pass','review':'Stale project/preview and actual QGP-G4I-PATHS refusals precede valid recovery. The initial protected-file refusal is separately identified. Eight observations cover all seven native MCP tools and match independent HTTP at the exact selected views.'},
 'NQ-04':{'result':'pass','review':'The dropped risk-apply reply was treated as unknown. Original-key lookup and identical resubmission retain the same receipt and versions; a changed request under the key is refused.'},
 'NQ-05':{'result':'pass','review':'Both native exports independently reconstruct and replay. VREC and RLS preserve original test candidate c50c47cad7dba77ac7098e37ce10a8fc79e44480. The report identifies all nine visible failed tool results, synthetic actor labels, no real external action, and reviewer replay as unperformed at native completion. The reviewer subsequently performed it.'}
}
result={'candidate':mechanical['candidate'],'host':host,'overall':'pass','cases':cases,'communication':{'completed_reads':completed,'first_explanation_line':first},'mechanical_assessment_sha256':hashlib.sha256((r/'mechanical-assessment.json').read_bytes()).hexdigest(),'reviewed_native_report_sha256':hashlib.sha256((n/'work/native-report.md').read_bytes()).hexdigest(),'metrics':mechanical['metrics'],'limits':['These results cover the exact CLI/model/component combination and private test projects only. Codex Windows desktop is deferred and unverified.','The assertion checks equality once and records no separate Python version or type assertion; the report states these limits.','The report transcribes MCP highlights, while full native event responses and independent HTTP evidence retain the complete originals.','The generated VREC/RLS prose still describes preparation; machine lifecycle fields and replay establish the later test states.','Lineage returned an empty complete result for the selected REQ; no stronger semantic coverage is inferred.','No real verification, release, publication, deployment, authority cutover or risk acceptance is supplied by synthetic test decisions.'],'simplicity_review':'The production change is one pointer to the existing canonical communication policy. It adds no duplicated policy or mechanism. Full workflow duration and large context remain visible; this correction establishes discovery order, not a performance improvement.'}
with (r/'independent-assessment.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'host':host,'overall':result['overall'],'communication':result['communication']}))
