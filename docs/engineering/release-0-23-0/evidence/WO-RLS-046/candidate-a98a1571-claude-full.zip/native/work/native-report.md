# Native hosted-workflow qualification report (Claude, test copy)

Test data only. Supplied actors (`test-owner`, `test-executor`, `quality-owner`,
`release-owner`) are synthetic labels, not human decisions. Git remains
authoritative. No push, tag creation, publication, installation or deployment occurred.

## Outcome

The fixture `greeting()` returns exactly `Hello rehearsal`. The local assertion passed
(exit 0, stdout `exact greeting passed`). The test lifecycle completed through
work completion, test verification and test release:
INT/CAP/REQ/SPEC/VER/REL-P3-001 `approved`, WO-P3-001 `implemented`,
RISK-P3-001 `mitigating` with DEC-P3-001 `decided` (option `mitigate`), VREC-P3-001 `verified`,
RLS-P3-001 `released`. Two immutable snapshots were exported. Independent replay
of the exports with released 0.22.1 was **not performed** by this agent; it is left to the reviewer.

Final evaluator next step (RLS-P3-001): `PROC-EXTERNAL-ACTION` / `STEP-EXTERNAL-ACTION`,
decision right `DR-EXTERNAL-ACTION`. No external action is authorized, so the agent stopped there.

## Identities

| Item | Value | Source |
| --- | --- | --- |
| Project | `2d6f28b6-3de1-45bc-942f-02e603a60a7c` | selection.json, status |
| Endpoint | `http://127.0.0.1:64833` | selection.json |
| Client | 0.23.0, wheel `f2fbc394…3e16` (matches combination) | `identity`, records/01-status.json |
| Service evaluator (governor) | 0.22.1, archive `cb35c3c4…3053`, payload `0e7b7c2b…e7ff` | records/01-status.json |
| Plugin-bundled evaluator | 0.23.0 (distinct; not used as governor) | combination.json |
| Authority mode / test copy | `sandbox-projection` / `true`, schema_revision 2 | records/01-status.json |
| Source fixture commit S | `5820415917e87b64d80bad2f7c39c6d18d692829` | source-manifest.json |
| Import baseline | `…a007ff7e…` (project v1) | records/02-import |
| Draft context | `2b7aadad-921c-4fb0-9462-0fdac78bfcae` (anchored on imported WO-P3-900; WO-P3-900 not modified) | records/04-draft-open |
| Retained handoff base (first accepted lifecycle mutation input head) | `c4b1a8ea0f585e480de415604f1cdb485b7ff928` | records/29-operation-lookup `/provenance/input_git_head` |
| Test candidate P (VREC/RLS) | `57b661eb7dcfad07a24e25c840295f48fcfe9181` | records/50-capture-apply, records/58-prepare-release-apply |
| Implementation candidate C | `a98a1571292f5bbf34cd2c7cff0af793d00fa12f` (selection `qualification_candidate`); not verified by any test record | selection.json, `identity` |

Context reporting is separate from gates. The checkpoint-free `check`/`work-context` results report
`compliance.status: not_assessable`. Passed gates come only from transition previews (`compliance.status: pass`):
records/22, 27, 32, 35, 47, 52, 55, 59.

## Content readiness (drafting)

Inputs came from task.md. Outcome and success: lines 10-12. Scope limits: lines 16 and 55-56. Synthetic confirmation: lines 49-56.
All required intent/requirement/spec/verification/work-order checklist items were supported, so the drafts are **Complete**.
REL-P3-001 was intentionally completed only after VREC-P3-001 was verified. Its
`candidate_commit` was taken from that VREC. Its `previous_release_tag` placeholder was removed
because no prior test release exists. Draft validation: records/12-18, 23, 54 (`admissible`, empty `incomplete`).
Draft validation is not a content review. The agent reviewed each saved revision against the type checklist.
Validation in records/20-validate: `valid: true`, 0 errors. One advisory remains on imported SPEC-P3-900 (W-AUT-022); it is unrelated and not modified.

## Lifecycle (accepted writes)

| Step | Key | Receipt | Project v |
| --- | --- | --- | --- |
| Approve INT/CAP/REQ/SPEC/VER (test-owner) | cf-lc-approve-defs-apply-003 | sha256:6c777532… | 17→18 |
| Approve WO-P3-001 (test-owner) | cf-lc-approve-wo-apply-001 | sha256:5734140f… | 18→19 |
| Start WO (test-executor) | cf-lc-start-apply-001 | sha256:35dedc92… | 19→20 |
| Raise RISK-P3-001 + DEC-P3-001 | cf-lc-raise-risk-apply-001 | sha256:669fee69… | 20→21 |
| Decide DEC-P3-001 mitigate, mitigated_by WO-P3-001 (test-owner) | cf-lc-decide-apply-001 | sha256:7eee2ac5… | 21→22 |
| Handoff (evidence/WO-P3-001/greeting-assertion.json) | cf-lc-handoff-apply-001 | sha256:552f4a7f… | 22→23 |
| Complete WO → implemented (test-executor) | cf-lc-complete-apply-001 | sha256:362ace22… | 23→24 |
| Capture VREC-P3-001 (owner quality-owner) | cf-lc-capture-apply-001 | sha256:0ad5fd3b… | 24→25 |
| VREC → verified (quality-owner) | cf-lc-verify-apply-001 | sha256:084d1388… | 25→26 |
| Approve REL-P3-001 (test-owner) | cf-lc-approve-rel-apply-001 | sha256:c78c10a0… | 27→28 |
| Prepare RLS-P3-001 v0.0.1 (owner release-owner, tag value `v0.0.1` recorded only) | cf-lc-prepare-release-apply-001 | sha256:3aa09963… | 28→29 |
| RLS → released (release-owner) | cf-lc-release-apply-001 | sha256:68dc05fc… | 29→30 |

The draft writes are import, draft-open, 7 creates and 10 revisions (records/02, 04-18, 23, 54).

## Required cases

| Case | Outcome | Evidence | Limit |
| --- | --- | --- | --- |
| Local assertion | PASS: exit 0, `exact greeting passed`, 0.087 s | work/evidence/greeting-assertion.json | Native Windows host via client_python; no Python version recorded; no type assertion |
| Stale preview after selected draft changed | Preview D1 `sha256:f0ae4039…` taken at 16/14. INT-P3-001 was then revised (16→17). Applying D1 unchanged was refused with 409 `HAG_REMOTE_STALE_PROJECT`. D1 at current 17/15 was refused with 409 `HAG_REMOTE_STALE_PREVIEW`. Status still showed v17. A fresh preview then succeeded. | records/22, 23-revise-int-2, 24, 25, 26-status-after-stale.json, 27, 28 | none |
| Out-of-scope handoff refusal | (a) `docs/engineering/lifecycle-pilot/notes/…` was refused by the service guard with 422 `HAG_REMOTE_PROTECTED_FIELD`, which is not a scope check. (b) `notes/greeting-assertion.json` was refused by the released evaluator: `QGP-G4I-PATHS: WEX201: changed path is outside execution scope`; next step: escalate under `DR-REMEDIATION-SCOPE`. Both returned `files: []` with no receipt. The next accepted op began at v22, so neither had an effect. The valid in-scope handoff was then accepted. | records/43, 44, 45, 46 | Scope was not expanded |
| Uncertain reply recovery | The apply of `cf-lc-approve-defs-apply-003` returned transport `unknown` (exit 2). Lookup of the original key showed `accepted`, receipt `sha256:6c777532…`, 17→18. | records/28-approve-defs-apply, 29-operation-lookup | none |
| Identical retry, no duplicate | Same request file and key returned the same receipt `sha256:6c777532…` and the same baseline. The next new op had project before=18. | requests/28-approve-defs-apply.json, records/30, 33 | none |
| Changed request under accepted key | Only the INT reason changed. Refused with 409 `HAG_REMOTE_KEY_REUSE`, no receipt. | requests/31-…json, records/31 | none |
| Risk + paired decision | RISK-P3-001 raised and threatens WO-P3-001. DEC-P3-001 decided `mitigate` by test-owner, `mitigated_by` WO-P3-001, and the risk moved to `mitigating`. Mitigation check: candidate P binds src/greeting.py sha256 `dcbd486a…`, the asserted snapshot. | records/38, 39, 40, 42, 49 (`/provenance/candidates`) | Risk acceptance was not supplied and not used |
| 7 MCP tools | work-context, check, lineage, impact, compare, revision and cypher were all `complete: true` with `continuation: null` on the explicit baseline views | work/mcp/mcp-reads.json | Responses were inline; the host saved no file. Key fields were transcribed. The revision document digest was not recomputed from the MCP bytes; it matches the export manifest value `a24c5baa…`. |
| Exports | Earlier: baseline `…87779dd1…` (VREC verified), snapshot `sha256:6f63c407…`, 26 files, head `f4a97fd8…` → work/exports/earlier-vrec-verified. Later: baseline `…4752d8eb…` (RLS released), snapshot `sha256:524d2306…`, 28 files, head `7f194cc1…`, bundle sha `142e09f7…` → work/exports/later-rls-released. Both manifests bind test candidate P. | records/62, 63; exports/*/manifest.json | `independent_replay: not yet performed`. The agent did not list destinations for an `.incomplete` marker; the client reported a completed save. |

## Failures, refusals and interventions (all observed)

1. `draft-open` with new `WO-P3-001` was refused with 404 `HAG_REMOTE_UNKNOWN_IDENTITY`, because the context must anchor on a baseline WO. The agent reopened on imported WO-P3-900 as an anchor only (records/03, 04).
2. The planned refusals listed above (stale ×2, key reuse, protected path, evaluator scope).
3. Transport `unknown` on records/28 (the endpoint dropped an accepted reply). It was recovered by lookup.
4. The first export call returned `not_sent` ("Create the export parent directory first"). The agent created `work/exports/README.md` with native Write and resent the same request (records/61, 62).
5. The first `observations` call used a record path outside the workspace. The helper refused locally with `ValueError`. This was an agent error with no effect.
No host permission denials occurred. No permissions were changed.

## File-read trace

The complete captured trace is in `work/records/64-observations` (`/observed_content_reads`, `/file_reads`), covering 186 native calls (count complete).
Reads were triggered in this order. task.md and selection.json came from the CLAUDE.md instruction.
Next were setup SKILL.md and hosted-context.md, then native-tools.md and native-execution-tools.md.
For drafting: hosted-drafts.md, then released DRAFT_DEFINITIONS (sha `a2041b84…`), DEFINE_CHANGE, ARTIFACTS, DEFINITION_LINKS,
ARTIFACT_AUTHORING, DRAFT_WORK_ORDERS and WORK_AND_EVIDENCE (`892ec2fe…`).
For the lifecycle: hosted-test-lifecycle.md, then server/README.md, lifecycle-v2.md, lifecycle-v2.json, harnessctl-reference.md (`6d4cec5c…`, concise hosted authoring),
AUTHORIZE_WORK (`991b526d…`), AUTHORITY (`da7202bf…`), EXECUTE_WORK (`f094e7bc…`), RISKS_AND_DECISIONS (`8dbc5fb4…`),
VERIFY_OUTCOME (`84686ea5…`), RELEASE (`ce700f8f…`), COMMUNICATION and RESULTS.
For evidence: hosted-evidence.md. For reads: hosted-reads.md, then hosted-artifact-graph.md (`b46e64c3…`, physical representation, before Cypher), then export-v2.json.
Source manifest (`137d1a6c…`), fixture src/greeting.py and the 7 imported `-900` records were read as permitted inputs.
No walkthroughs, test drivers, fixture-authoring functions or earlier transcripts were read.
Calls after the observation snapshot are excluded from it: the writes of this report and of native-observations.json.

## Uncertainties

- The out-of-scope case needed two attempts; the first was refused for a different reason (protected path).
- The MCP response bytes were not saved by the host.
- No independent replay or byte comparison of the exported bundles was performed.
