```toml
artifact = "WO-P3-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "fd15cd6e63c2cfaf8749f293e9933b387476a040ef2c47caa76ab80a2aa552d0"
rebound_at = "2026-10-16T08:10:40Z"
```

# WO-P3-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
