Export destinations for the native qualification run (test copy only).

- earlier-vrec-verified/: baseline se-harness-artifact-baseline/v1:sha256:87779dd1da86f58531fe654e7290b2677e67793788b2b379150f44e2aac4d8db (after VREC-P3-001 verified, before RLS-P3-001)
- later-rls-released/: baseline se-harness-artifact-baseline/v1:sha256:4752d8eb2432d5dac54fdbf9e75ff6b9070aedfbc23e6cf37a9012469dbea22e (after RLS-P3-001 released)

This file was written only to create the parent directory required by the client.
