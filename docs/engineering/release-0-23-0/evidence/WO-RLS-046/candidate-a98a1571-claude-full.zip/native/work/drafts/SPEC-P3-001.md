+++
id = "SPEC-P3-001"
type = "specification"
title = "Fixed rehearsal greeting value"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
# What an implementation must do to conform. The Explorer shows this summary under the title.
contract = "The fixture function greeting() returns the exact string Hello rehearsal."

[relations]
specifies = ["REQ-P3-001"]
+++

# Specification: Fixed rehearsal greeting value

Synthetic rehearsal input supplied by the test owner. This is not a real human decision.

## In plain words

The function `greeting()` in `src/greeting.py` gives back the fixed text
`Hello rehearsal`.

## Scope

This specification governs the return value of `greeting()` in the fixture
`src/greeting.py`. It leaves the check method and evidence to VER-P3-001.

## Terms

- **Fixture greeting.** The function `greeting()` defined in `src/greeting.py` of the test source snapshot.

## Rules

**LPG-GREET-001.** The implementation MUST return the string `Hello rehearsal` exactly, with no leading or trailing characters, when `greeting()` is called with no arguments.

## Failure behaviour

| Trigger | Response | Diagnostic |
| --- | --- | --- |
| `greeting()` returns any value other than `Hello rehearsal` | The implementation does not conform to LPG-GREET-001 | `none` |

## Examples

**Given** the fixture `src/greeting.py`, **when** the operator calls `greeting()`, **then** the result equals `Hello rehearsal` (LPG-GREET-001).

## Coverage

| Requirement | Rules |
| --- | --- |
| `REQ-P3-001` | LPG-GREET-001 |

## Not decided here

- The internal form of the function body; any body that satisfies LPG-GREET-001 conforms.
