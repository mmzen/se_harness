+++
id = "RISK-P3-001"
type = "risk"
title = "Assertion evidence may not represent the test candidate"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
description = "The exact-greeting assertion runs locally on the native host against the source snapshot, not inside the hosted test candidate. If src/greeting.py in the candidate differed from the asserted snapshot, the retained evidence would not prove REQ-P3-001 for that candidate."
action = "Execute WO-P3-001 without any source change, assert only the snapshot whose SHA-256 matches dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1, and confirm in the VREC review that src/greeting.py is unchanged."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-001"]
mitigated_by = ["WO-P3-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-16T08:08:46Z"
reason = "Synthetic test-owner input: choose mitigation for the test risk using WO-P3-001 (no source change; digest-checked assertion; VREC review confirms src/greeting.py unchanged)."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-16T08:07:56Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-16T08:08:46Z"
decided_by = "test-owner"
reason = "Synthetic test-owner input: choose mitigation for the test risk using WO-P3-001 (no source change; digest-checked assertion; VREC review confirms src/greeting.py unchanged)."
+++

# Risk: Assertion evidence may not represent the test candidate

## Description

The exact-greeting assertion runs locally on the native host against the source snapshot, not inside the hosted test candidate. If src/greeting.py in the candidate differed from the asserted snapshot, the retained evidence would not prove REQ-P3-001 for that candidate.

## Next action

Execute WO-P3-001 without any source change, assert only the snapshot whose SHA-256 matches dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1, and confirm in the VREC review that src/greeting.py is unchanged.
