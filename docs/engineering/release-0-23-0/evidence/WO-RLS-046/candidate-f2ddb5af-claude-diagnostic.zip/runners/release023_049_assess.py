"""Independent saved-byte readback and semantic assessment of the completed trial."""
import base64,hashlib,json,time,tomllib,urllib.request
import hag_efficiency_plan as p
O=p.W/'release023-049-qualification/native/claude-diagnostic';N=O/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(name,value):
    with (O/name).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
s=load(O/'selection.json');token=next(x['token'] for x in load(O/'credentials.json')['principals'] if x['id']=='operator')
def read(label,request):
    if (O/(label+'.json')).exists():
        retained=load(O/(label+'.json'));assert retained['request']==request and retained['http_status']==200
        value=retained['response'];raw=base64.b64decode(value['data']['document_base64'],validate=True)
        assert sha(raw)==value['data']['envelope']['document_sha256']
        return value,raw
    url=s['endpoint']+'/v1/projects/'+s['project_id']+'/reads/revision'
    raw=json.dumps(request,separators=(',',':')).encode();start=time.monotonic()
    with urllib.request.urlopen(urllib.request.Request(url,data=raw,headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'},method='POST'),timeout=30) as response:
        code=response.status;body=response.read();v=json.loads(body)
    put(label+'.json',{'method':'POST','url':url,'request':request,'http_status':code,'response':v,'response_sha256':sha(body),'seconds':time.monotonic()-start,'credential':'Authorization omitted; private operator only'})
    assert code==200 and v['complete']
    content=base64.b64decode(v['data']['document_base64'],validate=True)
    assert sha(content)==v['data']['envelope']['document_sha256']
    return v,content
observed=load(O/'independent-observations.json');assert observed['project_version']==4
request=load(N/'work/read-intent-001.evidence/1-request.json')
v,content=read('independent-authored-revision',request)
assert content==(N/'work/INT-P3-001.md').read_bytes()==(N/'work/read-intent-001.evidence/1-document-1.md').read_bytes()
assert tomllib.loads(content.decode().split('+++')[1])['status']=='draft'
imported=load(N/'work/import-001.evidence/1-response.json');baseline=imported['view']['baseline_id'];originals=[]
for item in imported['affected_artifacts']:
    req={'schema':'se-harness-graph-read/v1','operation':'revision','project_id':s['project_id'],'view':{'kind':'baseline','baseline_id':baseline},**item,'budget':{'rows':1,'bytes':2097152,'depth':0}}
    result,raw=read('independent-imported-'+item['artifact_id'],req)
    path=result['data']['envelope']['original_path'];assert raw==(N/'inputs/source'/path).read_bytes()
    originals.append({'artifact_id':item['artifact_id'],'path':path,'sha256':sha(raw),'matches_original':True})
summary=load(O/'mechanical-summary.json')
assert not summary['native_failures'] and not any(x['is_error'] for x in observed['results'])
assert observed['host_boundary_unchanged'] and not observed['input_changes']
assessment={
 'candidate':s['qualification_candidate'],'case':'EFF-04A2','trial':'claude-diagnostic','overall':'fail',
 'method':'Independent semantic review against the accepted VER-HAG-008 EFF-04A2 criterion, complete paired native call/result capture, separate authenticated saved-revision reads and original-byte comparison. Assertions bind observations; keywords do not determine the content verdict.',
 'blocking_findings':[
  {'id':'R23-NATIVE-003','criterion':'Missing-input handling and honest content readiness',
   'finding':'The agent did not ask for the missing agreed operational outcome or success measure. It authored a solution description, left the specific audience and observation point unidentified, then explicitly called the draft complete in both the saved report and final reply. VER-HAG-008 explicitly rejects a complete-content claim for this request.',
   'evidence':['native/work/INT-P3-001.md: outcome and Success measures','native/work/native-report.md: Content readiness','independent-observations.json: final_reply'],
   'effect':'Stop further native repetitions on this candidate. Qualification and aggregate verification remain pending.'},
  {'id':'R23-NATIVE-004','criterion':'Do not invent the user problem, operational benefit or requested limits',
   'finding':'The draft presents the lack of an adaptable greeting as an operator problem without an agreed operational reason. It also excludes changes to existing greeting behavior and limits the initiative to one additional audience, neither of which the request established. The saved report inaccurately says there are no unsupported claims or constraints.',
   'evidence':['native/work/INT-P3-001.md: Problem and Not this','native/work/native-report.md: Independent content findings'],
   'effect':'A structurally admissible draft is not accepted content; preserve the actual saved bytes and failed review.'}
 ],
 'passed_observations':['Exactly one new intent remained draft with the selected domain and synthetic owner.','All seven imported artifact revisions match their original staged bytes.','No failed native tool or command result appears in the complete capture. The saved report and final reply correctly report no failures or denials.','Saved revision bytes match the authored file and separate readback.','Staged inputs and inspected host settings are unchanged.'],
 'reporting_limit':'Four hosted mutations were accepted: import, draft-open, create-artifact and revise-artifact. The saved report says three while listing all four receipts. The final reply is not a clarification-only report; the saved-report route applies.',
 'service_result':'Draft admission returned zero structural errors/incomplete fields and content_review=not_assessed. This is not a service admission defect and does not establish semantic completeness.',
 'previous_candidate':'The earlier candidate remains failed. The earlier failed-Read reporting symptom did not recur here, but one failure-free trial does not prove reliable reporting after errors.',
 'readback':{'document_sha256':sha(content),'project_version':observed['project_version'],'imported_artifacts':originals},
 'metrics':observed['metrics'],
 'limits':['This failed missing-input diagnostic is not completed authoring success.','Its performance is reported separately; EFF-04B positive-case goals are not applied to it.','No further native tests or retry on this candidate is authorized by the stop rule.','No criterion waiver, human verification or release decision is inferred.'],
 'next':'Retain and publish this failed assessment. A changed correction requires a new reviewed scope/candidate; do not retry until a pass or supply expected answers.'
}
put('independent-assessment.json',assessment)
print(json.dumps({'overall':assessment['overall'],'findings':[x['id'] for x in assessment['blocking_findings']],'imported_bytes_confirmed':len(originals),'metrics':assessment['metrics']}))
