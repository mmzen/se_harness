+++
id = "INT-P3-001"
type = "intent"
title = "Adapt the rehearsal greeting for a new audience"
status = "draft"
owners = ["test-owner"]
created = "2026-10-13"
updated = "2026-10-13"
outcome = "An operator can obtain a greeting adapted for an audience beyond the current rehearsal audience."

[relations]
+++

# Intent: Adapt the rehearsal greeting for a new audience

## In plain words

The greeting system currently returns a single fixed greeting for the rehearsal audience. A different audience needs an adapted greeting from the same system.

## Problem

The function `greeting()` returns only `Hello rehearsal`. An operator who needs to address a different audience has no supported way to obtain an adapted greeting. The specific new audience is not yet identified.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| An adapted greeting is available for the identified new audience | Only the rehearsal greeting exists | The greeting system returns the correct adapted greeting when requested | Not yet defined; the specific audience and observation point are not identified |

## Not this

- Changes to the existing `Hello rehearsal` greeting or its current behavior
- Support for more than one additional audience in this initiative
- Approval, release or lifecycle decisions beyond this draft
- External integrations, deployment or infrastructure changes
