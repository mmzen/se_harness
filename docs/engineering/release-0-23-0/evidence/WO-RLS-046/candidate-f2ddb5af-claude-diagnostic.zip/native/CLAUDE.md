# Disposable qualification task inputs

Reuse the complete task entry already supplied in context. Only if it
is lost or truncated, read `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\release023-049-qualification\native\claude-diagnostic\native\task.md` to recover it.
For a truncated read, use read-text with --offset 0 --limit 4096;
continue from next_offset until complete is true.
These files retain the task, selected inputs and tool boundary.
Use the selected candidate plugin skills and their required references for the workflow.
This file supplies no lifecycle procedure or new permission.

Use this exact existing approved shell prefix (keep -I unquoted):

```text
"C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe" -I "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-049-qualification/native/claude-diagnostic/native/inputs/native_call.py"
```

Use one helper command per Bash call. Do not add a pipeline, a second
command (including echo), a shell wrapper or arbitrary Python. The tool
result already reports the exit status. Use native file tools or the
tool index's bounded file-read operation, including for retained results.
