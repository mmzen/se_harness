+++
id = "VER-P3-001"
type = "verification"
title = "Plan an independent exact greeting check"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"

[relations]
verifies = ["REQ-P3-900"]
+++

# Plan an independent exact greeting check

This synthetic draft supplies an alternative plan for an independent reviewer of the existing fixture. It does not replace VER-P3-900 or change any imported record. It records planned verification only.

## Independence

REQ-P3-900, Acceptance, requires exactly `Hello rehearsal`. SPEC-P3-900, rule P3-GREET-900, specifies the same string. These definitions establish the expected result before execution; candidate output does not establish it. The reviewer compares the retained assertion result with this expectation. The owner `test-owner` is a synthetic label, not a recorded human decision.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-900 | test | One invocation of the selected fixture's `greeting()` through `assert-greeting`; retain the record at the full path in Evidence retention. | On the native Windows test host, the helper's equality assertion compares the result with `Hello rehearsal`; exit status is 0 and stdout contains `exact greeting passed`. |

## Acceptance scenarios

Input: `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-053-qualification/native/codex-positive1/native/inputs/source/src/greeting.py`, from source fixture commit `5820415917e87b64d80bad2f7c39c6d18d692829`. The selected manifest is `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-053-qualification/native/codex-positive1/native/inputs/source-manifest.json`.

The helper requires the source SHA-256 to match `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1` before execution. A mismatch stops the check and establishes no pass.

Platform and evaluator: the assertion runs locally on the native Windows test host through `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-053-qualification/client/Scripts/python.exe`. The selected `native_call.py` helper evaluates equality once. The Linux service runtime is not the test runtime. Released evaluator `0.22.1` evaluates draft shape and links, not the greeting assertion.

When execution is separately authorized, perform this one planned PowerShell command:

```powershell
& 'C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe' -I 'C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-053-qualification/native/codex-positive1/native/inputs/native_call.py' assert-greeting --record 'C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-053-qualification/native/codex-positive1/native/work/WO-P3-900/assertion.json'
```

The reviewer inspects the retained exit status, stdout and stderr. A failing equality assertion returns nonzero and fails this case. A refusal or execution error leaves the requirement unassessed; retain the diagnostic. An absent success marker does not meet the pass condition. Use a new evidence path if the proposed path is already occupied.

## Evidence retention

Proposed full record path: `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-053-qualification/native/codex-positive1/native/work/WO-P3-900/assertion.json`.

Retain the helper's exact command, working directory, exit status, stdout, stderr and elapsed time, including associated capture files. Retain the selected source manifest and the source commit and digest above as input identity references. The record does not supply a Python version or commit-bound verification. This path is a plan; no assertion evidence has been produced by this authoring exercise.

## Residual uncertainty

The fixture source has been inspected, but this plan has not been executed. The helper makes one equality assertion and no separate type assertion. This plan covers the requested exact greeting outcome; it does not assess external effects or other quality properties. It grants no execution, approval or verification decision. One check covers the single requested outcome without duplicate tests.
