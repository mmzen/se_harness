Seven actual hag MCP tools returned complete responses for the selected test project. Each response has `complete=true`, `continuation=null`, and `unresolved_references=[]`. The requests and full MCP results are retained in [mcp-calls.json](work/mcp-calls.json); separate request files support the reviewer's exact HTTP replay. All seven saved request objects were read back and matched their submitted arguments.

Project: `d4535864-f1f5-4ab6-b56e-5afa90d4dee0`, endpoint `http://127.0.0.1:18969`. All returned views match their requests. All responses identify the selected evaluator 0.22.1, observed project version 29, `test_copy=true`, and `authority="rehearsal-only; Git remains authoritative"`. [Service status](work/status.json.stdout.txt) matches the supplied combination's component identities, protocols and client wheel digest. The candidate plugin evaluator 0.23.0 remains distinct from the service evaluator 0.22.1.

| Read | Observed result and exact evidence | Remaining limit |
| --- | --- | --- |
| work-context | [Result](work/01-work-context.mcp-result.json), decoded `content[0].text`: `data` contains 5 governing artifacts, 11 declared paths, 2 dependencies and 1 relevant decision for WO-P3-901. | `evaluator_output.compliance.status="not_assessable"`; `gates=[]`; `scope.change_set_complete=false`. |
| compare | [Result](work/02-compare.mcp-result.json), `data.changes`: 11 bindings, comprising 8 revisions changed and 3 artifacts added; 18 added and 11 removed resolved relation triples. | Relation triples include endpoint revision identities; counts do not mean 18 new logical relation kinds. |
| revision | [Result](work/03-revision.mcp-result.json), `data`: exact VREC-P3-901 revision `sha256:9a72e48f9ce1c7041513c25aea007a5affa33f3a1b273a2531cfd7e3ff671f0a`. Its 1,858 decoded UTF-8 bytes match document SHA-256 `296c2a54d0bdba07b166f8616922e2d03d712961d71d1ce23d9999f82bf9c26f`. [Byte check](work/revision-byte-verification.json). | The document's recorded test claims and synthetic actor labels provide no new assurance. |
| impact | [Result](work/04-impact.mcp-result.json), `data`: REQ-P3-901 has 8 reverse-reachable artifacts and 16 relations. | Declared graph relations at the selected later baseline only. |
| lineage | [Result](work/05-lineage.mcp-result.json), `data`: WO-P3-901 connects to 4 artifacts through 6 verification/evidence relations. | Recorded links only; evidence was not independently replayed. |
| check | [Result](work/06-check.mcp-result.json), `evaluator_output`: checkpoint-free operation completed, with no scoped or repository blockers. | Compliance is `not_assessable`, not passed gates. Full evaluator output is retained unchanged inside the MCP result. |
| cypher | [Request](work/07-cypher.request.json), [result](work/07-cypher.mcp-result.json), `data.rows`: earlier-view WO-P3-901 declares implements → REQ-P3-901, specifications → SPEC-P3-901, verification → VER-P3-901. | Only this admitted parameterized relationship query was exercised. |

The immutable baseline selections remain:

- Earlier B: `se-harness-artifact-baseline/v1:sha256:dbd4f49951685024e56c038cb53f15b9ac6f6319cee03d5516aff4c20e3cc4f6`.
- Later B: `se-harness-artifact-baseline/v1:sha256:17c078d59648c09c805a0882d251faaeafc1cdfe39ced7ddf80031930a8ab3ac`.
- Source fixture commit S: `5820415917e87b64d80bad2f7c39c6d18d692829`, from selection and returned provenance.
- Test Git candidate P: `d54f90430f866ab38456e2fa95941f3db563ca1a`, from the decoded VREC's `commit`.
- Actual implementation candidate C: `bb0890045f462343ecae66ca30b20b06cf6e8ae6`, from selection and helper identity.

The reads used the candidate [setup](inputs/plugin/verity-plane/skills/setup/SKILL.md) hosted route, [harness-orient](inputs/plugin/verity-plane/skills/harness-orient/SKILL.md), and [observed-result reporting guidance](inputs/plugin/verity-plane/skills/evidence/references/hosted-evidence.md). The complete physical-representation and bounded-Cypher sections were read before constructing the query. Read triggers, file hashes, offsets, selected schema pointers and exact helper outputs are retained in [instruction-read-trace.json](work/instruction-read-trace.json) and [native-observations.json](native-observations.json). Reading only applicable sections is recorded as such; no full read of the entire product guide or schema is claimed.

The [captured observation snapshot](work/observations-snapshot.json) reports one native failure entry. The setup read first used an invalid 16,000-character limit; the helper refused that argument and the 4,096-character retry returned the complete file. This was an argument error, not a permission denial. An overbroad tool-metadata discovery output was also truncated; a later hag-only discovery supplied the seven callable schemas. None of the seven graph responses was truncated or refused.

There is a procedure timing gap: my first English update preceded the setup and COMMUNICATION reads. I read the complete COMMUNICATION section before service status and all graph calls. That later read does not establish compliance before the first update. Instruction delivery was explicit; this test does not establish automatic startup delivery.

The snapshot is `in_progress` and `native_call_count_complete=false`; it excludes later evidence checks and report writes. The retained seven MCP responses contain zero tool errors and zero service refusals. These are counts for those seven calls, not a total-session error claim. Detailed snapshot limits and subsequent evidence-file hashes are in native-observations.json.

No service mutation or imported/real repository edit was made. Writes are confined to work/ and the two requested report files. No lifecycle, assurance, release or whole-work qualification completion is claimed. Independent HTTP replay remains with the reviewer; database-side read-only enforcement remains deferred under RISK-HAG-001.
