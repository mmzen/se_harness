"""Fresh native qualification using the accepted tasks and existing test driver."""
import copy,hashlib,ipaddress,json,os,secrets,shutil,socket,subprocess,sys,tarfile,uuid,zipfile
from pathlib import Path
import hag_efficiency_plan as p

Q=p.W/'release023-054-qualification';P=Q/'combination';R=p.R
C=(p.W/'release023-054-execution/candidate-head.txt').read_text().strip()
DOCKER=Path(r'C:\Users\mathi\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe')
os.environ['PATH']=str(DOCKER.parent)+os.pathsep+os.environ['PATH']
IMAGE='hag-release023:'+C[:12]
mode,host,case=sys.argv[1:4]
assert host in ('claude','codex') and case in ('diagnostic','positive1','positive2','positive3','full')
oldgroup='f' if case=='full' else 'e';oldtrial='421' if case=='full' else '431' if case=='diagnostic' else '432'
OLD=p.W/'h44'/oldgroup/(host+'-'+oldtrial)
O=Q/'native'/(host+'-'+case);N=O/'native';I=N/'inputs'
p.O=O
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
canon=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def put(f,value):
    f.parent.mkdir(parents=True,exist_ok=True)
    assert not f.exists(),f
    f.write_bytes(value if isinstance(value,bytes) else (value if isinstance(value,str) else json.dumps(value,indent=2)+'\n').encode())
def run(label,args,allowed=(0,)):
    result=p.run(label,args,cwd=p.W,allowed=allowed)
    r=load(O/(label+'.json'))
    print(json.dumps({'label':label,'exit':r['exit'],'seconds':r['elapsed_seconds'],'stdout_tail':r['stdout'][-900:],'stderr_tail':r['stderr'][-600:]}),flush=True)
    return result
def relocated(text):
    for old,new in [(str(OLD/'native'),str(N)),((OLD/'native').as_posix(),N.as_posix()),
                    ((OLD/'native').as_posix().replace('C:','//c'),N.as_posix().replace('C:','//c'))]:
        text=text.replace(old,new)
    return text
def env():
    s=load(O/'selection.json')
    os.environ.update(HAG_SERVICE_IMAGE=IMAGE,HAG_HTTP_PORT=str(s['port']),HAG_SOURCE_VOLUME=s['source_volume'],
        HAG_CONFIG_DIRECTORY=str(O/'configuration'),HAG_CREDENTIAL_FILE=str(O/'credentials.json'))
    return s
def dc(*args):
    return [DOCKER,'compose','-p',load(O/'selection.json')['compose_project'],'-f',P/'candidate-source/server/compose.yaml','-f',O/'network.json',*args]
def boundary():
    paths=[Path(x) for x in ('C:/Users/mathi/.codex/config.toml','C:/Users/mathi/.claude/settings.json','C:/Users/mathi/.claude/plugins/installed_plugins.json')]
    return {'settings':[{'path':str(f),'sha256':sha(f.read_bytes()) if f.exists() else None} for f in paths],
        'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
        'repository_status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)}
if mode=='prepare':
    O.mkdir(parents=True,exist_ok=False);I.mkdir(parents=True);(N/'work').mkdir()
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==C
    config=load(P/'configuration/config.json');config['test_copy']=True;config['project_id']=str(uuid.uuid4())
    extra=['se-harness-lifecycle-command/v2','se-harness-lifecycle-result/v2','se-harness-lifecycle-export/v2','se-harness-graph-read/v2']
    config['protocols']+=extra;config['components']['protocols']=config['protocols'];config['components']['schema_revision']=2
    config['components']['deployment_sha256']=sha(canon({'configuration':{k:v for k,v in config.items() if k!='components'},
        'compose_sha256':sha((P/'candidate-source/server/compose.yaml').read_bytes())}))
    put(O/'configuration/config.json',canon(config));put(I/'configuration.json',canon(config))
    combination={'payload':config['components'],'combination_id':'sha256:'+sha(b'se-harness-hosted-combination/v1\n'+canon(config['components']))}
    put(O/'combination.json',combination);put(I/'combination.json',combination)
    credentials=load(P/'credentials.json')
    for principal in credentials['principals']:principal.update(projects=[config['project_id']],token=secrets.token_urlsafe(32))
    put(O/'credentials.json',credentials)
    inventory=load(OLD/'native/inputs/inventory.json')['files']; old_hashes={x['relative']:x['sha256'] for x in inventory}
    for prefix in ('source','schemas','released-resources'):
        for f in (OLD/'native/inputs'/prefix).rglob('*'):
            if not f.is_file():continue
            relative=f.relative_to(OLD/'native/inputs').as_posix();assert sha(f.read_bytes())==old_hashes[relative],relative
            put(I/relative,f.read_bytes())
    put(I/'source-manifest.json',(OLD/'native/inputs/source-manifest.json').read_bytes())
    source_manifest=load(I/'source-manifest.json');files=[]
    for f in sorted((I/'source').rglob('*')):
        if f.is_file():
            raw=f.read_bytes();files.append({'path':f.relative_to(I/'source').as_posix(),'bytes':len(raw),
                'sha256':sha(raw),'blob_oid':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()})
    bypath={x['path']:x for x in files}
    for entry in source_manifest['artifacts']:
        actual=bypath[entry['path']]
        assert actual['bytes']==entry['bytes'] and actual['sha256']==entry['raw_sha256'] and actual['blob_oid']==entry['blob_oid']
    put(O/'source-inventory.json',{'source':source_manifest['source'],'files':files})
    with tarfile.open(O/'source.tar','x') as archive:
        archive.add(I/'source',arcname='source');archive.add(I/'source-manifest.json',arcname='source-manifest.json');archive.add(O/'source-inventory.json',arcname='source-inventory.json')
    archive=P/'plugin'/('verity-plane-'+host+'.zip')
    assert sha(archive.read_bytes())==config['components']['plugins'][host]['archive_sha256']
    with zipfile.ZipFile(archive) as z:
        assert all(not Path(x.filename).is_absolute() and '..' not in Path(x.filename).parts for x in z.infolist())
        z.extractall(I/'plugin')
    wheel=Q/'bundle/se_harness-0.23.0-py3-none-any.whl';put(I/wheel.name,wheel.read_bytes())
    for name in ('native_call.py','summarize_native.py','native-tools.md','native-execution-tools.md'):
        put(I/name,subprocess.check_output(['git','show',C+':tests/hosted_artifact_graph/'+name],cwd=R))
    for name in ('server/contracts/remote-v1.json','server/contracts/read-v1.json','server/contracts/lifecycle-v2.json','server/contracts/lifecycle-v2.md','server/contracts/export-v2.json','server/README.md','docs/notes/harnessctl-reference.md','docs/notes/hosted-artifact-graph.md'):
        put(I/'reference'/name,subprocess.check_output(['git','show',C+':'+name],cwd=R))
    put(I/'evaluator.json',config['components']['evaluator'])
    for operation in ('read','operation','create-artifact','revise-artifact'):
        put(I/'client-help'/f'{operation}.txt',subprocess.check_output([Q/'client/Scripts/python.exe','-I','-m','se_harness','remote',operation,'--help'],cwd=p.W))
    put(I/'client-help.txt',subprocess.check_output([Q/'client/Scripts/python.exe','-I','-m','se_harness','remote','--help'],cwd=p.W))
    baseport=18960+(['diagnostic','positive1','positive2','positive3','full'].index(case))*2+(host=='codex')
    with socket.socket() as probe:probe.bind(('127.0.0.1',baseport))
    project='r2354-'+host+'-'+case
    selection=load(OLD/'native-selection.json')
    def relocate(v):
        if isinstance(v,str):return relocated(v)
        if isinstance(v,list):return [relocate(x) for x in v]
        if isinstance(v,dict):return {k:relocate(x) for k,x in v.items()}
        return v
    selection=relocate(selection)
    selection.update(project_id=config['project_id'],endpoint=f'http://127.0.0.1:{baseport}',port=baseport,
        client_python=str(Q/'client/Scripts/python.exe'),client_wheel=str(I/wheel.name),
        compose_project=project,source_volume=project+'-source',qualification_candidate=C)
    put(O/'selection.json',selection);put(O/'native-selection.json',selection)
    put(I/'inventory.json',{'files':[{'path':str(f),'relative':f.relative_to(I).as_posix(),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())}
        for f in sorted(I.rglob('*')) if f.is_file()]})
    task=relocated((OLD/'native-task.md').read_text())
    put(O/'native-task.md',task)
    rules=relocate(load(OLD/'permissions.json'));put(O/'permissions.json',rules)
    assert str(OLD/'native') not in json.dumps(selection) and (OLD/'native').as_posix() not in json.dumps(rules)
    put(O/'stage-evidence.json',{'candidate':C,'previous_trial':str(OLD),'source_identity':source_manifest['source'],
        'source_files_validated':len(files),'task_sha256':sha(task.encode()),'permissions_sha256':sha((O/'permissions.json').read_bytes()),
        'plugin_archive_sha256':sha(archive.read_bytes()),'input_inventory_sha256':sha((I/'inventory.json').read_bytes()),
        'method':'Same accepted native task and permissions, relocated to new disposable paths; exact release-staged plugin/client and fresh project. No prior results or completed requests supplied.'})
    print(json.dumps({'prepared':str(O),'case':case,'host':host,'source_files':len(files)}))
elif mode=='start':
    selection=env();ids=subprocess.check_output([DOCKER,'network','ls','-q'],text=True).split()
    networks=run('networks',[DOCKER,'network','inspect',*ids]);used=[ipaddress.ip_network(v['Subnet']) for n in networks for v in n.get('IPAM',{}).get('Config',[]) or [] if 'Subnet' in v]
    available=[str(s) for s in ipaddress.ip_network('10.233.64.0/20').subnets(new_prefix=28) if not any(s.overlaps(x) for x in used)][:2];assert len(available)==2
    put(O/'network.json',{'networks':{k:{'ipam':{'config':[{'subnet':s}]}} for k,s in zip(('private','client'),available)}})
    run('volume-absent',[DOCKER,'volume','inspect',selection['source_volume']],allowed=(1,))
    run('volume-create',[DOCKER,'volume','create',selection['source_volume']])
    run('source-stage',[DOCKER,'run','--rm','--network','none','--mount',f'type=bind,src={O},dst=/input,readonly',
        '--mount',f'type=volume,src={selection["source_volume"]},dst=/source','--entrypoint','tar',IMAGE,'-xf','/input/source.tar','-C','/source'])
    run('up-graph',dc('up','-d','graph'))
    run('connection',dc('run','--rm','-T','--entrypoint','python','service','-c','from neo4j import GraphDatabase; d=GraphDatabase.driver("bolt://graph:7687"); d.verify_connectivity(); print("ready"); d.close()'))
    run('init',dc('run','--rm','service','init'));run('up-service',dc('up','-d','service'))
    run('ready',dc('exec','-T','service','harness-hosted','ready'))
elif mode=='resume-start':
    # A read-only connectivity probe ran before Memgraph was listening.
    # Preserve that failure and resume only initialization not yet invoked.
    assert load(O/'connection.json')['exit']==1
    assert not (O/'init.json').exists() and not (O/'up-service.json').exists()
    env()
    run('connection-02',dc('run','--rm','-T','--entrypoint','python','service','-c','from neo4j import GraphDatabase; d=GraphDatabase.driver("bolt://graph:7687"); d.verify_connectivity(); print("ready"); d.close()'))
    run('init',dc('run','--rm','service','init'));run('up-service',dc('up','-d','service'))
    run('ready',dc('exec','-T','service','harness-hosted','ready'))
elif mode=='run':
    # This first use is the approved diagnostic; later cases need its independent pass.
    if case!='diagnostic':raise RuntimeError('Confirm the diagnostic independent assessment before enabling later cases')
    executable=Path(r'C:\Users\mathi\.local\bin\claude.exe') if host=='claude' else Path(r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\2e5e00daee91c61d\codex.exe')
    if host!='claude':raise RuntimeError('Run the exact supported Codex boundary probes first')
    probe=run('model-probe',[executable,'-p','--no-session-persistence','--tools','','--model','claude-opus-4-6','--output-format','json',
        'Authorized provider availability probe. Reply exactly AUTH_OK. Use no tools, read no files and change nothing.'])
    assert probe.get('result','').strip()=='AUTH_OK' and not probe.get('is_error')
    sections=['docs/engineering/harness/COMMUNICATION.md#communication','docs/engineering/harness/DEFINE_CHANGE.md#read-this-when',
        'docs/engineering/harness/DEFINE_CHANGE.md#before-this-action','docs/engineering/harness/DEFINE_CHANGE.md#describe-the-intended-outcome','docs/engineering/ARTIFACT_AUTHORING.md#intent']
    args=[sys.executable,'-X','utf8','-B',R/'tests/hosted_artifact_graph/qualify_agents.py','--host',host,'--executable',executable,
        '--selection',O/'native-selection.json','--credentials',O/'credentials.json','--task',O/'native-task.md','--output',N,
        '--prepared-inputs','--timeout','1200','--complete-inputs','--permission-settings',O/'permissions.json','--model','claude-opus-4-6']
    for section in sections:args+=['--instruction-section',section]
    put(O/'boundary-before-native.json',boundary())
    try:code=subprocess.call(list(map(str,args)),cwd=p.W)
    finally:put(O/'boundary-after-native.json',boundary())
    raise SystemExit(code)
else:raise ValueError(mode)
