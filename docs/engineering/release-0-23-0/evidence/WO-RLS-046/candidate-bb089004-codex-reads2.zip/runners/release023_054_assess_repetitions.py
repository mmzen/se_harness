"""Record independent content review of the two fresh C54 Claude repetitions."""
import json,tomllib
from pathlib import Path
Q=Path(__file__).parent/'release023-054-qualification/native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
for case,count in [('claude-positive2',11),('claude-positive3',12)]:
    O=Q/case;o=load(O/'independent-observations.json');s=load(O/'mechanical-summary.json');r=load(O/'independent-readback.json')
    meta=tomllib.loads((O/'independent-document.md').read_text().split('+++')[1])
    assert meta['status']=='draft' and meta['relations']['verifies']==['REQ-P3-900']
    assert len(o['calls'])==len(o['results'])==count and s['native_call_count_complete']
    assert {v['id'] for v in o['calls']}=={v['id'] for v in o['results']}
    assert not s['native_failures'] and all(not v['is_error'] for v in o['results'])
    assert r['exact_saved_document'] and len(r['baseline_records'])==7
    assert o['project_version']==4 and not o['input_changes'] and o['host_boundary_unchanged']
    assert (O/'prelaunch-task.txt').read_bytes()==(O/'native/task.md').read_bytes()
    mutations=[x for x in r['operations'] if x['outcome']=='accepted'];assert len(mutations)==4
    a={'candidate':o['candidate'],'case':'EFF-04B','trial':case,'overall':'pass',
       'method':'Independent review of separately read saved document, source requirement/specification, paired native calls, report and final reply. Seven separate baseline reads establish unchanged imported bytes.',
       'content_result':'The new draft links REQ-P3-900 and derives Hello rehearsal independently from the requirement and specification. It contains a requirement/method/check/pass-condition matrix, the existing assert-greeting invocation with a source digest precondition, and a concrete work-order evidence path and retained fields. It remains draft and does not claim an executed test or human verification. No empty optional headings remain.',
       'reporting_result':'All paired calls succeeded. Independent reads confirm the exact saved document, project version four and unchanged imported records. The report retains the existing W-AUT-022 advisory and records each actual operation; no failure or denied operation is omitted.',
       'observations':[], 'artifact':r['artifact'],'document_sha256':r['document_sha256'],
       'exact_saved_document':True,'baseline_records_unchanged':7,'accepted_project_mutations':4,
       'operations':r['operations'],'metrics':o['metrics'],'goals':s['goals'],
       'evidence':['independent-document.md','independent-readback.json','independent-revision.json','independent-observations.json','mechanical-summary.json','native/work/native-report.md'],
       'limits':['Complete applicable instructions were already in the bounded initial input; the separate full test must establish pointer-based communication discovery.','No desktop, full lifecycle or release-readiness verdict.']}
    if case.endswith('2'):
        a['observations']=['The plan treats a nonzero assertion exit as failure. A source-digest mismatch prevents the planned assertion and is not proof of a product mismatch; its explicit pre-execution digest check preserves that prerequisite.','The residual-uncertainty section accurately distinguishes equality from a separate type assertion; it does not add a type acceptance criterion.']
    else:
        a['observations']=['The report groups three artifact writes separately from one draft-open context projection. Draft-open also mutates project state: the correct total is four accepted project mutations. Its evidence table and body explicitly retain that operation; the final short summary alone is incomplete.','The statement that all operations have accepted outcomes is imprecise for reads. All mutation receipts are accepted and the actual reads succeeded; this is recorded separately from the content verdict.']
    with (O/'independent-assessment.json').open('x',encoding='utf-8') as f:json.dump(a,f,indent=2);f.write('\n')
    print(json.dumps({'case':case,'overall':a['overall'],'metrics':o['metrics'],'goals':s['goals']}))
