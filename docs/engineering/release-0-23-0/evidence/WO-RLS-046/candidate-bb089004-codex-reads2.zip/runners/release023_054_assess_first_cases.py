"""Retain independent reviews of the observed Codex diagnostic and Claude draft."""
import json,tomllib
from pathlib import Path
Q=Path(__file__).parent/'release023-054-qualification'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
O=Q/'native/codex-diagnostic';o=load(O/'independent-observations.json');s=load(O/'mechanical-summary.json')
assert o['project_version']==0 and o['host_boundary_unchanged'] and not o['input_changes']
assert len(o['calls'])==7 and not s['native_failures'] and not s['native_call_count_complete']
assert (O/'native/work/native-report.md').is_file()
a={'candidate':o['candidate'],'case':'EFF-04A2','trial':O.name,'overall':'pass',
 'method':'Independent review of the saved report, final reply, all visible command/file-change items, separately read service status and original fixture.',
 'content_result':'The report distinguishes existing definitions from the new audience request. It asks who is affected, the present problem, what the adaptation should help the audience do or understand, the smallest useful improvement and an observable success condition. It marks the proposed outcome unconfirmed and makes no hosted definition or new authority claim.',
 'reporting_result':'Codex retained the required report because capture completeness is unavailable. It states no observed failed calls, without claiming exhaustive zero failures. The seven visible items consist of six successful read-only/helper commands and the report write. Independent service version remains zero and staged bytes are unchanged.',
 'observations':['Native capture gives a lower bound of seven items, not an exact call count or token metric.','The host emitted its prefer_mxc warning, ignored icon-path warnings, an unsupported PowerShell snapshot warning and a post-turn legacy_notify filename-too-long warning. Preserve these host diagnostics separately; they are not hidden as successful delivery checks. No global setting was changed to suppress them.'],
 'metrics':o['metrics'],'observed_tool_items_lower_bound':7,'goals':s['goals'],'report_branch':'saved report; complete capture unavailable',
 'evidence':['independent-observations.json','independent-status.json','mechanical-summary.json','native/events.jsonl','native/work/native-report.md'],
 'limits':['Negative diagnostic only; positive authoring, full lifecycle and delivery remain separate.','No desktop, release or actual verification decision.']}
with (O/'independent-assessment.json').open('x',encoding='utf-8') as f:json.dump(a,f,indent=2);f.write('\n')
O=Q/'native/claude-positive1';o=load(O/'independent-observations.json');s=load(O/'mechanical-summary.json');r=load(O/'independent-readback.json')
meta=tomllib.loads((O/'independent-document.md').read_text().split('+++')[1])
assert meta['status']=='draft' and meta['relations']['verifies']==['REQ-P3-900']
assert s['native_call_count_complete'] and len(o['calls'])==len(o['results'])==13
assert not s['native_failures'] and all(not x['is_error'] for x in o['results'])
assert r['exact_saved_document'] and len(r['baseline_records'])==7
assert o['project_version']==4 and not o['input_changes'] and o['host_boundary_unchanged']
assert (O/'prelaunch-task.txt').read_bytes()==(O/'native/task.md').read_bytes()
a={'candidate':o['candidate'],'case':'EFF-04B','trial':O.name,'overall':'pass',
 'method':'Independent semantic review of separately read saved bytes, original definitions, report and paired tool evidence; seven independent baseline reads establish unchanged imported Git blobs.',
 'content_result':'VER-P3-901 links REQ-P3-900, derives Hello rehearsal from accepted definitions, and contains the requirement/method/case/pass-condition matrix. Its planned assert-greeting check accurately describes the existing digest guard, single exact equality call, zero exit and expected success text. The evidence plan names a concrete work-order-relative destination. Optional headings without content are absent.',
 'reporting_result':'The draft remains draft. The final explicitly says no test was executed and no verification is claimed. Four accepted project mutations and two reads are correctly distinguished. The report retains the imported W-AUT-022 advisory. All captured calls succeeded; no denied, failed or uncertain command was omitted.',
 'observations':['The report uses accepted outcomes loosely for all six successful command records; its separate mutation table and final explicitly distinguish four writes from two reads. No extra accepted mutation is claimed.','The check is planned at a future verified candidate; this wording does not establish actual verification of the current source.'],
 'artifact':r['artifact'],'document_sha256':r['document_sha256'],'exact_saved_document':True,'baseline_records_unchanged':7,'final_project_version':4,
 'metrics':o['metrics'],'goals':s['goals'],'operations':r['operations'],
 'evidence':['independent-document.md','independent-readback.json','independent-revision.json','native/work/native-report.md','independent-observations.json','mechanical-summary.json'],
 'limits':['One positive attempt; two more fresh Claude attempts and one Codex attempt remain required.','Duration and context goals missed; call goal met. This is not an isolated performance benchmark.','No full lifecycle, desktop or release-readiness verdict.']}
with (O/'independent-assessment.json').open('x',encoding='utf-8') as f:json.dump(a,f,indent=2);f.write('\n')
print(json.dumps({'codex_diagnostic':'pass','claude_positive1':'pass','positive_metrics':o['metrics'],'goals':s['goals']}))
