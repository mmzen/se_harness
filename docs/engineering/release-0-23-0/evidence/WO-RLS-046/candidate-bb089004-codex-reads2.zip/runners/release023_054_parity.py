"""Independently repeat selected native MCP reads; never mutate projects."""
from pathlib import Path
import sys
W=Path(__file__).parent
source=(W/'hag_native_parity19.py').read_text()
old="O=Path(__file__).resolve().parent/'hag-agent-qualification-execution-20261007'"
assert source.count(old)==1
source=source.replace(old,"O=Path(__file__).resolve().parent/'release023-054-qualification/native'")
old="hosts={'codex':O/'codex/native03','claude':O/'claude/native02/work/sonnet01'}"
assert source.count(old)==1
source=source.replace(old,"hosts={h+'-full':O/(h+'-full')/'native' for h in ('codex','claude')}")
sys.argv=[__file__,'full54']
exec(compile(source,'native-independent-parity54','exec'),{'__file__':__file__,'__name__':'__main__'})
