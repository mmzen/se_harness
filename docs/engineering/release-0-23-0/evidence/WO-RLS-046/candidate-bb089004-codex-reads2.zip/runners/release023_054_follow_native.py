"""Run only the next native cases enabled by retained independent assessments."""
import json,subprocess,sys
from pathlib import Path
import hag_efficiency_plan as p
Q=p.W/'release023-054-qualification'
mode,host,case=sys.argv[1:4]
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
assert load(Q/'native/claude-diagnostic/independent-assessment.json')['overall']=='pass'
if mode!='run':raise ValueError('Preparation and service start use the unchanged initial runner')
if case=='positive1':pass
elif case in ('positive2','positive3'):
    assert host=='claude' and load(Q/'native/claude-positive1/independent-assessment.json')['overall']=='pass'
elif case!='diagnostic':raise ValueError('Full qualification uses its separately reviewed task route')
if host=='codex':
    assert load(Q/f'native/codex-{case}/boundary-probe-assessment.json')['overall']=='pass'
    assert load(Q/'codex-auth/assessment.json')['passed']
    if case=='positive1':
        for x in ('positive1','positive2','positive3'):
            assert load(Q/f'native/claude-{x}/independent-assessment.json')['overall']=='pass'
source=(p.W/'release023_054_native.py').read_text()
start=source.index("    # This first use is the approved diagnostic;")
end=source.index("    sections=",start)
source=source[:start]+'''    executable=Path(r'C:\\Users\\mathi\\.local\\bin\\claude.exe') if host=='claude' else Path(r'C:\\Users\\mathi\\AppData\\Local\\OpenAI\\Codex\\bin\\2e5e00daee91c61d\\codex.exe')
'''+source[end:]
needle="    args=[sys.executable"
idx=source.index(needle)
source=source[:idx]+'''    if case!='diagnostic':
        sections=['docs/engineering/harness/COMMUNICATION.md#communication',
            'docs/engineering/harness/DRAFT_DEFINITIONS.md#read-this-when',
            'docs/engineering/harness/DRAFT_DEFINITIONS.md#before-this-action',
            'docs/engineering/harness/DRAFT_DEFINITIONS.md#define-how-the-result-will-be-verified',
            'docs/engineering/harness/ARTIFACTS.md#artifact-types',
            'docs/engineering/harness/ARTIFACTS.md#artifact-locations',
            'docs/engineering/harness/DEFINITION_LINKS.md#links-between-definitions',
            'docs/engineering/ARTIFACT_AUTHORING.md#design-simplicity',
            'docs/engineering/ARTIFACT_AUTHORING.md#verification']
'''+source[idx:]
source=source.replace("'--complete-inputs','--permission-settings',O/'permissions.json','--model','claude-opus-4-6']", "'--complete-inputs']\n    if host=='claude':args+=['--permission-settings',O/'permissions.json','--model','claude-opus-4-6']\n    else:args+=['--codex-loopback-network']")
exec(compile(source,str(p.W/'release023_054_native.py'),'exec'),{'__name__':'__main__'})
