"""Retain observations for either host; leave the semantic verdict unassigned."""
import base64,hashlib,json,sys,time,urllib.request
from pathlib import Path
import hag_efficiency_plan as p
O=Path(sys.argv[1]).resolve();N=O/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(name,value):
    with (O/name).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
sys.path.insert(0,str(p.R/'tests/hosted_artifact_graph'))
from summarize_native import summarize
summary=summarize(N);put('mechanical-summary.json',summary)
events=[];diagnostics=[]
for i,line in enumerate((N/'events.jsonl').read_text().splitlines(),1):
    try:events.append((i,json.loads(line)))
    except ValueError:diagnostics.append({'line':i,'text':line})
calls=[];results=[];final=[];visible=[]
for line,e in events:
    if e.get('type')=='result':final.append(e.get('result'))
    for b in e.get('message',{}).get('content',[]):
        if b.get('type')=='text':visible.append({'line':line,'text':b['text']})
        if b.get('type')=='tool_use':calls.append({'line':line,'id':b['id'],'tool':b['name'],'input':b['input']})
        if b.get('type')=='tool_result':results.append({'line':line,'id':b['tool_use_id'],'is_error':b.get('is_error',False),'content':b.get('content')})
    if e.get('type')=='item.completed':
        item=e.get('item',{});typ=item.get('type')
        if typ=='agent_message':visible.append({'line':line,'text':item.get('text')})
        if typ in ('command_execution','file_change','mcp_tool_call'):
            calls.append({'line':line,'tool':typ,'item':item})
    if e.get('type') in ('error','turn.failed'):diagnostics.append({'line':line,'event':e})
s=load(O/'selection.json');token=next(x['token'] for x in load(O/'credentials.json')['principals'] if x['id']=='operator')
def read(label,request=None):
    url=s['endpoint']+('/v1/status' if request is None else '/v1/projects/'+s['project_id']+'/reads/revision')
    data=None if request is None else json.dumps(request,separators=(',',':')).encode()
    start=time.monotonic()
    with urllib.request.urlopen(urllib.request.Request(url,data=data,headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'}),timeout=30) as r:code=r.status;raw=r.read();v=json.loads(raw)
    put(label+'.json',{'method':'GET' if request is None else 'POST','url':url,'request':request,'http_status':code,'response':v,'response_sha256':sha(raw),'seconds':time.monotonic()-start,'credential':'Generated private test operator; Authorization omitted.'})
    return v
status=read('independent-status')
changes=[x['relative'] for x in load(N/'inputs/inventory.json')['files'] if not Path(x['path']).is_file() or sha(Path(x['path']).read_bytes())!=x['sha256']]
report=N/'work/native-report.md'
o={'candidate':s['qualification_candidate'],'trial':O.name,'project_version':status['project_version'],'metrics':{k:summary[k] for k in ('wall_seconds','native_calls','model_turns','initial_input_context','peak_input_context')},'input_changes':changes,'host_boundary_unchanged':load(O/'boundary-before-native.json')==load(O/'boundary-after-native.json'),'calls':calls,'results':results,'visible_messages':visible,'final_reply':final[-1] if final else visible[-1]['text'] if visible else None,'report':report.read_text() if report.exists() else None,'diagnostics':diagnostics,'verdict':'not assessed'}
put('independent-observations.json',o)
print(json.dumps({k:v for k,v in o.items() if k not in ('calls','results','visible_messages','report','diagnostics')},indent=2))
print(json.dumps({'failed_calls':summary['native_failures'],'diagnostics':diagnostics},indent=2))
