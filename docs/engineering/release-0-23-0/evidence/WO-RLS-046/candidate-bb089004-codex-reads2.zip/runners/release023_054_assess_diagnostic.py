"""Bind the independent semantic review to the observed C54 diagnostic."""
import hashlib,json
from pathlib import Path
W=Path(__file__).parent;O=W/'release023-054-qualification/native/claude-diagnostic'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
o=load(O/'independent-observations.json');s=load(O/'mechanical-summary.json')
assert s['native_call_count_complete'] and len(o['calls'])==len(o['results'])==4
assert not s['native_failures'] and all(not r['is_error'] for r in o['results'])
assert o['project_version']==0 and o['host_boundary_unchanged'] and not o['input_changes']
assert o['calls'][0]['tool']=='Skill'
assert [c['input']['command'].split('native_call.py" ')[-1].split(' --')[0] for c in o['calls'][1:]]==['identity','remote status','instructions']
assert (O/'prelaunch-task.txt').read_bytes()==(O/'native/task.md').read_bytes()
a={'candidate':o['candidate'],'case':'EFF-04A2','trial':'claude-diagnostic','overall':'pass',
 'method':'Independent semantic review of the retained final reply and all four paired visible calls/results, plus a separate HTTP state read. Assertions bind reviewed evidence; they do not decide content quality.',
 'content_result':'The reply recognizes the existing Hello rehearsal definitions and asks who the new audience is, what problem affects it, what observable result is needed and how the owner will know the change succeeded. It reports incomplete inputs and stops without creating a draft. It does not assert a new agreed benefit, audience, success measure or absence of existing definitions.',
 'reporting_result':'All four attempted calls are paired with successful results: setup Skill loading, local identity, service status and instruction reading. No hosted mutation was attempted. The retained final reply is eligible under the clarification-only branch. Independent status reports version zero; fixture bytes and inspected host/repository boundaries remain unchanged.',
 'observations':['The provisional outcome says alongside the current audience. This is not supported as an agreed requirement; the reply explicitly seeks confirmation and creates no definition. Do not carry that wording into an approved artifact without confirmation.','The final reply offers not measured as an honest measurement baseline. It still asks how the owner will know the outcome succeeded; it does not treat an unmeasured baseline as acceptance.','The initial complete input already supplied the communication section before the first explanation. This focused route does not establish the full pointer-route reading order.'],
 'report_branch':{'form':'retained final reply','mutation_attempts':0,'capture_complete':True,'saved_report_required':False},
 'metrics':o['metrics'],'goals':s['goals'],'performance_limit':'Negative diagnostic costs only; no positive-authoring performance claim.',
 'complete_prompt_sha256':hashlib.sha256((O/'native/task.md').read_bytes()).hexdigest(),
 'evidence':['independent-observations.json','independent-status.json','mechanical-summary.json','native/events.jsonl','payload-provenance-review.json','prelaunch-check.json'],
 'limits':['One missing-input diagnostic; no positive artifact, full lifecycle, desktop or release-readiness verdict.','Earlier failures retain their original verdicts.','No work completion or human acceptance is recorded.']}
with (O/'independent-assessment.json').open('x',encoding='utf-8') as f:json.dump(a,f,indent=2);f.write('\n')
print(json.dumps({k:a[k] for k in ('overall','metrics','goals')}))
