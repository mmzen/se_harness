"""Independent HTTP repeat of the separate native read-only case."""
from pathlib import Path
import sys
W=Path(__file__).parent
case=sys.argv[1] if len(sys.argv)>1 else 'reads';assert case in ('reads','reads2')
s=(W/'hag_native_parity19.py').read_text()
s=s.replace("O=Path(__file__).resolve().parent/'hag-agent-qualification-execution-20261007'","O=Path(__file__).resolve().parent/'release023-054-qualification/native'")
s=s.replace("hosts={'codex':O/'codex/native03','claude':O/'claude/native02/work/sonnet01'}","hosts={'codex-reads':O/'codex-"+case+"/native'}")
s=s.replace("storage='codex-final' if host=='codex-reads' else host","storage='codex-full' if host=='codex-reads' else host")
sys.argv=[__file__,case+'54']
exec(compile(s,'independent-read-case-parity','exec'),{'__file__':__file__,'__name__':'__main__'})
