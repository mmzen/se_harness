"""Retain the independent C54 Codex draft review from actual saved evidence."""
import json,tomllib
from pathlib import Path
O=Path(__file__).parent/'release023-054-qualification/native/codex-positive1'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
o=load(O/'independent-observations.json');s=load(O/'mechanical-summary.json');r=load(O/'independent-readback.json')
m=tomllib.loads((O/'independent-document.md').read_text().split('+++')[1])
assert m['status']=='draft' and m['relations']['verifies']==['REQ-P3-900']
assert r['exact_saved_document'] and len(r['baseline_records'])==7 and o['project_version']==4
assert not o['input_changes'] and o['host_boundary_unchanged'] and not s['native_failures']
assert not s['native_call_count_complete'] and (O/'native/work/native-report.md').exists()
a={'candidate':o['candidate'],'case':'EFF-04B','trial':'codex-positive1','overall':'pass',
 'method':'Independent review of the separately retrieved saved bytes, governing fixture definitions, visible calls, complete saved report and actual receipts. Imported records were checked through seven independent revision reads.',
 'content_result':'The draft has the verifies link, requirement-to-evidence matrix, independent expected literal, exact usable assertion command, source digest precondition, platform and concrete evidence filename. It distinguishes digest refusal from assertion failure, and a planned check from an executed result. The artifact stays draft; imported records and existing verification contract are unchanged.',
 'reporting_result':'The saved report distinguishes accepted mutations, successful reads, incomplete initial template, pre-existing W-AUT-022 advisory and unavailable complete native metrics. Four actual writes and project version four agree with independent readback. No observed failure or denied call is hidden. No independent human verification, actual test execution or publication is claimed.',
 'observations':['Preserve the host prefer_mxc, icon-path, unsupported PowerShell snapshot and legacy_notify filename-length diagnostics separately from executed tool failures.','The full report is required because exact capture completeness is unavailable. Its no-observed-failure claim is explicitly bounded; it does not assert an exhaustive count.'],
 'artifact':r['artifact'],'document_sha256':r['document_sha256'],'exact_saved_document':True,'baseline_records_unchanged':7,
 'accepted_project_mutations':4,'observed_tool_items_lower_bound':len(o['calls']),'metrics':o['metrics'],'goals':s['goals'],
 'evidence':['independent-document.md','independent-readback.json','independent-observations.json','mechanical-summary.json','native/work/native-report.md'],
 'limits':['Duration goal missed; exact call count and context metrics unavailable.','Complete initial instruction content does not prove pointer-based full-run discovery or automatic delivery.','No desktop or release-readiness verdict.']}
with (O/'independent-assessment.json').open('x',encoding='utf-8') as f:json.dump(a,f,indent=2);f.write('\n')
print(json.dumps({'overall':a['overall'],'metrics':o['metrics'],'observed_tool_items_lower_bound':len(o['calls']),'goals':s['goals']}))
