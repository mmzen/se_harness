"""Independent read-only inspection of accepted native mutations and imported bytes."""
import base64,hashlib,json,sys,time,urllib.request
from pathlib import Path
O=Path(sys.argv[1]).resolve();N=O/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(name,v):
    raw=v if isinstance(v,bytes) else (json.dumps(v,indent=2)+'\n').encode()
    with (O/name).open('xb') as f:f.write(raw)
s=load(O/'selection.json')
token=next(x['token'] for x in load(O/'credentials.json')['principals'] if x['id']=='operator')
records=[]
for f in (N/'work').rglob('*'):
    if not f.is_file() or f.stat().st_size>4*1024*1024:continue
    try:
        v=load(f)
        if not isinstance(v,dict) or not {'argv','stdout','exit'}<=v.keys():continue
        response=json.loads(v['stdout'])
        if not isinstance(response,dict):continue
        result=response.get('result',response)
        if not isinstance(result,dict):continue
        records.append((f,v,result))
    except (ValueError,TypeError,UnicodeError):continue
def read(label,result,item):
    request={'schema':'se-harness-graph-read/v1','operation':'revision','project_id':s['project_id'],'view':result['view'],'artifact_id':item['artifact_id'],'revision_id':item['revision_id'],'budget':{'rows':1,'bytes':2097152,'depth':0}}
    url=s['endpoint']+'/v1/projects/'+s['project_id']+'/reads/revision';start=time.monotonic()
    with urllib.request.urlopen(urllib.request.Request(url,data=json.dumps(request,separators=(',',':')).encode(),headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'}),timeout=30) as response:
        raw=response.read();value=json.loads(raw);code=response.status
    put(label+'.json',{'request':request,'url':url,'http_status':code,'response':value,'response_sha256':sha(raw),'seconds':time.monotonic()-start,'credential':'Synthetic private operator; authorization header omitted.'})
    return base64.b64decode(value['data']['document_base64'],validate=True)
imports=[(f,v,r) for f,v,r in records if 'import' in v['argv'] and r.get('outcome')=='accepted']
revisions=[(f,v,r) for f,v,r in records if 'revise-artifact' in v['argv'] and r.get('outcome')=='accepted']
observations={'candidate':s['qualification_candidate'],'trial':O.name,'command_records':len(records),'imports':len(imports),'accepted_revisions':len(revisions),'baseline_records':[],'verdict':'not assessed'}
manifest={x['artifact_id']:x for x in load(N/'inputs/source-manifest.json')['artifacts']}
for _,_,r in imports:
    for item in r['affected_artifacts']:
        key=item['artifact_id'];source=manifest[key];raw=read('independent-baseline-'+key,r,item)
        assert raw==(N/'inputs/source'/source['path']).read_bytes() and sha(raw)==source['raw_sha256']
        observations['baseline_records'].append({'id':key,'revision_id':item['revision_id'],'sha256':sha(raw),'exact_bytes':True})
if revisions:
    f,v,r=max(revisions,key=lambda x:x[2]['versions']['project']['after'])
    assert len(r['affected_artifacts'])==1;item=r['affected_artifacts'][0]
    raw=read('independent-revision',r,item);argv=v['argv']
    submitted=Path(argv[argv.index('--document-file')+1]).read_bytes()
    assert raw==submitted
    put('independent-document.md',raw)
    observations.update(artifact=item,document_sha256=sha(raw),exact_saved_document=True,final_project_version=r['versions']['project']['after'])
observations['operations']=[{'record':f.relative_to(N).as_posix(),'exit':v['exit'],'operation':v['argv'][v['argv'].index('remote')+1] if 'remote' in v['argv'] else None,'outcome':r.get('outcome')} for f,v,r in records]
put('independent-readback.json',observations)
print(json.dumps(observations,indent=2))
