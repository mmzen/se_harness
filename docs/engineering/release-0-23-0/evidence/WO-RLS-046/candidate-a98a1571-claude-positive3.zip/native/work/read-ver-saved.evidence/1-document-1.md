+++
id = "VER-P3-901"
type = "verification"
title = "Alternative independent greeting assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative independent greeting assertion

## Independence

The expected value `Hello rehearsal` derives from REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The assertion does not read, copy or depend on the candidate implementation to determine the expected result.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | `assert-greeting` on native test host | Exit 0 with `exact greeting passed`: the returned string equals `Hello rehearsal`. Platform: native test host via selected `client_python`. Evaluator: 0.22.1. |

## Acceptance scenarios

Run `assert-greeting` through the approved shell prefix on the native test host using the selected `client_python`. Verify that the source fixture digest matches the selected `greeting_sha256` before execution.

**Normal case:** `greeting()` returns the string `Hello rehearsal`. The assertion exits 0 and the record contains `exact greeting passed`.

**Failure case:** `greeting()` returns any other value. The assertion exits nonzero.

## Evidence retention

Retain the `assert-greeting` record at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/alt-assertion.json`. The record contains the exact command, working directory, exit status, stdout, stderr and elapsed time.

## Residual uncertainty

The `assert-greeting` tool does not record a Python version or perform a separate type assertion. It does not create commit-bound verification; the source manifest and commit identity establish the tested input separately.
