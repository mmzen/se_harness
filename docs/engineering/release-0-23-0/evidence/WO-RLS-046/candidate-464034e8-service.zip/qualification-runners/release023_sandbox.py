import hashlib,ipaddress,json,os,shutil,socket,subprocess,sys,tarfile,time
from pathlib import Path
import hag_efficiency_plan as p

p.O=p.W/'release023-qualification';Q=p.O;R=p.R;P=Q/'combination'
C=(p.W/'release023-correction-execution/candidate-head.txt').read_text().strip()
DOCKER=Path(r'C:\Users\mathi\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe')
os.environ['PATH']=str(DOCKER.parent)+os.pathsep+os.environ['PATH']
IMAGE='hag-release023:'+C[:12];PROJECT='hag-release023-'+C[:8];VOLUME=PROJECT+'-source'
PORT=18423
def py(*args):return [sys.executable,'-X','utf8','-B',*args]
def run(label,args,cwd=R,allowed=(0,)):
    result=p.run(label,args,cwd=cwd,allowed=allowed)
    record=json.loads((Q/(label+'.json')).read_text())
    print(json.dumps({'label':label,'exit':record['exit'],'seconds':record['elapsed_seconds'],
        'stdout_tail':record['stdout'][-1800:],'stderr_tail':record['stderr'][-1600:]},indent=2),flush=True)
    return result
def dc(*args):
    return [DOCKER,'compose','-p',PROJECT,'-f',P/'candidate-source/server/compose.yaml','-f',Q/'network.json',*args]
def env():
    os.environ.update(HAG_SERVICE_IMAGE=IMAGE,HAG_HTTP_PORT=str(PORT),HAG_SOURCE_VOLUME=VOLUME,
        HAG_CONFIG_DIRECTORY=str(P/'configuration'),HAG_CREDENTIAL_FILE=str(P/'credentials.json'))
mode=sys.argv[1]
if mode=='source':
    run('historical-source-stage',py('server/scripts/stage.py',R,R/'tests/hosted_artifact_graph/fixtures/reference-manifest.json',Q/'historical-source'))
    with tarfile.open(Q/'historical-source.tar','x') as archive:
        for name in ('source','source-manifest.json','source-inventory.json'):
            archive.add(Q/'historical-source'/name,arcname=name)
    raw=Q/'historical-source.tar'
    (Q/'historical-source-archive.json').write_text(json.dumps({'sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'bytes':raw.stat().st_size})+'\n')
elif mode=='start':
    assert json.loads((P/'combination.json').read_text())['payload']['source']['candidate_commit']==C
    with socket.socket() as probe:probe.bind(('127.0.0.1',PORT))
    ids=subprocess.check_output([DOCKER,'network','ls','-q'],text=True).split()
    networks=run('sandbox-existing-networks',[DOCKER,'network','inspect',*ids])
    used=[ipaddress.ip_network(x['Subnet']) for n in networks for x in (n.get('IPAM',{}).get('Config') or []) if 'Subnet' in x]
    available=[str(s) for s in ipaddress.ip_network('10.233.0.0/16').subnets(new_prefix=28) if not any(s.overlaps(n) for n in used)][:4]
    assert len(available)==4
    for name,pair in (('network.json',available[:2]),('restore-network.json',available[2:])):
        (Q/name).write_text(json.dumps({'networks':{k:{'ipam':{'config':[{'subnet':s}]}} for k,s in zip(('private','client'),pair)}})+'\n')
    run('source-volume-absent',[DOCKER,'volume','inspect',VOLUME],allowed=(1,))
    run('source-volume-create',[DOCKER,'volume','create',VOLUME])
    run('source-volume-populate',[DOCKER,'run','--rm','--network','none','--mount',f'type=bind,src={Q},dst=/input,readonly',
        '--mount',f'type=volume,src={VOLUME},dst=/source','--entrypoint','tar',IMAGE,'-xf','/input/historical-source.tar','-C','/source'])
    env();run('sandbox-up-graph',dc('up','-d','graph'))
    # The health probe is read-only. Initialization is applied exactly once below.
    for attempt in range(30):
        status=run('graph-ready-'+str(attempt),dc('run','--rm','-T','--entrypoint','python','service','-c',
            'from neo4j import GraphDatabase; d=GraphDatabase.driver("bolt://graph:7687"); d.verify_connectivity(); print("graph connection ready"); d.close()'),allowed=(0,1))
        if json.loads((Q/('graph-ready-'+str(attempt)+'.json')).read_text())['exit']==0:break
        time.sleep(1)
    else:raise RuntimeError('Graph did not become ready')
    run('sandbox-init',dc('run','--rm','service','init'))
    run('sandbox-up-service',dc('up','-d','service'))
    run('sandbox-ready',dc('exec','-T','service','harness-hosted','ready'))
    assert json.loads((Q/'client-install.json').read_text())['exit']==0
elif mode=='walkthrough':
    run('client-walkthrough',py('tests/hosted_artifact_graph/qualify_service.py','--client-python',Q/'client/Scripts/python.exe',
        '--client-wheel',Q/'bundle/se_harness-0.23.0-py3-none-any.whl','--configuration',P/'configuration/config.json',
        '--credentials',P/'credentials.json','--source-manifest',Q/'historical-source/source-manifest.json',
        '--scenario-fixture',R/'tests/hosted_artifact_graph/fixtures/scenarios-v1.json','--endpoint',f'http://127.0.0.1:{PORT}','--output',Q/'walkthrough'))
elif mode=='boundaries':
    prior=p.W/'hag-authority38-20261012/claude-341/native/inputs/se_harness-0.22.2-py3-none-any.whl'
    inventory=json.loads((prior.parent/'inventory.json').read_text())
    item=next(x for x in inventory['files'] if x['relative']==prior.name)
    assert hashlib.sha256(prior.read_bytes()).hexdigest()==item['sha256']
    shutil.copyfile(prior,Q/prior.name)
    (Q/'prior-client-binding.json').write_text(json.dumps({'source':str(prior),'inventory':str(prior.parent/'inventory.json'),
        'sha256':item['sha256'],'notice':'Historical actual wheel identity for compatibility admission only; not a new historical-client HTTP qualification.'},indent=2)+'\n')
    env();run('live-boundaries',dc('run','--rm','-T','-v',str(R/'tests/hosted_artifact_graph')+':/tests:ro',
        '-v',str(Q)+':/evidence','--entrypoint','python','service','/tests/qualify_boundaries.py',
        '--walkthrough','/evidence/walkthrough','--output','/evidence/boundaries',
        '--only','compatibility,invalid_and_rights,concurrent,faults,parity,resource_boundaries',
        '--compatibility-client-wheel','/evidence/se_harness-0.22.2-py3-none-any.whl',
        '--compatibility-client-wheel','/evidence/bundle/se_harness-0.23.0-py3-none-any.whl'))
elif mode=='recover':
    env();run('restart-restore',py('server/scripts/qualify.py','recover','--compose',P/'candidate-source/server/compose.yaml',
        '--project',PROJECT,'--output',Q/'recovery','--restore-port','18424','--compose-override',Q/'network.json','--restore-override',Q/'restore-network.json'))
else:raise ValueError(mode)
