+++
id = "RISK-P3-001"
type = "risk"
title = "Tested greeting bytes may differ from the verified test candidate"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
description = "The local assertion runs on the native host against the source fixture src/greeting.py (SHA-256 dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1), while the test VREC binds the disposable test candidate commit. If the candidate's src/greeting.py differs from the tested bytes, the retained assertion would not support the verification and release decisions."
action = "Under WO-P3-001, record the SHA-256 of src/greeting.py in the test candidate and compare it with the tested fixture digest before the VREC decision."
raised_by = "test-owner"

[relations]
threatens = ["WO-P3-001"]
mitigated_by = ["WO-P3-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-16T09:58:07Z"
reason = "Synthetic test-owner input: mitigate RISK-P3-001 through WO-P3-001, which records and compares the src/greeting.py digest in the test candidate before the VREC decision."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-16T09:56:54Z"
decided_by = "test-owner"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-16T09:58:07Z"
decided_by = "test-owner"
reason = "Synthetic test-owner input: mitigate RISK-P3-001 through WO-P3-001, which records and compares the src/greeting.py digest in the test candidate before the VREC decision."
+++

# Risk: Tested greeting bytes may differ from the verified test candidate

## Description

The local assertion runs on the native host against the source fixture src/greeting.py (SHA-256 dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1), while the test VREC binds the disposable test candidate commit. If the candidate's src/greeting.py differs from the tested bytes, the retained assertion would not support the verification and release decisions.

## Next action

Under WO-P3-001, record the SHA-256 of src/greeting.py in the test candidate and compare it with the tested fixture digest before the VREC decision.
