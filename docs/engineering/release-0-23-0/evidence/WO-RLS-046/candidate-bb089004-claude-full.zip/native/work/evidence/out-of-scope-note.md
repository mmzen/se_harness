Synthetic out-of-scope handoff probe for WO-P3-001. Not part of the approved scope.
