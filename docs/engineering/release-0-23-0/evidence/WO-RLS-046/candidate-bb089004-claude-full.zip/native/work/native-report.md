# Native hosted-workflow qualification report (Claude, test copy)

All records here are **test data** in the private hosted test project
`fb7ed09f-02be-4187-9652-17678546f887`. Actor labels (`test-owner`,
`test-executor`, `quality-owner`, `release-owner`) are synthetic task inputs,
not human consent. Git remains authoritative. No push, tag, publication,
installation, deployment or change to a real repository occurred.

## Outcome and required decision

- The full test lifecycle completed for `WO-P3-001`. The final states are:
  INT/CAP/REQ/SPEC/VER/REL-P3-001 `approved`; WO-P3-001 `implemented`;
  VREC-P3-001 `verified`; RLS-P3-001 `released` (test version `0.0.1`);
  DEC-P3-001 `decided` (`mitigate`); RISK-P3-001 `mitigating`.
- Current evaluator step for RLS-P3-001: `PROC-EXTERNAL-ACTION` /
  `STEP-EXTERNAL-ACTION`. The decision right is `DR-EXTERNAL-ACTION` (role:
  accountable external-action owner). The suggested response is "Reuse the
  matching complete-release or external-action authorization for RLS-P3-001;
  request only an uncovered action and target."
  No external action is authorized, so the work stops here. Source:
  `records/L32-rls-release-apply.json.stdout.txt` and the MCP `check` result.
- `greeting()` returns exactly `Hello rehearsal`. The local assertion exited 0
  with stdout `exact greeting passed`. Source: `work/evidence/greeting-assertion.json`,
  retained in the hosted test project at
  `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/greeting-assertion.json`
  (SHA-256 `c00586b9…fa68`).

## Identities (kept distinct)

| Identity | Value | Source |
| --- | --- | --- |
| Selected evaluator (released) | se_harness 0.22.1, archive `cb35c3c4…3053`, payload `0e7b7c2b…e7ff` | `inputs/evaluator.json`; `records/00-status.json` |
| Candidate client | 0.23.0, wheel `fe431265…b519` | `identity`; status `/components/client` |
| Hosted input baseline B (import) | `se-harness-artifact-baseline/v1:sha256:ebd3fb87…75e7` | `records/01-import.json` |
| Source fixture commit S | `5820415917e87b64d80bad2f7c39c6d18d692829` | `inputs/source-manifest.json` |
| Test Git candidate P (VREC/RLS) | `c50c47cad7dba77ac7098e37ce10a8fc79e44480` | `records/L24-capture-apply.json` `/provenance/candidates/0/test_candidate` |
| Actual implementation candidate C | `bb0890045f462343ecae66ca30b20b06cf6e8ae6` (selection `qualification_candidate`; also in `identity`) | `selection.json`; identity output |
| Draft context | `717625d1-0f16-41c0-9376-08f2451dc254` | `records/03-draft-open.json` |
| Handoff base (`from_git`) | `833bbf9ed54cf9513a24703ea7f8aba967f564bc`, the `input_git_head` of the first accepted lifecycle mutation (`nat-l03-raise-risk-apply`) | `records/L04-lookup-raise-risk.json` |

Context reporting is separate from gates. Status reported `ready: true`,
`authority_mode: sandbox-projection`, `test_copy: true` and
`database_read_only_enforcement: "deferred: RISK-HAG-001"`. All component
identities equal `inputs/combination.json`. Status is a context report; it is
not a passed gate.

## Case results

| Case | Outcome | Evidence (path / field) | Remaining limit |
| --- | --- | --- | --- |
| Selection and evaluator identity | Matched | `records/00-status.json` `/components/*` versus `inputs/combination.json` | Status is not a gate |
| Import | accepted, project 0→1 | `records/01-import.json` receipt `9905add9-…` | — |
| Draft-open with new WO ID | refused 404 `HAG_REMOTE_UNKNOWN_IDENTITY` | `records/02-draft-open.json` | The context had to be anchored on imported `WO-P3-900` (`records/03-draft-open.json`); WO-P3-900 itself was never revised or decided |
| Definitions and WO authoring | 7 drafts created and revised, 0 errors, 0 incomplete at final save | `records/04…17-*.json`; drafts in `work/drafts/` | Content review is mine against the released checklists; draft validation does not assess content |
| Input assessment (intent) | Complete | The task supplies the affected user (operator), the success measure (prove exact `Hello rehearsal` with an exported record) and the scope limits; the import shows only draft `-900` records (the present problem) | Baseline `not measured` |
| Risk + paired decision | RISK-P3-001 raised and DEC-P3-001 open; DEC decided `mitigate` by `test-owner`, `mitigated_by` WO-P3-001; RISK → `mitigating` | `records/L04-lookup-raise-risk.json`; `records/L08-decide-apply.json` receipt `sha256:8f869c7e…` | Risk acceptance was not supplied and not used |
| Uncertain reply recovery | Apply `nat-l03-raise-risk-apply` returned transport `unknown` (exit 2); lookup of the same key showed `accepted`, receipt `sha256:463cf08a…`, project 16→17 | `records/L03-raise-risk-apply.json` (stderr); `records/L04-lookup-raise-risk.json` | — |
| Identical retry | Same request file `requests/L03-raise-risk-apply.json`, same key: `accepted`, same receipt `sha256:463cf08a…`, same request digest `sha256:75308d60…`, versions still 16→17 (no duplicate effect) | `records/L05-raise-risk-identical-retry.json` | — |
| Changed request under the accepted key | refused 409 `HAG_REMOTE_KEY_REUSE` ("Operation key has different content."), no receipt | `requests/L06-raise-risk-changed-same-key.json`; `records/L06-raise-risk-changed-same-key.json` | — |
| Stale preview after a selected draft changed | Preview `sha256:d9212f89…` (L09). Then VER-P3-001 was revised (`records/19-revise-ver-2.json`, project 18→19). Apply with the old digest and old versions: refused 409 `HAG_REMOTE_STALE_PROJECT`. Old digest with current versions: refused 409 `HAG_REMOTE_STALE_PREVIEW`. Neither returned a receipt or effect. A fresh preview and apply were then accepted | `records/L10-*.json`, `records/L11-*.json`, `records/L12-*.json`, `records/L13-approve-apply.json` receipt `sha256:d4a07cc3…` | — |
| Approval packet | 6 transitions (INT/CAP/REQ/SPEC/VER/WO → `approved`, actor `test-owner`); all gates `pass` (QG-G1/G2/G3, QGS-ASSURANCE) | `records/L12-approve-preview-2.json` `/evaluator_output/commands/1/result/compliance`; `records/L13-approve-apply.json` | — |
| Start | Preflight `ready: true`; WO → `in_progress` by `test-executor`, receipt `sha256:36c10b49…` | `records/L14-*`, `records/L16-start-apply.json` | — |
| Out-of-scope handoff refusal | First attempt (`.md` under `docs/engineering/lifecycle-pilot/notes/`): service refused 422 `HAG_REMOTE_PROTECTED_FIELD`, "Handoff inputs cannot replace formal or instruction files." This is a protected-file refusal, not a scope refusal. Second attempt (`notes/WO-P3-001-out-of-scope-note.txt`): released evaluator refused (`HAG_REMOTE_EVALUATOR_REFUSED`, 422) with `QGP-G4I-PATHS: WEX201: changed path is outside execution scope: notes/WO-P3-001-out-of-scope-note.txt`; next step "Escalate … under DR-REMEDIATION-SCOPE". Neither attempt returned a receipt or version change | `records/L17-*.json`, `records/L18-*.json` | No scope escalation was requested; the valid handoff omitted the file |
| Valid handoff | accepted, receipt `sha256:2a1c7f66…`. Files: `greeting-assertion.json`, `greeting-digest-comparison.json`, evaluator `WO-P3-001-handoff.md`, `handoff.json` | `records/L19-handoff-preview.json` `/files`; `records/L20-handoff-apply.json` | The assertion record contains Windows host paths |
| Completion | WO → `implemented` by `test-executor`, receipt `sha256:d90006a8…` | `records/L22-complete-apply.json` | — |
| Test VREC | Captured by `quality-owner`; `ready` at P `c50c47ca…`; then `verified` by `quality-owner`, receipt `sha256:b48319e0…` | `records/L24-capture-apply.json` receipt `sha256:ae220e45…`; `records/20-read-vrec.json`; `records/L26-vrec-verify-apply.json` | The VREC binds P, not C |
| RISK-P3-001 mitigation | The P file list shows `src/greeting.py` = `dcbd486a…cecab1`, equal to the tested fixture digest | `records/L24-capture-apply.json` `/provenance/candidates/0/files`; evidence `greeting-digest-comparison.json` | RISK stays `mitigating`; no transition to `mitigated` was attempted |
| REL contract | Completed after verification with `candidate_commit` = P (the verified VREC candidate); `previous_release_tag` removed (no earlier release); approved by `test-owner`, receipt `sha256:fb5dd10c…` | `records/21-revise-rel-2.json`; `records/L28-rel-approve-apply.json` | Removing `previous_release_tag` is my judgment; the evaluator reported no error and no incomplete finding |
| Test RLS | Prepared by `release-owner` (version `0.0.1`, tag label `v0.0.1-test`; no Git tag created), `ready`, receipt `sha256:d89cceb1…`; then `released` by `release-owner`, receipt `sha256:5a9a75c5…` | `records/L30-*.json`, `records/L32-*.json` | Test release record only |
| Exports | Earlier: baseline `…8579587a…` (after start), snapshot `sha256:3b5fa00b…`, 21 files, bundle `0b5261d1…`, head `363dca50…` → `work/exports/earlier-after-start/`. Later: baseline `…43b34ce6…` (after release), snapshot `sha256:8387a4d4…`, 29 files, bundle `496b912f…`, head `37a56b61…`, candidate P bound → `work/exports/later-after-release/` | `records/E02-export-earlier.json`, `records/E03-export-later.json`, each `manifest.json` | Independent replay: **not yet performed** (as reported by the client). The reviewer must replay with released 0.22.1 |
| MCP reads (7 tools) | work-context, check, lineage (×2), impact, revision, compare and cypher all returned `complete: true`, `continuation: null` | `records/M01-mcp-reads.json` | Responses are transcribed; the MCP host did not save the full bodies to files. `lineage` on REQ-P3-001 returned empty artifacts/relations with `complete: true`; I report this as observed and do not interpret it. I did not decode the base64 document from `revision` independently |
| Host permission denial | None observed | `records/90-observations.json` | — |

## Failures and interventions (all retained)

The observations snapshot (`records/90-observations.json`) counts **9 native
tool errors** up to that call. The count measures tool results flagged as errors.
Service refusals inside normal results are not counted there; this run had none.

1. `02-draft-open` refused 404 (new WO ID absent from baseline). Intervention:
   anchored the context on `WO-P3-900`.
2. `L03` transport `unknown`. Recovery: key lookup, then identical retry.
3. `L06` key-reuse refusal (intended).
4. `L10` stale project refusal (intended).
5. `L11` stale preview refusal (intended).
6. `L17` protected-file refusal (unintended path choice; reported as is).
7. `L18` out-of-scope evaluator refusal (intended).
8. `E01` export `not_sent`: the parent `work/exports/` did not exist.
   Intervention: created it with native Write (`work/exports/README.txt`),
   then repeated the export (`E02`).
9. Local helper `read-json` error `JSON pointer does not exist` for
   `/snapshot/candidates/1` in the later manifest. This shows that only one
   candidate entry exists.

Calls after the snapshot (two native Reads/Writes of report files, plus this
report) are not included in its count.

## Uncertainties

- The out-of-scope demonstration needed two attempts; the first exercised a
  different (protected-file) refusal.
- `lineage` on REQ-P3-001 returned empty with `complete: true`; its semantics
  were not investigated further.
- The assertion record has no Python version. The assertion runs on the native
  Windows host through `client_python`, not in the Linux service.
- Independent replay of both exports is unperformed.

## File-read trace

The exact read list with paths and hashes is in `records/90-observations.json`
(`/observed_content_reads` and `/file_reads`). Key triggers: CLAUDE.md →
`task.md` and `selection.json`; task.md → `setup/SKILL.md` → `hosted-context.md`
→ `native-tools.md`, `native-execution-tools.md`; drafting →
`change/references/hosted-drafts.md` and released sections (DEFINE_CHANGE,
DRAFT_DEFINITIONS, ARTIFACTS, DEFINITION_LINKS, ARTIFACT_AUTHORING checklists,
DRAFT_WORK_ORDERS, WORK_AND_EVIDENCE); lifecycle → `hosted-test-lifecycle.md`,
`lifecycle-v2.md` (`9f1c02ef…`), `lifecycle-v2.json` (`be57fc3e…`) and each
action's released section (AUTHORITY, AUTHORIZE_WORK, RISKS_AND_DECISIONS,
EXECUTE_WORK, VERIFY_OUTCOME, RELEASE, RESULTS); reads → `hosted-reads.md`,
`hosted-artifact-graph.md` (`b46e64c3…`) before Cypher; evidence →
`hosted-evidence.md`, `export-v2.json` (`13e9936b…`). The source fixture
`src/greeting.py` (`dcbd486a…`) and the `-900` records were read as permitted
inputs. No walkthroughs, test drivers or earlier transcripts were read.
