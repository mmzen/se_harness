Parent directory for separate test-copy exports. Each export uses its own new subdirectory.
