+++
id = "SPEC-P3-001"
type = "specification"
title = "Exact rehearsal greeting result"
status = "approved"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
# What an implementation must do to conform. The Explorer shows this summary under the title.
contract = "The fixture function greeting() returns exactly the string Hello rehearsal when called with no arguments."

[relations]
specifies = ["REQ-P3-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-16T10:00:04Z"
decided_by = "test-owner"
reason = "Synthetic test-owner input: accept complete test definitions."
+++

# Specification: Exact rehearsal greeting result

Synthetic rehearsal input. This is not a real human decision.

## In plain words

The fixture function `greeting()` in `src/greeting.py` gives back the exact
text `Hello rehearsal`.

## Scope

This specification governs the return value of `greeting()` in the fixture
module `src/greeting.py`. The check method and evidence belong to VER-P3-001.

## Rules

**P3-GREET-001.** The implementation MUST return a value equal to the string
`Hello rehearsal` when `greeting()` is called with no arguments.

**P3-GREET-002.** The implementation MUST NOT return text that differs from
`Hello rehearsal` in characters, case or spacing.

## Failure behaviour

| Trigger | Response | Diagnostic |
| --- | --- | --- |
| `greeting()` returns any other value or raises | The exact-equality check fails | `none` |

## Examples

**Given** the fixture `src/greeting.py`, **when** `greeting()` is called with no
arguments, **then** the result equals `Hello rehearsal` (P3-GREET-001).

**Given** a fixture that returns `Hello Rehearsal`, **when** `greeting()` is
called, **then** the result fails the exact-equality check (P3-GREET-002).

## Coverage

| Requirement | Rules |
| --- | --- |
| `REQ-P3-001` | P3-GREET-001, P3-GREET-002 |

## Not decided here

- The implementation of `greeting()` beyond its return value.
