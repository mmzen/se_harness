```toml
artifact = "WO-P3-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "d53ea54d913d21e3baf9ac16c19795b91c3205301248c6d5789ea331dcb54614"
rebound_at = "2026-10-16T10:04:15Z"
```

# WO-P3-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
