"""Retain an independent review of the observed Claude clarification stop."""
import hashlib,json,sys,time,urllib.request
from pathlib import Path
import hag_efficiency_plan as p

Q=p.W/'release023-qualification';O=Q/'native/claude-diagnostic';N=O/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(name,value):
    with (O/name).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
sys.path.insert(0,str(p.R/'tests/hosted_artifact_graph'))
from summarize_native import summarize
summary=summarize(N)
if (O/'mechanical-summary.json').exists():assert load(O/'mechanical-summary.json')==summary
else:put('mechanical-summary.json',summary)
events=[json.loads(x) for x in (N/'events.jsonl').read_text().splitlines()]
calls=[];results=[];final=[]
for number,event in enumerate(events,1):
    if event.get('type')=='result':final.append(event['result'])
    message=event.get('message',{})
    for b in message.get('content',[]) if isinstance(message,dict) else []:
        if b.get('type')=='tool_use':calls.append({'line':number,'id':b['id'],'tool':b['name'],'input':b['input']})
        if b.get('type')=='tool_result':results.append({'line':number,'id':b['tool_use_id'],'is_error':b.get('is_error',False)})
assert len(calls)==2 and {x['id'] for x in calls}=={x['id'] for x in results}
assert calls[0]['tool']=='Read' and calls[1]['tool']=='Bash'
assert ' remote status --record ' in calls[1]['input']['command']
assert [x['is_error'] for x in results]==[True,False] and len(summary['native_failures'])==1
assert len(final)==1 and summary['native_call_count_complete']
selection=load(O/'selection.json');credentials=load(O/'credentials.json')
token=next(x['token'] for x in credentials['principals'] if x['id']=='operator')
url=selection['endpoint']+'/v1/status'
start=time.monotonic()
with urllib.request.urlopen(urllib.request.Request(url,headers={'Authorization':'Bearer '+token}),timeout=30) as response:
    status=response.status;raw=response.read();value=json.loads(raw)
put('independent-status.json',{'method':'GET','url':url,'http_status':status,'elapsed_seconds':time.monotonic()-start,'response':value,'response_sha256':sha(raw),'credential':'Authorization omitted; private test operator only'})
assert status==200 and value['project_version']==0
changes=[]
for item in load(N/'inputs/inventory.json')['files']:
    f=Path(item['path'])
    if not f.is_file() or sha(f.read_bytes())!=item['sha256']:changes.append(item['relative'])
assert not changes
assert load(O/'boundary-before-native.json')==load(O/'boundary-after-native.json')
assessment={'candidate':selection['qualification_candidate'],'trial':'claude-diagnostic','case':'EFF-04A2','overall':'fail',
 'method':'Independent semantic review of the complete retained reply against VER-HAG-008, with paired call/result inspection and a separate service-state read. Assertions bind observations; they do not grade content by keywords.',
 'content_passes':['Acknowledges the existing greeting and formal definitions.','Identifies the missing audience and asks how the owner will observe success.','Makes no complete-draft claim and performs no hosted mutation.'],
 'blocking_findings':[{'id':'R23-NATIVE-001','criterion':'Missing agreed operational outcome; no invented user problem or benefit',
 'finding':'The reply asks who the new audience is and how success will be observed, but does not ask what problem that audience has or what change in their situation is needed. Instead, its proposed outcome supplies an unsupported reason: the current greeting does not serve this different audience. Calling the statement incomplete does not establish an agreed operational outcome.',
 'evidence':'Final reply: "The adaptation is needed when the current greeting does not serve this different audience." The only two questions ask for audience and success observation.',
 'effect':'The first required Claude diagnostic fails. Stop further native repetitions on this candidate under the complete-input qualification rule; retain all prior results.'},
 {'id':'R23-NATIVE-002','criterion':'Every failed or denied native call must be reported',
 'finding':'The native Read of inputs/selection.json failed because that file does not exist. The final reply nevertheless states "No failures or denials." This independently fails the explicit failure-reporting criterion.',
 'evidence':'Captured event 15 and the retained final reply. The actual selection.json is at the native root, not inputs/.',
 'effect':'Preserve the failed result. A successful status call does not erase the earlier failed read.'}],
 'reporting_result':'Clarification-only final reply is an eligible report location because complete paired capture proves no attempted hosted mutation. Its false zero-failure claim fails the report criterion. The independent project remains version zero.',
 'observations':['The report labels the supplied fixture as imported history although no import occurred; project version zero is retained. It also labels the fixture greeting with the release candidate short SHA, whereas the source manifest retains the separate fixture commit. Neither wording is treated as proof of imported or changed records.'],
 'input_changes':changes,'host_boundary_unchanged':True,'project_version':value['project_version'],
 'calls':calls,'results':results,'final_reply':final[0],
 'metrics':{k:summary[k] for k in ('wall_seconds','native_calls','model_turns','initial_input_context','peak_input_context')},
 'limits':['This is a failed clarification diagnostic, not completed artifact authoring.','EFF-04B performance goals do not grade this diagnostic.','No further native runs, retry with answer hints, criterion waiver, release or human verification is inferred.']}
put('independent-assessment.json',assessment)
print(json.dumps({'overall':assessment['overall'],'finding':'R23-NATIVE-001','project_version':value['project_version'],'metrics':assessment['metrics']}))
