Before your first explanation, apply the supplied sections and read only the applicable plugin instructions and prerequisites still missing from context. Use the existing file tools below. This explicit test setup does not establish automatic startup instruction delivery.

# Inspect the selected hosted test records

You are the independent native agent for the read-only portion of VER-HAG-007
NQ-03. Use the exact test project and two immutable views in C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\release023-054-qualification\native\codex-reads\native\selection.json.
Git remains authoritative; these records and supplied actor labels are test data.
Make no service mutation and do not alter imported or real repository files.

Use the candidate plugin's setup and harness-orient guidance under inputs/plugin.
The operator has already installed the separate candidate client and selected
the service. Do not install, activate, or change the real host plugin.
Read the applicable protocol information under inputs/reference, including
docs/notes/hosted-artifact-graph.md and the read-v1.json schema. These are existing
product instructions. Automatic delivery is outside this case.

Use each of the seven actual hag MCP tools on meaningful selected views:
revision, work-context, compare, impact, lineage, check and cypher. Choose the
requests and query from the product instructions and observed records yourself.
Retain exact requests/results and completeness/continuation flags. Read saved
results if needed and permitted. An attempted or refused read is not a successful
read. Checkpoint-free context does not establish passed gates or authority.

The independent reviewer will repeat your exact read requests through HTTP.
Keep the two baseline selections unchanged. Do not inspect previous sessions,
qualification walkthroughs, or completed request examples. Authentication is
already configured by environment variable; never print its value or inspect
credential files. Keep normal native sandbox/review; stop a permission denial.

Write only under work/ and the two root files native-report.md and
native-observations.json. Record actual read triggers and file hashes, all tool
results and any unresolved gap. Report no lifecycle, assurance, release or
whole-work qualification completion from these reads.


Start instruction discovery at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\release023-054-qualification\native\codex-reads\native\inputs\plugin\verity-plane\skills\setup\SKILL.md`. Follow its route for this selected target. Read current prerequisites before acting; reuse unchanged content already retained in context.


## Codex file discovery

For task recovery after compaction and other file reads, use this approved helper prefix:

```json
["C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe", "-I", "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-054-qualification/native/codex-reads/native/inputs/native_call.py"]
```
Append `read-json ABSOLUTE_FILE` to read selection.json, or `read-text ABSOLUTE_FILE` for an inventoried input or work text file. Use native patch/file tools for writing. This host adaptation replaces only the unavailable native Read route; keep one helper call per invocation, normal permissions, the same selected task and all other restrictions. It supplies no workflow operation, request values, draft or decision.
