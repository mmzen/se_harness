# Focused hosted drafting diagnostic

You are Claude under WO-HAG-011. Work independently in the fresh private project
selected by `SELECTION_FILE`. Git governs real work.

## Requested outcome

Prepare exactly one new verification-contract draft for an independent reviewer
who needs a plan to check the existing fixture against REQ-P3-900: greeting()
returns exactly Hello rehearsal. This is an explicitly requested alternative
authoring exercise; existing VER-P3-900 and all imported -900 records remain
unchanged. Do not claim a missing requirement or verification contract.

Inspect the relevant fixture and governing requirement. Author the new contract
in the selected private service, using domain lifecycle-pilot and synthetic owner
test-owner. Define an independently derived expected result, the check to perform,
its pass condition and the evidence to retain. Plan verification only; do not claim
that tests ran or that the result is verified. Keep the artifact draft. Do not
create other artifacts, approve anything, start work, freeze a baseline or make
lifecycle decisions. Stop when the draft and actual authoring findings are saved,
or report the precise blocker.

## Inputs and boundaries

Apply the complete entry if supplied; otherwise read the selection. Follow the
selected plugin's skills/setup/SKILL.md route. Native Skill must resolve that
candidate. Reuse unchanged content; read missing prerequisites before acting.
After compaction recover the task, selection and original evidence.

Use tool_index for syntax and native file tools or its bounded readers.
Shell calls must use approved_shell_argv_prefix, one helper invocation each.
No scripts, wrappers, pipes, loops, direct client calls or other shell commands.
Normal permissions and hooks apply. Stop denials; do not change routes or permissions.

Write only under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\release023-052-qualification\native\claude-positive1\native\work`, using absolute paths. It exists; inputs are
read-only. Do not install software, activate a checkout, print credentials,
inspect auth stores, or change accounts or host settings. Authentication is
in the environment. Do not read prior trials. Choose operations yourself;
helpers supply no workflow.

## Report

Follow change/references/hosted-drafts.md: use the eligible clarification-only
reply or one short native-report.md in the work directory. Include its required
fields, readiness result and evidence links; keep the final reply consistent.
Do not duplicate captured metrics, observations or inventories. Before exhaustive
failure claims, use observations; it excludes later calls. Incomplete or unknown
capture requires a saved report stating that limit. Lifecycle, MCP parity,
reply recovery and export remain outside this draft-only qualification.
