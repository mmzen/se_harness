"""Retain assessor setup failures separately from native trials."""
import json
from pathlib import Path
import hag_efficiency_plan as p
Q=p.W/'release023-052-qualification'
short=Path(json.loads((Q/'short-native-location.json').read_text())['root'])/'claude-positive1'
long=Q/'native/claude-positive1'
assert not (short/'native/events.jsonl').exists() and not (long/'native/events.jsonl').exists()
for root,runner in [(long,'release023_052_follow_native.py'),(short,'release023_052_short_native.py')]:
    size=json.loads((root/'prelaunch-size-observation.json').read_text())
    v={'candidate':'05c629ddfc0f40924823160d8aaf0fa4e77940a2','phase':'pre-provider input assembly','invocation':[r'C:\Users\mathi\AppData\Local\Python\pythoncore-3.14-64\python.exe','-X','utf8','-B',str(p.W/runner),'run','claude','positive1'],'cwd':str(p.W),'exit':1,'diagnostic':'ValueError: Complete task entry exceeds 64 KiB; no input was truncated','size':size,'provider_invoked':False,'native_events_exist':False,'elapsed_seconds':None,'limit':'No persistent child invocation record was produced because refusal precedes capture. This record reconstructs exact outer argv and observed error from tool output; no unavailable timing is invented.'}
    with (root/'prelaunch-refusal.json').open('x') as f:json.dump(v,f,indent=2)
v={'candidate':'05c629ddfc0f40924823160d8aaf0fa4e77940a2','events':[
 {'event':'Ad hoc live Codex log inspection initially treated host warning lines as JSON.','result':'JSONDecodeError; inspection corrected to separate non-JSON diagnostic lines. Native run unaffected.'},
 {'event':'First positive provenance helper invoked from workspace base instead of work.','result':'ModuleNotFoundError before provider invocation; rerun from correct working directory passed.'},
 {'event':'Default temporary directory was redirected into sandbox package storage.','result':'Creating its child directory raised WinError 5. The locator is preserved as short-native-location-sandbox-attempt.json; a fresh ordinary host temporary location was staged with approved host access.'},
 {'event':'Positive input assembly attempted at regular and shorter disposable paths.','result':'Both refused before provider invocation: 67571 and 66163 bytes versus 65536. Same original source, sections, task and model; no truncation or pointer fallback. No positive native trial ran.'}],
 'effect':'No candidate source change, host-global setting change, lifecycle transition, public delivery or native retry-to-pass. Assessor setup observations do not count as native test failures.',
 'pending_correction':'Reduce non-source instruction/reference overhead while preserving every applicable rule, complete original fixture, identities and the 64 KiB refusal. Avoid dependence on unusually short directory names. This is a proposal, not approved implementation.'}
with (Q/'execution-observations.json').open('x') as f:json.dump(v,f,indent=2)
print('Retained both prelaunch refusals and separate assessor setup observations.')
