"""Relocate the unchanged positive input set to a shorter disposable path."""
import json,sys,tempfile
from pathlib import Path
import hag_efficiency_plan as p
Q=p.W/'release023-052-qualification'
locator=Q/'short-native-location.json'
if not locator.exists():
    root=Path(tempfile.mkdtemp(prefix='v52-',dir=r'C:\Users\mathi\AppData\Local\Temp'))
    with locator.open('x') as f:json.dump({'root':str(root),'reason':'Same complete input/task/sections exceeded 64 KiB due to reference growth and repeated absolute paths. Use shorter temporary paths only; no content removed, criteria or permissions changed.','previous_setup':str(Q/'native/claude-positive1'),'previous_prompt_bytes':67571,'limit':65536},f,indent=2)
root=Path(json.loads(locator.read_text())['root'])
mode,host,case=sys.argv[1:4]
assert case in ('positive1','positive2','positive3')
assert json.loads((Q/'native/claude-diagnostic/independent-assessment.json').read_text())['overall']=='pass'
source=(p.W/'release023_052_native.py').read_text()
source=source.replace("O=Q/'native'/(host+'-'+case);N=O/'native';I=N/'inputs'",f"O=Path({str(root)!r})/(host+'-'+case);N=O/'native';I=N/'inputs'")
source=source.replace('baseport=18920','baseport=18940').replace("project='r2352-'","project='r2352s-'")
if mode=='run':
    if case in ('positive2','positive3'):
        assert json.loads((root/'claude-positive1/independent-assessment.json').read_text())['overall']=='pass'
    assert host=='claude','Codex positive boundary required before enabling'
    start=source.index('    # This first use is the approved diagnostic;')
    end=source.index('    sections=',start)
    source=source[:start]+"    executable=Path(r'C:\\Users\\mathi\\.local\\bin\\claude.exe')\n"+source[end:]
    start=source.index('    sections=');end=source.index('    args=',start)
    source=source[:start]+'''    old=json.loads((p.W/'h44/e/claude-432/native/instruction-entry.json').read_text())
    sections=[r['resource']+'#'+s['heading'] for r in old['instruction_view']['resources'] for s in r['sections']]
'''+source[end:]
exec(compile(source,str(p.W/'release023_052_native.py'),'exec'),{'__name__':'__main__'})
