+++
id = "RISK-P3-901"
type = "risk"
title = "Greeting evidence could be mistaken for a different candidate"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
description = "A local fixture assertion could be attributed to a later service candidate without preserving the source digest and exact evidence, misleading the operator."
action = "Retain the source commit and digest, exact local assertion JSON, full handoff comparison and candidate-bound verification under WO-P3-901."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-901"]
mitigated_by = ["WO-P3-901"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-16T09:59:02Z"
reason = "The supplied synthetic decision selects mitigation through WO-P3-901: retain exact source and assertion evidence with candidate bindings."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-16T09:56:48Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-16T09:59:02Z"
decided_by = "test-owner"
reason = "The supplied synthetic decision selects mitigation through WO-P3-901: retain exact source and assertion evidence with candidate bindings."
+++

# Risk: Greeting evidence could be mistaken for a different candidate

## Description

A local fixture assertion could be attributed to a later service candidate without preserving the source digest and exact evidence, misleading the operator.

## Next action

Retain the source commit and digest, exact local assertion JSON, full handoff comparison and candidate-bound verification under WO-P3-901.
