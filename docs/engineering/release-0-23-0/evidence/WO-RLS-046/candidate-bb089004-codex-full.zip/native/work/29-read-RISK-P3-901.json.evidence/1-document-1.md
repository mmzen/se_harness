+++
id = "RISK-P3-901"
type = "risk"
title = "Greeting evidence could be mistaken for a different candidate"
status = "raised"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
description = "A local fixture assertion could be attributed to a later service candidate without preserving the source digest and exact evidence, misleading the operator."
action = "Retain the source commit and digest, exact local assertion JSON, full handoff comparison and candidate-bound verification under WO-P3-901."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-901"]

[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-16T09:56:48Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."
+++

# Risk: Greeting evidence could be mistaken for a different candidate

## Description

A local fixture assertion could be attributed to a later service candidate without preserving the source digest and exact evidence, misleading the operator.

## Next action

Retain the source commit and digest, exact local assertion JSON, full handoff comparison and candidate-bound verification under WO-P3-901.
