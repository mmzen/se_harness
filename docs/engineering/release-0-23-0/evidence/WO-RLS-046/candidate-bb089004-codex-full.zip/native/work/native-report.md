The required functional cases were observed in the disposable hosted project. The unchanged `greeting()` returned exactly `Hello rehearsal`. `WO-P3-901` is implemented, `VREC-P3-901` is verified, and `RLS-P3-901` is released for test version `0.0.1`. This is a synthetic release record. No real release, push, tag, publication, installation, or deployment occurred.

The run has qualification limitations: independent export replay remains for the reviewer, and the helper's file-read capture omits JSON selections. This report does not claim a flawless run or complete automatic read capture.

| Required case | Observed result | Retained evidence |
| --- | --- | --- |
| Selected context and evaluator | Schema-2 test-copy service and compatible selected client; context reporting was not treated as a passed gate | `001-status.json`, selection and identity reads |
| Own definitions and bounded work | New `-901` chain authored, content reviewed, validated, approved, started, handed off, and completed | Command records 004–015, 035–046, 048–053; [input assessment](input-assessment.md) |
| Risk and paired decision | `RISK-P3-901` created with `DEC-P3-901`; `test-owner` chose `mitigate` linked to `WO-P3-901` | Records 016–020, 028–034 |
| Exact local assertion | Exit 0, stdout `exact greeting passed\n`, empty stderr; source unchanged | [Assertion record](greeting-assertion.json) and its stdout/stderr files |
| Uncertain reply and retry | Original-key lookup recovered acceptance; identical resubmission returned the same receipt, request digest, versions, and affected revisions | [Exact comparison](retry-comparison.json), records 017–019 |
| Changed request under accepted key | HTTP 409 `HAG_REMOTE_KEY_REUSE`; no new receipt or effects | `020-risk-changed-key.json` and request |
| Stale preview | After SPEC revision, old preview with current version inputs refused HTTP 409 `HAG_REMOTE_STALE_PREVIEW`; no effects. Fresh preview and apply succeeded | Records 036–041 |
| Outside handoff | HTTP 422 `HAG_REMOTE_EVALUATOR_REFUSED`; exact scope diagnostic below. Intended approved path then passed | `047-handoff-outside.json`, records 048–053 |
| Verification and release | Commit-bound VREC verified; release contract approved; RLS released with passing decision gates | Records 054–070; [verification assessment](verification-assessment.md); [final check](072-mcp-final-check.json) |
| Seven MCP tools | Exact request and full response retained for all seven; each selected result complete with no continuation or unresolved references | Records 021–027 |
| Immutable exports | Earlier and later snapshots downloaded into separate new directories, including Git bundles and original candidate binding | [Earlier manifest](export-early/manifest.json), [later manifest](export-later/manifest.json) |

All paths in this report are relative to `work/`. Full command captures preserve argv, cwd, exit, stdout, stderr, and elapsed time. Lifecycle request files preserve submitted JSON. Typed draft commands also retain their evidence files. [Native observations](native-observations.json) contains machine-readable case outcomes and the final evaluator result.

Selected identities:

- Project: `d4535864-f1f5-4ab6-b56e-5afa90d4dee0`; endpoint `http://127.0.0.1:50767`.
- Context: `f3f6b1c6-53f9-4d35-a536-a860cbf5cf8d`; final context version 27, project version 29.
- Client: `0.23.0`, wheel SHA-256 `fe431265298cb94d5205c231729f920ce31e77c3f250f525870d214a079fb519`.
- Selected plugin candidate: `0.2.7`, bundled evaluator `0.23.0`. The service governor was released `0.22.1`, archive SHA-256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`, payload SHA-256 `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff`.
- Imported baseline B: `se-harness-artifact-baseline/v1:sha256:bd0ebe9bfbc1a7879cf0663a37b1286e487d61b690058d052967959e73977981`.
- Source fixture commit S: `5820415917e87b64d80bad2f7c39c6d18d692829`.
- Test candidate P: `d54f90430f866ab38456e2fa95941f3db563ca1a`.
- Separate actual qualification implementation candidate C: `bb0890045f462343ecae66ca30b20b06cf6e8ae6`.
- Handoff base: `91459ee4ccca70ef3f5718af94fb86587cda3568`, taken from the first accepted lifecycle operation's `input_git_head`.
- VREC capture input baseline: `se-harness-artifact-baseline/v1:sha256:28ba04d6a99055b49949eca4f098703450df1589dfd22458e1005e7d43beb2fd`.

The immutable 45-byte source has SHA-256 `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`. It defines `greeting()` and returns the literal `'Hello rehearsal'`. The local assertion record is 776 bytes, SHA-256 `d843205aff4cee405f589d19c4cd8786c64e4998e84f3ef8a897cd4378533c81`. Its retained command uses the selected client Python with `-I -B` and `runpy.run_path`, then asserts equality. The service did not run a source test. This Windows observation does not establish cross-platform behavior, CI execution, a separate type assertion, or an independently recorded Python version.

The new formal artifacts are `INT-P3-901`, `CAP-P3-901`, `REQ-P3-901`, `SPEC-P3-901`, `VER-P3-901`, `WO-P3-901`, `RISK-P3-901`, `DEC-P3-901`, `VREC-P3-901`, `REL-P3-901`, and `RLS-P3-901`. Definitions and REL are approved. WO remains implemented; verification did not silently change its state. DEC is decided and RISK remains mitigating, not closed. The synthetic identities are `test-owner` for definitions, work approval and risk decision; `test-executor` for execution; `quality-owner` for verification; and `release-owner` for release.

Validation found no errors or warnings. It retained the advisory `W-AUT-022` for the imported `SPEC-P3-900` rule `P3-GREET-900`. That historical artifact was not amended. The earlier and later export manifests have identical hashes for all seven imported `-900` files. New drafts received an independent content review; structural validation alone was not treated as semantic acceptance. The scope contained 11 exact paths. Automatic work-packet and related-record admission supplied required evidence/verification/release records. No scope broadening was used to overcome a refusal. The closed hosted schema did not expose a planned-path preparation check; manual scope review and the actual execution-scope gate were retained without claiming that missing check ran.

The dropped risk reply left acceptance initially unknown. Record 018 looked up `native-risk-apply`; record 019 resubmitted the exact original 017 request file. Both returned receipt `sha256:1c3fdb5ca43f1e30077d9019b23304b6da9f65b5600863be5e2523d7b18e0bf7` and request digest `sha256:c9dd4724efcec19d94ece7ebbdd67db7549f8582642adb7f3af2e9c7ca8fa9fb`. The versions remained project 14→15 and context 12→13. Record 020 changed only the risk title under the accepted key and was refused. The exact comparison distinguishes lookup from resubmission; a lookup alone is not retry evidence.

The stale-preview probe retained current project/context versions 17/15 while submitting the preview generated before the selected SPEC draft changed. The refusal left SPEC draft at that revision; record 039 read it back. Records 040–041 generated and applied a fresh preview.

The outside-handoff refusal reported `QG-G4-IMPLEMENTATION-EVIDENCE`, predicate `QGP-G4I-PATHS`, and `WEX201`: “changed path is outside execution scope: docs/engineering/lifecycle-pilot/evidence/outside/greeting-assertion.json”. Writes, files, and affected artifacts were empty and WO remained in_progress. The corrected handoff used the already-approved `evidence/WO-P3-901/greeting-assertion.json` path and the full lifecycle base. These service refusals were not host permission denials.

MCP records 021–027 preserve `revision` (paired DEC), `check` (pending DEC), `work_context` (own WO and definition chain), `impact` (own REQ dependents), `lineage` (REQ before VREC creation), `compare` (imported baseline versus context), and `cypher` (selected WO projection). They use project version 15/context version 13. Each returned `complete: true`, `continuation: null`, and an empty unresolved-reference list. The empty lineage result is only a result for that early view. All results were inline; no saved-result notices were left unread. The final RLS check in record 072 is also complete. Read-only database enforcement was not independently tested.

| Export | Earlier | Later |
| --- | --- | --- |
| Directory | `work/export-early` | `work/export-later` |
| File count | 20 | 28 |
| Snapshot | `sha256:1d3b88bda8bd7ee7c97b2251851cecff7405cb010ccf62adb938b06668b97348` | `sha256:6b6eb4a45e6f06d50b157aca8e372010a7f99258dc3211c8fc3b3649c7efe239` |
| Git head | `1a5a20ef91f510e55d5ae2a44cf95626463cc1f7` | `49acef65fc6e1ddaf85e250e6b849b32b68a2474` |
| Bundle SHA-256 | `be484707fa3acefecc644a83e6fc85a7fcd8d51762087e54362afd6794568832` | `bfaf4b87461385d41df651bc142321771d689395bc2ada948a2a5bc1221861e9` |

Export baselines, manifest hashes, bundle sizes, and absolute destinations are in native-observations.json. The later manifest retains P and its file map; the later governance head does not replace P. Intermediate exports `export-handoff`, `export-ready`, and `export-release-ready` support decision-time evidence review. No independent Git reconstruction or released-0.22.1 replay was performed here. Those checks remain with the independent reviewer.

The VREC evaluator sidecar reports `origin-version` inspection and version 0.22.1 with null archive/payload fields. It is not itself a full payload attestation. The service envelopes separately pin the exact governor. The RLS sidecar reports `full-payload` with the selected hashes. Both observed sidecars had empty diagnostics. The final release application passed `QG-G5-RELEASE-DECISION` and structural checks. The later context-only check is `not_assessable` with no gates; it reports state and does not re-prove those earlier gates.

Errors and trace limits are part of the result:

- Initial file read requested limit 16000, which the bounded reader rejected; it was corrected to 4096.
- A native patch to input-assessment.md failed because its context did not match. It made no write; the corrected patch succeeded.
- A guessed `verification_record` heading did not exist. The required verification-coverage section was then read separately.
- After compaction, one instruction request omitted the `harness/` directory. Exact inventory discovery and corrected paths recovered the required sections.
- During reporting, the full `/command_records` JSON selection returned a traceback and the orchestration JSON parse failed. Smaller selections succeeded. The 69-item command list was not fully reread.
- Records 017, 020, 038, and 047 are the expected transport/refusal cases described above. No current operation remains uncertain.
- Some draft/template projections were incomplete because placeholder links or row limits applied. They were not treated as complete governing views; the authored records were subsequently inspected through complete saved reads.
- The hosted-artifact-graph reference output was truncated; the required physical-representation section was visible. A whole-file reading claim is not made.

[Observation capture](073-observations-capture.json) is an in-progress snapshot: 209 observed tool items, seven native failure items, and four failed command records. It is not a total call count, wall-time measure, or billed-token total. Later reporting operations are outside that snapshot. The patch error and later reporting error are supplemented above. No host permission denial, permission escalation, user clarification, credential inspection, software installation, source edit, or delegation was observed.

[File-read trace](file-read-trace.json) retains exact paths, hashes, section/chunk boundaries, and trigger explanations for successful visible text reads, plus selected final JSON comparisons. Its `complete` field is false: the helper's `observed_content_reads` excludes JSON selections and `file_reads` was empty. The native transcript and retained command/evidence files are needed for the omitted JSON reads. Whole-file hashes and discovery listings are not proof of whole-file reading. The explicit initial task setup and compaction recovery do not establish automatic startup instruction delivery.

Exactly one current evaluator step is reported: `PROC-EXTERNAL-ACTION / STEP-EXTERNAL-ACTION` for `RLS-P3-901`. Its decision right is `DR-EXTERNAL-ACTION`, held by the accountable external-action owner. Its operative response is: “Reuse the matching complete-release or external-action authorization for RLS-P3-901; request only an uncovered action and target.” Release status alone performs no external action. The task excludes such actions, so this run ends with the synthetic released record and exported evidence.

