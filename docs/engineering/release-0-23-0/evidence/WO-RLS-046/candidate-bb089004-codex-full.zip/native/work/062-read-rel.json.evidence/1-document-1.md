+++
id = "REL-P3-901"
type = "release_contract"
title = "Test 0.0.1 greeting proof release"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
candidate_commit = "d54f90430f866ab38456e2fa95941f3db563ca1a"
[relations]
gates = ["WO-P3-901"]
+++

# Release Contract: Test 0.0.1 greeting proof release
## Release unit
Test version 0.0.1 includes only WO-P3-901 and the immutable fixture greeting proof at candidate d54f90430f866ab38456e2fa95941f3db563ca1a. Final verified VREC-P3-901 covers that work and VER-P3-901. The source fixture commit 5820415917e87b64d80bad2f7c39c6d18d692829 is provenance, not the release candidate.

## Required evidence
Require the verified VREC at the exact candidate, local assertion output with exit 0 and stdout `exact greeting passed`, source digest dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1, and the full-base handoff evidence. Preserve the risk and its mitigation decision. The assertion JSON is docs/engineering/lifecycle-pilot/evidence/WO-P3-901/greeting-assertion.json with SHA-256 d843205aff4cee405f589d19c4cd8786c64e4998e84f3ef8a897cd4378533c81.

## Compatibility and migration
No source, packaging, runtime or schema migration is part of this release record. No production compatibility claim is made.

## Security and provenance
Use the selected private test project and released evaluator 0.22.1. Preserve exact request receipts, source identity, candidate bindings, file hashes and Git history in immutable exports. Imported -900 records remain unchanged.

## Promotion policy
Prepare and assess one synthetic test RLS for version 0.0.1. The tag label `v0.0.1` is record metadata only. No push, tag creation, publication, installation or deployment is authorized. The operator reviews the exported record locally.

## Human approval triggers
The task supplies test-owner definition approval and release-owner preparation/decision inputs after gates pass. These are synthetic labels and confer no real human or external authority. Changed candidate, scope or failed gates stop the affected action.

## Rollback criteria and procedure
If evidence or candidate bindings fail, stop the test release assessment and retain the exact refusal. Preserve both immutable snapshots and all accepted history for inspection. No deployed state exists to roll back; never rewrite accepted records to conceal a failure.

## Post-release observation
At rehearsal completion, retain the final export for the independent reviewer to reconstruct Git history and check the exact bytes with released 0.22.1. Download success is not an independent replay result.

