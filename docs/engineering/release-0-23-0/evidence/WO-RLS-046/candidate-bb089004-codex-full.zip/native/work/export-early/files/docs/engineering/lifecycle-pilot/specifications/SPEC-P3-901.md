+++
id = "SPEC-P3-901"
type = "specification"
title = "Exact immutable greeting contract"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
contract = "The selected greeting() returns exactly Hello rehearsal without source modification."
[relations]
specifies = ["REQ-P3-901"]
+++

# Specification: Exact immutable greeting contract
## Scope
This contract covers the existing no-argument greeting() function in src/greeting.py and proof of its result. The source snapshot is immutable.

## Rules
**P3-GREET-901.** Calling greeting() without arguments MUST return exactly `Hello rehearsal`.

## Failure behaviour
A different result or an exception fails the equality assertion. Retain the failure and stop dependent acceptance; do not modify the fixture to conceal it.

## Examples
Given the selected fixture, when greeting() is called once, then the result equals `Hello rehearsal` under P3-GREET-901.

## Coverage
| Requirement | Rules |
| --- | --- |
| REQ-P3-901 | P3-GREET-901 |

## Design simplicity
One equality assertion and source inspection establish the requested behavior. No new mechanism, input mode, type assertion, architecture or runtime guarantee is required.

