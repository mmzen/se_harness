"""Confirm normal isolated hook review before resuming delivery tests."""
import hashlib,json,sys
from pathlib import Path
W=Path(__file__).parent;O=W/'release023-053-qualification/delivery'
sys.path.insert(0,str(W/'iar-demo-tools'))
from release023_053_delivery_support import Codex,save
r=json.loads((O/'codex-short-ready-for-trust.json').read_text())
E=O/'codex-short-trust-readback';E.mkdir(exist_ok=False)
c=Codex({'demo':r['profile_base'],'host_executables':{'codex':r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\2e5e00daee91c61d\codex.exe'}},E)
try:v=c.rpc('hooks/list',{'cwds':[r['cwd']]});save(E/'hooks.json',v)
finally:c.close()
hooks=[h for row in v['data'] for h in row['hooks']]
assert len(hooks)==1
h=hooks[0];assert h['trustStatus']=='trusted' and h['pluginId']=='verity-plane@se-harness' and h['enabled']
assert Path(h['sourcePath']).resolve()==(Path(r['plugin'])/'hooks/hooks.json').resolve()
assert hashlib.sha256(Path(h['sourcePath']).read_bytes()).hexdigest()==r['hook_file_sha256']
record={'method':'Normal isolated Codex CLI /hooks review; selected SessionStart Hook 1, inspected command/source/matcher/timeout/context, then t to trust. No trust-bypass flag or global profile change. Esc dismissed sandbox onboarding without setup. Closed the test CLI normally with Ctrl-D.', 'test_tui_session':'01a143c4-e4e7-7ca0-a25f-4f587a1d1f7a','hook':h,'profile_base':r['profile_base'],'source_sha256':r['hook_file_sha256']}
save(O/'codex-short-trust-reviewed.json',record)
print(json.dumps({'trusted':True,'key':h['key'],'hash':h['currentHash']}))
