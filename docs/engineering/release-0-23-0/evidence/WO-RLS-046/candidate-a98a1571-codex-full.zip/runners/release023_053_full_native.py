"""Run the unchanged full lifecycle task on the current private combination."""
import hashlib,json,subprocess,sys
from pathlib import Path
W=Path(__file__).parent;R=W/'hag221proposal';Q=W/'release023-053-qualification'
host=sys.argv[1];assert host in ('claude','codex');O=Q/'native'/(host+'-full');N=O/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
assert load(Q/'native/claude-diagnostic/independent-assessment.json')['overall']=='pass'
for trial in ('claude-positive1','claude-positive2','claude-positive3','codex-positive1'):
    assert load(Q/'native'/trial/'independent-assessment.json')['overall']=='pass'
if host=='codex':assert load(O/'boundary-probe-assessment.json')['overall']=='pass'
assert load(O/'ready.json')['exit']==0
C=load(O/'native-selection.json')['qualification_candidate']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==C
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
import hag_efficiency_plan as p
p.O=O
exe=Path(r'C:\Users\mathi\.local\bin\claude.exe') if host=='claude' else Path(r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\2e5e00daee91c61d\codex.exe')
version=p.run('full-host-version',[exe,'--version'],cwd=W)
if host=='claude':
    probe=p.run('full-live-model-probe',[exe,'-p','--no-session-persistence','--tools','','--model','claude-opus-5-5','--output-format','json','Authorized provider availability probe. Reply exactly AUTH_OK. Use no tools, read no files and change nothing.'],cwd=W)
    assert probe.get('result','').strip()=='AUTH_OK' and not probe.get('is_error')
sha=lambda b:hashlib.sha256(b).hexdigest()
def boundary():
    files=[Path(x) for x in ('C:/Users/mathi/.codex/config.toml','C:/Users/mathi/.claude/settings.json','C:/Users/mathi/.claude/plugins/installed_plugins.json')]
    return {'settings':[{'path':str(f),'sha256':sha(f.read_bytes()) if f.exists() else None} for f in files],'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'repository_status':subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)}
def put(name,v):
    with (O/name).open('x',encoding='utf-8') as f:json.dump(v,f,indent=2);f.write('\n')
put('full-route.json',{'task':'Unchanged h44 full native lifecycle task; only selected absolute paths relocated.','input_route':'pointers, as original full lifecycle qualification; complete-input route belongs to focused EFF cases','model':'claude-opus-5-5' if host=='claude' else 'Unchanged host selection; capture actual identity','model_basis':'Original h44/f/claude-421 full task used claude-opus-5-5; focused EFF trials use their separate claude-opus-4-6 selection. No equal-model speed comparison.','fault':'One accepted lifecycle reply dropped, as original NQ-04 task.','candidate':C})
args=[sys.executable,'-X','utf8','-B',R/'tests/hosted_artifact_graph/qualify_agents.py','--host',host,'--executable',exe,'--selection',O/'native-selection.json','--credentials',O/'credentials.json','--task',O/'native-task.md','--output',N,'--prepared-inputs','--timeout','3600','--drop-reply']
if host=='claude':args+=['--permission-settings',O/'permissions.json','--model','claude-opus-5-5']
else:args+=['--codex-loopback-network']
put('boundary-before-native.json',boundary())
try:code=subprocess.call(list(map(str,args)),cwd=W)
finally:put('boundary-after-native.json',boundary())
raise SystemExit(code)
