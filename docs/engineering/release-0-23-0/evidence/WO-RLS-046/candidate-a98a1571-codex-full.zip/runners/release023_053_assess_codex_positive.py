"""Retain independent review of the native Codex positive draft."""
import json,tomllib
from pathlib import Path
O=Path(__file__).parent/'release023-053-qualification/native/codex-positive1'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
o=load(O/'independent-observations.json');s=load(O/'mechanical-summary.json');r=load(O/'independent-readback.json')
m=tomllib.loads((O/'independent-document.md').read_text().split('+++')[1])
assert m['status']=='draft' and m['relations']['verifies']==['REQ-P3-900']
assert not s['native_call_count_complete'] and len(o['calls'])==13 and not s['native_failures']
assert all(c['item'].get('exit_code',0)==0 and c['item']['status']=='completed' for c in o['calls'])
assert r['exact_saved_document'] and len(r['baseline_records'])==7 and o['project_version']==4
assert not o['input_changes'] and o['host_boundary_unchanged']
assert (O/'prelaunch-task.txt').read_bytes()==(O/'native/task.md').read_bytes()
a={'candidate':o['candidate'],'case':'EFF-04B','trial':'codex-positive1','overall':'pass',
 'method':'Independent semantic review of the separately read saved document, original fixture/definitions, report, final reply and every visible tool result. Seven separate baseline reads establish immutable original bytes. Incomplete host telemetry is not inferred complete.',
 'content_result':'The draft verifies REQ-P3-900 with a complete requirement-to-evidence matrix and independently fixed Hello rehearsal expectation. It gives the exact available PowerShell helper command, native Windows runtime, source hash guard, equality pass/fail and unassessed error outcomes. A full proposed work/WO-P3-900/assertion.json path supplies concrete evidence retention. It distinguishes service evaluator, tested input and planned local assertion, and accurately states helper limitations.',
 'reporting_result':'The report correctly separates content review from evaluator shape admission, retains the original advisory and incomplete-template findings, lists accepted writes and saved-revision read, and discloses incomplete capture. It explicitly says no tests ran and no verification is claimed. No failed or denied action is visible, but no exhaustive count is asserted.',
 'artifact':r['artifact'],'document_sha256':r['document_sha256'],'exact_saved_document':True,'baseline_records_unchanged':7,'final_project_version':4,
 'metrics':o['metrics'],'goals':s['goals'],'visible_call_lower_bound':13,'native_call_count_complete':False,'operations':r['operations'],'input_changes':[],'host_boundary_unchanged':True,
 'host_diagnostics':o['diagnostics'],
 'limits':['211.466 seconds misses the duration goal; exact call total, peak context and model-turn count unavailable.','Host icon, PowerShell snapshot and legacy_notify warnings remain separate from successful visible native commands.','All six focused cases pass; this does not establish full native lifecycle/delivery, desktop, human verification or release readiness.'],
 'evidence':['independent-document.md','independent-readback.json','independent-revision.json','native/work/native-report.md','independent-observations.json','mechanical-summary.json','boundary-probe-assessment.json']}
with (O/'independent-assessment.json').open('x',encoding='utf-8') as f:json.dump(a,f,indent=2);f.write('\n')
print(json.dumps({k:a[k] for k in ('overall','metrics','visible_call_lower_bound')}))
