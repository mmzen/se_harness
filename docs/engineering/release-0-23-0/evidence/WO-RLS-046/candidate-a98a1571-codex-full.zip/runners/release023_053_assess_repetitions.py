"""Retain independent reviews after inspecting both fresh native repetitions."""
import json,tomllib
from pathlib import Path
Q=Path(__file__).parent/'release023-053-qualification'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
for case,count in [('positive2',13),('positive3',11)]:
    O=Q/'native'/('claude-'+case);o=load(O/'independent-observations.json');s=load(O/'mechanical-summary.json');r=load(O/'independent-readback.json')
    m=tomllib.loads((O/'independent-document.md').read_text().split('+++')[1])
    assert m['status']=='draft' and m['relations']['verifies']==['REQ-P3-900']
    assert s['native_call_count_complete'] and len(o['calls'])==len(o['results'])==count
    assert not s['native_failures'] and all(not x['is_error'] for x in o['results'])
    assert r['exact_saved_document'] and len(r['baseline_records'])==7
    assert o['project_version']==4 and not o['input_changes'] and o['host_boundary_unchanged']
    assert (O/'prelaunch-task.txt').read_bytes()==(O/'native/task.md').read_bytes()
    a={'candidate':o['candidate'],'case':'EFF-04B','trial':'claude-'+case,'overall':'pass',
      'method':'Independent semantic review of separately read saved bytes against request, original definitions and actual execution capability; paired calls/results, final reply, saved report and seven baseline reads inspected. No keyword grader.',
      'content_result':'The draft links REQ-P3-900, derives Hello rehearsal from the requirement/specification, supplies a complete matrix and the available assert-greeting equality check with concrete pass/fail outcomes. The evidence path includes the domain, work-order directory and distinct JSON filename. The check runs on the native test host; the released evaluator identity is distinguished from the client runtime. Imported history and fixture are unchanged.',
      'reporting_result':'The saved report and final reply separate the plan from executed verification. Four accepted project mutations and actual saved versions are correctly reported. No test execution or outcome verification is claimed. Complete paired capture contains no failed/denied call; the successful final report write after the observation snapshot is accounted for. The imported W-AUT-022 advisory is retained.',
      'specific_review':'The second draft names Windows, selected client_python, evaluator archive identity and actual record fields. Its saved report explicitly says no tests were executed.' if case=='positive2' else 'The third draft accurately limits the helper to equality: no separate type assertion, Python-version capture or commit-bound assurance. Its final reply explicitly states no tests or verification are claimed.',
      'artifact':r['artifact'],'document_sha256':r['document_sha256'],'exact_saved_document':True,'baseline_records_unchanged':7,'final_project_version':4,
      'metrics':o['metrics'],'goals':s['goals'],'operations':r['operations'],'input_changes':[],'host_boundary_unchanged':True,
      'limits':['Duration and peak-context goals missed; tool-call goal met. Correctness and efficiency have distinct verdicts.','Repetitions ran concurrently in separate fresh projects; record the range/median as observed costs, not an isolated benchmark.','Full lifecycle/delivery, desktop and accountable release decisions remain separate.'],
      'evidence':['independent-document.md','independent-readback.json','independent-revision.json','native/work/native-report.md','independent-observations.json','mechanical-summary.json']}
    with (O/'independent-assessment.json').open('x',encoding='utf-8') as f:json.dump(a,f,indent=2);f.write('\n')
    print(json.dumps({k:a[k] for k in ('trial','overall','metrics','goals')}))
