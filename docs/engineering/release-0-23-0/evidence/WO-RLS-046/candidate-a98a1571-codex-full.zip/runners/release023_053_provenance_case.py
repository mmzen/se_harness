"""Apply the same payload provenance review to a selected fresh trial."""
import sys
from pathlib import Path
W=Path(__file__).parent
host,case=sys.argv[1:3]
assert host in ('claude','codex') and case in ('diagnostic','positive1','positive2','positive3','full')
source=(W/'release023_053_provenance.py').read_text()
source=source.replace("O=Q/'native/claude-diagnostic'",f"O=Q/'native/{host}-{case}'")
original='421' if case=='full' else '431' if case=='diagnostic' else '432'
source=source.replace('h44/e/claude-431',f"h44/{'f' if case=='full' else 'e'}/{host}-{original}")
exec(compile(source,str(W/'release023_053_provenance.py'),'exec'),{'__name__':'__main__'})
