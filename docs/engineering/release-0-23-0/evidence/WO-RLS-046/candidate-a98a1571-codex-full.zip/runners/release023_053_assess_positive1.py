"""Retain semantic review of the first fresh positive draft."""
import hashlib,json,tomllib
from pathlib import Path
O=Path(__file__).parent/'release023-053-qualification/native/claude-positive1'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
o=load(O/'independent-observations.json');s=load(O/'mechanical-summary.json');r=load(O/'independent-readback.json')
meta=tomllib.loads((O/'independent-document.md').read_text().split('+++')[1])
assert meta['status']=='draft' and meta['relations']['verifies']==['REQ-P3-900']
assert s['native_call_count_complete'] and len(o['calls'])==len(o['results'])==15
assert not s['native_failures'] and all(not x['is_error'] for x in o['results'])
assert r['exact_saved_document'] and len(r['baseline_records'])==7
assert o['project_version']==4 and not o['input_changes'] and o['host_boundary_unchanged']
assert (O/'prelaunch-task.txt').read_bytes()==(O/'native/task.md').read_bytes()
a={'candidate':o['candidate'],'case':'EFF-04B','trial':'claude-positive1','overall':'pass',
 'method':'Independent semantic review of exact separately read saved bytes, the request and original definitions, report and all paired visible calls/results. Seven independent baseline reads confirm original Git-blob bytes. Assertions bind facts; no content keyword grader.',
 'content_result':'The draft links REQ-P3-900 and contains a requirement/method/case/pass-condition matrix. Expected Hello rehearsal derives from the requirement and specification. The planned assert-greeting capability is available and accurately described: selected-source digest guard, local Windows equality assertion, exit zero and exact greeting passed. The evidence plan names the full repository-relative work-order destination and filename. One exact equality check covers this literal requirement; no invented scenarios or missing-contract claim.',
 'reporting_result':'The report distinguishes draft admission from content review, retains the pre-existing W-AUT-022 advisory and all actual command records, and makes no executed-test or verified-outcome claim. The final says the contract plans a check. Complete capture establishes no failed or denied call. The last successful report write follows the observation snapshot and is accounted for.',
 'observations':['The report says two mutations then explicitly limits those to VER-P3-001 content writes and separately lists import and draft-open. The actual total is four accepted project mutations: import, draft-open, create, revise. The final correctly says two content writes; do not reuse this as a total-mutation count.','No explicit no-tests-ran sentence appears, but all checks are written as plans, no assertion was invoked, and no executed/verified result is claimed.','Additional reads and returned data increased context. This is a correct draft but misses duration and peak-context goals.'],
 'artifact':r['artifact'],'document_sha256':r['document_sha256'],'exact_saved_document':True,'baseline_records_unchanged':7,'final_project_version':4,
 'metrics':o['metrics'],'goals':s['goals'],'operations':r['operations'],'host_boundary_unchanged':True,'input_changes':[],
 'evidence':['independent-document.md','independent-readback.json','independent-revision.json','native/work/native-report.md','independent-observations.json','mechanical-summary.json'],
 'limits':['One positive attempt; the two further Claude repetitions and Codex positive remain required.','Ran concurrently with the separate Codex diagnostic; timing is an observation, not an isolated benchmark.','No full lifecycle/delivery, desktop, verification acceptance or release claim.']}
with (O/'independent-assessment.json').open('x',encoding='utf-8') as f:json.dump(a,f,indent=2);f.write('\n')
print(json.dumps({k:a[k] for k in ('overall','metrics','goals')}))
