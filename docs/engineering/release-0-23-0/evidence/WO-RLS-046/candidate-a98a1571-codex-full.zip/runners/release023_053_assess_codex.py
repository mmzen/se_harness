"""Retain independent current-candidate Codex diagnostic review."""
import hashlib,json
from pathlib import Path
O=Path(__file__).parent/'release023-053-qualification/native/codex-diagnostic'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
o=load(O/'independent-observations.json');s=load(O/'mechanical-summary.json')
assert len(o['calls'])==5 and not s['native_failures'] and not s['native_call_count_complete']
assert all(c['item'].get('exit_code',0)==0 and c['item']['status']=='completed' for c in o['calls'])
assert o['project_version']==0 and not o['input_changes'] and o['host_boundary_unchanged']
assert (O/'prelaunch-task.txt').read_bytes()==(O/'native/task.md').read_bytes()
a={'candidate':o['candidate'],'case':'EFF-04A2','trial':'codex-diagnostic','overall':'pass',
 'method':'Independent semantic review of the saved report and final reply against the supplied request and original fixture, all visible calls, and a separate HTTP service-status read. Incomplete telemetry remains explicit.',
 'content_result':'Identifies missing audience/problem, intended benefit, success condition and product scope. Acknowledges existing definitions and treats the proposed outcome as unconfirmed. Reports Incomplete, asks for missing facts, and makes no completeness or coverage-gap claim.',
 'reporting_result':'Uses the saved-report branch because capture completeness is unavailable. The report and final reply limit failure claims to observations. Four successful read/identity/observation helper calls and the successful report write are visible. No hosted mutation is visible; independent status is version zero. No exhaustive call total is inferred.',
 'metrics':o['metrics'],'goals':s['goals'],'visible_call_lower_bound':5,'native_call_count_complete':False,
 'host_diagnostics':o['diagnostics'],'host_diagnostic_limit':'Icon-path, unsupported PowerShell snapshot and legacy_notify Windows error 206 warnings are retained separately. They do not constitute hosted mutation failures or establish desktop/delivery qualification.',
 'report_sha256':hashlib.sha256((O/'native/work/native-report.md').read_bytes()).hexdigest(),
 'project_version':0,'input_changes':[],'host_boundary_unchanged':True,
 'limits':['Missing-input diagnostic only.','Exact native-call count, model turns and input-context measurements unavailable.','Concurrent with separate Claude positive project; timings are observations, not isolated benchmarks.','Remaining positive/native lifecycle/delivery and desktop evidence remain pending.'],
 'evidence':['independent-observations.json','independent-status.json','mechanical-summary.json','native/work/native-report.md','boundary-probe-assessment.json','payload-provenance-review.json']}
with (O/'independent-assessment.json').open('x',encoding='utf-8') as f:json.dump(a,f,indent=2);f.write('\n')
print(json.dumps({k:a[k] for k in ('overall','metrics','visible_call_lower_bound')}))
