"""Record the independently reviewed current-candidate diagnostic."""
import hashlib,json
from pathlib import Path
W=Path(__file__).parent; O=W/'release023-053-qualification/native/claude-diagnostic'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
o=load(O/'independent-observations.json');s=load(O/'mechanical-summary.json')
assert s['native_call_count_complete'] and len(o['calls'])==len(o['results'])==6
assert not s['native_failures'] and all(not r['is_error'] for r in o['results'])
assert o['project_version']==0 and o['host_boundary_unchanged'] and not o['input_changes']
assert ' remote status --record ' in o['calls'][0]['input']['command']
assert all(' instructions --section ' in c['input']['command'] for c in o['calls'][1:])
assert (O/'prelaunch-task.txt').read_bytes()==(O/'native/task.md').read_bytes()
a={
 'candidate':o['candidate'],'case':'EFF-04A2','trial':'claude-diagnostic','overall':'pass',
 'method':'Independent semantic review of final reply, all six paired visible calls/results and separately observed service status. Mechanical assertions bind evidence; no text matcher decides the semantic verdict.',
 'content_result':'The reply identifies existing Hello rehearsal definitions, distinguishes the new audience and its present problem as unknown, requests the observable outcome and how the owner will know it helped, and reports Incomplete. It creates no artifact and claims no agreed benefit, success condition or absence of prior definitions.',
 'reporting_result':'The retained final reply is eligible: all six attempted calls are captured and paired with successful results; there is one status read and five instruction reads, no hosted mutation attempt, failure or denial. It explicitly states no hosted mutation was attempted. Separate HTTP status confirms project version zero; all staged bytes and inspected host settings are unchanged.',
 'observations':[
  'The proposed statement adds alongside the existing rehearsal greeting. It is explicitly marked proposed and pending answers, not a supported or agreed product requirement. Do not carry this wording into a formal definition without requester confirmation.',
  'Five additional prerequisite reads increased peak context beyond the efficiency goal. They do not constitute a content failure, and this negative diagnostic does not establish positive drafting performance.'
 ],
 'report_branch':{'form':'retained final reply','mutation_attempts':0,'capture_complete':True,'saved_report_required':False},
 'metrics':o['metrics'],'goals':s['goals'],'project_version':0,'input_changes':[],'host_boundary_unchanged':True,
 'complete_prompt_sha256':hashlib.sha256((O/'native/task.md').read_bytes()).hexdigest(),
 'evidence':['independent-observations.json','independent-status.json','mechanical-summary.json','native/events.jsonl','payload-provenance-review.json','prelaunch-check.json'],
 'limits':['One missing-input diagnostic; no positive artifact-authoring, full lifecycle, desktop or release-readiness verdict.','Prior failures retain their original verdicts.','No completion, human verification, merge or release decision is recorded.'],
 'next':'Run the authorized Codex diagnostic with boundary probes and the original positive sequence.'
}
with (O/'independent-assessment.json').open('x',encoding='utf-8') as f:json.dump(a,f,indent=2);f.write('\n')
print(json.dumps({k:a[k] for k in ('overall','metrics','goals')}))
