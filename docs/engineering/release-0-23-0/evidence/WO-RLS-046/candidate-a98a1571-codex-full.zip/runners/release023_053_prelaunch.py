"""Measure exact staged inputs with the unchanged pre-provider launcher statements."""
import argparse,ast,copy,hashlib,json,sys
from pathlib import Path
W=Path(__file__).parent;R=W/'hag221proposal';Q=W/'release023-053-qualification'
host,case=sys.argv[1:3];O=Q/'native'/f'{host}-{case}';N=O/'native'
sys.path.insert(0,str(R/'tests/hosted_artifact_graph'));import qualify_agents as q
assert {f.name for f in N.iterdir()}=={'inputs','work'} and not list((N/'work').iterdir())
selectors=['docs/engineering/harness/COMMUNICATION.md#communication']
if case=='diagnostic':selectors += ['docs/engineering/harness/DEFINE_CHANGE.md#read-this-when','docs/engineering/harness/DEFINE_CHANGE.md#before-this-action','docs/engineering/harness/DEFINE_CHANGE.md#describe-the-intended-outcome','docs/engineering/ARTIFACT_AUTHORING.md#intent']
else:selectors += ['docs/engineering/harness/DRAFT_DEFINITIONS.md#read-this-when','docs/engineering/harness/DRAFT_DEFINITIONS.md#before-this-action','docs/engineering/harness/DRAFT_DEFINITIONS.md#define-how-the-result-will-be-verified','docs/engineering/harness/ARTIFACTS.md#artifact-types','docs/engineering/harness/ARTIFACTS.md#artifact-locations','docs/engineering/harness/DEFINITION_LINKS.md#links-between-definitions','docs/engineering/ARTIFACT_AUTHORING.md#design-simplicity','docs/engineering/ARTIFACT_AUTHORING.md#verification']
path=Path(q.__file__);tree=ast.parse(path.read_text());fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run');fn=copy.deepcopy(fn)
cut=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.If) and isinstance(n.test,ast.Name) and n.test.id=='entry');fn.body=fn.body[:cut]
scope=dict(vars(q));exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),str(path),'exec'),scope)
args=argparse.Namespace(output=N,prepared_inputs=True,selection=O/'native-selection.json',credentials=O/'credentials.json',host=host,drop_reply=False,complete_inputs=True,instruction_section=selectors,task=O/'native-task.md',codex_loopback_network=host=='codex')
captured={}
def trace(frame,event,arg):
 if frame.f_code.co_name=='run' and 'prompt' in frame.f_locals:captured.update({k:frame.f_locals[k] for k in ('prompt','entry','settings') if k in frame.f_locals})
 return trace
sys.settrace(trace);error=None
try:scope['run'](args)
except ValueError as exc:error=str(exc)
finally:sys.settrace(None)
sha=lambda b:hashlib.sha256(b).hexdigest()
prompt=captured['prompt'].encode();packet=captured['entry']
with (O/'prelaunch-entry.json').open('x') as f:json.dump(packet,f,indent=2)
with (O/'prelaunch-task.txt').open('xb') as f:f.write(prompt)
row={'host':host,'case':case,'candidate':captured['settings']['qualification_candidate'],'root':str(N),'bytes':len(prompt),'limit':65536,'headroom':65536-len(prompt),'error':error,
 'sha256':sha(prompt),'source_files':len(packet['complete_input_files']['sources']),'source_bytes':packet['source_bytes'],'reference_bytes':packet['reference_bytes'],'provider_invoked':False,'service_contacted':False,'qualifier_sha256':sha(path.read_bytes()),
 'method':'Original launcher statements through complete-input size/credential guard; AST excludes all provider/capture code. Temporary effective selection removed after retaining exact entry; source inputs unchanged.'}
selection=N/'selection.json';assert json.loads(selection.read_text())==captured['settings'];selection.unlink()
assert {f.name for f in N.iterdir()}=={'inputs','work'}
with (O/'prelaunch-check.json').open('x') as f:json.dump(row,f,indent=2)
print(json.dumps(row,indent=2));assert error is None
