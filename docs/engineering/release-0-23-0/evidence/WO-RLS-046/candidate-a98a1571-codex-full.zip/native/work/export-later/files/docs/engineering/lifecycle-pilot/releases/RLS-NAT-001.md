+++
id = "RLS-NAT-001"
type = "release_record"
title = "Release candidate 0.0.1"
status = "released"
owners = ["release-owner"]
created = "2026-10-16"
updated = "2026-10-16"
version = "0.0.1"
commit = "af4b6c9268f8c01b3303ad9e6ef2136059c32929"
git_object_format = "sha1"
prepared_at = "2026-10-16T08:19:39Z"
prepared_by = "release-owner"
evaluator_evidence_path = "docs/engineering/lifecycle-pilot/evidence/RLS-NAT-001-evaluator.json"
evaluator_evidence_sha256 = "1521d0f7b70cf50ac623f3fb80a2d95bdc28293681b809002573d3115629707c"
tag = "v0.0.1"

released_at = "2026-10-16T08:21:09Z"
authorized_by = "release-owner"
[relations]
satisfies = ["REL-NAT-001"]
includes_verification = ["VREC-NAT-001"]
releases_work = ["WO-NAT-001"]

[[lifecycle_events]]
from = "ready"
to = "released"
decided_at = "2026-10-16T08:21:09Z"
decided_by = "release-owner"
reason = "Task-supplied synthetic release decision after gates pass: version 0.0.1, WO-NAT-001 only, verified VREC-NAT-001 at af4b6c9268f8c01b3303ad9e6ef2136059c32929, approved REL-NAT-001. Rehearsal record only; no external actions."
+++

# Release Record Candidate

This ready record proposes release `0.0.1` for `WO-NAT-001` from candidate commit `af4b6c9268f8c01b3303ad9e6ef2136059c32929`. An accountable release owner must review and transition it to `released`; this command did not approve, commit, tag, release, or publish anything.

The release candidate commit may precede the governance commit retaining this record. Any release tag must be created and checked by the authorized release process.
