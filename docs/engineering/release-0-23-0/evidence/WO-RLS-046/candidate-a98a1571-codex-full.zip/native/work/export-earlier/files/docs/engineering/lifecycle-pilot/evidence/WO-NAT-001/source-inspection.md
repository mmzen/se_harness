# Source inspection and evidence review

Inspected the selected immutable inputs/source/src/greeting.py before execution. Exact content:

```python
def greeting():
    return 'Hello rehearsal'
```

Source fixture commit S: 5820415917e87b64d80bad2f7c39c6d18d692829.
File SHA-256: dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1 (45 bytes).
The read digest matches selection.json. Source was not modified.

REQ-NAT-001 and SPEC-NAT-001 prescribe the expected literal independently of execution. The local Windows assertion through the selected client_python exited 0 with stdout `exact greeting passed\n` and empty stderr. Exact record: greeting-assertion.json, SHA-256 56616632c9201204162d100f43f7abc780d683aad1eaa02ad59d38fc84081ae8. No separate type assertion or runtime version is claimed.

Review: the proof needs no implementation change, added architecture, CI changes or additional tests. New definitions and evidence serve only the requested operator proof. The approved work scope names the definitions, risk/decision pair, release contract and evidence component; generated records must directly cover WO-NAT-001. The local fixture identity is distinct from the disposable Git verification candidate and the implementation candidate a98a1571292f5bbf34cd2c7cff0af793d00fa12f.

Limits: one call on this fixture; no production, cross-platform, independent replay or database enforcement claim.
