```toml
artifact = "WO-NAT-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "1eb747da68ac8687959342133ff3299f985c455365f7e1b44174fd7d52567664"
rebound_at = "2026-10-16T08:10:35Z"
```

# WO-NAT-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
