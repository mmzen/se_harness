+++
id = "CAP-NAT-001"
type = "capability"
title = "Inspect and prove the fixture greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
ability = "The test operator can inspect the selected immutable greeting fixture and retrieve proof of its exact return value."

[relations]
derives_from = ["INT-NAT-001"]
+++

# Capability: Inspect and prove the fixture greeting
The operator needs local source inspection and retained assertion evidence for the selected test copy. Both serve the inspectable engineering record in INT-NAT-001. The exact expected value and verification method belong to the linked requirement and verification contract. No source modification or production behavior is included.

