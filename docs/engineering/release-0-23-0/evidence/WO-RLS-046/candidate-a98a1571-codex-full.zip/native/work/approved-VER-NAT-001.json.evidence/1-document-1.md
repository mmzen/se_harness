+++
id = "VER-NAT-001"
type = "verification"
title = "Exact greeting assertion and source evidence"
status = "approved"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"

[relations]
verifies = ["REQ-NAT-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-16T08:04:43Z"
decided_by = "test-owner"
reason = "Apply supplied synthetic definition approval after checklist review and passing gates."
+++

# Verification Contract: Exact greeting assertion and source evidence

## Independence
The expected string comes from REQ-NAT-001 and SPEC-NAT-001 rule NAT-GREET-001, supplied by the test owner. It is not derived from candidate output. test-executor retains execution evidence; quality-owner prepares and assesses the test verification record using supplied synthetic authority.

## Requirement-to-evidence matrix
| Requirement | Method | Case/evidence | Pass condition |
| --- | --- | --- | --- |
| REQ-NAT-001 | test | docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/greeting-assertion.json | The local equality assertion exits 0 and stdout is exact greeting passed. |
| REQ-NAT-001 | inspection | docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/source-inspection.md | The inspected fixture identity matches the selected SHA-256 and its function returns the required literal. |

## Procedure and platform
Use the selected native Windows host and selection.json client_python. Execute the approved native_call.py helper operation `assert-greeting --record C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\release023-053-qualification\native\codex-full\native\work\greeting-assertion.json` once after work starts. This calls greeting() once and asserts equality only; it supplies no separate type assertion or Python version evidence. The helper refuses a source digest mismatch. Inspect src/greeting.py through the bounded reader before execution.

Retain the local record unchanged at the matrix's repository evidence path through the hosted handoff. Preserve the exact command, working directory, exit status, stdout, stderr and elapsed time. The selected source commit is 5820415917e87b64d80bad2f7c39c6d18d692829 and greeting SHA-256 is dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1.

## Assessment and evidence retention
An exception, unequal result, nonzero exit or missing evidence blocks acceptance. The service runs released evaluator 0.22.1 for lifecycle gates; it does not execute the greeting test. Capture a commit-bound VREC for the disposable Git candidate, retaining that candidate separately from the fixture and implementation candidate. Retain requests, receipts and earlier/later exports for independent review.

## Residual uncertainty
This proves one selected fixture call and its retained record, not production behavior, other platforms, database enforcement or independent Git replay. Independent replay is the separate reviewer's task.

