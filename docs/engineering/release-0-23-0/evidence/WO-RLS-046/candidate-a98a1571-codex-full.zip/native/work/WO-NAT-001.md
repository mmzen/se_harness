+++
id = "WO-NAT-001"
type = "work_order"
title = "Prove the immutable greeting with an exported test record"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"

[assurance]
commit_bound_verification = "required"
rationale = "Test verification and release decisions depend on new definitions, traceability and retained evidence at one exact disposable Git candidate."
decided_by = "test-owner"

[execution_scope]
paths = [
  "src/greeting.py",
  "docs/engineering/lifecycle-pilot/intent/INT-NAT-001.md",
  "docs/engineering/lifecycle-pilot/capabilities/CAP-NAT-001.md",
  "docs/engineering/lifecycle-pilot/requirements/REQ-NAT-001.md",
  "docs/engineering/lifecycle-pilot/specifications/SPEC-NAT-001.md",
  "docs/engineering/lifecycle-pilot/verification/VER-NAT-001.md",
  "docs/engineering/lifecycle-pilot/work-orders/WO-NAT-001.md",
  "docs/engineering/lifecycle-pilot/risks/RISK-NAT-001.md",
  "docs/engineering/lifecycle-pilot/decisions/DEC-NAT-001.md",
  "docs/engineering/lifecycle-pilot/release/REL-NAT-001.md",
  "docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/"
]

[relations]
implements = ["REQ-NAT-001"]
specifications = ["SPEC-NAT-001"]
verification = ["VER-NAT-001"]
+++

# Work Order: Prove the immutable greeting

## Objective
Give the test operator inspectable proof that greeting() returns exactly Hello rehearsal and a complete exported engineering record.

## In scope
New NAT-001 definitions, their synthetic approval history, one local assertion, source inspection, one paired risk/decision with mitigation, bounded handoff, commit-bound verification and test release assessment for 0.0.1. Exercise the requested stale-preview, scope-refusal and uncertain-reply cases using retained requests.

## Out of scope
Source edits, imported -900 record changes, real engineering decisions, push, tags, publication, installation, deployment and account or permission changes.

## Authorized decision envelope
test-executor may start approved work, perform the local assertion, retain evidence, hand off and record completion. Use only the task owner's supplied synthetic decisions for definition/work approval, mitigation, verification and release. No agent may invent risk acceptance or expand scope.

## Constraints
Use the selected test project and released evaluator 0.22.1. Preserve the immutable fixture and all accepted records. Local runtime is Windows through the selected client_python. No service endpoint runs source tests.

## Expected change surface
Inspected src/greeting.py is the tested immutable source; the source manifest identifies the tracked snapshot. The new INT, CAP, REQ, SPEC and VER revisions were inspected and provide purpose, behavior and evidence requirements. Their exact paths above include approval writes. This WO records bounded execution. The exact RISK/DEC paths reserve the planned pair; compare the risk preview's returned paths before applying. REL-NAT-001 is completed only after the final VREC establishes its candidate.
The evidence/WO-NAT-001/ component holds greeting-assertion.json, source-inspection.md and the selected work's evaluator handoff outputs. Generated VREC/RLS IDs and evidence paths are unresolved until their command previews; direct records covering this WO and their declared evidence use the released generated-output admission rule. Reassess their actual paths before applying.
No implementation, packaging, CI or caller changes are needed: the task requests proof of an existing immutable no-argument function. No architecture addresses this new requirement. Existing imported history is reference only.

## Required verification
Perform VER-NAT-001 exactly. Require a passing local equality assertion, matching source inspection and released lifecycle gates. Capture the disposable Git candidate in a VREC prepared by quality-owner. Complete and approve the release contract using that verified candidate.

## Evidence to record
Retain exact local output at docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/greeting-assertion.json and inspection at docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/source-inspection.md. Retain exact requests, receipts, read views and exports locally under work/.

## Stop and escalate conditions
Stop the affected operation on fixture mismatch, assertion failure, failed gates, incomplete required reads, protocol mismatch or host permission denial. Recover uncertain replies by the original operation key before choosing another action. Do not broaden scope or change credentials.

## Completion report format
State completed behavior, observed checks, exact source and candidate identities, refusals and unchanged effects, residual uncertainty and the evaluator's next accountable decision. Preserve earlier and later immutable exports.

