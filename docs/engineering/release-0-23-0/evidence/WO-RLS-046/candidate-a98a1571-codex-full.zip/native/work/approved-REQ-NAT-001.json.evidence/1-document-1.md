+++
id = "REQ-NAT-001"
type = "requirement"
title = "Exact local greeting result"
status = "approved"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
statement = "Calling greeting() in the selected local fixture returns exactly Hello rehearsal."
verification_method = ["test", "inspection"]
priority = "must"
source = "test-owner task.md and CAP-NAT-001"
measure = "One exact equality assertion passes and its output is retained."

[relations]
derives_from = ["CAP-NAT-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-16T08:04:43Z"
decided_by = "test-owner"
reason = "Apply supplied synthetic definition approval after checklist review and passing gates."
+++

# Requirement: Exact local greeting result

## Why
The test operator needs reproducible evidence of the selected fixture behavior for the exported engineering record.

## Behavior and acceptance
Given the immutable selected fixture src/greeting.py, when greeting() is called without arguments, the result equals the literal string `Hello rehearsal`. Inspect the source and retain the assertion command, exit status, stdout and stderr. Any exception or unequal result fails the check and prevents a passing verification claim. No additional failure behavior or source changes are specified.

