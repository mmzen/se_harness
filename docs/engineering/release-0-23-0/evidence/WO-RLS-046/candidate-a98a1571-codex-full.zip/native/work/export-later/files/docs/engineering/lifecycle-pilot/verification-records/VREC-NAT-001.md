+++
id = "VREC-NAT-001"
type = "verification_record"
title = "Verification candidate for WO-NAT-001"
status = "verified"
owners = ["quality-owner"]
created = "2026-10-16"
updated = "2026-10-16"
commit = "af4b6c9268f8c01b3303ad9e6ef2136059c32929"
git_object_format = "sha1"
worktree_state = "clean"
prepared_at = "2026-10-16T08:12:43Z"
prepared_by = "quality-owner"
artifact_snapshot_sha256 = "5f0e46385cd4d06c2d8b0cf256a86c8061573353714c764b544fcefce7379ea3"
evidence_paths = ["docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/WO-NAT-001-handoff.md", "docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/greeting-assertion.json", "docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/handoff.json", "docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/source-inspection.md"]
evaluator_evidence_path = "docs/engineering/lifecycle-pilot/evidence/VREC-NAT-001-evaluator.json"
evaluator_evidence_sha256 = "2762aeaa36f7fe172361be82edb9420da8a316d972c443f2f0a37bfc54d25bc6"

verified_at = "2026-10-16T08:13:38Z"
verified_by = "quality-owner"
[relations]
verifies_work_order = ["WO-NAT-001"]
conforms_to = ["VER-NAT-001"]

[[lifecycle_events]]
from = "ready"
to = "verified"
decided_at = "2026-10-16T08:13:38Z"
decided_by = "quality-owner"
reason = "Supplied synthetic verification decision: exact local greeting assertion and source inspection pass VER-NAT-001 for the bound disposable candidate."
+++

# Verification Record Candidate

This ready record binds retained evidence for `WO-NAT-001` to candidate commit `af4b6c9268f8c01b3303ad9e6ef2136059c32929`. Preparation uses each selected work order's recorded execution approval. An accountable assurance owner must review the evidence and transition the record to `verified`; this command did not approve, commit, tag, release, or publish anything.

The record is intentionally created after the candidate commit it names, avoiding self-referential commit metadata.
