+++
id = "RISK-NAT-001"
type = "risk"
title = "Loss of binding between local assertion and tested fixture"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
description = "If the local assertion is exported without its source identity and exact output, the operator could mistake a different fixture or candidate for the tested greeting. This threatens the inspectable proof in WO-NAT-001."
action = "Retain the exact assertion and source inspection, bind them through WO-NAT-001 handoff and commit-bound verification, and preserve both exports for review."
raised_by = "test-owner"

[relations]
threatens = ["WO-NAT-001"]
mitigated_by = ["WO-NAT-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-16T08:09:08Z"
reason = "Supplied synthetic mitigation choice: retain exact assertion and source identity under WO-NAT-001 and bind the evidence through verification."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-16T08:08:00Z"
decided_by = "test-owner"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-16T08:09:08Z"
decided_by = "test-owner"
reason = "Supplied synthetic mitigation choice: retain exact assertion and source identity under WO-NAT-001 and bind the evidence through verification."
+++

# Risk: Loss of binding between local assertion and tested fixture

## Description

If the local assertion is exported without its source identity and exact output, the operator could mistake a different fixture or candidate for the tested greeting. This threatens the inspectable proof in WO-NAT-001.

## Next action

Retain the exact assertion and source inspection, bind them through WO-NAT-001 handoff and commit-bound verification, and preserve both exports for review.
