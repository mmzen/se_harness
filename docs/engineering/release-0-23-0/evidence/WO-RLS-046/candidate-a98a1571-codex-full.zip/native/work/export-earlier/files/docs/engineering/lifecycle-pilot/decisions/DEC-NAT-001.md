+++
id = "DEC-NAT-001"
type = "decision"
title = "Answer to the threat Loss of binding between local assertion and tested fixture"
status = "decided"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
kind = "question"
question = "How is the threat 'Loss of binding between local assertion and tested fixture' answered: accept, avoid or mitigate?"
raised_by = "test-owner"
recommendation = "mitigate"

[[options]]
id = "accept"
label = "Accept the threat; record a residual and a revisit trigger."

[[options]]
id = "avoid"
label = "Avoid the threat by a design change recorded in an ADR or a decision."

[[options]]
id = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."

[relations]
concerns = ["RISK-NAT-001", "WO-NAT-001"]
blocks = ["WO-NAT-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-16T08:09:08Z"
reason = "Supplied synthetic mitigation choice: retain exact assertion and source identity under WO-NAT-001 and bind the evidence through verification."

[[lifecycle_events]]
from = "open"
to = "decided"
decided_at = "2026-10-16T08:09:08Z"
decided_by = "test-owner"
reason = "Supplied synthetic mitigation choice: retain exact assertion and source identity under WO-NAT-001 and bind the evidence through verification."
+++

# Decision: Answer to the threat Loss of binding between local assertion and tested fixture

## Question

How is the threat 'Loss of binding between local assertion and tested fixture' answered: accept, avoid or mitigate? The description and the threatened artifacts are on RISK-NAT-001.

## Options

- `accept`: Accept the threat; record a residual and a revisit trigger.
- `avoid`: Avoid the threat by a design change recorded in an ADR or a decision.
- `mitigate`: Mitigate the threat through a work order; the risk closes under verified coverage.

## Recommendation

The raiser recommends `mitigate`.

## Disposition

Written by `harnessctl decide`; do not edit by hand. Disposing this decision
moves RISK-NAT-001 to the state the chosen option names, in the same act.
