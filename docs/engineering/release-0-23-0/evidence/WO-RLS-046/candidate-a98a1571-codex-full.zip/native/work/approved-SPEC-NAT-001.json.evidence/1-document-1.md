+++
id = "SPEC-NAT-001"
type = "specification"
title = "Literal greeting fixture contract"
status = "approved"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
contract = "The selected greeting() call returns exactly Hello rehearsal without modifying the fixture."

[relations]
specifies = ["REQ-NAT-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-16T08:04:43Z"
decided_by = "test-owner"
reason = "Apply supplied synthetic definition approval after checklist review and passing gates."
+++

# Specification: Literal greeting fixture contract

## Scope
This contract governs the selected immutable src/greeting.py fixture. It prescribes only the behavior needed for the operator's proof; no new architecture or implementation mechanism is needed.

## Rules
**NAT-GREET-001.** Calling greeting() without arguments MUST return exactly the literal string `Hello rehearsal`.

## Failure behaviour
An exception or unequal result fails the local verification assertion. Retain the failure output; do not rewrite the fixture or report a pass.

## Example
Given the selected source snapshot, when greeting() is invoked, then `greeting() == "Hello rehearsal"` is true.

## Coverage
| Requirement | Rules |
| --- | --- |
| REQ-NAT-001 | NAT-GREET-001 |

