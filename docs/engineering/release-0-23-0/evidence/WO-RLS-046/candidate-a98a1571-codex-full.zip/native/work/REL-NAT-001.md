+++
id = "REL-NAT-001"
type = "release_contract"
title = "Test greeting release 0.0.1"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
candidate_commit = "af4b6c9268f8c01b3303ad9e6ef2136059c32929"
[relations]
gates = ["WO-NAT-001"]
+++

# Test greeting release 0.0.1

## Release unit
The disposable hosted rehearsal records version 0.0.1 for WO-NAT-001 at the exact candidate above. Its outcome is inspection of the existing source and a local assertion that greeting() returns exactly `Hello rehearsal`. The source is unchanged. No real tag, publication, installation or deployment is authorized.

## Required evidence
Require WO-NAT-001 implemented and the one final VREC-NAT-001 verified for exactly that work order and candidate. Retain the exact local assertion record, source inspection, work handoff and generated evaluator sidecars. The assertion must exit zero and report `exact greeting passed`; source inspection must agree with the selected immutable source blob. Earlier and later immutable exports support independent reviewer reconstruction with released evaluator 0.22.1; reconstruction is not claimed by this record.

## Compatibility and migration
No code, API, data or dependency change is made. There is no migration. The single local equality assertion establishes only the supplied no-argument greeting outcome on the observed local runtime.

## Security and provenance
Use the selected released evaluator identity and unchanged evidence bytes. Keep the original VREC candidate binding, which differs from the source fixture commit and the later governance head. No credentials or external account settings are part of the evidence. A mismatched candidate, missing evidence, changed bytes or failed gate prevents release assessment.

## Promotion policy
Only the disposable test RLS may become released after its gates pass, under the task's synthetic release-owner decision for version 0.0.1. This transition records an assessment; it executes no external delivery action. The required wire tag value v0.0.1 is a test record label only, not permission to create a Git tag.

## Human approval triggers
The task supplies conditional synthetic approval for this bounded test release. Any different candidate, work set, version or external action requires separate matching authority; stop the affected action if the supplied conditions no longer match.

## Rollback criteria and procedure
If evidence, candidate binding or gate results disagree, stop progression and retain the precise failure for review. Preserve immutable records and exports. There is no deployed system to roll back and no destructive reset is authorized.

## Post-release observation window
At the end of this rehearsal, inspect the resulting RLS state and candidate coverage, retain a new immutable export and report any uncertainty. The independent reviewer subsequently reconstructs the two exported histories and checks exact bytes and original candidate bindings.

