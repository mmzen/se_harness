+++
id = "CAP-NAT-001"
type = "capability"
title = "Inspect and prove the fixture greeting"
status = "approved"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"
ability = "The test operator can inspect the selected immutable greeting fixture and retrieve proof of its exact return value."

[relations]
derives_from = ["INT-NAT-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-16T08:04:43Z"
decided_by = "test-owner"
reason = "Apply supplied synthetic definition approval after checklist review and passing gates."
+++

# Capability: Inspect and prove the fixture greeting
The operator needs local source inspection and retained assertion evidence for the selected test copy. Both serve the inspectable engineering record in INT-NAT-001. The exact expected value and verification method belong to the linked requirement and verification contract. No source modification or production behavior is included.

