The disposable hosted rehearsal reached work completion, verified test evidence and a released test record for version 0.0.1. The local assertion passed: `greeting() == "Hello rehearsal"`, with exit 0, stdout `exact greeting passed\n` and empty stderr. The existing source was inspected and left unchanged. This report records observed behavior, including procedural and capture limitations; it is not a claim of independent replay or real release authority.

The selected project is `3209fd5c-0c20-484c-9d9f-b60e4aa28559` at `http://127.0.0.1:64853`; context `fa25fa20-7fd9-4f6e-bd95-f10ba0a6413b` ends at version 27, project version 29. [Final status](status-final.json.stdout.txt) reports schema 2, ready, test-copy and sandbox-projection. Readiness and checkpoint-free graph reporting are distinct from passed transition gates.

| Identity | Exact value |
| --- | --- |
| Candidate client | 0.23.0; wheel SHA-256 `f2fbc394a65da29fcdb02eb6994dc08e7bc8ad6248b8ddad440021c68e583e16` |
| Released governor | 0.22.1; archive SHA-256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`; payload SHA-256 `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff` |
| Source fixture S | `5820415917e87b64d80bad2f7c39c6d18d692829` |
| Disposable verification/release candidate P | `af4b6c9268f8c01b3303ad9e6ef2136059c32929` |
| Actual qualification candidate C | `a98a1571292f5bbf34cd2c7cff0af793d00fa12f` |
| Import baseline B | `se-harness-artifact-baseline/v1:sha256:0047df22322147bb2895927dc8120af98789e9c403282364a397d4a89071f940` |
| VREC capture input baseline B | `se-harness-artifact-baseline/v1:sha256:7af362e26d8f7260bc3591bb8cbd0dbfc78ecf4c0f4c670cd6ef684e68b5ea3f` |
| First accepted lifecycle input Git base | `4a7a80651ebaff54ec80292aa8e3ffa1d3a00b5d` |

The Codex plugin component is 0.2.7, archive SHA-256 `baade3dff402e2da52b8bf0b4607a00476e63661405384f99f6523091d5a7c72`. Its bundled evaluator is 0.23.0; the service's governor is separately pinned to 0.22.1. The full selected combination, including database/server/runtime identities, is retained in final status. The source fixture is a Git-blob snapshot without local Git metadata. P binds the test records and does not verify C.

| Case | Observed outcome and exact retained evidence | Limit |
| --- | --- | --- |
| Definitions | New INT/CAP/REQ/SPEC/VER-NAT-001 reviewed and approved. [Input assessment](input-assessment.md), [approval request](definitions-apply-request.json), [recovered receipt](definitions-recovery-result.json.stdout.txt). | Draft admission assesses shape/links; substantive agent review is separate. |
| Work approval | WO-NAT-001 approved by test-owner, eleven scope paths. [Approval](wo-approval-apply-result.json), [decoded exact WO](mcp-revision-decoded-envelope.json). | Conditional synthetic authority only. |
| Start | WO-NAT-001 started by test-executor. [Start result](start-apply-result.json). | Separate from approval/completion. |
| Local verification | Exact equality assertion passed and source matched. [Assertion record](greeting-assertion.json), [stdout](greeting-assertion.json.stdout.txt), [inspection](source-inspection.md). | One Windows local assertion; no separate type assertion or Python-version claim; no service source test. |
| Risk decision | DEC-NAT-001 chose mitigate; RISK-NAT-001 is mitigating and linked to WO-NAT-001. [Decision](export-earlier/files/docs/engineering/lifecycle-pilot/decisions/DEC-NAT-001.md), [risk](export-earlier/files/docs/engineering/lifecycle-pilot/risks/RISK-NAT-001.md). | No risk acceptance or automatic closure. |
| Stale preview | After an INT draft edit, service refused 409 HAG_REMOTE_STALE_PREVIEW. [Request](stale-preview-request.json), [result](stale-preview-result.json.stdout.txt). | No receipt, affected artifacts or files. Refusal versions are null, not invented equal counters; fresh acceptance used post-edit guards 15/13. |
| Uncertain reply | Definitions apply exited 2 with unknown transport outcome. Original-key lookup recovered acceptance. [Submission](definitions-apply-result.json), [lookup](definitions-recovery-result.json). | Initial failure alone did not prove acceptance. |
| Identical retry | A separate rehearse submission of the identical request returned the same complete receipt and versions. [Retry command](definitions-identical-retry.json), [retry output](definitions-identical-retry.json.stdout.txt). | Lookup and resubmission are distinct observations. |
| Changed request/key | Changed approval reason under accepted key refused 409 HAG_REMOTE_KEY_REUSE. [Request](definitions-changed-key-request.json), [result](definitions-changed-key-result.json). | No receipt, affected artifacts or files. |
| Protected handoff | First negative handoff refused 422 HAG_REMOTE_PROTECTED_FIELD. [Result](handoff-outside-result.json). | Formal/instruction guard refusal; this alone did not establish scope enforcement. |
| Out-of-scope handoff | Second negative handoff refused 422 HAG_REMOTE_EVALUATOR_REFUSED with QGP-G4I-PATHS/WEX201 for evidence/WO-NAT-002/greeting-assertion.json. [Request](handoff-scope-request.json), [result](handoff-scope-result.json.stdout.txt). | WO remained in_progress; mutation writes, affected artifacts and files empty. Valid handoff used the unchanged 20/18 version guards. |
| Valid handoff | Scoped evidence accepted using the first lifecycle input base. [Retained base](retained-base.json), [result](handoff-valid-apply-result.json). | The later start head was not substituted for the base. |
| Completion | WO-NAT-001 implemented by test-executor. [Completion](complete-apply-result.json), [exact revision](mcp-revision.json). | Completion does not itself verify/release. |
| Verification | VREC-NAT-001 prepared ready, then verified by quality-owner. [Preparation](vrec-apply-result.json), [decision](verify-apply-result.json), [final VREC](export-later/files/docs/engineering/lifecycle-pilot/verification-records/VREC-NAT-001.md). | Exact candidate P retained. |
| Release contract | REL-NAT-001 authored and approved for P and WO-NAT-001. [Approved read](rel-approved-read.json). | Test version 0.0.1; no external delivery authorization. |
| Release preparation | RLS-NAT-001 prepared ready by release-owner. [Preparation](rls-apply-result.json), [ready record](export-rls-review/files/docs/engineering/lifecycle-pilot/releases/RLS-NAT-001.md). | Preparation's next-step checkpoint is not_assessable; not reported as gate passage. |
| Release decision | Transition preview and apply gates pass; RLS-NAT-001 released. [Preview](release-preview-result.json.stdout.txt), [accepted result](release-apply-result.json.stdout.txt), [final record](export-later/files/docs/engineering/lifecycle-pilot/releases/RLS-NAT-001.md). | Final checkpoint-free [check](mcp-final-release-check.json) is not_assessable for the next external action. |

The uncertain operation key was `native-definitions-apply`. Its accepted request digest is `sha256:1d833e305c3c07f0b6202262612b8ad3e9134965c4f5bea7e1b6310baaf01c6a`, receipt `sha256:970577d3cb75fc8a26f7d3c428f72c7ec9ff684e59c609cb10f290a941594dc8`. Lookup and retry stdout have identical SHA-256 `6b47716ae0b993c99b4f4f929a89070f1ef16383f54f51a79744ea0d44765b08`; original and retry command argv are identical. Both return project 15→16 and context 13→14, establishing one retained effect. The original request file has SHA-256 `e142018d236d709363dc2629de7c3b2492619022ad62bb10ee699577d387eb9e`; the changed request has SHA-256 `14a6647ef9e3b74bd9252360f17a370c7239e4bea7a0b54adc0df8b1de7df2c9`.

The retained assertion record SHA-256 is `56616632c9201204162d100f43f7abc780d683aad1eaa02ad59d38fc84081ae8`; stdout SHA-256 is `a6e0ec4f9e6f8c034dd347f6ae199dc837bd769183e10293f49f5b6b9a861607`. The 45-byte source SHA-256 is `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`. The final manifest retains those same source and assertion digests at P and the later governance snapshot. Source and imported -900 file metadata agree between the two exports; no decisions targeted imported history.

| MCP tool | Meaningful selected view and observation | Saved exact request/response |
| --- | --- | --- |
| work-context | Context 12, draft WO and its five governing definitions | [mcp-work-context.json](mcp-work-context.json) |
| check | Context 17, open paired DEC; checkpoint-free context reporting | [mcp-check.json](mcp-check.json) |
| revision | Context 20, exact implemented WO; raw document decoded and read | [mcp-revision.json](mcp-revision.json) |
| cypher | Context 25, release-record reservation query returned no rows | [mcp-cypher.json](mcp-cypher.json) |
| impact | Final immutable baseline, REQ reverse reachability returned eight artifacts | [mcp-impact.json](mcp-impact.json) |
| lineage | Final immutable baseline, RLS linked REL/VER/VREC/WO records | [mcp-lineage.json](mcp-lineage.json) |
| compare | Earlier and later immutable baselines; REL/RLS/VREC added, WO binding changed | [mcp-compare.json](mcp-compare.json) |

All seven responses are `complete:true`, `continuation:null`, with no unresolved references. The additional final RLS check is the eighth MCP call. Saved results were read through the bounded helper. Completeness applies only to the selected question/view and does not grant approval or assurance.

| Export | Exact immutable identities | Retained bytes |
| --- | --- | --- |
| [Earlier manifest](export-earlier/manifest.json) | B `se-harness-artifact-baseline/v1:sha256:c25fdee338117791d70ffc0991588e58d772cfd8262061ef6d7ba58ee77d7eaf`; snapshot `sha256:fa038ac75059e99b7de26e36b56e6285c1fcbf4a5b0d38c2b955cb7fdb542c5b`; head `b12a919655c5110528d70a6daf388367a2c969c0` | 24 files; manifest SHA-256 `8d9ef2d7a7943c3345f96712fc8a8e6de015813af7452075cc17a6a69d937cad`; bundle 20,676 bytes, SHA-256 `dd488c4b24aba82743493b1d0bc2169f5c69110cd13656b37507fa12aeb8ea78` |
| [Later manifest](export-later/manifest.json) | B `se-harness-artifact-baseline/v1:sha256:fefbbc196057c4f1f57ca89785831d6173150052a1ae4d389a10998d7c488191`; snapshot `sha256:d2e18d26e15d0aa831da7702c53a62378342777562b728882745c2d18f1856e9`; head `6e71d0854cd2d416c1306fc87fe5bfb574c69b4b` | 29 files; manifest SHA-256 `a984209ab90d5004d04f73bc7e3bf34842e1db41ae8fdad3d69cfe2b94a1ad79`; bundle 27,788 bytes, SHA-256 `0094eba77534844412181cdaa9779f29b871e2bc7f097659862a223097863787` |

Both destinations were new and remain separate. Additional exports `export-vrec-review/` and `export-rls-review/` retain prepared records and sidecars inspected before decisions. Download success is established; independent reconstruction/replay is **not performed** by this agent. The final governance head differs from P; original VREC/RLS bindings were not rewritten.

Material limitations and errors remain part of the result:

- Instructions were explicitly read from the selected candidate. Automatic startup delivery is untested. COMMUNICATION was discovered/read after the first English explanation; later reading does not satisfy that earlier timing requirement.
- Some large tool outputs were truncated. Needed fields were read subsequently; metadata alone was not treated as full content. One reference-selection expression returned an empty substring and supplies no new visible-content evidence.
- Recovered operator errors included a read-text limit of 6000 (allowed maximum 4096), unavailable JavaScript `structuredClone`, a release-export read missing its `files/` directory, and a failed aggregate command-record read followed by a JSON parse error on a Traceback. The aggregate reader failure cause was not assessed; a selected record was then read with a narrower pointer. These were tool/reader/orchestration problems, distinct from service refusals. The capture retains additional native failure IDs whose detailed mapping is not available in its summary; no cause is invented.
- The initial negative handoff hit a protected-file guard before scope evaluation; the second test is the actual scope-refusal evidence. Neither was a host permission rejection. No permission escalation, credential change or account intervention occurred.
- VREC's generated evaluator sidecar reports origin-version inspection with null archive/payload hashes. Full evaluator identity is separately retained in status/receipts and the RLS full-payload sidecar. Generated VREC/RLS prose retains ready-template wording after transition; front matter, lifecycle history and receipts establish actual states.
- The historical W-AUT-022 warning on SPEC-P3-900 remains an unrelated advisory. No historical artifact was edited to remove it.
- The helper's closed lifecycle check shape has no standalone transition-target/planned-path checkpoint. Transition previews provided actual transition gates; scope enforcement is evidenced by the handoff evaluator. No unsupported check is claimed.
- Local source has no Git metadata; reservation inspection used the hosted selected view and disposable preparation. No real Git tag, push, installation, publication or deployment was performed.

[The report capture](observations-report-capture.json) reports 260 observed native tool items, eight native failed-item entries and five nonzero command records: one uncertain transport and four service refusals. These are distinct, potentially overlapping measurements, not additive failure totals. Total native calls, wall duration and peak context are unavailable; the snapshot is explicitly incomplete and excludes subsequent reporting reads/writes. The earlier final-capture index contains 79 command records and 78 successful visible-read entries; it is not a complete execution count. The raw capture's content_review is “not performed by this summary”; substantive review described above was performed separately.

[Structured observations](native-observations.json) retain exact IDs, views, keys, selected read paths/hashes with triggers, case outcomes and limitations. [Input assessment](input-assessment.md) ties definitions to the supplied outcome. Requests, command argv, complete stdout/stderr and decoded draft evidence remain under this directory. All actors and decisions are synthetic task inputs; no new human intervention was requested.

The next accountable step for this qualification is the independent reviewer's reconstruction of the earlier and later exports and released-0.22.1 checks of exact bytes and original candidate bindings. The evaluator's next engineering step is authorization for an exact external action, but no external action is selected by this task.

