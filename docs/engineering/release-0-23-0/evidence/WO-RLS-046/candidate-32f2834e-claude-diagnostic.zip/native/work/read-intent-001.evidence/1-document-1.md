+++
id = "INT-P3-001"
type = "intent"
title = "Adapt the rehearsal greeting for a new audience"
status = "draft"
owners = ["test-owner"]
created = "2026-10-13"
updated = "2026-10-13"
outcome = "An operator can read a greeting adapted for a new audience."

[relations]
+++

# Intent: Adapt the rehearsal greeting for a new audience

## In plain words

The existing rehearsal greeting serves one fixed audience. This intent covers adapting the greeting so that a new audience receives an appropriate greeting.

## Problem

The `greeting()` function returns the fixed string `Hello rehearsal`. An operator who needs to address a new audience has no way to produce a different greeting. The existing definitions (INT-P3-900 through WO-P3-900) govern only the current fixed greeting and do not cover adaptation for other audiences.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| The new audience receives an adapted greeting | not measured | The adapted greeting is returned for the new audience | Manual operator inspection after delivery |

## Not this

- Changes to the existing fixed greeting for the current audience (governed by INT-P3-900). *(confirmed by task constraint)*
- Approval, release or lifecycle decisions beyond this draft. *(confirmed by task constraint)*
- New infrastructure, deployment or external integrations. *(proposed for confirmation)*
