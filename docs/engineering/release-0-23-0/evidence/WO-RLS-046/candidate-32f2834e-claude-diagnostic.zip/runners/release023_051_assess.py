"""Independent reads and the reviewed semantic assessment of this exact trial."""
import base64,hashlib,json,time,tomllib,urllib.request
import hag_efficiency_plan as p
O=p.W/'release023-051-qualification/native/claude-diagnostic';N=O/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(name,value):
    with (O/name).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
s=load(O/'selection.json');token=next(x['token'] for x in load(O/'credentials.json')['principals'] if x['id']=='operator')
def read(label,request):
    url=s['endpoint']+'/v1/projects/'+s['project_id']+'/reads/revision'
    body=json.dumps(request,separators=(',',':')).encode();start=time.monotonic()
    with urllib.request.urlopen(urllib.request.Request(url,data=body,headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'},method='POST'),timeout=30) as response:
        code=response.status;raw=response.read();v=json.loads(raw)
    put(label+'.json',{'method':'POST','url':url,'request':request,'http_status':code,'response':v,'response_sha256':sha(raw),'seconds':time.monotonic()-start,'credential':'Authorization omitted; generated private test operator only'})
    assert code==200 and v['complete']
    content=base64.b64decode(v['data']['document_base64'],validate=True)
    assert sha(content)==v['data']['envelope']['document_sha256']
    return v,content
observed=load(O/'independent-observations.json');assert observed['project_version']==4
request=load(N/'work/read-intent-001.evidence/1-request.json')
v,content=read('independent-authored-revision',request)
assert content==(N/'work/INT-P3-001.md').read_bytes()==(N/'work/read-intent-001.evidence/1-document-1.md').read_bytes()
assert tomllib.loads(content.decode().split('+++')[1])['status']=='draft'
imported=load(N/'work/import-001.evidence/1-response.json');baseline=imported['view']['baseline_id'];originals=[]
for item in imported['affected_artifacts']:
    req={'schema':'se-harness-graph-read/v1','operation':'revision','project_id':s['project_id'],'view':{'kind':'baseline','baseline_id':baseline},**item,'budget':{'rows':1,'bytes':2097152,'depth':0}}
    result,raw=read('independent-imported-'+item['artifact_id'],req)
    path=result['data']['envelope']['original_path'];assert raw==(N/'inputs/source'/path).read_bytes()
    originals.append({'artifact_id':item['artifact_id'],'path':path,'sha256':sha(raw),'matches_original':True})
summary=load(O/'mechanical-summary.json')
assert not summary['native_failures'] and not any(x['is_error'] for x in observed['results'])
assert observed['host_boundary_unchanged'] and not observed['input_changes']
mutations=[]
for name in ('import-001','draft-open-001','create-intent-001','revise-intent-001'):
    result=load(N/('work/'+name+'.evidence/1-response.json'))
    mutations.append({'record':name,'outcome':result.get('outcome'),'project_version':result.get('project_version')})
assessment={
 'candidate':s['qualification_candidate'],'case':'EFF-04A2','trial':'claude-diagnostic','overall':'fail',
 'method':'Independent semantic review against unchanged VER-HAG-008 using the request, original fixture, visible input table, authored document, report, final reply and complete paired calls/results. Separate HTTP revision reads confirm the actual saved bytes and every imported record. No table/keyword detector decides content readiness.',
 'blocking_findings':[
  {'id':'R23-NATIVE-007','criterion':'Missing-input handling and supported completeness',
   'finding':'The new table is present but incorrectly marks every required input supplied. It treats not measured, an allowed baseline, as the success measure, and infers the user problem from the fixed greeting. It asks no question about the missing agreed operational outcome or measure. The saved draft and final reply still claim complete content. This directly fails the unchanged EFF-04A2 criterion.',
   'evidence':['native/events.jsonl: visible input assessment at event 125','native/work/INT-P3-001.md: Problem and Success measures','native/work/native-report.md: Content readiness and Independent content review','independent-observations.json: final_reply'],
   'effect':'Required diagnostic fails; stop further native repetitions on this candidate and keep aggregate verification unready.'},
  {'id':'R23-NATIVE-008','criterion':'Supported statements and faithful reporting of effects',
   'finding':'The table asserts that operators cannot use the current greeting for a new audience, and the draft says an operator has no way to produce a different greeting. The fixture establishes one fixed function, not those wider usage/capability facts. The draft also treats retaining the current fixed greeting for its audience as confirmed scope, whereas the task protects imported records and the fixture during this exercise. Separately, the final reply calls the saved-revision read a fifth mutation; actual accepted writes are import, draft-open, create and revise, reaching project version 4.',
   'evidence':['native/events.jsonl: visible input assessment at event 125','native/work/INT-P3-001.md: Problem and Not this','native/work/native-report.md: No unsupported claims statement','independent-observations.json: final_reply and actual calls/results','independent-status.json: project_version'],
   'effect':'The content/report does not satisfy the existing source-support and actual-effect reporting rules.'}
 ],
 'instruction_adherence_observation':'The explicit input table appeared after create-artifact, not before creating the draft as the reviewed guide requests. It did appear before writing the authored document. Exposing the table made the reasoning error visible but did not correct it; this observation is not a new acceptance gate.',
 'passed_observations':['Exactly one new intent remains draft with the selected synthetic owner and domain.','The revised guide was delivered with SHA-256 57a6fb26a8710381620ca0d579c53f442c397db66e2d7be1004db686604b6b64.','An explicit input-assessment table appeared, and the final report reused its categories.','The newly proposed infrastructure limit is labeled proposed in both draft and report; that part improved.','The separate saved-revision read matches authored and native-readback bytes.','All seven imported records retain their original staged bytes.','No native tool call failed or was denied; the reported observation snapshot accurately excludes the later report write.','Staged inputs and inspected host settings are unchanged.'],
 'service_boundary':'Storage and draft admission worked. Structural admissibility and an empty incomplete list do not establish semantic completeness; no service defect is inferred from allowing an incomplete draft.',
 'readback':{'document_sha256':sha(content),'project_version':observed['project_version'],'accepted_mutations':mutations,'imported_artifacts':originals},
 'metrics':observed['metrics'],
 'comparison':{'previous_candidate':'74feac0767f33658b31fb9e9ad2b6a13a188c13c','previous_seconds':502.774,'previous_peak_input_context':71591,'current_seconds':observed['metrics']['wall_seconds'],'current_peak_input_context':observed['metrics']['peak_input_context'],'limit':'Different instruction candidates, one failed negative diagnostic each. Lower observed cost is not proven general speed improvement or successful authoring.'},
 'simplicity_review':'One shared guide gained 75 words, with no new runtime, tool or required repository file. The explicit assessment is observable and reused, but its supplied-versus-missing judgment is still wrong. Another unsupported completion claim prevents success despite lower observed cost.',
 'separate_execution_events':['A pre-run provenance inspection guessed the wrong plugin archive root. The path was recovered from native-selection.json and all checks passed before the first native invocation; no native trial was retried.'],
 'limits':['First diagnostic failed; no subsequent native repetition, Codex, positive or full native case on this candidate.','Earlier failures retain their original verdicts.','Remaining current-combination walkthrough/recovery, local upgrade and native lifecycle/delivery checks are not claimed by this result.','Separate desktop evidence remains pending.','No completion, human verification, merge, release or public delivery decision is inferred.'],
 'next':'Retain and publish the exact result. A different correction needs reviewed scope and a new candidate. Do not repeat this candidate until a pass, feed expected answers or weaken its criteria.'
}
put('independent-assessment.json',assessment)
print(json.dumps({'overall':assessment['overall'],'findings':[x['id'] for x in assessment['blocking_findings']],'imported_bytes_confirmed':len(originals),'document_sha256':sha(content),'metrics':assessment['metrics']}))
