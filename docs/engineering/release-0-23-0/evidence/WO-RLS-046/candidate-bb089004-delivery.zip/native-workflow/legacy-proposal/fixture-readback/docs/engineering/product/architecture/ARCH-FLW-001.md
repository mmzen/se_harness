+++
id = "ARCH-FLW-001"
type = "architecture"
title = "ARCH-FLW-001"
status = "approved"
owners = ["owner"]
created = "2026-08-11"
updated = "2026-08-11"
[decision_assessment]
outcome = "no_significant_decision"
triggers = []
rationale = "Disposable plain-text note, no architecture change."
assessed_by = "technical-owner"

[relations]
addresses = ["REQ-FLW-001"]
conforms_to = ["SPEC-FLW-001"]
+++

# ARCH-FLW-001

Retain the existing local filesystem layout.
