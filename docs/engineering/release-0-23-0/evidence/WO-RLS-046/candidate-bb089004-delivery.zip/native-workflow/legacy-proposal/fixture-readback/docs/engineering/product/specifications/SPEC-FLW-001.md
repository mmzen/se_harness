+++
id = "SPEC-FLW-001"
type = "specification"
title = "SPEC-FLW-001"
status = "approved"
owners = ["owner"]
created = "2026-08-11"
updated = "2026-08-11"


[relations]
specifies = ["REQ-FLW-001"]
+++

# SPEC-FLW-001

Use plain UTF-8 files below notes/. No runtime, network, configuration or authority behavior changes.
