+++
id = "REQ-FLW-001"
type = "requirement"
title = "REQ-FLW-001"
status = "approved"
owners = ["owner"]
created = "2026-08-11"
updated = "2026-08-11"
statement = "THE SYSTEM SHALL provide fixture notes with the exact text selected by the work order."
verification_method = "automated-test"

[relations]
derives_from = ["CAP-FLW-001"]
+++

# REQ-FLW-001

Accept when the selected note exists and its UTF-8 text matches the work-order acceptance text.
