# Fixture preparation

Execution checks are pending.
