+++
id = "CAP-FLW-001"
type = "capability"
title = "CAP-FLW-001"
status = "approved"
owners = ["owner"]
created = "2026-08-11"
updated = "2026-08-11"


[relations]
derives_from = ["INT-FLW-001"]
+++

# CAP-FLW-001

The fixture reader can read plain-text notes.
