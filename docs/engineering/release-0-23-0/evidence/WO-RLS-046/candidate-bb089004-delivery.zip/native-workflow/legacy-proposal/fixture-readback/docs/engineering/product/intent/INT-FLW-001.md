+++
id = "INT-FLW-001"
type = "intent"
title = "INT-FLW-001"
status = "approved"
owners = ["owner"]
created = "2026-08-11"
updated = "2026-08-11"


[relations]

+++

# INT-FLW-001

Disposable fixture only. Make small notes available to the fixture reader.
