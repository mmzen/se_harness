+++
id = "VER-FLW-001"
type = "verification"
title = "VER-FLW-001"
status = "approved"
owners = ["owner"]
created = "2026-08-11"
updated = "2026-08-11"


[relations]
verifies = ["REQ-FLW-001"]
+++

# VER-FLW-001

Read the selected note as UTF-8 and assert exact equality with its work-order acceptance text. Retain command, output and exit code.
