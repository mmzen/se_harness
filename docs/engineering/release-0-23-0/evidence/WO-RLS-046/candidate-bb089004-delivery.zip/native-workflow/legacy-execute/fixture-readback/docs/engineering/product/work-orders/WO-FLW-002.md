+++
id = "WO-FLW-002"
type = "work_order"
title = "Provide the planned fixture note"
status = "draft"
owners = ["engineering-owner"]
created = "2026-10-16"
updated = "2026-10-16"
evidence_paths = ["docs/engineering/product/evidence/WO-FLW-002/"]

[execution_scope]
paths = [
  "notes/future.txt",
  "docs/engineering/product/work-orders/WO-FLW-002.md",
  "docs/engineering/product/evidence/WO-FLW-002/",
]

[relations]
implements = ["REQ-FLW-001"]
specifications = ["SPEC-FLW-001"]
architecture = ["ARCH-FLW-001"]
verification = ["VER-FLW-001"]
+++

# Work Order: Provide the planned fixture note

## Objective

A future fixture reader can read notes/future.txt containing exactly `planned` followed by one LF: UTF-8 bytes 70 6c 61 6e 6e 65 64 0a.

## In scope

Create the note, update this work-order record, and retain its verification evidence in the declared directory.

## Out of scope

Other notes, WO-FLW-001, accepted definitions, runtime behavior, configuration, CI, release and operating changes.

## Authorized decision envelope

After approval, the implementer may choose local write and check commands within scope. Changes to acceptance text, scope, definitions or assurance classification require the accountable human's decision.

## Constraints

Use plain UTF-8 without a BOM, one trailing LF and the existing filesystem layout. Reuse INT-FLW-001, CAP-FLW-001, REQ-FLW-001, SPEC-FLW-001, ARCH-FLW-001 and VER-FLW-001 unchanged.

## Expected change surface

- notes/future.txt: new reader-facing note; absent during inspection.
- docs/engineering/product/work-orders/WO-FLW-002.md: bounded plan and later execution report.
- docs/engineering/product/evidence/WO-FLW-002/: retained check commands, output and exit codes.

Inspected notes/note.txt, the product definitions, WO-FLW-001 and its evidence. No runtime, callers, packaging, CI or separate test suite is present in this fixture. The existing exact-text contract covers verification; no supporting code or documentation change is needed. No generated destination is unresolved.

## Proposed assurance classification

Proposed: commit-bound verification required, because later acceptance relies on the correctness of the new note and its evidence. Engineering-owner must confirm or revise this proposal before approval. No assurance decision is recorded.

## Required verification

Apply VER-FLW-001 to REQ-FLW-001: read notes/future.txt as UTF-8 and assert equality with `planned\n`. Compare its bytes with 70 6c 61 6e 6e 65 64 0a to exclude BOM and CRLF. Pass only when both comparisons succeed with exit code 0. Validate formal artifacts and check all changed paths against scope.

## Evidence to record

Retain the verification command, output, exit code and scope result under docs/engineering/product/evidence/WO-FLW-002/. Record actual results after execution.

## Stop and escalate conditions

Stop for a failed required check, missing approval or assurance confirmation, or a need to change accepted definitions or scope.

## Completion report format

Report delivered bytes, actual checks, evidence paths, limitations, evaluator-returned lifecycle state and next accountable decision.
