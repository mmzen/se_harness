+++
id = "WO-FLW-002"
type = "work_order"
title = "Provide the planned fixture note"
status = "draft"
owners = ["engineering-owner"]
created = "2026-10-16"
updated = "2026-10-16"
evidence_paths = ["docs/engineering/product/evidence/WO-FLW-002/"]

[execution_scope]
paths = [
  "notes/future.txt",
  "docs/engineering/product/work-orders/WO-FLW-002.md",
  "docs/engineering/product/evidence/WO-FLW-002/",
]

[relations]
implements = ["REQ-FLW-001"]
specifications = ["SPEC-FLW-001"]
architecture = ["ARCH-FLW-001"]
verification = ["VER-FLW-001"]
+++

# Work Order: Provide the planned fixture note

## Objective

A future fixture reader can read notes/future.txt containing exactly UTF-8 bytes 70 6c 61 6e 6e 65 64 0a: `planned` followed by one LF.

## In scope

Create the note, update this work-order record, and retain its verification evidence in the declared directory.

## Out of scope

Other notes, WO-FLW-001, accepted definitions, runtime behavior, configuration, CI, and release or operating changes.

## Authorized decision envelope

After approval, the implementer may choose the local write and check commands within this scope. Changing acceptance text, scope, definitions, or assurance classification requires the accountable human's decision.

## Constraints

Use plain UTF-8 without a BOM, one trailing LF, and the existing filesystem layout. Reuse INT-FLW-001, CAP-FLW-001, REQ-FLW-001, SPEC-FLW-001, ARCH-FLW-001 and VER-FLW-001 unchanged.

## Expected change surface

- notes/future.txt: new reader-facing note; absent during inspection.
- docs/engineering/product/work-orders/WO-FLW-002.md: bounded plan and later execution report.
- docs/engineering/product/evidence/WO-FLW-002/: retain exact-text check commands, output and exit codes.

Inspected notes/note.txt and the existing product definitions and evidence. No runtime, callers, packaging, CI or separate test suite is present in this fixture. The existing exact-text contract is sufficient; no supporting code or documentation change is needed. No generated destination is unresolved.

## Proposed assurance classification

Proposed: commit-bound verification required, because later acceptance relies on the correctness of the new note and its evidence. Engineering-owner must confirm the classification before approval; no assurance decision is recorded.

## Required verification

Apply VER-FLW-001 to REQ-FLW-001: read notes/future.txt as UTF-8 and assert exact equality with `planned\n`. Also compare its bytes with 70 6c 61 6e 6e 65 64 0a to exclude BOM and CRLF. Pass only when both comparisons succeed with exit code 0. Validate formal artifacts and check that all changed paths stay within the declared scope.

## Evidence to record

Retain the verification command, output, exit code and scope check in docs/engineering/product/evidence/WO-FLW-002/. Record actual results only after execution.

## Stop and escalate conditions

Stop for a failed required check, a need to change accepted definitions or scope, or missing approval or assurance confirmation.

## Completion report format

Report the delivered bytes, actual checks and evidence paths, limitations, lifecycle state returned by the evaluator, and its next accountable decision.
