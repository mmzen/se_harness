+++
id = "WO-FLW-001"
type = "work_order"
title = "WO-FLW-001"
status = "implemented"
owners = ["owner"]
created = "2026-08-11"
updated = "2026-10-16"
evidence_paths = ["docs/engineering/product/evidence/WO-FLW-001/observations.md"]

[assurance]
commit_bound_verification = "required"
rationale = "Synthetic fixture decision: require verification bound to the exact commit, with the existing independent exact-text check."
decided_by = "engineering-owner"

[execution_scope]
paths = ["notes/note.txt", "docs/engineering/product/work-orders/", "docs/engineering/product/evidence/", "docs/engineering/product/verification-records/"]

[relations]
implements = ["REQ-FLW-001"]
specifications = ["SPEC-FLW-001"]
architecture = ["ARCH-FLW-001"]
verification = ["VER-FLW-001"]
[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-09-30T00:00:00Z"
decided_by = "engineering-owner"
reason = "Synthetic fixture approval, not production authority."
scope_paths = ["notes/note.txt", "docs/engineering/product/work-orders/", "docs/engineering/product/evidence/", "docs/engineering/product/verification-records/"]

[[lifecycle_events]]
from = "approved"
to = "in_progress"
decided_at = "2026-10-16T09:59:43Z"
decided_by = "Codex"
reason = "Execution of DR-WO-START under recorded work-order approval; relevant local gates passed."

[[lifecycle_events]]
from = "in_progress"
to = "implemented"
decided_at = "2026-10-16T10:06:09Z"
decided_by = "Codex"
reason = "Execution of DR-WO-COMPLETE under recorded work-order approval; relevant local gates passed."
+++

# WO-FLW-001

## Fixture scope

Replace notes/note.txt with exactly `after` followed by one LF. Retain the required check output under the declared evidence directory. The work-orders directory also covers transport of the separately prepared new draft; this grants no approval or implementation authority for that draft.

## Simulated existing approval

This is synthetic fixture history for WO-RLS-046 qualification, not a real person or a product approval. The test scenario supplies existing approval by engineering-owner for this exact scope and required classification. Start, local edits, local commits, checks, completion and required verification preparation are included. The selected work order remains the only authorized implementation. Other work orders may be transported as draft proposals only. Push, PR, release and actual external actions are excluded.
