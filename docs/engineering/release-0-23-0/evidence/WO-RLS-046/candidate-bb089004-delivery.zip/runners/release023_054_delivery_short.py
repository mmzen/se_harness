"""Recover only delivery-test setup at ordinary shorter temporary paths."""
from pathlib import Path
import json,shutil,tempfile,sys
W=Path(__file__).parent;O=W/'release023-054-qualification/delivery'
host=sys.argv[1]
record=O/(host+'-short-profile.json');assert not record.exists()
B=Path(tempfile.mkdtemp(prefix='r2354profiles-'))
sys.path.insert(0,str(W/'iar-demo-tools'))
from run_demo import child_env
env=child_env(B,host)
for key in ('CODEX_HOME','CLAUDE_CONFIG_DIR','APPDATA','LOCALAPPDATA','TEMP'):Path(env[key]).mkdir(parents=True,exist_ok=True)
old=O/'private-profiles/profiles'/host
if host=='claude':shutil.copyfile(old/'claude/.credentials.json',Path(env['CLAUDE_CONFIG_DIR'])/'.credentials.json')
else:
    shutil.copyfile(old/'codex/auth.json',Path(env['CODEX_HOME'])/'auth.json')
    (Path(env['CODEX_HOME'])/'config.toml').write_text('cli_auth_credentials_store = "file"\ncheck_for_update_on_startup = false\n')
record.write_text(json.dumps({'root':str(B),'reason':'Use the ordinary short temporary profile established in earlier qualification; no new-candidate long-path failure is implied. Separate from focused drafting input limits.'},indent=2))
s=(W/('release023_054_delivery_'+host+'.py')).read_text()
s=s.replace("BASE=OUT/'private-profiles'", "BASE=Path(json.loads((OUT/('"+host+"-short-profile.json')).read_text())['root'])")
s=s.replace('plugin027-native-', 'plugin027-native-short-').replace('plugin027-trusted-native-', 'plugin027-trusted-native-short-')
s=s.replace('plugin027-native-short-inputs.json','plugin027-native-inputs.json')
target=W/('release023_054_delivery_'+host+'_short.py');assert not target.exists()
compile(s,str(target),'exec');target.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'host':host,'profile':str(B),'driver':str(target)}))
