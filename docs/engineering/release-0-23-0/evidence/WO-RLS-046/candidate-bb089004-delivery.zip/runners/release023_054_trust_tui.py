"""Open the normal hook review in the isolated test profile only."""
import json,os,sys,subprocess
from pathlib import Path
W=Path(__file__).parent;O=W/'release023-054-qualification/delivery'
sys.path.insert(0,str(W/'iar-demo-tools'))
from run_demo import child_env
v=json.loads((O/'codex-short-ready-for-trust.json').read_text())
env=child_env(Path(v['profile_base']),'codex');env['TERM']='xterm-256color'
exe=r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\2e5e00daee91c61d\codex.exe'
os.chdir(v['cwd'])
raise SystemExit(subprocess.call([exe,'--no-daemon','--enable','hooks','--no-alt-screen','-C',v['cwd']],env=env))
