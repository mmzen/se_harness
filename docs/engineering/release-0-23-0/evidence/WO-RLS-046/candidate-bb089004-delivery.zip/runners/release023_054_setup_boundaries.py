"""Exact-package adapter/setup boundaries; not native-host event evidence."""
import hashlib,json,os,subprocess,sys,tempfile,time
from pathlib import Path
from unittest.mock import patch
W=Path(__file__).parent;D=W/'release023-054-qualification/delivery';O=D/'setup-boundaries';O.mkdir(exist_ok=False)
root=Path(tempfile.mkdtemp(prefix='r2354setup-'));data=root/'data';data.mkdir()
ready=json.loads((D/'codex-short-ready-for-trust.json').read_text());plugin=Path(ready['plugin']);scripts=plugin/'scripts'
sys.path.insert(0,str(scripts));import harness_runtime as runtime;import inject_instructions as delivery;import activate
prior=plugin.parents[3]/'data/verity-plane-se-harness/evaluators'
# Resolve from the actual isolated profile layout, not the replaceable package.
prior=Path(ready['profile_base'])/'profiles/codex/codex/plugins/data/verity-plane-se-harness/evaluators'
wheels={'current':plugin/'packages/se_harness-0.23.0-py3-none-any.whl','legacy':W/'plg030-public-inputs/se_harness-0.20.0-py3-none-any.whl'}
record={'candidate':(W/'release023-054-execution/candidate-head.txt').read_text().strip(),'root':str(root),'kind':'real setup processes and adapter fault injection; not native host delivery','commands':[],'cases':{},'passed':False}
def save(): (O/'assessment.json').write_text(json.dumps(record,indent=2)+'\n')
def done(label,p,args):
 out,err=p.communicate(timeout=180);record['commands'].append({'label':label,'argv':list(map(str,args)),'cwd':str(root),'exit':p.returncode,'stdout':out,'stderr':err});save();return p.returncode,out,err
def start(args):return subprocess.Popen(list(map(str,args)),cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8')
targets={};identities={}
for name,wheel in wheels.items():
 digest=hashlib.sha256(wheel.read_bytes()).hexdigest();version=wheel.name.split('-')[1];py=prior/version/digest/'Scripts/python.exe';assert py.is_file(),py
 target=root/name;target.mkdir();args=[py,'-I','-m','se_harness','init',target,'--project-name','Setup boundary fixture','--json'];assert done(name+'-init',start(args),args)[0]==0
 targets[name]=target;identities[name]={'version':version,'archive_sha256':digest}
def setup_args(name,which=data):return [sys.executable,'-I',scripts/'setup.py','--target',targets[name],'--data-root',which,'--wheel',wheels[name]]
try:
 a=setup_args('current');pa=start(a);lock=runtime.environment_path(data,identities['current']);lock=lock.with_name(lock.name+'.lock')
 deadline=time.monotonic()+30
 while not lock.exists() and time.monotonic()<deadline:time.sleep(.02)
 assert lock.exists()
 b=setup_args('current');pb=start(b);c=setup_args('legacy');pc=start(c)
 rb=done('same-release-contention',pb,b);assert rb[0]==1 and 'another operation owns' in rb[2]
 assert done('current-setup',pa,a)[0]==0;assert done('different-release-setup',pc,c)[0]==0
 env=runtime.environment_path(data,identities['current']);before=(env/'ready.json').read_bytes()
 assert done('same-release-retry',start(b),b)[0]==0 and (env/'ready.json').read_bytes()==before
 record['cases']['concurrent_setup']='pass: same identity refused while locked; distinct release completed; retry reused immutable ready environment'
 partial=root/'interrupted';ep=runtime.environment_path(partial,identities['current']);ep.mkdir(parents=True)
 p=setup_args('current',partial);rp=done('interrupted-environment',start(p),p);assert rp[0]==1 and 'incomplete private environment' in rp[2] and not list(ep.iterdir())
 record['cases']['interrupted_setup']='pass: refused partial environment without repairing over it'
 before_files={f.relative_to(targets['current']).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in targets['current'].rglob('*') if f.is_file()}
 activate.activate('codex','setup-boundary',data,targets['current'])
 with patch('socket.socket.connect',side_effect=OSError('network unavailable in adapter test')):
  text=delivery.repository_context(targets['current'],data)
 assert 'This repository uses SE Harness 0.23.0.' in text
 record['cases']['cached_offline_adapter']='pass: cached entry returned while test-process socket connections refused; subprocess resource reader is local; not a native offline event claim'
 selection=runtime.session_file('codex','setup-boundary',data);old=selection.read_bytes()
 with patch.object(runtime.os,'replace',side_effect=OSError('controlled interrupted replacement')):
  try:activate.activate('codex','setup-boundary',data,targets['legacy'])
  except OSError:pass
  else:raise AssertionError('interrupted replacement accepted')
 assert selection.read_bytes()==old
 record['cases']['atomic_selection']='pass: interrupted replacement preserved complete prior record'
 missing=env/'share/se-harness/templates/repository/standard/ENGINEERING_HARNESS.md.tpl'
 assert missing.is_file() and missing.resolve().is_relative_to(root.resolve())
 backup=missing.with_suffix(missing.suffix+'.qualification-preserved');assert not backup.exists()
 missing.rename(backup)
 try:
  try:delivery.repository_context(targets['current'],data)
  except runtime.DeliveryError as e:record['cases']['missing_resource']={'result':'pass','error':str(e)}
  else:raise AssertionError('missing resource accepted')
  assert not missing.exists()
 finally:backup.rename(missing)
 assert 'This repository uses SE Harness 0.23.0.' in delivery.repository_context(targets['current'],data)
 assert before_files=={f.relative_to(targets['current']).as_posix():hashlib.sha256(f.read_bytes()).hexdigest() for f in targets['current'].rglob('*') if f.is_file()}
 record['repository_unchanged']=True;record['passed']=True
finally:save()
print(json.dumps({'passed':record['passed'],'cases':record['cases']}))
