"""Prepare isolated native delivery probes from the exact staged packages."""
import base64,hashlib,json,os,shutil,sys
from pathlib import Path
W=Path(__file__).parent;Q=W/'release023-054-qualification';O=Q/'delivery'
O.mkdir(exist_ok=True);B=O/'private-profiles'
sys.path.insert(0,str(W/'iar-demo-tools'))
from run_demo import child_env
identity=json.loads((Q/'marketplace/PACKAGE-IDENTITY.json').read_text())
C=(W/'release023-054-execution/candidate-head.txt').read_text().strip()
assert identity['source']['revision']==C
expected=dict(identity['evaluator']);expected['archive_name']=expected['archive']
inputs={h:base64.b64encode((Q/'marketplace/packages'/('verity-plane-'+h+'.zip')).read_bytes()).decode() for h in ('codex','claude')}
inputs.update(marketplace=json.loads((Q/'marketplace/.agents/plugins/marketplace.json').read_text()),expected=expected)
if (O/'plugin027-native-inputs.json').exists():assert json.loads((O/'plugin027-native-inputs.json').read_text())==inputs
else:(O/'plugin027-native-inputs.json').write_text(json.dumps(inputs))
for host in ('codex','claude'):
    env=child_env(B,host)
    for key in ('CODEX_HOME','CLAUDE_CONFIG_DIR','APPDATA','LOCALAPPDATA','TEMP'):
        Path(env[key]).mkdir(parents=True,exist_ok=True)
    # Opaque copies for the authorized disposable tests; never parse or publish.
    if host=='codex':
        if not (Path(env['CODEX_HOME'])/'auth.json').exists():shutil.copyfile(Path('C:/Users/mathi/.codex/auth.json'),Path(env['CODEX_HOME'])/'auth.json')
        if not (Path(env['CODEX_HOME'])/'config.toml').exists():(Path(env['CODEX_HOME'])/'config.toml').write_text('cli_auth_credentials_store = "file"\ncheck_for_update_on_startup = false\n')
    else:
        if not (Path(env['CLAUDE_CONFIG_DIR'])/'.credentials.json').exists():shutil.copyfile(Path('C:/Users/mathi/.claude/.credentials.json'),Path(env['CLAUDE_CONFIG_DIR'])/'.credentials.json')
    source=(W/('r221_final_native_'+host+'.py')).read_text()
    def replace(old,new):
        global source
        assert old in source,old
        source=source.replace(old,new)
    replace("OUT=WORK/'r221-final-20261005'","OUT=WORK/'release023-054-qualification/delivery'")
    replace("BASE=Path(json.loads((WORK/'iar-demo-tools/prepared-demo.json').read_text())['demo'])","BASE=OUT/'private-profiles'")
    replace('plugin026','plugin027')
    if host=='codex':replace('0.2.6','0.2.7')
    replace('a51e250fa15c740a','2e5e00daee91c61d')
    replace("prefix='p026final-'","prefix='r2354delivery-'")
    if host=='codex':
        replace("assert len(installed)==1 and installed[0]['pluginId']=='verity-plane@se-harness'\n        restore=installed[0]['marketplaceSource']['source'];report['restore_marketplace']=restore", "assert installed==[], 'Expected isolated empty plugin profile'\n        restore=None")
        replace("run('install-test-package'", "run('add-test-marketplace',[exe,'plugin','marketplace','add',str(market),'--json'])\n        run('install-test-package'")
    else:
        replace("'--model','sonnet'","'--model','claude-opus-5-5'")
        replace("assert report['version']=='2.1.273 (Claude Code)'", "assert report['version']=='2.1.296 (Claude Code)'")
        replace('4f640284ec496b88cd7aa4ba88ca537d9374a2f8',C)
        replace('WO-RLS-041/VER-RLS-037','WO-RLS-046/VER-RLS-040')
    # Independent app-server process; never attach to or restart the desktop host.
    if host=='codex':
        replace('from acceptance_native import Codex,extract_codex,save','from release023_054_delivery_support import Codex,extract_codex,save')
    target=W/('release023_054_delivery_'+host+'.py')
    compile(source,str(target),'exec')
    if target.exists():assert target.read_text()==source
    else:
        with target.open('x',encoding='utf-8',newline='\n') as f:f.write(source)
support=(W/'iar-demo-tools/acceptance_native.py').read_text()
assert "[manifest['host_executables']['codex'], '--enable', 'hooks'," in support
support=support.replace("[manifest['host_executables']['codex'], '--enable', 'hooks',", "[manifest['host_executables']['codex'], '--no-daemon', '--enable', 'hooks',")
with (W/'release023_054_delivery_support.py').open('x',encoding='utf-8',newline='\n') as f:f.write(support)
record={'candidate':C,'evaluator':expected,'host_version':'Current observed versions; not a performance comparison.','authentication':'Existing authorized authentication copied opaquely into private disposable profiles; credential contents never inspected or retained as evidence.','scope':'Native startup/activation/manual and automatic compaction/resume; separate desktop criterion unchanged.','claude_model':'claude-opus-5-5, same as current full lifecycle selection; delivery probes do not compare speed with prior sonnet runs.','settings':'Only disposable profiles and per-session automatic-compaction settings; no global host changes.','drivers':{h:hashlib.sha256((W/('release023_054_delivery_'+h+'.py')).read_bytes()).hexdigest() for h in ('codex','claude')}}
(O/'preparation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'prepared':str(O),'candidate':C,'hosts':['codex','claude']}))
