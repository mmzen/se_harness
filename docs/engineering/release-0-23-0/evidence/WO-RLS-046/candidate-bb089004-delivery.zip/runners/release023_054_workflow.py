"""Fresh local workflow fixtures with required assurance; no real decision or push."""
from pathlib import Path
import hashlib,json,sys,tempfile
W=Path(__file__).parent;D=W/'release023-054-qualification/delivery'
location=D/'workflow-location.json'
if not location.exists():
    root=Path(tempfile.mkdtemp(prefix='r2354flow-'))
    location.write_text(json.dumps({'root':str(root)},indent=2)+'\n')
root=Path(json.loads(location.read_text())['root'])
s=(W/'r221_fix043_codex_workflow.py').read_text()
changes={
 'from acceptance_native import Codex, extract_codex, save':'from release023_054_delivery_support import Codex, extract_codex, save',
 "BASE = Path(json.loads((WORK/'iar-demo-tools/prepared-demo.json').read_text())['demo'])":"BASE = Path(json.loads((WORK/'release023-054-qualification/delivery/codex-short-profile.json').read_text())['root'])",
 "ROOT = Path(r'C:\\Users\\mathi\\AppData\\Local\\Temp\\r221-fix043-flow')":'ROOT = Path('+repr(str(root))+')',
 "OUT = WORK/'r221-fix043-20261005/native-workflow'":"OUT = WORK/'release023-054-qualification/delivery/native-workflow'",
 'a51e250fa15c740a':'2e5e00daee91c61d',
 "MARKET = WORK/'r221-fix043-20261005/plugin026-marketplace'":"MARKET = Path(json.loads((WORK/'release023-054-qualification/delivery/codex-short-ready-for-trust.json').read_text())['marketplace'])",
 "REPO = WORK/'r221'":"REPO = WORK/'hag221proposal'",
 '0.2.6':'0.2.7','0.22.1':'0.23.0',
 '41aa3f93f126c1f7cbb9efb6b31d5bb3ad755358e37069699d21bfee9be39475':'fe431265298cb94d5205c231729f920ce31e77c3f250f525870d214a079fb519',
 'WO-RLS-041':'WO-RLS-046',
 'not_required':'required',
 'Disposable explanatory note only, with exact text check; no product behavior or authority change.':'Synthetic fixture decision: require verification bound to the exact commit, with the existing independent exact-text check.',
 "paths=['notes/note.txt','docs/engineering/product/work-orders/','docs/engineering/product/evidence/WO-FLW-001/']":"paths=['notes/note.txt','docs/engineering/product/work-orders/','docs/engineering/product/evidence/','docs/engineering/product/verification-records/']",
 'Start, local edits, local commits, checks and completion are included.':'Start, local edits, local commits, checks, completion and required verification preparation are included. The selected work order remains the only authorized implementation. Other work orders may be transported as draft proposals only.',
 'this grants local execution and commits only.':'this grants local execution, commits and required verification preparation only. No test assurance acceptance is supplied.',
 'Finally inspect the evaluator\'s next step and the delivery procedure.':'Prepare required verification through the discovered procedure if its prerequisites pass. Stop before its human acceptance. Inspect the evaluator\'s next step and the review-publication or delivery procedure.',
 "print(json.dumps({'phase':phase,'replies':replies}),flush=True)":"print(json.dumps({'phase':phase,'completed':True,'report':str(dest/'report.json')}),flush=True)"
}
for before,after in changes.items():
    assert before in s,before
    s=s.replace(before,after)
assert not sys.argv[1].startswith(('install','restore'))
if sys.argv[1]=='prepare':
    note={'candidate':(W/'release023-054-execution/candidate-head.txt').read_text().strip(),
      'purpose':'New independent local workflow fixtures for current package; old fixtures are preserved.',
      'correction':'The historical fixture used not_required assurance for implementation. These new fixtures use required assurance and cover generated verification-record and evaluator-evidence paths. No real accepted artifact was amended.',
      'host_surface':'CLI app-server only; desktop deferred and unverified',
      'decisions':'Synthetic existing fixture work approval only. No assurance acceptance, external action or actual product authority.',
      'driver_sha256':hashlib.sha256(s.encode()).hexdigest()}
    with (D/'workflow-fixture-preparation.json').open('x',encoding='utf-8') as f:json.dump(note,f,indent=2);f.write('\n')
exec(compile(s,'current-disposable-workflow','exec'),{'__file__':__file__,'__name__':'__main__'})
