"""Retain command diagnostics independently of PowerShell's aggregate exit."""
import json,re,sys
from pathlib import Path
W=Path(__file__).parent;phase=sys.argv[1];O=W/'release023-054-qualification/delivery/native-workflow'/phase
errors=[];count=0
for no,line in enumerate((O/'native-events.jsonl').read_text().splitlines(),1):
 x=json.loads(line);n=x.get('notification',{})
 if n.get('method')!='item/completed':continue
 item=n.get('params',{}).get('item',{})
 if item.get('type')!='commandExecution':continue
 count+=1;output=item.get('aggregatedOutput') or ''
 signals=re.findall(r'(?im)^.*(?:SyntaxError:|Traceback \(most recent call last\)|ParserError:|CategoryInfo\s*:|FullyQualifiedErrorId\s*:|not recognized as the name|Cannot find path|cannot be loaded).*$' ,output)
 if signals:errors.append({'event':no,'exit':item.get('exitCode'),'command':item.get('command'),'diagnostic_lines':signals,'output':output})
result={'phase':phase,'completed_commands':count,'diagnostics':errors,'meaning':'Diagnostic signals can occur despite aggregate exit zero. Preserve them; the independent fixture assessment determines final effects. No failed attempt is erased by subsequent recovery.'}
with (O/'command-diagnostics.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'phase':phase,'commands':count,'diagnostic_events':[{'event':x['event'],'exit':x['exit'],'diagnostic_lines':x['diagnostic_lines']} for x in errors]}))
