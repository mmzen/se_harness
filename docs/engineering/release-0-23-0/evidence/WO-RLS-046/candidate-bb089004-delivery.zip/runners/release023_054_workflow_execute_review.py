"""Independent inspection of a completed local fixture execution."""
import hashlib,json,subprocess,sys,tomllib
from pathlib import Path
W=Path(__file__).parent;D=W/'release023-054-qualification/delivery/native-workflow';phase=sys.argv[1];O=D/phase
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
report=load(O/'report.json');f=report['fixture'];R=Path(f['repo']);base=f['baseline']
def git(*args):return subprocess.check_output(['git','-c','safe.directory='+str(R),'-C',str(R),*args])
def meta(path):return tomllib.loads(path.read_text(encoding='utf-8').split('+++')[1])
assert not git('status','--porcelain').strip()
head=git('rev-parse','HEAD').decode().strip()
assert (R/'notes/note.txt').read_bytes()==b'after\n'
changed=git('diff','--name-only',base,head).decode().splitlines()
prefix='docs/engineering/product/'
expected={prefix+'work-orders/WO-FLW-001.md',prefix+'work-orders/WO-FLW-002.md',prefix+'evidence/WO-FLW-001/observations.md',prefix+'evidence/WO-FLW-001/handoff.json',prefix+'verification-records/VREC-FLW-001.md',prefix+'evidence/VREC-FLW-001-evaluator.json','notes/note.txt'}
assert set(changed)==expected,changed
wo=meta(R/prefix/'work-orders/WO-FLW-001.md');vrec=meta(R/prefix/'verification-records/VREC-FLW-001.md')
assert wo['status']=='implemented' and wo['assurance']['commit_bound_verification']=='required'
assert vrec['status']=='ready' and not vrec.get('lifecycle_events') and 'verified_by' not in vrec
assert all(e['decided_by']=='Codex' for e in wo['lifecycle_events'] if e['to'] in ('in_progress','implemented'))
assert git('show',vrec['commit']+':notes/note.txt')==b'after\n'
governance=git('diff','--name-only',vrec['commit'],head).decode().splitlines()
assert set(governance)=={prefix+'verification-records/VREC-FLW-001.md',prefix+'evidence/VREC-FLW-001-evaluator.json'}
prior=D/phase.replace('execute','proposal')/'fixture-readback'/prefix/'work-orders/WO-FLW-002.md'
assert prior.read_bytes()==(R/prefix/'work-orders/WO-FLW-002.md').read_bytes()
assert not subprocess.check_output(['git','-C',f['destination'],'for-each-ref']).strip()
assert not (R/'notes/future.txt').exists()
items=[]
for line,raw in enumerate((O/'native-events.jsonl').read_text().splitlines(),1):
    x=json.loads(raw);n=x.get('notification',{})
    if n.get('method')=='item/completed' and n['params']['item'].get('type')=='commandExecution':items.append((line,n['params']['item']))
failures=[{'event':i,'command':x.get('command'),'exit':x.get('exitCode'),'status':x.get('status'),'output':x.get('aggregatedOutput')} for i,x in items if x.get('exitCode') not in (None,0) or x.get('status')=='failed']
out=O/'fixture-readback';out.mkdir()
for rel in sorted(expected):
    target=out/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((R/rel).read_bytes())
result={'candidate':(W/'release023-054-execution/candidate-head.txt').read_text().strip(),'phase':phase,'execution_boundary':'pass','fixture_candidate':vrec['commit'],'fixture_review_head':head,'changed_paths':changed,'note_exact':True,'accepted_definitions_unchanged':True,'new_proposal_preserved':True,'wo_state':wo['status'],'vrec_state':vrec['status'],'remote_refs_empty':True,'actual_publication':False,'human_verification':False,'native_failed_commands':failures,'commands_observed':len(items),'limits':['Per-command review waits are not a performance benchmark.','The separate proposal content finding remains; this execution uses the independently seeded approved WO-FLW-001.','CLI app-server only; desktop unverified.'],'delivery_result':'Ready record remains pending review-publication authority for the named local fixture remote, refs/heads/workflow-demo to refs/heads/main. No publish executed.'}
with (O/'independent-assessment.json').open('x',encoding='utf-8') as s:json.dump(result,s,indent=2);s.write('\n')
print(json.dumps({k:result[k] for k in ('phase','execution_boundary','fixture_candidate','fixture_review_head','wo_state','vrec_state','remote_refs_empty','commands_observed')}))
