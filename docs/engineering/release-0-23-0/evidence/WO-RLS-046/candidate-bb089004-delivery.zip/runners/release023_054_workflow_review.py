"""Observe the native proposal boundary independently; no execution verdict."""
import hashlib,json,subprocess,sys,tomllib
from pathlib import Path
W=Path(__file__).parent;D=W/'release023-054-qualification/delivery/native-workflow';O=D/sys.argv[1]
report=json.loads((O/'report.json').read_text());f=report['fixture'];R=Path(f['repo'])
git=lambda *a:subprocess.check_output(['git','-c','safe.directory='+str(R),'-C',str(R),*a],text=True).strip()
assert git('rev-parse','HEAD')==f['baseline'] and not git('diff',f['baseline'],'--name-only')
path='docs/engineering/product/work-orders/WO-FLW-002.md'
assert git('ls-files','--others','--exclude-standard').splitlines()==[path]
raw=(R/path).read_bytes();m=tomllib.loads(raw.decode().split('+++')[1])
assert m['status']=='draft' and 'assurance' not in m and 'lifecycle_events' not in m
assert m['relations']['implements']==['REQ-FLW-001'] and not (R/'notes/future.txt').exists()
assert (R/'notes/note.txt').read_bytes()==subprocess.check_output(['git','-C',R,'show',f['baseline']+':notes/note.txt'])
rows=[json.loads(x) for x in (O/'native-events.jsonl').read_text().splitlines()]
items=[(i+1,x['notification']['params']['item']) for i,x in enumerate(rows) if x.get('notification',{}).get('method')=='item/completed']
commands=[(i,x) for i,x in items if x.get('type')=='commandExecution']
failures=[{'event_line':i,'exit_code':x.get('exitCode'),'status':x.get('status'),'command':x.get('command'),'output':x.get('aggregatedOutput')} for i,x in commands if x.get('exitCode') not in (None,0) or x.get('status')=='failed']
dest=O/'fixture-readback';dest.mkdir()
for source in R.rglob('*.md'):
    if '.git' in source.relative_to(R).parts:continue
    target=dest/source.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
a={'candidate':(W/'release023-054-execution/candidate-head.txt').read_text().strip(),'phase':sys.argv[1],
 'scope':'Native proposal boundary only; not a full cycle or desktop verdict.','proposal_boundary_passed':True,
 'observations':{'baseline_unchanged':f['baseline'],'only_untracked_file':path,'new_artifact_sha256':hashlib.sha256(raw).hexdigest(),'new_state':'draft','no_decided_assurance':True,'no_lifecycle_events':True,'no_implementation':True},
 'visible_completed_commands':len(commands),'failures':failures,
 'content_review':'Requested note bytes, existing governing links, bounded paths and future check/evidence are stated. Assurance remains a proposal, not a decided table. Execution and publication were not inferred from activation.',
 'limitations':['The new draft does not yet cover fixed generated VREC destinations despite proposing required assurance. Its no-unresolved-destination sentence is too broad; any later approval must resolve those destinations. This draft is not approved or executed by this test.','The existing WO-FLW-001 is a separately seeded correctly classified work order and remains eligible for its own independent execution test.','Per-command review waits are included; this is not an authoring performance comparison.'],
 'full_cycle':'pending'}
with (O/'independent-assessment.json').open('x',encoding='utf-8') as out:json.dump(a,out,indent=2);out.write('\n')
print(json.dumps({'proposal_boundary_passed':True,'failures':len(failures),'full_cycle':'pending','scope_note':'new proposal assurance destinations not fully defined'}))
