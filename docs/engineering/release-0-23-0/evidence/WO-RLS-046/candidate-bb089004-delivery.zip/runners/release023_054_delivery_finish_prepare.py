"""Reuse the successful native delivery drivers with new inputs and profiles."""
import ast,hashlib,json,subprocess,sys
from pathlib import Path
W=Path(__file__).parent;O=W/'release023-054-qualification/delivery'
C=(W/'release023-054-execution/candidate-head.txt').read_text().strip()
for host in ('codex','claude'):
 subprocess.run([sys.executable,'-X','utf8','-B',W/'release023_054_delivery_short.py',host],cwd=W,check=True)
 source=(W/f'release023_053_delivery_{host}_short.py').read_text()
 source=source.replace('release023-053','release023-054').replace('release023_053','release023_054').replace('r2353','r2354').replace('a98a1571292f5bbf34cd2c7cff0af793d00fa12f',C)
 ast.parse(source)
 target=W/f'release023_054_delivery_{host}_short.py';target.write_text(source,encoding='utf-8',newline='\n')
 (O/(host+'-driver-adaptation.json')).write_text(json.dumps({'candidate':C,'source_driver':f'release023_053_delivery_{host}_short.py','driver_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'changes':'Fresh candidate paths, exact candidate identity, unique temporary profiles. Preserve the previously established ordinary prompt/auto-compaction route and normal Codex hook trust review. No new semantic result inferred.'},indent=2)+'\n')
source=(W/'release023_053_trust_tui.py').read_text().replace('release023-053','release023-054')
(W/'release023_054_trust_tui.py').write_text(source,encoding='utf-8',newline='\n')
print('Fresh short profiles and existing delivery procedures ready.')
