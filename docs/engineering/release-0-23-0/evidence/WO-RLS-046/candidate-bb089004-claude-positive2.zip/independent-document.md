+++
id = "VER-P3-001"
type = "verification"
title = "Assert exact greeting by direct invocation"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert exact greeting by direct invocation

## Independence

The expected value `Hello rehearsal` is fixed by REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The assertion compares the candidate function output against that requirement-derived literal. No candidate output influences the expected value.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | `assert-greeting` native invocation | greeting() returns exactly `Hello rehearsal`; exit 0 with `exact greeting passed` |

## Acceptance scenarios

**Normal behavior:** Call greeting() through the `assert-greeting` tool on the native test host using the selected `client_python`. The tool runs the fixture function once and performs a string-equality assertion against the literal `Hello rehearsal`. Exit 0 with the message `exact greeting passed` constitutes a passing result.

**Failure outcome:** A nonzero exit from `assert-greeting` indicates the returned string does not equal the expected literal. This fails REQ-P3-900.

## Evidence retention

Retain the `assert-greeting` record at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/assertion.json`. The record contains the exact command, working directory, exit status, stdout, stderr and elapsed time. Verify the source digest matches `greeting_sha256` before execution.

## Residual uncertainty

The `assert-greeting` tool performs string equality only. It does not assert the return type. A required type assertion beyond string equality remains outside this tool's capability.
