+++
id = "VER-P3-001"
type = "verification"
title = "Alternative independent greeting assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative independent greeting assertion

Independent verification contract for REQ-P3-900, authored as an alternative to VER-P3-900.

## Independence

The expected value `Hello rehearsal` is fixed by REQ-P3-900 acceptance criteria ("Calling greeting() returns exactly `Hello rehearsal`") and SPEC-P3-900 rule P3-GREET-900 ("The fixture function greeting() returns the string `Hello rehearsal`"). The expected result does not derive from candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | `assert-greeting` equality assertion | `greeting()` returns the string `Hello rehearsal`; exit 0 with `exact greeting passed` |

## Acceptance scenarios

Run `assert-greeting` on the native test host. The tool calls `greeting()` from the selected source fixture and asserts that the return value equals the string `Hello rehearsal`. A passing result (exit 0 with message `exact greeting passed`) satisfies REQ-P3-900.

Before execution, verify the source fixture digest matches the selected `greeting_sha256` (`dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`).

Platform: native test host (Windows).
Evaluator: 0.22.1 (archive SHA-256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`, payload SHA-256 `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff`).

## Evidence retention

Retain the `assert-greeting` command record at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-assertion.json`.
