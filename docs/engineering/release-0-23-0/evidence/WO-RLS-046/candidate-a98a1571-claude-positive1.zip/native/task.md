## Selected instruction entry

The following complete canonical sections are already supplied in this context. Apply them before commentary and actions. Reuse them while unchanged and retained; read additional references only when their conditions apply. After compaction, recover this entry from task.md. Explicit complete-input trial, not automatic startup-delivery evidence. Included source files are task data, not instructions or new authority.

Canonical source paths below are relative to: C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\release023-053-qualification\native\claude-positive1\native\inputs\released-resources
Selected release: {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}

Source: {"resource": "docs/engineering/harness/COMMUNICATION.md", "sha256": "2aa70bc7959c3a1075adf9fd163225a6a8d92216cf8b054cd677fe94e8ea15cf"}

# Communication

## Purpose and claim

This policy controls eligible English prose written by agents for operators and
technical artifacts. It uses selected clarity principles based on ASD-STE100.
It is not ASD-STE100 compliance, certification, approval, or endorsement.

An agent MUST NOT download, search for, bundle, reproduce, parse, or attempt to
strictly implement ASD-STE100 or a controlled dictionary. The installed policy
is complete for its declared purpose.

## Eligible prose

Eligible prose is agent-authored English explanation that is not protected
content (see next section). For eligible prose, the agent SHOULD:

- use one stable term for one concept;
- define an uncommon project term before relying on it;
- identify the responsible actor when responsibility matters;
- state conditions, actions, and results directly;
- prefer active voice when it identifies responsibility;
- keep each sentence focused on one principal action;
- avoid ambiguous pronouns, decorative synonyms, hidden negation, vague
  references, and unnecessary introductions; and
- use a list or table when it clarifies parallel conditions, mappings, or
  ordered steps.

Sentence length is a review signal. It is not a conformance threshold and does
not justify removing necessary technical detail.

## Protected content

Exact protected content MUST remain byte-identical. It includes:

- code and inline code;
- commands, paths, identifiers, hashes, version strings, URLs, schemas, and
  field names;
- JSON, TOML, YAML, XML, and other machine-readable data;
- logs, diagnostics, evidence, evaluator output, and canonical restitution
  blocks;
- quotations; and
- operator-supplied text that is presented as supplied text.

Protected content MUST NOT be automatically paraphrased. It includes BCP 14 obligations, 
requirement statements, lifecycle and decision meanings, safety or legal qualifications, 
acceptance thresholds, formulas, and established terminology.

Source: {"resource": "docs/engineering/harness/DRAFT_DEFINITIONS.md", "sha256": "a2041b84342c2b2e4b5ec0f26e3a70702a894c57d9810855cfe514881e5a0c28"}

## Read this when

The selected change lacks a definition, verification, release or operating contract.


## Before this action

Before choosing a type, read [ARTIFACTS.md#artifact-types](ARTIFACTS.md#artifact-types) and [ARTIFACTS.md#artifact-locations](ARTIFACTS.md#artifact-locations). Before links, read [DEFINITION_LINKS.md#links-between-definitions](DEFINITION_LINKS.md#links-between-definitions). Before authoring, read [../ARTIFACT_AUTHORING.md#design-simplicity](../ARTIFACT_AUTHORING.md#design-simplicity) and the exact type checklist linked in this file.


### Define how the result will be verified

**Inputs:** The selected requirements (REQ), specifications (SPEC), proposed
amendments, and existing verification contracts (VER).

**Output:**

- **Formal artifacts:** New or updated verification contracts (VER) in
  `draft` where coverage is missing. None created or modified where existing
  contracts provide unchanged coverage. Accepted contracts remain unchanged.
- **Transient working material:** The selection of reused verification
  contracts (VER), any amendment proposals prepared through [Propose any needed amendments to existing definitions](AMEND_DEFINITIONS.md#propose-any-needed-amendments-to-existing-definitions), coverage
  gaps, and unresolved questions. Retain these under the same conditions
  as [Describe the intended outcome](DEFINE_CHANGE.md#describe-the-intended-outcome).

**Actions:**

1. Read each selected requirement's (REQ) acceptance criteria and linked
   specifications (SPEC).
2. Compare those criteria with the existing verification contracts (VER).
3. Select unchanged contracts that cover the proposed behavior.
4. For each coverage gap, create a verification contract (VER) with the
   commands below, or use [Propose any needed amendments to existing definitions](AMEND_DEFINITIONS.md#propose-any-needed-amendments-to-existing-definitions) to propose an amendment to an existing one.
5. Complete `Requirement-to-evidence matrix`. For each requirement (REQ),
   record its ID, method, case or evidence, and pass condition. Use `test`,
   `analysis`, `inspection`, or `demonstration` as the method.
6. Specify the inputs, platform, evaluator, and command or manual actions for
   each check. Derive expected results from the requirement (REQ) and
   specification (SPEC), not from candidate output.
7. Set `[relations].verifies` to the covered requirement (REQ) IDs.
8. Complete `Independence`, `Evidence retention`, and applicable assessment
   sections in each new or edited draft.
9. Apply `## verification` → `### Checklist` in
   `docs/engineering/ARTIFACT_AUTHORING.md`.
10. Retain questions about missing criteria or methods for [Record unresolved decisions (DEC)](RISKS_AND_DECISIONS.md#record-unresolved-decisions-dec).

**Harness commands:**

For each new verification contract (VER), run the creation sequence from
[Draft any missing definitions](DRAFT_DEFINITIONS.md#draft-any-missing-definitions) with these arguments. Inspect the preview before creation; replace
`VER-ID` with its `allocated_id`:

```text
harnessctl create-artifact REPO --domain DOMAIN --type verification --dry-run --json
harnessctl create-artifact REPO --domain DOMAIN --type verification --id VER-ID --json
```

No harness command writes the verification method or pass criteria. The human
or agent completes that content. No verification record (VREC) is created here.

**Completion:** Every selected requirement (REQ) has a defined verification
method and pass condition, or an explicit unresolved question. Each proposed
check identifies how to perform it and where its evidence will be retained.

**Later use:** [Prepare work orders (WO) linking the definitions, scope, planned work, and verification requirements](DRAFT_WORK_ORDERS.md#prepare-work-orders-wo-linking-the-definitions-scope-planned-work-and-verification-requirements) links these contracts to work orders (WO). The execution
and verification processes later perform the checks and assess the evidence.


Source: {"resource": "docs/engineering/harness/ARTIFACTS.md", "sha256": "2fa84648afedc03f3b811cb0e61d77ee1a1d52421ba3b3fa3eb435c4abd6eb89"}

## Artifact types

“Required” means the selected work needs coverage of that type. It does not
mean every change must create a new file. Reuse an existing active artifact
when its accepted meaning and scope still cover the work. Create a conditional
artifact only when its condition applies.

For an existing selected work order (WO), get its current state and next
action with:

```text
harnessctl check REPO --artifact WO-ID --json
```

Before implementation, check whether that work order (WO) and its linked
definitions are eligible to start:

```text
harnessctl preflight REPO --work-order WO-ID --phase start --json
```

The first command reports lifecycle context without evaluating checkpoint
gates. The second evaluates start readiness, including the states and coverage
of the selected definitions. Neither command approves or starts work.
Here, `REPO` is the absolute repository path and `WO-ID` is the actual ID of
the selected work order (WO). Use the repository's selected released evaluator.

| Type                  | ID prefix | Purpose                                                                                                                                                                      | When needed                                                                                                                                              |
|-----------------------|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|
| `intent`              | `INT-`    | States the problem, intended outcome, and limits of responsibility.                                                                                                          | The work needs an accepted purpose. Reuse an intent (INT) when that purpose still applies.                                                               |
| `capability`          | `CAP-`    | Describes an ability that a human or agent should have.                                                                                                                      | Requirements (REQ) need a link to the capability (CAP) they support.                                                                                     |
| `requirement`         | `REQ-`    | States required behavior or a constraint, with a condition for acceptance.                                                                                                   | The change creates or changes an obligation. Reuse a requirement (REQ) only if its meaning stays unchanged.                                              |
| `specification`       | `SPEC-`   | Defines the detailed behavior, interfaces, constraints, and rejection conditions.                                                                                            | Each requirement (REQ) selected for implementation needs specification (SPEC) coverage.                                                                  |
| `architecture`        | `ARCH-`   | Defines system structure and boundaries needed to meet significant requirements (REQ).                                                                                       | An active architecture (ARCH) directly addresses a requirement (REQ) selected by the work order (WO).                                                    |
| `adr`                 | `ADR-`    | Records an architecture decision (ADR), the alternatives, and their consequences.                                                                                            | An applicable architecture (ARCH) declares that a significant decision is required.                                                                      |
| `verification`        | `VER-`    | Defines how requirements (REQ) will be checked and what counts as a pass.                                                                                                    | Each selected requirement (REQ) needs verification coverage. This is the verification contract (VER), not a test result.                                 |
| `work_order`          | `WO-`     | Defines the bounded work to execute and its governing artifacts. Approval grants work authority.                                                                             | Before execution. One work order (WO) may cover several requirements (REQ). Completed scope does not authorize later work.                               |
| `verification_record` | `VREC-`   | Binds work orders (WO), verification contracts (VER), evidence, and one exact candidate commit for assessment.                                                               | When verification tied to a commit is required. One record may cover several work orders (WO) at the same commit.                                        |
| `release_contract`    | `REL-`    | Defines permitted release scope, gates, rollback conditions, and authority limits.                                                                                           | When a release record (RLS) is proposed.                                                                                                                 |
| `release_record`      | `RLS-`    | Records preparation and the later release decision for verified work at one exact commit.                                                                                    | When a formal release is proposed. Preparing the record does not release the work.                                                                       |
| `decision`            | `DEC-`    | Records a question, options, recommendation, decision maker, affected artifacts, and the eventual answer. It can also record a deviation from one specification (SPEC) rule. | A question blocks a transition, affects more than one artifact, or must remain recorded after approval; or work cannot meet a specification (SPEC) rule. |
| `risk`                | `RISK-`   | Records a threat, an owner, and a next action. Scoring and categories are optional.                                                                                          | A concern needs follow-up. A separate decision (DEC) is used when the concern must block work.                                                           |
| `operating_contract`  | `OPS-`    | Defines continuing service, support, monitoring, or operational assurance obligations.                                                                                       | Ongoing operational commitments apply. Omitting the record does not prove those commitments have been met.                                               |

Code, tests, acceptance scenarios, evidence files, commits, dashboards, tickets,
and conversations are not additional formal artifact types. They may support
or be referenced by formal artifacts but do not grant authority by themselves.


## Artifact locations

New formal artifacts use these directories below
`docs/engineering/DOMAIN/`. `DOMAIN` is the selected domain name. These paths
describe storage, not authority; the artifact ID, metadata, and typed links
remain authoritative. Use the supported authoring command to obtain the actual
path. Do not move existing records merely to match this table.

| Artifact | TYPE | Directory |
| --- | --- | --- |
| Intent (INT) | `intent` | `intent/` |
| Capability (CAP) | `capability` | `capabilities/` |
| Requirement (REQ) | `requirement` | `requirements/` |
| Specification (SPEC) | `specification` | `specifications/` |
| Architecture (ARCH) | `architecture` | `architecture/` |
| Architecture decision (ADR) | `adr` | `architecture/adr/` |
| Verification contract (VER) | `verification` | `verification/` |
| Work order (WO) | `work_order` | `work-orders/` |
| Verification record (VREC) | `verification_record` | `verification-records/` |
| Release contract (REL) | `release_contract` | `release/` |
| Release record (RLS) | `release_record` | `releases/` |
| Operating contract (OPS) | `operating_contract` | `operations/` |
| Decision (DEC) | `decision` | `decisions/` |
| Risk (RISK) | `risk` | `risks/` |

The same domain has `evidence/` for retained work-order evidence and
`acceptance/` for acceptance scenarios. These are supporting files, not new
formal artifact types. Legacy flat artifact locations remain readable and
MUST NOT be moved by an upgrade without separate authority.

Templates under `docs/engineering/templates/` are authoring assets. They are
excluded from active-artifact validation and grant no authority. Use
`capture-verification` and `prepare-release` for commit-bound VREC and RLS
instances; an edited template is not a substitute for their derived evidence.

Source: {"resource": "docs/engineering/harness/DEFINITION_LINKS.md", "sha256": "75b0c06f90fbb219fc31684a1a2d97987215dbada20e335656e45a57532c3010"}

## Links between definitions

An arrow points from the artifact that records the link to the artifact it
references. These links describe meaning and coverage, not execution order.

Repository validation, draft validation and work-order preflight share the
declared source/relation/target types. A supplied undeclared relation or a target
of the wrong type is invalid even when no work order selects the artifact.
Preflight still evaluates readiness only for its selected governing chain.
The read-only draft query permits specific unfinished authoring slots; ordinary
validation and approval retain their completeness requirements.

```mermaid
flowchart LR
    CAP["Capability (CAP)"] -->|derives_from| INT["Intent (INT)"]
    REQ["Requirement (REQ)"] -->|derives_from| CAP
    SPEC["Specification (SPEC)"] -->|specifies| REQ
    VER["Verification contract (VER)"] -->|verifies| REQ
    ARCH["Architecture (ARCH)"] -->|addresses| REQ
    ARCH -->|conforms_to| SPEC
    ADR["Architecture decision (ADR)"] -->|decides| ARCH
```

| Source → target | Relation | Meaning and coverage |
| --- | --- | --- |
| Capability (CAP) → Intent (INT) | `derives_from` | Each active capability (CAP) names one or more active intents (INT). |
| Requirement (REQ) → Capability (CAP) | `derives_from` | Each active requirement (REQ) names one or more active capabilities (CAP). |
| Specification (SPEC) → Requirement (REQ) | `specifies` | Each requirement (REQ) selected by a work order (WO) needs one or more selected active specifications (SPEC). |
| Architecture (ARCH) → Requirement (REQ) | `addresses` | The architecture (ARCH) names every requirement (REQ) that materially drives its structure. |
| Architecture (ARCH) → Specification (SPEC) | `conforms_to` | For each addressed requirement (REQ), the selected architecture (ARCH) names at least one selected specification (SPEC) covering it. |
| Architecture decision (ADR) → Architecture (ARCH) | `decides` | Each selected architecture (ARCH) that requires a design decision has at least one selected active architecture decision (ADR). |
| Verification contract (VER) → Requirement (REQ) | `verifies` | Each selected requirement (REQ) has one or more selected active verification contracts (VER). |


Source: {"resource": "docs/engineering/ARTIFACT_AUTHORING.md", "sha256": "71de2cc92a470e2da25d525e3ad002b77faedb6ef0e69e2fa476a2fa4cb78ff5"}

## Design simplicity

For unfinished work, `harnessctl validate-draft REPO --artifact ID --json`
reports whether one supported draft has an admissible shape. Only exact values
at the same type and field in this evaluator's canonical template, and missing
or empty required authoring links, can be reported as incomplete. Invalid
identity, dates, metadata shapes, actual endpoints, lifecycle history and
disposition are errors. A missing non-template ID is an error. Background
findings remain visible; this result makes no whole-repository validity claim.
Complete the authoring checklist and pass ordinary approval gates before
requesting approval. Draft admission grants no authority to write or approve.

Choose the least complex design that satisfies the agreed requirements and
constraints. Justify material added complexity by the need it serves and why
a simpler approach is insufficient. Consider the effort to understand, build,
test, operate and change the whole solution. Defer speculative needs. Review
both the necessity of the specified behavior and the simplicity of its
implementation. Preserve correctness and the project's required quality and
safety properties.

Start from the smallest complete solution. Each project supplies its agreed
users, scale, operating conditions and quality constraints. Agreed future needs
can matter; imagined flexibility alone is insufficient. Credible risk analysis
can justify prevention before an incident. Fewer lines, shorter specifications
or fewer tests do not establish simplicity; moving work to users, operations
or dependencies also has a cost.

Apply the relevant questions below before definition approval and during design
and implementation review. Return unjustified obligations or design complexity
for revision through the existing decision process. Explain material choices
in the existing specification, design or review: the need, why a simpler option
is insufficient and the added cost. Scale the explanation to the decision; a
small choice may need one sentence, a significant design may use its existing
architecture decision. Trivial changes need no separate comparison document.

These are human review standards. They introduce no separate KISS artifact,
mandatory score, receipt, automated simplicity gate or additional approval.


## verification

### Checklist

- Independence: expected values derive from the requirements and specifications, never from candidate output.
- A requirement-to-evidence matrix with a pass condition per requirement.
- Cover normal behavior and meaningful failure outcomes or risks; do not invent failure scenarios to fill a template.
- What accepted behavior or quality does each test or CI check establish? Cover distinct relevant outcomes, reuse applicable evidence, and avoid mirroring every implementation branch or combination.
- Pass criteria name the platforms and the evaluator.


## Complete selected inputs

The selection, references and entire staged fixture below are supplied once. Apply the applicable instructions and inspect these exact source contents; reuse them while retained and unchanged. The original paths remain available. Reading this delivered content satisfies its read instruction; reread a file only if its required content is missing, changed or no longer retained. The agent selects all operations, authored content and conclusions.

File identities below use paths relative to this input root: C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\release023-053-qualification\native\claude-positive1\native\inputs

### Effective selection

{
  "host": "claude",
  "project_id": "1fcc872c-03ce-45df-bdef-f2757d3def47",
  "endpoint": "http://127.0.0.1:18942",
  "source_manifest": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\inputs\\source-manifest.json",
  "configuration": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\inputs\\configuration.json",
  "source_directory": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\inputs\\source",
  "client_python": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\client\\Scripts\\python.exe",
  "client_wheel": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\inputs\\se_harness-0.23.0-py3-none-any.whl",
  "plugin": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\inputs\\plugin\\verity-plane",
  "combination": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\inputs\\combination.json",
  "compose_project": "r2353-claude-positive1",
  "source_volume": "r2353-claude-positive1-source",
  "source_commit": "5820415917e87b64d80bad2f7c39c6d18d692829",
  "source_kind": "Exact tracked Git-blob snapshot without Git metadata.",
  "reference_root": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\inputs\\reference",
  "released_resources": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\inputs\\released-resources",
  "native_helper": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\inputs\\native_call.py",
  "greeting_sha256": "dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1",
  "inputs_inventory": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\inputs\\inventory.json",
  "helper_python": "C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe",
  "approved_shell_argv_prefix": [
    "C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe",
    "-I",
    "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-053-qualification/native/claude-positive1/native/inputs/native_call.py"
  ],
  "native_task_file": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\task.md",
  "output_directory": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\work",
  "tool_index": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\inputs\\native-tools.md",
  "evaluator_version": "0.22.1",
  "evaluator_file": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\release023-053-qualification\\native\\claude-positive1\\native\\inputs\\evaluator.json",
  "qualification_candidate": "a98a1571292f5bbf34cd2c7cff0af793d00fa12f",
  "port": 18942,
  "token_variable": "HAG_NATIVE_TEST_TOKEN",
  "instruction_delivery": "session-local plugin"
}

### Selected reference

{"path": "native-tools.md", "sha256": "7bced8eebbb8eb8570ce78b1c78cbf86340776dff325e92e7b4dcf9252b42dfc", "bytes": 5303}

````text
# Native test tools

Append one operation to `selection.json`'s exact `approved_shell_argv_prefix` per
shell call. Use native Write/Edit; native Read takes absolute paths. No wrappers,
loops, pipes, listing, direct client commands or permission changes.
This is a capability guide, not workflow authority.

Records, evidence and exports require new paths under selected `work/`; other
locations are refused before execution. Use selected absolute paths or include
`work/` in relative paths. Observations scan only `work/`.

## Draft mutations

Prefer typed input; consult raw schemas/help only for missing fields.
The selected plugin's hosted-drafts reference governs authoring and reporting.

```text
remote OPERATION --typed --compact --record ABSOLUTE_NEW_RECORD [FIELDS]
```

All take `--operation-key KEY --expected-project-version N --evaluator-file FILE`
(selected `evaluator_file`). The adapter supplies the selected endpoint, project,
token environment and exact installed client. The client builds/checks the request;
no automatic version refresh/retry. Typed and raw input cannot be mixed.

| Operation | Other fields |
| --- | --- |
| `import` | `--source-manifest FILE` (selected `source_manifest`) |
| `draft-open` | `--baseline ID --work-order WO-ID` |
| `create-artifact` | `--context UUID --context-version N --domain NAME --artifact-type TYPE`; optional `--artifact ID --include-document` |
| `revise-artifact` | `--context UUID --context-version N --artifact ID --expected-revision REVISION --document-file FILE` |

Creation allocates/writes at once: no `--dry-run` or local preview.
`--include-document` reads that revision, returning text or its decoded path.
UTF-8 documents need no manual base64 or copied client digest.

`--record` saves the command; its new `.evidence` directory holds exact requests,
responses and decoded documents. Reuse displayed `client_view` fields; inspect
outcomes/findings and required omissions. For uncertain effects after capture
failure, use `remote operation --key KEY --record ABSOLUTE_NEW_RECORD` with the
original key. A failure after sending can conceal a committed effect.

## Read one revision

```text
remote read --typed --compact --record ABSOLUTE_NEW_RECORD --artifact ID --expected-revision REVISION --context UUID --context-version N
```

For imports use `--baseline ID` instead of context fields. Select exact revisions
from inputs/results. Reads take no `--operation-key`, `--expected-project-version`
or `--evaluator-file`.

## Reads and discovery

| Need | Operation |
| --- | --- |
| Service readiness/components | `remote status --record ABSOLUTE_NEW_RECORD` |
| Local wheel metadata | `identity` |
| Captured calls/reads/failures | `observations --record ABSOLUTE_NEW_RECORD` |
| Complete released sections | `instructions --section "RESOURCE_ID#HEADING"`; repeat up to 12 |
| Unknown input location | `find-file BASENAME --under RELATIVE_DIRECTORY/` |
| Exact inventory entry | `lookup-file RELATIVE_NAME` |
| JSON | `read-json ABSOLUTE_FILE`; optional `--pointer '"/field"'`, `--keys`, or `--decode-base64` for a raw base64 field |
| Text | `read-text ABSOLUTE_FILE [ABSOLUTE_FILE ...]`; up to eight inventoried inputs, pinned task.md or work files; 64 KiB limit |
| Truncated text | `read-text ABSOLUTE_FILE --offset 0 --limit 4096`; one file, character offsets; follow next_offset until complete |

Use canonical instruction IDs, e.g. `docs/engineering/harness/DRAFT_DEFINITIONS.md#read-this-when`.
The legacy `released-resources/` prefix works. Entry conditions are included when
present; links are not followed. Read applicable prerequisites. Checklist and
repeated continuation selectors are in plugin `change/references/hosted-drafts.md`.

Inventory names omit `inputs/`, e.g. `source/src/greeting.py`. Lookup/digest is not
content. Use known paths; batch independent reads/sections and reuse unchanged
content. Locate unknown headings by reading the file once; do not guess them.
No full inventory is required.

Read [Execution tools](native-execution-tools.md) before planning/executing checks
for available assertions/evidence. Reading or planning grants no execution authority.

## Other operations

For raw requests, lifecycle rehearsal or handoff encoding, first read
[their command details](native-execution-tools.md#raw-requests-and-lifecycle-rehearsal).

## Report evidence

Run `observations --record ABSOLUTE_NEW_RECORD` before reporting: full snapshot
saved, bounded failures/pointers returned, no verdict. `observed_content_reads`
contains successful visible reads; `file_reads` includes failed Claude Read attempts.
Use the trace, not inventory lookups. Missing reads stay unknown; later reads
prove nothing about earlier reads. Capture may be incomplete and excludes later
report writes. Retain the record path instead of copying commands.

`record` is a JSON file even without an extension. Use `read_arguments` with the
approved prefix; optionally add `--pointer`, never append a filename.
`command_records` includes extensionless captures and exact available
`response_fields` (receipt/outcome/provenance), sorted by filename, not time.
Inspect original requests/results for claims; the index selects no handoff base
or retry. Apply hosted-drafts' report/content rules; memory proves no failure count.

````

### Selected reference

{"path": "combination.json", "sha256": "22b89b7839a23ac413b389e1ff07a99fcfbf6ad0b48ed53b210ec3feccc113c4", "bytes": 3054}

```text
{
  "payload": {
    "client": {
      "version": "0.23.0",
      "wheel_sha256": "f2fbc394a65da29fcdb02eb6994dc08e7bc8ad6248b8ddad440021c68e583e16"
    },
    "database": {
      "image": "memgraph/memgraph@sha256:4710bee1ab5b47599876e30f17ae1679d0bbb2262d84dc06641521fecb7c89ce",
      "version": "3.13.1"
    },
    "deployment_sha256": "31bd95485e4956addf88bb8464854467e108b010d3c99007cdbdaf8a6173371e",
    "evaluator": {
      "archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053",
      "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff",
      "version": "0.22.1"
    },
    "plugins": {
      "claude": {
        "archive_sha256": "1dd86622f0b249129cfeea280c03ef550445fe0a67c61775699439986eeda9b5",
        "evaluator": {
          "archive_sha256": "f2fbc394a65da29fcdb02eb6994dc08e7bc8ad6248b8ddad440021c68e583e16",
          "payload_sha256": "8b5671743d56fceb81bf6117fca97c807f407bafaf9137d629ac60b91ffa14b6",
          "version": "0.23.0"
        },
        "inventory_sha256": "2644379a64524f4f322666131bea3452ac74d6f5d5be78ece3a480f253540e1d",
        "version": "0.2.7"
      },
      "codex": {
        "archive_sha256": "baade3dff402e2da52b8bf0b4607a00476e63661405384f99f6523091d5a7c72",
        "evaluator": {
          "archive_sha256": "f2fbc394a65da29fcdb02eb6994dc08e7bc8ad6248b8ddad440021c68e583e16",
          "payload_sha256": "8b5671743d56fceb81bf6117fca97c807f407bafaf9137d629ac60b91ffa14b6",
          "version": "0.23.0"
        },
        "inventory_sha256": "5e521568f2b06c255736bf8f5a77da0677fc1b6592692daf7584884ac13aa432",
        "version": "0.2.7"
      }
    },
    "protocols": [
      "se-harness-remote-command/v1",
      "se-harness-remote-result/v1",
      "se-harness-graph-read/v1",
      "se-harness-artifact-revision/v1",
      "se-harness-artifact-baseline/v1",
      "se-harness-lifecycle-command/v2",
      "se-harness-lifecycle-result/v2",
      "se-harness-lifecycle-export/v2",
      "se-harness-graph-read/v2"
    ],
    "required_secret_keys": [
      "principals[].token"
    ],
    "runtime": {
      "image": "python@sha256:88310c082760d93ac7c74d579e95e53a4ab6ea52dd8901abc61a103daf488ac4",
      "platform": "linux/amd64",
      "python": "3.13.16"
    },
    "schema": "se-harness-hosted-combination/v1",
    "schema_revision": 2,
    "server": {
      "dependency_lock_sha256": "b1b1f24330aeafc5f13b00d138e0b87a501975c7bc65fd92fb9c519a2f02eeca",
      "image_manifest": "sha256:71c5628a6a4484af1dd4fd8127aa9ad5453fbe3df4a8a323c6425f556b2a17f1",
      "system_packages_sha256": "3b79cfbc2fb5844a952a7e17b401771dc412dfaae78723c9b0665111212c278d",
      "version": "0.1.0.dev1",
      "wheel_sha256": "29772df1e0baccbfbd426a1cba23e3489fc681c847f6a6016ed659698819c915"
    },
    "source": {
      "candidate_commit": "a98a1571292f5bbf34cd2c7cff0af793d00fa12f",
      "repository": "https://github.com/mmzen/se_harness.git"
    }
  },
  "combination_id": "sha256:001018a26550ed9e19d9ff639c86a90adbbcab5fef5f1cfa572a4eee4b660d20"
}

```

### Selected reference

{"path": "plugin/verity-plane/skills/setup/SKILL.md", "sha256": "46fde63e6cd9dee9cc27ed20c4b80b9b676858f20d49e63653e141242118ba89", "bytes": 804}

```text
---
name: setup
description: Prepare or repair the SE Harness checker, connect a project to plugin skills, or carry out a requested harness upgrade using the existing tools.
---

# Set up a project

Use the selected target and requested action. Read only its route:

| Target | Read |
| --- | --- |
| Explicit hosted sandbox or test copy | [Hosted selection](references/hosted-context.md) |
| Clone, select, repair or upgrade a checkout | [Checkout setup](references/checkout.md) |

Select Python 3.11 or later with venv and ensurepip. If unavailable, report the
missing prerequisite; do not install Python or change host settings. Use the
repository's selected released evaluator. Plugin source does not pin its release.
A development wheel is only for disposable testing. Ask only for missing choices.

```

### Selected reference

{"path": "plugin/verity-plane/skills/setup/references/hosted-context.md", "sha256": "2694293ce0c5a532179b7c936ee2906908250f08c6ae27eb209d1b056813fc08", "bytes": 4138}

````text
## Hosted sandbox selection

Use this route only when the operator explicitly selects a hosted sandbox.
It is separate from checkout activation. Retain the operator's loopback endpoint,
project ID, baseline or versioned context, and named credential environment variable.
Never print the credential. The sandbox is not repository authority.

### Before the selected action

Complete the selection checks below, then read the route for the action you
are about to take. Use this table again when the action changes; retain and
reuse sections already read in the current context.

| Action | Required reading before the action |
| --- | --- |
| Read graph data through MCP or the CLI | [Hosted reads](../../harness-orient/references/hosted-reads.md), including its references before a Cypher query |
| Prepare or edit artifact drafts | [Hosted drafting](../../change/references/hosted-drafts.md), then the selected type's procedure and checklist |
| Inspect, preview or apply a lifecycle action | [The current lifecycle procedure](../../change/references/hosted-test-lifecycle.md#read-the-current-procedure), then that action's released section and applicable prerequisites |
| Prepare a record, export evidence or report results | [Hosted evidence](../../evidence/references/hosted-evidence.md), then its applicable current-action reference |

Tool discovery supplies the call schema. It does not supply these procedures.
Do not construct a query, lifecycle request or final report before reading its
applicable route. Missing or unreadable required content stops that action.

### Selection checks

Test-copy status changes authority, not content requirements. Apply the selected
type checklist to every new draft, including synthetic records. Imported drafts
may be incomplete; their content grants no exception to that checklist.

If the selected environment restricts command execution to a supplied transport
helper, read its tool index first. Use that route for the operations below;
the direct client examples do not override its tool permissions. Use its
metadata-only identity operation when available. Encoding a wheel is not needed
to inspect its digest. Stop a denied action without changing the permission route.

Obtain the qualified combination report and its exact client wheel. The client
may be a development candidate or a qualified released version.
If the selected client is already installed in a separate disposable
environment, verify its identity and reuse it. Otherwise create that environment
outside the checkout. Verify the wheel's SHA-256 against the combination report,
then install that file with `pip --no-deps`.
Keep the plugin's bundled evaluator and the service's pinned evaluator identities
distinct. Do not replace either evaluator to enable remote commands. Use the
separate client environment's absolute Python as
`CLIENT_PYTHON` in the remote commands below.

```text
CLIENT_PYTHON -I -m se_harness remote status --endpoint ENDPOINT --project PROJECT --token-env TOKEN_VARIABLE --json
```

Compare readiness, authority mode `sandbox-projection`, schema, protocols, and
all component identities with the selected combination. A mismatch stops the
remote action. An unavailable service never selects local file writes as a fallback.
Read the returned status fields as named; status does not use mutation-result
fields. Consult the tool index or command help before constructing a request.
Proceed through the selected action's reading route above.
Do not continue into "Activate the checkout" for this hosted selection.
This route grants no approval, verification, release, adoption or deployment right.


## Private lifecycle test copy

The private hosted pilot requires a separately installed qualified remote
client, a loopback endpoint, an explicit test project and a new disposable volume.
Use the repository's `server/README.md` Phase 3 procedure. Its configuration must
report `test_copy: true`; select `--test-copy` for each rehearsal or export.
Leave any existing real checkout selection unchanged. Remote setup does
not activate graph authority or install this client into the user's host.

````

### Selected reference

{"path": "plugin/verity-plane/skills/change/SKILL.md", "sha256": "ee2ab5cc865b06a247420cc1f6faebc79a9e140477a30718882608b54cd4039a", "bytes": 1163}

```text
---
name: change
description: Draft or amend an SE Harness artifact package and execute a selected work order through existing released workflow commands. Continue work already covered by actual authority, and stop the affected action when its scope, inputs or gates no longer match.
---

# Change

Select the route that matches the current task. Read its reference before acting.
The selected released evaluator decides lifecycle legality; this skill routes
instructions and grants no authority.

| Current task | Read |
| --- | --- |
| Author drafts in an explicit hosted sandbox/test copy | [Hosted drafting](references/hosted-drafts.md) |
| Rehearse lifecycle actions in an explicit hosted test copy | [Hosted lifecycle](references/hosted-test-lifecycle.md) |
| Define or execute work in a repository | [Repository change](references/repository-change.md) |

Load only the selected route and its applicable prerequisites. Reuse unchanged
material retained in context; recover it after compaction. Do not preload the
other routes or future lifecycle procedures.

Before an external mutation, read [Provider controls](references/authority.md#external-actions).

```

### Selected reference

{"path": "plugin/verity-plane/skills/change/references/hosted-drafts.md", "sha256": "09912f982b0dbcaadcd3d79f895d91aa83fb3de0f1a32d45f666de8400879be6", "bytes": 11183}

```text
## Select the current step

Use exact instructions already delivered with their source identity. Reading that
content satisfies its read instruction. Open its file only if required content
is missing, changed or no longer retained. A pointer alone is not content.

Complete [Hosted selection](../../setup/references/hosted-context.md) once for
the unchanged selection. Use its supplied absolute file path; do not guess a
location from its filename. Draft preparation grants no decision right or Git authority.

Match the request and existing confirmed context to the current step:

| Available inputs | Read from the selected release |
| --- | --- |
| The intended outcome or scope still needs clarification | `docs/engineering/harness/DEFINE_CHANGE.md`: **Read this when**, **Before this action**, then **Describe the intended outcome**. Use **Define the limits of the change** when its inputs are available. |
| Confirmed outcome, scope and selected definitions; a definition draft is needed | `docs/engineering/harness/DRAFT_DEFINITIONS.md`: **Read this when**, **Before this action**, then the requested type's procedure below. |

Before choosing the drafting route, apply **Check the inputs before writing**.
The clarification route produces transient discussion, not a formal artifact.

Apply the shared check in **Report and recover** before an exhaustive failure
claim. For a clarification stop, include three short parts in the final reply:

- **Actions:** State whether any hosted change was attempted. Include every
  observed failure or denial, including local reads and recovered failures.
- **Known inputs:** Keep existing definitions and supplied scope limits.
- **Questions:** Ask only for missing facts needed now.

This retained reply is the transient report only if no hosted mutation command
was invoked and the captured attempted-call record is complete. Refused or denied
mutation commands are still attempts. If capture is incomplete or its completeness
is unknown, use the saved report in **Report and recover** and state that limit,
even when no change was observed. The clarification reply
needs no duplicate file or new lifecycle checkpoint.

For a requested intent, consult `docs/engineering/ARTIFACT_AUTHORING.md#intent`
when identifying missing content. Read other prerequisites when their stated
condition applies. Before selecting artifacts, load the clarification procedure's
artifact and link references. Before drafting, use this type table:

| Type | Drafting procedure |
| --- | --- |
| Verification | **Define how the result will be verified** |
| Release or operating contract | **Prepare a release or operating contract** |
| Other definition | **Draft any missing definitions** |

Apply the drafting procedure's prerequisites, including
`ARTIFACT_AUTHORING.md#design-simplicity` and the type checklist. Use full type
names such as `#intent`, `#verification`, or `#work_order`, not codes.

For a release contract in a private lifecycle test, the source fixture commit
is not the disposable Git candidate that verification will capture. Do not
complete or approve a contract with a guessed candidate. If the final candidate
is not yet known, defer completing and approving the contract. Take its exact
`candidate_commit` from the final verified VREC, complete the release scope and
evidence requirements, then obtain the contract's required decision. An explicitly
supplied candidate constraint remains binding.

The released `harnessctl ... REPO` examples act on repository files. Hosted work
uses the selected tool index or `docs/notes/harnessctl-reference.md#concise-hosted-authoring`.
Do not combine their arguments. The canonical content rules still apply.

Obtain missing sections together from the selected resource root; batch independent
file reads with known paths. Missing, ambiguous or changed sources
stop the affected action. For 0.22.1's repeated
`CONTINUE.md#continue-selected-work` title, read its unique `#procedure` parent.
Load [lifecycle instructions](hosted-test-lifecycle.md) only for that task.

## Check the inputs before writing

First locate the requester's confirmation of the outcome and scope required
by **Describe the intended outcome**. Reuse a matching confirmation, including
one recorded in an accepted definition. If it is
absent, present the proposed wording and ask for confirmation before dependent
drafting. Do not import, open a draft context or create a template to ask.

Use one short assessment for the requested type's required checklist items:

| Required input | Direct support: short source passage and location, or **Missing** | Question if missing |
| --- | --- | --- |

A passage must answer the item for this change. A citation, your interpretation
or text you plan to write is not direct support. Reuse delivered sources and an
unchanged assessment; no new file or repeated read is required.

Code describes existing behavior. Existing definitions establish their stated
scope. Neither establishes an unstated user need for a different change. A task's
execution restrictions alone do not establish product scope limits. Keep deductions and
proposed limits unconfirmed in both the draft and report.

For an intent, assess the affected user and present problem, wanted improvement,
and success measure separately. A baseline states today's value; `not measured`
does not supply a success condition. Restating the requested software output
does not establish its benefit. Use the checklist, not template shape, to decide.

- **Missing required input:** report **Incomplete**, ask only the missing question
  and stop dependent writing. Preserve any existing partial draft.
- **All required inputs supported:** author the supported content. After saving,
  check each item against the saved revision before reporting **Complete**.
- **Assessment prevented by access or operation uncertainty:** report **Blocked**
  and recover the missing evidence.

Reuse this assessment in the report and final reply. Optional facts stay optional.
A successful save, empty `incomplete` list or `content_review: not_assessed` does
not establish completeness. Choose in-scope methods and evidence paths as plans,
not observed results.

Before claiming a coverage gap, read the applicable requirements, specifications
and verification contracts. Code or one same-type record cannot establish their
absence. For a verification plan, derive expected values from definitions; name
the check, pass condition and full proposed evidence path, including filename
and any work-order directory. In an environment with restricted execution tools,
read their capability descriptions before choosing the check. This is a planning
read, not test execution. Match the planned assertions, platform and evidence
fields to those tools. Distinguish the local test runtime from the service and lifecycle evaluator.
If a required condition cannot be assessed with the available tools, report that
gap before requesting approval; do not promise an unavailable check.

Report a type/outcome mismatch without changing type or inventing a fact.

## Author and submit

Choose the operation, target, expected versions, retry key and content. Use the
documented typed fields and evaluator identity file; do not also load raw schemas
for those fields. Import is operator-only and uses the complete source manifest.

Use `--typed --compact --record-directory NEW_DIRECTORY`, or the selected helper's
documented permission route. Raw `--request FILE` needs its schema and referenced
definitions. Do not mix modes or manually encode typed documents. Freeze is
raw-only and grants no approval. Explicit IDs permit a new domain; automatic
allocation requires an existing domain with an evaluable ID token.

Inspect the created template through `--include-document` or
[an exact revision read](../../harness-orient/references/hosted-reads.md#read-one-hosted-revision).
Findings are not the document. Complete only supported content and review it
against the type checklist. Trace each verification pass condition to its
governing definition and planned check. Remove unsupported claims, duplicate
checks and constraints absent from definitions; an unrequested extra check is
not a required gap. Correct omissions from confirmed inputs before stopping.
Report the content review separately from template checks.

Submit the complete UTF-8 file with `revise-artifact`. Review the saved document
and its returned versions, receipt and findings. If this review finds a supported
in-scope correction, revise the draft and review the new saved revision.
`revise-artifact` edits an editable draft, not an approved or imported record.
Lifecycle history, decisions and evidence stay immutable. If a protected-record
refusal occurs, stop that revision. Do not retry it with changed state, history
or content. A separate draft proposal does not amend or replace an accepted
record; use the selected release's amendment boundary and obtain any missing
authority before dependent work. Resolve blocked reads first.

## Report and recover

Before an exhaustive failure claim in either report form, inspect the captured
observations and account for calls made after that snapshot. A later success does
not erase a failed call. If complete capture cannot be established, state that
limit and use the saved-report route. Reuse retained observations; no duplicate
report or extra read is needed when they already cover the claim.

For the clarification reply, use **Select the current step**. Otherwise retain
complete requests/results and one short report outside the repository, including
after a mutation attempt or uncertain effect. Read required omitted findings.
The report contains:

- **Content readiness:** reuse the assessment from **Check the inputs before
  writing**, updated for the latest saved revision. Keep missing inputs and questions visible.
- **Saved state:** selection, revision, versions and exact document/result paths.
- **Validation and review:** evaluator findings, independent content findings,
  local and remote failures (including recovered ones), denials, uncertain effects,
  and any returned procedure/step. Apply the shared report check above. Link
  evidence; do not copy inventories.

Draft validation checks template shape and required links; it does not assess
content. Planned checks are not executed tests. Keep report and final reply
consistent with the content-readiness decision.
Classify effects from operation receipts: accepted writes, successful reads and
failed or uncertain attempts. Count only accepted writes as mutations; a read
does not add one. Attribute facts to their actual source. Response metadata is
not saved content. Use only confirmed paths and digests.
After compaction, recover the retained reply or report and obtain fresh context.

For stale input, inspect the selection without silently refreshing versions.
For an uncertain reply or capture failure, look up `remote operation --key KEY`
with the same selection and credential, or retry identical bytes and key. Resolve
the effect before selecting another key. Changed bytes under an accepted key are
refused. Never fall back to local writes.

```

### Source data

{"path": "source/.engineering-harness.lock", "sha256": "1ec80dbed14b379d2b33a53ba8d84d1af87d7ab2436dcf753761bcd1bcbf8252", "bytes": 656}

```text
{
  "evaluator": {
    "archive_name": "se_harness-0.22.1-py3-none-any.whl",
    "archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053",
    "payload_manifest": "se-harness-installed-payload-v1",
    "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff",
    "version": "0.22.1"
  },
  "files": {
    ".gitattributes": {
      "mode": "fragment",
      "sha256": "fba4cf22b45939f8c705f2a9c3bd964408b5003d0599993e72735ce865b97e3b"
    }
  },
  "hash_algorithm": "sha256",
  "hash_mode": "utf8-text-lf-v1",
  "resource_layout": "released-resources-v1",
  "schema": 5,
  "tool_version": "0.22.1"
}

```

### Source data

{"path": "source/.engineering-harness.toml", "sha256": "069622e02d80bdec13240889f7e83b1063b01208b9e4a5f6f37fdcdcf53a8d22", "bytes": 237}

```text
[harness]
resource_layout = "released-resources-v1"
tool_version = "0.22.1"
installed_at = "2026-10-07"
project_name = "Disposable lifecycle rehearsal"

[revision_provenance]
required_for_verified_work = true
required_for_release = true

```

### Source data

{"path": "source/.gitattributes", "sha256": "fba4cf22b45939f8c705f2a9c3bd964408b5003d0599993e72735ce865b97e3b", "bytes": 173}

```text
# se-harness:begin
# Preserve canonical evaluator-evidence bytes and their bound SHA-256 on every platform.
docs/engineering/**/evidence/*.json text eol=lf
# se-harness:end

```

### Source data

{"path": "source/REHEARSAL.txt", "sha256": "feb75968b83b4fa18865b23e3b2a8b498915e4c7ab770fee2dd9cd3418ac8e8c", "bytes": 46}

```text
Synthetic test copy. No real human authority.

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/capabilities/CAP-P3-900.md", "sha256": "f00af6febc1d62752cab0364e3f4e80e227438f494d98d9f02a9a5c7fdc30bc0", "bytes": 426}

```text
+++
id = "CAP-P3-900"
type = "capability"
title = "Read the rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"
ability = "Read the exact rehearsal greeting."

[relations]
derives_from = ["INT-P3-900"]
+++

# Read the rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

The operator can read the fixed greeting from the local test fixture.

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/intent/INT-P3-900.md", "sha256": "20649db79738fdf649578286679d6fe05491e460c5a41e68ba0ed3161c47e7ed", "bytes": 516}

```text
+++
id = "INT-P3-900"
type = "intent"
title = "Inspect one rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"
outcome = "The test operator observes Hello rehearsal."

[relations]
+++

# Inspect one rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

An operator needs a fixed greeting for a disposable lifecycle rehearsal.
Success is an observed exact greeting and exported test evidence. No real product or release is involved.

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/release/REL-P3-900.md", "sha256": "a7cc92f770027bae2ffbf987a1a83eb36bd5e012632e1db07cf5f377f6b12935", "bytes": 529}

```text
+++
id = "REL-P3-900"
type = "release_contract"
title = "Prepare a test release record only"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"

[relations]
gates = ["WO-P3-900"]
+++

# Prepare a test release record only

Synthetic rehearsal input. This is not a real human decision.

Test version 0.0.1 binds this work and its verified test candidate. No tags, publication or deployment. Discard the disposable test project if replay fails. Retain the verification record and exact evidence.

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/requirements/REQ-P3-900.md", "sha256": "99028b8605edfd6e85d3cbfb0ee5243f43df69059e314ed1f0b9ab0bde0bbba4", "bytes": 539}

```text
+++
id = "REQ-P3-900"
type = "requirement"
title = "Return the exact rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"
statement = "Calling greeting() returns Hello rehearsal."
verification_method = ["test"]
priority = "must"
source = "Synthetic Phase 3 fixture"

[relations]
derives_from = ["CAP-P3-900"]
+++

# Return the exact rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

## Acceptance

Calling greeting() returns exactly `Hello rehearsal`.

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/specifications/SPEC-P3-900.md", "sha256": "0904f98bddc075f26c87e2e2ce603e3d74a497b8df85e1093bf3b0f5f35a45f9", "bytes": 539}

```text
+++
id = "SPEC-P3-900"
type = "specification"
title = "Fixed rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"
contract = "Return the fixed greeting without external effects."

[relations]
specifies = ["REQ-P3-900"]
+++

# Fixed rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

**P3-GREET-900.** The fixture function greeting() returns the string `Hello rehearsal`.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-900 | P3-GREET-900 |

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/verification/VER-P3-900.md", "sha256": "9c975ff911c736f30dab7688df8f136e66eefd81eebc09362d0345cef813e8b4", "bytes": 688}

```text
+++
id = "VER-P3-900"
type = "verification"
title = "Independently assert the greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"

[relations]
verifies = ["REQ-P3-900"]
+++

# Independently assert the greeting

Synthetic rehearsal input. This is not a real human decision.

## Independence

Expected text is fixed by REQ-P3-900, not candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-900 | test | exact greeting assertion | Equals Hello rehearsal |

Retain the actual assertion result in docs/engineering/lifecycle-pilot/evidence/WO-P3-900/assertion.json.

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/work-orders/WO-P3-900.md", "sha256": "98ac1fa85021ac8a6f4d7a74973e2148dac97aa6ca69064d847818efc3771332", "bytes": 1096}

```text
+++
id = "WO-P3-900"
type = "work_order"
title = "Implement the synthetic greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"

[assurance]
commit_bound_verification = "required"
rationale = "Synthetic fixture decision for test assurance."
decided_by = "test-owner"

[execution_scope]
paths = ["src/greeting.py", "docs/engineering/lifecycle-pilot/"]

[relations]
implements = ["REQ-P3-900"]
specifications = ["SPEC-P3-900"]
verification = ["VER-P3-900"]
+++

# Implement the synthetic greeting

Synthetic rehearsal input. This is not a real human decision.

## Objective

Return the exact test greeting.

## In scope

Only the synthetic source, pilot definitions and test evidence.

## Out of scope

Real engineering records, real human decisions and external actions.

## Authorized decision envelope

All supplied actors are synthetic test labels.

## Required verification

Run VER-P3-900 on the exact clean fixture commit.

## Stop conditions

Stop when the released evaluator refuses.

## Completion

Retain actual outputs and candidate identity.

```

### Source data

{"path": "source/src/greeting.py", "sha256": "dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1", "bytes": 45}

```text
def greeting():
    return 'Hello rehearsal'

```
Before your first explanation, apply the supplied sections and read only the applicable plugin instructions and prerequisites still missing from context. Use the existing file tools below. This explicit test setup does not establish automatic startup instruction delivery.

# Focused hosted drafting diagnostic

You are Claude under WO-HAG-011. Work independently in the fresh private project
selected by `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\release023-053-qualification\native\claude-positive1\native\selection.json`. Git governs real work.

## Requested outcome

Prepare exactly one new verification-contract draft for an independent reviewer
who needs a plan to check the existing fixture against REQ-P3-900: greeting()
returns exactly Hello rehearsal. This is an explicitly requested alternative
authoring exercise; existing VER-P3-900 and all imported -900 records remain
unchanged. Do not claim a missing requirement or verification contract.

Inspect the relevant fixture and governing requirement. Author the new contract
in the selected private service, using domain lifecycle-pilot and synthetic owner
test-owner. Define an independently derived expected result, the check to perform,
its pass condition and the evidence to retain. Plan verification only; do not claim
that tests ran or that the result is verified. Keep the artifact draft. Do not
create other artifacts, approve anything, start work, freeze a baseline or make
lifecycle decisions. Stop when the draft and actual authoring findings are saved,
or report the precise blocker.

## Inputs and boundaries

Apply the complete entry if supplied; otherwise read the selection. Follow the
selected plugin's skills/setup/SKILL.md route. Native Skill must resolve that
candidate. Reuse unchanged content; read missing prerequisites before acting.
After compaction recover the task, selection and original evidence.

Use tool_index for syntax and native file tools or its bounded readers.
Shell calls must use approved_shell_argv_prefix, one helper invocation each.
No scripts, wrappers, pipes, loops, direct client calls or other shell commands.
Normal permissions and hooks apply. Stop denials; do not change routes or permissions.

Write only under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\release023-053-qualification\native\claude-positive1\native\work`, using absolute paths. It exists; inputs are
read-only. Do not install software, activate a checkout, print credentials,
inspect auth stores, or change accounts or host settings. Authentication is
in the environment. Do not read prior trials. Choose operations yourself;
helpers supply no workflow.

## Report

Follow change/references/hosted-drafts.md: use the eligible clarification-only
reply or one short native-report.md in the work directory. Include its required
fields, readiness result and evidence links; keep the final reply consistent.
Do not duplicate captured metrics, observations or inventories. Before exhaustive
failure claims, use observations; it excludes later calls. Incomplete or unknown
capture requires a saved report stating that limit. Lifecycle, MCP parity,
reply recovery and export remain outside this draft-only qualification.
