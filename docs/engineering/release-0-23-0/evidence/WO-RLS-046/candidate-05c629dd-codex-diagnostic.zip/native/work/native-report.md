# Hosted intent drafting diagnostic

Content readiness: **Incomplete**. The request does not establish the new audience, its problem, the benefit sought, a success condition, or confirmed product scope and outcome wording. No hosted mutation was attempted. No intent was created.

## Content assessment

| Required input | Direct support or Missing | Question if missing |
| --- | --- | --- |
| Affected user | Missing. The request says only "a new audience." | Who is the new audience, and when will it use the greeting? |
| Present problem | Missing. INT-P3-900 says "An operator needs a fixed greeting for a disposable lifecycle rehearsal." This describes the existing rehearsal, not the new audience's problem. | What difficulty does the existing greeting cause that audience? |
| Wanted improvement and smallest useful outcome | Missing. "Adapt the existing greeting for a new audience" requests a change but does not state its benefit. | What should the adaptation help that audience do or understand? |
| Success measure | Missing. INT-P3-900 says "Success is an observed exact greeting and exported test evidence." That measure applies to the existing rehearsal. | What observable result will show that the adaptation helped? |
| Baseline | source/src/greeting.py returns 'Hello rehearsal'. No baseline for the new audience's experience is supplied. | No separate question is needed now; an unmeasured baseline can be recorded honestly. |
| Agreed needs and product scope limits | Missing for the adaptation. The request establishes drafting boundaries only: "Prepare exactly one new intent draft", domain lifecycle-pilot, synthetic owner test-owner, and draft status. | What is the smallest included change, and what product behavior must remain outside scope? |
| Confirmed intended outcome and scope | Missing. No confirmation of wording for this adaptation appears in the supplied inputs. | Complete and confirm the proposed wording below together with the product scope. |

Proposed wording for confirmation, with unresolved facts shown explicitly: "When [audience] uses the greeting in [context], the adapted greeting helps them [benefit]; success is [observable result]." This is transient discussion, not a formal definition.

## Known inputs and saved state

The supplied fixture and all seven -900 definitions were inspected from their complete delivered content. REQ-P3-900 requires the exact greeting `Hello rehearsal`; SPEC-P3-900 defines the fixed return value without external effects; VER-P3-900 plans an exact greeting assertion. These existing definitions do not establish the new audience's need. No coverage-gap claim is made.

Selection: project `85b23a86-7eb4-4674-81b4-8f12a81b90f5`, endpoint `http://127.0.0.1:18921`, domain `lifecycle-pilot`, synthetic owner `test-owner`. The service reports project version `0`, `sandbox-projection`, and `test_copy: true`. Git remains authoritative. No hosted input baseline, draft context, artifact ID, revision, or saved artifact document was created or selected.

Source fixture commit S: `5820415917e87b64d80bad2f7c39c6d18d692829`. Qualification implementation candidate C: `05c629ddfc0f40924823160d8aaf0fa4e77940a2`, supplied in the selection and returned by identity. No test Git candidate P was established. No verification or release claim is made.

## Validation and review

| Assessed case | Observed result and evidence | Remaining limit |
| --- | --- | --- |
| Selection checks | The metadata identity operation returned the selected client wheel SHA-256. [Service status](status-check.json.stdout.txt) reports readiness, authority mode, schema, protocols, evaluator, client, and component identities matching the supplied combination. [Command capture](status-check.json). | Readiness does not authorize lifecycle decisions or establish draft completeness. |
| Intent content review | The assessment above identifies missing required inputs from the supplied request and definitions. | No saved revision exists to review. |
| Authoring validation | No import, draft-open, create-artifact, or revise-artifact command was invoked. | There are no authoring evaluator findings, receipt, or returned procedure/step. |
| Failures and capture | [Observation snapshot](observations.json) reports empty `native_failures` and `failed_command_records` arrays. No failure, denial, or uncertain hosted effect was observed in the visible calls. | `native_call_count_complete` is false; capture is incomplete, so this is not an exhaustive failure claim. The snapshot excludes subsequent commentary and report creation. |

The fixture, supplied -900 records, and all lifecycle states remain unmodified by this task. No checks were executed. The required next input is the audience, problem, benefit, success condition, product scope, and confirmation described above.

The [selected change skill](../inputs/plugin/verity-plane/skills/change/SKILL.md) routes this action to [Hosted drafting](../inputs/plugin/verity-plane/skills/change/references/hosted-drafts.md). Its instruction is: "If it is absent, present the proposed wording and ask for confirmation before dependent drafting." The absent item is the requester's confirmation of outcome and scope. The same procedure requires stopping dependent writing when a required input is missing.
