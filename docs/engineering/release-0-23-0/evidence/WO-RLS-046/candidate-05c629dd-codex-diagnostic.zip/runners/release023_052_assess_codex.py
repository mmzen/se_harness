import hashlib,json
import hag_efficiency_plan as p
O=p.W/'release023-052-qualification/native/codex-diagnostic'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
o=load(O/'independent-observations.json');s=load(O/'mechanical-summary.json')
assert o['project_version']==0 and o['host_boundary_unchanged'] and not o['input_changes']
assert len(o['calls'])==6 and not s['native_failures']
assert all(c['item'].get('exit_code',0)==0 and c['item']['status']=='completed' for c in o['calls'])
assert s['native_call_count_complete'] is False
a={'candidate':o['candidate'],'case':'EFF-04A2','trial':'codex-diagnostic','overall':'pass',
 'method':'Independent semantic review of supplied originals, saved report, final reply, visible calls/results and independent HTTP status. Native-call capture remains incomplete and no exact total is inferred.',
 'content_result':'The report identifies the unspecified audience, problem, benefit, success condition and confirmed product scope. It distinguishes the existing -900 rehearsal outcome from this new request, does not invent an agreed outcome or claim complete content, and requests confirmation with explicit missing facts.',
 'reporting_result':'The saved-report route is correct because capture is incomplete. Both report and final reply limit their failure statements to observed calls. Five successful helper commands and one report write are visible. They include no hosted mutation; the separate service read confirms project version zero. This does not infer an exact native-call total from the visible subset.',
 'findings':[],
 'wording_observation':'The report ends with "No checks were executed" after a table accurately describing readiness checks. In context this refers to planned artifact verification; no tests or artifact validation ran. The final reply explicitly says service checks passed. This phrasing does not negate the correctly retained actions and is not a new failure criterion.',
 'host_diagnostics':o['diagnostics'],
 'host_diagnostic_limit':'Captured host warnings include icon path validation, unsupported PowerShell snapshots and a legacy_notify after-agent hook failure (Windows error 206). These are retained separately from the successful visible native tools. The report does not make an exhaustive zero-failure claim. They do not establish instruction-delivery or desktop qualification.',
 'metrics':o['metrics'],'visible_call_lower_bound':6,'native_call_count_complete':False,
 'report_sha256':hashlib.sha256((O/'native/work/native-report.md').read_bytes()).hexdigest(),
 'project_version':0,'input_changes':[],'host_boundary_unchanged':True,
 'evidence':['native/work/native-report.md','native/events.jsonl','independent-status.json','independent-observations.json','mechanical-summary.json','boundary-probe.json','boundary-probe-assessment.json','payload-provenance-review.json'],
 'limits':['Missing-input diagnostic only; no new hosted artifact or completed positive authoring result.','Exact native call count, model-turn count and input-context measurements are unavailable.','The provider/model default was not overridden; configured gpt-6-astra/high. No equivalent-model performance comparison with earlier defaults is claimed.','Other release qualification and human decisions remain pending.']}
with (O/'independent-assessment.json').open('x',encoding='utf-8') as f:json.dump(a,f,indent=2);f.write('\n')
print(json.dumps({'overall':a['overall'],'metrics':a['metrics'],'visible_call_lower_bound':6}))
