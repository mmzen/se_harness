"""Probe the same supported session-only Codex boundary before native testing."""
import json,socket,subprocess,sys,time,urllib.request
from pathlib import Path
W=Path(__file__).parent;Q=W/'release023-052-qualification'
EXE=r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\2e5e00daee91c61d\codex.exe'
if sys.argv[1]=='inside':
    root=Path(sys.argv[2]);endpoint=sys.argv[3];sentinel=Path(sys.argv[4]);result={}
    for name,action in [
        ('workspace_write',lambda:(root/'owned-write.txt').write_bytes(b'probe\n')),
        ('outside_write',lambda:sentinel.open('r+')),
        ('selected_service',lambda:urllib.request.urlopen(endpoint+'/health',timeout=5)),
        ('external_proxy',lambda:urllib.request.urlopen('https://example.com/',timeout=5)),
        ('external_direct',lambda:socket.create_connection(('1.1.1.1',443),timeout=5))]:
        try:
            x=action();result[name]={'succeeded':True,'status':getattr(x,'status',None)}
            if hasattr(x,'close'):x.close()
        except Exception as exc:result[name]={'succeeded':False,'error':type(exc).__name__,'detail':str(exc)}
    print(json.dumps(result))
else:
    case=sys.argv[1];O=Q/'native'/('codex-'+case)
    selection=json.loads((O/'selection.json').read_text())
    root=O/'boundary-probe';root.mkdir(exist_ok=False)
    sentinel=O/'outside-sentinel.txt';sentinel.write_bytes(b'unchanged\n')
    sys.path.insert(0,str(W/'hag221proposal/tests/hosted_artifact_graph'))
    from qualify_agents import codex_loopback_options
    argv=[EXE,*codex_loopback_options('codex',selection['endpoint']),'sandbox','--include-managed-config','--permission-profile','hag-loopback','--cd',str(root),'--',sys.executable,'-I','-B',str(Path(__file__).resolve()),'inside',str(root),selection['endpoint'],str(sentinel)]
    start=time.monotonic();r=subprocess.run(argv,cwd=root,capture_output=True,text=True,encoding='utf-8',timeout=60)
    record={'argv':argv,'cwd':str(root),'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'elapsed_seconds':time.monotonic()-start}
    with (O/'boundary-probe.json').open('x') as f:json.dump(record,f,indent=2)
    assert r.returncode==0,r.stderr
    facts=json.loads(r.stdout)
    passed=(facts['workspace_write']['succeeded'] and not facts['outside_write']['succeeded'] and facts['selected_service'].get('status')==200
        and not facts['external_proxy']['succeeded'] and '403' in facts['external_proxy'].get('detail','')
        and not facts['external_direct']['succeeded'] and '10013' in facts['external_direct'].get('detail','') and sentinel.read_bytes()==b'unchanged\n')
    v={'overall':'pass' if passed else 'fail','facts':facts,'limit':'Session-only managed network proxy with no allowed external destination. MXC can expose other loopback services; not port isolation. No provider credentials used by probes; no global settings changed.'}
    with (O/'boundary-probe-assessment.json').open('x') as f:json.dump(v,f,indent=2)
    print(json.dumps(v));assert passed
