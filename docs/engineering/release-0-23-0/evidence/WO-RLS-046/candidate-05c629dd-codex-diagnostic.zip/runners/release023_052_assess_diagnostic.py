"""Retain the independently reviewed Claude clarification result."""
import hashlib,json
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'release023-052-qualification/native/claude-diagnostic'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
o=load(O/'independent-observations.json');s=load(O/'mechanical-summary.json')
assert s['native_call_count_complete'] and len(o['calls'])==len(o['results'])==2
assert not s['native_failures'] and not any(x['is_error'] for x in o['results'])
assert o['project_version']==0 and o['host_boundary_unchanged'] and not o['input_changes']
assert o['calls'][0]['input']['command'].endswith(' identity')
assert ' remote status --record ' in o['calls'][1]['input']['command']
a={'candidate':o['candidate'],'case':'EFF-04A2','trial':'claude-diagnostic','overall':'pass',
 'method':'Independent semantic review of the retained final reply, complete paired visible calls/results, unchanged original fixture and instructions, plus a separate authenticated HTTP status read. Assertions bind mechanical observations; no keyword or table detector determines the verdict.',
 'content_result':'Claude acknowledges the existing greeting and governing -900 definitions. It separates the unspecified audience/present problem, partial wanted improvement and missing success condition. It asks what problem the audience has, what observable result is wanted and how the owner will know it helped. The outcome sentence is explicitly proposed, not represented as agreed. It reports Incomplete and does not claim a complete draft or invent an agreed benefit.',
 'reporting_result':'The retained final reply is eligible as the transient clarification report. The complete two-call capture contains only local client identity and a service status read; both succeeded. No hosted mutation was attempted. The independent service read confirms project version zero. There is no authored record or imported baseline to read back; the complete staged fixture bytes are unchanged.',
 'findings':[],
 'report_branch':{'form':'retained final reply','mutation_attempts':0,'capture_complete':True,'independent_project_version':0,'saved_report_required':False},
 'evidence':['independent-observations.json','independent-status.json','mechanical-summary.json','native/events.jsonl','payload-provenance-review.json','boundary-before-native.json','boundary-after-native.json'],
 'metrics':o['metrics'],'input_changes':[],'host_boundary_unchanged':True,
 'guide_sha256':'09912f982b0dbcaadcd3d79f895d91aa83fb3de0f1a32d45f666de8400879be6',
 'simplicity_review':'The shared guide is 19 words shorter (1607 to 1588). It reuses existing requester confirmation and a transient source assessment, with no new tool or mandatory file. This run stopped before unnecessary draft writes. Two calls establish client identity and service readiness. Provider time remains unclassified.',
 'limits':['One negative clarification diagnostic, not positive artifact authoring or proof of general speed improvement.','No current-candidate Codex, positive drafting, full native lifecycle or delivery verdict follows from this result.','Other required release qualification and separate desktop evidence remain pending.','Prior failures retain their original verdicts; no human verification, completion, merge or release decision is recorded.'],
 'next':'Continue the authorized Codex diagnostic with boundary probes and EFF-04B sequence under unchanged criteria.'}
with (O/'independent-assessment.json').open('x',encoding='utf-8') as f:json.dump(a,f,indent=2);f.write('\n')
print(json.dumps({'case':a['case'],'overall':a['overall'],'report_branch':a['report_branch'],'metrics':a['metrics']}))
