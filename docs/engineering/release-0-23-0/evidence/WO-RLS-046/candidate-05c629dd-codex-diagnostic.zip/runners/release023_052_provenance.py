"""Inspect the approved native payload before any provider invocation."""
import hashlib,json,re,subprocess
from pathlib import Path
import hag_efficiency_plan as p
Q=p.W/'release023-052-qualification';O=Q/'native/claude-diagnostic';N=O/'native';I=N/'inputs'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
selection=load(O/'native-selection.json');C=selection['qualification_candidate']
tokens=[x['token'].encode() for f in (Q/'combination/credentials.json',O/'credentials.json') for x in load(f)['principals']]
inventory=load(I/'inventory.json')['files'];entries=[]
old=load(p.W/'h44/e/claude-431/native/inputs/inventory.json')['files'];old_hashes={x['relative']:x['sha256'] for x in old}
preserved=[]
for item in inventory:
    f=Path(item['path']);assert f.resolve().is_relative_to(I.resolve())
    raw=f.read_bytes();assert sha(raw)==item['sha256']
    assert not any(t in raw for t in tokens)
    assert not re.search(rb'sk-ant-(?:oat|ort|api)[^\s"\\]+',raw)
    if item['relative'].startswith(('source/','schemas/','released-resources/')):
        assert sha(raw)==old_hashes[item['relative']];preserved.append(item['relative'])
    entries.append({'path':item['relative'],'bytes':len(raw),'sha256':sha(raw)})
guide=Path(selection['plugin'])/'skills/change/references/hosted-drafts.md'
expected=subprocess.check_output(['git','show',C+':plugins/verity-plane/common/skills/change/references/hosted-drafts.md'],cwd=p.R)
assert guide.read_bytes()==expected and sha(expected)=='09912f982b0dbcaadcd3d79f895d91aa83fb3de0f1a32d45f666de8400879be6'
for name in ('native_call.py','summarize_native.py','native-tools.md','native-execution-tools.md'):
    assert (I/name).read_bytes()==subprocess.check_output(['git','show',C+':tests/hosted_artifact_graph/'+name],cwd=p.R)
report={'candidate':C,'files_scanned':len(entries),'unchanged_fixture_schema_resources':len(preserved),'guide_sha256':sha(expected),
 'classification':'Original operator-selected synthetic fixture and released resources; publicly reviewed candidate guide/client/references; generated localhost/project metadata. No prior result, completed new artifact or expected answer is supplied.',
 'secret_scan':'No generated sandbox token or Anthropic credential signature in staged inputs. Generated sandbox credentials remain outside the staged input root and are supplied only through the qualification helper environment. No provider credential store was inspected.',
 'source_checks':'Complete inventory bytes match; fixture/schema/released-resource files match the retained original input inventory; delivered guide and helper references match exact candidate Git blobs.',
 'entries':entries}
with (O/'payload-provenance-review.json').open('x',encoding='utf-8') as f:json.dump(report,f,indent=2)
print(json.dumps({k:v for k,v in report.items() if k!='entries'}))
