"""Collect native observations without assigning a content verdict."""
import hashlib, json, sys, time, urllib.request
from pathlib import Path
import hag_efficiency_plan as p

Q=p.W/'release023-052-qualification'; O=Q/'native/claude-diagnostic'; N=O/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(name,value):
    if (O/name).exists():
        assert load(O/name)==value, 'Existing observation differs: '+name
        return
    with (O/name).open('x',encoding='utf-8') as f:
        json.dump(value,f,indent=2);f.write('\n')
sys.path.insert(0,str(p.R/'tests/hosted_artifact_graph'))
from summarize_native import summarize
summary=summarize(N); put('mechanical-summary.json',summary)
events=[json.loads(x) for x in (N/'events.jsonl').read_text().splitlines()]
calls=[];results=[];final=[]
for number,event in enumerate(events,1):
    if event.get('type')=='result': final.append(event.get('result'))
    message=event.get('message',{})
    for block in message.get('content',[]) if isinstance(message,dict) else []:
        if block.get('type')=='tool_use': calls.append({'line':number,'id':block['id'],'tool':block['name'],'input':block['input']})
        if block.get('type')=='tool_result': results.append({'line':number,'id':block['tool_use_id'],'is_error':block.get('is_error',False),'content':block.get('content')})
assert {x['id'] for x in calls}=={x['id'] for x in results}
assert summary['native_call_count_complete'] and len(final)==1
selection=load(O/'selection.json'); credentials=load(O/'credentials.json')
token=next(x['token'] for x in credentials['principals'] if x['id']=='operator')
url=selection['endpoint']+'/v1/status';start=time.monotonic()
with urllib.request.urlopen(urllib.request.Request(url,headers={'Authorization':'Bearer '+token}),timeout=30) as response:
    status=response.status;raw=response.read();value=json.loads(raw)
put('independent-status.json',{'method':'GET','url':url,'http_status':status,'elapsed_seconds':time.monotonic()-start,'response':value,'response_sha256':sha(raw),'credential':'Authorization omitted; private test operator only'})
changes=[]
for item in load(N/'inputs/inventory.json')['files']:
    f=Path(item['path'])
    if not f.is_file() or sha(f.read_bytes())!=item['sha256']:changes.append(item['relative'])
observations={'candidate':selection['qualification_candidate'],'trial':'claude-diagnostic','case':'EFF-04A2',
    'input_changes':changes,'host_boundary_unchanged':load(O/'boundary-before-native.json')==load(O/'boundary-after-native.json'),
    'project_version':value['project_version'],'calls':calls,'results':results,'final_reply':final[0],
    'metrics':{k:summary[k] for k in ('wall_seconds','native_calls','model_turns','initial_input_context','peak_input_context')},
    'content_verdict':'not yet assessed'}
put('independent-observations.json',observations)
print(json.dumps({k:v for k,v in observations.items() if k not in ('calls','results')},indent=2))
print(json.dumps({'calls':[{'line':x['line'],'id':x['id'],'tool':x['tool']} for x in calls], 'failed_results':[x for x in results if x['is_error']]},indent=2))
