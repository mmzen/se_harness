"""Independent mechanical assessment; preserve native errors and review limits."""
import hashlib,json,sys,tomllib
from pathlib import Path
W=Path(__file__).parent;Q=W/'release023-054-qualification/native';host=sys.argv[1];r=Q/(host+'-full');n=r/'native';w=n/'work'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
meta=lambda f:tomllib.loads(f.read_text().split('+++')[1])
a=load(r/'replay54/assessment.json');s=load(r/'mechanical-summary.json');o=load(r/'independent-observations.json')
assert len(a['cases'])==12 and all(x['outcome']=='passed' for x in a['cases'])
exports=[x for x in a['exports'] if x['case'].startswith('native-')];assert len(exports)>=2
parity=[load(f) for f in (Q/'native-parity-full54').glob('*'+host+'-full*.json')]
tools={'revision','work-context','compare','impact','lineage','check','cypher'}
matched={x['tool'] for x in parity if x.get('exact_match') and x.get('http_status')==200}
assert tools.issubset(matched),matched
originals=list((n/'inputs/source').rglob('*-900.md'))+[n/'inputs/source/src/greeting.py'];preserved=[];final=[]
for f in w.rglob('manifest.json'):
 if not (f.parent/'history.bundle').is_file():continue
 m=load(f);assert m['test_copy'] is True
 for source in originals:assert m['snapshot']['files'][source.relative_to(n/'inputs/source').as_posix()]['sha256']==sha(source.read_bytes())
 assert not (f.parent/'.incomplete').exists()
 preserved.append({'export':f.parent.relative_to(w).as_posix(),'original_files':len(originals)})
 if any(meta(x)['status']=='released' for x in (f.parent/'files').rglob('RLS-*.md')):final.append(f.parent/'files/docs/engineering/lifecycle-pilot')
assert final
final=final[-1];vr=next(f for f in final.rglob('VREC-*.md') if meta(f)['status']=='verified');rl=next(f for f in final.rglob('RLS-*.md') if meta(f)['status']=='released')
assert meta(vr)['commit']==meta(rl)['commit'];actors=[]
for f in final.rglob('*.md'):
 try:m=meta(f)
 except (ValueError,IndexError):continue
 if m['id'].endswith('-900'):continue
 for e in m.get('lifecycle_events',[]):
  expected=None
  if e['to']=='approved':expected='test-owner'
  elif m['type']=='work_order' and e['to'] in ('in_progress','implemented'):expected='test-executor'
  elif m['type']=='verification_record' and e['to']=='verified':expected='quality-owner'
  elif m['type']=='release_record' and e['to']=='released':expected='release-owner'
  if expected:assert e['decided_by']==expected,(m['id'],e,expected)
  actors.append({'id':m['id'],'to':e['to'],'actor':e['decided_by']})
assert not o['input_changes'] and o['host_boundary_unchanged'] and load(n/'session.json')['exit']==0
v={'candidate':load(r/'selection.json')['qualification_candidate'],'trial':r.name,'accepted_operations_replayed':12,'native_exports':len(exports),'mcp_observations':len(parity),'mcp_tools_exactly_matched':sorted(matched),'mcp_unmatched_observations':[{'tool':x['tool'],'status':x.get('http_status'),'native_call_id':x['native_call_id']} for x in parity if not x.get('exact_match')],'test_candidate':meta(vr)['commit'],'actors':actors,'originals':preserved,'boundaries_unchanged':True,'metrics':{k:s.get(k) for k in ('wall_seconds','native_calls','observed_tool_items','native_call_count_complete','model_turns','initial_input_context','peak_input_context')},'native_failed_items':len(s['native_failures']),'content_review':'Separate manual assessment required; this script does not decide completeness.'}
with (r/'mechanical-assessment.json').open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)
print(json.dumps({k:v[k] for k in ('trial','accepted_operations_replayed','native_exports','mcp_tools_exactly_matched','test_candidate','native_failed_items','metrics')}))
