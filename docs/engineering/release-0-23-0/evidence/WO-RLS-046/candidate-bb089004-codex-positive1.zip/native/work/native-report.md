# Hosted verification draft report

Content readiness: **Complete** for the requested alternative verification plan. Exactly one new artifact, VER-P3-001, was authored and remains draft with owner test-owner and `verifies = ["REQ-P3-900"]`. Imported -900 records remain unchanged. No missing-contract claim is made. No tests, approvals, starts, freezes or lifecycle decisions were performed.

## Content assessment

| Required input | Direct support and saved-content review | Missing question |
| --- | --- | --- |
| Confirmed outcome and scope | User request: “Prepare exactly one new verification-contract draft” and “existing VER-P3-900 and all imported -900 records remain unchanged.” Saved introduction preserves that scope. | None |
| Independent expectation | REQ-P3-900 Acceptance: “Calling greeting() returns exactly `Hello rehearsal`.” SPEC-P3-900 P3-GREET-900 states the same string. Saved Independence derives the expectation from these definitions. | None |
| Requirement, method and pass condition | REQ-P3-900 names method `test`. Execution tools: “Exit 0 with `exact greeting passed` records a passing equality assertion.” Saved matrix maps REQ-P3-900 to that check and pass condition. | None |
| Inputs, platform and evaluator | Supplied selection identifies the source commit, digest and client Python. Execution tools: “It runs locally through `selection.json`'s `client_python`, on the native test host”. Saved acceptance scenario names the Windows host, exact command, assertion evaluator and source identity separately from the Linux service and draft evaluator. | None |
| Meaningful failure outcomes | Execution tools: “A failing assertion returns a nonzero exit” and “The source digest must match the selected `greeting_sha256` before execution.” Saved plan retains failed assertions and digest refusals without inventing extra tests. | None |
| Evidence retention | Execution tools specify “exact command, working directory, exit status, stdout, stderr and elapsed time.” Saved Evidence retention specifies a full new work-directory filename and these supported fields. | None |

The supplied fixture text was inspected: `greeting()` returns the literal specified by the definitions. This is source inspection, not execution. One equality check is sufficient for the requested outcome. The plan does not promise a separate type assertion, local Python-version evidence or commit-bound verification. No required input remains unresolved.

## Saved state

Selection: endpoint `http://127.0.0.1:18963`, project `d22ecae5-2553-48c6-a62a-b8d21400d146`, private test copy, authority mode `sandbox-projection`. [Status](status.json.stdout.txt) reports readiness and component identities matching supplied combination `sha256:e9e47f438dde68f8a87ac4b6dd24ca404333bb381049e2ec3e78677587403250`. Client wheel identity matched version `0.23.0`; selected service evaluator remains `0.22.1`, distinct from the plugin's `0.23.0` evaluator.

Hosted input baseline B: `se-harness-artifact-baseline/v1:sha256:ac97fec20e5402fcf36dfb402b70b48474ce7c75082cc5259ffcbd0430f3ff5d` from the import receipt. Source fixture commit S: `5820415917e87b64d80bad2f7c39c6d18d692829`. Qualification implementation candidate C: `bb0890045f462343ecae66ca30b20b06cf6e8ae6`, established by the supplied selection and identity response. Disposable test Git candidate P is not established in this draft-only task.

Final context: `be9ab1bb-b6d4-4f97-929d-19d8dd35065a`, version `2`; project version `4`. Artifact path: `docs/engineering/lifecycle-pilot/verification/VER-P3-001.md`. Revision: `sha256:8cd585a8aa90642948f455262f8adfe92f04617bd9aaed2d57aa1097f90ec51d`. Document SHA-256: `fed9be0cc57e0855b28aae00778ba1a8a95d71c927575ba07b5d0fe0db39b2db`.

The exact saved document is [read-final.json.evidence/1-document-1.md](read-final.json.evidence/1-document-1.md). The submission file is [VER-P3-001.md](VER-P3-001.md). Each linked result directory retains its exact request and response.

## Validation and review

| Case | Observed outcome and evidence | Limit |
| --- | --- | --- |
| Import, key `codex-positive1-import-01` | Accepted write; [result](import.json.evidence/1-response.json), `outcome`, receipt `1f893fd3-7562-4098-9a86-3a8429d41c08`. | Imports the supplied records; grants no lifecycle authority. |
| Open context, key `codex-positive1-open-01` | Accepted write; [result](draft-open.json.evidence/1-response.json), receipt `e821c788-c74b-4aef-9305-1f954c40c6e6`. Returned `PROC-FOCUS-SELECTED` / `STEP-FOCUS-SELECTED`; no scoped or repository blockers. | Work order remains draft; the returned focus procedure does not start work. |
| Create, key `codex-positive1-create-01` | Accepted write; [result](create.json.evidence/1-response.json), receipt `cac6331b-d33f-4545-9967-732953b66fce`. Template admitted with unfinished body/title/owner/relation. | Included template read reported unresolved `REQ-xxx` and incomplete context. This was corrected in the same draft. |
| Revise, key `codex-positive1-revise-01` | Accepted write; [result](revise.json.evidence/1-response.json), receipt `ae66ccd0-b6bd-4189-b324-08a19509517e`. `admissible: true`, `errors: []`, `incomplete: []`. | Draft shape and required links only; service `content_review: not_assessed`. |
| Exact final revision read | Successful read; [result](read-final.json.evidence/1-response.json), `complete: true`, no unresolved references, no continuation. Decoded document and digest reviewed. | A read is not a mutation or approval. |
| Agent content review | Complete against the assessment above and the saved document. Expected value, check, pass condition, native platform and evidence filename are explicit. | Planned check only; no executed evidence or verified result. |

The evaluator retained this background advisory unchanged: `W-AUT-022`: `Coverage row REQ-P3-900 names undefined rule P3-GREET-900.` It refers to imported `docs/engineering/lifecycle-pilot/specifications/SPEC-P3-900.md`. The task does not authorize modifying that record. No authoring findings were omitted from the compact mutation results.

[Observations](observations.json) returned empty `native_failures` and `failed_command_records`. Capture is in progress and `native_call_count_complete` is false; exhaustive failure counts and complete capture are therefore unassessed. The snapshot excludes this report write. No denial, uncertain mutation effect or failed invocation appears in the inspected results. Exact receipts establish accepted writes; the template's initial incomplete read is retained above rather than treated as an operation failure. The supplied complete-input delivery is not evidence of automatic startup instruction delivery. Lifecycle, MCP parity, reply recovery and export were not assessed.
