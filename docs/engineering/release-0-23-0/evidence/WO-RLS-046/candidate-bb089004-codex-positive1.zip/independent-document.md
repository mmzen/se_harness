+++
id = "VER-P3-001"
type = "verification"
title = "Plan an independent check of the rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-16"
updated = "2026-10-16"

[relations]
verifies = ["REQ-P3-900"]
+++

# Plan an independent check of the rehearsal greeting

Synthetic alternative authoring exercise for an independent reviewer. This draft plans one check of the existing fixture. It does not replace VER-P3-900 or change any imported record. No test has run under this contract, and no verification or lifecycle decision is asserted.

## Independence

The expected result is the literal `Hello rehearsal`, derived from REQ-P3-900 Acceptance and SPEC-P3-900 rule P3-GREET-900. Do not derive or update the expected result from candidate output. The reviewer compares the retained assertion result with this expectation. The synthetic owner test-owner is not evidence of an independent human decision.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-900 | test | One call to greeting() using assert-greeting; retain the record at the full path below. | On the selected native Windows host, the helper's equality assertion against `Hello rehearsal` exits 0 and stdout contains `exact greeting passed`. A nonzero exit or missing success output does not establish a pass. |

## Acceptance scenarios

Input: the existing fixture at `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-054-qualification/native/codex-positive1/native/inputs/source/src/greeting.py`, selected through `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-054-qualification/native/codex-positive1/native/inputs/source-manifest.json`.

The source fixture commit is `5820415917e87b64d80bad2f7c39c6d18d692829`. Before execution, the helper requires the source SHA-256 to match `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`. A digest mismatch prevents assessing the selected fixture; retain the refusal and do not claim a pass.

Planned command, to be run only under separate execution authority in PowerShell:

```powershell
& 'C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe' -I 'C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-054-qualification/native/codex-positive1/native/inputs/native_call.py' assert-greeting --record 'C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-054-qualification/native/codex-positive1/native/work/WO-P3-900-VER-P3-001-assertion.json'
```

The check evaluator is the helper's assert-greeting equality assertion. It invokes the fixture once through `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-054-qualification/client/Scripts/python.exe` on the native Windows test host. It makes no separate type assertion. A returned value unequal to the expected string produces an assertion failure and a nonzero exit. Retain that outcome as a failed check.

The remote client is version `0.23.0`. The service runs on `linux/amd64` with Python `3.13.16`; that is not the test platform. The service's selected SE Harness evaluator `0.22.1` assesses draft shape and required links, not the greeting result.

## Evidence retention

Retain the actual result at `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/release023-054-qualification/native/codex-positive1/native/work/WO-P3-900-VER-P3-001-assertion.json`. This is a proposed new path, not an existing test result. The record retains the exact command, working directory, exit status, stdout, stderr and elapsed time. Preserve any output files referenced by that record, along with the selected source manifest, source commit and source digest. Retain failures as well as successful outcomes; do not replace observed output with an expected result.

## Residual uncertainty

This plan establishes no executed result or commit-bound verification. The assertion record does not report the local Python version. The source fixture commit is not a later verification candidate. The single equality check addresses the requested REQ-P3-900 outcome; this exercise makes no additional assurance claim about external effects, performance, security or release readiness. No required input for this bounded plan remains unresolved.
