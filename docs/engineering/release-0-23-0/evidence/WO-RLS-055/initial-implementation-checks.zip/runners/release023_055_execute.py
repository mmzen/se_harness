"""Apply the supplied WO-RLS-055 approval and exact linked REL amendment."""
import hashlib,json,sys,tomllib
import hag_efficiency_plan as p
R=p.R;O=p.W/'release023-055-execution';p.O=O
D=R/'docs/engineering/release-0-23-0';E=D/'evidence/WO-RLS-055';WO=D/'work-orders/WO-RLS-055.md';REL=D/'release/REL-SEH-036.md'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
meta=lambda f:tomllib.loads(f.read_text().split('+++')[1])
B=load(E/'review-binding.json')
REASON=('Human mmzen answered "I approve" on 2026-10-16 to the explicit WO-RLS-055 request and review at PR #544 head 9c42b4d00e744bc1f3b2461a0819081141dd4c3b. Approves the bounded historical-rehearsal correction, required commit-bound verification under VER-RLS-039, and manual activation of the exact linked REL-SEH-036 membership amendment preserving accepted bytes and lifecycle history. Includes local implementation/checks, actual read-only rehearsal qualification, and ordinary updates to draft PR #544, codex/release-0-23-0 to mmzen/se_harness:main, including the ready aggregate record and a later separately supplied verification decision. Keeps live publication checks, original findings and desktop deferral unchanged. Human verification, merge and exact complete-release approval remain separate. Reviewed WO SHA-256 '+B['work_order']+'.')
def write(f,v):
 with f.open('x',encoding='utf-8') as s:json.dump(v,s,indent=2);s.write('\n')
def brief(v):print(json.dumps(v.get('restitution',v.get('operation',{}))))
args=['transition',R,'--set','WO-RLS-055=approved','--decision','WO-RLS-055=mmzen','--reason','WO-RLS-055='+REASON]
mode=sys.argv[1]
if mode=='approve-preview':
 assert sha(WO)==B['work_order'] and sha(REL)==B['release_before'] and sha(E/'REL-SEH-036-proposed.txt')==B['release_proposed']
 with (E/'WO-RLS-055-reviewed.txt').open('xb') as s:s.write(WO.read_bytes())
 raw=WO.read_bytes();assert b'[assurance]' not in raw
 addition=b'[assurance]\ncommit_bound_verification = "required"\nrationale = "mmzen confirmed required commit-bound verification for the release resolver, workflow and qualification correction."\ndecided_by = "mmzen"\n\n'
 WO.write_bytes(raw.replace(b'[execution_scope]',addition+b'[execution_scope]',1))
 write(O/'confirmed-inputs.json',{'wo_sha256':sha(WO),'rel_before':sha(REL),'rel_proposed':sha(E/'REL-SEH-036-proposed.txt')})
 brief(p.gov('approval-preview',*args,'--json'))
elif mode=='approve-apply':
 assert load(O/'approval-preview.json')['exit']==0 and sha(WO)==load(O/'confirmed-inputs.json')['wo_sha256']
 brief(p.gov('approval-apply',*args,'--apply','--json'))
 assert meta(WO)['status']=='approved' and meta(WO)['lifecycle_events'][-1]['decided_by']=='mmzen'
elif mode=='amend':
 assert meta(WO)['status']=='approved' and sha(REL)==B['release_before'] and sha(E/'REL-SEH-036-proposed.txt')==B['release_proposed']
 old=meta(REL);REL.write_bytes((E/'REL-SEH-036-proposed.txt').read_bytes());new=meta(REL)
 assert old['lifecycle_events']==new['lifecycle_events'] and new['relations']['gates']==[*old['relations']['gates'],'WO-RLS-055']
 write(E/'amendment-applied.json',{'human':'mmzen','decision':REASON,'review_head':'9c42b4d00e744bc1f3b2461a0819081141dd4c3b','before_sha256':B['release_before'],'after_sha256':sha(REL),'lifecycle_history_unchanged':True,'only_change':'Add WO-RLS-055 to REL-SEH-036 gates.','method':'Explicitly authorized manual linked revision; preserved accepted bytes in REL-SEH-036-accepted-before.txt.'})
 brief(p.gov('approved-context','check',R,'--artifact','WO-RLS-055','--json'))
elif mode=='start-preflight':brief(p.gov('start-preflight','preflight',R,'--work-order','WO-RLS-055','--phase','start','--json'))
elif mode in ('start-preview','start-apply'):
 assert load(O/'start-preflight.json')['exit']==0
 a=['transition',R,'--set','WO-RLS-055=in_progress','--decision','WO-RLS-055=Codex']
 if mode=='start-apply':
  assert load(O/'start-preview.json')['exit']==0;a+=['--apply']
 brief(p.gov(mode,*a,'--json'))
elif mode=='context':brief(p.gov('implementation-context','check',R,'--artifact','WO-RLS-055','--json'))
else:raise ValueError(mode)
