"""Retain and publish the approved correction for actual hosted rehearsal."""
import base64,hashlib,json,subprocess,sys,tomllib,zipfile
import hag_efficiency_plan as p
R=p.R;O=p.W/'release023-055-execution';p.O=O
D=R/'docs/engineering/release-0-23-0';E=D/'evidence/WO-RLS-055'
BASE='4fb5dbc29ffd7a2ccdc9a081c9c9b9f82b99d999';BEFORE='9c42b4d00e744bc1f3b2461a0819081141dd4c3b';BRANCH='codex/release-0-23-0'
IDS=['WO-RLS-'+x for x in ('045','046','048','049','050','051','052','053','054','055')]
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,s):
 with f.open('x',encoding='utf-8',newline='\n') as out:out.write(s)
def body(h):return f'''Prepare evaluator/client 0.23.0 and plugin 0.2.7 with the private source-built hosted sandbox. Git remains authoritative. Released evaluator 0.22.1 governs preparation and the service.

Harness-Work-Orders: {', '.join(IDS)}

**Verification pending; draft, not ready to merge.** mmzen approved WO-RLS-055, required commit-bound verification and the exact linked REL-SEH-036 membership amendment. The bounded historical-rehearsal correction is implemented for qualification at review head `{h}`; WO-RLS-055 remains in progress until required actual checks and handoff pass.

[Correction and observed local checks](https://github.com/mmzen/se_harness/blob/{h}/docs/engineering/release-0-23-0/evidence/WO-RLS-055/implementation-review.md) · [Prior candidate qualification](https://github.com/mmzen/se_harness/blob/{h}/docs/engineering/release-0-23-0/evidence/WO-RLS-045/qualification-progress-6fa4d1a6.md) · [Open findings and desktop deferral](https://github.com/mmzen/se_harness/blob/{h}/docs/engineering/release-0-23-0/evidence/WO-RLS-054/open-items.md)

Historical qualification now checks the released record's exact integration bytes and approved/integration documentation. Later main documentation may differ. Live publication still checks current main and retains its default caller. Qualification-only output is refused by publication consumers and is not transferred as a publication bundle. One resolver, build recipe and qualification workflow remain.

Local affected suites: 141 tests, 1 skip, exit 0. The original historical failure and the intermediate regression failures are retained. An intermediate read-only resolution of actual RLS-SEH-033 succeeded; final correction qualification requires the real hosted rehearsal and source/package checks. Final aggregate verification and final archive/staging identities remain pending.

R23-NATIVE-010/011 remain open under DEC-RLS-010 / RISK-RLS-008. Codex Windows desktop remains **not run / unverified** under DEC-RLS-011 / RISK-RLS-009. CLI observations do not establish desktop support. Prior native evidence keeps its actual source and input identities. Required new or changed inputs need checks; no failed or unrun result is a pass.

Earlier preparation WOs 045/046/048–054 are implemented; delivery WO-RLS-047 is approved and unstarted. No release publication, public marketplace promotion, merge, provider-setting change, adoption or host update is included. Full comparison base remains `{BASE}`, target main, PR #544 remains draft. New head `{h}` needs its own CI results. Human verification and exact complete-release approval remain separate.
'''
mode=sys.argv[1]
if mode=='headers':
 assert load(O/'focused-02.json')['exit']==0 and load(O/'implementation-validation.json')['exit']==0
 with zipfile.ZipFile(E/'header-refresh-055.zip','x',zipfile.ZIP_DEFLATED) as z:
  for aid in IDS:
   f=D/'evidence'/aid/(aid+'-handoff.md')
   if f.exists():z.writestr('before/'+aid+'.md',f.read_bytes())
   v=p.gov('header-'+aid,'evidence',R,'--artifact',aid,'--checkpoint','handoff','--json')
   assert f.exists();z.writestr('after/'+aid+'.md',f.read_bytes());z.write(O/('header-'+aid+'.json'),'commands/'+aid+'.json')
   print(json.dumps({'header':aid,'refreshed':True}),flush=True)
 f=E/'WO-RLS-055-handoff.md'
 with f.open('a',encoding='utf-8',newline='\n') as out:out.write('\n## Implementation observations\n\nSee implementation-review.md and initial-implementation-checks.zip for the approved\ncorrection, exact amendment, affected test results and original failures. Actual\nhosted rehearsal and final candidate qualification remain pending; this header\nrefresh supplies no completion, verification or release decision.\n')
elif mode=='report':
 for n in ('focused-02','distribution-check','source-cli-smoke','implementation-validation'):assert load(O/(n+'.json'))['exit']==0
 with zipfile.ZipFile(E/'initial-implementation-checks.zip','x',zipfile.ZIP_DEFLATED) as z:
  for f in sorted(O.glob('*.json')):z.writestr(f.name,f.read_bytes())
  for name in ('release023_055_execute.py','release023_055_progress.py'):z.write(p.W/name,'runners/'+name)
 f=E/'WO-RLS-055-handoff.md'
 with f.open('a',encoding='utf-8',newline='\n') as out:out.write('\n## Implementation observations\n\nSee implementation-review.md and initial-implementation-checks.zip. Local affected\nchecks pass; required actual hosted rehearsal and final candidate qualification\nremain pending. This packet makes no completion or verification decision.\n')
 report='''# Historical release rehearsal correction — implementation review

mmzen approved WO-RLS-055, required commit-bound verification and the exact linked
REL-SEH-036 amendment from review head 9c42b4d00e744bc1f3b2461a0819081141dd4c3b.
The evaluator recorded approval and start. The exact membership amendment is
applied; accepted bytes and lifecycle history remain preserved.

The correction is implemented, but **actual hosted rehearsal and final release
qualification remain pending**. WO-RLS-055 is in progress. No final verification
or release decision is claimed.

## Behavior and scope

The existing resolver has an explicit `--historical` mode for released-record
qualification. It requires the exact released record bytes at its integration
commit and keeps all existing plan, evidence, candidate, marketplace and recipe
checks. Documentation must match at its approved commit and release integration;
later main documentation may differ. The default live route still requires
current-main consistency. The production publisher workflow is unchanged.

Historical output uses a qualification-only schema. Only the two inert bundle
verifiers accept it; publication consumers refuse it. The read-only rehearsal
caller selects that mode and does not upload a publication bundle. The same
qualification/build sequence is reused. No additional service, formal artifact
type, publisher or policy copy was added.

This distinct output label is needed to prevent rehearsal output from being
mistaken for current delivery readiness. Adding a second build lane or disabling
the shared documentation guard would add cost or weaken publication checks.

## Observed local checks

- Affected resolver, delivery, CI and documentation suites: 141 tests, 1 skip,
  exit 0. Distribution validation and source CLI smoke check passed.
- Ordinary artifact validation passed: zero errors. Existing warnings remain.
- An intermediate actual RLS-SEH-033 historical resolution succeeded against
  unchanged origin/main and retained the released 0.22.1 candidate identity.
  It preceded the final record-byte guard; hosted qualification must exercise
  the final committed correction. It is not a final-candidate pass.
- Tests cover legitimate later documentation, changed plan/record/evidence,
  missing history and wrong candidate; bad integration documentation still
  fails. Publication consumers refuse qualification output before a write.
- Original failures remain retained. The first affected run had one assertion
  expecting a different refusal message; the input was already refused.
  A separate record-body regression then exposed missing exact-byte validation
  in historical mode; the new guard fixes it and the regression passes.

## Release limits and next work

Run both real publication rehearsal legs and complete-delivery/recovery tests.
Retain the exact candidate and CI subjects, then finish full required qualification
and handoff. Refresh final package/staging identities and assess input reuse
explicitly before preparing the aggregate VREC. Existing native source observations
remain at their original inputs; no new native or desktop result is inferred.

R23-NATIVE-010/011 stay open under DEC-RLS-010. Codex Windows desktop remains
unverified under DEC-RLS-011. This correction does not repair or retest those
findings. It grants no release, merge, public ref, provider-setting or host change.

initial-implementation-checks.zip retains actual commands, output, exits,
timings, approvals and failed observations. The evaluator refused an attempted
refresh of older WO-RLS-045 because WO-RLS-055 is the only active work order;
header-refresh-055.zip preserves its unchanged prior bytes. Only WO-RLS-055's
own packet was created. The complete PR check passed with the old packets
unchanged. Earlier records and archives remain unchanged.
'''
 put(E/'implementation-review.md',report)
 f=D/'README.md';s=f.read_text();start=s.index('Current status:');end=s.index('Read the [current qualification report]')
 s=s[:start]+'''Current status: **WO-RLS-055 correction is implemented for qualification.**
The historical-rehearsal blocker remains open until the real rehearsal passes.
WO-RLS-045/046/048–054 are implemented; WO-RLS-055 is in progress;
WO-RLS-047 is approved and unstarted. The approved linked membership amendment
is applied. Read the [correction review](evidence/WO-RLS-055/implementation-review.md)
for current results; the earlier candidate report below remains historical.

'''+s[end:]
 s=s.replace('Draft historical-rehearsal correction. Approval and exact linked membership amendment pending.', 'Approved historical-rehearsal correction and exact linked amendment applied; required qualification in progress.')
 f.write_text(s,encoding='utf-8',newline='\n')
 print('Implementation review and actual observations retained.')
elif mode=='validate':
 v=p.gov('review-validation','validate',R,'--json');assert v['valid'];print(json.dumps({k:v.get(k) for k in ('valid','error_count','warning_count')}))
elif mode=='commit':
 assert git('rev-parse','HEAD')==BEFORE and load(O/'review-validation.json')['exit']==0
 scopes=tomllib.loads((D/'work-orders/WO-RLS-055.md').read_text().split('+++')[1])['execution_scope']['paths']
 paths=set(git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines())
 assert paths and all(any(x==s or (s.endswith('/') and x.startswith(s)) for s in scopes) for x in paths)
 assert not git('diff','--cached','--name-only')
 p.run('correction-diff-check',['git','-c','core.whitespace=cr-at-eol','diff','--check'],cwd=R)
 p.run('correction-add',['git','add','--',*sorted(paths)],cwd=R)
 p.run('correction-commit',['git','commit','-m','Separate historical release rehearsal from live delivery readiness','-m','Harness-Work-Orders: '+', '.join(IDS)],cwd=R)
 h=git('rev-parse','HEAD');assert not git('status','--porcelain');put(O/'implementation-head.txt',h+'\n');print(json.dumps({'head':h,'paths':len(paths)}))
elif mode=='checks':
 h=git('rev-parse','HEAD');put(O/'review-body.md',body(h));put(O/'review-event.json',json.dumps({'pull_request':{'body':body(h)}})+'\n')
 v=p.gov('review-check-pr','check-pr',R,'--event',O/'review-event.json','--from-git',BASE,'--json');assert v['status']=='pass'
 scopes=tomllib.loads((D/'work-orders/WO-RLS-055.md').read_text().split('+++')[1])['execution_scope']['paths']
 paths=[x for x in v['changed_paths'] if any(x==s or (s.endswith('/') and x.startswith(s)) for s in scopes)]
 put(O/'publication-paths.json',json.dumps({'head':h,'base':BASE,'selected':paths,'other_approved_paths':[x for x in v['changed_paths'] if x not in paths]},indent=2)+'\n')
 a=['check',R,'--artifact','WO-RLS-055','--checkpoint','pre-action']
 for path in paths:a+=['--changed-path',path]
 v=p.gov('review-preaction',*a,'--changes-complete','--json');assert v['compliance']['status']=='pass';print('Review checks passed.')
elif mode=='publish':
 h=git('rev-parse','HEAD');assert not git('status','--porcelain')
 assert load(O/'review-check-pr.json')['exit']==load(O/'review-preaction.json')['exit']==0
 assert load(O/'publication-paths.json')['head']==h and (O/'review-body.md').read_text()==body(h)
 before=p.run('publication-remote-before',['gh','pr','view','544','--repo','mmzen/se_harness','--json','headRefOid,headRefName,baseRefName,isDraft'],cwd=R)
 assert before=={'headRefOid':BEFORE,'headRefName':BRANCH,'baseRefName':'main','isDraft':True}
 rules=p.run('publication-controls',['gh','api','repos/mmzen/se_harness/rulesets/20693381'],cwd=R)
 assert rules['enforcement']=='active' and {'required_status_checks','pull_request','non_fast_forward','deletion'}<={x['type'] for x in rules['rules']}
 subprocess.run(['git','merge-base','--is-ancestor',BEFORE,h],cwd=R,check=True)
 p.run('publication-push',['git','push','origin',h+':refs/heads/'+BRANCH],cwd=R)
 p.run('publication-edit',['gh','pr','edit','544','--repo','mmzen/se_harness','--body-file',O/'review-body.md'],cwd=R)
 after=p.run('publication-remote-after',['gh','pr','view','544','--repo','mmzen/se_harness','--json','headRefOid,headRefName,baseRefName,isDraft,body'],cwd=R)
 assert after=={'headRefOid':h,'headRefName':BRANCH,'baseRefName':'main','isDraft':True,'body':body(h)}
 rel='docs/engineering/release-0-23-0/evidence/WO-RLS-055/implementation-review.md'
 read=p.run('publication-readable-review',['gh','api',f'repos/mmzen/se_harness/contents/{rel}?ref={h}'],cwd=R)
 assert base64.b64decode(read['content'])==subprocess.check_output(['git','show',h+':'+rel],cwd=R)
 print(json.dumps({'head':h,'review_readback':True,'draft':True}))
else:raise ValueError(mode)
