"""Retain fresh candidate CI and independently compare its tested Git tree."""
import json,re,subprocess,sys
import hag_efficiency_plan as p
Q=p.W/'release023-052-qualification';p.O=Q
C=(p.W/'release023-052-execution/candidate-head.txt').read_text().strip()
mode=sys.argv[1]
if mode=='snapshot':
    label='ci-snapshot-'+sys.argv[2]
    v=p.run(label,['gh','pr','view','544','--repo','mmzen/se_harness','--json','headRefOid,statusCheckRollup'],cwd=p.R)
    assert v['headRefOid']==C
    print(json.dumps([{'name':x['name'],'status':x['status'],'conclusion':x.get('conclusion'),'url':x.get('detailsUrl')} for x in v['statusCheckRollup']]))
elif mode=='source':
    v=p.run('candidate-ci-snapshot',['gh','pr','view','544','--repo','mmzen/se_harness','--json','headRefOid,statusCheckRollup'],cwd=p.R)
    assert v['headRefOid']==C
    item=next(x for x in v['statusCheckRollup'] if x['name']=='Candidate source evidence')
    assert item['status']=='COMPLETED' and item['conclusion']=='SUCCESS'
    run_id=re.search(r'/runs/(\d+)/',item['detailsUrl']).group(1)
    dest=Q/'ci-source-raw';assert not dest.exists()
    p.run('ci-source-download',['gh','run','download',run_id,'--repo','mmzen/se_harness','--name','candidate-source-raw','--dir',dest],cwd=p.R)
    evidence=json.loads((dest/'summary.json').read_text());assert evidence['result']=='pass' and evidence['exit_code']==0 and evidence['working_tree']=='clean'
    tested=evidence['candidate']
    commit=p.run('ci-merge-commit',['gh','api','repos/mmzen/se_harness/git/commits/'+tested],cwd=p.R)
    tree=subprocess.check_output(['git','rev-parse',C+'^{tree}'],cwd=p.R,text=True).strip()
    assert commit['tree']['sha']==tree
    match=re.search(r'Ran (\d+) tests in ([\d.]+)s',evidence['output_tail']);assert match
    skip=re.search(r'OK \(skipped=(\d+)\)',evidence['output_tail'])
    result={'candidate':C,'tested_commit':tested,'complete_tree':tree,'exact_tree_match':True,'run_id':int(run_id),'source_result':'pass','tests':int(match[1]),'skips':int(skip[1]) if skip else 0,'test_seconds':float(match[2]),'limit':'CI tested its PR merge commit; full Git tree equals the candidate. Distinct commits retained. CI packages are not promoted.'}
    with (Q/'ci-source-comparison.json').open('x') as f:json.dump(result,f,indent=2)
    print(json.dumps(result))
else:raise ValueError(mode)
