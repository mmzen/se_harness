"""Install the exact source archive by index selection in a disposable environment."""
import hashlib,json,sys
import hag_efficiency_plan as p
Q=p.W/'release023-052-qualification';O=Q/'windows-sdist';O.mkdir(exist_ok=False);p.O=O
C=(p.W/'release023-052-execution/candidate-head.txt').read_text().strip()
def run(label,args):
    result=p.run(label,args,cwd=p.W,allowed=(0,1,2))
    r=json.loads((O/(label+'.json')).read_text())
    print(json.dumps({'label':label,'exit':r['exit'],'seconds':r['elapsed_seconds']}),flush=True)
    assert r['exit']==0,label
    return result
run('environment',[sys.executable,'-I','-m','venv',O/'environment'])
python=O/'environment/Scripts/python.exe'
run('build-tools',[python,'-I','-m','pip','install','--disable-pip-version-check','--require-hashes','-r',p.R/'release/build-toolchain.lock'])
run('install',[python,'-I','-m','pip','install','--disable-pip-version-check','--no-index','--no-deps','--no-build-isolation','--no-cache-dir',
    '--find-links',Q/'bundle','--no-binary=se-harness','se-harness==0.23.0'])
run('identity',[python,'-I','-m','se_harness','identity','--role','candidate-package','--expected-version','0.23.0',
    '--expected-root',O/'environment','--candidate-commit',C,'--checkout-root',p.R,'--entry-point',O/'environment/Scripts/harnessctl.exe',
    '--require-isolated-python','--require-entry-point'])
run('surface',[python,'-I',p.R/'scripts/check_portable_release_surface.py','--harnessctl',O/'environment/Scripts/harnessctl.exe'])
run('init',[python,'-I','-m','se_harness','init',O/'target','--project-name','Disposable source package qualification','--json'])
run('doctor',[python,'-I','-m','se_harness','doctor',O/'target','--json'])
with (O/'assessment.json').open('x') as f:
    json.dump({'candidate':C,'state':'passed','archive_sha256':hashlib.sha256((Q/'bundle/se_harness-0.23.0.tar.gz').read_bytes()).hexdigest(),
    'method':'Index-selected exact local sdist, no binary/cached se-harness, isolated disposable environment. Hash-pinned build tools; init and doctor outside source.',
    'limit':'This does not establish support for direct archive-path PEP 610 sdist installation or qualify the separately promoted wheel.'},f,indent=2)
