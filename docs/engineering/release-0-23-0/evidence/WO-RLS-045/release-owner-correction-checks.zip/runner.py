import base64,difflib,json,subprocess,sys,tomllib,zipfile
import release023_delivery as d
R=d.R;O=d.O;P=d.P;E=d.E;probe=d.W/'r23op'
mode=sys.argv[1]
if mode=='probe':
    assert d.git('rev-parse','HEAD')==d.H and not d.git('status','--porcelain') and not probe.exists()
    d.plan();assert d.record()['status']=='ready'
    d.p.run('owner-probe-clone',['git','clone','--shared','--no-checkout','--config','core.longpaths=true','--config','core.autocrlf=false',R,probe])
    d.p.run('owner-probe-checkout',['git','checkout','--detach',d.H],cwd=probe)
    old=(R/d.RECORD).read_bytes();assert old==(probe/d.RECORD).read_bytes()==d.blob(d.H,d.RECORD)
    assert old.count(b'owners = ["Codex"]')==1
    new=old.replace(b'owners = ["Codex"]',b'owners = ["mmzen"]',1);(probe/d.RECORD).write_bytes(new)
    patch=''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+d.RECORD,tofile='b/'+d.RECORD))
    d.put(O/'release-owner-correction.patch',patch)
    result=d.p.gov('owner-proposal-validation','validate',probe,'--json');assert result['valid']
    result=d.p.gov('owner-proposal-preview','transition',probe,'--set','RLS-SEH-034=released','--decision','RLS-SEH-034=mmzen','--reason','RLS-SEH-034=Read-only diagnosis of proposed owner correction. mmzen approved the complete release; owner and review-base amendment remains pending. No transition is applied.','--json')
    assert not result['findings']['scoped_blockers'] and (probe/d.RECORD).read_bytes()==new and (R/d.RECORD).read_bytes()==old
    d.put(O/'owner-proposal-result.json',{'candidate_commit':d.C,'plan_sha256':d.SHA,'before_sha256':d.sha(old),'after_sha256':d.sha(new),'only_changed_field':'owners','before':['Codex'],'proposed':['mmzen'],'prepared_by':'Codex','proposal_validation':'pass','read_only_transition_preview':'pass','real_record_unchanged':True,'state':'ready'})
    print('One-line ownership proposal validates and previews successfully; real record unchanged.')
elif mode=='finish-probe':
    old=(O/'RLS-SEH-034-before.md').read_bytes();new=old.replace(b'owners = ["Codex"]',b'owners = ["mmzen"]',1)
    observation=d.load(O/'owner-proposal-preview.json');result=json.loads(observation['stdout'])
    assert observation['exit']==0 and '--apply' not in observation['argv'] and not result['findings']['scoped_blockers']
    assert (probe/d.RECORD).read_bytes()==new and (R/d.RECORD).read_bytes()==old
    assert tomllib.loads(new.decode().split('+++',2)[1])['status']=='ready'
    d.put(O/'owner-proposal-result.json',{'candidate_commit':d.C,'plan_sha256':d.SHA,'before_sha256':d.sha(old),'after_sha256':d.sha(new),'only_changed_field':'owners','before':['Codex'],'proposed':['mmzen'],'prepared_by':'Codex','proposal_validation':'pass','read_only_transition_preview':'pass','real_record_unchanged':True,'state':'ready','observation_note':'Preview reports proposed writes. An initial helper assertion mistook that list for applied writes; exact filesystem comparison confirms no transition was applied.'})
    print('Successful preview confirmed against unchanged filesystem state.')
elif mode=='retain':
    assert d.git('rev-parse','HEAD')==d.H and not d.git('status','--porcelain')
    assert d.load(O/'owner-proposal-result.json')['real_record_unchanged']
    assert (R/d.RECORD).read_bytes()==(O/'RLS-SEH-034-before.md').read_bytes()
    with (R/E/'release-owner-correction.patch').open('xb') as f:f.write((O/'release-owner-correction.patch').read_bytes())
    with zipfile.ZipFile(R/E/'release-owner-correction-checks.zip','x',zipfile.ZIP_DEFLATED) as z:
        for name in ('release-context.json','release-preview.json','transition-help.json','RLS-SEH-034-before.md','owner-probe-clone.json','owner-probe-checkout.json','owner-proposal-validation.json','owner-proposal-preview.json','owner-proposal-result.json'):z.write(O/name,name)
        z.write(d.W/'release023_owner_proposal.py','runner.py')
    review=f'''# Correct the release owner and continue the approved release

mmzen approved the complete evaluator/client 0.23.0 and plugin 0.2.7 release.
That approval remains retained. The released 0.22.1 evaluator refused its
transition preview with `WEX201` / `E009`: `authorized_by` must name a record
owner, while generated RLS-SEH-034 has `owners = ["Codex"]`.
The record remains **ready**. No release transition, merge or publication occurred.

## Exact proposed correction

Change one line in [RLS-SEH-034](../../releases/RLS-SEH-034.md):

```diff
-owners = ["Codex"]
+owners = ["mmzen"]
```

Preserve `prepared_by = "Codex"`, state, history, candidate, distributions,
relations, body and all bound evidence. The [exact patch](release-owner-correction.patch)
remains unapplied in the real checkout. This corrects a ready release input;
it changes no evaluator code, binary, plugin, test or provider setting.

## Evidence and cause

The generated owner conflates the preparation actor with the accountable release
human. `transition` offers no owner-binding parameter. The existing `decide`
owner-binding feature concerns question/deviation records, not this operation.
Recording Codex as the decision-maker would misattribute the human decision.

The same issue was recorded during the 0.22.1 release. It remains present in
the selected evaluator. I missed that known preparation condition. A passing
transition gate check did not detect it; the exact read-only transition preview
should have been performed before the final approval request.

In a separate disposable checkout of `{d.H}`, the proposed one-line input
passes released 0.22.1 validation and the read-only transition preview as mmzen.
No transition was applied there. The real record remains byte-identical to its
reviewed version. [Raw evidence](release-owner-correction-checks.zip) retains
the refused real preview, original bytes, exact commands and passing proposal.

Follow-up: distinguish preparer and release owner in record preparation, and
ensure the final decision preview is checked before asking for release approval.
This is an open follow-up, not a change to the already verified 0.23.0 payload.

## Bounded amendment to the reviewed base

The approved plan permits only the recorded decision after its review base.
Changing ownership therefore needs this explicit amendment. Approve the one-line
owner correction and the following precise rule for the new pre-decision base:

1. Start at the published commit containing only these three proposal files
   on top of `{d.H}`.
2. Add a separate commit changing only the RLS owner line shown above.
3. Use that exact resulting commit as the amended review base. Compare the
   derivation before applying the human release decision.

Keep the frozen plan bytes and SHA-256
`{d.SHA}` unchanged. Re-preview and record the existing complete-release decision
as mmzen, then require the publisher's normal decision-only integration check.
The original grant continues for its unchanged payloads, destinations, receipt
paths, provider checks and recovery rules. No gate is waived.

Candidate `{d.C}`, evaluator/client 0.23.0, plugin 0.2.7 and the accepted
DEC-RLS-010/011 limitations are unchanged. Adoption and user-host updates remain
excluded. No repeat approval of the unchanged release/publication plan is requested.

**Response requested:** Approve the owner correction and continue.
Until that response, keep the real RLS ready and PR #545 draft.
'''
    d.put(R/E/'release-owner-correction-review.md',review)
    result=d.p.gov('owner-proposal-real-validation','validate',R,'--json');assert result['valid']
    print('Unapplied correction and bounded review-base amendment prepared.')
elif mode=='commit':
    paths=[E+'release-owner-correction.patch',E+'release-owner-correction-checks.zip',E+'release-owner-correction-review.md']
    assert d.git('rev-parse','HEAD')==d.H and not d.git('diff','--name-only') and not d.git('diff','--cached','--name-only')
    assert set(d.git('ls-files','--others','--exclude-standard').splitlines())==set(paths)
    d.p.run('owner-proposal-add',['git','add','--',*paths],cwd=R)
    d.p.run('owner-proposal-commit',['git','commit','-m','Review the RLS owner correction and bounded approval-base amendment','-m','Harness-Work-Orders: WO-RLS-045, WO-RLS-047'],cwd=R)
    h=d.git('rev-parse','HEAD');d.put(O/'owner-proposal-head.txt',h+'\n');print(h)
elif mode=='checks':
    h=(O/'owner-proposal-head.txt').read_text().strip();assert d.git('rev-parse','HEAD')==h
    prior=d.p.run('owner-proposal-pr-before',['gh','pr','view','545','--repo','mmzen/se_harness','--json','headRefOid,headRefName,baseRefName,state,isDraft,body'],cwd=R)
    assert prior['headRefOid']==d.H and prior['headRefName']==d.BRANCH and prior['baseRefName']=='main' and prior['state']=='OPEN' and prior['isDraft']
    body=prior['body'].replace('**RLS-SEH-034 is ready. Complete-release approval is pending; keep draft.**','**mmzen approved the complete release. Its transition preview was refused because the prepared RLS owner is Codex, while the release human is mmzen. RLS-SEH-034 remains ready; keep draft while the exact owner/base correction is reviewed.**')
    body+=f'\n[One-line owner correction and bounded review-base amendment](https://github.com/mmzen/se_harness/blob/{h}/{E}release-owner-correction-review.md). The real RLS is unchanged. A disposable validation and read-only transition preview pass. Existing complete-release authority is retained; no public action has occurred.\n'
    d.put(O/'owner-proposal-body.md',body);d.put(O/'owner-proposal-event.json',{'pull_request':{'body':body}})
    result=d.p.gov('owner-proposal-pr-check','check-pr',R,'--event',O/'owner-proposal-event.json','--from-git',d.BASE,'--json');assert result['status']=='pass'
    args=['check',R,'--artifact','WO-RLS-047','--checkpoint','pre-action']
    for name in result['changed_paths']:args+=['--changed-path',name]
    result=d.p.gov('owner-proposal-preaction',*args,'--changes-complete','--json');assert result['compliance']['status']=='pass'
    print('Proposal publication scope and pre-action checks pass.')
elif mode=='publish':
    h=(O/'owner-proposal-head.txt').read_text().strip();assert d.git('rev-parse','HEAD')==h and not d.git('status','--porcelain')
    assert d.load(O/'owner-proposal-pr-check.json')['exit']==d.load(O/'owner-proposal-preaction.json')['exit']==0
    d.plan();assert (R/d.RECORD).read_bytes()==(O/'RLS-SEH-034-before.md').read_bytes()
    d.p.run('owner-proposal-push',['git','push','origin',h+':refs/heads/'+d.BRANCH],cwd=R)
    d.p.run('owner-proposal-pr-edit',['gh','pr','edit','545','--repo','mmzen/se_harness','--body-file',O/'owner-proposal-body.md'],cwd=R)
    actual=d.p.run('owner-proposal-readback',['gh','pr','view','545','--repo','mmzen/se_harness','--json','headRefOid,baseRefName,isDraft,state,body'],cwd=R)
    assert actual['headRefOid']==h and actual['baseRefName']=='main' and actual['isDraft'] and actual['state']=='OPEN'
    assert actual['body'].replace('\r\n','\n')==(O/'owner-proposal-body.md').read_text()
    value=d.p.run('owner-proposal-readable',['gh','api',f'repos/mmzen/se_harness/contents/{E}release-owner-correction-review.md?ref={h}'],cwd=R)
    assert base64.b64decode(value['content'])==d.blob(h,E+'release-owner-correction-review.md')
    print(json.dumps({'review_head':h,'url':'https://github.com/mmzen/se_harness/pull/545','owner_correction':'unapplied','original_complete_release_approval':'retained'}))
else:raise ValueError(mode)
