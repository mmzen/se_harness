"""Validate exact retained observations and freshly check the committed candidate."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,tomllib,zipfile
C,name,digest=sys.argv[1:];receipt=Path(name);raw=receipt.read_bytes()
assert hashlib.sha256(raw).hexdigest()==digest
r=json.loads(raw);assert r['candidate']==C
root=Path.cwd()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==C
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
for row in r['files']:
    f=Path(r['evidence_root'])/row['path'];assert hashlib.sha256(f.read_bytes()).hexdigest()==row['sha256'],row['path']
    if f.suffix=='.zip':
        with zipfile.ZipFile(f) as z:assert z.testzip() is None,f
domain=root/'docs/engineering/release-0-23-0'
meta=lambda f:tomllib.loads(f.read_text(encoding='utf-8').split('+++')[1])
rel=meta(domain/'release/REL-SEH-036.md');assert set(rel['relations']['gates'])==set(r['work'])
files={f.stem:f for f in (root/'docs/engineering').rglob('WO-*.md') if f.stem in r['work']}
assert set(files)==set(r['work'])
declared=set()
for f in files.values():
    m=meta(f);assert m['status']=='implemented';declared.update(m['relations']['verification'])
assert declared==set(r['verification'])
for n in ('010','011'):
    m=meta(domain/('decisions/DEC-RLS-'+n+'.md'));assert m['status']=='decided' and m['disposition']['option']=='accept' and m['disposition']['decided_by']=='mmzen'
env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1');env.pop('PYTHONPATH',None)
argv=[sys.executable,'-B','-X','utf8','-m','se_harness','qualify','complete-candidate','.', '--candidate-commit',C,'--json']
result=subprocess.run(argv,env=env,capture_output=True,text=True,encoding='utf-8',timeout=900)
out=receipt.parent/'capture-candidate-check.json'
with out.open('x',encoding='utf-8') as f:json.dump({'argv':argv,'cwd':str(root),'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr},f,indent=2)
assert result.returncode==0,result.stdout+result.stderr
print(json.dumps({'candidate':C,'receipt_sha256':digest,'bound_files':len(r['files']),'selected_work':r['work'],'verification_contracts':r['verification'],'fresh_complete_candidate':json.loads(result.stdout),'assessment':r['assessment'],'limits':'Retained historical observations keep their original subjects; source/package/runtime comparisons state reuse. Desktop remains unverified and the accepted instruction findings remain failed/open. No human verification, merge, release or public delivery is supplied.'},sort_keys=True))
