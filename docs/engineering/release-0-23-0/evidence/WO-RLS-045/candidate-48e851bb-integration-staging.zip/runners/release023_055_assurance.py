"""Assemble the bounded final assessment and exact evidence list before capture."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tomllib,zipfile
import hag_efficiency_plan as p
W=p.W;R=p.R;Q=W/'release023-final-055';D=R/'docs/engineering/release-0-23-0'
C=(Q/'candidate-source.txt').read_text().strip();short=C[:8]
sha=lambda b:hashlib.sha256(b).hexdigest()
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
def put(f,s):
    with f.open('x',encoding='utf-8',newline='\n') as out:out.write(s)
def copy(src,dst):
    with dst.open('xb') as out:out.write(src.read_bytes())
mode=sys.argv[1]
if mode=='extras':
    src=(W/'release023_054_retain.py').read_text().split('mode=sys.argv[1]')[0]
    src=src.replace("Q=W/'release023-054-qualification';O=W/'release023-054-execution'","Q=W/'release023-final-055';O=Q").replace("(O/'candidate-head.txt')","(Q/'candidate-source.txt')")
    src=src.replace("if k in ('thinking','signature','reasoning_content'):","if k in ('thinking','reasoning_content'):")
    ns={'__file__':str(W/'release023_054_retain.py')};exec(compile(src,'retention-functions','exec'),ns)
    files={}
    for sub in ('integration-ci','marketplace-review'):
        for f in (Q/sub).rglob('*.json'):files[sub+'/'+f.relative_to(Q/sub).as_posix()]=f
    for name in ('release023_055_assurance.py','release023_055_capture_checks.py','release023_055_capture.py','release023_055_ci.py','release023_055_marketplace.py'):
        if (W/name).is_file():files['runners/'+name]=W/name
    label='candidate-'+short+'-integration-staging'
    ns['archive'](label,files)
    meta=load(Q/'retained'/(label+'.metadata.json'));target=D/'evidence/WO-RLS-045'/(label+'.zip');copy(Q/'retained'/(label+'.zip'),target)
    index_path=D/'evidence/WO-RLS-045'/('evidence-index-'+short+'.json');index=load(index_path)
    index['records'].append({'path':target.relative_to(R).as_posix(),**meta})
    for n in ('marketplace-review-commit','marketplace-review-publication'):
        target=D/'evidence/WO-RLS-046'/(n+'-'+short+'.json');copy(Q/'marketplace-review'/(n+'.json'),target)
        index['records'].append({'path':target.relative_to(R).as_posix(),'sha256':sha(target.read_bytes()),'bytes':target.stat().st_size})
    for name in ('service-boundary-reuse.json','windows-source-applicability.json','final-coverage.json'):
        target=D/'evidence/WO-RLS-045'/('candidate-'+short+'-'+name);copy(Q/name,target)
        index['records'].append({'path':target.relative_to(R).as_posix(),'sha256':sha(target.read_bytes()),'bytes':target.stat().st_size})
    index_path.write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'retained_records':len(index['records'])}))
elif mode=='report':
    for name in ('recipe-replay','released-package-verification','installed-cli-surface','portable-plugin-tests','stage-plugins','combination-build','linux-packages-01','windows-upgrade-2','windows-upgrade-3','client-walkthrough','restart-restore'):
        assert load(Q/(name+'.json'))['exit']==0,name
    ci=load(Q/'ci-source-comparison.json');assert ci['whole_tree_equal'] and ci['manual_candidate_replay']['manifest_equals_local']
    checks=json.loads(load(Q/'ci-snapshot-completed.json')['stdout']);assert checks['headRefOid']==C and all(x['conclusion']=='SUCCESS' for x in checks['statusCheckRollup'])
    coverage=load(Q/'final-coverage.json');assert len(coverage['work'])==20 and len(coverage['verification'])==11
    bundle=load(Q/'bundle-manifest.json');combo=load(Q/'combination/combination.json');staging=load(Q/'marketplace-review/marketplace-review-publication.json')
    assert staging['public_before']==staging['public_after']
    text=f'''# Final release verification assessment — 0.23.0 / plugin 0.2.7

The candidate is ready for the human verification decision, subject to the
existing release-only dispositions below. No verification decision is supplied
by this assessment. The later review commit contains this evidence and the
generated VREC; it does not replace the assessed candidate.

Candidate: `{C}`. Selected governor: released **0.22.1**, outside the checkout.
The private hosted service remains source-built; Git remains authoritative.
The final record covers exactly **20 implemented work orders and 11 contracts**
declared by REL-SEH-036. The [coverage file](candidate-{short}-final-coverage.json)
lists every ID and path. Delivery WO-RLS-047 remains approved and unstarted.

## Observed final checks

| Check | Result and exact applicability |
| --- | --- |
| Windows source | 1,346 tests, 24 skips, exit 0 at `c740d49e30da74bab27ad29bb59fef2e785a6eae`. Reused with an [explicit comparison](candidate-{short}-windows-source-applicability.json): only seven release completion/evidence files changed afterward. The initial sandbox access failure is retained. |
| Linux source | 1,346 tests, 2 skips, exit 0 at CI subject `{ci['ci_tested_commit']}`. Its entire Git tree equals C. |
| Reproducible build | Two pinned local producer runs match byte-for-byte. The independent [exact-head GitHub replay](https://github.com/mmzen/se_harness/actions/runs/38903274786) has the identical full bundle manifest. Historical RLS-SEH-033 and complete-delivery/recovery rehearsals also pass. |
| Installed archives | Exact final wheel and index-selected sdist pass on Windows and Linux. Released independent package checks pass. No direct archive-path PEP 610 sdist claim is made. |
| Upgrade | Two real Windows 0.22.1-to-0.23.0 runs pass with matching semantic digest. Both CI platform upgrade jobs pass. |
| Plugin assembly | 47 portable tests, 2 skips; both 0.2.7 packages contain the exact final wheel. All 89 staged Git blobs match the qualified files. |
| Hosted combination | Fresh final packaged walkthrough: 18 commands, including expected refusals. Restart and consistent restore pass. Fixed evaluator remains 0.22.1. |
| Unchanged service boundaries | Reused from candidate `6fa4d1a6`, explicitly compared in [the reuse record](candidate-{short}-service-boundary-reuse.json). Server runtime, dependencies, fixed source fixture and operational policy inputs match. These are not fresh boundary runs. |
| Integration package | All 19 CI checks pass at C, including deterministic integration build and independent same-byte Windows/Linux installs. The exact source TAR is 602,767,360 bytes; expanded file total 590,043,102 bytes; 17,735 members. All remain within fixed 1 GiB / 20,000-entry limits. The non-promotable PR package is distinct from the release archives. |

## Contract assessment

| Contract | Evidence and assessment |
| --- | --- |
| VER-HAG-001 | Original import/immutability/atomicity/graph outcomes in preserved VREC-HAG-004 and its bound evidence; current server/client byte comparisons, fixed imported Git bytes, final walkthrough and recovery corroborate integration. Unchanged service boundaries are reused as labelled. |
| VER-HAG-004 / VER-HAG-005 | VREC-HAG-003 and exact unchanged evidence retain evaluator-pin reconciliation, stacked-branch adoption assessment and history preservation. The final combination independently names the pinned released evaluator and actual component identities. |
| VER-HAG-006 | VREC-HAG-005 retains private lifecycle parity, authority/operation boundaries, rollback/staleness/retry, exact export/replay and compatibility. New final archive admission, packaged walkthrough and restore pass; unchanged mechanisms and their original results are compared explicitly. |
| VER-HAG-007 / VER-HAG-008 | VREC-HAG-006/007 retain their accepted contract scope. Native and independent replay/read observations at `bb089004` are reused through exact runtime/instruction/fixture comparisons. Original failures and the two release findings stay visible; this does not convert failed drafting/content cases into passes. |
| VER-HUP-025 | Preserved VREC-HUP-028 and its exact candidate-bound evidence; fresh final two-run upgrade qualification and both CI platform jobs assess current integration. |
| VER-IAR-021 | Preserved native bootstrap, selection, resume/compaction, isolation and delivery-gap evidence at `bb089004`, including actual host/session identities. Portable assembly/selection tests run again. Desktop is unverified under the new bounded disposition; CLI results do not cover it. |
| VER-IPK-002 | Fresh final integration CI build/Windows/Linux receipts, source size/count/hash, full source suites and preserved hostile-input regressions. Prior VREC-IPK-002 stays unchanged. |
| VER-RLS-039 | Final membership, source/package/build/upgrade observations, exact manual rehearsal, archive/staging identity and preserved governing records. WO-RLS-055 resolves the historical-rehearsal blocker with actual qualification. Later ready-RLS replay and complete-release authority remain separate procedures. |
| VER-RLS-040 | Both final plugin inventories and public-parent staging readback; actual coordinated image/configuration; fresh final walkthrough/recovery; explicit native/service reuse. The accepted native findings and desktop omission remain limits. |

The [source/package comparison](candidate-{short}-source-package-reuse-comparison.json)
checks all 127 expanded wheel members, both host inventories and nine historical
verification records with their bound evidence. The [service comparison](candidate-{short}-service-runtime-reuse-comparison.json)
checks all 27 expanded server members and fixed dependencies. C54-to-C6 comparisons
are retained unchanged; C6-to-C comparisons extend that evidence chain. Archive,
inventory, source and image identities differ and are assessed separately.

The release census remains advisory: it reports missing singular trailers for
some first-parent commits, including combined work-order declarations. This is
not an exemption or a passing census claim. REL-SEH-036's reviewed 20-work-order
membership supplies formal scope; earlier 0.22.1 publication records remain
historical and are not reclassified as new product work.

## Open items carried into the decision

- **R23-NATIVE-010 remains open:** the separate Codex read-only trial explained
  before reading communication policy. Functional reads passed; the instruction
  failure did not. DEC-RLS-010 / RISK-RLS-008 accepts this release-only carry.
- **R23-NATIVE-011 remains open:** both proposed work orders omitted generated
  verification paths. Separate seeded execution does not repair those drafts.
  The same bounded disposition applies.
- **Codex Windows desktop remains not run / unverified**, under DEC-RLS-011 /
  RISK-RLS-009. Complete desktop qualification before the next plugin release or
  a verified-desktop claim.
- Duration/context improvements remain separate. RISK-HAG-001/002 retain the
  private-sandbox and deferred database-control boundaries.

These decisions do not mark failures or unrun cases passed. Historical native
indexes retain the readiness statements from when they were written; the later
DEC-RLS-010/011 records provide the actual bounded human dispositions.
R23-REHEARSAL-001 is resolved; its original failures remain under WO-RLS-055.

## Exact delivery inputs

Wheel SHA-256: `{bundle['wheel_sha256']}`.
Source archive SHA-256: `{bundle['sdist_sha256']}`.
Hosted combination: `{combo['combination_id']}`.
Plugin review ref: `{staging['staging_ref']}` at `{staging['staging_commit']}`.
The public marketplace tip remains `{staging['public_after']}`.

The [evidence index](evidence-index-{short}.json) identifies current archives and
direct receipts. Capture also explicitly binds the reused native archives,
assessments, historical records/evidence, open-item dispositions and correction
results; it does not rely on following index links. New archives contain no
credential or private-reasoning payload. Existing protected bytes are preserved.

Human verification accepts this assessed candidate and its disclosed limits.
Merge, the exact complete-release decision, public delivery, repository adoption
and host updates remain separate. No public package, tag or marketplace was
promoted during this verification preparation.
'''
    report=D/'evidence/WO-RLS-045'/('verification-assessment-'+short+'.md')
    if report.exists():assert report.read_text(encoding='utf-8')==text
    else:put(report,text)
    paths={r['path'] for r in load(D/'evidence/WO-RLS-045'/('evidence-index-'+short+'.json'))['records']}
    paths|={report.relative_to(R).as_posix(),(D/'evidence/WO-RLS-045'/('evidence-index-'+short+'.json')).relative_to(R).as_posix()}
    native=load(D/'evidence/WO-RLS-054/evidence-index-bb089004.json')
    for row in native['archives']:
        assert sha((R/row['repository_path']).read_bytes())==row['sha256'];paths.add(row['repository_path'])
    paths.update(native['assessments'])
    comparison=load(Q/'source-package-reuse-comparison.json')
    for row in comparison['historical_verification_preserved']:
        paths.add(row['path']);paths.update(x['path'] for x in row['evidence'])
    for rel in ('evidence/WO-RLS-054/open-items.md','decisions/DEC-RLS-010.md','decisions/DEC-RLS-011.md','risks/RISK-RLS-008.md','risks/RISK-RLS-009.md','evidence/WO-RLS-055/qualification-review.md','evidence/WO-RLS-055/qualification-checks.zip','evidence/WO-RLS-055/completion-checks.zip','evidence/WO-RLS-045/candidate-6fa4d1a6-source-package-reuse-comparison.json','evidence/WO-RLS-045/candidate-6fa4d1a6-service-runtime-reuse-comparison.json','evidence/WO-RLS-046/candidate-6fa4d1a6-service.zip'):
        paths.add((D/rel).relative_to(R).as_posix())
    receipt={'candidate':C,'evidence_root':str(R),'work':[x['id'] for x in coverage['work']],'verification':[x['id'] for x in coverage['verification']],'files':[{'path':x,'sha256':sha((R/x).read_bytes()),'bytes':(R/x).stat().st_size} for x in sorted(paths)],'assessment':{'required_checks':'passed with explicit reuse and bounded human dispositions','native_findings':'R23-NATIVE-010/011 remain failed/open; DEC-RLS-010 / RISK-RLS-008 release-only carry','desktop':'not run / unverified; DEC-RLS-011 / RISK-RLS-009','historical_rehearsal':'pass; original failure retained','public_delivery':'not performed'}}
    dest=Q/'capture-receipt.json'
    if dest.exists():
        old=load(dest);assert len(old['files'])<len(receipt['files'])
        copy(dest,Q/'capture-receipt-before-extra-evidence.json')
        dest.write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    else:put(dest,json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'report':str(report),'evidence_files':len(paths)}))
else:raise ValueError(mode)
