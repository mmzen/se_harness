import json,re,subprocess,sys
import hag_efficiency_plan as p
Q=p.W/'release023-final-055';p.O=Q
C=(Q/'candidate-source.txt').read_text().strip()
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
def put(f,r):
    with f.open('x',encoding='utf-8') as out:json.dump(r,out,indent=2);out.write('\n')
mode=sys.argv[1]
if mode=='source':
    v=p.run('ci-source-snapshot',['gh','pr','view','544','--repo','mmzen/se_harness','--json','headRefOid,statusCheckRollup'],cwd=p.R)
    assert v['headRefOid']==C
    j=next(x for x in v['statusCheckRollup'] if x['name']=='Candidate source evidence');assert j['conclusion']=='SUCCESS'
    rid=re.search(r'/runs/(\d+)/',j['detailsUrl']).group(1)
    p.run('ci-source-download',['gh','run','download',rid,'--repo','mmzen/se_harness','--name','candidate-source-raw','--dir',Q/'ci-source-raw'],cwd=p.R)
    e=load(Q/'ci-source-raw/summary.json');assert e['result']=='pass' and e['exit_code']==0 and e['working_tree']=='clean'
    subject=p.run('ci-tested-commit',['gh','api','repos/mmzen/se_harness/git/commits/'+e['candidate']],cwd=p.R)
    tree=subprocess.check_output(['git','rev-parse',C+'^{tree}'],cwd=p.R,text=True).strip();assert subject['tree']['sha']==tree
    tests=re.search(r'Ran (\d+) tests in ([\d.]+)s',e['output_tail']);skip=re.search(r'OK \(skipped=(\d+)\)',e['output_tail']);assert tests
    put(Q/'ci-source-result.json',{'candidate':C,'ci_tested_commit':e['candidate'],'tree':tree,'whole_tree_equal':True,'run_id':rid,'result':'pass','tests':int(tests[1]),'skips':int(skip[1]) if skip else 0,'test_seconds':float(tests[2])})
    print('Final Linux source tree and result confirmed.')
elif mode=='rehearsal':
    run=p.run('manual-rehearsal-final',['gh','run','view','38903274786','--repo','mmzen/se_harness','--json','headSha,status,conclusion,jobs,url'],cwd=p.R)
    assert run['headSha']==C and run['conclusion']=='success' and all(j['conclusion']=='success' for j in run['jobs'])
    p.run('ci-manual-download',['gh','run','download','38903274786','--repo','mmzen/se_harness','--dir',Q/'ci-manual-replay'],cwd=p.R)
    print('Final successful rehearsal evidence retained.')
elif mode=='compare':
    d=Q/'ci-manual-replay'/('qualification-candidate-'+C)
    replay=load(d/'release-build-replay.json');bundle=load(Q/'bundle-manifest.json')
    assert replay['candidate']['commit']==C and replay['manifest']==bundle
    record=Q/'ci-manual-replay/qualification-release-record-RLS-SEH-033'
    plan=load(record/'release-plan.json');assert plan['schema']=='se-harness-release-qualification/v1' and plan['candidate_commit']=='4f640284ec496b88cd7aa4ba88ca537d9374a2f8'
    assert load(record/'qualification.json')['state']==load(record/'rebuilt-manifest-result.json')['state']=='exact'
    r=load(Q/'ci-source-result.json');r['manual_candidate_replay']={'run_id':38903274786,'result':'pass','manifest_equals_local':True,'historical_record':'RLS-SEH-033','historical_qualification':'pass','complete_delivery_recovery':'pass'}
    put(Q/'ci-source-comparison.json',r);print(json.dumps(r))
else:raise ValueError(mode)
