import hashlib,json,os,subprocess,sys
import hag_efficiency_plan as p
Q=p.W/'release023-final-055';p.O=Q;C=(Q/'candidate-source.txt').read_text().strip()
record='VREC-SEH-034'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=p.R,text=True).strip()==C
assert not list((p.R/'docs/engineering').rglob(record+'.md'))
assert not subprocess.check_output(['git','log','--all','--format=','--name-only','--','**/'+record+'.md'],cwd=p.R,text=True).strip()
receipt=Q/'capture-receipt.json';raw=receipt.read_bytes();r=json.loads(raw);assert r['candidate']==C
args=['capture-verification',p.R,'--id',record,'--owner','Codex','--domain','release-0-23-0','--candidate-commit',C]
for wid in r['work']:args+=['--work-order',wid]
for vid in r['verification']:args+=['--verification',vid]
for row in r['files']:args+=['--evidence',row['path']]
assert 'GIT_CONFIG_COUNT' not in os.environ
os.environ.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true')
args+=['--json','--test-command',sys.executable,'-B','-X','utf8',p.W/'release023_055_capture_checks.py',C,receipt,hashlib.sha256(raw).hexdigest()]
r=p.gov('final-capture',*args)
print(json.dumps({k:v for k,v in r.items() if k in ('operation','status','created','paths','mutation','findings','candidate')}))
