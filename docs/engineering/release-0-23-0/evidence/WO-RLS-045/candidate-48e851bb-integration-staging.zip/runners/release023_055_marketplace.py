"""Use the existing ordinary-child review staging procedure for final bytes."""
from pathlib import Path
import json
W=Path(__file__).parent;Q=W/'release023-final-055'
C=(Q/'candidate-source.txt').read_text().strip()
src=(W/'release023_marketplace_review.py').read_text()
src=src.replace("O=p.W/'release023-open-items';p.O=O", "O=p.W/'release023-final-055/marketplace-review';O.mkdir(exist_ok=True);p.O=O")
src=src.replace("Q=p.W/'release023-054-qualification/marketplace'", "Q=p.W/'release023-final-055/marketplace'")
src=src.replace("C='bb0890045f462343ecae66ca30b20b06cf6e8ae6'",'C='+repr(C))
src=src.replace("DEST=E/'marketplace-review-commit-bb089004.json'", "DEST=O/'marketplace-review-commit.json'")
src=src.replace("'fe431265298cb94d5205c231729f920ce31e77c3f250f525870d214a079fb519'",repr(json.loads((Q/'bundle-manifest.json').read_text())['wheel_sha256']))
src=src.replace("f=E/'marketplace-review-publication-bb089004.json'", "f=O/'marketplace-review-publication.json'")
src=src.replace("'review-publication-preaction-046.json'", "'review-publication-preaction-probe.json'")
exec(compile(src,str(W/'release023_marketplace_review.py'),'exec'),{'__name__':'__main__','__file__':str(W/'release023_marketplace_review.py')})
