import hashlib,json,subprocess,zipfile
import hag_efficiency_plan as p
Q=p.W/'release023-final-055';R=p.R;C=(Q/'candidate-source.txt').read_text().strip()
assert not list((R/'docs/engineering').rglob('VREC-SEH-034.md'))
receipt=Q/'capture-receipt.json';r=json.loads(receipt.read_text())
dest=R/'docs/engineering/release-0-23-0/evidence/WO-RLS-045/capture-receipt-recovery-48e851bb.zip'
with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
    for n in ('final-capture-clean.json','capture-candidate-check-clean.json'):z.write(Q/n,n)
    for n in ('release023_055_capture_receipt.py','release023_055_capture_checks_receipt.py','release023_055_capture_receipt_recover.py'):z.write(p.W/n,'runners/'+n)
report=R/'docs/engineering/release-0-23-0/evidence/WO-RLS-045/verification-assessment-48e851bb.md'
with report.open('a',encoding='utf-8') as f:f.write('\n## Post-candidate evidence binding\n\nThe clean runtime passed all candidate checks. The second capture then refused\nWEX304 because newly produced final evidence is absent from the older candidate\ncommit. No record was written. The committed-candidate procedure is retained:\ndirect evidence paths name only unchanged files present at C; the candidate test\nchecks every final and reused evidence digest against one exact receipt. Its\nSHA-256 is an explicit test argument retained in the generated VREC, as in the\nprevious release. The byte-identical receipt and final observations are retained\nin the later review commit. No new candidate or rebuilt payload is substituted.\nThe refusal is retained in capture-receipt-recovery-48e851bb.zip.\n')
sha=lambda b:hashlib.sha256(b).hexdigest()
(Q/'capture-receipt-before-binding-recovery.json').write_bytes(receipt.read_bytes())
for row in r['files']:
    if row['path']==report.relative_to(R).as_posix():row.update(sha256=sha(report.read_bytes()),bytes=report.stat().st_size)
r['files'].append({'path':dest.relative_to(R).as_posix(),'sha256':sha(dest.read_bytes()),'bytes':dest.stat().st_size})
paths=set(subprocess.check_output(['git','ls-tree','-r','--name-only',C],cwd=R,text=True).splitlines())
r['committed_evidence_paths']=sorted(x['path'] for x in r['files'] if x['path'] in paths)
r['post_candidate_evidence_paths']=sorted(x['path'] for x in r['files'] if x['path'] not in paths)
for row in r['files']:
    if row['path'] in paths:assert sha(subprocess.check_output(['git','show',C+':'+row['path']],cwd=R))==row['sha256'],row['path']
r['binding']='Direct paths bind unchanged evidence present at C. The explicit candidate-test receipt digest binds all files, including later final observations. Record, receipt and those exact bytes are retained in the later review commit.'
receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'committed':len(r['committed_evidence_paths']),'post_candidate':len(r['post_candidate_evidence_paths'])}))
