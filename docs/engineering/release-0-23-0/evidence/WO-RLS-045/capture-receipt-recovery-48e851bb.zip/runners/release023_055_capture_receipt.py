from pathlib import Path
source=Path(__file__).with_name('release023_055_capture.py')
text=source.read_text().replace("'--test-command',sys.executable", "'--test-command',Q/'capture-source-env/Scripts/python.exe'")
text=text.replace("for row in r['files']:args+=['--evidence',row['path']]", "for rel in r['committed_evidence_paths']:args+=['--evidence',rel]")
text=text.replace("'release023_055_capture_checks.py'","'release023_055_capture_checks_receipt.py'")
text=text.replace("p.gov('final-capture'","p.gov('final-capture-receipt'")
exec(compile(text,str(source),'exec'))
