import hashlib,json,subprocess,sys,tomllib
import hag_efficiency_plan as p
R=p.R; W=p.W; O=W/'release023-release-review-20261017';O.mkdir(exist_ok=True);p.O=O
D='docs/engineering/release-0-23-0/';C='48e851bbc94d7fb0c06e9b80666c3860cb5f8c15';BASE='b43bef8c213ecabee94447a8fb52c32294c7ab75'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
meta=lambda f:tomllib.loads(f.read_text().split('+++')[1])
mode=sys.argv[1]
if mode=='prepare':
    assert git('rev-parse','HEAD')==BASE and not git('status','--porcelain')
    v=meta(R/D/'verification-records/VREC-SEH-034.md');r=meta(R/D/'release/REL-SEH-036.md')
    assert v['status']=='verified' and v['verified_by']=='mmzen' and v['commit']==C
    assert set(v['relations']['verifies_work_order'])==set(r['relations']['gates'])
    assert not list((R/'docs/engineering').rglob('RLS-SEH-034.md'))
    assert not git('log','--all','--format=','--name-only','--','**/RLS-SEH-034.md')
    p.gov('context','check',R,'--artifact','VREC-SEH-034','--json')
    args=['prepare-release',R,'--id','RLS-SEH-034','--release-contract','REL-SEH-036','--verification-record','VREC-SEH-034','--version','0.23.0','--tag','v0.23.0','--owner','Codex','--domain','release-0-23-0']
    for wid in r['relations']['gates']:args+=['--work-order',wid]
    result=p.gov('prepare',*args,'--json');print(json.dumps({k:result[k] for k in ('operation','mutation','candidate','findings') if k in result}))
elif mode=='bind':
    record=next((R/D).rglob('RLS-SEH-034.md'));assert meta(record)['commit']==C
    manifest=R/D/'evidence/WO-RLS-045/candidate-48e851bb-bundle-manifest.json'
    p.run('bind',['C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe','-X','utf8','-B',R/'scripts/bind_release_distribution.py','--repository',R,'--release-record',record.relative_to(R).as_posix(),'--manifest',manifest.relative_to(R).as_posix()],cwd=R)
    m=meta(record);assert m['distribution']['wheel_sha256']=='ffa486d386383992349e75e2890b36ded105c797acaa483783d1380cfd520d5c'
    print(json.dumps({'record':record.relative_to(R).as_posix(),'state':m['status'],'candidate':m['commit'],'distribution':m['distribution']}))
else:raise ValueError(mode)
