import concurrent.futures,datetime,json,os,re,subprocess,sys
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'release023-release-review-20261017';O.mkdir(exist_ok=True);p.O=O
def probe(host,model=None):
    label=host+('-opus' if model else '')
    cwd=O/('auth-'+label);cwd.mkdir(exist_ok=False)
    prompt='Authentication connectivity check only. Reply exactly AUTH_READY. Do not use tools, read files, or change anything.'
    if host=='codex':
        binary=r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\2e5e00daee91c61d\codex.exe'
        args=[binary,'--no-daemon','exec','--ephemeral','--skip-git-repo-check','--sandbox','read-only','--json','-c','plugins."verity-plane@se-harness".enabled=false',prompt]
    else:
        binary=r'C:\Users\mathi\.local\bin\claude.exe'
        args=[binary,'--safe-mode','--tools','','--strict-mcp-config','--no-session-persistence','--output-format','json','-p',prompt]
    if model:args[1:1]=['--model',model]
    version=subprocess.run([binary,'--version'],capture_output=True,text=True,encoding='utf-8',timeout=30)
    at=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        result=subprocess.run(args,cwd=cwd,env=dict(os.environ,PYTHONUTF8='1',NO_COLOR='1'),stdin=subprocess.DEVNULL,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180)
        code,out,err=result.returncode,result.stdout,result.stderr
    except subprocess.TimeoutExpired:code,out,err=None,'','Timed out after 180 seconds; no live success established.'
    if re.search(r'sk-ant-(?:oat|ort|api)\S+',out+err):raise RuntimeError('Potential secret output; nothing retained.')
    passed=False
    if code==0:
        if host=='claude':
            data=json.loads(out);passed=data.get('is_error') is not True and data.get('result','').strip()=='AUTH_READY'
        else:
            rows=[json.loads(x) for x in out.splitlines() if x.startswith('{')]
            passed=any(x.get('type')=='turn.completed' for x in rows) and any(x.get('item',{}).get('text','').strip()=='AUTH_READY' for x in rows)
    record={'host':host,'observed_at':at,'argv':args,'cwd':str(cwd),'cli_version':version.stdout.strip(),'exit':code,'passed':passed,'stdout':out,'stderr':err,'claim':'Point-in-time provider authentication readiness only; no plugin/public-route qualification.'}
    with (O/(label+'-auth-readiness.json')).open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
    print(json.dumps({k:record[k] for k in ('host','cli_version','exit','passed')}),flush=True)
def provider(item):
    name,endpoint=item;p.run('provider-'+name,['gh','api','repos/mmzen/se_harness/'+endpoint])
if sys.argv[1]=='auth-opus':probe('claude','claude-opus-5-5')
elif sys.argv[1]=='auth':
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(probe,('codex','claude')))
elif sys.argv[1]=='controls':
    endpoints=[('pypi','environments/pypi'),('pypi-branches','environments/pypi/deployment-branch-policies'),('main','rules/branches/main'),('marketplace','rules/branches/plugin-marketplace'),('maintenance','rules/branches/release%2F0.23'),('pages','pages'),('latest','releases/latest'),('permissions','actions/permissions/workflow')]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(provider,endpoints))
    p.run('provider-refs',['git','ls-remote','origin','refs/heads/main','refs/heads/codex/release-0-23-0','refs/heads/release/0.23','refs/heads/plugin-marketplace','refs/heads/codex/plugin-0-2-7-staging','refs/tags/last','refs/tags/v0.23.0'],cwd=p.R)
    p.run('provider-new-release',['gh','api','repos/mmzen/se_harness/releases/tags/v0.23.0'],allowed=(0,1))
    print('Provider observations retained.')
else:raise ValueError(sys.argv[1])
