"""Retain final qualification using the existing secret/private-trace exclusions."""
from pathlib import Path
import hashlib,json,sys
W=Path(__file__).parent
src=(W/'release023_final_retain.py').read_text()
src=src.replace("Q=W/'release023-final';O=Q", "Q=W/'release023-final-055';O=Q")
src=src.replace("'ci-source-raw','ci-manual-replay'", "'ci-source-raw','ci-manual-replay'")
src=src.replace("assert load(Q/'live-boundaries.json')['exit']==0 and load(Q/'restart-restore.json')['exit']==0", "assert load(Q/'client-walkthrough.json')['exit']==0 and load(Q/'restart-restore.json')['exit']==0")
src=src.replace("('live-boundaries.json','restart-restore.json','prior-client-binding.json')", "('client-walkthrough.json','restart-restore.json','service-boundary-reuse.json')")
start=src.index(" files={f.name:f for f in (W/'release023-055-proposal')")
end=src.index(" target=D/'evidence/WO-RLS-045'/('evidence-index-'",start)
src=src[:start]+src[end:]
src=src.replace("Historical-record rehearsal failed and blocks final qualification.", "Historical-record rehearsal correction passed. Final observations and explicit historical reuse remain distinct.")
src=src.replace("'release023_final_qualify.py','release023_final_support.py','release023_final_compare.py','release023_final_ci_retain.py','release023_final_upgrades.py'", "'release023_055_final_qualify.py','release023_055_final_support.py','release023_055_final_compare.py','release023_055_final_retain.py'")
exec(compile(src,str(W/'release023_final_retain.py'),'exec'),{'__name__':'__main__','__file__':str(W/'release023_final_retain.py')})
