"""Apply the existing qualification runner to the final WO-RLS-055 candidate."""
from pathlib import Path
W=Path(__file__).parent
src=(W/'release023_054_qualify.py').read_text()
src=src.replace("p.W/'release023-054-qualification'","p.W/'release023-final-055'")
src=src.replace("p.W/'release023-054-execution/candidate-head.txt'","p.W/'release023-final-055/candidate-source.txt'")
exec(compile(src,str(W/'release023_054_qualify.py'),'exec'),{'__name__':'__main__','__file__':str(W/'release023_054_qualify.py')})
