from pathlib import Path
W=Path(__file__).parent
src=(W/'release023_final_compare.py').read_text()
src=src.replace("Q=p.W/'release023-final';OLD=p.W/'release023-054-qualification'", "Q=p.W/'release023-final-055';OLD=p.W/'release023-final'")
src=src.replace("assert paths and all(x.startswith('docs/engineering/release-0-23-0/') for x in paths)", "assert paths and all(x.startswith('docs/engineering/release-0-23-0/') or x in {'.github/scripts/publish_release.py','.github/workflows/release-qualification.yml','.github/workflows/publication-rehearsal.yml','tests/test_release_orchestration.py','docs/notes/release-publication-rehearsal.md','docs/notes/developing-se-harness.md'} for x in paths)")
src=src.replace("'all_source_runtime_tests_fixtures_and_preexisting_contracts_outside_release_domain_identical':True", "'runtime_native_fixtures_instructions_and_preexisting_native_contracts_identical':True,'changed_release_orchestration_tests_and_workflows_qualified_separately':True")
src=src.replace('final packaged walkthrough, boundaries and restart/restore are fresh observations, separately retained.', 'final packaged walkthrough and restart/restore are fresh observations, separately retained. Unchanged boundary observations are explicitly reused from the previous candidate, with fixed source-fixture and policy-input comparisons in service-boundary-reuse.json.')
exec(compile(src,str(W/'release023_final_compare.py'),'exec'),{'__name__':'__main__','__file__':str(W/'release023_final_compare.py')})
