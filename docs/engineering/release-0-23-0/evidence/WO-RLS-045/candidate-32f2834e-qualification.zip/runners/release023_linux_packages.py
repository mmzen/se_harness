"""Disposable Linux tests of the exact promotable archives; no host mutation."""
import hashlib,json,subprocess,sys,time
from pathlib import Path

Q=Path('/inputs');O=Path('/results');S=Q/'combination/candidate-source'
C=json.loads((Q/'bundle-manifest.json').read_text())['commit']
wheel=Q/'bundle/se_harness-0.23.0-py3-none-any.whl'
def run(label,argv):
    start=time.monotonic();r=subprocess.run(list(map(str,argv)),cwd=O,capture_output=True,text=True)
    record={'argv':list(map(str,argv)),'cwd':str(O),'exit':r.returncode,'elapsed_seconds':time.monotonic()-start,'stdout':r.stdout,'stderr':r.stderr}
    with (O/(label+'.json')).open('x') as f:json.dump(record,f,indent=2)
    print(json.dumps({'label':label,'exit':r.returncode,'seconds':record['elapsed_seconds']}),flush=True)
    assert r.returncode==0,label
run('package-verification',['/opt/evaluator/bin/python','-I','-m','se_harness','qualify','candidate-package',
    '--candidate-wheel',wheel,'--candidate-commit',C,'--candidate-wheel-sha256',hashlib.sha256(wheel.read_bytes()).hexdigest(),
    '--verifier-wheel-sha256','cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053',
    '--checkout-root',S,'--output',O/'package-qualification.json','--json'])
for name,archive in [('wheel',wheel),('sdist',Q/'bundle/se_harness-0.23.0.tar.gz')]:
    venv=Path('/tmp')/('release023-'+name);python=venv/'bin/python'
    run(name+'-environment',[sys.executable,'-m','venv','--system-site-packages',venv])
    install=[python,'-I','-m','pip','install','--disable-pip-version-check','--no-index','--no-deps','--no-build-isolation','--no-cache-dir']
    # General source installations are index-selected. A local archive-path
    # install creates PEP 610 sdist metadata, outside the wheel archive contract.
    install += ['--find-links',Q/'bundle','--no-binary=se-harness','se-harness==0.23.0'] if name=='sdist' else [archive]
    run(name+'-install',install)
    run(name+'-identity',[python,'-I','-m','se_harness','identity','--role','candidate-package','--expected-version','0.23.0',
        '--expected-root',venv,'--candidate-commit',C,'--checkout-root',S,'--entry-point',venv/'bin/harnessctl','--require-isolated-python','--require-entry-point'])
    run(name+'-surface',[python,'-I','/check_portable_release_surface.py','--harnessctl',venv/'bin/harnessctl'])
    target=Path('/tmp')/('release023-'+name+'-target')
    run(name+'-init',[python,'-I','-m','se_harness','init',target,'--project-name','Disposable package qualification','--json'])
    run(name+'-doctor',[python,'-I','-m','se_harness','doctor',target,'--json'])
print('Exact Linux wheel/sdist qualification passed.',flush=True)
