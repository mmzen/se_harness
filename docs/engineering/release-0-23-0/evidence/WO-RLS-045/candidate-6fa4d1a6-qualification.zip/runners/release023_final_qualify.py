"""Reuse the qualified runner on the final committed governance candidate."""
import sys
from pathlib import Path
W=Path(__file__).parent
text=(W/'release023_054_qualify.py').read_text(encoding='utf-8')
text=text.replace("p.W/'release023-054-qualification'","p.W/'release023-final'")
text=text.replace("p.W/'release023-054-execution/candidate-head.txt'","p.W/'release023-final/candidate-source.txt'")
exec(compile(text,str(W/'release023_054_qualify.py'),'exec'),{'__name__':'__main__','__file__':str(W/'release023_054_qualify.py')})
