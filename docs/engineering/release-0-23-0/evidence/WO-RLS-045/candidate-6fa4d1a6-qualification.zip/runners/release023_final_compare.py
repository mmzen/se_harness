"""Explicit byte comparisons; earlier observations keep their original identities."""
import hashlib,json,subprocess,sys,zipfile,tomllib
import hag_efficiency_plan as p
Q=p.W/'release023-final';OLD=p.W/'release023-054-qualification';p.O=Q;R=p.R
C=(Q/'candidate-source.txt').read_text().strip();PREV=(Q/'previous-source.txt').read_text().strip()
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R)
def zipmap(f):
    with zipfile.ZipFile(f) as z:return {x.filename:sha(z.read(x)) for x in z.infolist() if not x.is_dir()}
def put(name,value):
    with (Q/name).open('x',encoding='utf-8') as f:json.dump(value,f,indent=2);f.write('\n')
if sys.argv[1]=='packages':
    paths=git('diff','--name-only',PREV,C).decode().splitlines()
    assert paths and all(x.startswith('docs/engineering/release-0-23-0/') for x in paths)
    wheel='bundle/se_harness-0.23.0-py3-none-any.whl';a=zipmap(OLD/wheel);b=zipmap(Q/wheel);assert a==b
    rows=[]
    for host in ('codex','claude'):
        rel=f'marketplace/packages/{host}/verity-plane';old=OLD/rel;new=Q/rel
        of={f.relative_to(old).as_posix():sha(f.read_bytes()) for f in old.rglob('*') if f.is_file()}
        nf={f.relative_to(new).as_posix():sha(f.read_bytes()) for f in new.rglob('*') if f.is_file()};assert set(of)==set(nf)
        changed=[n for n in of if of[n]!=nf[n]]
        assert set(changed)<={'assembly-inventory.json','packages/se_harness-0.23.0-py3-none-any.whl'},changed
        oi=json.loads((old/'assembly-inventory.json').read_text());ni=json.loads((new/'assembly-inventory.json').read_text())
        rows.append({'host':host,'files':len(of),'changed_files':[{'path':n,'previous_sha256':of[n],'current_sha256':nf[n]} for n in changed],
          'all_other_files_identical':True,'previous_inventory':oi,'current_inventory':ni})
    records=[]
    for aid in ('VREC-HAG-001','VREC-HAG-002','VREC-HAG-003','VREC-HAG-004','VREC-HAG-005','VREC-HAG-006','VREC-HAG-007','VREC-HUP-028','VREC-IPK-002'):
        f,=list((R/'docs/engineering').rglob(aid+'.md'));rel=f.relative_to(R).as_posix();raw=git('show',C+':'+rel);assert raw==git('show',PREV+':'+rel)
        meta=tomllib.loads(raw.decode().split('+++')[1]);evidence=meta['evidence_paths']+[meta['evaluator_evidence_path']]
        ev=[]
        for name in evidence:
            x=git('show',C+':'+name);assert x==git('show',PREV+':'+name),name;ev.append({'path':name,'sha256':sha(x)})
        records.append({'id':aid,'path':rel,'sha256':sha(raw),'candidate':meta['commit'],'status':meta['status'],'evidence':ev})
    put('source-package-reuse-comparison.json',{'candidate':C,'previous_qualified_source':PREV,'source_changed_paths':paths,
      'all_source_runtime_tests_fixtures_and_preexisting_contracts_outside_release_domain_identical':True,
      'wheel_members_identical':True,'wheel_member_count':len(a),'wheel_members':a,'previous_archive_sha256':sha((OLD/wheel).read_bytes()),'final_archive_sha256':sha((Q/wheel).read_bytes()),
      'host_packages':rows,'historical_verification_preserved':records,
      'assessment':'Reused native content, lifecycle, read, delivery-boundary and failure observations remain at the previous source/package identities. Runtime/resource bytes, host hooks, prompts/test fixture source and accepted native criteria are unchanged. Archive and inventory provenance differ; fresh final archive installation, staging and source checks cover these new identities. Final service walkthrough/recovery is separately required. No historical failure or missing desktop result becomes a pass.'})
    print(json.dumps({'source_changes':len(paths),'wheel_members_identical':len(a),'hosts':[{'host':r['host'],'files':r['files'],'changed':[x['path'] for x in r['changed_files']]} for r in rows],'historical_records_preserved':len(records)}))
elif sys.argv[1]=='service':
    docker=p.W.parent.parent.parent/'unused'
    docker='C:/Users/mathi/AppData/Local/Programs/DockerDesktop/resources/bin/docker.exe'
    code="import json,hashlib,zipfile;from pathlib import Path;w,=Path('/opt/service-wheel').glob('*.whl');z=zipfile.ZipFile(w);print(json.dumps({n:hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist()}))"
    a=p.run('previous-server-members',[docker,'run','--rm','--network','none','--entrypoint','python','hag-release023:'+PREV[:12],'-c',code])
    b=p.run('final-server-members',[docker,'run','--rm','--network','none','--entrypoint','python','hag-release023:'+C[:12],'-c',code]);assert a==b
    old=json.loads((OLD/'combination/combination.json').read_text());new=json.loads((Q/'combination/combination.json').read_text())
    for k in ('runtime','database','evaluator','protocols','schema_revision'):assert old['payload'][k]==new['payload'][k],k
    for k in ('dependency_lock_sha256','system_packages_sha256','version'):assert old['payload']['server'][k]==new['payload']['server'][k]
    put('service-runtime-reuse-comparison.json',{'previous_combination':old,'current_combination':new,'expanded_server_wheel_members':a,'runtime_and_dependency_identities_equal':True,
      'assessment':'Source/image/archive/configuration identities differ and remain explicit. Expanded server runtime bytes, fixed dependencies, database/runtime image and released evaluator are identical. Reuse only unaffected historical scenarios; final packaged walkthrough, boundaries and restart/restore are fresh observations, separately retained.'})
    print(json.dumps({'server_members_identical':len(a),'unchanged_fixed_runtime_dependencies':True}))
else:raise ValueError(sys.argv[1])
