"""Read CI evidence for the exact preparation candidate; no workflow dispatch."""
import json,re,subprocess
import hag_efficiency_plan as p
Q=p.W/'release023-final';p.O=Q
C=(Q/'candidate-source.txt').read_text().strip()
v=json.loads((Q/'ci-snapshot-02.json').read_text(encoding='utf-8-sig'))
assert v['headRefOid']==C
job=next(x for x in v['statusCheckRollup'] if x['name']=='Candidate source evidence')
assert job['conclusion']=='SUCCESS'
run_id=re.search(r'/runs/(\d+)/',job['detailsUrl']).group(1)
dest=Q/'ci-source-raw';assert not dest.exists()
p.run('ci-source-download',['gh','run','download',run_id,'--repo','mmzen/se_harness','--name','candidate-source-raw','--dir',dest],cwd=p.R)
e=json.loads((dest/'summary.json').read_text());assert e['result']=='pass' and e['exit_code']==0 and e['working_tree']=='clean'
tested=e['candidate'];commit=p.run('ci-tested-commit',['gh','api','repos/mmzen/se_harness/git/commits/'+tested],cwd=p.R)
tree=subprocess.check_output(['git','rev-parse',C+'^{tree}'],cwd=p.R,text=True).strip()
assert commit['tree']['sha']==tree
tests=re.search(r'Ran (\d+) tests in ([\d.]+)s',e['output_tail']);skips=re.search(r'OK \(skipped=(\d+)\)',e['output_tail']);assert tests
result={'candidate':C,'ci_tested_commit':tested,'tree':tree,'whole_tree_equal':True,'run_id':int(run_id),'result':'pass','tests':int(tests[1]),'skips':int(skips[1]) if skips else 0,'test_seconds':float(tests[2])}
dest=Q/'ci-manual-replay';assert not dest.exists()
p.run('ci-manual-replay-download',['gh','run','download','38895333553','--repo','mmzen/se_harness','--name','qualification-candidate-'+C,'--dir',dest],cwd=p.R)
files=list(dest.rglob('release-build-replay.json'));assert len(files)==1
replay=json.loads(files[0].read_text());local=json.loads((Q/'bundle-manifest.json').read_text())
assert replay['manifest']==local,(replay.keys(),local.keys())
result['manual_candidate_replay']={'run_id':38895333553,'manifest_equals_local':True,'replay_path':str(files[0].relative_to(Q)),'run_overall':'failure','historical_record_rehearsal':'failed; separate unresolved blocker'}
with (Q/'ci-source-comparison.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
