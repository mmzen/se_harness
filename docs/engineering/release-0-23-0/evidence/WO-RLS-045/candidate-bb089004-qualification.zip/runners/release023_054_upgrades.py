"""Run version-sensitive upgrade rehearsals at the immutable candidate commit."""
import json,os,subprocess,sys,tempfile
from pathlib import Path
import hag_efficiency_plan as p
p.O=p.W/'release023-054-qualification'
C=(p.W/'release023-054-execution/candidate-head.txt').read_text().strip()
root=Path(tempfile.mkdtemp(prefix='r2354up-'));checkout=root/'c';workspace=root/'w';workspace.mkdir()
assert 'GIT_CONFIG_COUNT' not in os.environ
os.environ.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true')
p.run('upgrade-candidate-clone',['git','clone','--shared','--no-checkout',p.R,checkout],cwd=p.W)
p.run('upgrade-candidate-checkout',['git','-C',checkout,'checkout','--detach',C],cwd=p.W)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout,text=True).strip()==C
with (p.O/'upgrade-environment-recovery.json').open('x',encoding='utf-8') as f:
 json.dump({'candidate':C,'checkout':str(checkout),'workspace':str(workspace),'reason':'Isolated exact candidate checkout; review head differs only in retained evidence.','session_only_git_config':{'core.longpaths':True},'global_settings_changed':False},f,indent=2)
for number in (2,3):
 label='windows-upgrade-'+str(number)
 p.run(label,[sys.executable,'-X','utf8','-B','-m','repository_tools.upgrade_rehearsal','--repository',checkout,
    '--predecessor-python',p.P,'--successor-python',p.O/'client/Scripts/python.exe','--output',p.O/label,'--workspace',workspace,'--timings'],cwd=checkout)
 result=json.loads((p.O/label/'upgrade-rehearsal-result.json').read_text())
 assert result['overall_result']=='pass'
 print(json.dumps({'case':label,'overall':'pass','semantic_sha256':result['semantic_sha256']}),flush=True)
results=[json.loads((p.O/('windows-upgrade-'+str(n))/'upgrade-rehearsal-result.json').read_text()) for n in (2,3)]
assert results[0]['semantic_sha256']==results[1]['semantic_sha256']
print('Both exact-candidate upgrades passed with the same semantic digest.')
