"""Retain CI's exact tested head and its evidence-only difference from candidate C."""
import json,re,subprocess
import hag_efficiency_plan as p
Q=p.W/'release023-054-qualification';p.O=Q
C=(p.W/'release023-054-execution/candidate-head.txt').read_text().strip()
H=(p.W/'release023-054-execution/publication-head.txt').read_text().strip()
v=p.run('source-ci-snapshot',['gh','pr','view','544','--repo','mmzen/se_harness','--json','headRefOid,statusCheckRollup'],cwd=p.R)
assert v['headRefOid']==H
item=next(x for x in v['statusCheckRollup'] if x['name']=='Candidate source evidence')
assert item['status']=='COMPLETED' and item['conclusion']=='SUCCESS'
run_id=re.search(r'/runs/(\d+)/',item['detailsUrl']).group(1);dest=Q/'ci-source-raw';assert not dest.exists()
p.run('ci-source-download',['gh','run','download',run_id,'--repo','mmzen/se_harness','--name','candidate-source-raw','--dir',dest],cwd=p.R)
e=json.loads((dest/'summary.json').read_text());assert e['result']=='pass' and e['exit_code']==0 and e['working_tree']=='clean'
tested=e['candidate'];commit=p.run('ci-tested-commit',['gh','api','repos/mmzen/se_harness/git/commits/'+tested],cwd=p.R)
git=lambda *a:subprocess.check_output(['git',*a],cwd=p.R,text=True).strip()
assert commit['tree']['sha']==git('rev-parse',H+'^{tree}')
binding=json.loads((p.W/'release023-054-execution/publication-candidate-comparison.json').read_text())
paths=git('diff','--name-only',C,H).splitlines();assert set(paths)==set(binding['changed_paths'])
assert all(x.startswith('docs/engineering/release-0-23-0/evidence/') for x in paths)
match=re.search(r'Ran (\d+) tests in ([\d.]+)s',e['output_tail']);assert match
skip=re.search(r'OK \(skipped=(\d+)\)',e['output_tail'])
r={'candidate':C,'review_head':H,'tested_commit':tested,'tested_tree_matches_review_head':True,'candidate_complete_tree_equal':False,'candidate_to_review_changed_paths':paths,'runtime_test_configuration_and_formal_definitions_equal':True,'run_id':int(run_id),'result':'pass','tests':int(match[1]),'skips':int(skip[1]) if skip else 0,'test_seconds':float(match[2]),'limit':'CI tested its PR merge commit, whose whole tree matches review H. H differs from C only in enumerated evidence headers and status/retention files. Do not claim whole-tree identity with C. Exact C archives remain the local pinned build outputs; CI packages are not promoted.'}
with (Q/'ci-source-comparison.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps(r))
