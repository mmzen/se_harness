import base64, datetime, hashlib, importlib.util, json, subprocess, sys, tomllib, types, zipfile
import hag_efficiency_plan as p
R=p.R; W=p.W; O=W/'release023-release-review-20261017'; p.O=O
D='docs/engineering/release-0-23-0/'; E=D+'evidence/WO-RLS-045/'; P=D+'evidence/WO-RLS-047/'
C='48e851bbc94d7fb0c06e9b80666c3860cb5f8c15'; BASE='b43bef8c213ecabee94447a8fb52c32294c7ab75'
DOC=(O/'documentation-head.txt').read_text().strip()
BRANCH='codex/release-0-23-0'; IDS=['WO-RLS-045','WO-RLS-046','WO-RLS-047','WO-RLS-055']
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
blob=lambda ref,path:subprocess.check_output(['git','show',ref+':'+path],cwd=R)
def put(f,data):
    with f.open('x',encoding='utf-8',newline='\n') as out:out.write(data if isinstance(data,str) else json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def replace_draft(f,obj):
    assert not git('ls-files','--',f.relative_to(R).as_posix())
    f.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
def check_plan():
    plan=load(R/E/'complete-release-plan.json')
    spec=importlib.util.spec_from_file_location('release023_final_publisher',R/'.github/scripts/publish_release.py')
    pub=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pub;spec.loader.exec_module(pub)
    surfaces=pub.delivery.validate_plan(plan)
    rls=tomllib.loads((R/D/'releases/RLS-SEH-034.md').read_text().split('+++')[1]);d=rls['distribution']
    assert rls['status']=='ready' and rls['commit']==C
    marketplace=pub.verify_marketplace(R,types.SimpleNamespace(candidate_commit=C,wheel_sha256=d['wheel_sha256'],version=rls['version'],wheel=d['wheel']),plan)
    readiness=load(R/E/'complete-release-readiness.json')
    assert readiness['documentation']['commit']==DOC
    for name,digest in readiness['documentation']['source_files'].items():assert sha(blob(DOC,name))==digest==sha((R/name).read_bytes()),name
    for name,digest in plan['complete_release']['documentation'].items():assert readiness['documentation']['source_files'][name]==digest
    assert sha((R/E/'complete-release-readiness.json').read_bytes())==plan['complete_release']['readiness']['sha256']
    for row in readiness['evidence']:assert sha((R/row['path']).read_bytes())==row['sha256'],row['path']
    captured=load(R/E/'capture-receipt-48e851bb.json')
    for row in captured['files']:assert sha((R/row['path']).read_bytes())==row['sha256'],row['path']
    assert blob(DOC,'docs/engineering/release-0-23-0/releases/RLS-SEH-034.md')==blob('c7be3ce0e3f28dc19b13691e00bdf2ab93474dde','docs/engineering/release-0-23-0/releases/RLS-SEH-034.md')
    report={'plan_sha256':sha((R/E/'complete-release-plan.json').read_bytes()),'candidate':C,'documentation_commit':DOC,'surfaces':list(surfaces),'marketplace':marketplace,'documentation':'All 10 source files match their exact Git blobs; 7 supported paths also match the canonical plan map.','candidate_evidence':f"All {len(captured['files'])} captured files unchanged.",'readiness':'All referenced evidence hashes match. Public observations remain pending.','authority':'Prepared for human decision; no release or external authorization supplied.'}
    put(R/E/'complete-release-plan-check.json',report)
    return report
def body(h):return f'''Prepare complete delivery of evaluator/client 0.23.0 and Verity Plane plugin 0.2.7. The verified candidate and qualified payloads are unchanged.

Harness-Work-Orders: {', '.join(IDS)}

**RLS-SEH-034 is ready. Complete-release approval is pending; keep draft.**

[Complete-release review](https://github.com/mmzen/se_harness/blob/{h}/{E}complete-release-review.md) · [Exact plan](https://github.com/mmzen/se_harness/blob/{h}/{E}complete-release-plan.json) · [Release record](https://github.com/mmzen/se_harness/blob/{h}/{D}releases/RLS-SEH-034.md)

mmzen verified VREC-SEH-034 at `{C}`. Its 20 work orders, 11 contracts, archives and staged marketplace remain fixed. Two ready-record replay builds reproduce the bound archives. Current source guidance now cites verification, the separate release authority and public evidence; qualified package snapshots stay unchanged.

All 47 focused onboarding/documentation checks pass. The earlier source CI failure (README 679 words versus a 650-word limit) is retained; the README now has 643 words. Fresh CI must pass before the final approval request. Local validation, release-decision and full-scope review checks pass. The five-surface plan and all ten documentation Git blobs have been checked.

R23-NATIVE-010/011 remain open under DEC-RLS-010 / RISK-RLS-008. Codex Windows desktop remains unverified under DEC-RLS-011 / RISK-RLS-009. Git remains authoritative; the service stays private and source-built, with evaluator 0.22.1.

WO-RLS-047 remains in progress. Public observations and its final VER-RLS-041 assurance follow authorized publication. The proposed single approval covers protected release/receipt integrations, version tag, GitHub/PyPI, maintenance line, marketplace, documentation, Pages and latest/last. Public delivery, adoption and host updates have not occurred. This review targets main from `{BRANCH}` with complete comparison base `{BASE}`.
'''
mode=sys.argv[1]
if mode=='prepare':
    assert git('rev-parse','HEAD')==DOC
    assert load(O/'readme-bounded-tests-fixed.json')['exit']==0
    for name in ('complete-release-plan.json','complete-release-readiness.json'):
        put(O/('pre-readme-final-'+name),(R/E/name).read_text())
    archive=R/E/'complete-release-preparation.zip'
    names=['pypi-version-availability.json','ready-replay-final.json','ready-replay-download.json','plan-schema-correction.json','complete-plan-check.json','unreviewed-complete-release-plan.json','unreviewed-complete-release-readiness.json','pre-readme-final-complete-release-plan.json','pre-readme-final-complete-release-readiness.json']
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
        for name in names:z.write(O/name,name)
        for name in ('release023_complete_plan.py','release023_plan_schema_recovery.py','release023_final_review.py'):z.write(W/name,'runners/'+name)
    readiness=load(R/E/'complete-release-readiness.json')
    readiness['documentation']['commit']=DOC
    hashes={name:sha(blob(DOC,name)) for name in readiness['documentation']['source_files']}
    readiness['documentation']['source_files']=hashes
    readiness['documentation']['checks']='47 existing onboarding/documentation/identity/link tests pass. README: 643 words within the unchanged 650-word limit. Candidate evidence and qualified package bytes unchanged.'
    readiness['documentation']['ci']='Earlier source CI failed only the README word limit. That failure and the correction are retained. CI on the final review head must pass before the human complete-release request.'
    readiness['observed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    for name in (E+'complete-release-preparation.zip',P+'source-guide-bound-correction.md',P+'source-guide-bound-correction.zip'):
        readiness['evidence'].append({'path':name,'sha256':sha((R/name).read_bytes())})
    replace_draft(R/E/'complete-release-readiness.json',readiness)
    plan=load(R/E/'complete-release-plan.json')
    plan['complete_release']['documentation']={n:d for n,d in hashes.items() if n=='README.md' or n.startswith('docs/')}
    plan['complete_release']['readiness']['sha256']=sha((R/E/'complete-release-readiness.json').read_bytes())
    next(x for x in plan['surfaces'] if x['id']=='documentation')['expected']['commit']=DOC
    replace_draft(R/E/'complete-release-plan.json',plan)
    checked=check_plan()
    lines=[]
    for name,digest in hashes.items():lines.append(f'| `{name}` | `{digest}` |')
    review=f'''# Complete release: evaluator 0.23.0 and plugin 0.2.7

## Decision requested

Approve the complete release under **RLS-SEH-034 / REL-SEH-036**, including the
listed protected integrations and public delivery actions. This review is a
proposal; the release record remains `ready` until mmzen supplies that decision.

Exact [delivery plan](complete-release-plan.json) SHA-256:
`{checked['plan_sha256']}`.
The immutable review commit presented with the request binds this plan, the
ready record and all preparation material. Only the recorded RLS decision may
be added before its protected integration. Later receipt integrations are limited
to the exact paths listed in the plan. No unrelated change or check bypass is covered.

## Inputs already verified

- Candidate: `{C}`; VREC-SEH-034 verified by mmzen.
- Release coverage: 20 implemented work orders and 11 verification contracts.
- Wheel SHA-256: `ffa486d386383992349e75e2890b36ded105c797acaa483783d1380cfd520d5c`.
- Source archive SHA-256: `777c9c1f518f6db1d3beb013f9bbb908544c482598ee399767fd789414f2ccfa`.
- Two ready-record builds reproduced those archives: [run 39007950424](https://github.com/mmzen/se_harness/actions/runs/39007950424).
- Read the [verified assessment](verification-assessment-48e851bb.md),
  [replay receipt](ready-record-replay-034-receipt.json), and
  [plan checks](complete-release-plan-check.json).

The replay used preparation commit `c7be3ce0e3f28dc19b13691e00bdf2ab93474dde`.
The subsequent README correction changes no RLS bytes, binary candidate, recipe,
archive, qualified plugin file or candidate-bound evidence. All captured hashes
remain equal. All 47 focused documentation/onboarding checks pass. The earlier
README CI failure and intermediate local errors are preserved in the
[correction evidence](../WO-RLS-047/source-guide-bound-correction.md).
Final review-head CI must pass before the approval request.

## Actions covered by this one decision

| Action | Exact destination and condition |
| --- | --- |
| Release decision and integration | Record mmzen's decision on RLS-SEH-034. Merge PR #545 into `mmzen/se_harness:main` through its required checks, using a merge commit and exact checked head. The diff from the immutable review head may add only the RLS decision/binding. |
| Evaluator | Publish the bound wheel and source archive as PyPI `se-harness==0.23.0` and GitHub `v0.23.0`. Tag the exact candidate and establish `release/0.23` at that candidate. Re-download and test the public wheel. |
| Marketplace | Promote commit `d04776866046b60b14ffef14ced1453c4aafa7d9` from parent `85ae003769f53908addbdcf46c820a8af530ac24` to `plugin-marketplace`. Exact tree: `0e0ff666693ad7f00564435e2f35ce8e31a2fb4e`; identity SHA-256: `f3d3f808d06d09f15628fbbe7958a8bf6e72807f0536a8c9905d947d78376a5e`. Verify both public CLI fresh and 0.2.6-to-0.2.7 update routes in disposable profiles. |
| Documentation | Integrate the exact source guidance at `{DOC}` and compare its ten hashes below. Preserve the qualified package snapshots; retain later availability observations as JSON receipts. |
| Demonstration | Run the existing Pages workflow with the first main commit containing the exact released binding. Check `https://mmzen.github.io/se_harness/` and its existing domain `https://www.verityplane.ai/`; no provider-setting change. |
| Markers | After required non-marker observations pass, set GitHub latest to `v0.23.0` and move `last` from `4f640284ec496b88cd7aa4ba88ca537d9374a2f8` to `{C}` using the exact lease. |
| Receipts | Commit and integrate only the plan's named receipt paths through protected PRs. Check the five delivery surfaces against the frozen plan; keep observed effects separate from authority. |

The plugin bundles evaluator/client 0.23.0. The private hosted service continues
to use evaluator 0.22.1. Its tested combination is
`sha256:70890d365551c04d38eb74afb8f815cf30c5eb61d09e9ac7d1e322b9b657de0a`.
All 89 marketplace files match the qualified identity. This plan publishes no
hosted service or container image.

## Readiness and limitations

Provider protections remain enabled: main requires PR/checks and merge commits;
PyPI permits only main with the approved reviewer removal retained; marketplace
and maintenance refs deny deletion and non-fast-forward updates. The version
and maintenance refs were absent; PyPI 0.23.0 returned 404. These observations are
rechecked before each action. The human's prior PyPI publisher-settings
confirmation is historical evidence, not a new authenticated settings read.

Both live CLI probes passed. Claude requires explicit `claude-opus-5-5` because
the configured default returned model-not-found (404). No global setting was
changed. Authentication is point-in-time evidence; failed later checks stop
the affected delivery observation.

- R23-NATIVE-010/011 remain open under DEC-RLS-010 / RISK-RLS-008.
- Codex Windows desktop remains not run/unverified under DEC-RLS-011 / RISK-RLS-009.
- Git remains authoritative. The service stays a private source build.
  RISK-HAG-001/002 and the existing application controls remain applicable.
- WO-RLS-047 remains in progress. Public observations and final VER-RLS-041
  assurance follow publication and are excluded from release membership to avoid
  circularity. This request does not fabricate those future results or decisions.
- Repository adoption, user-host updates, authentication/DB ACL work, production
  deployment, provider-setting changes and performance work are excluded.

## Recovery

Inspect remote effects before any retry. Resume only missing actions whose
identities and conditions still match this plan. Never replace an immutable
published version or archive. A conflicting ref, changed payload, failed required
check or missing control stops the affected action. Keep partial delivery visible.
Do not move latest/last until the required preceding observations pass. A changed
plan needs a new decision; an unchanged plan does not need repeated authorization.

## Frozen documentation

The canonical plan schema permits seven README/docs paths. Its bound readiness
companion also fixes the three package-source README paths, so all ten are checked.
The initial unsupported draft was corrected before any human review; its failure
and prior drafts are retained in [preparation evidence](complete-release-preparation.zip).

| Source path at `{DOC}` | Git-blob SHA-256 |
| --- | --- |
{chr(10).join(lines)}
'''
    put(R/E/'complete-release-review.md',review)
    index=R/D/'README.md';text=index.read_text()
    text=text.replace('plan and ready-record replay are being prepared for the separate release decision.','[plan and review](evidence/WO-RLS-045/complete-release-review.md) are ready for the separate release decision.\nTwo ready-record replay builds reproduce the exact archives. The source README\ncorrection passes all 47 focused checks; final review CI must pass before approval.')
    index.write_text(text,encoding='utf-8',newline='\n')
    print(json.dumps({'plan_sha256':checked['plan_sha256'],'documentation':DOC,'prepared':True}))
elif mode=='validate':
    r=p.gov('complete-final-validation','validate',R,'--json');assert r['valid']
    r=p.gov('complete-final-release-gates','check',R,'--artifact','RLS-SEH-034','--checkpoint','transition','--target','released','--json');assert r['compliance']['status']=='pass'
    print('Final validation and ready-release decision gates pass.')
elif mode=='commit':
    assert git('rev-parse','HEAD')==DOC and not git('diff','--cached','--name-only')
    paths=sorted(set(git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()))
    assert paths and all(x.startswith(D) for x in paths)
    p.run('complete-final-add',['git','add','--',*paths],cwd=R)
    p.run('complete-final-diff-check',['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=R)
    p.run('complete-final-commit',['git','commit','-m','Freeze complete 0.23.0 delivery plan for human release review','-m','Harness-Work-Orders: '+', '.join(IDS)],cwd=R)
    h=git('rev-parse','HEAD');put(O/'complete-review-head.txt',h+'\n');assert not git('status','--porcelain');print(h)
elif mode=='checks':
    h=(O/'complete-review-head.txt').read_text().strip();assert git('rev-parse','HEAD')==h
    put(O/'complete-body.md',body(h));put(O/'complete-event.json',{'pull_request':{'body':body(h)}})
    r=p.gov('complete-check-pr','check-pr',R,'--event',O/'complete-event.json','--from-git',BASE,'--json');assert r['status']=='pass'
    args=['check',R,'--artifact','WO-RLS-047','--checkpoint','pre-action']
    for name in r['changed_paths']:args+=['--changed-path',name]
    r=p.gov('complete-preaction',*args,'--changes-complete','--json');assert r['compliance']['status']=='pass'
    print('Complete comparison and pre-action checks pass.')
elif mode=='publish':
    h=(O/'complete-review-head.txt').read_text().strip();assert git('rev-parse','HEAD')==h and not git('status','--porcelain')
    assert load(O/'complete-check-pr.json')['exit']==load(O/'complete-preaction.json')['exit']==0
    pr=p.run('complete-pr-before',['gh','pr','view','545','--repo','mmzen/se_harness','--json','headRefOid,headRefName,baseRefName,isDraft,state'],cwd=R)
    assert pr['state']=='OPEN' and pr['headRefName']==BRANCH and pr['baseRefName']=='main' and pr['isDraft'] and pr['headRefOid']=='c7be3ce0e3f28dc19b13691e00bdf2ab93474dde'
    rules=p.run('complete-provider-controls',['gh','api','repos/mmzen/se_harness/rulesets/20693381'],cwd=R)
    assert rules['enforcement']=='active' and {'pull_request','required_status_checks','non_fast_forward','deletion'}<={x['type'] for x in rules['rules']}
    p.run('complete-push',['git','push','origin',h+':refs/heads/'+BRANCH],cwd=R)
    p.run('complete-pr-edit',['gh','pr','edit','545','--repo','mmzen/se_harness','--body-file',O/'complete-body.md'],cwd=R)
    pr=p.run('complete-pr-readback',['gh','pr','view','545','--repo','mmzen/se_harness','--json','url,headRefOid,baseRefName,isDraft,body'],cwd=R)
    assert pr['headRefOid']==h and pr['baseRefName']=='main' and pr['isDraft'] and pr['body']==body(h)
    for name in ('complete-release-review.md','complete-release-plan.json'):
        result=p.run('complete-readable-'+name,['gh','api',f'repos/mmzen/se_harness/contents/{E+name}?ref={h}'],cwd=R)
        assert base64.b64decode(result['content'])==blob(h,E+name)
    print(json.dumps({'url':pr['url'],'review_head':h,'plan_sha256':sha((R/E/'complete-release-plan.json').read_bytes())}))
else:raise ValueError(mode)
