import datetime,hashlib,importlib.util,json,subprocess,sys,tomllib,types,urllib.request,urllib.error,zipfile
import hag_efficiency_plan as p
R=p.R;W=p.W;O=W/'release023-release-review-20261017';p.O=O
D='docs/engineering/release-0-23-0/';E=D+'evidence/WO-RLS-045/';P=D+'evidence/WO-RLS-047/'
C='48e851bbc94d7fb0c06e9b80666c3860cb5f8c15';DOC='c7be3ce0e3f28dc19b13691e00bdf2ab93474dde';BASE='b43bef8c213ecabee94447a8fb52c32294c7ab75'
STAGE='d04776866046b60b14ffef14ced1453c4aafa7d9';PARENT='85ae003769f53908addbdcf46c820a8af530ac24'
OLD='4f640284ec496b88cd7aa4ba88ca537d9374a2f8'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
observed=lambda n:json.loads(load(O/(n+'.json'))['stdout'])
meta=lambda f:tomllib.loads(f.read_text().split('+++')[1])
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
blob=lambda ref,path:subprocess.check_output(['git','show',ref+':'+path],cwd=R)
def put(path,obj):
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
mode=sys.argv[1]
if mode=='pypi':
    url='https://pypi.org/pypi/se-harness/0.23.0/json'
    try:
        with urllib.request.urlopen(url,timeout=30) as r:status=r.status;payload=r.read()
    except urllib.error.HTTPError as ex:status=ex.code;payload=ex.read()
    put(O/'pypi-version-availability.json',{'url':url,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'http_status':status,'response_sha256':sha(payload),'version_unused':status==404})
    assert status==404,'Version already exists or availability is unknown';print('PyPI 0.23.0 is absent (HTTP 404).')
elif mode=='replay':
    run=sys.argv[2];details=p.run('ready-replay-final',['gh','run','view',run,'--repo','mmzen/se_harness','--json','status,conclusion,headSha,url,jobs'],cwd=R)
    assert details['status']=='completed' and details['conclusion']=='success' and details['headSha']==DOC
    target=O/'ready-replay-download';target.mkdir(exist_ok=False)
    p.run('ready-replay-download',['gh','run','download',run,'--repo','mmzen/se_harness','--dir',target],cwd=R)
    files=list(target.rglob('release-build-replay.json'));assert len(files)==1
    raw=files[0].read_bytes();replay=json.loads(raw);record=meta(R/D/'releases/RLS-SEH-034.md')
    assert replay['candidate']['commit']==C and len(replay['builds'])==2
    for b in replay['builds']:
        for key in ('wheel_sha256','sdist_sha256'):assert b[key]==record['distribution'][key]
    assert replay['manifest']==load(R/E/'candidate-48e851bb-bundle-manifest.json')
    path=R/E/'ready-record-replay-034.json'
    with path.open('xb') as f:f.write(raw)
    put(R/E/'ready-record-replay-034-receipt.json',{'schema':'release-ready-record-replay-receipt/v1','record':'RLS-SEH-034','candidate':C,'review_commit':DOC,'run':details['url'],'status':'success','replay_path':path.relative_to(R).as_posix(),'replay_sha256':sha(raw),'two_builds_match_bound_archives':True,'authority':'Read-only corroboration; no release or publication decision.'})
    print('Two ready-record builds reproduce the exact verified archives.')
elif mode=='prepare':
    assert git('rev-parse','HEAD')==DOC
    rls=meta(R/D/'releases/RLS-SEH-034.md');v=meta(R/D/'verification-records/VREC-SEH-034.md')
    assert rls['status']=='ready' and rls['commit']==C and v['status']=='verified' and v['verified_by']=='mmzen' and v['commit']==C
    assert load(R/E/'ready-record-replay-034-receipt.json')['status']=='success'
    assert load(O/'pypi-version-availability.json')['version_unused']
    for host in ('codex','claude-opus'):assert load(O/(host+'-auth-readiness.json'))['passed']
    assert observed('provider-latest')['tag_name']=='v0.22.1'
    refs=dict(line.split()[::-1] for line in load(O/'provider-refs.json')['stdout'].splitlines())
    assert refs['refs/tags/last']==OLD and refs['refs/heads/plugin-marketplace']==PARENT and refs['refs/heads/codex/plugin-0-2-7-staging']==STAGE
    assert 'refs/tags/v0.23.0' not in refs and 'refs/heads/release/0.23' not in refs
    assert not any(x.get('reviewers') for x in observed('provider-pypi')['protection_rules'] if x['type']=='required_reviewers')
    assert observed('provider-pypi-branches')['branch_policies']==[{'id':57065399,'node_id':'MDE2OkdhdGVCcmFuY2hQb2xpY3k1NzA2NTM5OQ==','name':'main','type':'branch'}]
    main=observed('provider-main');assert {'pull_request','required_status_checks','non_fast_forward','deletion'}<={x['type'] for x in main}
    assert next(x for x in main if x['type']=='pull_request')['parameters']['allowed_merge_methods']==['merge']
    for name in ('marketplace','maintenance'):assert {'non_fast_forward','deletion'}<={x['type'] for x in observed('provider-'+name)}
    ident_raw=blob(STAGE,'PACKAGE-IDENTITY.json');identity=json.loads(ident_raw)
    assert sha(ident_raw)=='f3d3f808d06d09f15628fbbe7958a8bf6e72807f0536a8c9905d947d78376a5e'
    doc_paths=['README.md','release/plugin-marketplace/README.md','plugins/verity-plane/codex/README.md','plugins/verity-plane/claude-code/README.md','docs/notes/plugin-installation-guide.md','docs/notes/plugin-marketplace-publication.md','docs/notes/developing-se-harness.md','docs/notes/harness-installation-and-upgrades.md','docs/notes/hosted-artifact-graph.md',P+'README.md']
    doc_hashes={n:sha(blob(DOC,n)) for n in doc_paths}
    assert all(sha((R/n).read_bytes())==v for n,v in doc_hashes.items())
    evidence=[D+'verification-records/VREC-SEH-034.md',E+'verification-assessment-48e851bb.md',E+'capture-receipt-48e851bb.json',E+'ready-release-preparation-20261017.zip',E+'ready-release-review.md',E+'ready-record-replay-034.json',E+'ready-record-replay-034-receipt.json',D+'evidence/WO-RLS-046/marketplace-review-publication-48e851bb.json']
    readiness={'schema':'se-harness-complete-release-readiness/v1','candidate_commit':C,'verification_records':['VREC-SEH-034'],'qualification':'passed','controls_ready':True,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'evidence':[{'path':n,'sha256':sha((R/n).read_bytes())} for n in evidence],
      'documentation':{'commit':DOC,'work_order':'WO-RLS-047','source_files':doc_hashes,'checks':'31 existing documentation/identity/link tests pass; qualified package snapshots and candidate evidence unchanged','authority':'Already-approved local source-status preparation. Public observations and final VER-RLS-041 assurance remain pending; no completed-work or new verification decision is claimed.'},
      'provider_controls':{'main':'Protected PR with required validate; merge commits only; no bypass','pypi':'Existing main-only environment; approved reviewer removal remains; OIDC workflow unchanged','trusted_publisher':'mmzen account-side confirmation for owner mmzen, repository se_harness, workflow publish-pypi.yml and environment pypi retained from 0.22.1 activation; not a new authenticated PyPI settings read','marketplace_and_maintenance':'Non-fast-forward and deletion denied; observed exact parent and absent new maintenance ref','pages':'Existing Pages workflow and domain unchanged'},
      'authentication':{'codex':'Live probe passes','claude-code':'Explicit claude-opus-5-5 live probe passes; configured global.anthropic.claude-fable-5-1 default returns 404 and is not usable','limit':'Point-in-time readiness, not a promise that credentials cannot expire; required public tests remain future observations.'},
      'limitations':['R23-NATIVE-010/011 remain open under DEC-RLS-010 / RISK-RLS-008.','Codex Windows desktop remains not run/unverified under DEC-RLS-011 / RISK-RLS-009.','Git remains authoritative; source-built private service only, fixed hosted evaluator 0.22.1; RISK-HAG-001/002 remain.','Performance work, adoption, host update and production service deployment are excluded.','Public fresh/update tests and delivery receipts remain pending until authorized publication.'],
      'authority':'Prepared input for the exact human complete-release decision; this file authorizes nothing.'}
    put(R/E/'complete-release-readiness.json',readiness)
    version='0.23.0';wheel=rls['distribution']['wheel_sha256'];files=identity['files']
    actions=['release-integration','version-tag','github-release','pypi','maintenance-line','marketplace','documentation','pages','latest','last','receipts']
    settings=[('evaluator','https://pypi.org/project/se-harness/0.23.0/',{'record':'RLS-SEH-034','version':version,'wheel_sha256':wheel},['publisher','public_install'],'Integrate only the reviewed preparation plus exact RLS decision through protected PR #545 using a merge commit at its checked head. Dispatch publish-pypi.yml from main for RLS-SEH-034. Reconcile v0.23.0, GitHub assets, PyPI and release/0.23 at the exact candidate; independently download and install the public wheel. Stop on a conflicting immutable version or missing control.'),
      ('marketplace','https://github.com/mmzen/se_harness.git#plugin-marketplace',{'plugin_version':'0.2.7','source_commit':C,'evaluator_version':version,'wheel_sha256':wheel,'public_revision':STAGE,'codex_content_sha256':files['packages/codex/verity-plane/assembly-inventory.json'],'claude-code_content_sha256':files['packages/claude/verity-plane/assembly-inventory.json']},['assembly','qualification','public_ref'],'After public-wheel equality, promote the exact reviewed child to plugin-marketplace. Run public fresh installation and 0.2.6-to-0.2.7 update on both Windows CLIs in disposable profiles, using explicit qualified Opus 5.5 for Claude live calls. Preserve original inventories and archive bytes. No desktop pass or user-host update is authorized.'),
      ('documentation','https://github.com/mmzen/se_harness/tree/main',{'commit':DOC},['claims_review','links'],'Integrate the reviewed source guidance from the named documentation commit with the release decision. Compare every frozen Git-blob hash at review, integration and live main. Preserve qualified README snapshots. Retain later public availability as named JSON receipts; no post-approval prose edits or hash substitutions.'),
      ('demonstration','https://mmzen.github.io/se_harness/',{'governance_commit':'release-governance'},['deployment'],'Use the existing Pages workflow at the first main commit with the exact released RLS and binding. Observe canonical URL and existing domain provenance. Do not change provider settings; failed or unknown deployments remain pending.'),
      ('release_markers','https://github.com/mmzen/se_harness',{'latest':'v0.23.0','last':C},['authorization','readback'],'Only after every required non-marker observation passes, mark GitHub v0.23.0 latest and move last from the exact previous object to the release candidate. Use the existing serialized workflow and exact last lease; stop on unexpected movement. Integrate named receipts and check complete delivery.')]
    surfaces=[]
    for name,destination,expected,required,next_action in settings:
        entry={'id':name,'owner':'mmzen','disposition':'update','destination':destination,'work_reference':'WO-RLS-047','next_action':next_action,'expected':expected,'required_observations':required}
        if name=='marketplace':entry['hosts']=['codex','claude-code']
        surfaces.append(entry)
    receipt_names=['observations.json','publisher.json','evaluator-public-install.json','marketplace-public-ref.json','codex-public-fresh.json','codex-public-update.json','claude-code-public-fresh.json','claude-code-public-update.json','documentation-observations.json','pages-observations.json','release-marker-receipt.json','delivery-result.json','maintenance-line.json','integration-receipts.json']
    plan={'schema':'se-harness-delivery-plan/v2','release':{'contract':'REL-SEH-036','record':'RLS-SEH-034','version':version,'wheel_sha256':wheel},'review':{'by':'mmzen','reference':'PR #545 complete-release review. The matching human response is still required. The immutable review commit binds this plan and complete-release-review.md.'},'surfaces':surfaces,
      'complete_release':{'repository':'mmzen/se_harness','candidate_commit':C,'actions':actions,'marketplace':{'parent':PARENT,'commit':STAGE,'tree':'0e0ff666693ad7f00564435e2f35ce8e31a2fb4e','identity_sha256':sha(ident_raw)},'markers':{'previous_latest':'v0.22.1','previous_last':OLD},'integration':{'decision_paths':[D+'releases/RLS-SEH-034.md'],'receipt_paths':[P+n for n in receipt_names]},'readiness':{'path':E+'complete-release-readiness.json','sha256':sha((R/E/'complete-release-readiness.json').read_bytes())},'observations':P+'observations.json','evidence_root':P.rstrip('/'),'documentation':doc_hashes}}
    plan['complete_release']['documentation']={n:d for n,d in doc_hashes.items() if n=='README.md' or n.startswith('docs/')}
    put(R/E/'complete-release-plan.json',plan);print(json.dumps({'plan_sha256':sha((R/E/'complete-release-plan.json').read_bytes()),'readiness':'prepared','candidate':C,'documentation':DOC}))
elif mode=='check':
    plan=load(R/E/'complete-release-plan.json');spec=importlib.util.spec_from_file_location('release023_publisher',R/'.github/scripts/publish_release.py');pub=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pub;spec.loader.exec_module(pub)
    surfaces=pub.delivery.validate_plan(plan);m=meta(R/D/'releases/RLS-SEH-034.md');d=m['distribution']
    result=pub.verify_marketplace(R,types.SimpleNamespace(candidate_commit=C,wheel_sha256=d['wheel_sha256'],version=m['version'],wheel=d['wheel']),plan)
    for name,digest in plan['complete_release']['documentation'].items():assert sha(blob(DOC,name))==digest and sha((R/name).read_bytes())==digest
    ready=load(R/plan['complete_release']['readiness']['path'])
    for name,digest in ready['documentation']['source_files'].items():assert sha(blob(DOC,name))==digest and sha((R/name).read_bytes())==digest
    assert sha((R/plan['complete_release']['readiness']['path']).read_bytes())==plan['complete_release']['readiness']['sha256']
    for row in ready['evidence']:assert sha((R/row['path']).read_bytes())==row['sha256']
    report={'plan_sha256':sha((R/E/'complete-release-plan.json').read_bytes()),'surfaces':list(surfaces),'marketplace':result,'documentation':'10 exact Git blobs match','readiness':'all named evidence digests match; public observations still pending','authority':'No released state or human decision fabricated. Full resolver/integration decision checks follow the actual human release decision.'}
    put(O/'complete-plan-check.json',report);print(json.dumps(report))
else:raise ValueError(mode)
