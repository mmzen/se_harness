import hashlib,json
import hag_efficiency_plan as p
O=p.W/'release023-release-review-20261017';E=p.R/'docs/engineering/release-0-23-0/evidence/WO-RLS-045'
plan=E/'complete-release-plan.json';ready=E/'complete-release-readiness.json'
assert hashlib.sha256(plan.read_bytes()).hexdigest()=='d5935d55bc7d80b42cdd5b729dd49451f51f2b40480e3dc0a329ce874dd0d1cd'
for f in (plan,ready):
    with (O/('unreviewed-'+f.name)).open('xb') as out:out.write(f.read_bytes())
x=json.loads(plan.read_text());r=json.loads(ready.read_text());all_paths=x['complete_release']['documentation']
r['documentation']['source_files']=all_paths
r['documentation']['binding_note']='The existing plan validator accepts only README.md and docs/ paths in its canonical documentation map. All ten reviewed source files are bound here, including three packaging-source README files. Qualified public package bytes remain bound independently by the staged marketplace identity.'
ready.write_text(json.dumps(r,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
x['complete_release']['readiness']['sha256']=hashlib.sha256(ready.read_bytes()).hexdigest()
x['complete_release']['documentation']={n:d for n,d in all_paths.items() if n=='README.md' or n.startswith('docs/')}
plan.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
note={'observed_failure':'scripts.check_release_delivery.InvalidInput: documentation: unsupported path','command':'release023_complete_plan.py check','exit':1,'unreviewed_plan_sha256':'d5935d55bc7d80b42cdd5b729dd49451f51f2b40480e3dc0a329ce874dd0d1cd','resolution':'Use supported canonical map; preserve all ten source-file digests in the bound readiness companion. No accepted plan, product policy, payload, evidence or human decision changed.','canonical_documentation_paths':len(x['complete_release']['documentation']),'all_bound_source_files':len(all_paths)}
with (O/'plan-schema-correction.json').open('x',encoding='utf-8') as f:json.dump(note,f,indent=2)
print(json.dumps({'plan_sha256':hashlib.sha256(plan.read_bytes()).hexdigest(),'canonical_paths':len(x['complete_release']['documentation']),'all_paths':len(all_paths)}))
