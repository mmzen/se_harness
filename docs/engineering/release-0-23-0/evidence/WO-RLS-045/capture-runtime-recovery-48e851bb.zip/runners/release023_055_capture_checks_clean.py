from pathlib import Path
source=Path(__file__).with_name('release023_055_capture_checks.py')
text=source.read_text().replace("'capture-candidate-check.json'","'capture-candidate-check-clean.json'")
exec(compile(text,str(source),'exec'))
