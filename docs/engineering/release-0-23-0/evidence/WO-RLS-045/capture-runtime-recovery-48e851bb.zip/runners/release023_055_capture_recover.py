import json,sys,hashlib,zipfile
import hag_efficiency_plan as p
Q=p.W/'release023-final-055';p.O=Q
mode=sys.argv[1]
if mode=='environment':
    p.run('capture-clean-environment-retry',[sys.executable,'-I','-m','venv',Q/'capture-source-env'],cwd=p.W)
    code="import importlib.metadata,json; print(json.dumps([x.metadata['Name'] for x in importlib.metadata.distributions()]))"
    r=p.run('capture-clean-metadata',[Q/'capture-source-env/Scripts/python.exe','-I','-c',code],cwd=p.W)
    assert isinstance(r,list) and not any(x.casefold().replace('_','-')=='se-harness' for x in r)
    print('Clean test runtime has no installed se-harness metadata.')
elif mode=='retain':
    assert not list((p.R/'docs/engineering').rglob('VREC-SEH-034.md'))
    dest=p.R/'docs/engineering/release-0-23-0/evidence/WO-RLS-045/capture-runtime-recovery-48e851bb.zip'
    with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
        for n in ('final-capture.json','capture-candidate-check.json','capture-clean-environment.json','capture-clean-environment-retry.json','capture-clean-metadata.json'):z.write(Q/n,n)
        for n in ('release023_055_capture.py','release023_055_capture_checks.py','release023_055_capture_clean.py','release023_055_capture_checks_clean.py','release023_055_capture_recover.py'):z.write(p.W/n,'runners/'+n)
    report=p.R/'docs/engineering/release-0-23-0/evidence/WO-RLS-045/verification-assessment-48e851bb.md'
    with report.open('a',encoding='utf-8') as f:f.write('\n## Capture runtime recovery\n\nThe initial capture refused `RID018`: the system Python resolved distribution\nmetadata outside the temporary candidate checkout. No VREC was written. A fresh\nsource-test environment contains no installed se-harness metadata; the same\nidentity and candidate checks run unchanged there. The original refusal and\nsandbox ensurepip failure are retained in capture-runtime-recovery-48e851bb.zip.\nThis recovery changes the test environment, not product code or acceptance rules.\n')
    receipt=Q/'capture-receipt.json';r=json.loads(receipt.read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
    (Q/'capture-receipt-before-runtime-recovery.json').write_bytes(receipt.read_bytes())
    for row in r['files']:
        if row['path']==report.relative_to(p.R).as_posix():row.update(sha256=sha(report),bytes=report.stat().st_size)
    r['files'].append({'path':dest.relative_to(p.R).as_posix(),'sha256':sha(dest),'bytes':dest.stat().st_size})
    receipt.write_text(json.dumps(r,indent=2)+'\n');print('Refusal and unchanged-criteria runtime recovery retained.')
else:raise ValueError(mode)
