import hashlib,json,os,subprocess,sys,tempfile
from pathlib import Path
import hag_efficiency_plan as p

p.O=p.W/'release023-053-qualification'
p.O.mkdir(exist_ok=True)
C=(p.W/'release023-053-execution/candidate-head.txt').read_text().strip()
DOCKER=Path(r'C:\Users\mathi\AppData\Local\Programs\DockerDesktop\resources\bin')
os.environ['PATH']=str(DOCKER)+os.pathsep+os.environ['PATH']
def run(label,args,cwd=p.R):
    result=p.run(label,args,cwd=cwd,allowed=(0,1,2))
    record=json.loads((p.O/(label+'.json')).read_text())
    print(json.dumps({'label':label,'exit':record['exit'],'seconds':record['elapsed_seconds'],
        'stdout':record['stdout'][-2500:],'stderr':record['stderr'][-3000:]},indent=2),flush=True)
    assert record['exit']==0,label
    return result
def py(*a):return [sys.executable,'-X','utf8','-B',*a]
def clean():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=p.R,text=True).strip()==C
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=p.R,text=True).strip()
mode=sys.argv[1]
if mode=='build':
    clean()
    run('docker-identity',[DOCKER/'docker.exe','version','--format','{{json .}}'])
    run('recipe-replay',py('-m','repository_tools.release_build','replay','--repository',p.R,'--commit',C,
        '--version','0.23.0','--output-directory',p.O/'bundle','--result',p.O/'release-build-replay.json'))
    replay=json.loads((p.O/'release-build-replay.json').read_text())
    assert replay['candidate']['commit']==C
    (p.O/'bundle-manifest.json').write_text(json.dumps(replay['manifest'],indent=2)+'\n')
elif mode=='source':
    clean()
    run('windows-source',py('scripts/run_tests.py','--scale','full','--workers','4','--timings',p.O/'windows-timings.json'))
elif mode=='packages':
    wheel=p.O/'bundle/se_harness-0.23.0-py3-none-any.whl'
    run('released-package-verification',[p.P,'-I','-m','se_harness','qualify','candidate-package',
        '--candidate-wheel',wheel,'--candidate-commit',C,'--candidate-wheel-sha256',hashlib.sha256(wheel.read_bytes()).hexdigest(),
        '--verifier-wheel-sha256','cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053',
        '--checkout-root',p.R,'--output',p.O/'windows-package-qualification.json','--json'],cwd=p.W)
    run('client-environment',py('-m','venv',p.O/'client'),cwd=p.W)
    candidate=p.O/'client/Scripts/python.exe'
    run('client-install',[candidate,'-I','-m','pip','install','--disable-pip-version-check','--no-index','--no-deps',wheel],cwd=p.W)
    run('installed-cli-surface',py(p.R/'scripts/check_portable_release_surface.py','--harnessctl',p.O/'client/Scripts/harnessctl.exe'),cwd=p.W)
    run('portable-plugin-tests',py('-m','unittest','tests.plugin_integration.progressive_discovery.test_delivery',
        'tests.plugin_integration.progressive_discovery.test_activation','tests.plugin_integration.test_simple_plugin',
        'tests.plugin_integration.package_assembly.test_package_assembly','-v'))
elif mode=='upgrades':
    workspace=Path(tempfile.mkdtemp(prefix='vp23-'))
    assert 'GIT_CONFIG_COUNT' not in os.environ
    os.environ.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true')
    (p.O/'upgrade-environment-recovery.json').write_text(json.dumps({'workspace':str(workspace),
        'session_only_git_config':{'core.longpaths':True},'reason':'Use the short disposable workspace and process-only Git setting established during prior-candidate qualification; no new-candidate failure is implied.',
        'global_settings_changed':False},indent=2)+'\n')
    for number in (2,3):
        run('windows-upgrade-'+str(number),py('-m','repository_tools.upgrade_rehearsal','--repository',p.R,
            '--predecessor-python',p.P,'--successor-python',p.O/'client/Scripts/python.exe',
            '--output',p.O/('windows-upgrade-'+str(number)),'--workspace',workspace,'--timings'))
    results=[json.loads((p.O/('windows-upgrade-'+str(n))/'upgrade-rehearsal-result.json').read_text()) for n in (2,3)]
    assert all(r['overall_result']=='pass' for r in results) and results[0]['semantic_sha256']==results[1]['semantic_sha256']
    print('Both real upgrades passed with the same semantic digest.',flush=True)
elif mode=='stage':
    clean();bundle=p.O/'bundle-manifest.json';wheel=p.O/'bundle/se_harness-0.23.0-py3-none-any.whl'
    run('stage-plugins',py('scripts/build_plugin_marketplace.py','stage','--repository',p.R,'--revision',C,
        '--candidate-manifest',bundle,'--expected-manifest-sha256',hashlib.sha256(bundle.read_bytes()).hexdigest(),
        '--wheel',wheel,'--expected-wheel-sha256',hashlib.sha256(wheel.read_bytes()).hexdigest(),
        '--evaluator-python',p.P,'--output-directory',p.O/'marketplace'))
elif mode=='linux-packages':
    label='linux-packages-'+(sys.argv[2] if len(sys.argv)>2 else '01')
    output=p.O/label;output.mkdir(exist_ok=False)
    script=p.R/'scripts/check_portable_release_surface.py'
    assert script.read_bytes()==subprocess.check_output(['git','show',C+':scripts/check_portable_release_surface.py'],cwd=p.R)
    run(label,[DOCKER/'docker.exe','run','--rm','--network','none','--mount',f'type=bind,src={p.O},dst=/inputs,readonly',
        '--mount',f'type=bind,src={output},dst=/results','--mount',f'type=bind,src={p.W/"release023_linux_packages.py"},dst=/runner.py,readonly',
        '--mount',f'type=bind,src={script},dst=/check_portable_release_surface.py,readonly',
        '--entrypoint','python','hag-release023:'+C[:12],'/runner.py'])
elif mode=='combination':
    clean();wheel=p.O/'bundle/se_harness-0.23.0-py3-none-any.whl'
    prior=Path(r'C:\Users\mathi\.codex\plugins\cache\se-harness\verity-plane\0.2.6\packages\se_harness-0.22.1-py3-none-any.whl')
    if not prior.is_file(): raise FileNotFoundError(prior)
    assert hashlib.sha256(prior.read_bytes()).hexdigest()=='cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053'
    run('combination-build',py('server/scripts/qualify.py','prepare','--repository',p.R,'--output',p.O/'combination',
        '--client-wheel',wheel,'--client-replay',p.O/'release-build-replay.json','--evaluator-wheel',prior,
        '--image','hag-release023:'+C[:12],'--plugin-marketplace',p.O/'marketplace','--client-bundle',p.O/'bundle-manifest.json',
        '--evaluator-python',p.P))
else:raise ValueError(mode)
