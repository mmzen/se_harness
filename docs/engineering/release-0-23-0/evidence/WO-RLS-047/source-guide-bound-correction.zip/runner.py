import json,subprocess,sys,zipfile
import hag_efficiency_plan as p
O=p.W/'release023-release-review-20261017';p.O=O;R=p.R
PY='C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe';E='docs/engineering/release-0-23-0/evidence/WO-RLS-047/'
mode=sys.argv[1]
if mode=='test':
    r=p.run('readme-bounded-tests-fixed',[PY,'-X','utf8','-B','-m','unittest','tests.test_public_onboarding','tests.test_progressive_documentation','tests.plugin_integration.package_assembly.test_refresh_guidance'],cwd=R)
    count=len((R/'README.md').read_text().split());assert count<=650
    print(json.dumps({'readme_words':count,'limit':650,'result':r}))
elif mode=='commit':
    assert json.loads((O/'readme-bounded-tests-fixed.json').read_text())['exit']==0
    dest=R/E/'source-guide-bound-correction.zip'
    with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED) as z:
        for name in ('ready-ci-failed.log','ready-pr-ci.json','readme-bounded-tests.json','readme-bounded-tests-fixed.json'):z.write(O/name,name)
        z.write(p.W/'release023_readme_bound.py','runner.py')
    count=len((R/'README.md').read_text().split())
    review=R/E/'source-guide-bound-correction.md'
    with review.open('x',encoding='utf-8') as f:f.write(f'''# Source README size correction

The source suite at review c7be3ce0e3f28dc19b13691e00bdf2ab93474dde ran
1,346 tests, with one failure and two skips. The root README contained 679
words, above the existing 650-word limit. Downstream package checks were skipped.

WO-RLS-047 shortens only its new release summary to retain the qualification,
open-item, public-evidence and private-service boundaries. The README now has
{count} words. Existing onboarding, documentation and identity/link checks pass.
An intermediate local attempt still had 655 words and two sandbox temporary
directory access errors. The corrected run outside that sandbox passes all 47 tests.
The test and its limit are unchanged. Original CI failure and correction results
are retained in [the observations](source-guide-bound-correction.zip).

The binary candidate, archives, staged marketplace and ready RLS bytes are
unchanged. The successful ready-record replay remains applicable to those exact
inputs. The draft delivery plan's documentation hash must use the corrected
source commit before human review; the earlier unreviewed drafts are preserved
outside the repository. New CI must pass before complete-release approval.
''')
    paths=['README.md',E+'source-guide-bound-correction.zip',E+'source-guide-bound-correction.md']
    p.run('readme-bound-add',['git','add','--',*paths],cwd=R)
    p.run('readme-bound-diff',['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=R)
    p.run('readme-bound-commit',['git','commit','-m','Keep the release summary within the README size limit','-m','Harness-Work-Order: WO-RLS-047'],cwd=R)
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
    (O/'documentation-head.txt').write_text(head+'\n');print(head)
else:raise ValueError(mode)
