"""Prepare the separately required assurance of observed public delivery."""
import json,subprocess,sys,tomllib,zipfile
import release023_delivery as d
R=d.R;E=d.P;O=d.O;BASE=d.BASE
def run(n,a):return d.p.run(n,a,cwd=R)
def gov(n,*a):return d.p.gov(n,a[0],R,*a[1:],'--json')
mode=sys.argv[1]
if mode=='retain':
    assert d.load(O/'final-delivery-result.json')['status']=='complete'
    assert d.load(O/'publisher-final/delivery-result.json')['status']=='complete'
    final=d.load(O/'publisher-final-success.json');assert json.loads(final['stdout'])['conclusion']=='success'
    merged=(O/'receipt2-merge.txt').read_text().strip()
    assert d.git('branch','--show-current')=='codex/release-0-23-0' and not d.git('status','--porcelain')
    run('closeout-fetch-main',['git','fetch','origin']);assert d.git('rev-parse','origin/main')==merged
    run('closeout-fast-forward',['git','merge','--ff-only',merged]);assert not d.git('status','--porcelain');d.plan()
    context=gov('closeout-context','check','--artifact','WO-RLS-047');assert context['procedure']['current_step']=='STEP-WO-IMPLEMENT-CHECK'
    wo=tomllib.loads((R/d.D/'work-orders/WO-RLS-047.md').read_text().split('+++',2)[1]);assert wo['status']=='in_progress'
    assert d.load(R/E/'delivery-result.json')['status']=='complete'
    assessment='''# Public delivery verification assessment

Evaluator/client 0.23.0 and Verity Plane 0.2.7 were delivered under the unchanged
complete-release approval for RLS-SEH-034. The five-surface report is complete.
This assessment covers WO-RLS-047 under VER-RLS-041. The human verification of
these post-publication observations remains separate from the earlier binary
verification and release decision.

| Requirement | Observed result | Retained evidence |
| --- | --- | --- |
| REQ-RLO-019 | Pass. Independent public GitHub/PyPI archives match the approved hashes. Clean evaluator install and qualification pass. Both Windows CLIs pass fresh installation and actual 0.2.6-to-0.2.7 update, installed-file comparison, skill discovery and bundled evaluator setup. All ten frozen source documents, composed links, tagged private-sandbox source and public Pages provenance match. | evaluator-public-install.json, the four public-route receipts, documentation-observations.json and pages-observations.json |
| REQ-RLO-020 | Pass. All five surfaces have matching observed identities and content-bound evidence. Failures and recovery remain visible. | observations.json and delivery-result.json |
| REQ-RLO-023 | Pass. The existing publisher reused exact archives and the staged marketplace child. v0.23.0, release/0.23 and last resolve to the approved binary candidate; latest is v0.23.0. Protected receipt integrations preserve the frozen plan. | publisher.json, marketplace-public-ref.json, maintenance-line.json, release-marker-receipt.json and integration-receipts.json |

## Failures and recovery

The version-specific PyPI metadata endpoint returned 404 twice. The official
PyPI package index exposed both exact archives. Independent downloads, archive
hashes, attestations and a clean public install then passed. The original HTTP
failures and diagnostic results remain in evaluator-public-install.json.

Codex CLI 0.162.0-alpha.17.2 timed out twice during native marketplace upgrade.
Re-adding the same source alone reported alreadyAdded and left the old snapshot.
Recovery used native marketplace remove/add with the same public repository and
explicit plugin-marketplace ref in the disposable profile. The installed 0.2.6
plugin and its exact files remained intact before the successful native update
to 0.2.7. This qualifies the observed recovery route; the ordinary upgrade
timeouts remain recorded and are not reported as passing attempts. No global
setting or operator-host plugin changed.

The first documentation helper tried to resolve package-relative README links
inside the source tree. The corrected observation checks source links in the
source tree and package links in the actual composed marketplace. The helper
failure is retained; no approved document or package bytes changed.

The first publisher completion refused absent committed public observations.
After their protected integration, marker promotion passed. The same job's
report still read the previous pending marker observation. Independent marker
readback and the final receipt integration resolved that reporting dependency.
The final publisher result is successful. No check was waived.

## Scope and limits

The binary candidate remains 48e851bbc94d7fb0c06e9b80666c3860cb5f8c15,
already verified in VREC-SEH-034. This later candidate contains delivery evidence
and work completion, not replacement binaries. The full execution comparison
retains b43bef8c213ecabee94447a8fb52c32294c7ab75, the release-review main baseline.
The review PR compares its own new closeout changes with current main.

R23-NATIVE-010/011 remain open under DEC-RLS-010 / RISK-RLS-008. Codex Windows
desktop remains unverified under DEC-RLS-011 / RISK-RLS-009. These public-route
checks do not claim live model or desktop testing. Git remains authoritative;
the hosted service stays private and source-built, with evaluator 0.22.1.
Repository adoption, user-host updates and public service deployment are excluded.
'''
    d.put(R/E/'closeout-assessment.md',assessment)
    names=['receipts-validate','receipts-scope','receipts-check-pr','receipt1-merge-ci','receipt1-merge-diff','receipt1-merge-readback','marker-receipts-validate','marker-receipts-scope','marker-receipts-check-pr','marker-receipts-diff-check','receipt2-merge-ci','receipt2-merge-diff','receipt2-merge-readback','final-complete-delivery-report','publisher-final-success']
    with zipfile.ZipFile(R/E/'closeout-checks.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for name in names:z.write(O/(name+'.json'),name+'.json')
        for path in sorted((O/'publisher-final').glob('*.json')):z.write(path,'publisher-final/'+path.name)
        for name in ('release023_public_evaluator.py','release023_public_docs_pages.py','release023_receipts.py','release023_receipt_integration.py','release023_closeout.py'):z.write(d.W/name,name)
    for kind in ('handoff','pre-action'):
        path=R/E/('WO-RLS-047-'+kind+'.md');raw=path.read_bytes();header=raw.split(b'```',2)[0]+b'```'+raw.split(b'```',2)[1]+b'```'
        body='\n\n# WO-RLS-047 '+kind+' evidence\n\nAll five public delivery surfaces pass as retained in [the delivery result](delivery-result.json).\n[The closeout assessment](closeout-assessment.md) maps the approved requirements\nto actual observations and preserves failures, recovery and accepted limitations.\nThe exact released binaries and frozen plan remain unchanged. Required final\ncommit-bound assurance is being prepared; no human verification is inferred.\n'
        path.write_bytes(header+body.encode('utf-8'))
    gov('closeout-review-preflight','preflight','--work-order','WO-RLS-047','--phase','review')
    gov('closeout-handoff-evidence','evidence','--artifact','WO-RLS-047','--checkpoint','handoff')
    gov('closeout-pre-action-evidence','evidence','--artifact','WO-RLS-047','--checkpoint','pre-action')
    r=gov('closeout-handoff','check','--artifact','WO-RLS-047','--checkpoint','handoff','--from-git',BASE);assert r['compliance']['status']=='pass'
    print('Public-delivery closeout handoff passes.')
elif mode=='complete':
    assert d.load(O/'closeout-handoff.json')['exit']==0
    reason='Execution completion under the approved WO-RLS-047 scope and unchanged complete-release grant. All five surfaces pass independent retained public observations, the final publisher is successful, and both claimed CLIs pass fresh/update installation and evaluator setup. Earlier failures, supported recovery and accepted native/desktop limitations remain explicit. This applies no human assurance decision; VER-RLS-041 requires separate commit-bound verification.'
    a=['transition','--set','WO-RLS-047=implemented','--decision','WO-RLS-047=Codex','--reason','WO-RLS-047='+reason]
    preview=gov('closeout-completion-preview',*a);assert not preview['findings']['scoped_blockers']
    gov('closeout-completion-apply',*a,'--apply');gov('closeout-implemented-context','check','--artifact','WO-RLS-047')
    with zipfile.ZipFile(R/E/'closeout-lifecycle.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for name in ('closeout-context','closeout-review-preflight','closeout-handoff-evidence','closeout-pre-action-evidence','closeout-handoff','closeout-completion-preview','closeout-completion-apply','closeout-implemented-context'):z.write(O/(name+'.json'),name+'.json')
    changed=set(d.git('diff','--name-only').splitlines()+d.git('ls-files','--others','--exclude-standard').splitlines());assert changed and all(p.startswith(d.D) for p in changed)
    run('closeout-stage',['git','add','--',*sorted(changed)]);run('closeout-diff-check',['git','diff','--cached','--check'])
    run('closeout-commit',['git','commit','-m','Record public 0.23.0 delivery completion and assurance evidence','-m','Harness-Work-Order: WO-RLS-047'])
    assert not d.git('status','--porcelain');d.put(O/'closeout-candidate.txt',d.git('rev-parse','HEAD')+'\n')
elif mode=='capture':
    candidate=(O/'closeout-candidate.txt').read_text().strip();assert d.git('rev-parse','HEAD')==candidate and not d.git('status','--porcelain')
    assert not d.git('log','--all','--format=','--name-only','--','**/VREC-RLS-005.md')
    py=O/'evaluator-public-attempt3/env/Scripts/python.exe';assert py.is_file()
    paths=[E+p.name for p in (R/E).glob('*.json')]+[E+x for x in ('closeout-assessment.md','closeout-checks.zip','closeout-lifecycle.zip')]
    args=[d.p.P,'-I','-m','se_harness','capture-verification',R,'--id','VREC-RLS-005','--work-order','WO-RLS-047','--verification','VER-RLS-041','--owner','Codex','--domain','release-0-23-0','--candidate-commit',candidate]
    for p in sorted(paths):args+=['--evidence',p]
    args+=['--json','--test-command',py,'-I','-B','-X','utf8',d.W/'release023_closeout_capture.py',candidate,d.sha((R/E/'delivery-result.json').read_bytes())]
    d.p.run('closeout-capture',args)
    r=gov('closeout-ready-context','check','--artifact','VREC-RLS-005');assert r['instruction_discovery']['status']=='available'
    print(json.dumps({'record':'VREC-RLS-005','candidate':candidate,'state':r['state'],'step':r['procedure']['current_step']}))
else:raise ValueError(mode)
