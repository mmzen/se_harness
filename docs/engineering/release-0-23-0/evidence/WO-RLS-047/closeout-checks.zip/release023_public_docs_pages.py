"""Observe frozen documentation, tagged private sandbox and release-bound Pages."""
import datetime,importlib.util,json,posixpath,re,urllib.request,sys
import release023_delivery as d
M=(d.O/'release-merge-head.txt').read_text().strip();plan=d.plan()
ready=d.load(d.R/plan['complete_release']['readiness']['path'])
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
suffix='-attempt'+sys.argv[1] if len(sys.argv)>1 else ''
def save(name,value):(d.O/name.replace('.json',suffix+'.json')).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
assert not (d.O/('documentation-readback'+suffix+'.json')).exists() and not (d.O/('pages-readback'+suffix+'.json')).exists()
d.p.run('docs-fetch-main'+suffix,['git','fetch','origin','refs/heads/main:refs/remotes/origin/main','refs/heads/plugin-marketplace:refs/remotes/origin/plugin-marketplace','refs/tags/v0.23.0:refs/tags/v0.23.0'],cwd=d.R)
head=d.git('rev-parse','origin/main');assert head==M
docs={'observed_at':now(),'public_main':head,'source_file_checks':[],'status':'pending'}
try:
    documentation=ready['documentation'];frozen=documentation['source_files']
    assert len(frozen)==10 and all(frozen[p]==h for p,h in plan['complete_release']['documentation'].items())
    sources=list(plan['complete_release']['documentation'])
    for p,expected in frozen.items():
        values={ref:d.sha(d.blob(ref,p)) for ref in ('92f948ad9faea69e00485d59c0680694e21bc30e',M,head)}
        assert set(values.values())=={expected},p
        docs['source_file_checks'].append({'path':p,'expected_sha256':expected,'observed':values})
    spec=importlib.util.spec_from_file_location('links',d.R/'tests/plugin_integration/package_assembly/test_refresh_guidance.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    files={p:d.blob(head,p) for p in sources}
    for source in sources:
        for link in re.findall(r'\[[^]]*\]\(([^)]+)\)',files[source].decode()):
            if re.match(r'(?:https?://|mailto:|#)',link):continue
            p=posixpath.normpath(posixpath.join(posixpath.dirname(source),link.split('#')[0]));files[p]=d.blob(head,p)
    findings=mod.link_findings(files,sources);docs['source_link_findings']=findings;assert not findings
    new=plan['complete_release']['marketplace']['commit'];assert d.git('rev-parse','origin/plugin-marketplace')==new
    identity=json.loads(d.blob(new,'PACKAGE-IDENTITY.json'));package={p:d.blob(new,p) for p in identity['files']}
    assert all(d.sha(b)==identity['files'][p] for p,b in package.items())
    findings=mod.link_findings(package,['README.md','packages/codex/verity-plane/README.md','packages/claude/verity-plane/README.md']);docs['package_link_findings']=findings;assert not findings
    tag=d.git('rev-parse','v0.23.0^{commit}');assert tag==d.C
    sandbox_paths=d.git('ls-tree','-r','--name-only',d.C,'--','server/','docs/notes/hosted-artifact-graph.md').splitlines()
    assert sandbox_paths and all(d.blob(tag,p)==d.blob(d.C,p) for p in sandbox_paths)
    docs.update(status='pass',source_links='passed',public_package_links='passed',public_package_revision=new,public_package_file_count=len(package),tagged_sandbox={'tag':'v0.23.0','commit':tag,'candidate':d.C,'matching_files':len(sandbox_paths),'source_paths':sandbox_paths,'public_service_claim':False},claims_review='All ten frozen source files match the reviewed documentation commit, release governance and current main. Both public package README snapshots and all package bytes match qualification. Dated historical observations remain historical. Actual current public availability is retained in these named receipts. R23-NATIVE-010/011 remain open; Codex Windows desktop remains unverified under accepted DEC-RLS-010/011. Git remains authoritative and the service remains private and source-built with evaluator 0.22.1.')
    docs['link_context']='Seven source documents resolve in the source tree. Three package README templates resolve in their composed marketplace locations, as required by the existing test_package_links_resolve_after_composition. The first observation wrongly tried to resolve a package-relative link under release/plugin-marketplace in the source tree; that helper failure is retained separately.'
    save('documentation-readback.json',docs)
except Exception as e:
    docs.update(status='failed',error=str(e));save('documentation-readback.json',docs);raise
pages={'status':'pending','observed_at':now(),'http':[],'manifests':[]}
try:
    for base in ('https://mmzen.github.io/se_harness/','https://www.verityplane.ai/'):
        observed={}
        for name in ('publication-manifest.json','index.html'):
            url=base+name
            with urllib.request.urlopen(url,timeout=120) as r:
                raw=r.read();pages['http'].append({'url':url,'resolved_url':r.url,'status':r.status,'sha256':d.sha(raw),'size':len(raw),'observed_at':now()})
            observed[name]=raw;save('pages-readback.json',pages)
        manifest=json.loads(observed['publication-manifest.json']);assert manifest['release_record']=='RLS-SEH-034' and manifest['candidate_commit']==d.C and manifest['governance_commit']==M
        assert manifest['published_dashboard_sha256']==d.sha(observed['index.html'])
        pages['manifests'].append({'source':base,'content':manifest})
    pages.update(status='pass',release_record='RLS-SEH-034',candidate_commit=d.C,governance_commit=M);save('pages-readback.json',pages)
except Exception as e:
    pages.update(status='failed',error=str(e));save('pages-readback.json',pages);raise
print(json.dumps({'documentation':docs['status'],'pages':pages['status'],'governance_commit':M}))
