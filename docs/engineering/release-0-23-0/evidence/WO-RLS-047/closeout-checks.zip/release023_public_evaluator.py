"""Independent public download/install observations; never the checkout governor."""
import datetime,json,subprocess,urllib.request,sys
import release023_delivery as d
attempt=int(sys.argv[1]) if len(sys.argv)>1 else 1
out=d.O/('evaluator-public' if attempt==1 else 'evaluator-public-attempt'+str(attempt));out.mkdir(exist_ok=True)
dest=out/'result.json';assert not dest.exists()
resolved=d.load(d.O/'resolved-release-plan.json');assert resolved['candidate_commit']==d.C
plan=d.plan();package=json.loads(d.blob(plan['complete_release']['marketplace']['commit'],'PACKAGE-IDENTITY.json'))
expected_identity=package['evaluator'];assert expected_identity['version']=='0.23.0'
expected={'se_harness-0.23.0-py3-none-any.whl':'ffa486d386383992349e75e2890b36ded105c797acaa483783d1380cfd520d5c','se_harness-0.23.0.tar.gz':'777c9c1f518f6db1d3beb013f9bbb908544c482598ee399767fd789414f2ccfa'}
report={'status':'pending','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'http':[],'commands':[]}
def save():dest.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def get(url,headers=None):
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers=headers or {}),timeout=120) as r:
            data=r.read();report['http'].append({'url':url,'resolved_url':r.url,'status':r.status,'sha256':d.sha(data),'size':len(data),'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
        save();return data
    except Exception as e:
        report['http'].append({'url':url,'error':str(e)});save();raise
def run(label,args):
    name='public-evaluator-attempt'+str(attempt)+'-'+label
    try:return d.p.run(name,args)
    finally:
        report['commands'].append(d.load(d.O/(name+'.json')));save()
try:
    if attempt>=3:
        meta=json.loads(get('https://pypi.org/simple/se-harness/',{'Accept':'application/vnd.pypi.simple.v1+json'}))
        entries=[{'filename':f['filename'],'url':f['url'],'digests':f['hashes']} for f in meta['files'] if f['filename'] in expected]
        report['pypi_metadata_source']='Official PyPI Simple JSON index; version metadata API returned retained 404 responses.'
    else:
        meta=json.loads(get('https://pypi.org/pypi/se-harness/0.23.0/json'));entries=meta['urls']
    report['pypi_metadata']=meta;save()
    public=out/'pypi';public.mkdir();github=out/'github';github.mkdir()
    for name,sha in expected.items():
        entry=next(x for x in entries if x['filename']==name);assert entry['digests']['sha256']==sha
        raw=get(entry['url']);assert d.sha(raw)==sha;(public/name).write_bytes(raw)
        provenance=json.loads(get(f'https://pypi.org/integrity/se-harness/0.23.0/{name}/provenance'));assert provenance['attestation_bundles'];report.setdefault('provenance',{})[name]=provenance;save()
    run('github-download',['gh','release','download','v0.23.0','--repo','mmzen/se_harness','--dir',github,'--pattern','se_harness-0.23.0*'])
    for name,sha in expected.items():assert d.sha((github/name).read_bytes())==sha
    report['archive_hashes']=expected;save()
    env=out/'env';run('venv',[d.PY,'-m','venv',env]);py=env/'Scripts/python.exe';wheel=public/'se_harness-0.23.0-py3-none-any.whl'
    run('install',[py,'-I','-m','pip','install','--disable-pip-version-check','--no-index','--no-deps',wheel])
    identity=run('identity',[py,'-I','-m','se_harness','identity','--role','released-evaluator','--expected-version','0.23.0','--expected-root',env,'--checkout-root',d.R,'--evaluator-payload-sha256',expected_identity['payload_sha256'],'--evaluator-wheel-sha256',expected[wheel.name],'--require-isolated-python','--json']);assert identity['passed']
    run('qualification',[py,'-I','-m','se_harness','qualify','public-install',d.R,'--release-record','RLS-SEH-034','--public-wheel',wheel,'--public-wheel-sha256',expected[wheel.name],'--payload-sha256',expected_identity['payload_sha256'],'--output',out/'qualification.json','--json'])
    report.update(status='pass',identity=identity,qualification=d.load(out/'qualification.json'),python=str(py));save()
    print(json.dumps({'status':'pass','version':'0.23.0','archives':expected}))
except Exception as e:
    report.update(status='failed',error=str(e));save();raise
