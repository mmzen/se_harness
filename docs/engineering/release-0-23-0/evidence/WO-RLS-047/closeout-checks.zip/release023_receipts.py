"""Prepare and integrate only the frozen release's permitted JSON receipts."""
import datetime,hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
import release023_session as s
s.OUT=s.WORK/'release023-delivery-20261017';R=s.WORK/'r23receipts'
M=(s.OUT/'release-merge-head.txt').read_text().strip();C='48e851bbc94d7fb0c06e9b80666c3860cb5f8c15'
SHA='420b4b82891b2fe77244cc3c4a995ddab8153a11f649324f01b1f37e83e51b34'
P=s.DOMAIN+'evidence/WO-RLS-047/';E=s.DOMAIN+'evidence/WO-RLS-045/'
binding={'release_record':'RLS-SEH-034','candidate_commit':C,'plan_sha256':SHA}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def raw(name):return read(s.OUT/(name+'.json'))
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def write(name,value):
    value={**binding,**value};assert all(value[k]==v for k,v in binding.items());p=R/P/name;p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def ref(name):return [{'path':name,'sha256':hashlib.sha256((R/P/name).read_bytes()).hexdigest()}]
def embedded(p):
    b=(s.REPO/p).read_bytes();return {'path':p,'commit':M,'sha256':hashlib.sha256(b).hexdigest(),'content':json.loads(b) if p.endswith('.json') else b.decode()}
mode=sys.argv[1]
if mode=='prepare':
    assert not R.exists();s.run('receipts-clone',['git','-c','core.autocrlf=false','-c','core.longpaths=true','clone','--shared','--no-checkout',s.REPO,R])
    for key,value in [('core.autocrlf','false'),('core.longpaths','true')]:s.run('receipts-config-'+key,['git','config',key,value],cwd=R)
    s.run('receipts-checkout',['git','checkout','-b','codex/release-0-23-0-receipts',M],cwd=R)
    s.run('receipts-origin',['git','remote','set-url','origin','https://github.com/mmzen/se_harness.git'],cwd=R)
    assert not git('status','--porcelain')
    plan=read(R/E/'complete-release-plan.json');assert hashlib.sha256((R/E/'complete-release-plan.json').read_bytes()).hexdigest()==SHA
    release=embedded(s.DOMAIN+'releases/RLS-SEH-034.md')
    run=(s.OUT/'publisher-run.txt').read_text().strip()
    attempts=[]
    for f in sorted(s.OUT.glob('publisher-attempt*-final.json')):
        number=f.name.split('attempt')[1].split('-')[0]
        state=json.loads(read(f)['stdout']);assert state['status']=='completed'
        item={'attempt':int(number),'status':read(f),'artifacts':{}}
        for p in sorted((s.OUT/('publisher-attempt'+number)).rglob('*.json')):
            if p.name in ('release-result.json','marketplace-result.json','marker-result.json','delivery-result.json','public-install-qualification.json'):
                item['artifacts'][p.relative_to(s.OUT).as_posix()]=read(p)
        log=s.OUT/('publisher-attempt'+number+'-failed-log.json')
        if log.exists():item['failed_log']=read(log)
        attempts.append(item)
    assert attempts
    latest=attempts[-1];state=json.loads(latest['status']['stdout'])
    assert all(j['conclusion']=='success' for j in state['jobs'] if j['name']!='Finish under the recorded complete-release approval'),state
    write('publisher.json',{'observed_at':now(),'workflow_url':'https://github.com/mmzen/se_harness/actions/runs/'+run,'released_record':release,'decision_envelope':read(s.OUT/'corrected-release-envelope.json'),'attempts':attempts,'recovery':'Actual publisher attempts and failures are retained. Completed non-marker stages are preserved. Marker completion awaits the committed public observations required by the frozen plan.'})
    install=read(s.OUT/'evaluator-public-attempt3/result.json');assert install['status']=='pass';install['earlier_attempts']=[read(s.OUT/p) for p in ('evaluator-public/result.json','evaluator-public-attempt2/result.json')];install['visibility_diagnostic']=read(s.OUT/'pypi-visibility-diagnostic.json');write('evaluator-public-install.json',install)
    public=s.run('public-ref-confirmed',['git','ls-remote','origin','refs/heads/plugin-marketplace','refs/heads/release/0.23','refs/tags/v0.23.0','refs/tags/v0.23.0^{}','refs/tags/last'],cwd=R)[1]
    refs={line.split()[1]:line.split()[0] for line in public.stdout.splitlines()}
    new=plan['complete_release']['marketplace']['commit']
    assert refs['refs/heads/plugin-marketplace']==new and refs['refs/heads/release/0.23']==C and refs.get('refs/tags/v0.23.0^{}',refs['refs/tags/v0.23.0'])==C
    identity=json.loads(subprocess.check_output(['git','show',new+':PACKAGE-IDENTITY.json'],cwd=s.REPO))
    promotion=next(v for k,v in latest['artifacts'].items() if k.endswith('/marketplace-result.json'))
    write('marketplace-public-ref.json',{'observed_at':now(),'status':'pass','readback':raw('public-ref-confirmed'),'publisher':promotion,'assembly':{'commit':new,'path':'PACKAGE-IDENTITY.json','sha256':plan['complete_release']['marketplace']['identity_sha256'],'content':identity},'qualification':{'readiness':embedded(E+'complete-release-readiness.json'),'binary_verification':embedded(s.DOMAIN+'verification-records/VREC-SEH-034.md'),'retained_evidence_index':embedded(E+'capture-receipt-48e851bb.json')},'limitations':['R23-NATIVE-010/011 remain open under accepted DEC-RLS-010 / RISK-RLS-008.','Codex Windows desktop remains unverified under accepted DEC-RLS-011 / RISK-RLS-009.','Public routes exercise actual native installation/update, skill discovery and setup, not a desktop or live model session.']})
    routes=[]
    for host in ('codex','claude'):
        for kind in ('fresh','update'):
            route=read(s.OUT/(f'public027/{kind}-{host}-route'+('-attempt4' if (kind,host)==('update','codex') else '')+'.json'));setup=read(s.OUT/f'public027/{kind}-{host}-setup.json');assert route['status']==setup['status']=='pass'
            name=f'{route["host"]}-public-{kind}.json';v={'observed_at':now(),'status':'pass','native_route':route,'setup':setup,'runner_sources':{p:(s.WORK/p).read_text() for p in ('release023_public_routes.py','release023_public_setup.py')}}
            if kind=='update':v['baseline']=read(s.OUT/f'public027/baseline-{host}-route.json')
            if (kind,host)==('update','codex'):v['earlier_failed_attempts']=[read(s.OUT/p) for p in ('public027/update-codex-route.json','public027/update-codex-route-attempt2.json','public027/update-codex-route-attempt3.json')];v['recovery_note']='The native marketplace upgrade command timed out twice. Native re-add alone kept the old snapshot. Registration recovery through native remove/add preserved the installed old package before the actual native update. The original failed observations remain explicit; no host-global setting changed.'
            write(name,v);summary={k:route[k] for k in ('host','kind','status','host_version','observed_at','source','revision','plugin_version','content_sha256','evaluator_version','wheel_sha256')}
            if kind=='update':summary.update({k:route[k] for k in ('starting_version','starting_source')})
            routes.append({**summary,'evidence':ref(name)})
    for outname,inname in [('documentation-observations.json','documentation-readback-attempt2.json'),('pages-observations.json','pages-readback-attempt2.json')]:
        v=read(s.OUT/inname);assert v['status']=='pass'
        if outname=='documentation-observations.json':v['earlier_helper_failure']=read(s.OUT/'documentation-readback.json')
        write(outname,v)
    latest_release=s.run('public-latest-before-markers',['gh','api','repos/mmzen/se_harness/releases/latest'])[0]
    assert latest_release['tag_name']==plan['complete_release']['markers']['previous_latest'] and refs['refs/tags/last']==plan['complete_release']['markers']['previous_last']
    write('maintenance-line.json',{'observed_at':now(),'status':'pass','branch':'release/0.23','commit':C,'commands':[raw('public-ref-confirmed'),raw('public-latest-before-markers')],'publication':'Existing publisher reconciled the maintenance branch; independent readback equals the exact released candidate.'})
    write('integration-receipts.json',{'observed_at':now(),'completed_release_integration':raw('merge-readback'),'governance_commit':M,'receipt_integration':'Prepared for protected receipt-only PR; not integrated at this observation.','assurance':'WO-RLS-047 post-publication verification remains separate; these observations do not verify a future formal VREC.'})
    mapping={'evaluator':{'publisher':'publisher.json','public_install':'evaluator-public-install.json'},'marketplace':{x:'marketplace-public-ref.json' for x in ('assembly','qualification','public_ref')},'documentation':{x:'documentation-observations.json' for x in ('claims_review','links')},'demonstration':{'deployment':'pages-observations.json'}}
    surfaces=[]
    for surf in plan['surfaces']:
        name=surf['id'];row={'id':name,'status':'pending' if name=='release_markers' else 'pass','observed_at':now(),'source':surf['destination'],'identity':dict(surf['expected']),'evidence':{}}
        if name=='release_markers':row.update(identity={'latest':latest_release['tag_name'],'last':refs['refs/tags/last']},note='Markers unchanged until this exact public observation package is integrated and assessed.');row['evidence']={'authorization':ref('publisher.json'),'readback':ref('maintenance-line.json')}
        else:row['evidence']={k:ref(v) for k,v in mapping[name].items()}
        if name=='marketplace':row['routes']=routes
        if name=='demonstration':row['identity']['governance_commit']=M
        surfaces.append(row)
    write('observations.json',{'schema':'se-harness-delivery-observations/v1','observed_at':now(),'release':{'record':'RLS-SEH-034','status':'released','source':'https://github.com/mmzen/se_harness/blob/'+M+'/'+s.DOMAIN+'releases/RLS-SEH-034.md','observed_at':now(),'evidence':ref('publisher.json')},'surfaces':surfaces})
    spec=importlib.util.spec_from_file_location('delivery',R/'scripts/check_release_delivery.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    result,code=mod.assess(R/E/'complete-release-plan.json',R/P/'observations.json',R/P,governance_commit=M,before_markers=True);assert code==0 and result['status']=='ready_for_markers',result
    write('delivery-result.json',result)
    changed=git('ls-files','--others','--exclude-standard').splitlines();assert set(changed)<=set(plan['complete_release']['integration']['receipt_paths']);print(json.dumps({'files':len(changed),'status':result['status']}))
elif mode=='check-commit':
    s.gov('receipts-validate','validate',repo=R)
    paths=git('ls-files','--others','--exclude-standard').splitlines();args=[]
    for p in paths:args+=['--changed-path',p]
    s.gov('receipts-scope','check','--artifact','WO-RLS-047','--checkpoint','scope',*args,'--changes-complete',repo=R)
    s.run('receipts-diff-check',['git','diff','--check'],cwd=R)
    s.run('receipts-stage',['git','add','--',*paths],cwd=R)
    s.run('receipts-commit',['git','commit','-m','Retain public 0.23.0 and plugin 0.2.7 observations','-m','Harness-Work-Order: WO-RLS-047'],cwd=R)
    head=git('rev-parse','HEAD');(s.OUT/'receipt1-head.txt').write_text(head+'\n')
    s.run('receipts-integration-check',[s.PYTHON,'-B','-X','utf8',R/'.github/scripts/publish_release.py','check-integration','--repository',R,'--envelope',s.OUT/'corrected-release-envelope.json','--base',M,'--head',head,'--receipts'])
    body='The approved evaluator 0.23.0 and plugin 0.2.7 are public. This receipt-only change retains independent GitHub/PyPI archive checks, four public CLI fresh/update routes with evaluator setup, documentation and Pages readback. It preserves all actual publisher attempts and failures.\n\nAll non-marker observations pass. Latest/last remain pending until this protected integration lets the existing publisher assess these exact receipts. No lifecycle records, source, frozen plan or payloads change. R23-NATIVE-010/011 remain open and Codex Windows desktop remains unverified under accepted DEC-RLS-010/011. WO-RLS-047 commit-bound assurance remains separate.\n\nThis integration uses the existing complete-release grant in RLS-SEH-034.\n\nHarness-Work-Order: WO-RLS-047\n'
    (s.OUT/'receipt1-pr-body.md').write_text(body);(s.OUT/'receipt1-pr-event.json').write_text(json.dumps({'pull_request':{'body':body}}))
    s.gov('receipts-check-pr','check-pr','--event',s.OUT/'receipt1-pr-event.json','--from-git',M,repo=R)
elif mode=='push':
    head=(s.OUT/'receipt1-head.txt').read_text().strip();assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
    _,remote=s.run('receipts-main-before',['git','ls-remote','origin','refs/heads/main'],cwd=R);assert remote.stdout.split()[0]==M
    s.gov('receipts-publish-gates','check','--artifact','RLS-SEH-034','--checkpoint','pre-action','--procedure','PROC-EXTERNAL-ACTION',repo=R)
    s.run('receipts-push',['git','push','-u','origin','HEAD:refs/heads/codex/release-0-23-0-receipts'],cwd=R)
    s.run('receipts-create-pr',['gh','pr','create','--repo','mmzen/se_harness','--base','main','--head','codex/release-0-23-0-receipts','--title','Retain public release 0.23.0 and plugin 0.2.7 observations','--body-file',s.OUT/'receipt1-pr-body.md'])
