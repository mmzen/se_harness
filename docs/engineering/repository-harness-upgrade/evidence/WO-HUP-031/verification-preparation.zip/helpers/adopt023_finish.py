"""Retain observed evidence, complete work and capture verification under its approval."""
from adopt023_execute import *
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def load(n):return json.loads((O/(n+'.json')).read_text())

complete=['transition',R,'--set',WO+'=implemented','--decision',WO+'=codex',
 '--reason',WO+'=Applied the approved public 0.23.0 repository adoption, CI pin, development source 0.23.1 and current guidance/test changes. Required local checks, full regression and two matching upgrade rehearsals passed. Historical bytes and private service selection are preserved. Retained failures and corrections remain visible. Human verification and merge remain separate.']

if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='retain':
    required=['full-source-final','focused-guidance-corrected','distribution-check','cli-smoke',
      'evaluator-facts','adopted-identity','adopted-validation','adopted-entry','adopted-procedure',
      'adoption-activation','governor-transition','actual-rehearsal-1','actual-rehearsal-2']
    for name in required:assert load(name)['exit']==0,name
    assert load('preservation')['all_equal'] and not load('changed-links-final')['findings']
    assert not git('status','--porcelain')
    c=(O/'implementation-commit.txt').read_text().strip();assert git('rev-parse','HEAD')==c
    with zipfile.ZipFile(E/'commands.zip','x',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(O.glob('*.json')):z.write(f,f.name)
        for folder in ('upgrade-1','upgrade-2'):
            for f in sorted((O/folder).glob('*.json')):z.write(f,folder+'/'+f.name)
        for f in sorted(W.glob('adopt023_*.py')):z.write(f,'helpers/'+f.name)
    paths=git('diff','--name-only',BASE,c).splitlines()
    assessed={x:sha(R/x) for x in paths if '/work-orders/' not in x}
    r={'base':BASE,'implementation_commit':c,'assessed_file_sha256':assessed,
       'commands_sha256':sha(E/'commands.zip'),'source_suite':{'tests':1346,'reported_skips':24,'exit':0},
       'focused_recovery':{'tests':47,'exit':0},'preserved_files':len(load('preservation')['files']),
       'current_index_exclusions':load('preservation')['excluded_current_indexes'],
       'ci':'Pending review publication; required CI must pass before merge.',
       'limits':'Repository adoption only. Host plugin and private service unchanged. Existing open instruction findings and desktop omission retained.'}
    (E/'results.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
    report=f'''# Repository adoption of 0.23.0 — verification assessment

WO-HUP-031 adopts the exact public evaluator under VER-HUP-026. Human approval
authorizes implementation and review publication; result acceptance remains pending.
Implementation commit: `{c}`. Trusted base: `{BASE}`.

| Requirement / check | Actual result |
| --- | --- |
| REQ-REB-027: public identity | Pass. Selected wheel and payload match RLS-SEH-034; isolated identity, doctor, validation and released-root checks pass. |
| REQ-IAR-031: bounded installer | Pass. Only configuration and lock change. Repeat upgrade is unchanged; schema 5, external resources and integrations remain selected. |
| Owner and history preservation | Pass. All 14,625 checked pre-existing owner, formal, evidence and plugin/package files match their original Git blobs. Four approved current indexes are excluded explicitly. |
| CI/source boundary | Pass. CI and repository select 0.23.0; unpublished source is 0.23.1. Version derivation and committed governor-transition assessment pass. |
| Real upgrade rehearsal | Pass twice. Disposable 0.23.0-to-0.23.1 runs have identical semantic results. The local test wheel is not promotable or a repository governor. |
| Regression | Final clean-commit full suite: 1,346 tests, 24 skips, exit 0. All 47 affected guidance tests pass after correction. Distribution checks and CLI help pass. |
| Guidance | Current public claims use independent release/observation inputs. All changed documentation links resolve. Published snapshots and accepted limits retain their bytes. |
| Session | Activation and resource lookup return the selected 0.23.0 instructions. This is not native startup/compaction or desktop qualification. |
| Handoff/candidate | Subsequent generated handoff and capture records establish completion and the exact verification candidate. |
| Hosted CI | Pending publication; required checks must pass before merge. |

## Failures and corrections

The first focused run reported 16 errors in the refresh-guidance helper. Its old
receipt layout expected an inline marketplace proof; the 0.23.0 receipt binds a
separate proof by path and SHA-256. The corrected helper follows that binding and
rejects missing bindings and changed proof bytes. Existing wrong-version, public-ref,
tree, digest, contradictory-claim and link rejection checks remain in place.

The first changed-link check found the old hosted-client heading anchor after the
heading was updated. The correction restores the historical anchor and uses the
current heading for the current link. Final changed-link review passes.

The first full run passed while the guidance correction was being completed.
The final full run was repeated on the clean committed implementation; only that
stable run supplies the final full-suite claim. Both runs and the failed focused
run remain in commands.zip. Earlier preparation sandbox failures remain in
preparation-checks.zip. No failed or skipped check is relabeled as a pass.

## Review and limits

This change reuses the installer, CI pipeline and existing tests. Product source
changes only its version fields. The test uses retained public evidence, not
agreement between mutable README strings. The private service remains on 0.22.1
and Git remains authoritative. No host-plugin, provider, tag, release, deployment
or new live-host change was performed.

R23-NATIVE-010/011 remain open under DEC-RLS-010 / RISK-RLS-008. Codex Windows
desktop remains unverified under DEC-RLS-011 / RISK-RLS-009. Adoption adds no waiver.
Human verification and merge remain separate. The existing grant covers the draft
review PR and later verification-decision push to codex/adopt-0-23-0 targeting main.

See [bound results](results.json), [actual commands](commands.zip), the
[approval review](review.md), and the canonical installer transaction
[WO-HUP-031-evaluator-upgrade.json](../WO-HUP-031-evaluator-upgrade.json).
'''
    (E/'final-assessment.md').write_bytes(report.encode('utf-8'))
    call('review-preflight','preflight',R,'--work-order',WO,'--phase','review',target=True)
    call('handoff-packet','evidence',R,'--artifact',WO,'--checkpoint','handoff',target=True)
    call('handoff-check','check',R,'--artifact',WO,'--checkpoint','handoff','--from-git',BASE,target=True)
 elif mode=='complete-preview':
    assert load('handoff-check')['exit']==0
    call('completion-preview',*complete,target=True)
 elif mode=='complete-apply':
    assert current()['status']=='in_progress' and load('completion-preview')['exit']==0
    call('completion-apply',*complete,'--apply',target=True)
    call('implemented-context','check',R,'--artifact',WO,target=True)
    with zipfile.ZipFile(E/'lifecycle.zip','x',zipfile.ZIP_DEFLATED) as z:
        for name in ('review-preflight','handoff-packet','handoff-check','completion-preview','completion-apply','implemented-context'):
            z.write(O/(name+'.json'),name+'.json')
    p.run('evidence-add',['git','add','--',D+'work-orders/'+WO+'.md',E],cwd=R)
    p.run('evidence-whitespace',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'],cwd=R)
    p.run('evidence-commit',['git','commit','-m','Retain adoption checks and implementation completion','-m','Harness-Work-Order: '+WO],cwd=R)
    assert not git('status','--porcelain')
    (O/'candidate.txt').write_text(git('rev-parse','HEAD')+'\n')
 elif mode=='final-assess':
    c=(O/'candidate.txt').read_text().strip();assert git('rev-parse','HEAD')==c
    r=p.run('final-governor-transition',[SOURCE,'-S',R/'scripts/validate_governor_transition.py','assess',
      '--repository',R,'--base-revision',BASE,'--default-branch-ref','refs/remotes/origin/main',
      '--evaluator-python',TARGET,'--evaluator-entry-point',TARGET.parent/'harnessctl.exe',
      '--evaluator-wheel',WHEEL,'--output',O/'final-transition-result.json','--json'])
    print(json.dumps({'passed':r['passed'],'candidate':c}))
 elif mode=='capture':
    c=(O/'candidate.txt').read_text().strip();assert git('rev-parse','HEAD')==c and not git('status','--porcelain')
    assert not git('log','--all','--format=','--name-only','--','**/'+VREC+'.md')
    args=[TARGET,'-I','-m','se_harness','capture-verification',R,'--id',VREC,'--work-order',WO,
      '--verification',VER,'--owner','codex','--domain','repository-harness-upgrade','--candidate-commit',c]
    for f in sorted(E.iterdir()):
        if f.is_file():args+=['--evidence',f.relative_to(R).as_posix()]
    args+=['--evidence',TRANSACTION,'--json','--test-command',SOURCE,'-I','-B','-X','utf8',
      W/'adopt023_capture_check.py',c,sha(E/'results.json'),O/'final-transition-result.json',sha(O/'final-transition-result.json')]
    r=p.run('verification-capture',args);print(json.dumps(r.get('restitution',r)))
    call('ready-context','check',R,'--artifact',VREC,target=True)
 else:raise ValueError(mode)
