"""Assess exact committed adoption inputs; source qualification is evidence only."""
import sys,json,hashlib,subprocess,zipfile,os
from pathlib import Path
C,expected,transition_path,transition_sha=sys.argv[1:]
R=Path.cwd();D='docs/engineering/repository-harness-upgrade/'
E=R/D/'evidence/WO-HUP-031'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
assert git('rev-parse','HEAD')==C and not git('status','--porcelain')
assert sha(E/'results.json')==expected
r=json.loads((E/'results.json').read_text())
for path,digest in r['assessed_file_sha256'].items():assert sha(R/path)==digest,path
changes=git('diff','--name-only',r['implementation_commit'],C).splitlines()
assert all(x==D+'work-orders/WO-HUP-031.md' or x.startswith(D+'evidence/WO-HUP-031/') for x in changes),changes
assert sha(E/'commands.zip')==r['commands_sha256']
with zipfile.ZipFile(E/'commands.zip') as z:
    for name in ('full-source-final','focused-guidance-corrected','distribution-check','cli-smoke',
      'evaluator-facts','adopted-identity','adopted-validation','adopted-entry','adopted-procedure',
      'adoption-activation','governor-transition','actual-rehearsal-1','actual-rehearsal-2'):
        assert json.loads(z.read(name+'.json'))['exit']==0,name
    assert json.loads(z.read('preservation.json'))['all_equal']
    assert not json.loads(z.read('changed-links-final.json'))['findings']
    assert json.loads(z.read('full-final-binding.json'))['candidate_commit']==r['implementation_commit']
    a=json.loads(z.read('upgrade-1/upgrade-rehearsal-result.json'))
    b=json.loads(z.read('upgrade-2/upgrade-rehearsal-result.json'))
    assert a['overall_result']==b['overall_result']=='pass' and a['semantic_sha256']==b['semantic_sha256']
t=Path(transition_path);assert sha(t)==transition_sha
tr=json.loads(t.read_text());assert tr['passed'] and tr['target']['commit']==C
env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1');env.pop('PYTHONPATH',None)
argv=[sys.executable,'-B','-X','utf8','-m','se_harness','qualify','complete-candidate','.', '--candidate-commit',C,'--json']
test=subprocess.run(argv,env=env,capture_output=True,encoding='utf-8',timeout=900)
print(json.dumps({'candidate_commit':C,'retained_results_sha256':expected,
    'final_transition_sha256':transition_sha,'final_transition_passed':True,
    'candidate_check':{'argv':argv,'cwd':str(R),'exit_code':test.returncode,'stdout':test.stdout,'stderr':test.stderr},
    'scope':'Retained tests and rehearsals bind unchanged implementation files. Fresh source qualification and the final released-governor assessment cover this exact commit. No new native-host or service qualification is claimed.'}))
assert test.returncode==0
