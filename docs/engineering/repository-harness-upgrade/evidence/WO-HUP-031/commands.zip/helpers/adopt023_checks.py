"""Required adoption checks; candidate source is evidence, never the governor."""
import os,re,posixpath,tarfile,tempfile
from adopt023_execute import *

def checked(label,args,cwd=R):
    r=p.run(label,args,cwd=cwd)
    print(json.dumps({'name':label,'exit':json.loads((O/(label+'.json')).read_text())['exit'],
        'result':{k:r[k] for k in ['passed','valid','overall_result','semantic_sha256','version','candidate_version'] if k in r}}),flush=True)
    return r

mode=sys.argv[1]
if mode=='focused':
    checked('focused-tests',[SOURCE,'-B','-X','utf8','-m','unittest','tests.test_ci_pipeline',
      'tests.test_governor_transition','tests.test_predecessor_bootstrap_retirement',
      'tests.test_progressive_documentation','tests.test_public_onboarding',
      'tests.plugin_integration.package_assembly.test_refresh_guidance'])
elif mode=='full':
    checked('full-source',[SOURCE,'-B','-X','utf8','scripts/run_tests.py','--scale','full'])
elif mode=='other':
    checked('distribution-check',[SOURCE,'-B','-X','utf8','scripts/validate_release_distributions.py','--root','.'])
    checked('cli-smoke',[SOURCE,'-B','-X','utf8','-m','se_harness','--help'])
    checked('evaluator-facts',[SOURCE,'-B','-X','utf8','-m','repository_tools.evaluator_facts','derive','--repository',R,'--json'])
    call('adopted-validation','validate',R,target=True)
    call('adopted-entry','resources',R,'--resource','ENGINEERING_HARNESS.md','--content',target=True)
    call('adopted-procedure','resources',R,'--resource','docs/engineering/harness/EXECUTE_WORK.md',target=True)
elif mode=='preserve':
    rows=subprocess.check_output(['git','ls-tree','-r','-z',BASE,'--','AGENTS.md','docs/engineering',
       '.gitattributes','.gitignore','.github/PULL_REQUEST_TEMPLATE.md','release/plugin-marketplace','plugins'],cwd=R)
    allowed={'docs/engineering/README.md','docs/engineering/release-0-23-0/README.md',
       D+'README.md','docs/engineering/self-hosting-boundary/SELF_HOSTING.md'}
    entries=[]
    for row in rows.split(b'\0'):
        if not row:continue
        meta,path=row.decode().split('\t');blob=meta.split()[2]
        if path in allowed:continue
        data=(R/path).read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        entries.append({'path':path,'base_blob':blob,'current_blob':actual,'equal':blob==actual})
    doc={'base':BASE,'excluded_current_indexes':sorted(allowed),'files':entries,'all_equal':all(x['equal'] for x in entries)}
    (O/'preservation.json').write_text(json.dumps(doc,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'checked_files':len(entries),'all_equal':doc['all_equal']}));assert doc['all_equal']
elif mode=='links':
    sys.path.insert(0,str(R))
    from tests.plugin_integration.package_assembly.test_refresh_guidance import link_findings
    paths=git('diff','--name-only',BASE).splitlines()
    sources=[x for x in paths if x.endswith('.md') and '/work-orders/' not in x and '/verification/' not in x]
    files={x:(R/x).read_bytes() for x in sources}
    for source in sources:
        for target in re.findall(r'\[[^]]*\]\(([^)]+)\)',files[source].decode()):
            if re.match(r'(?:https?://|mailto:|#)',target):continue
            path=posixpath.normpath(posixpath.join(posixpath.dirname(source),target.split('#')[0]))
            if (R/path).is_file():files[path]=(R/path).read_bytes()
            elif (R/path).is_dir() and '#' not in target:files[path]=b''
    findings=link_findings(files,sources)
    dest=O/((sys.argv[2] if len(sys.argv)>2 else 'changed-links')+'.json')
    assert not dest.exists(),dest
    dest.write_text(json.dumps({'sources':sources,'findings':findings},indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'sources':len(sources),'findings':findings}));assert not findings
elif mode=='commit':
    paths=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
    allowed=current()['execution_scope']['paths']
    assert all(x in allowed or any(y.endswith('/') and x.startswith(y) for y in allowed) for x in paths)
    checked('implementation-add',['git','add','--',*paths])
    checked('implementation-whitespace',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'])
    checked('implementation-commit',['git','commit','-m','Adopt public evaluator 0.23.0 and refresh current guidance','-m','Harness-Work-Order: WO-HUP-031'])
    assert not git('status','--porcelain')
    (O/'implementation-commit.txt').write_text(git('rev-parse','HEAD')+'\n')
elif mode=='build':
    c=(O/'implementation-commit.txt').read_text().strip();assert git('rev-parse','HEAD')==c
    export=O/'candidate-export';export.mkdir()
    checked('candidate-export',['git','archive','--format=tar','--output',O/'candidate-source.tar',c])
    with tarfile.open(O/'candidate-source.tar') as t:t.extractall(export,filter='data')
    checked('candidate-wheel',[PY,'-m','pip','wheel','--disable-pip-version-check','--no-deps','--wheel-dir',O/'candidate-dist',export],cwd=W)
    env=O/'candidate-env';cp=env/'Scripts/python.exe'
    checked('candidate-environment',[PY,'-m','venv',env],cwd=W)
    wheel=O/'candidate-dist/se_harness-0.23.1-py3-none-any.whl';assert wheel.is_file()
    checked('candidate-install',[cp,'-m','pip','install','--disable-pip-version-check','--no-index','--no-deps',wheel],cwd=W)
    checked('candidate-identity',[cp,'-I','-m','se_harness','identity','--role','candidate-package',
       '--expected-version','0.23.1','--expected-root',env,'--checkout-root',R,'--candidate-commit',c,'--require-isolated-python','--json'],cwd=W)
    (O/'candidate-wheel-binding.json').write_text(json.dumps({'commit':c,'version':'0.23.1',
        'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),
        'purpose':'Non-promotable CI rehearsal input only; not released or used as repository governor.'},indent=2)+'\n')
elif mode=='rehearse':
    cp=O/'candidate-env/Scripts/python.exe';assert cp.is_file()
    os.environ.update({'GIT_CONFIG_COUNT':'1','GIT_CONFIG_KEY_0':'core.longpaths','GIT_CONFIG_VALUE_0':'true'})
    (O/'rehearsal-environment.json').write_text(json.dumps({'workspace':tempfile.gettempdir(),
        'process_local_git':{'core.longpaths':'true'},'global_settings_changed':False},indent=2)+'\n')
    for i in (1,2):
        checked('actual-rehearsal-'+str(i),[SOURCE,'-B','-X','utf8','-m','repository_tools.upgrade_rehearsal',
           '--repository',R,'--predecessor-python',TARGET,'--successor-python',cp,
           '--output',O/('upgrade-'+str(i)),'--workspace',tempfile.gettempdir(),'--timings'])
    a=json.loads((O/'upgrade-1/upgrade-rehearsal-result.json').read_text());b=json.loads((O/'upgrade-2/upgrade-rehearsal-result.json').read_text())
    assert a['overall_result']==b['overall_result']=='pass' and a['semantic_sha256']==b['semantic_sha256']
    print(json.dumps({'both_pass':True,'semantic_sha256':a['semantic_sha256']}))
elif mode=='assess':
    checked('governor-transition',[SOURCE,'-S',R/'scripts/validate_governor_transition.py','assess',
      '--repository',R,'--base-revision',BASE,'--default-branch-ref','refs/remotes/origin/main',
      '--evaluator-python',TARGET,'--evaluator-entry-point',TARGET.parent/'harnessctl.exe',
      '--evaluator-wheel',WHEEL,'--output',O/'transition-result.json','--json'],cwd=W)
else:raise ValueError(mode)
