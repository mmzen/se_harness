"""Apply the approved current-documentation, owner CI and source-version edits."""
from adopt023_execute import *

def edit(name,old,new):
    f=R/name;s=f.read_text(encoding='utf-8')
    assert s.count(old)==1,(name,old[:100],s.count(old))
    f.write_bytes(s.replace(old,new,1).encode('utf-8'))

def block(name,start,end,new):
    f=R/name;s=f.read_text(encoding='utf-8')
    assert s.count(start)==1 and s.count(end)==1,name
    i=s.index(start);j=s.index(end,i)
    f.write_bytes((s[:i]+new+s[j:]).encode('utf-8'))

assert current()['status']=='in_progress'
assert '0.23.0' in (R/'.engineering-harness.toml').read_text()
edit('.github/workflows/engineering-harness.yml','SE_HARNESS_VERSION: "0.22.1"','SE_HARNESS_VERSION: "0.23.0"')
edit('pyproject.toml','version = "0.23.0"','version = "0.23.1"')
edit('se_harness/__init__.py','__version__ = "0.23.0"','__version__ = "0.23.1"')

edit('README.md',
 'Observed public delivery (2026-10-05): Plugin **0.2.6** bundles released **SE Harness 0.22.1**. Windows Codex/Claude CLI installation, update from 0.2.5 and offline setup passed. [Public evidence](docs/engineering/release-0-22-1/evidence/WO-RLS-042/closeout-assessment.md) records identities and limits.',
 'Observed public delivery (2026-10-17): Plugin **0.2.7** bundles released **SE Harness 0.23.0**. Windows Codex/Claude CLI installation, update from 0.2.6 and offline setup passed. [Public evidence](docs/engineering/release-0-23-0/evidence/WO-RLS-047/closeout-assessment.md) records the supported Codex update recovery, retained timeouts and limits.')
block('README.md','### Evaluator 0.22.1 and plugin 0.2.6','## Fewer repository files',
'''### Evaluator 0.23.0 and plugin 0.2.7

The [release](docs/engineering/release-0-23-0/README.md) delivers the hosted client
and plugin guidance. [VREC-SEH-034](docs/engineering/release-0-23-0/verification-records/VREC-SEH-034.md)
records candidate verification. R23-NATIVE-010/011 remain open; Codex Windows
desktop remains unverified under accepted DEC-RLS-010/011 and RISK-RLS-008/009.

[RLS-SEH-034](docs/engineering/release-0-23-0/releases/RLS-SEH-034.md) records release
authority. [VREC-RLS-005](docs/engineering/release-0-23-0/verification-records/VREC-RLS-005.md)
verifies completed public delivery. The repository selects evaluator 0.23.0 under
[WO-HUP-031](docs/engineering/repository-harness-upgrade/work-orders/WO-HUP-031.md);
development source is unpublished 0.23.1. The private, source-built service keeps
evaluator 0.22.1. Git remains authoritative.

Historical [0.22.1 / plugin 0.2.6](docs/engineering/release-0-22-1/README.md)
records retain their original results.

''')
edit('README.md','Future complete-release procedure','Complete-release procedure')
edit('docs/engineering/README.md',
 '- [release-0-23-0/](release-0-23-0/README.md): approved preparation of evaluator/client 0.23.0 and plugin 0.2.7; exact-package and private-service qualification remain pending.',
 '- [release-0-23-0/](release-0-23-0/README.md): published evaluator/client 0.23.0 and plugin 0.2.7; candidate verification is VREC-SEH-034 and public-delivery verification is VREC-RLS-005. Accepted instruction findings and the desktop omission remain open.')
edit('docs/engineering/README.md',
 '- [Repository adoption](repository-harness-upgrade/README.md): WO-HUP-030 selects 0.22.1. Release preparation now selects unpublished candidate source 0.23.0; it does not change the root evaluator.',
 '- [Repository adoption](repository-harness-upgrade/README.md): WO-HUP-031 selects released evaluator 0.23.0 and unpublished development source 0.23.1. The private service remains on 0.22.1.')
edit('docs/engineering/self-hosting-boundary/SELF_HOSTING.md','pinned to 0.22.1 under WO-HUP-030','pinned to 0.23.0 under WO-HUP-031')
edit('docs/engineering/self-hosting-boundary/SELF_HOSTING.md','binds the selected 0.22.1 wheel','binds the selected 0.23.0 wheel')
edit(D+'README.md','## Current adoption: 0.22.1',
'''## Current adoption: 0.23.0

[WO-HUP-031](work-orders/WO-HUP-031.md) adopts the public wheel bound by
RLS-SEH-034 under [VER-HUP-026](verification/VER-HUP-026.md). The installer changes
only the configuration and lock; the separately approved owner edit pins CI to
0.23.0. Development source advances to unpublished 0.23.1. Current guides and
the public-identity test follow verified VREC-RLS-005 delivery evidence.

The [review](evidence/WO-HUP-031/review.md) binds the approved scope and preparation
checks. Final implementation verification and merge remain separate. The private
service stays on 0.22.1; host plugins and accepted release limitations are unchanged.

## Previous adoption: 0.22.1''')

block('docs/engineering/release-0-23-0/README.md',
 '# Proposed evaluator 0.23.0 and plugin 0.2.7 release','Historical preparation:',
'''# Published evaluator 0.23.0 and plugin 0.2.7

Current status: **RLS-SEH-034 is released. VREC-SEH-034 and VREC-RLS-005 are verified
by mmzen. All five public delivery surfaces are complete.**

Binary candidate `48e851bbc94d7fb0c06e9b80666c3860cb5f8c15` covers 20 implemented
work orders and 11 verification contracts. The [candidate assessment](evidence/WO-RLS-045/verification-assessment-48e851bb.md)
and [VREC-SEH-034](verification-records/VREC-SEH-034.md) retain its qualification,
including 19 passing CI checks and accepted limits. PR #544 merged that verification.
[RLS-SEH-034](releases/RLS-SEH-034.md) binds the same candidate and archives.

[VREC-RLS-005](verification-records/VREC-RLS-005.md), merged through PR #548,
verifies the later public observations under WO-RLS-047. The
[closeout assessment](evidence/WO-RLS-047/closeout-assessment.md) and
[delivery result](evidence/WO-RLS-047/delivery-result.json) cover GitHub/PyPI,
marketplace, documentation, Pages, maintenance line and latest/last. Windows
Codex and Claude CLI fresh/update routes passed. Codex required native marketplace
registration recovery; its ordinary upgrade timeouts remain recorded.

The [frozen plan and review](evidence/WO-RLS-045/complete-release-review.md)
retain the release inputs and decision boundary. Published package README snapshots
remain unchanged; current source guidance reports the later delivery result.

''')
edit('docs/engineering/release-0-23-0/README.md',
 'Exact release membership, proposed versions and one complete-release decision.',
 'Exact release membership, versions and the complete-release decision.')
edit('docs/engineering/release-0-23-0/README.md',
 'Review branch: `codex/release-0-23-0`, proposed target `main`.\nReleased 0.22.1 continues to govern preparation and the private service.\nThe proposed plugin bundles the new 0.23.0 evaluator/client; these distinct\nidentities must be explicit in the actual combination and current instructions.',
 'Historical preparation branch: `codex/release-0-23-0`, integrated into `main`.\nReleased 0.22.1 governed preparation and remains the private service evaluator.\nRepository adoption under WO-HUP-031 selects 0.23.0; development source is 0.23.1.\nPublished plugin 0.2.7 bundles evaluator/client 0.23.0.')
edit('docs/engineering/release-0-23-0/README.md',
 'The preparation review and its byte-bound checks preserve the original proposal. Human verification and merge precede the later frozen-plan\napproval, which can cover all listed public outputs together.',
 'The preparation review and its byte-bound checks preserve the original proposal.\nHuman verification, integration and the complete-release decision were followed\nby the retained public delivery and closeout verification.')

block('docs/notes/developing-se-harness.md','Development source in this checkout reports','In evaluator examples,',
'''Development source reports unpublished 0.23.1. The repository and CI select
independently installed public 0.23.0 under `WO-HUP-031`, from RLS-SEH-034.
The schema-5 lock selects external wheel resources and retains their public
wheel/payload digests. Source execution remains candidate evidence and does not
establish released-evaluator identity. The private service retains its 0.22.1 pin.

''')
block('docs/notes/developing-se-harness.md',
 'Agent skills and native instruction delivery come from each host',
 'Use the [plugin installation guide]',
'''Agent skills and native instruction delivery come from each host's installed
Verity Plane plugin. Public plugin 0.2.7 bundles evaluator/client 0.23.0 at
marketplace commit `d04776866046b60b14ffef14ced1453c4aafa7d9`.
Publication does not update a user's plugin or repository selection.
WO-HUP-031 selects evaluator 0.23.0 here.
[Public observations](../engineering/release-0-23-0/evidence/WO-RLS-047/closeout-assessment.md),
verified in VREC-RLS-005, cover Windows CLI fresh/update routes and offline setup.
Codex update used supported marketplace registration recovery after retained
timeouts. These observations do not claim new live model or desktop tests.
R23-NATIVE-010/011 remain open; desktop remains unverified under DEC-RLS-010/011
and RISK-RLS-008/009.

''')
edit('docs/notes/developing-se-harness.md',
 'The selected 0.22.1 evaluator applies these checks after the authorized `WO-HUP-030` adoption.',
 'The selected 0.23.0 evaluator applies these checks after the authorized `WO-HUP-031` adoption.')
edit('docs/notes/developing-se-harness.md',
 'The protected `pypi` environment remains a separate human decision.',
 'For the complete-release route, the exact frozen plan covers all listed outputs. The separately authorized reviewer-only provider change was applied for 0.22.1; recheck its current controls before dispatch. Legacy records retain their original authority requirements.')
block('docs/notes/developing-se-harness.md','- Latest markers, the step that was missed:',
 '\nThis repository integrates reviewed work',
'''- Latest markers: the complete-release route promotes latest/last only after its required public observations pass. It uses the frozen plan's prior marker identities and retains readback. Resume the existing publisher under the same approval; do not add manual tag writes. The [delivery procedure](release-delivery-completion.md#execute-and-resume-delivery) defines the receipt integration and completion report. Legacy releases keep their original route. Historical incident: `last` stayed on 0.7.1 through the 0.8.0 and 0.9.0 releases, and 0.9.0 remained latest after 0.10.0 publication, until manual correction on 2026-08-29.
''')
edit('docs/notes/developing-se-harness.md',
 'WO-HUP-030 selects public 0.22.1 from RLS-SEH-033 in the repository and CI.\nIts transaction updates only the configuration and lock; retained integrations\nand owner files stay in place. That adoption advanced development source to\nunpublished 0.22.2. REL-SEH-036 now prepares 0.23.0 without changing the root evaluator.',
 'WO-HUP-031 selects public 0.23.0 from RLS-SEH-034 in the repository and CI.\nIts installer transaction updates only the configuration and lock; retained\nintegrations and owner files stay in place. Separate approved edits set the CI\npin and development source 0.23.1. Public delivery is verified in VREC-RLS-005.\nThe preceding WO-HUP-030 adoption selected 0.22.1 and development source 0.22.2.')
edit('docs/notes/developing-se-harness.md',
 'This repository follows its selected public 0.22.1 evaluator after the authorized `WO-HUP-030` adoption.',
 'This repository follows its selected public 0.23.0 evaluator after the authorized `WO-HUP-031` adoption.')

edit('docs/notes/harness-installation-and-upgrades.md',
 'SE Harness 0.22.1 and plugin 0.2.6 are public. This repository selects\nreleased evaluator 0.22.1 under WO-HUP-030',
 'SE Harness 0.23.0 and plugin 0.2.7 are public. This repository selects\nreleased evaluator 0.23.0 under WO-HUP-031')
edit('docs/notes/harness-installation-and-upgrades.md',
 'Use [the delivery evidence](../engineering/release-0-23-0/evidence/WO-RLS-047/README.md)\nto establish public availability.',
 '[VREC-RLS-005](../engineering/release-0-23-0/verification-records/VREC-RLS-005.md)\nverifies the [public delivery observations](../engineering/release-0-23-0/evidence/WO-RLS-047/closeout-assessment.md).')

edit('docs/notes/release-delivery-completion.md','repository selects 0.22.1 under WO-HUP-030.',
 'repository selects 0.23.0 under WO-HUP-031.')
edit('docs/notes/release-delivery-completion.md','## Current 0.22.1 delivery',
'''## Current 0.23.0 delivery

Evaluator/client 0.23.0 and plugin 0.2.7 are public. Marketplace commit:
`d04776866046b60b14ffef14ced1453c4aafa7d9`. The
[delivery result](../engineering/release-0-23-0/evidence/WO-RLS-047/delivery-result.json)
records all five surfaces complete, including Pages, latest v0.23.0 and last at
the released candidate. [VREC-RLS-005](../engineering/release-0-23-0/verification-records/VREC-RLS-005.md)
records mmzen's verification of the public observations.

Windows Codex and Claude CLI fresh installation, update from 0.2.6 and offline
setup passed. The [assessment](../engineering/release-0-23-0/evidence/WO-RLS-047/closeout-assessment.md)
retains Codex's marketplace timeouts and supported registration recovery.
R23-NATIVE-010/011 remain open; desktop remains unverified under DEC-RLS-010/011
and RISK-RLS-008/009. Repository adoption is separately governed by WO-HUP-031.
These public-route checks do not qualify live model sessions or the private service.

## Historical 0.22.1 delivery''')

edit('docs/notes/plugin-installation-guide.md',
 'for actual public fresh/update observations. Do not infer publication from qualification.',
 'for actual public fresh/update observations. [VREC-RLS-005](../engineering/release-0-23-0/verification-records/VREC-RLS-005.md)\nverifies completed delivery. Windows Codex and Claude CLI fresh installation,\n0.2.6-to-0.2.7 update and offline setup passed. Codex used the recovery below\nafter ordinary marketplace upgrade timed out; those attempts remain failures.')
edit('docs/notes/plugin-installation-guide.md',
 '## Connect a disposable project and check it',
'''### Observed Codex marketplace recovery

The 0.23.0 public qualification used Codex CLI 0.162.0-alpha.17.2. Its ordinary
marketplace upgrade timed out twice. Re-adding the same source alone returned
`alreadyAdded` and kept the old snapshot. In the disposable profile, native
marketplace remove/add with the same repository and explicit `plugin-marketplace`
ref refreshed registration. The installed 0.2.6 plugin and its files remained
intact before the successful native update to 0.2.7. See the
[retained recovery](../engineering/release-0-23-0/evidence/WO-RLS-047/closeout-assessment.md#failures-and-recovery).
This qualifies that recovery route, not the timed-out ordinary update attempts.
Inspect the actual source and installed bytes before using this recovery.

## Connect a disposable project and check it''')

block('docs/notes/plugin-marketplace-publication.md',
 'For evaluator 0.22.1 / plugin 0.2.6,','## Historical public delivery: 0.22.0 / 0.2.5',
'''Evaluator/client 0.23.0 and plugin 0.2.7 are public.
[VREC-SEH-034](../engineering/release-0-23-0/verification-records/VREC-SEH-034.md)
records binary verification; [RLS-SEH-034](../engineering/release-0-23-0/releases/RLS-SEH-034.md)
records the release decision. [VREC-RLS-005](../engineering/release-0-23-0/verification-records/VREC-RLS-005.md)
verifies the [public delivery observations](../engineering/release-0-23-0/evidence/WO-RLS-047/closeout-assessment.md).
Compare the actual public identity with those records before claiming delivery.
R23-NATIVE-010/011 and the desktop omission remain under DEC-RLS-010/011 and
RISK-RLS-008/009. Public CLI checks do not remove those limits.

Package READMEs are immutable snapshots from their qualified source. The 0.2.6
and 0.2.7 snapshots include earlier status and preparation wording. Preserve
their bytes and inventories. Current source guidance and delivery receipts
describe later publication; do not rewrite a qualified package in place.
The [0.22.1 public evidence](../engineering/release-0-22-1/evidence/WO-RLS-042/README.md)
retains that earlier release's observations and decisions.

''')
edit('docs/notes/plugin-marketplace-publication.md',
 'The repository now selects 0.22.1 under WO-HUP-030.',
 'The repository now selects 0.23.0 under WO-HUP-031.')
edit('docs/notes/plugin-marketplace-publication.md',
 'The [0.22.1 / plugin 0.2.6 preparation](../engineering/release-0-22-1/README.md)',
 'The [0.23.0 / plugin 0.2.7 release](../engineering/release-0-23-0/README.md)')

edit('docs/notes/harnessctl-reference.md','in the selected released 0.22.1 evaluator','in the selected released 0.23.0 evaluator')
edit('docs/notes/harnessctl-reference.md',
 '## Hosted sandbox client (unpublished)\n\n`harnessctl remote` is available in candidate client 0.22.2, installed into a\nseparate test environment. The selected released evaluator 0.22.1 does not\nprovide this command. Keep the released evaluator selected for repository and server checks.\n\nIn these examples, `CLIENT_PYTHON` is the absolute Python path in the separate\ncandidate environment.',
 '## Hosted sandbox client\n\n`harnessctl remote` is available in released evaluator/client 0.23.0, now selected\nfor this repository. The private service remains pinned to its separate released\n0.22.1 evaluator. A client upgrade does not change the service selection.\n\nIn these examples, `CLIENT_PYTHON` is the absolute Python path in the isolated\nreleased 0.23.0 client environment.')
edit('docs/notes/harnessctl-reference.md','0.22.1 after explicit adoption under WO-HUP-030.',
 '0.23.0 after explicit adoption under WO-HUP-031.')

name='tests/plugin_integration/package_assembly/test_refresh_guidance.py'
f=R/name;s=f.read_text(encoding='utf-8')
s=s.replace('"""Keep the unpublished HAG candidate separate from public release evidence."""',
 '"""Check package identities and current claims against independent public receipts."""')
s=s.replace('# REL-SEH-036 selects these unpublished release identities.',
 '# REL-SEH-036 selects these package identities; development source may advance.')
s=s.replace('CANDIDATE_PLUGIN','PACKAGE_PLUGIN').replace('CANDIDATE_EVALUATOR','PACKAGE_EVALUATOR')
s=s.replace('PUBLIC_PLUGIN = "0.2.6"','PUBLIC_PLUGIN = "0.2.7"')
s=s.replace('RLS-SEH-033','RLS-SEH-034').replace('release-0-22-1/','release-0-23-0/').replace('WO-RLS-042/','WO-RLS-047/')
s=s.replace('EVALUATOR = "0.22.1"','EVALUATOR = "0.23.0"').replace(
 'cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053',SHA)
s=s.replace('candidate manifest version','package manifest version')
s=s.replace('test_selected_candidate_and_public_claims_have_independent_inputs','test_package_and_public_claims_have_independent_inputs')
s=s.replace('test_each_host_must_match_the_unpublished_candidate','test_each_host_must_match_the_selected_package')
s=s.replace('for version in (PUBLIC_PLUGIN, "0.2.8"):', 'for version in ("0.2.6", "0.2.8"):')
s=s.replace('test_candidate_version_does_not_replace_public_evidence','test_wrong_package_or_public_claim_is_rejected')
s=s.replace('data["marketplace"].replace(PACKAGE_PLUGIN, PUBLIC_PLUGIN)', 'data["marketplace"].replace(PACKAGE_PLUGIN, "0.2.6")')
s=s.replace('data["root"].replace(PUBLIC_PLUGIN, PACKAGE_PLUGIN)', 'data["root"].replace(PUBLIC_PLUGIN, "0.2.8")')
f.write_bytes(s.encode('utf-8'))
print(json.dumps({'tracked_changes':git('diff','--name-only').splitlines()}))
