"""Disposable preparation rehearsal; selected repository is not upgraded."""
import hashlib,json,sys
from adopt023_prepare import *
scratch=W/'adopt023-planning-rehearsal'
mode=sys.argv[1]
if mode=='run':
 assert not scratch.exists()
 run('rehearsal-clone',['git','clone','--no-hardlinks','--no-checkout',R,scratch])
 run('rehearsal-checkout',['git','-c','core.autocrlf=false','-c','core.longpaths=true','checkout','--detach',BASE],cwd=scratch)
 run('rehearsal-autocrlf',['git','config','core.autocrlf','false'],cwd=scratch)
 run('rehearsal-longpaths',['git','config','core.longpaths','true'],cwd=scratch)
 paths=['AGENTS.md','.gitattributes','.gitignore','.github/PULL_REQUEST_TEMPLATE.md','.github/workflows/engineering-harness.yml']
 before={x:hashlib.sha256((scratch/x).read_bytes()).hexdigest() for x in paths}
 gov('rehearsal-apply','upgrade','--apply','--evidence-output',D+'evidence/adoption-0-23-0-planning-transaction.json',target=True,repo=scratch)
 gov('rehearsal-doctor','doctor',target=True,repo=scratch)
 run('rehearsal-root',[TARGET,'-I','-m','se_harness','qualify','released-root',scratch,'--json'])
 gov('rehearsal-repeat','upgrade',target=True,repo=scratch)
 changed=git('diff','--name-only',cwd=scratch).splitlines()
 assert set(changed)=={'.engineering-harness.toml','.engineering-harness.lock'}
 after={x:hashlib.sha256((scratch/x).read_bytes()).hexdigest() for x in paths};assert before==after
 for name,old,new in [('pyproject.toml','version = "0.23.0"','version = "0.23.1"'),('se_harness/__init__.py','__version__ = "0.23.0"','__version__ = "0.23.1"')]:
  f=scratch/name;s=f.read_text(encoding='utf-8');assert s.count(old)==1;f.write_bytes(s.replace(old,new).encode('utf-8'))
 facts=run('rehearsal-evaluator-facts',[PY,'-B','-X','utf8','-m','repository_tools.evaluator_facts','derive','--repository',scratch,'--json'],cwd=scratch)
 result={'scope':'Disposable planning rehearsal only. Selected repository remains 0.22.1.','base':BASE,'installer_changed_paths':changed,'owner_before':before,'owner_after':after,'evaluator_facts':facts,'status':'pass'}
 (O/'rehearsal-summary.json').write_bytes((json.dumps(result,indent=2)+'\n').encode('utf-8'));print(json.dumps(result))
else:raise ValueError(mode)
