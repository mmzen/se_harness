"""Prepare the bounded adoption proposal; no real repository upgrade or approval."""
import json,sys,hashlib,subprocess,tomllib
from pathlib import Path
import hag_efficiency_plan as p
W=p.W;R=p.R;O=W/'adopt023-preparation-20261017';O.mkdir(exist_ok=True);p.O=O
BASE='ed29d435f37b5c2c8b81b1e1375d504edc98787a'
PY=Path(r'C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe')
PLUGIN=Path(r'C:/Users/mathi/.codex/plugins/cache/se-harness/verity-plane/0.2.6')
DATA=Path(r'C:/Users/mathi/.codex/plugins/data/verity-plane-se-harness')
SHA='ffa486d386383992349e75e2890b36ded105c797acaa483783d1380cfd520d5c'
TARGET=DATA/'evaluators/0.23.0'/SHA/'Scripts/python.exe'
WHEEL=W/'release023-delivery-20261017/evaluator-public-attempt3/pypi/se_harness-0.23.0-py3-none-any.whl'
D='docs/engineering/repository-harness-upgrade/'
def run(n,a,**kw):
 r=p.run(n,a,**kw)
 if isinstance(r,dict): print(json.dumps({'name':n,**{k:r[k] for k in ['status','outcome','allocated_id','path','changes','errors','error_count','warning_count','returncode','diagnostics'] if k in r}}),flush=True)
 return r
def gov(n,cmd,*a,repo=R,target=False,allowed=(0,)):
 return run(n,[TARGET if target else p.P,'-I','-m','se_harness',cmd,repo,*a,'--json'],allowed=allowed)
def git(*a,cwd=R):return subprocess.check_output(['git',*a],cwd=cwd,text=True).strip()
if __name__=='__main__':
 mode=sys.argv[1]
 if mode=='setup':
  assert hashlib.sha256(WHEEL.read_bytes()).hexdigest()==SHA
  run('target-environment-setup',[PY,'-I',PLUGIN/'scripts/setup.py','--target',R,'--data-root',DATA,'--wheel',WHEEL],allowed=(0,1))
  assert TARGET.is_file()
 elif mode=='inspect':
  assert not git('status','--porcelain') and git('rev-parse','HEAD')==BASE and git('rev-parse','origin/main')==BASE
  run('create-adoption-branch',['git','switch','-c','codex/adopt-0-23-0','origin/main'],cwd=R)
  run('target-upgrade-help',[TARGET,'-I','-m','se_harness','upgrade','--help'])
  gov('target-doctor-before','doctor',target=True,allowed=(0,1))
  gov('target-upgrade-preview','upgrade',target=True)
  result=gov('repository-inspect','inspect');print('inspection recorded',len(json.dumps(result)))
  for typ in ['work_order','verification']:
   print(json.dumps(gov('allocate-'+typ,'create-artifact','--domain','repository-harness-upgrade','--type',typ,'--dry-run')))
 elif mode=='create':
  typ,aid=sys.argv[2:]
  print(json.dumps(gov('create-'+aid,'create-artifact','--domain','repository-harness-upgrade','--type',typ,'--id',aid)))
  fs=list((R/D).rglob(aid+'.md'));assert len(fs)==1;print(fs[0].read_text(encoding='utf-8'))
 else:raise ValueError(mode)
