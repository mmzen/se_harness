"""Execute only the approved WO-HUP-031 repository adoption."""
import zipfile
from adopt023_prepare import *
PREP=O
O=W/'adopt023-execution-20261017';O.mkdir(exist_ok=True);p.O=O
E=R/D/'evidence/WO-HUP-031'
WO='WO-HUP-031';VER='VER-HUP-026';VREC='VREC-HUP-029'
SOURCE=W/'release023-final-055/capture-source-env/Scripts/python.exe'
TRANSACTION=D+'evidence/WO-HUP-031-evaluator-upgrade.json'

def call(label,*args,target=False,allowed=(0,)):
    r=p.run(label,[TARGET if target else p.P,'-I','-m','se_harness',*args,'--json'],allowed=allowed)
    print(json.dumps({'name':label,**{k:r[k] for k in [
        'status','outcome','valid','error_count','warning_count','changes','restitution',
        'operation','diagnostics','refusals','writes','summary'] if k in r}}),flush=True)
    return r

def current(aid=WO):
    folder='work-orders' if aid==WO else 'verification'
    return tomllib.loads((R/D/folder/(aid+'.md')).read_text(encoding='utf-8').split('+++')[1])

reason='mmzen approved implementation and review publication for repository/CI adoption of public 0.23.0, development source 0.23.1, the named documentation/test changes, required commit-bound verification, review pushes/draft PR codex/adopt-0-23-0 to mmzen/se_harness:main and the later verification-decision push. Human verification, merge and host-plugin updates remain separate.'
approval=['transition',R,'--set',VER+'=approved','--set',WO+'=approved',
          '--decision',VER+'=mmzen','--decision',WO+'=mmzen',
          '--reason',VER+'='+reason,'--reason',WO+'='+reason]
start=['transition',R,'--set',WO+'=in_progress','--decision',WO+'=codex',
       '--reason',WO+'=Start the approved adoption under mmzen authority.']

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='approval-preview':
        assert git('branch','--show-current')=='codex/adopt-0-23-0'
        assert git('rev-parse','HEAD')==BASE
        reviewed=json.loads((E/'reviewed-artifacts.json').read_text())
        assert all(hashlib.sha256((R/x['path']).read_bytes()).hexdigest()==x['sha256'] for x in reviewed['artifacts'])
        assert current()['status']=='draft' and current(VER)['status']=='draft'
        f=R/D/'work-orders'/ (WO+'.md');s=f.read_text(encoding='utf-8')
        assert '[assurance]' not in s.split('+++')[1]
        addition='[assurance]\ncommit_bound_verification = "required"\nrationale = "The repository evaluator selection, CI pin, source version boundary and current instructions change trusted state used by later decisions."\ndecided_by = "mmzen"\n\n'
        s=s.replace('[relations]\n',addition+'[relations]\n',1);f.write_bytes(s.encode('utf-8'))
        (E/'approval.json').write_text(json.dumps({'human':'mmzen','date':'2026-10-17',
            'answer':'Approve implementation and review publication','scope':reason,
            'reviewed_manifest':'reviewed-artifacts.json','recording_change':'Added only human-confirmed assurance metadata to the draft work order.',
            'approval_input_sha256':{x:hashlib.sha256((R/D/folder/(x+'.md')).read_bytes()).hexdigest()
                for x,folder in [(WO,'work-orders'),(VER,'verification')]}},indent=2)+'\n',encoding='utf-8')
        call('approval-preview',*approval)
    elif mode=='approval-apply':
        grant=json.loads((E/'approval.json').read_text())
        assert all(hashlib.sha256((R/D/folder/(x+'.md')).read_bytes()).hexdigest()==grant['approval_input_sha256'][x]
            for x,folder in [(WO,'work-orders'),(VER,'verification')])
        call('approval-apply',*approval,'--apply')
        assert current()['status']=='approved' and current(VER)['status']=='approved'
        call('start-preflight','preflight',R,'--work-order',WO,'--phase','start')
        call('start-preview',*start)
    elif mode=='start-apply':
        assert current()['status']=='approved'
        call('start-apply',*start,'--apply')
        call('started-check','check',R,'--artifact',WO)
    elif mode=='scope':
        paths=json.loads((PREP/'planned-paths.json').read_text())
        paths=[x for x in paths if not x.endswith('/')]
        paths+=git('ls-files','--others','--exclude-standard').splitlines()
        args=[v for x in sorted(set(paths)) for v in ['--changed-path',x]]
        call('implementation-scope','check',R,'--artifact',WO,'--checkpoint','scope',*args,'--changes-complete')
    elif mode=='upgrade-preview':
        assert current()['status']=='in_progress'
        call('upgrade-authorized-preview','upgrade',R,'--evidence-output',TRANSACTION,target=True)
    elif mode=='upgrade-apply':
        assert current()['status']=='in_progress'
        call('upgrade-authorized-apply','upgrade',R,'--evidence-output',TRANSACTION,'--apply',target=True)
        call('adopted-doctor','doctor',R,target=True)
        call('adopted-identity','identity','--role','released-evaluator',
             '--expected-version','0.23.0','--expected-root',TARGET.parent.parent,
             '--checkout-root',R,'--evaluator-payload-sha256',
             '8b5671743d56fceb81bf6117fca97c807f407bafaf9137d629ac60b91ffa14b6',
             '--evaluator-wheel-sha256',SHA,'--require-isolated-python',target=True)
        call('adopted-root','qualify','released-root',R,target=True)
        call('adopted-repeat','upgrade',R,target=True)
    else:raise ValueError(mode)
