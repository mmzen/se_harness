"""Publish the approved draft review, preserving the separate verification decision."""
import base64
from adopt023_execute import *
V=D+'verification-records/'+VREC+'.md';J=D+'evidence/'+VREC+'-evaluator.json'
REMOTE='https://github.com/mmzen/se_harness.git'
mode=sys.argv[1]
if mode=='prepare':
    c=(O/'candidate.txt').read_text().strip();assert git('rev-parse','HEAD')==c
    meta=tomllib.loads((R/V).read_text().split('+++')[1]);assert meta['status']=='ready' and meta['commit']==c
    assert set(git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines())=={V,J}
    with zipfile.ZipFile(E/'verification-preparation.zip','x',zipfile.ZIP_DEFLATED) as z:
        for name in ['final-governor-transition','final-transition-result','verification-capture','ready-context']:
            z.write(O/(name+'.json'),name+'.json')
        for name in ['adopt023_capture_check.py','adopt023_finish.py']:
            z.write(W/name,'helpers/'+name)
    (E/'verification-preparation.md').write_text(f'''# Verification preparation

The released 0.23.0 evaluator prepared VREC-HUP-029 for candidate `{c}`.
It remains ready, with human verification pending. The candidate check confirms
the retained result/evidence digests, unchanged tested implementation, final
governor-transition assessment and fresh complete-candidate source qualification.
Source qualification is evidence only; the released environment governs the record.

The review commit adds this note, preparation logs and the generated record/evaluator
evidence. It preserves the candidate and its bound evidence. No host update, live
host/service test, release or merge is performed. Required CI must pass before merge.
The existing approval authorizes this draft review and its later decision-only push.
''',encoding='utf-8',newline='\n')
    p.run('review-add',['git','add','--',V,J,E/'verification-preparation.zip',E/'verification-preparation.md'],cwd=R)
    p.run('review-whitespace',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'],cwd=R)
    p.run('review-commit',['git','commit','-m','Prepare exact adoption verification for review','-m','Harness-Work-Order: '+WO],cwd=R)
    assert not git('status','--porcelain')
    h=git('rev-parse','HEAD');(O/'review-head.txt').write_text(h+'\n')
    call('generated-pr-body','pr-body',R,'--artifact',WO,target=True)
    evidence=D+'evidence/'+WO+'/'
    body=f'''## Summary

Adopt public evaluator **0.23.0** in the repository and CI. Advance development source to unpublished **0.23.1** so CI keeps it distinct from the released governor. Update current guidance and its tests against verified 0.23.0 / plugin 0.2.7 delivery receipts.

Harness-Work-Order: WO-HUP-031

## Verification pending

- Exact candidate: `{c}`.
- [Ready VREC-HUP-029](https://github.com/mmzen/se_harness/blob/{h}/{V}).
- [Assessment and limits](https://github.com/mmzen/se_harness/blob/{h}/{evidence}final-assessment.md), [bound results](https://github.com/mmzen/se_harness/blob/{h}/{evidence}results.json), and [actual check outputs](https://github.com/mmzen/se_harness/blob/{h}/{evidence}commands.zip).
- Final full suite: 1,346 tests, 24 skips, exit 0. The 47 affected guidance tests, distribution checks, CLI smoke, released identity/root checks and two matching real upgrade rehearsals pass. Initial failures and corrections are retained.
- All 14,625 checked pre-existing owner, formal, evidence and package files retain their bytes. Schema 5, external resources and integrations stay selected.
- CI is pending at publication. Required checks must pass before merge.

The private service remains on 0.22.1; Git remains authoritative. No host-plugin update or new native-host/service qualification is included. R23-NATIVE-010/011 remain open under DEC-RLS-010 / RISK-RLS-008; Codex Windows desktop remains unverified under DEC-RLS-011 / RISK-RLS-009.

Implementation and review publication are approved. Human verification and merge remain separate; the existing grant includes the later verification-decision push.
'''
    (O/'pr-body.md').write_bytes(body.encode('utf-8'))
    (O/'pr-event.json').write_text(json.dumps({'pull_request':{'body':body}},indent=2)+'\n')
    call('review-check-pr','check-pr',R,'--event',O/'pr-event.json','--from-git',BASE,target=True)
    call('review-pre-action','check',R,'--artifact',VREC,'--checkpoint','pre-action','--procedure','PROC-REVIEW-PUBLISH',target=True)
    assert not git('status','--porcelain')
elif mode=='controls':
    r=p.run('provider-ruleset-detail',['gh','api','repos/mmzen/se_harness/rulesets/20693381'])
    print(json.dumps({k:r[k] for k in ['enforcement','conditions','bypass_actors','rules']}))
    r=p.run('remote-final-before-push',['git','ls-remote',REMOTE,'refs/heads/main','refs/heads/codex/adopt-0-23-0'],cwd=R)
    print(r['stdout'])
elif mode=='push':
    h=(O/'review-head.txt').read_text().strip();assert git('rev-parse','HEAD')==h and not git('status','--porcelain')
    assert git('branch','--show-current')=='codex/adopt-0-23-0'
    assert json.loads((O/'review-check-pr.json').read_text())['exit']==0
    assert json.loads((O/'review-pre-action.json').read_text())['exit']==0
    p.run('review-push',['git','push',REMOTE,h+':refs/heads/codex/adopt-0-23-0'],cwd=R)
    r=p.run('review-pr-create',['gh','pr','create','--repo','mmzen/se_harness','--head','codex/adopt-0-23-0','--base','main','--draft',
        '--title','Adopt public evaluator 0.23.0 and refresh release guidance','--body-file',O/'pr-body.md'])
    print(r['stdout'])
elif mode=='readback':
    h=(O/'review-head.txt').read_text().strip()
    info=p.run('review-pr-readback',['gh','pr','view','codex/adopt-0-23-0','--repo','mmzen/se_harness','--json',
        'number,url,state,headRefOid,headRefName,baseRefName,isDraft,headRepositoryOwner,headRepository,statusCheckRollup'])
    assert info['headRefOid']==h and info['headRefName']=='codex/adopt-0-23-0' and info['baseRefName']=='main' and info['isDraft'] and info['state']=='OPEN'
    assert info['headRepositoryOwner']['login']=='mmzen' and info['headRepository']['name']=='se_harness'
    for label,path in [('record',V),('assessment',D+'evidence/'+WO+'/final-assessment.md'),('results',D+'evidence/'+WO+'/results.json'),('evaluator',J)]:
        r=p.run('remote-'+label,['gh','api','repos/mmzen/se_harness/contents/'+path+'?ref='+h])
        assert r['sha']==git('rev-parse',h+':'+path)
        if r.get('encoding')=='base64':assert base64.b64decode(r['content'])==(R/path).read_bytes()
    print(json.dumps({'url':info['url'],'head':h,'candidate':(O/'candidate.txt').read_text().strip(),'draft':True,'review_bytes_confirmed':True,
        'checks':[{'name':x.get('name',x.get('context')),'status':x.get('status',x.get('state')),'conclusion':x.get('conclusion')} for x in info['statusCheckRollup']]}))
else:raise ValueError(mode)
