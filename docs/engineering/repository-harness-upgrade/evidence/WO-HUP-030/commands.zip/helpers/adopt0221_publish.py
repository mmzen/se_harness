import json,sys,subprocess,base64
from adopt0221_prepare import R,OUT,BASE,run,gov
D='docs/engineering/repository-harness-upgrade/'
E=D+'evidence/WO-HUP-030/'
V=D+'verification-records/VREC-HUP-028.md'
J=D+'evidence/VREC-HUP-028-evaluator.json'
REMOTE='https://github.com/mmzen/se_harness.git'
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
mode=sys.argv[1]
if mode=='prepare':
    C=(OUT/'candidate.txt').read_text().strip()
    assert git('rev-parse','HEAD')==C
    value=(R/V).read_text();assert 'status = "ready"' in value and C in value
    assert set(git('status','--porcelain').splitlines()) # writes must be inspected by the caller
    review=f'''# Verification preparation

VREC-HUP-028 is ready for human review of candidate `{C}` under VER-HUP-025.
The released 0.22.1 evaluator prepared it after the exact committed candidate
check passed. Capture also rechecked the retained input digests and bound the
fresh predecessor assessment for this exact commit. The earlier full-scale
suite and both upgrade rehearsals remain at their original observed identities.
Only this work order's completion and evidence separate that tested implementation
from the captured candidate; no new product or test change is claimed tested.

The review head adds this note, the VREC and its declared evaluator evidence.
It leaves the candidate and bound evidence unchanged. Review publication is
authorized for codex/adopt-0-22-1 targeting main. Verification is pending;
required hosted CI must pass before merge. No merge is authorized.
'''
    (R/E/'verification-preparation.md').write_text(review,encoding='utf-8',newline='\n')
    run('review-add',['git','add','--',V,J,E+'verification-preparation.md'],cwd=R)
    run('review-commit',['git','commit','-m','Prepare commit-bound adoption verification for review','-m','Harness-Work-Order: WO-HUP-030'],cwd=R)
    assert not git('status','--porcelain')
    H=git('rev-parse','HEAD');(OUT/'review-head.txt').write_text(H+'\n')
    gov('generated-pr-body','pr-body','--artifact','WO-HUP-030',target=True)
    body=f'''## Summary

Adopt the exact public evaluator 0.22.1 in the repository and CI. Advance development source to unpublished 0.22.2 so candidate checks keep it distinct from the governing release. Refresh current release and installation guidance against verified public 0.22.1 / plugin 0.2.6 receipts.

Harness-Work-Order: WO-HUP-030

## Verification pending

- Candidate: `{C}`.
- [Ready VREC-HUP-028](https://github.com/mmzen/se_harness/blob/{H}/{V}).
- [Assessment and limitations](https://github.com/mmzen/se_harness/blob/{H}/{E}review.md).
- [Bound results](https://github.com/mmzen/se_harness/blob/{H}/{E}results.json) and [raw checks](https://github.com/mmzen/se_harness/blob/{H}/{E}commands.zip).
- Full source suite: 1,293 tests, 23 reported skips, exit 0. Focused regressions, distribution validation, CLI smoke, released identity/root checks and two identical real upgrade rehearsals pass. Earlier failures and corrections are retained.
- 13,242 checked pre-existing owner/artifact/evidence files retain their exact bytes. Schema 5, external resources and existing integrations remain selected.
- CI is pending at publication; required checks must pass before merge.

Human verification remains pending. Approval already covers this draft review publication and the later decision-only push. HAG pin amendment/decision recording, host-plugin updates and merge remain separate. Codex Windows desktop remains unverified under the prior accepted DEC-RLS-009 / RISK-RLS-007; this adoption makes no new native-host or hosted-service claim.
'''
    (OUT/'pr-body.md').write_text(body,encoding='utf-8',newline='\n')
    (OUT/'pr-event.json').write_text(json.dumps({'pull_request':{'body':body}},indent=2)+'\n')
    gov('review-check-pr','check-pr','--event',str(OUT/'pr-event.json'),'--from-git',BASE,target=True)
    gov('review-pre-action','check','--artifact','VREC-HUP-028','--checkpoint','pre-action','--procedure','PROC-REVIEW-PUBLISH',target=True)
    assert not git('status','--porcelain')
elif mode=='controls':
    run('provider-rules',['gh','api','repos/mmzen/se_harness/rules/branches/main'])
    run('provider-ruleset',['gh','api','repos/mmzen/se_harness/rulesets/20693381'])
    run('existing-review-pr',['gh','pr','list','--repo','mmzen/se_harness','--head','codex/adopt-0-22-1','--state','all','--json','number,url,state,headRefOid,baseRefName,isDraft'])
    run('remote-before-push',['git','ls-remote',REMOTE,'refs/heads/main','refs/heads/codex/adopt-0-22-1'])
elif mode=='push':
    H=(OUT/'review-head.txt').read_text().strip();assert git('rev-parse','HEAD')==H and not git('status','--porcelain')
    assert json.loads((OUT/'review-pre-action.json').read_text())['exit_code']==0
    assert json.loads((OUT/'review-check-pr.json').read_text())['exit_code']==0
    assert git('branch','--show-current')=='codex/adopt-0-22-1'
    run('review-push',['git','push',REMOTE,H+':refs/heads/codex/adopt-0-22-1'],cwd=R)
    run('review-pr-create',['gh','pr','create','--repo','mmzen/se_harness','--head','codex/adopt-0-22-1','--base','main','--draft','--title','Adopt public evaluator 0.22.1 and refresh release guidance','--body-file',OUT/'pr-body.md'])
elif mode=='readback':
    H=(OUT/'review-head.txt').read_text().strip()
    info,_=run('review-pr-readback',['gh','pr','view','codex/adopt-0-22-1','--repo','mmzen/se_harness','--json','number,url,state,headRefOid,headRefName,baseRefName,isDraft,headRepositoryOwner,headRepository,statusCheckRollup'])
    assert info['headRefOid']==H and info['headRefName']=='codex/adopt-0-22-1' and info['baseRefName']=='main' and info['isDraft'] and info['state']=='OPEN'
    for label,path in [('record',V),('assessment',E+'review.md'),('results',E+'results.json'),('evaluator-evidence',J)]:
        j,_=run('remote-'+label,['gh','api','repos/mmzen/se_harness/contents/'+path+'?ref='+H])
        assert j['sha']==git('rev-parse',H+':'+path)
        if j.get('encoding')=='base64':assert base64.b64decode(j['content'])==(R/path).read_bytes()
    print(json.dumps({'url':info['url'],'head':H,'candidate':(OUT/'candidate.txt').read_text().strip(),'draft':True,'review_bytes_confirmed':True}))
