import json,sys,subprocess,tarfile,hashlib,os,tempfile
from adopt0221_prepare import R,OUT,BASE,TARGET,WHEEL,run,gov
import r221_session as s
P=OUT/'candidate-env/Scripts/python.exe'
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
mode=sys.argv[1]
if mode=='commit':
    paths=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
    allowed=json.loads((OUT/'planned-paths.json').read_text())
    assert all(p in allowed or any(x.endswith('/') and p.startswith(x) for x in allowed) for p in paths),paths
    run('implementation-add',['git','add','--',*paths],cwd=R)
    run('implementation-whitespace',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'],cwd=R)
    run('implementation-commit',['git','commit','-m','Adopt public evaluator 0.22.1 and refresh current guidance','-m','Harness-Work-Order: WO-HUP-030'],cwd=R)
    (OUT/'implementation-commit.txt').write_text(git('rev-parse','HEAD')+'\n')
elif mode=='commit-finish':
    run('implementation-index-correction',['git','add','--','docs/engineering/README.md'],cwd=R)
    run('implementation-whitespace-corrected',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'],cwd=R)
    run('implementation-commit',['git','commit','-m','Adopt public evaluator 0.22.1 and refresh current guidance','-m','Harness-Work-Order: WO-HUP-030'],cwd=R)
    (OUT/'implementation-commit.txt').write_text(git('rev-parse','HEAD')+'\n')
elif mode=='build':
    C=(OUT/'implementation-commit.txt').read_text().strip();assert git('rev-parse','HEAD')==C
    export=OUT/'candidate-export';export.mkdir()
    run('candidate-export',['git','archive','--format=tar','--output',OUT/'candidate-source.tar',C],cwd=R)
    with tarfile.open(OUT/'candidate-source.tar') as t:t.extractall(export,filter='data')
    run('candidate-wheel',[s.PYTHON,'-m','pip','wheel','--disable-pip-version-check','--no-deps','--wheel-dir',OUT/'candidate-dist',export])
    run('candidate-environment',[s.PYTHON,'-m','venv',P.parent.parent])
    wheel=OUT/'candidate-dist/se_harness-0.22.2-py3-none-any.whl';assert wheel.is_file()
    run('candidate-install',[P,'-m','pip','install','--disable-pip-version-check','--no-index','--no-deps',wheel])
    run('candidate-identity',[P,'-I','-m','se_harness','identity','--role','candidate-package','--expected-version','0.22.2','--expected-root',P.parent.parent,'--checkout-root',R,'--candidate-commit',C,'--require-isolated-python','--json'])
    (OUT/'candidate-wheel-binding.json').write_text(json.dumps({'commit':C,'version':'0.22.2','wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'purpose':'Local non-promotable CI rehearsal input only; no publication.'},indent=2)+'\n')
elif mode=='rehearse':
    assert P.is_file()
    for i in (1,2):
        run('actual-rehearsal-'+str(i),[s.PYTHON,'-B','-m','repository_tools.upgrade_rehearsal','--repository',R,'--predecessor-python',TARGET,'--successor-python',P,'--output',OUT/('upgrade-'+str(i)),'--workspace',s.WORK,'--timings'],cwd=R)
    a=json.loads((OUT/'upgrade-1/upgrade-rehearsal-result.json').read_text());b=json.loads((OUT/'upgrade-2/upgrade-rehearsal-result.json').read_text())
    assert a['overall_result']==b['overall_result']=='pass' and a['semantic_sha256']==b['semantic_sha256']
    print('Both real upgrade rehearsals passed with identical semantic digests.')
elif mode=='assess':
    run('governor-transition',[s.PYTHON,'-S',R/'scripts/validate_governor_transition.py','assess','--repository',R,'--base-revision',BASE,'--default-branch-ref','refs/remotes/github/main','--evaluator-python',TARGET,'--evaluator-entry-point',TARGET.parent/'harnessctl.exe','--evaluator-wheel',WHEEL,'--output',OUT/'transition-result.json','--json'])
elif mode=='rehearse-recovery':
    # Process-local Git option for disposable repositories; no global setting.
    settings={'GIT_CONFIG_COUNT':'1','GIT_CONFIG_KEY_0':'core.longpaths','GIT_CONFIG_VALUE_0':'true'}
    os.environ.update(settings)
    (OUT/'rehearsal-environment.json').write_text(json.dumps({'environment':settings,'workspace':tempfile.gettempdir(),'reason':'The first scratch export failed Windows Git path length checks; no product code changed.'},indent=2)+'\n')
    for i in (1,2):
        run('actual-rehearsal-corrected-'+str(i),[s.PYTHON,'-B','-m','repository_tools.upgrade_rehearsal','--repository',R,'--predecessor-python',TARGET,'--successor-python',P,'--output',OUT/('upgrade-corrected-'+str(i)),'--workspace',tempfile.gettempdir(),'--timings'],cwd=R)
    a=json.loads((OUT/'upgrade-corrected-1/upgrade-rehearsal-result.json').read_text());b=json.loads((OUT/'upgrade-corrected-2/upgrade-rehearsal-result.json').read_text())
    assert a['overall_result']==b['overall_result']=='pass' and a['semantic_sha256']==b['semantic_sha256']
    print('Both corrected real upgrade rehearsals passed with identical semantic digests.')
