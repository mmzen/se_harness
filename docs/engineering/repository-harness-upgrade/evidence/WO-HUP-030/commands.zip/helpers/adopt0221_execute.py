"""Apply the reviewed adoption package under mmzen's explicit approval."""
import hashlib,json,subprocess,sys,tomllib
from adopt0221_prepare import R,OUT,BASE,TARGET,run,gov
import r221_session as s
D='docs/engineering/repository-harness-upgrade/'
W=D+'work-orders/WO-HUP-030.md'
V=D+'verification/VER-HUP-025.md'
bind=json.loads((OUT/'review-binding.json').read_text())
reason=('Human mmzen answered "Approve package, verification and review PR" to the exact '
        'WO-HUP-030 / VER-HUP-025 review: public evaluator 0.22.1 adoption, unpublished '
        'source 0.22.2, named CI/documentation/test updates, required commit-bound '
        'verification and ordinary review pushes/draft PR from codex/adopt-0-22-1 '
        'to mmzen/se_harness:main, including the later recorded verification decision. '
        'Human verification acceptance, merge, host-plugin updates and HAG contract '
        'amendment remain separate. Reviewed bytes matched; only confirmed assurance '
        'fields were added before preview. Reviewed SHA-256 ')
def record(p):return tomllib.loads((R/p).read_text().split('+++',2)[1])
def approval_args():
    args=['transition']
    for p,aid in [(V,'VER-HUP-025'),(W,'WO-HUP-030')]:
        args += ['--set',aid+'=approved','--decision',aid+'=mmzen','--reason',aid+'='+reason+bind['reviewed_drafts'][p]+'.']
    return args
mode=sys.argv[1]
if mode=='preview':
    for p,digest in bind['reviewed_drafts'].items():assert hashlib.sha256((R/p).read_bytes()).hexdigest()==digest
    text=(R/W).read_text();assert '[assurance]' not in text
    text=text.replace('[execution_scope]', '[assurance]\ncommit_bound_verification = "required"\nrationale = "mmzen confirmed required commit-bound verification because later engineering and release decisions rely on the evaluator selection, CI pin, source boundary and adoption guidance."\ndecided_by = "mmzen"\n\n[execution_scope]',1)
    (R/W).write_text(text,encoding='utf-8',newline='\n')
    (OUT/'approval-apply-binding.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in (W,V)},indent=2)+'\n')
    gov('approval-preview',*approval_args())
elif mode=='approve':
    for p,digest in json.loads((OUT/'approval-apply-binding.json').read_text()).items():assert hashlib.sha256((R/p).read_bytes()).hexdigest()==digest
    gov('approval-apply',*approval_args(),'--apply')
    assert all(record(p)['status']=='approved' for p in (W,V))
    gov('approved-context','check','--artifact','WO-HUP-030')
    gov('start-preflight','preflight','--work-order','WO-HUP-030','--phase','start')
    gov('start-preview','transition','--set','WO-HUP-030=in_progress','--decision','WO-HUP-030=Codex')
elif mode=='start':
    assert record(W)['status']=='approved'
    gov('start-apply','transition','--set','WO-HUP-030=in_progress','--decision','WO-HUP-030=Codex','--apply')
    gov('started-context','check','--artifact','WO-HUP-030')
    args=['check','--artifact','WO-HUP-030','--checkpoint','scope','--changes-complete']
    for p in json.loads((OUT/'planned-paths.json').read_text()):
        if not p.endswith('/'):args += ['--changed-path',p]
    gov('implementation-scope',*args)
    run('approval-commit-stage',['git','add','--',W,V],cwd=R)
    run('approval-commit',['git','commit','-m','Approve bounded 0.22.1 adoption package','-m','Harness-Work-Order: WO-HUP-030'],cwd=R)
elif mode=='upgrade':
    assert record(W)['status']=='in_progress'
    assert 'tool_version = "0.22.0"' in (R/'.engineering-harness.toml').read_text()
    gov('approved-upgrade-preview','upgrade',target=True)
elif mode=='apply-upgrade':
    assert record(W)['status']=='in_progress'
    gov('adoption-apply','upgrade','--evidence-output',D+'evidence/WO-HUP-030-evaluator-upgrade.json','--apply',target=True)
    gov('adoption-doctor','doctor',target=True)
    run('adoption-root',[TARGET,'-I','-m','se_harness','qualify','released-root',R,'--json'])
    gov('adoption-repeat','upgrade',target=True)
    run('adoption-activation',[s.PYTHON,'-I',r'C:\Users\mathi\.codex\plugins\cache\se-harness\verity-plane\0.2.5\scripts\activate.py','--host','codex','--session-id','01a0bd7b-24c7-7503-8955-4a24231fb2a4','--data-root',r'C:\Users\mathi\.codex\plugins\data\verity-plane-se-harness','--target',R])
