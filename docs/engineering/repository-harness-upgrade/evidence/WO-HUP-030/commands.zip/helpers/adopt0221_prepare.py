"""Transient adoption preparation; no real upgrade apply or lifecycle approval."""
import datetime, hashlib, json, subprocess, sys
from pathlib import Path
import r221_session as s

R=s.WORK/'r221p'
OUT=s.WORK/'adopt0221-preparation-20261005'
OUT.mkdir(exist_ok=True)
TARGET=Path(r'C:\Users\mathi\.codex\plugins\data\verity-plane-se-harness\evaluators\0.22.1\cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053\Scripts\python.exe')
WHEEL=s.WORK/'r221-delivery-corrected-20261005/evaluator-public/pypi/se_harness-0.22.1-py3-none-any.whl'
BASE='00708eb1000020cf4b1672ffe9bfc684b0c6d51c'

def run(name,args,cwd=s.WORK,allow=(0,)):
    dest=OUT/(name+'.json'); assert not dest.exists(),dest
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=subprocess.run([str(x) for x in args],cwd=cwd,capture_output=True,text=True,encoding='utf-8',timeout=900)
    data={'argv':[str(x) for x in args],'cwd':str(cwd),'observed_at':start,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
    dest.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
    try:j=json.loads(p.stdout)
    except ValueError:j={}
    if isinstance(j,dict):
        compact={k:v for k,v in j.items() if k in ('operation','outcome','status','allocated_id','path','file','files','changes','state','restitution','error_count','warning_count','errors','scope','writes','checks')}
    else:compact={}
    print(json.dumps({'name':name,'exit':p.returncode,'record':str(dest),'result':compact or p.stdout[-1600:],'stderr':p.stderr[-600:]}),flush=True)
    assert p.returncode in allow,(name,p.returncode)
    return j,p

def gov(name,*args,target=False,repo=R,allow=(0,)):
    return run(name,[TARGET if target else s.GOV,'-I','-m','se_harness',args[0],repo,*args[1:],'--json'],allow=allow)

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='inspect':
        assert hashlib.sha256(WHEEL.read_bytes()).hexdigest()=='cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053'
        run('target-upgrade-help',[TARGET,'-I','-m','se_harness','upgrade','--help'])
        gov('target-doctor-before','doctor',target=True,allow=(0,1))
        gov('target-upgrade-preview','upgrade',target=True)
        gov('current-hag-context','check','--artifact','WO-HAG-001')
        for typ in ('work_order','verification'):
            gov('allocate-'+typ,'create-artifact','--domain','repository-harness-upgrade','--type',typ,'--dry-run')
    elif mode=='create':
        typ,aid=sys.argv[2:]
        gov('create-'+aid,'create-artifact','--domain','repository-harness-upgrade','--type',typ,'--id',aid)
        files=list((R/'docs/engineering/repository-harness-upgrade').rglob(aid+'.md'))
        assert len(files)==1
        print(files[0].read_text(encoding='utf-8'))
    elif mode=='validate':
        gov('draft-validation-complete','validate')
        paths=json.loads((OUT/'planned-paths.json').read_text())
        paths=[p for p in paths if not p.endswith('/')]
        paths += ['docs/engineering/repository-harness-upgrade/evidence/WO-HUP-030/'+p for p in ['review.md','results.json','commands.zip','handoff.json','WO-HUP-030-handoff.md']]
        args=['check','--artifact','WO-HUP-030']
        for p in paths:args += ['--planned-path',p]
        gov('draft-planned-scope',*args)
    elif mode=='rehearse':
        scratch=s.WORK/'adopt0221-rehearsal'
        assert not scratch.exists()
        run('rehearsal-clone',['git','clone','--no-hardlinks','--no-checkout',R,scratch])
        run('rehearsal-checkout',['git','-c','core.autocrlf=false','-c','core.longpaths=true','checkout','--detach',BASE],cwd=scratch)
        run('rehearsal-autocrlf',['git','config','core.autocrlf','false'],cwd=scratch)
        run('rehearsal-longpaths',['git','config','core.longpaths','true'],cwd=scratch)
        before={p:hashlib.sha256((scratch/p).read_bytes()).hexdigest() for p in ['AGENTS.md','.gitattributes','.github/PULL_REQUEST_TEMPLATE.md','.github/workflows/engineering-harness.yml','.gitignore']}
        gov('rehearsal-upgrade','upgrade','--evidence-output','docs/engineering/repository-harness-upgrade/evidence/WO-HUP-030-evaluator-upgrade.json','--apply',target=True,repo=scratch)
        gov('rehearsal-doctor','doctor',target=True,repo=scratch)
        run('rehearsal-root',[TARGET,'-I','-m','se_harness','qualify','released-root',scratch,'--json'])
    elif mode=='finish-rehearsal':
        scratch=s.WORK/'adopt0221-rehearsal'
        assert 'tool_version = "0.22.1"' in (scratch/'.engineering-harness.toml').read_text()
        before={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in ['AGENTS.md','.gitattributes','.github/PULL_REQUEST_TEMPLATE.md','.github/workflows/engineering-harness.yml','.gitignore']}
        run('rehearsal-root-corrected',[TARGET,'-I','-m','se_harness','qualify','released-root',scratch,'--json'])
        gov('rehearsal-repeat','upgrade',target=True,repo=scratch)
        _,result=run('rehearsal-change-list',['git','diff','--name-only'],cwd=scratch)
        assert set(result.stdout.splitlines())=={'.engineering-harness.toml','.engineering-harness.lock'}
        assert before=={p:hashlib.sha256((scratch/p).read_bytes()).hexdigest() for p in before}
        for name,old,new in [('pyproject.toml','version = "0.22.1"','version = "0.22.2"'),('se_harness/__init__.py','__version__ = "0.22.1"','__version__ = "0.22.2"')]:
            p=scratch/name;value=p.read_text(encoding='utf-8');assert value.count(old)==1;p.write_text(value.replace(old,new),encoding='utf-8',newline='\n')
        run('rehearsal-evaluator-facts',[s.PYTHON,'-B','-X','utf8','-m','repository_tools.evaluator_facts','derive','--repository',scratch,'--json'],cwd=scratch)
        (OUT/'rehearsal-owner-preservation.json').write_text(json.dumps({'before':before,'after':before,'scope':'Disposable planning rehearsal only; selected repository remains 0.22.0.'},indent=2)+'\n')
