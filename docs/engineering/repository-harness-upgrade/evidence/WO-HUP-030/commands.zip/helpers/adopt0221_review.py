"""Build the transient human review from observed preparation results."""
import hashlib,json
from adopt0221_prepare import R,OUT,BASE

D='docs/engineering/repository-harness-upgrade/'
def result(name):return json.loads(json.loads((OUT/(name+'.json')).read_text())['stdout'])
validation=result('draft-validation-complete')
scope=result('draft-planned-scope')['scope']['preparation']
assert validation['error_count']==0 and scope['coverage']=='covered' and not scope['uncovered_paths']
files=[D+'work-orders/WO-HUP-030.md',D+'verification/VER-HUP-025.md']
hashes={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in files}
(OUT/'review-binding.json').write_text(json.dumps({'base':BASE,'branch':'codex/adopt-0-22-1','reviewed_drafts':hashes},indent=2)+'\n',encoding='utf-8')
review=f'''# Adopt evaluator 0.22.1 — approval review

## Decision requested

Approve **WO-HUP-030** and **VER-HUP-025**, including required commit-bound
verification and the bounded review push/PR from `codex/adopt-0-22-1` to
`mmzen/se_harness:main`. Your instruction "Go adopt" supplies the adoption
direction. This review adds its exact scope, source increment and assurance.

## Outcome and scope

- Select the public 0.22.1 wheel from RLS-SEH-033 in the repository and CI.
- The installer updates only `.engineering-harness.toml` and `.engineering-harness.lock`.
- Advance development source to **0.22.2**, unpublished, to avoid PRE008.
- Refresh the eleven named current documents and the existing public-guidance
  test's independently sourced expectations. Keep historical records intact.
- Run checks, retain the transaction and evidence, and publish the ready
  verification package before requesting your separate acceptance.

No host-plugin update, public release, provider change, merge, hosted-service
verification or HAG contract amendment is included. Existing Codex Windows
desktop omissions are unchanged. Formal verification and merge remain separate.

## Already checked

| Observation | Result |
| --- | --- |
| Exact public wheel SHA-256 | `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053` |
| Target payload | `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff` |
| Draft validation, governor 0.22.0 | Zero errors; 63 pre-existing warnings |
| Planned file coverage | {len(scope['planned_paths'])} concrete paths covered; zero uncovered or invalid declarations |
| Disposable upgrade | Only configuration and lock changed |
| Disposable doctor / released-root qualification | Pass; 1,958 artifacts, zero errors |
| Repeated upgrade | No changed paths |
| Owner/integration files | AGENTS.md and four retained integration files byte-identical |
| Rehearsed source/evaluator pair | 0.22.2 / public 0.22.1; evaluator-facts derivation passes |

These are planning observations, not final implementation assurance. The selected
checkout remains 0.22.0. Only the two draft artifacts have been added there.
The private 0.22.1 evaluator is prepared beside 0.22.0. No full implementation
suite or new native-host qualification is claimed.

The initial draft validation refused an unconfirmed assurance table; it was
removed and its classification remains a prose proposal. One qualification
invocation used the wrong argument order; the corrected released command passed.
Both original results remain retained outside the repository.

## Reviewed artifacts

- [WO-HUP-030]({(R/files[0]).as_posix()})
- [VER-HUP-025]({(R/files[1]).as_posix()})

Base: `{BASE}`. Complete reviewed byte digests are in `review-binding.json`
beside this transient review. The work order lists all exact paths and limits.

## Why a package decision is still needed

The installed DRAFT_WORK_ORDERS procedure requires the human to confirm the
assurance classification and says: "Preparation does not approve or start
execution." AUTHORITY requires matching reviewed inputs for each decision.
This request covers the new work order, CI/source/docs scope, required assurance
and review publication together; it does not repeat the release decision.

## HAG follow-up remains visible

Adoption alone does not change SPEC-HAG-003 or VER-HAG-001, which still select
0.22.0 for the hosted service and its oracle. Both 0.22.0 and 0.22.1's released
AMEND_DEFINITIONS procedure explicitly lack a supported command/relation for
activating a linked revision. The exact pin replacement and affected links must
be reviewed before a supported amendment or a bounded manual exception.

DEC-HAG-001 retains your known `extend-evaluator` choice as an unapplied
decision. The new released decision command can record it with the correct
human ownership binding after adoption and the remaining authority checks.
WO-HAG-001 and PR #535 keep their current state, branch and target.
'''
(OUT/'review.md').write_text(review,encoding='utf-8',newline='\n')
print(json.dumps({'review':str(OUT/'review.md'),'hashes':hashes,'coverage':scope['coverage']}))
