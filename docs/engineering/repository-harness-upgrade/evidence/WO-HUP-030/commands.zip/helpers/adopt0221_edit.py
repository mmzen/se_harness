"""Bounded owner edits for approved WO-HUP-030; no formal-history edits."""
from adopt0221_prepare import R

def edit(path, pairs):
    p=R/path
    raw=p.read_bytes().decode('utf-8'); nl='\r\n' if '\r\n' in raw else '\n'
    text=raw.replace('\r\n','\n')
    for old,new in pairs:
        assert old in text,(path,old)
        text=text.replace(old,new)
    p.write_bytes(text.replace('\n',nl).encode('utf-8'))

edit('.github/workflows/engineering-harness.yml', [('SE_HARNESS_VERSION: "0.22.0"','SE_HARNESS_VERSION: "0.22.1"')])
edit('pyproject.toml',[('version = "0.22.1"','version = "0.22.2"')])
edit('se_harness/__init__.py',[('__version__ = "0.22.1"','__version__ = "0.22.2"')])
edit('README.md',[
('Observed public delivery (2026-10-03): Plugin **0.2.5** bundles released **SE Harness 0.22.0**. Codex CLI fresh installation, update from 0.2.4 and offline setup passed. [Public evidence](docs/engineering/release-0-22-0/evidence/WO-RLS-036/README.md) records exact identities and limits.',
 'Observed public delivery (2026-10-05): Plugin **0.2.6** bundles released **SE Harness 0.22.1**. On Windows, Codex and Claude Code CLI fresh installation, update from 0.2.5 and offline setup passed. [Public evidence](docs/engineering/release-0-22-1/evidence/WO-RLS-042/closeout-assessment.md) records exact identities and limits. Codex Windows desktop remains unverified under accepted DEC-RLS-009 / RISK-RLS-007.'),
('[Claude follow-up](docs/engineering/release-0-22-0/', 'Historical 0.22.0 [Claude follow-up](docs/engineering/release-0-22-0/'),
('distinguish authorization and availability. Qualification is not publication.\nRepository evaluator: 0.22.0.\nDelivery excludes adoption and hosted-service verification.',
 'record completed public delivery, separately verified in\n[VREC-RLS-004](docs/engineering/release-0-22-1/verification-records/VREC-RLS-004.md).\nRepository evaluator: 0.22.1, adopted under\n[WO-HUP-030](docs/engineering/repository-harness-upgrade/work-orders/WO-HUP-030.md).\nDevelopment source is unpublished 0.22.2. The hosted-service contract remains\npinned to 0.22.0; its amendment and verification are separate.')])
edit('docs/engineering/README.md',[
('## Product and governance domains\n','## Product and governance domains\n\n- [release-0-22-1/](release-0-22-1/README.md): published evaluator 0.22.1 and plugin 0.2.6;\n  [verified public delivery](release-0-22-1/verification-records/VREC-RLS-004.md) covers the five surfaces.\n- [Repository adoption](repository-harness-upgrade/README.md): WO-HUP-030 selects 0.22.1; development source is unpublished 0.22.2.\n'),
('\n- [Release 0.22.1 / plugin 0.2.6 preparation](release-0-22-1/README.md): approved qualification scope; publication and adoption remain pending.\n','\n')])
edit('docs/engineering/self-hosting-boundary/SELF_HOSTING.md',[
('pinned to 0.22.0 under WO-HUP-028','pinned to 0.22.1 under WO-HUP-030'),
('selected 0.22.0 wheel resources','selected 0.22.1 wheel resources')])
edit('docs/engineering/repository-harness-upgrade/README.md',[
('## Current adoption: 0.22.0', '''## Current adoption: 0.22.1

[WO-HUP-030](work-orders/WO-HUP-030.md) adopts the exact public wheel bound by
RLS-SEH-033 under [VER-HUP-025](verification/VER-HUP-025.md). The installer
updates only the configuration and lock. CI selects 0.22.1; development source
advances to unpublished 0.22.2. Owner content, external resources, integrations
and historical artifacts stay intact. No instruction copies are recreated.

See the [transaction](evidence/WO-HUP-030-evaluator-upgrade.json) and
[adoption review](evidence/WO-HUP-030/review.md). Human verification and merge
remain separate. This adoption does not update the host plugin or amend the
hosted-service contract, which still pins 0.22.0.

## Previous adoption: 0.22.0''')])
edit('docs/engineering/release-0-22-1/README.md',[
('# Proposed evaluator 0.22.1 and plugin 0.2.6 release','# Evaluator 0.22.1 and plugin 0.2.6 release'),
('Status: **VREC-SEH-033 verified by mmzen; RLS-SEH-033 ready. Complete-release review remains in preparation.**',
 'Status: **RLS-SEH-033 released; all five public delivery surfaces complete.**\n[VREC-RLS-004](verification-records/VREC-RLS-004.md) records mmzen\'s verification of the [public observations](evidence/WO-RLS-042/closeout-assessment.md), merged through PR #539.\nRepository adoption now proceeds separately under [WO-HUP-030](../repository-harness-upgrade/work-orders/WO-HUP-030.md).'),
('The PR remains draft. [RLS-SEH-033](releases/RLS-SEH-033.md) is ready and bound','At the preparation checkpoint, [RLS-SEH-033](releases/RLS-SEH-033.md) was ready and bound'),
('now presents the exact plan, readiness, destinations and recovery boundaries.\nRLS-SEH-033 remains ready until mmzen makes that single release decision.\nRequired public observations occur afterward and are never inferred from this\npreparation. The release request covers all listed external actions, including\nprotected integration and bounded receipt PRs; adoption remains separate.',
 'retains the exact plan, readiness, destinations and recovery boundaries reviewed\nby mmzen. The recorded complete-release decision authorized its listed external\nactions. The [delivery result](evidence/WO-RLS-042/delivery-result.json) and\n[public assessment](evidence/WO-RLS-042/closeout-assessment.md) record completion,\nincluding marketplace, Pages and latest/last. Adoption remains separate.'),
('not an authenticated PyPI read by the agent. No release was dispatched.',
 'not an authenticated PyPI read by the agent. No release was dispatched during\nthat configuration step; later publication is retained in the delivery evidence.'),
('The current governor remains released 0.22.0.', 'The release was prepared under released 0.22.0. Repository adoption under\nWO-HUP-030 now selects released 0.22.1.'),
('After delivery, prepare explicit adoption and preserved linked revisions of\nSPEC-HAG-003 and VER-HAG-001. Then use the adopted released decision command to',
 'Repository adoption is covered by WO-HUP-030. Preserved linked revisions of\nSPEC-HAG-003 and VER-HAG-001 still need separate review and authority.\nAfter that boundary is resolved, use the adopted released decision command to')])
edit('docs/notes/developing-se-harness.md',[
('Development source in this checkout reports 0.22.1; it is not published by this adoption. Exact public 0.22.0 is bound by RLS-SEH-032.', 'Development source in this checkout reports 0.22.2; it is not published by this adoption. Exact public 0.22.1 is bound by RLS-SEH-033.'),
('independently installed public 0.22.0, adopted under `WO-HUP-028`','independently installed public 0.22.1, adopted under `WO-HUP-030`'),
('Verity Plane plugin. Public plugin 0.2.5 bundles evaluator 0.22.0 at marketplace\ncommit `7d30907f15bd7e06fb632e1ebf4e88e01b68726c`. Publication does not update a user\'s local\nplugin or a repository\'s evaluator. WO-HUP-028 selects 0.22.0 here.\n[Current public observations](../engineering/release-0-22-0/evidence/WO-RLS-036/README.md)\nrecord Codex CLI routes and the explicitly untested Claude and desktop surfaces.',
 'Verity Plane plugin. Public plugin 0.2.6 bundles evaluator 0.22.1 at marketplace\ncommit `85ae003769f53908addbdcf46c820a8af530ac24`. Publication does not update a user\'s local\nplugin or a repository\'s evaluator. WO-HUP-030 selects 0.22.1 here.\n[Current public observations](../engineering/release-0-22-1/evidence/WO-RLS-042/closeout-assessment.md)\nrecord Windows Codex and Claude Code CLI fresh/update routes and offline setup.\nCodex Windows desktop remains unverified under DEC-RLS-009 / RISK-RLS-007;\nthese public-route observations do not claim new live model-session tests.'),
('The [0.22.1 / plugin 0.2.6 preparation](../engineering/release-0-22-1/README.md)\nuses the complete-release route. Candidate qualification, exact final approval\nand public delivery are separate observed stages. Public latest remains 0.22.0;\nrepository adoption and the hosted evaluator pin are unchanged.',
 'The [0.22.1 / plugin 0.2.6 release](../engineering/release-0-22-1/README.md)\ncompleted the complete-release route. Candidate qualification, final approval\nand public delivery have separate records. Public latest is 0.22.1.\nWO-HUP-030 adopts that evaluator; the hosted-service contract still pins 0.22.0.'),
('The selected 0.22.0 evaluator applies these checks after the authorized `WO-HUP-028` adoption.', 'The selected 0.22.1 evaluator applies these checks after the authorized `WO-HUP-030` adoption.'),
('WO-HUP-028 selects public 0.22.0 from RLS-SEH-032', 'WO-HUP-030 selects public 0.22.1 from RLS-SEH-033'),
('0.22.1 so candidate qualification remains distinct', '0.22.2 so candidate qualification remains distinct'),
('selected public 0.22.0 evaluator after the authorized `WO-HUP-028` adoption.', 'selected public 0.22.1 evaluator after the authorized `WO-HUP-030` adoption.')])
edit('docs/notes/harness-installation-and-upgrades.md',[
('SE Harness 0.22.0 and plugin 0.2.5 are public.', 'SE Harness 0.22.1 and plugin 0.2.6 are public.'),
('released evaluator 0.22.0 under WO-HUP-028','released evaluator 0.22.1 under WO-HUP-030'),
('This repository adopts 0.22.0 under WO-HUP-028 after 0.21.0 under WO-HUP-003,','This repository adopts 0.22.1 under WO-HUP-030 after 0.22.0 under WO-HUP-028,\n0.21.0 under WO-HUP-003,'),
('advances to unpublished 0.22.1;', 'advances to unpublished 0.22.2;')])
edit('docs/notes/release-delivery-completion.md',[
('The [approved 0.22.0 / 0.2.5 release]', 'The historical [approved 0.22.0 / 0.2.5 release]'),
('uses selected evaluator 0.21.0 and the existing delivery route. Subsequent\nadoption and the reviewed provider configuration activate the new route below.',
 'used selected evaluator 0.21.0 and the existing delivery route. Later adoption\nand reviewed provider configuration enabled the complete-release route used by\n[0.22.1 / 0.2.6](../engineering/release-0-22-1/README.md).'),
('repository selects 0.22.0 under WO-HUP-028. Apply the separately reviewed\nprovider configuration before offering the complete-release route as ready. Existing releases keep their original decisions and procedures.',
 'repository selects 0.22.1 under WO-HUP-030. The separately authorized\n[provider configuration](../engineering/release-0-22-1/evidence/WO-RLS-040/provider-configuration-applied.json)\nwas applied for 0.22.1. Recheck provider controls before each release.\nExisting releases keep their original decisions and procedures.'),
('## Current 0.22.0 delivery', '''## Current 0.22.1 delivery

Evaluator 0.22.1 and plugin 0.2.6 are public. The marketplace commit is
`85ae003769f53908addbdcf46c820a8af530ac24`. The
[delivery result](../engineering/release-0-22-1/evidence/WO-RLS-042/delivery-result.json)
records all five surfaces complete, including Pages, latest v0.22.1 and last at
the released candidate. [VREC-RLS-004](../engineering/release-0-22-1/verification-records/VREC-RLS-004.md)
records mmzen's verification of those observations.

Windows Codex and Claude Code CLI fresh installation, update from 0.2.5 and
offline setup passed. Codex Windows desktop remains unverified under accepted
DEC-RLS-009 / RISK-RLS-007. These public routes do not claim live model-session
or hosted-service tests. Repository adoption is separate under WO-HUP-030.

## Historical 0.22.0 delivery''')])
edit('docs/notes/plugin-installation-guide.md',[
('Codex and Claude CLI checks passed; public fresh/update results are separate.',
 'Codex and Claude CLI checks passed. The separately retained public observations\nconfirm Windows fresh installation, update from 0.2.5, installed package bytes\nand offline setup for both hosts. [VREC-RLS-004](../engineering/release-0-22-1/verification-records/VREC-RLS-004.md)\nrecords mmzen\'s verification of those results. They do not claim a desktop or\nnew live model-session test.')])
edit('docs/notes/plugin-marketplace-publication.md',[
('records publication and public-route results separately. Read those records',
 'records completed publication and public-route results separately.\n[VREC-RLS-004](../engineering/release-0-22-1/verification-records/VREC-RLS-004.md)\nrecords mmzen\'s verification of those observations. Read those records'),
('The repository now selects 0.22.0.', 'The repository now selects 0.22.1 under WO-HUP-030.')])
edit('docs/notes/harnessctl-reference.md',[
('available in the governing 0.21.0 evaluator and published 0.22.0', 'available since 0.21.0 and in the selected released 0.22.1 evaluator'),
('Released 0.21.0 and 0.22.0 provide this command for repositories selecting the\n`released-resources-v1` layout. This repository uses its independently installed\n0.21.0 evaluator. Publishing 0.22.0 does not change that selection.',
 'Released evaluators since 0.21.0 provide this command for repositories selecting\nthe `released-resources-v1` layout. This repository uses independently installed\n0.22.1 after explicit adoption under WO-HUP-030. Publication alone does not\nchange a repository\'s selection.')])
print('Updated the 15 approved owner files; public-expectation test remains next.')
