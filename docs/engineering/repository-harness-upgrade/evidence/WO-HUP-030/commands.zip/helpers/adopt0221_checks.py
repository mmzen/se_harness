import sys,json,subprocess,hashlib,re,posixpath
from adopt0221_prepare import R,OUT,BASE,TARGET,WHEEL,run,gov
import r221_session as s
mode=sys.argv[1]
if mode=='focused':
    run('focused-tests',[s.PYTHON,'-B','-X','utf8','-m','unittest','tests.test_ci_pipeline','tests.test_governor_transition','tests.test_predecessor_bootstrap_retirement','tests.test_progressive_documentation','tests.test_public_onboarding','tests.plugin_integration.package_assembly.test_refresh_guidance'],cwd=R)
elif mode=='focused-recovery':
    run('focused-readme-recovery',[s.PYTHON,'-B','-X','utf8','-m','unittest','tests.test_public_onboarding','tests.plugin_integration.package_assembly.test_refresh_guidance'],cwd=R)
elif mode=='full':
    run('full-source',[s.PYTHON,'-B','-X','utf8','scripts/run_tests.py','--scale','full'],cwd=R)
elif mode=='readme-final':
    run('focused-readme-final',[s.PYTHON,'-B','-X','utf8','-m','unittest','tests.test_public_onboarding','tests.plugin_integration.package_assembly.test_refresh_guidance'],cwd=R)
elif mode=='origin-recovery':
    run('origin-before',['git','remote','get-url','origin'],cwd=R)
    run('origin-corrected',['git','remote','set-url','origin','https://github.com/mmzen/se_harness.git'],cwd=R)
    run('origin-readback',['git','remote','get-url','origin'],cwd=R)
    run('dashboard-origin-recovery',[s.PYTHON,'-B','-X','utf8','-m','unittest','tests.test_dashboard_webui.DashboardWebUIContractTests.test_release_proof_fields_reach_the_summary_and_compact_topology'],cwd=R)
    run('full-source-corrected',[s.PYTHON,'-B','-X','utf8','scripts/run_tests.py','--scale','full'],cwd=R)
elif mode=='other':
    run('distribution-check',[s.PYTHON,'-B','-X','utf8','scripts/validate_release_distributions.py','--root','.'],cwd=R)
    run('cli-smoke',[s.PYTHON,'-B','-X','utf8','-m','se_harness','--help'],cwd=R)
    run('evaluator-facts',[s.PYTHON,'-B','-X','utf8','-m','repository_tools.evaluator_facts','derive','--repository',R,'--json'],cwd=R)
elif mode=='identity':
    run('target-identity-complete',[TARGET,'-I','-m','se_harness','identity','--role','released-evaluator','--expected-version','0.22.1','--expected-root',TARGET.parent.parent,'--checkout-root',R,'--evaluator-payload-sha256','0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff','--evaluator-wheel-sha256','cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053','--require-isolated-python','--json'])
    gov('adopted-validation','validate',target=True)
    gov('adopted-entry','resources','--resource','ENGINEERING_HARNESS.md','--content',target=True)
elif mode=='preserve':
    expected=subprocess.check_output(['git','ls-tree','-r','-z',BASE,'--','AGENTS.md','docs/engineering'],cwd=R)
    allowed={'docs/engineering/README.md','docs/engineering/release-0-22-1/README.md','docs/engineering/repository-harness-upgrade/README.md','docs/engineering/self-hosting-boundary/SELF_HOSTING.md'}
    entries=[]
    for row in expected.split(b'\0'):
        if not row:continue
        meta,path=row.decode().split('\t');name=meta.split()[2]
        if path in allowed:continue
        data=(R/path).read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        entries.append({'path':path,'base_blob':name,'current_blob':actual,'equal':name==actual})
    doc={'base':BASE,'excluded_current_indexes':sorted(allowed),'files':entries,'all_equal':all(x['equal'] for x in entries)}
    (OUT/'preservation.json').write_text(json.dumps(doc,indent=2)+'\n')
    print(json.dumps({'files':len(entries),'all_equal':doc['all_equal']}));assert doc['all_equal']
elif mode=='links':
    sys.path.insert(0,str(R))
    from tests.plugin_integration.package_assembly.test_refresh_guidance import link_findings
    paths=subprocess.check_output(['git','diff','--name-only',BASE],cwd=R,text=True).splitlines()
    sources=[p for p in paths if p.endswith('.md') and '/work-orders/' not in p and '/verification/' not in p]
    files={p:(R/p).read_bytes() for p in sources}
    for source in sources:
        for target in re.findall(r'\[[^]]*\]\(([^)]+)\)',files[source].decode()):
            if re.match(r'(?:https?://|mailto:|#)',target):continue
            path=posixpath.normpath(posixpath.join(posixpath.dirname(source),target.split('#')[0]))
            if (R/path).is_file():files[path]=(R/path).read_bytes()
            elif (R/path).is_dir() and '#' not in target:files[path]=b''
    findings=link_findings(files,sources)
    dest=OUT/'changed-links.json'
    if dest.exists():dest.rename(OUT/'changed-links-initial.json')
    dest.write_text(json.dumps({'sources':sources,'findings':findings},indent=2)+'\n');print(json.dumps(findings));assert not findings
