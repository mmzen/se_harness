import json,sys,subprocess,hashlib,zipfile,os
from adopt0221_prepare import R,OUT,BASE,TARGET,WHEEL,run,gov
import r221_session as s
D='docs/engineering/repository-harness-upgrade/'
E=D+'evidence/WO-HUP-030/'
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(name):return json.loads((OUT/(name+'.json')).read_text())
mode=sys.argv[1]
if mode=='retain':
    for name in ('full-source-corrected','focused-readme-final','distribution-check','cli-smoke','evaluator-facts','target-identity-complete','adopted-validation','adopted-entry','adoption-activation','governor-transition','actual-rehearsal-corrected-1','actual-rehearsal-corrected-2'):
        assert load(name)['exit_code']==0,name
    assert load('preservation')['all_equal']
    (R/E).mkdir(exist_ok=True)
    review='''# Review repository adoption of 0.22.1

WO-HUP-030 adopts the exact public evaluator released under RLS-SEH-033.
VER-HUP-025 defines this assessment. Implementation approval does not accept
the result; the prepared VREC and review PR provide the separate human decision.

## Result

- Repository selection and CI now use released **0.22.1**. The installed wheel
  and payload match the approved public identities.
- The installer changed only the configuration and lock. Schema 5, external
  resources and retained integrations remain selected. Repeat upgrade is unchanged.
- Development source is **0.22.2**, unpublished. Version derivation passes
  without PRE008. No new release or host-plugin installation was performed.
- Current guides report actual 0.22.1 / plugin 0.2.6 delivery. Historical records
  and published snapshots keep their bytes and meaning.

## Assessment against VER-HUP-025

| Criterion | Observed result | Retained evidence |
| --- | --- | --- |
| Exact public evaluator | Pass: 0.22.1 wheel and payload match RLS-SEH-033; isolated released identity passes | commands.zip: target-identity-complete.json, adoption-root.json |
| Bounded upgrade and repeat | Pass: two selection-file updates, doctor and root qualification pass; repeat unchanged | Canonical transaction ../WO-HUP-030-evaluator-upgrade.json; commands.zip: adoption-apply.json, adoption-repeat.json |
| Owner and historical preservation | Pass: all 13,242 checked pre-existing files match their original Git blobs; four named current indexes are explicitly excluded | commands.zip: preservation.json |
| CI and development boundary | Pass: governor 0.22.1/source 0.22.2; predecessor assessment passes at the implementation commit | commands.zip: evaluator-facts.json, governor-transition.json |
| Real CI upgrade rehearsal | Pass twice: independent disposable 0.22.1-to-0.22.2 transactions have equal semantic digests | commands.zip: upgrade-corrected-1/ and upgrade-corrected-2/ |
| Regression and distribution | Full suite: 1,293 tests, 23 reported skips, exit 0. Focused checks pass after the corrections below; 23 release-bearing records pass distribution validation; CLI help passes | commands.zip: full-source-corrected.json, focused-tests.json, focused-readme-final.json, distribution-check.json, cli-smoke.json |
| Current guidance | Public claims use independent RLS-SEH-033 and WO-RLS-042 observations. Negative version, digest, public-ref, tree and premature-claim cases remain checked | Test diff and changed-links.json in commands.zip |
| Session selection | Pass: activation and resources return the selected 0.22.1 entry | commands.zip: adoption-activation.json, adopted-entry.json |
| Handoff and exact candidate | Recorded by the generated handoff, lifecycle archive and subsequent VREC | handoff.json, WO-HUP-030-handoff.md, lifecycle.zip, VREC |
| Hosted CI | Pending review publication; required checks must pass before merge | Current PR checks |

## Failures and recovery

The first README revision exceeded its existing 650-word limit; the second was
one word over. The final wording passes without changing the limit. The first
full suite failed the dashboard repository-URL assertion because this local
clone's origin was another filesystem checkout. Origin now names the exact
mmzen/se_harness GitHub repository. The affected test and full suite pass.

The first real upgrade rehearsal failed while Git indexed long Windows scratch
paths. A shorter temporary location and process-local core.longpaths support
resolved that environment failure. Both corrected runs pass; no global Git
setting or product behavior was changed. The initial identity invocation lacked
required arguments, and the staged whitespace check found an extra final blank
line. Corrected commands passed. Original outputs remain in commands.zip.

The broad link check initially treated an existing directory link as a missing
file. The check now accepts existing directories without a heading fragment;
all file and heading checks remain active. No repository link needed changing.

Earlier draft/preparation invocation failures and the pre-adoption version
mismatch remain in the same archive. They are not successful qualification.

## Diff review and limits

This reuses the installer, CI workflow and existing tests. It adds no runtime
mechanism or dependency. The only product-source changes are the two version
fields. The regression uses the existing current-public receipt format and
checks public ref identity against the qualified tree, rather than treating a
staged package as proof of publication.

AGENTS.md and the HAG definitions, work order, decision and evidence retain
their original bytes. SPEC-HAG-003 / VER-HAG-001 still pin 0.22.0. Their amendment
and recording mmzen's known extend-evaluator choice need separate bounded work.
This adoption supplies no hosted-service verification or permission to resume
dependent HAG execution.

Direct activation is a selection check, not a native startup/compaction test.
Codex Windows desktop remains unverified under the prior accepted release-only
DEC-RLS-009 / RISK-RLS-007. No authentication, host-plugin, provider, tag,
marketplace or release changes were made. Human verification and merge remain
separate. The existing grant covers publication of this review and the later
recorded verification decision to codex/adopt-0-22-1 targeting main.
'''
    (R/E/'review.md').write_text(review,encoding='utf-8',newline='\n')
    # The changed-link check includes the newly materialized review destination.
    run('link-check-command-corrected',[s.PYTHON,'-B','-X','utf8',s.WORK/'adopt0221_checks.py','links'])
    with zipfile.ZipFile(R/E/'commands.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.glob('*.json')):z.write(p,p.name)
        for folder in ('upgrade-1','upgrade-corrected-1','upgrade-corrected-2'):
            for p in sorted((OUT/folder).glob('*.json')):z.write(p,folder+'/'+p.name)
        for p in sorted(s.WORK.glob('adopt0221_*.py')):z.write(p,'helpers/'+p.name)
    implementation=(OUT/'implementation-commit.txt').read_text().strip()
    paths=git('diff','--name-only',BASE,implementation).splitlines()
    assessed={p:sha(R/p) for p in paths if '/work-orders/' not in p}
    value={'base':BASE,'implementation_commit':implementation,'assessed_file_sha256':assessed,'commands_sha256':sha(R/E/'commands.zip'),'source_suite':{'tests':1293,'reported_skips':23,'exit_code':0},'preserved_files':13242,'current_index_exclusions':load('preservation')['excluded_current_indexes'],'hosted_ci':'pending PR publication; must pass before merge','limits':'Repository adoption only. No host-plugin, HAG pin/decision, release, deployment or new native host claim.'}
    (R/E/'results.json').write_text(json.dumps(value,indent=2)+'\n')
    gov('review-preflight','preflight','--work-order','WO-HUP-030','--phase','review',target=True)
    gov('handoff-packet','evidence','--artifact','WO-HUP-030','--checkpoint','handoff',target=True)
    gov('handoff-check','check','--artifact','WO-HUP-030','--checkpoint','handoff','--from-git',BASE,target=True)
elif mode=='complete':
    assert load('handoff-check')['exit_code']==0
    args=['transition','--set','WO-HUP-030=implemented','--decision','WO-HUP-030=Codex','--reason','WO-HUP-030=Applied the approved public 0.22.1 adoption, CI/source version and current-guide changes. Required local checks pass, including full regression and two real CI upgrade rehearsals. Historical bytes and HAG records are preserved. Retained failures and corrections remain visible. Completion does not supply human verification or merge authority.']
    gov('completion-preview',*args,target=True)
    gov('completion-apply',*args,'--apply',target=True)
    gov('implemented-context','check','--artifact','WO-HUP-030',target=True)
    with zipfile.ZipFile(R/E/'lifecycle.zip','x',compression=zipfile.ZIP_DEFLATED) as z:
        for name in ('review-preflight','handoff-packet','handoff-check','completion-preview','completion-apply','implemented-context'):
            z.write(OUT/(name+'.json'),name+'.json')
    run('evidence-add',['git','add','--',D+'work-orders/WO-HUP-030.md',E],cwd=R)
    run('evidence-whitespace',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'],cwd=R)
    run('evidence-commit',['git','commit','-m','Retain adoption checks and record implementation completion','-m','Harness-Work-Order: WO-HUP-030'],cwd=R)
    assert not git('status','--porcelain')
    (OUT/'candidate.txt').write_text(git('rev-parse','HEAD')+'\n')
elif mode in ('capture','capture-retry'):
    C=(OUT/'candidate.txt').read_text().strip();assert git('rev-parse','HEAD')==C and not git('status','--porcelain')
    assert not git('log','--all','--format=','--name-only','--','**/VREC-HUP-028.md')
    capture_python=OUT/'capture-source-env/Scripts/python.exe'
    run('capture-source-environment',[s.PYTHON,'-m','venv','--without-pip',capture_python.parent.parent])
    if mode=='capture':
        run('final-governor-transition',[s.PYTHON,'-S',R/'scripts/validate_governor_transition.py','assess','--repository',R,'--base-revision',BASE,'--default-branch-ref','refs/remotes/github/main','--evaluator-python',TARGET,'--evaluator-entry-point',TARGET.parent/'harnessctl.exe','--evaluator-wheel',WHEEL,'--output',OUT/'final-transition-result.json','--json'])
    else:
        gov('capture-recovery-context','check','--artifact','WO-HUP-030',target=True)
        assert not (R/D/'verification-records/VREC-HUP-028.md').exists()
        run('capture-runtime-diagnosis',[s.PYTHON,'-B','-X','utf8','-m','se_harness','qualify','complete-candidate',R,'--candidate-commit',C,'--json'],cwd=R,allow=(1,))
    args=[TARGET,'-I','-m','se_harness','capture-verification',R,'--id','VREC-HUP-028','--work-order','WO-HUP-030','--verification','VER-HUP-025','--owner','Codex','--domain','repository-harness-upgrade','--candidate-commit',C]
    for p in sorted((R/E).iterdir()):
        if p.is_file():args+=['--evidence',p.relative_to(R).as_posix()]
    args+=['--evidence',D+'evidence/WO-HUP-030-evaluator-upgrade.json','--json','--test-command',capture_python,'-B','-X','utf8',s.WORK/'adopt0221_capture_check.py',C,sha(R/E/'results.json'),str(OUT/'final-transition-result.json'),sha(OUT/'final-transition-result.json')]
    os.environ.update({'GIT_CONFIG_COUNT':'1','GIT_CONFIG_KEY_0':'core.longpaths','GIT_CONFIG_VALUE_0':'true'})
    run('verification-capture' if mode=='capture' else 'verification-capture-corrected',args)
    gov('ready-context','check','--artifact','VREC-HUP-028',target=True)
