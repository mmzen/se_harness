"""Check retained tests against exact committed adoption inputs; no authority."""
import sys,json,hashlib,subprocess,zipfile,os
from pathlib import Path
C,expected,transition_path,transition_sha=sys.argv[1:]
R=Path.cwd();E=R/'docs/engineering/repository-harness-upgrade/evidence/WO-HUP-030'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],text=True).strip()
assert git('rev-parse','HEAD')==C and not git('status','--porcelain')
assert sha(E/'results.json')==expected
r=json.loads((E/'results.json').read_text())
for p,digest in r['assessed_file_sha256'].items():assert sha(R/p)==digest,p
changes=git('diff','--name-only',r['implementation_commit'],C).splitlines()
prefix='docs/engineering/repository-harness-upgrade/'
assert all(p==prefix+'work-orders/WO-HUP-030.md' or p.startswith(prefix+'evidence/WO-HUP-030/') for p in changes),changes
assert sha(E/'commands.zip')==r['commands_sha256']
with zipfile.ZipFile(E/'commands.zip') as z:
    for name in ('full-source-corrected','focused-readme-final','distribution-check','cli-smoke','evaluator-facts','target-identity-complete','adopted-validation','adopted-entry','adoption-activation','governor-transition','actual-rehearsal-corrected-1','actual-rehearsal-corrected-2'):
        assert json.loads(z.read(name+'.json'))['exit_code']==0,name
    assert json.loads(z.read('preservation.json'))['all_equal']
    assert not json.loads(z.read('changed-links.json'))['findings']
    a=json.loads(z.read('upgrade-corrected-1/upgrade-rehearsal-result.json'));b=json.loads(z.read('upgrade-corrected-2/upgrade-rehearsal-result.json'))
    assert a['overall_result']==b['overall_result']=='pass' and a['semantic_sha256']==b['semantic_sha256']
t=Path(transition_path);assert sha(t)==transition_sha
tr=json.loads(t.read_text());assert tr['passed'] and tr['target']['commit']==C
env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1');env.pop('PYTHONPATH',None)
argv=[sys.executable,'-B','-X','utf8','-m','se_harness','qualify','complete-candidate','.', '--candidate-commit',C,'--json']
p=subprocess.run(argv,env=env,capture_output=True,text=True,encoding='utf-8',timeout=900)
print(json.dumps({'candidate_commit':C,'retained_results_sha256':expected,'final_transition_sha256':transition_sha,'final_transition':tr,'candidate_check':{'argv':argv,'cwd':str(R),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr},'claim':'Exact committed inputs match the retained full-scale test and two upgrade rehearsal observations. Fresh complete-candidate and exact-candidate predecessor assessment passed only when their observed exits are zero.'}))
assert p.returncode==0
