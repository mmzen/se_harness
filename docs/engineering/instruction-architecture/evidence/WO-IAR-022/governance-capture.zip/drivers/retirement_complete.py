import json,sys
from retirement_tools import REPO,invoke,ROOT
from evolution_cli import LOG
args=['transition',str(REPO)]
for wo in ['WO-IAR-022','WO-IAR-024','WO-IAR-025']:
    args+=['--set',wo+'=implemented','--decision',wo+'=Codex','--reason',wo+'=Codex completed the unchanged approved scope. VER-IAR-017 evidence, full Windows/Linux suites, installed-package checks and combined complete-change handoff pass. Human commit-bound verification remains pending.']
args+=['--json']
if sys.argv[1]=='apply':
    preview=json.loads((LOG/'retirement-completion-preview.stdout').read_text())
    assert preview['compliance']['status']=='pass'
    args+=['--apply']
invoke('retirement-completion-'+sys.argv[1],args)
