import zipfile
from retirement_tools import ROOT,REPO
work=ROOT/'work'
destination=REPO/'docs/engineering/instruction-architecture/evidence/WO-IAR-022/governance-capture.zip'
with zipfile.ZipFile(destination,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted((work/'evolution-evidence').glob('retirement*')):
        if p.is_file():z.writestr('commands/'+p.name,p.read_bytes())
    for p in sorted(work.glob('retirement*.py')):
        z.writestr('drivers/'+p.name,p.read_bytes())
    z.writestr('pull-request-event.json',(work/'retirement-pr-event.json').read_bytes())
print(destination)
