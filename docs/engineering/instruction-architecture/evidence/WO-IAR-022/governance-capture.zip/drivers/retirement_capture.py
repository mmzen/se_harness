import json,subprocess
from retirement_tools import ROOT,REPO,G,invoke
candidate=json.loads((ROOT/'work/retirement-candidate.json').read_text())['commit']
assert subprocess.check_output(G+['rev-parse','HEAD'],text=True).strip()==candidate
assert not subprocess.check_output(G+['status','--porcelain'],text=True)
assert not subprocess.check_output(G+['log','--all','--format=','--name-only','--','*VREC-IAR-014*'],text=True).strip()
base='docs/engineering/instruction-architecture/evidence/'
names=['WO-IAR-022/review.md','WO-IAR-022/raw-capture.zip','WO-IAR-022/governance-capture.zip','WO-IAR-022/evidence-index.json','WO-IAR-022/protected-files.json','WO-IAR-022/final-package-comparison.json','WO-IAR-024/review.md','WO-IAR-024/shared-evidence.json','WO-IAR-025/review.md','WO-IAR-025/shared-evidence.json','WO-IAR-025/applied.patch']
args=['capture-verification',str(REPO),'--id','VREC-IAR-014','--domain','instruction-architecture','--owner','Codex','--verification','VER-IAR-017','--json']
for wo in ['WO-IAR-022','WO-IAR-024','WO-IAR-025']:args+=['--work-order',wo]
for p in names:args+=['--evidence',base+p]
invoke('retirement-capture',args)
