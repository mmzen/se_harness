import json,subprocess
from retirement_tools import ROOT,REPO,G,meta
paths=set(subprocess.check_output(G+['diff','--name-only','HEAD'],text=True).splitlines())
paths.update(subprocess.check_output(G+['ls-files','--others','--exclude-standard'],text=True).splitlines())
scope=[]
for wo in ['WO-IAR-022','WO-IAR-024','WO-IAR-025']:scope+=meta(wo)['execution_scope']['paths']
outside=[p for p in paths if not any(p.startswith(s) if s.endswith('/') else p==s for s in scope)]
assert not outside,outside
subprocess.run(G+['diff','--check','--','.',':(exclude)*.patch'],check=True,capture_output=True)
subprocess.run(G+['add','--',*sorted(paths)],check=True,capture_output=True)
subprocess.run(G+['diff','--cached','--check','--','.',':(exclude)*.patch'],check=True,capture_output=True)
subprocess.run(G+['commit','-m','fix: retire obsolete guide seeds and preserve supported upgrades'],check=True,capture_output=True)
commit=subprocess.check_output(G+['rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(G+['status','--porcelain'],text=True)
(ROOT/'work/retirement-candidate.json').write_text(json.dumps({'commit':commit,'work_orders':['WO-IAR-022','WO-IAR-024','WO-IAR-025'],'files':sorted(paths)},indent=2)+'\n')
print(json.dumps({'candidate':commit,'files':len(paths),'clean':True}))
