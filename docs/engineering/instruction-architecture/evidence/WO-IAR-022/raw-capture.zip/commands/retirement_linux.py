import json,os,subprocess,sys,tempfile,time
from pathlib import Path

work=Path(__file__).resolve().parent
source=work/'se_harness';logs=work/'cleanup-checks'
env=os.environ.copy()
env.update(PYTHONIOENCODING='utf-8',GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=str(source))
target=Path(tempfile.mkdtemp(prefix='iar022-linux-'))/'repository'
subprocess.run(['git','clone','--no-hardlinks',str(source),str(target)],check=True,capture_output=True,env=env)
names=subprocess.check_output(['git','-C',str(source),'ls-files','-z','--cached','--others','--exclude-standard'],env=env).decode().split('\0')
for name in filter(None,names):
    src=source/name;dst=target/name
    assert dst.resolve().is_relative_to(target.resolve())
    if src.is_file():
        dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
    elif dst.is_file():dst.unlink()
origin=subprocess.check_output(['git','-C',str(source),'remote','get-url','origin'],env=env,text=True).strip()
subprocess.run(['git','-C',str(target),'remote','set-url','origin',origin],check=True)
checks=[('retirement-linux-full',['scripts/run_tests.py','--workers','4']),
        ('retirement-linux-delivery',['-m','unittest','discover','-s','tests/plugin_integration/progressive_discovery','-p','test_*.py']),
        ('retirement-linux-distributions',['scripts/validate_release_distributions.py','--root','.']),
        ('retirement-linux-cli',['-m','se_harness','--help'])]
failed=False
for label,args in checks:
    label += '-final'
    argv=[sys.executable,'-B',*args];start=time.time()
    with (logs/(label+'.stdout')).open('wb') as out,(logs/(label+'.stderr')).open('wb') as err:
        p=subprocess.run(argv,cwd=target,env=env,stdout=out,stderr=err)
    record={'argv':argv,'cwd':str(target),'source':str(source),'exit_code':p.returncode,'seconds':round(time.time()-start,2),'python':sys.version,'platform':sys.platform}
    (logs/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if p.returncode:failed=True;print((logs/(label+'.stderr')).read_text(errors='replace')[-5000:],flush=True)
print('Snapshot: '+str(target),flush=True)
sys.exit(int(failed))
