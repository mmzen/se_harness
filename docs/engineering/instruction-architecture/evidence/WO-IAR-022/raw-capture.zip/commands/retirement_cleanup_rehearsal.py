import hashlib,json,runpy,sys
from pathlib import Path
# Reuse the recorded installed-command runner without executing another mode.
sys.argv=['retirement_packages_check.py','helpers']
m=runpy.run_path(str(Path(__file__).with_name('retirement_packages_check.py')))
base=m['base'];harness=m['harness'];candidate=m['candidate'];predecessor=m['predecessor'];names=m['NAMES'];hashes=m['hashes']
root=base/'cleanup-rehearsal';log=m['logs']
harness('cleanup-predecessor-init',predecessor,'init',root,'--project-name','Synthetic cleanup rehearsal','--json')
reviewed={n:hashlib.sha256((root/'docs/engineering'/n).read_bytes()).hexdigest() for n in names}
harness('cleanup-upgrade',candidate,'upgrade',root,'--apply','--json')
results=[]
def inspect(active):
    errors=[]
    for n in names:
        p=root/'docs/engineering'/n
        if p.is_symlink() or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=reviewed[n]:errors.append('modified-or-unsafe:'+n)
        if n in active:errors.append('active-consumer:'+n)
    return errors
p=root/'docs/engineering/OPERATING_CARD.md';original=p.read_bytes()
p.write_bytes(original+b'\r\nOwner edit\r\n');before=hashes(root)
errors=inspect(set());assert errors and before==hashes(root)
results.append({'case':'modified-pointer','refusal':errors,'all_bytes_unchanged':True})
p.write_bytes(original)
before=hashes(root);errors=inspect({'OPERATING_CARD.md'});assert errors and before==hashes(root)
results.append({'case':'active-old-consumer','refusal':errors,'all_bytes_unchanged':True})
assert not inspect(set())
# This is a test-only decision over this disposable repository. Native host
# qualification is intentionally simulated, never represented as actual proof.
before=hashes(root)
for n in names:
    p=root/'docs/engineering'/n
    assert p.resolve().is_relative_to(root.resolve())
    p.unlink()
after=hashes(root)
removed={'docs/engineering/'+n for n in names}
assert set(before)-set(after)==removed
assert all(before[p]==raw for p,raw in after.items())
harness('cleanup-reconcile-preview',candidate,'upgrade',root,'--json')
harness('cleanup-reconcile-apply',candidate,'upgrade',root,'--apply','--json')
harness('cleanup-doctor',candidate,'doctor',root,'--json')
lock=json.loads((root/'.engineering-harness.lock').read_bytes())
assert not removed.intersection(lock['files'])
before=hashes(root)
# Inspect after the successful apply, then retry reconciliation only. No repeat
# deletion and no recreation of an absent owner pointer.
assert all(not (root/p).exists() for p in removed)
harness('cleanup-retry',candidate,'upgrade',root,'--apply','--json')
assert before==hashes(root)
results.append({'case':'reviewed-stock-only','removed':sorted(removed),'other_files_unchanged':True,'doctor':'pass','retry_exactly_unchanged':True})
(log/'cleanup-rehearsal.json').write_text(json.dumps({'method':'Synthetic procedure rehearsal using actual installed CLI; no real owner cleanup or native-host qualification','reviewed_sha256':reviewed,'results':results},indent=2)+'\n')
print('Cleanup rehearsal passed',flush=True)
