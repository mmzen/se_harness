import hashlib,json,os,subprocess,tarfile,time,zipfile
from retirement_tools import ROOT,REPO,NAMES
out=ROOT/'work/retirement-final-packages';old=ROOT/'work/retirement-packages'
source=out/'sdist-source';source.mkdir(exist_ok=False)
with tarfile.open(out/'dist/se_harness-0.20.0.tar.gz') as t:t.extractall(source,filter='data')
argv=[str(ROOT/'work/retirement-build-env/Scripts/python.exe'),'-m','build','--no-isolation','--wheel','--outdir',str(out/'sdist-wheel'),str(next(source.iterdir()))]
start=time.time();p=subprocess.run(argv,cwd=ROOT,capture_output=True)
(out/'sdist-build.stdout').write_bytes(p.stdout);(out/'sdist-build.stderr').write_bytes(p.stderr)
(out/'sdist-build.json').write_text(json.dumps({'argv':argv,'cwd':str(ROOT),'exit_code':p.returncode,'seconds':round(time.time()-start,2)},indent=2)+'\n')
assert p.returncode==0
def members(path):
    with zipfile.ZipFile(path) as z:return {n:z.read(n) for n in z.namelist()}
tested=members(old/'dist/se_harness-0.20.0-py3-none-any.whl')
result={'method':'Exact decompressed member comparison, including RECORD; archive timestamps may differ.','packages':[]}
for wheel in [out/'dist/se_harness-0.20.0-py3-none-any.whl',out/'sdist-wheel/se_harness-0.20.0-py3-none-any.whl']:
    actual=members(wheel)
    assert tested==actual, [n for n in set(tested)|set(actual) if tested.get(n)!=actual.get(n)]
    result['packages'].append({'path':str(wheel),'sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'all_members_equal_to_tested_wheel':True})
with tarfile.open(out/'dist/se_harness-0.20.0.tar.gz') as t:
    names=t.getnames()
    for name in NAMES:assert not any(n.endswith('/templates/repository/standard/docs/engineering/'+name) for n in names)
    target='se_harness-0.20.0/tests/test_release_build.py'
    assert t.extractfile(target).read()==(REPO/'tests/test_release_build.py').read_bytes()
result['sdist']={'sha256':hashlib.sha256((out/'dist/se_harness-0.20.0.tar.gz').read_bytes()).hexdigest(),'omits_six_templates':True,'contains_final_packaging_test':True}
(out/'comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
