import hashlib,json,os,subprocess,sys,tarfile,tempfile,time,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT/'work/se_harness'
NAMES=('OPERATING_CARD.md','DECISION_RIGHTS.md','QUALITY_GATES.md','WORKFLOW.md','TRACEABILITY.md','TECHNICAL_COMMUNICATION.md')

packages=ROOT/'work/retirement-packages'
base=Path(os.environ.get('RETIREMENT_OUTPUT',str(packages)))
base.mkdir(parents=True,exist_ok=True)
logs=base/'checks';logs.mkdir(exist_ok=True)
candidate=Path(os.environ.get('RETIREMENT_CANDIDATE',str(ROOT/'work/retirement-candidate-env/Scripts/python.exe')))
predecessor=Path(os.environ.get('RETIREMENT_PREDECESSOR',r'C:\Users\mathi\Documents\Codex\plugin-data\verity-plane\evaluator\Scripts\python.exe'))
builder=ROOT/'work/retirement-build-env/Scripts/python.exe'

def call(label,argv,expected=0,cwd=base):
    if (logs/(label+'.json')).exists():
        n=1
        while (logs/(label+f'.prior-{n}.json')).exists():n+=1
        for suffix in ('.stdout','.stderr','.json'):
            p=logs/(label+suffix)
            if p.exists():p.rename(logs/(label+f'.prior-{n}'+suffix))
    argv=list(map(str,argv));start=time.time()
    env=os.environ.copy();env.update(PYTHONIOENCODING='utf-8',GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=REPO.as_posix(),GIT_CONFIG_KEY_1='core.longpaths',GIT_CONFIG_VALUE_1='true')
    p=subprocess.run(argv,cwd=cwd,env=env,capture_output=True)
    (logs/(label+'.stdout')).write_bytes(p.stdout);(logs/(label+'.stderr')).write_bytes(p.stderr)
    result={'argv':argv,'cwd':str(cwd),'exit_code':p.returncode,'expected_exit':expected,'seconds':round(time.time()-start,2)}
    (logs/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result),flush=True)
    if p.returncode!=expected:print(p.stderr.decode(errors='replace')[-3000:]);raise RuntimeError(label)
    try:return json.loads(p.stdout)
    except ValueError:return p.stdout.decode(errors='replace')

def harness(label,python,*args,expected=0):return call(label,[python,'-I','-B','-m','se_harness',*args],expected)
def hashes(root):return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
def check_fresh(label,python):
    root=base/label
    if not root.exists():harness(label+'-init',python,'init',root,'--project-name','Retirement verification','--json')
    lock=json.loads((root/'.engineering-harness.lock').read_bytes())
    for name in NAMES:
        relative='docs/engineering/'+name
        assert not (root/relative).exists() and relative not in lock['files']
    harness(label+'-doctor',python,'doctor',root,'--json')
    if not (root/'docs/engineering/probe').exists():harness(label+'-scaffold',python,'scaffold-domain',root,'--domain','probe','--json')
    artifact=root/'docs/engineering/probe/work-orders/WO-PRB-001.md'
    if not artifact.exists():harness(label+'-create',python,'create-artifact',root,'--domain','probe','--type','work_order','--id','WO-PRB-001','--json')
    # Complete only a synthetic draft; no approval or implementation is claimed.
    # All fixture definitions stay drafts. This factory writes data only; the
    # actual check below runs through the installed candidate, outside source.
    sys.path.insert(0,str(REPO/'tests'))
    from artifact_support import formal,write
    artifact_base=root/'docs/engineering/probe'
    records=[('intent','INT-PRB-001','intent',{}),
             ('capabilities','CAP-PRB-001','capability',{'derives_from':['INT-PRB-001']}),
             ('requirements','REQ-PRB-001','requirement',{'derives_from':['CAP-PRB-001']}),
             ('specifications','SPEC-PRB-001','specification',{'specifies':['REQ-PRB-001']}),
             ('verification','VER-PRB-001','verification',{'verifies':['REQ-PRB-001']}),
             ('work-orders','WO-PRB-001','work_order',{'implements':['REQ-PRB-001'],'specifications':['SPEC-PRB-001'],'verification':['VER-PRB-001']})]
    for directory,aid,kind,relations in records:
        write(artifact_base/directory/(aid+'.md'),formal(aid,kind,'draft',relations,complete=True))
    result=harness(label+'-check',python,'check',root,'--artifact','WO-PRB-001','--json')
    assert result['instruction_discovery']['status']=='available'
    return root

if sys.argv[1]=='build-sdist-wheel':
    source=base/'sdist-source';source.mkdir(exist_ok=False)
    with tarfile.open(base/'dist/se_harness-0.20.0.tar.gz') as tar:tar.extractall(source,filter='data')
    roots=list(source.iterdir());assert len(roots)==1
    call('sdist-wheel-build',[builder,'-m','build','--no-isolation','--wheel','--outdir',base/'sdist-wheel',roots[0]])
elif sys.argv[1]=='installed':
    sdist_python=Path(os.environ.get('RETIREMENT_SDIST',str(ROOT/'work/retirement-sdist-env/Scripts/python.exe')))
    listings={}
    for package in sorted((packages/'dist').iterdir()):
        if package.suffix=='.whl':
            with zipfile.ZipFile(package) as z:names=z.namelist()
        else:
            with tarfile.open(package) as t:names=t.getnames()
        for name in NAMES:assert not any(n.endswith('/templates/repository/standard/docs/engineering/'+name) for n in names),(package,name)
        listings[package.name]={'sha256':hashlib.sha256(package.read_bytes()).hexdigest(),'members':names}
    (logs/'distribution-members.json').write_text(json.dumps(listings,indent=2)+'\n',encoding='utf-8')
    call('candidate-origin',[candidate,'-I','-c','import se_harness,sys;print(se_harness.__file__);print(sys.version)'])
    check_fresh('fresh-wheel',candidate);check_fresh('fresh-sdist',sdist_python)
    root=base/'upgrade-019'
    harness('predecessor-init',predecessor,'init',root,'--project-name','Retirement predecessor','--json')
    harness('predecessor-doctor',predecessor,'doctor',root,'--json')
    observed={}
    for i,name in enumerate(NAMES):
        p=root/'docs/engineering'/name
        if i%3==1:p.write_bytes(p.read_bytes()+b'\r\nOwner bytes \xff\r\n')
        elif i%3==2:p.unlink()
        observed['docs/engineering/'+name]=p.read_bytes() if p.exists() else None
    harness('upgrade-preview',candidate,'upgrade',root,'--json')
    harness('upgrade-apply',candidate,'upgrade',root,'--apply','--json')
    lock=json.loads((root/'.engineering-harness.lock').read_bytes())
    for rel,raw in observed.items():
        assert rel not in lock['files']
        assert raw==((root/rel).read_bytes() if (root/rel).exists() else None),rel
    harness('upgrade-doctor',candidate,'doctor',root,'--json')
    before=hashes(root)
    harness('upgrade-retry',candidate,'upgrade',root,'--apply','--json')
    assert before==hashes(root)
    (logs/'owner-preservation.json').write_text(json.dumps({'cases':{p:{'before':hashlib.sha256(raw).hexdigest() if raw else None,'after':hashlib.sha256((root/p).read_bytes()).hexdigest() if (root/p).exists() else None,'tracked':p in lock['files']} for p,raw in observed.items()},'retry_exactly_unchanged':True},indent=2)+'\n',encoding='utf-8')
elif sys.argv[1]=='rehearsal':
    call('existing-upgrade-rehearsal-retry',[sys.executable,'-B','-m','repository_tools.upgrade_rehearsal','--repository',REPO,'--predecessor-python',predecessor,'--successor-python',candidate,'--output',base/'rehearsal-retry','--workspace',tempfile.gettempdir(),'--json','--timings'],cwd=REPO)
