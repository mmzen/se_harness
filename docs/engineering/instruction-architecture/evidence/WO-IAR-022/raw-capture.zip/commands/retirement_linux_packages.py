import json,os,subprocess,sys,tempfile,time
from pathlib import Path
work=Path(__file__).resolve().parent
out=work/'retirement-linux-packages-confirmed';out.mkdir(exist_ok=False)
runtime=Path(tempfile.mkdtemp(prefix='iar022-packages-'))
env=os.environ.copy()
def run(label,args):
    start=time.time();p=subprocess.run(list(map(str,args)),env=env,capture_output=True)
    (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
    record={'argv':list(map(str,args)),'cwd':str(Path.cwd()),'exit_code':p.returncode,'seconds':round(time.time()-start,2),'python':sys.version}
    (out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if p.returncode:print(p.stderr.decode(errors='replace')[-3000:]);raise SystemExit(p.returncode)
for name,wheel in [('candidate',work/'retirement-packages/dist/se_harness-0.20.0-py3-none-any.whl'),('sdist',work/'retirement-packages/sdist-wheel/se_harness-0.20.0-py3-none-any.whl'),('predecessor',work/'r019-public-github-assets/se_harness-0.19.0-py3-none-any.whl')]:
    venv=runtime/name
    run(name+'-venv',[sys.executable,'-m','venv',venv])
    py=venv/'bin/python'
    run(name+'-install',[py,'-m','pip','install','--no-index','--no-deps',wheel])
    env['RETIREMENT_'+name.upper()]=str(py)
env['RETIREMENT_OUTPUT']=str(out)
run('installed',[sys.executable,'-B',work/'retirement_packages_check.py','installed'])
run('rehearsal',[sys.executable,'-B',work/'retirement_packages_check.py','rehearsal'])
