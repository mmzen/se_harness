import hashlib,json,subprocess,tarfile,zipfile
from pathlib import Path
from retirement_tools import ROOT,REPO,NAMES,G
work=ROOT/'work';out=work/'retirement-inventory';out.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
names=subprocess.check_output(G+['ls-files','-z','--cached','--others','--exclude-standard']).decode().split('\0')
inventory=[]
for name in sorted(set(filter(None,names))):
    p=REPO/name
    if not p.is_file():continue
    try:content=p.read_text(encoding='utf-8')
    except UnicodeError:continue
    matches=[{'line':i,'excerpt':s[:240],'line_sha256':hashlib.sha256(s.encode()).hexdigest(),'names':[n for n in NAMES if n in s]} for i,s in enumerate(content.splitlines(),1) if any(n in s for n in NAMES)]
    if not matches:continue
    if name.startswith('tests/'):
        kind='historical' if '/fixtures/' in name else 'current'
        reason='Retained predecessor/synthetic observations, not runtime instructions.' if kind=='historical' else 'Migration, negative-control, preservation or current-route assertion; full suites assess execution.'
    elif name=='se_harness/instruction_discovery.json':kind,reason='conditional','0.18.0 editable-guide migration fingerprints only.'
    elif name=='se_harness/installer.py':kind,reason='conditional','Explicit 0.18.0 conversion and preserved leaving-seed inventory; fresh installs do not create guides.'
    elif name in ['se_harness/workflow_contract.py','se_harness/preflight.py']:
        kind,reason='conditional','Retained renderer or legacy policy-path constant; not current required-reading/install inventory. Removal is explicitly deferred.'
    elif name.startswith('plugins/'):
        kind,reason='conditional','Current guide is explicit; older installed roots may select their legacy guide. Missing current guide is not fallback authority.'
    elif name.startswith('templates/'):
        kind,reason='current','Upgrade/migration procedure names retirement targets and explains preserved-owner handling, not required reading of obsolete files.'
    elif name.startswith('docs/notes/'):
        kind,reason='historical','Repository-owned explanation/assessment tied to the retained 0.19.0 installation or earlier work; not distributed current instruction route. Existing installed pointers remain until separate adoption.'
    elif name=='.engineering-harness.lock':
        kind,reason='conditional','Installed repository remains on released 0.19.0; seed entries leave only in a separately approved adoption.'
    elif name=='GLOSSARY.md' or name.startswith('docs/rca/'):
        kind,reason='historical','Repository-owned glossary or RCA describes retained installed/historical policy; not a distributed current guide consumer.'
    elif name.startswith('docs/engineering/'):
        kind,reason='historical','Formal definitions, work history, retained observations or repository-installed 0.19.0 files. This product change does not rewrite these records.'
    else:
        kind,reason='review-required','Unclassified path.'
    inventory.append({'path':name,'classification':kind,'reason':reason,'matches':matches})
write('consumer-inventory.json',inventory)
assert not [x for x in inventory if x['classification']=='review-required']
inputs=json.loads((work/'retirement-packages/source-inputs.json').read_text())['sha256']
changed=[p for p,h in inputs.items() if (REPO/p).is_file() and sha(REPO/p)!=h]
production=[p for p in changed if p.startswith(('se_harness/','templates/','plugins/','repository_tools/','scripts/')) or p in ['pyproject.toml','MANIFEST.in']]
assert not production,production
package_differences=[]
with tarfile.open(work/'retirement-packages/dist/se_harness-0.20.0.tar.gz') as archive:
    for member in archive.getmembers():
        rel='/'.join(member.name.split('/')[1:])
        if member.isfile() and rel in inputs:
            current=REPO/rel
            if current.is_file() and archive.extractfile(member).read()!=current.read_bytes():package_differences.append(rel)
write('build-input-comparison.json',{'build_source_base':'d0e94b1cc50be9972aec85d5f64064b3361aeb06','unchanged_production_inputs':True,'changed_nonproduction_inputs':changed,'sdist_source_differences':package_differences,'meaning':'Disposable package test build. No release reproducibility, publication or adoption claim.'})
protected=['ENGINEERING_HARNESS.md','AGENTS.md','CLAUDE.md','.engineering-harness.lock','docs/engineering/WORKFLOW.json','docs/engineering/QUALITY_GATES.json','docs/engineering/ARTIFACT_AUTHORING.md',*[f'docs/engineering/{n}' for n in NAMES]]
protected += [p for p in names if p.startswith('docs/engineering/harness/')]
diff=set(subprocess.check_output(G+['diff','--name-only','d0e94b1cc50be9972aec85d5f64064b3361aeb06']).decode().splitlines())
assert not diff.intersection(protected)
write('protected-files.json',{'comparison_base':'d0e94b1cc50be9972aec85d5f64064b3361aeb06','unchanged':{p:sha(REPO/p) for p in protected if (REPO/p).is_file()}})
print(json.dumps({'consumer_files':len(inventory),'production_input_differences':production,'sdist_source_differences':package_differences,'changed_nonproduction':changed}),flush=True)
