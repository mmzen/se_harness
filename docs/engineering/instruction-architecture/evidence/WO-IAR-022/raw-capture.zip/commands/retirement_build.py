import hashlib,json,os,subprocess,sys,tempfile,time
from pathlib import Path
from retirement_tools import ROOT,REPO,G,NAMES

out=ROOT/'work'/ (sys.argv[1] if len(sys.argv)>1 else 'retirement-packages')
out.mkdir(exist_ok=False)
snapshot=out/'source';snapshot.mkdir()
paths=subprocess.check_output(G+['ls-files','-z','--cached','--others','--exclude-standard']).decode().split('\0')
hashes={}
for name in filter(None,paths):
    src=REPO/name
    if not src.is_file():continue
    dst=snapshot/name;assert dst.resolve().is_relative_to(snapshot.resolve())
    dst.parent.mkdir(parents=True,exist_ok=True);raw=src.read_bytes();dst.write_bytes(raw)
    hashes[name]=hashlib.sha256(raw).hexdigest()
(out/'source-inputs.json').write_text(json.dumps({'base_commit':subprocess.check_output(G+['rev-parse','HEAD'],text=True).strip(),'kind':'non-promotable working-source test build','sha256':hashes},indent=2)+'\n',encoding='utf-8')
python=ROOT/'work/retirement-build-env/Scripts/python.exe'
argv=[str(python),'-m','build','--no-isolation','--wheel','--sdist','--outdir',str(out/'dist'),str(snapshot)]
start=time.time()
with (out/'build.stdout').open('wb') as stdout,(out/'build.stderr').open('wb') as stderr:
    p=subprocess.run(argv,cwd=ROOT,stdout=stdout,stderr=stderr)
record={'argv':argv,'cwd':str(ROOT),'exit_code':p.returncode,'seconds':time.time()-start}
(out/'build.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record),flush=True)
print((out/'build.stderr').read_text(errors='replace')[-1500:])
sys.exit(p.returncode)
