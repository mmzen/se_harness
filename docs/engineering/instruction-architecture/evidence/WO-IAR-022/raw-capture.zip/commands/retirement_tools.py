import json,subprocess,tomllib
from evolution_cli import REPO,ROOT,run,LOG

NAMES=('OPERATING_CARD.md','DECISION_RIGHTS.md','QUALITY_GATES.md','WORKFLOW.md','TRACEABILITY.md','TECHNICAL_COMMUNICATION.md')
BASE='fd05dc9f28452c906e764a37570342acbabd09b9'
VERIFIED_BASE='a0435434bcfa9ce385931e2d0e64bf98cab300e1'
G=['git','-c','safe.directory='+REPO.as_posix(),'-C',str(REPO)]

def meta(wo):
    return tomllib.loads((REPO/f'docs/engineering/instruction-architecture/work-orders/{wo}.md').read_text(encoding='utf-8').split('+++',2)[1])

def invoke(label,args):
    code,r=run(label,args)
    print(json.dumps({'label':label,'exit':code,'state':r.get('state'),'findings':r.get('findings'),'restitution':r.get('restitution')}),flush=True)
    if code:raise SystemExit(code)
    return r

def scope(wo):
    paths=[]
    for p in meta(wo)['execution_scope']['paths']:
        if p.endswith('released-0.19.0/'):
            paths.extend(p+n for n in (*NAMES,'provenance.json'))
        elif p.endswith('/'):
            paths.append(p+'review.md')
        else:paths.append(p)
    args=['check',str(REPO),'--artifact',wo,'--checkpoint','scope','--changes-complete','--json']
    for p in paths:args+=['--changed-path',p]
    invoke('retirement-'+wo+'-planned-scope',args)

if __name__=='__main__':
    import sys
    scope(sys.argv[1])
