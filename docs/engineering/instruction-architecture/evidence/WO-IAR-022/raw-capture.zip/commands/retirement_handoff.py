import json,sys
from retirement_tools import ROOT,REPO,BASE,invoke
event=ROOT/'work/retirement-pr-event.json'
body='''Correct active instruction discovery and retire six obsolete guide templates while preserving owner files and supported migration.

WO-IAR-020 retains partial native qualification only; it is not complete. WO-IAR-021/023 were implemented and verified by VREC-IAR-013. WO-IAR-022/024/025 implement retirement, covered consumers and the exact CLI-note correction. Real host adoption, release and repository pointer cleanup remain separate.

Harness-Work-Orders: WO-IAR-020, WO-IAR-021, WO-IAR-022, WO-IAR-023, WO-IAR-024, WO-IAR-025
'''
event.write_text(json.dumps({'pull_request':{'body':body}},indent=2)+'\n',encoding='utf-8')
if sys.argv[1]=='combined':
    invoke('retirement-combined-handoff',['check-pr',str(REPO),'--event',str(event),'--from-git',BASE,'--json'])
elif sys.argv[1]=='preflight':
    for wo in ['WO-IAR-022','WO-IAR-024','WO-IAR-025']:
        invoke('retirement-'+wo+'-review-preflight',['preflight',str(REPO),'--work-order',wo,'--phase','review','--json'])
elif sys.argv[1]=='evidence':
    for wo in ['WO-IAR-022','WO-IAR-024','WO-IAR-025']:
        invoke('retirement-'+wo+'-evidence',['evidence',str(REPO),'--artifact',wo,'--checkpoint','handoff','--json'])
