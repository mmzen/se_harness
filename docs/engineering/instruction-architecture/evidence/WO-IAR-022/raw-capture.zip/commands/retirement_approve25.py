import hashlib
from retirement_tools import REPO,invoke,meta
wo='WO-IAR-025';p=REPO/f'docs/engineering/instruction-architecture/work-orders/{wo}.md'
assert meta(wo)['status']=='draft'
reviewed=hashlib.sha256(p.read_bytes()).hexdigest()
s=p.read_text(encoding='utf-8').replace('[execution_scope]','[assurance]\ncommit_bound_verification = "required"\nrationale = "Human-approved commit-bound verification of the instruction link used for retirement and subsequent release review."\ndecided_by = "mmzen"\n\n[execution_scope]',1)
s=s.replace('Commit-bound verification is proposed as required because the corrected\ninstruction route supports retirement and later release decisions. The human\nhas not yet confirmed this work order or its assurance classification.\nDo not record assurance.decided_by before that decision.', 'Human repository owner mmzen confirmed required commit-bound verification with\n"Approve WO-IAR-025 and required verification". The corrected instruction route\nsupports retirement and later release decisions.')
p.write_text(s,encoding='utf-8');sha=hashlib.sha256(p.read_bytes()).hexdigest()
reason='Human repository owner mmzen: "Approve WO-IAR-025 and required verification". Approval includes the reviewed two-line note correction and the existing 0.19.0 engineering-owner encoding. Reviewed draft SHA-256 '+reviewed+'. Only the supplied assurance decision was added before transition; input SHA-256 '+sha+'. Codex applies the human decision.'
args=['transition',str(REPO),'--set',wo+'=approved','--decision',wo+'=engineering-owner','--reason',wo+'='+reason,'--json']
invoke('retirement025-approval-preview',args)
assert hashlib.sha256(p.read_bytes()).hexdigest()==sha
invoke('retirement025-approval-apply',args+['--apply'])
