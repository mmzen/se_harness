import hashlib,json,sys,tomllib
from evolution_cli import REPO,run,ROOT

def invoke(label,args):
    code,r=run(label,args)
    print(json.dumps({'label':label,'exit':code,'ready':r.get('ready'),'state':r.get('state'),'restitution':r.get('restitution'),'errors':r.get('errors')}),flush=True)
    if code: raise SystemExit(code)
    return r

if sys.argv[1]=='approve24':
    path=REPO/'docs/engineering/instruction-architecture/work-orders/WO-IAR-024.md'
    text=path.read_text(encoding='utf-8')
    assert tomllib.loads(text.split('+++',2)[1])['status']=='draft'
    reviewed=hashlib.sha256(path.read_bytes()).hexdigest()
    text=text.replace('[execution_scope]', '[assurance]\ncommit_bound_verification = "required"\nrationale = "Human-approved commit-bound assurance for the consumer corrections and retirement checks used by subsequent adoption and release decisions."\ndecided_by = "mmzen"\n\n[execution_scope]',1)
    text=text.replace('Commit-bound assurance is proposed as **required** because the correction\nchanges instructions and tests on which retirement and later release decisions\ndepend. The human has not yet approved this additional scope or confirmed its\nassurance classification. Leave assurance.decided_by unset until that decision.', 'The human repository owner mmzen confirmed **required** commit-bound assurance\nwith "I approve", in direct response to the request to approve WO-IAR-024 and\nrequired verification, using the existing 0.19.0 engineering-owner encoding.\nThe correction changes instructions and tests on which later retirement and\nrelease decisions depend.')
    path.write_text(text,encoding='utf-8')
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    reason='Human repository owner mmzen: "I approve", in response to the request to approve WO-IAR-024 and required commit-bound verification, with existing 0.19.0 engineering-owner encoding. Reviewed draft SHA-256 '+reviewed+'. The only pre-transition edits record the supplied assurance decision. Approval input SHA-256 '+digest+'. Codex applies that human decision.'
    args=['transition',str(REPO),'--set','WO-IAR-024=approved','--decision','WO-IAR-024=engineering-owner','--reason','WO-IAR-024='+reason,'--json']
    invoke('retirement024-approval-preview',args)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
    invoke('retirement024-approval-apply',args+['--apply'])
else:
    wo=sys.argv[1]
    invoke('retirement-'+wo+'-start-preflight',['preflight',str(REPO),'--work-order',wo,'--phase','start','--json'])
    args=['transition',str(REPO),'--set',wo+'=in_progress','--decision',wo+'=Codex','--reason',wo+'=Codex starts the unchanged approved scope under mmzen\'s recorded approval after passing start checks.','--json']
    invoke('retirement-'+wo+'-start-preview',args)
    invoke('retirement-'+wo+'-start-apply',args+['--apply'])
    invoke('retirement-'+wo+'-start-readback',['check',str(REPO),'--artifact',wo,'--json'])
