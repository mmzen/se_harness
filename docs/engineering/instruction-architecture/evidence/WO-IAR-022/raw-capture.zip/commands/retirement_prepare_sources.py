import hashlib,json,zipfile
from retirement_tools import REPO,ROOT,NAMES

wheel=ROOT/'work/r019-public-github-assets/se_harness-0.19.0-py3-none-any.whl'
assert hashlib.sha256(wheel.read_bytes()).hexdigest()=='43419a0c5e7711e7888ed69c207d5599dcd39a4aeb706c8827e7bb33c46573d8'
dest=REPO/'tests/fixtures/progressive-discovery/released-0.19.0'
dest.mkdir(exist_ok=False)
provenance={'archive':wheel.name,'archive_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'version':'0.19.0','files':{},'newline_policy':'Files are extracted bytes from the released wheel. Tests normalize checkout CRLF to LF before comparing with these published LF digests; owner preservation compares exact observed bytes without normalization.'}
with zipfile.ZipFile(wheel) as z:
    for name in NAMES:
        suffix='/templates/repository/standard/docs/engineering/'+name
        members=[n for n in z.namelist() if n.endswith(suffix)]
        assert len(members)==1,members
        raw=z.read(members[0]);(dest/name).write_bytes(raw)
        provenance['files'][name]={'member':members[0],'sha256':hashlib.sha256(raw).hexdigest()}
(dest/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n',encoding='utf-8')
template=REPO/'templates/repository/standard/docs/engineering'
for name in NAMES:
    p=(template/name).resolve()
    assert p.parent==template.resolve() and p.is_relative_to(REPO.resolve())
    p.unlink()
p=REPO/'pyproject.toml';lines=p.read_text(encoding='utf-8').splitlines(keepends=True)
removed=[line for line in lines if any('templates/repository/standard/docs/engineering/'+name+'"' in line for name in NAMES)]
assert len(removed)==6,removed
p.write_text(''.join(line for line in lines if line not in removed),encoding='utf-8')
print(json.dumps(provenance,indent=2))
