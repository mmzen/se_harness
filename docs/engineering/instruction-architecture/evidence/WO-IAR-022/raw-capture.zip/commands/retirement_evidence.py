import hashlib,json,shutil,subprocess,zipfile
from retirement_tools import ROOT,REPO,BASE,VERIFIED_BASE,NAMES,G
work=ROOT/'work';domain=REPO/'docs/engineering/instruction-architecture'
target=domain/'evidence/WO-IAR-022';target.mkdir(parents=True,exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
checks=[]
for label in ['retirement-windows-final','retirement-linux-full-final','retirement-note-final','retirement-windows-delivery','retirement-linux-delivery-final','retirement-windows-distributions','retirement-linux-distributions-final','retirement-windows-cli','retirement-linux-cli-final']:
    p=work/'cleanup-checks'/(label+'.json');v=json.loads(p.read_text());assert v['exit_code']==0
    checks.append({'label':label,**v})
for root in [work/'retirement-packages',work/'retirement-linux-packages-confirmed']:
    assert json.loads((root/'rehearsal-retry/upgrade-rehearsal-result.json').read_text())['overall_result']=='pass'
    assert json.loads((root/'checks/owner-preservation.json').read_text())['retry_exactly_unchanged']
assert json.loads((work/'evolution-evidence/retirement-final-validate.stdout').read_text())['valid']
raw=[]
raw.extend((p,'checks/'+p.name) for p in (work/'cleanup-checks').glob('retirement*') if p.is_file())
for folder in ['retirement-packages','retirement-final-packages','retirement-linux-packages','retirement-linux-packages-final','retirement-linux-packages-confirmed','retirement-inventory']:
    base=work/folder
    for p in base.rglob('*'):
        rel=p.relative_to(base)
        if p.is_file() and (rel.parts[0] in ['checks','rehearsal','rehearsal-retry'] or len(rel.parts)==1):
            raw.append((p,folder+'/'+rel.as_posix()))
raw.extend((p,'commands/'+p.name) for p in work.glob('retirement*.py'))
raw.extend((p,'governance/'+p.name) for p in (work/'evolution-evidence').glob('retirement*') if p.is_file())
with zipfile.ZipFile(target/'raw-capture.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,arc in sorted(raw,key=lambda x:x[1]):z.writestr(arc,p.read_bytes())
inventory=json.loads((work/'retirement-inventory/consumer-inventory.json').read_text())
write(target/'evidence-index.json',{'work_orders':['WO-IAR-022','WO-IAR-024','WO-IAR-025'],'verification':['VER-IAR-017'],'trusted_base':BASE,'verified_reference_correction':VERIFIED_BASE,'verified_reference_record':'VREC-IAR-013','checks':checks,'raw_capture':{'path':'raw-capture.zip','sha256':sha(target/'raw-capture.zip'),'members':[{'path':arc,'sha256':sha(p),'bytes':p.stat().st_size} for p,arc in raw]},'consumer_inventory':{'files':len(inventory),'classifications':{kind:sum(v['classification']==kind for v in inventory) for kind in ['current','conditional','historical']}},'limits':['Source and disposable installed-package tests, not a release build or publication.','Native qualification and real adoption remain WO-IAR-020/later work.','Repository-installed pointers, root policy, machine gates and VREC-IAR-013 evidence are unchanged.']})
for name in ['protected-files.json','build-input-comparison.json']:
    shutil.copy2(work/'retirement-inventory'/name,target/name)
shutil.copy2(work/'retirement-final-packages/comparison.json',target/'final-package-comparison.json')
for wid in ['WO-IAR-024','WO-IAR-025']:
    d=domain/'evidence'/wid;d.mkdir(parents=True,exist_ok=True)
    write(d/'shared-evidence.json',{'shared':'docs/engineering/instruction-architecture/evidence/WO-IAR-022/evidence-index.json','bound_raw_capture':'docs/engineering/instruction-architecture/evidence/WO-IAR-022/raw-capture.zip','raw_sha256':sha(target/'raw-capture.zip'),'verification':'VER-IAR-017'})
patch=subprocess.check_output(G+['diff','--','docs/notes/harnessctl-reference.md'])
(domain/'evidence/WO-IAR-025/applied.patch').write_bytes(patch)
print(json.dumps({'raw_members':len(raw),'zip_bytes':(target/'raw-capture.zip').stat().st_size,'checks':len(checks)}))
