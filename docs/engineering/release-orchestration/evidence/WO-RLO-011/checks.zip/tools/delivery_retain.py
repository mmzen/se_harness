import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from evolution_cli import REPO

dest = REPO / 'docs/engineering/release-orchestration/evidence/WO-RLO-011'
dest.mkdir(parents=True, exist_ok=True)
label, *command = sys.argv[1:]
assert label and all(c.isalnum() or c in '-_' for c in label)
if (dest / (label + '.json')).exists():
    n = 1
    while (dest / (label + f'-prior-{n}.json')).exists(): n += 1
    for suffix in ('.json', '.stdout.txt', '.stderr.txt'):
        p = dest / (label + suffix)
        if p.exists(): p.rename(dest / (label + f'-prior-{n}' + suffix))
environment = os.environ.copy()
environment.update(GIT_CONFIG_COUNT='2', GIT_CONFIG_KEY_0='safe.directory', GIT_CONFIG_VALUE_0=REPO.as_posix(), GIT_CONFIG_KEY_1='core.longpaths', GIT_CONFIG_VALUE_1='true', PYTHONIOENCODING='utf-8')
begin = datetime.datetime.now(datetime.timezone.utc).isoformat()
proc = subprocess.run(command, cwd=REPO, env=environment, capture_output=True)
for suffix, data in (('.stdout.txt', proc.stdout), ('.stderr.txt', proc.stderr)):
    (dest / (label + suffix)).write_bytes(data)
summary = {'argv': command, 'cwd': str(REPO), 'started_at': begin, 'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit_code':proc.returncode, 'stdout_sha256': hashlib.sha256(proc.stdout).hexdigest(), 'stderr_sha256':hashlib.sha256(proc.stderr).hexdigest()}
(dest / (label + '.json')).write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary))
print(proc.stdout.decode('utf-8', errors='replace')[-4500:])
print(proc.stderr.decode('utf-8', errors='replace')[-6000:])
raise SystemExit(proc.returncode)
