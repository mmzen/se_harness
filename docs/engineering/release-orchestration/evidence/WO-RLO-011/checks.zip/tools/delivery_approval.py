import hashlib
import json
import sys
from pathlib import Path
from evolution_cli import REPO, ROOT, LOG, run

mode = sys.argv[1]
binding = ROOT / 'work/delivery-approval-binding.json'
if mode == 'prepare':
    review = json.loads((ROOT / 'outputs/release-delivery-proposal-review-2026-09-28.json').read_text())
    for record in review['records']:
        assert hashlib.sha256(Path(record['path']).read_bytes()).hexdigest() == record['sha256'], record['id']
    wo = Path(review['records'][-1]['path'])
    content = wo.read_text(encoding='utf-8')
    content = content.replace('[execution_scope]', '[assurance]\ncommit_bound_verification = "required"\nrationale = "Later release closeout relies on the correctness of the reporting code and required procedure; human mmzen confirmed required commit-bound verification on 2026-09-28."\ndecided_by = "mmzen"\n\n[execution_scope]', 1)
    content = content.replace('Human confirmation\nof the classification is pending; no assurance decision-maker is recorded yet.', 'Human mmzen confirmed\nthis classification with "I approve" in response to the exact package and\nrequired-verification approval request on 2026-09-28.')
    wo.write_text(content, encoding='utf-8')
    args = ['transition', str(REPO)]
    for record in review['records']:
        role = 'product-owner' if record['id'].startswith(('CAP-', 'REQ-')) else 'quality-owner' if record['id'].startswith('VER-') else 'engineering-owner'
        current = hashlib.sha256(Path(record['path']).read_bytes()).hexdigest()
        record['apply_sha256'] = current
        reason = ('Human repository owner mmzen: "I approve", responding to the seven-artifact release-delivery package and required commit-bound verification request on 2026-09-28. '
                  f'Reviewed SHA-256 {record["sha256"]}; transition input SHA-256 {current}. '
                  f'Legacy evaluator role {role} records the human decision; Codex applies it. '
                  'Only the confirmed assurance fields and confirmation text were added to WO-RLO-011. Implementation is bounded by that work order; no external action is authorized.')
        args += ['--set', record['id'] + '=approved', '--decision', record['id'] + '=' + role, '--reason', record['id'] + '=' + reason]
    args += ['--json']
    binding.write_text(json.dumps({'records': review['records'], 'args': args}, indent=2) + '\n')
    print('Compared all seven reviewed hashes; recorded only the confirmed assurance input.')
else:
    selected = json.loads(binding.read_text())
    for record in selected['records']:
        assert hashlib.sha256(Path(record['path']).read_bytes()).hexdigest() == record['apply_sha256'], record['id']
    args = selected['args']
    if mode == 'apply':
        preview = json.loads((LOG / 'delivery-approval-preview.stdout').read_text())
        assert preview['operation']['outcome'] in {'completed', 'ready', 'previewed'}, preview['operation']
        args += ['--apply']
    code, result = run('delivery-approval-' + mode, args)
    print(json.dumps({k: result.get(k) for k in ('operation', 'findings', 'state', 'restitution')}, indent=2))
    sys.exit(code)
