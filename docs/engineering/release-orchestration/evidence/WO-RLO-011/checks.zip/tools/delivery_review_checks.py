import ast
import json
import re
from pathlib import Path
from evolution_cli import REPO

guide = REPO / 'docs/notes/release-delivery-completion.md'
links = []
for target in re.findall(r'\]\(([^)]+)\)', guide.read_text(encoding='utf-8')):
    if '://' in target: continue
    path, _, anchor = target.partition('#')
    dest = (guide.parent / path).resolve()
    assert dest.is_relative_to(REPO) and dest.exists(), target
    if anchor:
        slugs = []
        for line in dest.read_text(encoding='utf-8').splitlines():
            if line.startswith('#'):
                title = line.lstrip('#').strip().lower()
                slugs.append(re.sub(r'[^\w\- ]', '', title).replace(' ', '-'))
        assert anchor in slugs, target
    links.append(target)
script = REPO / 'scripts/check_release_delivery.py'
tree = ast.parse(script.read_text(encoding='utf-8'))
imports = []
for node in ast.walk(tree):
    if isinstance(node, ast.Import): imports.extend(alias.name for alias in node.names)
    if isinstance(node, ast.ImportFrom): imports.append(node.module)
assert set(imports) <= {'__future__', 'argparse', 'datetime', 'hashlib', 'json', 'pathlib', 're', 'sys', 'urllib.parse'}
print(json.dumps({'new_guide_links':links, 'resolved':True, 'candidate_imports':imports,
                  'boundary_inspection':'Only standard-library local reading/reporting; no network, subprocess or file mutation API in candidate.',
                  'limitations':'Static inspection complements tests; it is not a general sandbox or authenticity check.'}, indent=2))
