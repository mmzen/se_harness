# Release delivery correction: prepared artifact package

Prepared on 2026-09-28 on local branch `plan/release-delivery-completion`.

The approved plan has been translated into seven draft artifacts. This is the first phase: fix the release procedure and its completion check, then use it for the marketplace and documentation corrections. No implementation or publication has started.

## Proposed result

- Declare evaluator, marketplace, current documentation, demonstration and release-marker dispositions before publication.
- Preserve the evaluator → public wheel → plugin assembly → qualification → authorized publication → public installation/update sequence, with owned handoffs.
- Compare exact identities and retained evidence through one read-only repository script.
- Report formal release state, evaluator publication and overall delivery separately. Missing or deferred marketplace work leaves delivery incomplete.

## Exact package for approval

| Artifact | Purpose | Proposed state |
| --- | --- | --- |
| [CAP-RLO-004](C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/se_harness/docs/engineering/release-orchestration/capabilities/CAP-RLO-004.md) | Track delivery across all release surfaces | approved |
| [REQ-RLO-018](C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/se_harness/docs/engineering/release-orchestration/requirements/REQ-RLO-018.md) | Declare every delivery surface and outstanding handoff | approved |
| [REQ-RLO-019](C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/se_harness/docs/engineering/release-orchestration/requirements/REQ-RLO-019.md) | Check delivery identity and public availability | approved |
| [REQ-RLO-020](C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/se_harness/docs/engineering/release-orchestration/requirements/REQ-RLO-020.md) | Report delivery completion without granting authority | approved |
| [SPEC-RLO-006](C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/se_harness/docs/engineering/release-orchestration/specifications/SPEC-RLO-006.md) | Repository delivery planning and completion checks | approved |
| [VER-RLO-008](C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/se_harness/docs/engineering/release-orchestration/verification/VER-RLO-008.md) | Release delivery completion and handoff verification | approved |
| [WO-RLO-011](C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/se_harness/docs/engineering/release-orchestration/work-orders/WO-RLO-011.md) | Add release delivery completion procedure and checks | approved |

Reuse the accepted INT-RLO-001 without changes. No accepted definition or historical release record is amended.

## Bounded implementation

Add `scripts/check_release_delivery.py`, its focused test suite and fixtures, and `docs/notes/release-delivery-completion.md`. Update only the release-completion and handoff text in `docs/notes/developing-se-harness.md` and `docs/notes/plugin-marketplace-publication.md`. The work order contains exact paths and the boundaries for new evidence and verification records.

The script consumes local, hash-bound evidence. It does not independently perform host tests or validate human judgments. Its report must state that limitation. It changes no formal state, public ref, host profile or credential setting.

The next plugin version, package correction, broader guide cleanup, push/PR, merge and publication are outside this work order. PR #494 remains separate; this branch starts at its current head.

## Verification

VER-RLO-008 defines seven cases: complete delivery; the current missing-marketplace failure; equal version with different bytes; public fresh/update evidence; malformed or inaccessible inputs; absence of side effects; and an executable guide review. Existing release-orchestration and dashboard-publication regressions also run.

**Proposed assurance: required commit-bound verification.** Future completion decisions rely on this reporting code and procedure. The final VREC will bind one clean implementation commit and retained evidence; its acceptance remains a later human decision.

## Checks performed

- Released evaluator 0.19.0 identity passed; repository doctor passed.
- Artifact validation passed: zero errors and zero authoring advisories. The 52 existing maintenance warnings are unrelated to this package.
- Checkpoint-free check found no selected-scope blocker; WO-RLO-011 remains draft.
- Approval checkpoint stopped on `QGS-ASSURANCE`: a complete human-confirmed assurance classification is required before approval.
- No lifecycle transition, implementation test, push or publication was performed.

## Remaining decision

Approve the seven listed artifacts and confirm required commit-bound verification for WO-RLO-011. The prior plan approval is retained; this decision covers the newly specified path scope and assurance contract. After it is supplied, record the assurance classification, preview the exact approval packet, apply only passing transitions, and continue the approved work.

The current evaluator next step is `PROC-FOCUS-SELECTED / STEP-FOCUS-SELECTED`: supply the corrective input for `QGS-ASSURANCE`. This report does not replace that result with an inferred approval.

The selected draft-work-order procedure states: “If the assurance classification has not been confirmed, present it as a proposal in the review handoff.” It also says to record the human decision before previewing approval. [Source](C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/se_harness/docs/engineering/harness/DRAFT_WORK_ORDERS.md).

The Verity Plane change skill requires definition decisions to match the exact reviewed IDs, target states and file hashes. [Skill](C:/Users/mathi/.codex/plugins/cache/se-harness/verity-plane/0.2.0/skills/change/SKILL.md); [continuing-authority rule](C:/Users/mathi/.codex/plugins/cache/se-harness/verity-plane/0.2.0/skills/change/references/authority.md).

Continue the previously accepted 0.19.0 role-label encoding when the evaluator requires it; retain mmzen as the actual human decision-maker in the reason. No actor label supplies authority.

## Reviewed bytes

[Machine-readable review and complete SHA-256 values](C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/outputs/release-delivery-proposal-review-2026-09-28.json)

| Artifact | SHA-256 |
| --- | --- |
| CAP-RLO-004 | `f4bdd5e9a19f9b1913336a3d8db6e801a083f2ce976c17bdf119bfddd007abf3` |
| REQ-RLO-018 | `c793c7622ef3c4fd666d5e6d43f2def577a41a2c5d98df12ac8366a7f01b3ce4` |
| REQ-RLO-019 | `d86eadf49538b2affdcde226c1bed1f9074b864eac570d9c0cc9334daf66d538` |
| REQ-RLO-020 | `742575e8789d4693a248a27cb90196995b4eaa92187e4a1eee598acf6db04774` |
| SPEC-RLO-006 | `93f82e8118171632319744149ce945617e493ea853134fc505debdd1bf23736a` |
| VER-RLO-008 | `120acb98ef1615017295693cc0aaef6705fbf1f8821a04b5fda270916701ffde` |
| WO-RLO-011 | `01f4390678f4c8c6130b5d5fe6de2acfbb5ffa0aaccb383cc4a069449439f85a` |
