from pathlib import Path
import json, os, subprocess, sys, time

output=Path(__file__).resolve().parent/'complete-release-approval'
argv=[sys.executable,'-B','-X','utf8','scripts/run_tests.py','--workers','4']
started=time.time()
# Capture needs canonical checkout bytes. That evaluator-only Git override must
# not replace the ordinary Windows Git configuration inside unrelated fixtures.
env=os.environ.copy()
assert env.get('GIT_CONFIG_KEY_1') == 'core.autocrlf'
env['GIT_CONFIG_COUNT']='1'
env.pop('GIT_CONFIG_KEY_1',None)
env.pop('GIT_CONFIG_VALUE_1',None)
result=subprocess.run(argv,env=env,capture_output=True,text=True,encoding='utf-8')
(output/'capture-full-tests.stdout.txt').write_text(result.stdout,encoding='utf-8')
(output/'capture-full-tests.stderr.txt').write_text(result.stderr,encoding='utf-8')
(output/'capture-full-tests.run.json').write_text(json.dumps({'argv':argv,'cwd':str(Path.cwd()),'exit_code':result.returncode,'seconds':time.time()-started,'git_config_count':env.get('GIT_CONFIG_COUNT'),'test_environment':'Removed only the capture-injected core.autocrlf override; normal workstation configuration retained; no global Git change.'},indent=2)+'\n',encoding='utf-8')
print('Actual test command: '+json.dumps(argv),flush=True)
print(result.stdout,flush=True)
print(result.stderr,flush=True)
raise SystemExit(result.returncode)
