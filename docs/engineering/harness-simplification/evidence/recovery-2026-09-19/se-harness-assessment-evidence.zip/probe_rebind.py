import contextlib, hashlib, io, json, subprocess, sys
from pathlib import Path
from se_harness.cli import main
from se_harness.workflow_evidence_packet import parse_evidence_header
root=Path(sys.argv[1]).resolve()
results=[]
def cli(*args):
    out, err=io.StringIO(),io.StringIO()
    with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
        code=main(list(args))
    try: value=json.loads(out.getvalue())
    except ValueError: value=out.getvalue()
    results.append({'argv':list(args),'exit_code':code,'output':value,'stderr':err.getvalue()})
    return code
wo=root/'docs/engineering/product/work-orders/WO-AUD-001.md'
wo.write_text(wo.read_text().replace('evidence_paths = ["docs/engineering/product/evidence/WO-AUD-001-verification.md"]\n',''),encoding='utf-8')
(root/'src/outside.py').write_text('outside = 1\n',encoding='utf-8')
cli('evidence',str(root),'--artifact','WO-AUD-001','--checkpoint','handoff','--json')
packet=root/'docs/engineering/product/evidence/WO-AUD-001/WO-AUD-001-handoff.md'
with packet.open('ab') as f: f.write(b'\nFAIL: Tests did not run. This body is stale and supplies no passing result.\n')
before_header,before_body=parse_evidence_header(packet.read_bytes())
for args in [('add','.'),('commit','-m','Disposable packet baseline')]:
    run=subprocess.run(['git','-C',str(root),*args],capture_output=True,text=True)
    assert run.returncode==0,run.stderr
(root/'src/exact.py').write_text('value = 999\n',encoding='utf-8')
cli('check',str(root),'--artifact','WO-AUD-001','--json')
cli('check',str(root),'--artifact','WO-AUD-001','--checkpoint','handoff','--from-git','HEAD','--json')
after_header,after_body=parse_evidence_header(packet.read_bytes())
results.append({'observation':'rebind','header_changed':before_header!=after_header,'body_identical':before_body==after_body,'before_header':before_header,'after_header':after_header,'body_sha256':hashlib.sha256(after_body).hexdigest(),'body':after_body.decode()})
Path(sys.argv[2]).write_text(json.dumps(results,indent=2),encoding='utf-8')
for r in results:
    print(json.dumps({k:v for k,v in r.items() if k!='output'}))
