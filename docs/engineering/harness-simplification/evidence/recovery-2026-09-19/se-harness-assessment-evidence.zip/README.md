# Assessment evidence

Observed 2026-09-16. Source commit f05c478a29c39f94968fdc842a34c861d30a42ac.
Released evaluator: se-harness 0.18.0, installed into a private venv from PyPI.
Candidate source: version 0.19.0. Platform: Windows, Python 3.14.6.

All mutation probes operate on fresh disposable fixtures outside the reviewed
clone. They do not patch approval, preflight, evidence, or mutation guards.
The repository's tests.artifact_support helper supplies synthetic fixture inputs.

## Reproduce

Create a private environment and install se-harness==0.18.0. Use its Python:

    python -I probe_harness.py REPOSITORY NEW_FIXTURE_DIRECTORY RESULTS_JSON released
    python -I probe_rebind.py FIXTURE_DIRECTORY REBIND_RESULTS_JSON

The second command extends the first command's fixture. NEW_FIXTURE_DIRECTORY
must not already exist. For candidate read-only probe outcomes, run with source
Python and replace the final argument with candidate. Candidate mode does not
apply lifecycle transitions.

The first exploratory run used the test helper's legacy WO-001 spelling and was
blocked by preflight's public work-order ID grammar. Its raw result is retained
as exploratory/probes-released.json. The corrected script changes it to
WO-AUD-001; probes-released-v2.json is the final released result.

Focused tests (run from the source checkout):

    python -m unittest tests.test_workflow_execution tests.test_workflow_compliance tests.test_authoring_gate tests.test_instruction_architecture tests.test_workflow_documentation_contract

158 tests ran; one was skipped; no failures. This is not a full-suite result.

The live control responses came from read-only gh api requests to the ruleset,
effective main rules, PyPI environment and deployment-branch-policy endpoints.
No server settings or repository records were changed.
