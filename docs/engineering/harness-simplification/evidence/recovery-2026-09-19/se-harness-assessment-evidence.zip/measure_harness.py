import json, os, sys
from pathlib import Path
from collections import Counter
from se_harness.engine.validate_engineering_artifacts import validate_repository
from se_harness.preflight import run_preflight
root=Path(sys.argv[1]).resolve()
os.environ['GIT_CONFIG_COUNT']='1'
os.environ['GIT_CONFIG_KEY_0']='safe.directory'
os.environ['GIT_CONFIG_VALUE_0']=root.as_posix()
report=validate_repository(root)
result={'artifacts':len(report.artifacts),'types':dict(Counter(x.artifact_type for x in report.artifacts)), 'errors':len(report.errors),'warnings':len(report.warnings),'manifests':[], 'instruction_files':[]}
for wo in ['WO-CIP-006','WO-DST-023','WO-KIS-009']:
    p=run_preflight(root, work_order_id=wo,phase='review',report=report)
    entries=[{'path':str(x),'bytes':len((root/x).read_bytes())} for x in p.reading_manifest]
    result['manifests'].append({'work_order':wo,'ready':p.ready,'files':len(entries),'bytes':sum(x['bytes'] for x in entries),'entries':entries})
for f in ['AGENTS.md','ENGINEERING_HARNESS.md','docs/engineering/OPERATING_CARD.md','docs/engineering/WORKFLOW.md','docs/engineering/DECISION_RIGHTS.md','docs/engineering/QUALITY_GATES.md','docs/engineering/TRACEABILITY.md','docs/engineering/ARTIFACT_AUTHORING.md','docs/engineering/TECHNICAL_COMMUNICATION.md']:
    raw=(root/f).read_bytes()
    result['instruction_files'].append({'path':f,'bytes':len(raw),'lines':len(raw.splitlines())})
print(json.dumps(result,indent=2))
