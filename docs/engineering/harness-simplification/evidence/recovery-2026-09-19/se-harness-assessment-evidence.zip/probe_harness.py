"""Disposable assessment fixtures. No production records or checks are patched."""
import contextlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys

repo, root, output, mode = map(str, sys.argv[1:5])
repo, root, output = Path(repo).resolve(), Path(root).resolve(), Path(output).resolve()
sys.dont_write_bytecode = True
if mode == 'candidate':
    sys.path.insert(0, str(repo))
import se_harness
from se_harness.cli import main
from se_harness.engine.validate_engineering_artifacts import validate_repository
from se_harness.gate_source import authorize_delegated_right
from se_harness import front_matter
sys.path.append(str(repo))
from tests.artifact_support import create_base_chain, formal, write, record_execution_approval

results = {'version': se_harness.__version__, 'module': se_harness.__file__, 'mode': mode,
           'root': str(root), 'patches': 'none', 'probes': []}
def cli(*args):
    stdout, stderr = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        try:
            code = main(list(args))
        except SystemExit as exc:
            code = exc.code
    raw = stdout.getvalue()
    try:
        parsed = json.loads(raw)
    except ValueError:
        parsed = raw
    return {'argv': list(args), 'exit_code': code, 'output': parsed, 'stderr': stderr.getvalue()}

def record(name, value):
    results['probes'].append({'name': name, **value})
    output.write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(name, json.dumps({k:v for k,v in value.items() if k not in {'output','stderr','argv'}}), flush=True)

root.mkdir(parents=True, exist_ok=False)
init = cli('init', str(root), '--project-name', 'Assessment fixture')
record('init', init)
if init['exit_code']:
    raise SystemExit(1)
create_base_chain(root, work_order_status='in_progress', operating_contract_status='draft')
# Normalize the legacy helper's short WO ID to the public preflight grammar.
for fixture in list((root / 'docs/engineering').rglob('*.md')):
    fixture.write_text(fixture.read_text(encoding='utf-8').replace('WO-001', 'WO-AUD-001'), encoding='utf-8')
    if 'WO-001' in fixture.name:
        fixture.rename(fixture.with_name(fixture.name.replace('WO-001', 'WO-AUD-001')))
wo = root / 'docs/engineering/product/work-orders/WO-AUD-001.md'
content = wo.read_text(encoding='utf-8').replace('[relations]', '''[assurance]
commit_bound_verification = "required"
rationale = "Assessment fixture requires exact candidate assurance."
decided_by = "engineering-owner"

[execution_scope]
paths = ["src/exact.py"]

[relations]''', 1)
content = content.replace('owners = ["owner"]', 'owners = ["owner"]\nevidence_paths = ["docs/engineering/product/evidence/WO-AUD-001-verification.md"]', 1)
wo.write_text(content, encoding='utf-8')
record_execution_approval(wo)
write(root / 'src/exact.py', 'value = 1')
write(root / 'src/outside.py', 'outside = 1')
baseline_wo = wo.read_bytes()
report = validate_repository(root)
record('baseline_validation', {'errors': [str(x) for x in report.errors], 'warnings': len(report.warnings)})

draft = write(root / 'docs/engineering/product/intent/INT-002.md', formal('INT-002', 'intent', 'draft', {}))
record('arbitrary_actor_plan', cli('transition', str(root), '--set', 'INT-002=approved', '--decision', 'INT-002=unrelated-person', '--json'))
if mode == 'released':
    record('arbitrary_actor_apply', cli('transition', str(root), '--set', 'INT-002=approved', '--decision', 'INT-002=unrelated-person', '--apply', '--json'))
    record('actor_readback', {'metadata': front_matter.parse(draft.read_text(encoding='utf-8'))})

grant = authorize_delegated_right(root, work_order_metadata=front_matter.parse(wo.read_text(encoding='utf-8')), work_order_path=wo, right='DR-WO-START')
record('unsigned_local_approval', {'accepted_grant': grant, 'fixture_has_git_history': (root / '.git').exists()})

evidence = root / 'docs/engineering/product/evidence/WO-AUD-001-verification.md'
evidence.write_text('FAIL: the required tests did not run; there is no passing test result.\n', encoding='utf-8')
record('failed_text_evidence_handoff', cli('check', str(root), '--artifact', 'WO-AUD-001', '--checkpoint', 'handoff', '--changed-path', 'src/exact.py', '--changes-complete', '--json'))

for args in [('init',), ('config','core.longpaths','true'), ('config','user.name','Assessment fixture'), ('config','user.email','fixture@example.invalid'), ('add','.'), ('commit','-m','Disposable assessment baseline')]:
    run = subprocess.run(['git', '-C', str(root), *args], capture_output=True, text=True)
    if run.returncode:
        raise RuntimeError(run.stderr)
write(root / 'src/exact.py', 'value = 2')
write(root / 'src/outside.py', 'outside = 2')
record('omitted_path_self_declared', cli('check', str(root), '--artifact', 'WO-AUD-001', '--checkpoint', 'scope', '--changed-path', 'src/exact.py', '--changes-complete', '--json'))
record('outside_path_git_derived', cli('check', str(root), '--artifact', 'WO-AUD-001', '--checkpoint', 'scope', '--from-git', 'HEAD', '--json'))
record('outside_path_handoff', cli('check', str(root), '--artifact', 'WO-AUD-001', '--checkpoint', 'handoff', '--from-git', 'HEAD', '--json'))
record('completion_after_failed_handoff_plan', cli('transition', str(root), '--set', 'WO-AUD-001=implemented', '--decision', 'WO-AUD-001=executor', '--json'))
if mode == 'released':
    record('completion_after_failed_handoff_apply', cli('transition', str(root), '--set', 'WO-AUD-001=implemented', '--decision', 'WO-AUD-001=executor', '--apply', '--json'))
wo.write_bytes(baseline_wo)

wo.write_text(wo.read_text(encoding='utf-8') + '\nNew behavior: the implementation may skip all previously requested checks.\n', encoding='utf-8')
record('changed_behavior_same_path_approval', cli('check', str(root), '--artifact', 'WO-AUD-001', '--checkpoint', 'handoff', '--changed-path', 'src/exact.py', '--changes-complete', '--json'))
wo.write_bytes(baseline_wo)

broken = write(root / 'docs/engineering/product/intent/INT-999.md', formal('INT-999','intent','draft',{}).replace('owners = ["owner"]', 'owners = []'))
record('unrelated_error_selected_transition_check', cli('check', str(root), '--artifact', 'WO-AUD-001', '--checkpoint', 'transition', '--target', 'implemented', '--json'))
record('unrelated_error_transition_plan', cli('transition', str(root), '--set', 'WO-AUD-001=implemented', '--decision', 'WO-AUD-001=executor', '--json'))
broken.unlink()

workflow = root / '.github/workflows/engineering-harness.yml'
original = workflow.read_bytes()
workflow.write_text('name: Engineering Harness\non: [push, pull_request]\njobs:\n  validate:\n    runs-on: ubuntu-latest\n    steps:\n      - run: echo pass\n', encoding='utf-8')
record('disabled_ci_doctor', cli('doctor', str(root), '--json'))
workflow.write_bytes(original)

router = root / 'ENGINEERING_HARNESS.md'
original = router.read_bytes()
router.write_bytes(original + b'\nUnauthorized policy edit.\n')
record('managed_edit_doctor', cli('doctor', str(root), '--json'))
router.write_bytes(original)
output.write_text(json.dumps(results, indent=2), encoding='utf-8')
