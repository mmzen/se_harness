import contextlib
import hashlib
import importlib.util
import json
import os
import pathlib
import platform
import sys
import traceback
import unittest

test_path, mode, selection, output = sys.argv[1:]
test_path = pathlib.Path(test_path).resolve()
checkout = test_path.parents[1]
evidence = pathlib.Path(output).resolve()
assert not evidence.is_relative_to(checkout)
evidence.mkdir(parents=True, exist_ok=True)
assert mode in ("source", "package") and selection in ("smoke", "full")
os.environ["SE_HARNESS_OWNERSHIP_PACKAGE"] = "1" if mode == "package" else "0"
os.environ["SE_HARNESS_OWNERSHIP_EVIDENCE"] = str(evidence / "cases")
if os.environ.get("GITHUB_SHA"):
    os.environ["SE_HARNESS_OWNERSHIP_COMMIT"] = os.environ["GITHUB_SHA"]
if mode == "source":
    sys.path.insert(0, str(checkout))
wheel = pathlib.Path(os.environ["SE_HARNESS_OWNERSHIP_WHEEL"])
facts = {
    "schema": "se-harness-skill-ownership-ci-v1",
    "status": "incomplete", "mode": mode, "selection": selection,
    "argv": sys.orig_argv, "python": sys.version, "python_executable": sys.executable,
    "isolated": sys.flags.isolated, "platform": platform.platform(),
    "runner_os": os.environ.get("RUNNER_OS"),
    "runner_image": os.environ.get("ImageOS"),
    "runner_image_version": os.environ.get("ImageVersion"),
    "candidate_commit": os.environ.get("GITHUB_SHA"),
    "head_commit": os.environ.get("REHEARSAL_HEAD_SHA"),
    "run_id": os.environ.get("GITHUB_RUN_ID"),
    "run_attempt": os.environ.get("GITHUB_RUN_ATTEMPT"),
    "wheel_name": wheel.name,
    "wheel_sha256": hashlib.sha256(wheel.read_bytes()).hexdigest(),
    "test_module_sha256": hashlib.sha256(test_path.read_bytes()).hexdigest(),
    "source_inventory_sha256": hashlib.sha256(pathlib.Path(os.environ["SE_HARNESS_OWNERSHIP_SOURCE_MANIFEST"]).read_bytes()).hexdigest(),
    "source_archive_sha256": hashlib.sha256(pathlib.Path(os.environ["SE_HARNESS_OWNERSHIP_SDIST"]).read_bytes()).hexdigest(),
    "promotable": False,
}
runtime_path = evidence / "runtime.json"
runtime_path.write_text(json.dumps(facts, indent=2, sort_keys=True) + "\n", encoding="utf-8")
passed = False
try:
    with (evidence / "test-output.log").open("w", encoding="utf-8") as log:
        with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
            import se_harness
            imported = pathlib.Path(se_harness.__file__).resolve()
            facts["imported_evaluator"] = str(imported)
            facts["candidate_version"] = se_harness.__version__
            if mode == "package":
                assert sys.flags.isolated, "installed acceptance requires -I"
                assert imported.is_relative_to(pathlib.Path(sys.prefix).resolve())
                assert not imported.is_relative_to(checkout), "checkout evaluator imported"
            else:
                assert imported.is_relative_to(checkout), "source evaluator was shadowed"
            spec = importlib.util.spec_from_file_location("ownership_acceptance", test_path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = module
            spec.loader.exec_module(module)
            suite = module.acceptance_suite(smoke=selection == "smoke")
            result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
            passed = result.wasSuccessful() and result.testsRun > 0
            facts.update(status="pass" if passed else "fail", tests=result.testsRun,
                         failures=len(result.failures), errors=len(result.errors),
                         skipped=[{"test": str(test), "reason": reason} for test, reason in result.skipped])
except BaseException:
    facts["status"] = "error"
    facts["error"] = traceback.format_exc()
    raise
finally:
    runtime_path.write_text(json.dumps(facts, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(facts, sort_keys=True))
raise SystemExit(0 if passed else 1)
