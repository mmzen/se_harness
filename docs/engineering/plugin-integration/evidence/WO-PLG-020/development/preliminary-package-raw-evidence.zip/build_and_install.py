from pathlib import Path
import hashlib, json, os, subprocess, sys, time, tomllib
control = Path(__file__).resolve().parent
source = control.parents[1] / 'w20s'
manifest = json.loads((control/'source-manifest.json').read_bytes())
assert manifest['candidate_commit'] is None and manifest['promotable'] is False
build_python = control/'build-env'/'Scripts'/'python.exe'
candidate_python = control/'candidate-env'/'Scripts'/'python.exe'
backend = control/'build-tools'/'setuptools-84.0.0-py3-none-any.whl'
assert hashlib.sha256(backend.read_bytes()).hexdigest() == '51a52592b3b99e102b609654876bd65f19f999935166d1352678931132b0c670'
env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONPATH='')
commands = []
def run(name, argv, *, cwd=control, expected=0):
    started = time.time()
    process = subprocess.run([str(x) for x in argv], cwd=cwd, env=env, capture_output=True, timeout=300)
    (control/(name+'.stdout.log')).write_bytes(process.stdout)
    (control/(name+'.stderr.log')).write_bytes(process.stderr)
    commands.append({'name':name,'argv':[str(x) for x in argv],'cwd':str(cwd),'returncode':process.returncode,'seconds':time.time()-started,
                     'stdout_sha256':hashlib.sha256(process.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(process.stderr).hexdigest()})
    (control/'commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf-8')
    print(name, 'exit', process.returncode, flush=True)
    if process.returncode != expected:
        raise RuntimeError(name+' failed; inspect retained stdout/stderr')
    return process
run('install-build-backend',[build_python,'-m','pip','install','--disable-pip-version-check','--no-index','--no-deps',backend])
out = control/'dist'
out.mkdir()
run('build-one-preliminary-wheel',[build_python,'-I','-B','-c','import sys; from setuptools.build_meta import build_wheel; print(build_wheel(sys.argv[1]))',out],cwd=source)
run('build-preliminary-sdist',[build_python,'-I','-B','-c','import sys; from setuptools.build_meta import build_sdist; print(build_sdist(sys.argv[1]))',out],cwd=source)
wheels = list(out.glob('*.whl'))
sdists = list(out.glob('*.tar.gz'))
assert len(wheels)==len(sdists)==1
wheel, sdist = wheels[0], sdists[0]
(out/'SOURCES.txt').write_bytes((source/'se_harness.egg-info'/'SOURCES.txt').read_bytes())
artifacts = {p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in [wheel,sdist,out/'SOURCES.txt']}
(out/'SHA256SUMS').write_text(''.join(item['sha256']+'  '+name+'\n' for name,item in sorted(artifacts.items())),encoding='ascii')
summary = {'schema':'se-harness-preliminary-package-observation-v1','promotable':False,'exact_committed_candidate':False,'candidate_commit':None,
           'base_commit':manifest['base_commit'],'snapshot_manifest_sha256':hashlib.sha256((control/'source-manifest.json').read_bytes()).hexdigest(),
           'source_snapshot':str(source),'artifacts':artifacts,'backend':{'name':backend.name,'sha256':hashlib.sha256(backend.read_bytes()).hexdigest()}}
(control/'package-observation.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n',encoding='utf-8')
run('install-preliminary-candidate',[candidate_python,'-m','pip','install','--disable-pip-version-check','--no-index','--no-deps',wheel])
version = tomllib.loads((source/'pyproject.toml').read_text(encoding='utf-8'))['project']['version']
identity = run('candidate-role-missing-commit',[candidate_python,'-I','-B','-m','se_harness','identity','--role','candidate-package',
               '--expected-version',version,'--expected-root',control/'candidate-env','--checkout-root',source,
               '--entry-point',control/'candidate-env'/'Scripts'/'harnessctl.exe','--require-isolated-python','--require-entry-point','--json'],expected=1)
report = json.loads(identity.stdout)
assert [item['code'] for item in report['diagnostics']] == ['RID015'], report
observation_code = '''import hashlib,json,pathlib,sys; import se_harness; from se_harness.evaluator_identity import installed_evaluator_identity; identity=installed_evaluator_identity(); wheel=pathlib.Path(sys.argv[1]); assert identity.archive_sha256==hashlib.sha256(wheel.read_bytes()).hexdigest(); assert pathlib.Path(se_harness.__file__).resolve().is_relative_to(pathlib.Path(sys.prefix).resolve()); assert sys.flags.isolated; print(json.dumps({"preliminary":True,"promotable":False,"candidate_commit":None,"identity":identity.to_lock(),"module":se_harness.__file__,"prefix":sys.prefix,"python":sys.version,"argv":sys.orig_argv,"isolated":sys.flags.isolated},sort_keys=True))'''
run('installed-content-identity',[candidate_python,'-I','-B','-c',observation_code,wheel])
print(json.dumps(summary,sort_keys=True),flush=True)