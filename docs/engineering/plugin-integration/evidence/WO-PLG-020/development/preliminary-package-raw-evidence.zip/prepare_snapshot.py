from pathlib import Path
import hashlib, json, os, re, stat, subprocess, sys
root = Path(r'C:\Users\hok\Documents\Codex\2026-09-12\clo\work\wo20').resolve()
control = Path(__file__).resolve().parent
snapshot = control.parents[1] / 'w20s'
snapshot.mkdir()
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root)
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
entries = {}
for raw in git('ls-files', '--stage', '-z').split(b'\0'):
    if not raw: continue
    prefix, name = raw.decode('utf-8').split('\t', 1)
    mode, oid, stage = prefix.split()
    if stage != '0' or mode not in {'100644','100755'}:
        raise RuntimeError(f'unsupported tracked entry {name}: {prefix}')
    entries[name] = {'mode': mode, 'index_blob': oid, 'tracked': True}
allowed_untracked = {'se_harness/skill_ownership.py', 'se_harness/skill_ownership_contract.json', 'tests/test_skill_ownership.py'}
for raw in git('ls-files', '--others', '--exclude-standard', '-z').split(b'\0'):
    if not raw: continue
    name = raw.decode('utf-8')
    if name not in allowed_untracked and not name.startswith('tests/fixtures/skill_ownership/'):
        raise RuntimeError(f'unapproved untracked file {name}')
    entries[name] = {'mode': '100644', 'index_blob': None, 'tracked': False}
eols = {}
for args in [('ls-files','--eol','-z'), ('ls-files','--eol','--others','--exclude-standard','-z')]:
    for raw in git(*args).split(b'\0'):
        if not raw: continue
        eol, name = raw.decode('utf-8').split('\t',1)
        eols[name] = eol.strip()
for name, metadata in sorted(entries.items()):
    if any(part in {'.git','target','__pycache__'} or part.endswith('.egg-info') for part in Path(name).parts):
        raise RuntimeError(f'excluded output/metadata path is tracked: {name}')
    source = root / name
    info = source.lstat()
    if not stat.S_ISREG(info.st_mode) or getattr(info,'st_file_attributes',0) & 1024:
        raise RuntimeError(f'non-ordinary input {name}')
    raw = source.read_bytes()
    eol = eols[name]
    text = 'w/-text' not in eol and 'attr/-text' not in eol
    normalized = raw.replace(b'\r\n',b'\n') if text else raw
    destination = snapshot / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(normalized)
    if source.read_bytes() != raw:
        raise RuntimeError(f'input changed while snapshotting: {name}')
    metadata.update(source_sha256=sha(raw),snapshot_sha256=sha(normalized),bytes=len(normalized),git_eol=eol,normalized_crlf=text and raw != normalized)
manifest = {'schema':'se-harness-preliminary-content-snapshot-v1','promotable':False,'exact_committed_candidate':False,
 'source_repository':str(root),'base_commit':git('rev-parse','HEAD').decode().strip(),'candidate_commit':None,
 'source_status':git('status','--porcelain=v1','--untracked-files=all').decode(),'normalization':'Git text files CRLF to LF; binary/-text bytes retained',
 'files':dict(sorted(entries.items()))}
raw = (json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
(control/'source-manifest.json').write_bytes(raw)
(control/'source-manifest.sha256').write_text(sha(raw)+'\n',encoding='ascii')
print(json.dumps({'snapshot':str(snapshot),'files':len(entries),'manifest_sha256':sha(raw),'candidate_commit':None,'base_commit':manifest['base_commit']},sort_keys=True))