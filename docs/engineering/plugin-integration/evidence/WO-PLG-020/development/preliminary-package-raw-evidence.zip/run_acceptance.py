from pathlib import Path
import hashlib, json, os, subprocess, sys, time
control = Path(__file__).resolve().parent
source = control.parents[1]/'w20s'
candidate_python = control/'candidate-env'/'Scripts'/'python.exe'
wheel = next((control/'dist').glob('*.whl'))
sdist = next((control/'dist').glob('*.tar.gz'))
manifest_sha = hashlib.sha256((control/'source-manifest.json').read_bytes()).hexdigest()
workflow = (source/'.github/workflows/candidate-evidence.yml').read_text(encoding='utf-8')
runner = workflow.split("          @'\n",1)[1].split("          '@ |",1)[0]
runner = '\n'.join(line[10:] if line.startswith('          ') else line for line in runner.splitlines())+'\n'
runner = runner.replace('"schema": "se-harness-skill-ownership-ci-v1",', '"schema": "se-harness-skill-ownership-preliminary-v1",\n    "preliminary_content_snapshot": True, "exact_committed_candidate": False,\n    "snapshot_manifest_sha256": '+repr(manifest_sha)+',')
compile(runner,'preliminary-acceptance-runner','exec')
runner_path = control/'run-preliminary-acceptance.py'
runner_path.write_text(runner,encoding='utf-8')
env = dict(os.environ,PYTHONNOUSERSITE='1',PYTHONPATH='',PYTHONDONTWRITEBYTECODE='1',
           SE_HARNESS_OWNERSHIP_WHEEL=str(wheel),SE_HARNESS_OWNERSHIP_SDIST=str(sdist),
           SE_HARNESS_OWNERSHIP_SOURCE_MANIFEST=str(control/'dist'/'SOURCES.txt'),
           SE_HARNESS_OWNERSHIP_LEGACY_PYTHON=str(control.parents[1]/'evaluator-017'/'Scripts'/'python.exe'))
for key in ('GITHUB_SHA','REHEARSAL_HEAD_SHA','SE_HARNESS_OWNERSHIP_COMMIT'):
    env.pop(key,None)
commands=[]
def run(name,argv,*,cwd=control,timeout=1800):
    started=time.time()
    result=subprocess.run([str(x) for x in argv],cwd=cwd,env=env,capture_output=True,timeout=timeout)
    (control/(name+'.stdout.log')).write_bytes(result.stdout)
    (control/(name+'.stderr.log')).write_bytes(result.stderr)
    commands.append({'name':name,'argv':[str(x) for x in argv],'cwd':str(cwd),'returncode':result.returncode,'seconds':time.time()-started,
                     'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
    (control/'acceptance-commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf-8')
    print(name,'exit',result.returncode,flush=True)
    if result.returncode:
        raise RuntimeError(name+' failed; retained stdout/stderr and case evidence')
run('package-inventory',[sys.executable,'-B','-m','unittest','tests.test_integration_package.OwnershipDistributionInventoryTests','-v'],cwd=source)
run('installed-smoke',[candidate_python,'-I','-B',runner_path,source/'tests/test_skill_ownership.py','package','smoke',control/'package-smoke'])
run('installed-full',[candidate_python,'-I','-B',runner_path,source/'tests/test_skill_ownership.py','package','full',control/'package-full'])
print('Preliminary package acceptance finished; no commit-bound candidate claimed',flush=True)