"""Disposable released-0.17 writer probe. Never modifies the source checkout."""
from __future__ import annotations
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

PROBE = Path(__file__).resolve().parent
BASE = PROBE / "final-valid"
BASE.mkdir()
CHECKOUT = PROBE.parent.parent / "wo20"
LEGACY = PROBE.parent.parent / "evaluator-017" / "Scripts" / "python.exe"
WHEEL = PROBE / "final-wheel-dist" / "se_harness-0.18.0-py3-none-any.whl"
os.environ["SE_HARNESS_OWNERSHIP_PACKAGE"] = "1"
os.environ["SE_HARNESS_OWNERSHIP_WHEEL"] = str(WHEEL)
spec = importlib.util.spec_from_file_location("ownership_probe_fixture", CHECKOUT / "tests" / "test_skill_ownership.py")
support = importlib.util.module_from_spec(spec)
spec.loader.exec_module(support)

from se_harness import __version__, installer, skill_ownership
from se_harness.artifact_layout import create_artifact
from se_harness.evaluator_identity import installed_evaluator_identity
import se_harness

def save(name, value):
    (BASE / name).write_bytes((json.dumps(value, sort_keys=True, indent=2) + "\n").encode())

fixture = support.SkillOwnershipAcceptanceTests()
fixture.base = BASE / "fixture"
fixture.base.mkdir()
fixture.root = fixture.base / "repository"
fixture.identity = installed_evaluator_identity()
fixture.wheel_bytes = WHEEL.read_bytes()
assert fixture.identity.archive_sha256 == support.sha(fixture.wheel_bytes)
assert not Path(se_harness.__file__).resolve().is_relative_to(CHECKOUT)
changes, old = installer.plan_install(fixture.root, project_name="legacy-writer-probe", mode="init")
installer.apply_changes(fixture.root, changes, old, allow_updates=False)
created = create_artifact(fixture.root, domain="legacy-probe", artifact_type="work_order", artifact_id="WO-LEG-001", dry_run=False)
draft = fixture.root / created.path
draft_raw = draft.read_text(encoding="utf-8")
for old, new in [('<Bounded implementation objective>', 'Disposable legacy writer probe'),
                 ('<engineering owner>', 'fixture engineering owner'),
                 ('<required or not_required>', 'required'),
                 ('["REQ-xxx"]', '["REQ-LEG-001"]'), ('["SPEC-xxx"]', '["SPEC-LEG-001"]'), ('["VER-xxx"]', '["VER-LEG-001"]')]:
    draft_raw = draft_raw.replace(old, new)
draft.write_text(draft_raw, encoding="utf-8", newline="\n")
artifact_spec = importlib.util.spec_from_file_location("artifact_probe_fixture", CHECKOUT / "tests" / "artifact_support.py")
artifact_support = importlib.util.module_from_spec(artifact_spec)
artifact_spec.loader.exec_module(artifact_support)
for folder, identifier, kind, relations, extra in [
    ("intent", "INT-LEG-001", "intent", {}, ""),
    ("capabilities", "CAP-LEG-001", "capability", {"derives_from": ["INT-LEG-001"]}, ""),
    ("requirements", "REQ-LEG-001", "requirement", {"derives_from": ["CAP-LEG-001"]}, 'statement = "THE SYSTEM SHALL retain the test observation."\nverification_method = "automated-test"'),
    ("specifications", "SPEC-LEG-001", "specification", {"specifies": ["REQ-LEG-001"]}, ""),
    ("verification", "VER-LEG-001", "verification", {"verifies": ["REQ-LEG-001"]}, ""),
]:
    artifact_support.write(fixture.root / "docs/engineering/legacy-probe" / folder / (identifier + ".md"),
                           artifact_support.formal(identifier, kind, "draft", relations, extra))
fixture.plugins = {}
fixture.binding_path = fixture.base / "binding.json"
fixture.binding = fixture.make_binding(("codex", "claude"))
fixture.write_binding()
plan = skill_ownership.plan_skill_ownership(fixture.root, provider="plugin", binding_input=fixture.binding_path)
assert plan["passed"], plan
migration = skill_ownership.apply_skill_ownership(fixture.root, provider="plugin", binding_input=fixture.binding_path, expected_plan_sha256=plan["plan_sha256"])
assert migration["passed"], migration
save("fixture-setup.json", {"script_sha256": support.sha(Path(__file__).read_bytes()), "candidate_python": sys.executable,
    "candidate_version": __version__, "candidate_module": se_harness.__file__, "candidate_identity": fixture.identity.to_lock(),
    "candidate_wheel": str(WHEEL), "candidate_wheel_sha256": support.sha(fixture.wheel_bytes),
    "provenance_limit": "Final CI wheel for merge commit 5e9570d0d679ce551a1c436681de51193bc1e483, whose tree equals PR head 1e062e4db06b6e7131429db15b3d6b9876e600db, artifact 10299474643; SHA independently verified before installation. This focused probe is supplementary, not a replacement for qualification.",
    "fixture_support": str(CHECKOUT / "tests" / "test_skill_ownership.py"), "created_artifact": created.__dict__,
    "migration_plan": plan, "migration_result": migration})

def run(name, python, args):
    argv = [str(python), "-I", "-B", "-m", "se_harness", *args]
    before = support.snapshot(fixture.base)
    before_bytes = {p: (fixture.base / p).read_bytes() for p, item in before.items() if item["kind"] == "file"}
    result = subprocess.run(argv, cwd=BASE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=120)
    after = support.snapshot(fixture.base)
    changed = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
    output = BASE / name
    output.mkdir()
    (output / "stdout.bin").write_bytes(result.stdout)
    (output / "stderr.bin").write_bytes(result.stderr)
    raw_changes = {}
    for index, path in enumerate(changed):
        entry = {"path": path}
        if path in before_bytes:
            rawname = f"{index:03d}-before.bin"
            (output / rawname).write_bytes(before_bytes[path])
            entry["before_raw"] = rawname
        if after.get(path, {}).get("kind") == "file":
            rawname = f"{index:03d}-after.bin"
            (output / rawname).write_bytes((fixture.base / path).read_bytes())
            entry["after_raw"] = rawname
        raw_changes[path] = entry
    observation = {"argv": argv, "cwd": str(BASE), "exit_status": result.returncode,
        "stdout_sha256": support.sha(result.stdout), "stderr_sha256": support.sha(result.stderr),
        "before": before, "after": after, "changed_destinations": changed, "raw_changes": raw_changes}
    save(f"{name}/observation.json", observation)
    print(json.dumps({"case": name, "status": result.returncode, "changed": changed, "stdout": result.stdout.decode(errors="replace")[:2000], "stderr": result.stderr.decode(errors="replace")[:500]}), flush=True)
    return observation

run("01-candidate-doctor", sys.executable, ["doctor", str(fixture.root), "--json"])
assert run("02-candidate-validate", sys.executable, ["validate", str(fixture.root), "--json"])["exit_status"] == 0
assert run("02b-released-validate", LEGACY, ["validate", str(fixture.root), "--json"])["exit_status"] == 0
run("03-released-version", LEGACY, ["--version"])
run("04-released-doctor-control", LEGACY, ["doctor", str(fixture.root), "--json"])
run("05-released-evidence", LEGACY, ["evidence", str(fixture.root), "--artifact", "WO-LEG-001", "--checkpoint", "handoff", "--rebound-at", "2026-09-12T15:28:00Z", "--json"])
run("06-released-dashboard-derived", LEGACY, ["dashboard", str(fixture.root), "--json"])
