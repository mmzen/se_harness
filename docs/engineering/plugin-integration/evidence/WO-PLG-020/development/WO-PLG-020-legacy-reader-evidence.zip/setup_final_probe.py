from pathlib import Path
import hashlib
import json
import subprocess
import sys
import zipfile

base = Path(__file__).resolve().parent
archive = base.parent / 'hosted-ci-review' / '20260912T151223.021336Z-artifact-10299474643.zip'
expected = 'ec2421f9562096e86f1a16c4117358e836541384f0dd32bbabec8a8357479985'
wheel_dir = base / 'final-wheel-dist'
wheel_dir.mkdir()
with zipfile.ZipFile(archive) as z:
    members = [name for name in z.namelist() if Path(name).name == 'se_harness-0.18.0-py3-none-any.whl']
    assert len(members) == 1, members
    wheel_bytes = z.read(members[0])
assert hashlib.sha256(wheel_bytes).hexdigest() == expected
wheel = wheel_dir / 'se_harness-0.18.0-py3-none-any.whl'
wheel.write_bytes(wheel_bytes)
env = base / 'final-candidate-env'
records = []
for name, argv in [('venv', [sys.executable, '-I', '-B', '-m', 'venv', str(env)]),
                   ('install', [str(env / 'Scripts' / 'python.exe'), '-I', '-B', '-m', 'pip', 'install', '--no-index', '--no-deps', '--disable-pip-version-check', str(wheel)])]:
    result = subprocess.run(argv, cwd=base, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (base / f'final-{name}-stdout.bin').write_bytes(result.stdout)
    (base / f'final-{name}-stderr.bin').write_bytes(result.stderr)
    records.append({'name': name, 'argv': argv, 'exit_status': result.returncode})
    assert result.returncode == 0, result.stderr
original = (base / 'probe.py').read_text()
text = original.replace('BASE = Path(__file__).resolve().parent',
    'PROBE = Path(__file__).resolve().parent\nBASE = PROBE / "final-wheel"\nBASE.mkdir()')
text = text.replace('CHECKOUT = BASE.parent.parent / "wo20"', 'CHECKOUT = PROBE.parent.parent / "wo20"')
text = text.replace('LEGACY = BASE.parent.parent / "evaluator-017"', 'LEGACY = PROBE.parent.parent / "evaluator-017"')
text = text.replace('WHEEL = BASE.parent / "local-package" / "dist"', 'WHEEL = PROBE / "final-wheel-dist"')
text = text.replace('Preliminary installed development wheel used only to construct a valid schema-4 disposable fixture; not qualification evidence for committed candidate.',
    'Final CI wheel for candidate commit 1e062e4db06b6e7131429db15b3d6b9876e600db, artifact 10299474643; SHA independently verified before installation. This focused probe is supplementary, not a replacement for qualification.')
needle = 'fixture.plugins = {}'
replacement = '''draft = fixture.root / created.path
draft_raw = draft.read_text(encoding="utf-8")
for old, new in [('<Bounded implementation objective>', 'Disposable legacy writer probe'),
                 ('<engineering owner>', 'fixture engineering owner'),
                 ('<required or not_required>', 'required'),
                 ('["REQ-xxx"]', '[]'), ('["SPEC-xxx"]', '[]'), ('["VER-xxx"]', '[]')]:
    draft_raw = draft_raw.replace(old, new)
draft.write_text(draft_raw, encoding="utf-8", newline="\\n")
fixture.plugins = {}'''
assert needle in text
text = text.replace(needle, replacement)
script = base / 'final_probe.py'
script.write_text(text, encoding='utf-8', newline='\n')
records.append({'wheel_archive': str(archive), 'member': members[0], 'wheel_sha256': expected, 'script_sha256': hashlib.sha256(script.read_bytes()).hexdigest()})
(base / 'final-setup.json').write_text(json.dumps(records, indent=2) + '\n')
result = subprocess.run([str(env / 'Scripts' / 'python.exe'), '-I', '-B', str(script)], cwd=base)
sys.exit(result.returncode)
