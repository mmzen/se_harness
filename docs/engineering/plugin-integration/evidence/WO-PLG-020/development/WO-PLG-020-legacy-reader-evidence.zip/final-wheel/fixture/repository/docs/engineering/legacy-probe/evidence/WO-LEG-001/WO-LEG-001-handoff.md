```toml
artifact = "WO-LEG-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "b58fd888107b85e8662860d4d838aff095bd115a4cab4ecca0db6f291525a1f2"
rebound_at = "2026-09-12T18:00:00Z"
```

# WO-LEG-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
