+++
id = "WO-LEG-001"
type = "work_order"
title = "Disposable legacy writer probe"
status = "draft"
owners = ["fixture engineering owner"]
created = "2026-09-12"
updated = "2026-09-12"

[assurance]
commit_bound_verification = "required"
rationale = "<why future decisions do or do not require commit-bound assurance>"
decided_by = "<accountable role>"

[execution_scope]
paths = [
  "<exact/repository-relative/path>",
  "<repository-relative/component-prefix/>",
]

# Optional. Delete this table unless the accountable owner delegates the three
# mechanical decisions of this work order to a non-human actor.
[delegation]
class = "execution"

[relations]
implements = ["REQ-LEG-001"]
specifications = ["SPEC-LEG-001"]
verification = ["VER-LEG-001"]
+++

# Work Order: <title>

## Lifecycle

Use `approved` to authorize bounded execution and `implemented` after the work and retained evidence are complete. Governance-only work normally stops at `implemented`. Use `verified` or `released` only when an eligible commit-bound VREC explicitly covers this work order under the repository's configured provenance policy.

Before approval, classify commit-bound verification explicitly. Use `required` when future engineering, assurance, operational, or release decisions will rely on the correctness of changed executable behavior, managed policy, CI, definitions, traceability, or other trusted engineering state. Use `not_required` only when the work solely records or transports an already authorized verification, release, supersession, publication, or deployment decision. Split mixed scope or use `required`; uncertainty requires escalation rather than an inferred default.

Before approval, replace every `[execution_scope].paths` placeholder. An entry
ending in `/` admits that directory and its descendants. Every other entry
admits one exact repository-relative path. Do not use absolute paths,
backslashes, wildcards, dot components, drive prefixes, URIs, or duplicate
case variants.

The optional `[delegation]` table with `class = "execution"` lets the
`delegated-executor` role apply `DR-WO-START`, `DR-WO-COMPLETE` and
`DR-VREC-PREPARE` for this work order, and nothing else, only while the
required pull-request check for the candidate head is `success`; the class
is read from the base of the pull request, so a branch cannot add it to
itself. Approving a work order that carries the table is the act of
delegating. Delete the table when every decision stays human.

Add `architecture = ["ARCH-xxx", "ADR-xxx"]` under `[relations]` when architecture applies. The relation selects every applicable architecture plus every required deciding ADR. An ADR may be omitted only for a selected architecture whose accepted `decision_assessment` is `no_significant_decision`; every `adr_required` architecture needs at least one selected active ADR that decides it.

An architecture is applicable when it addresses an architecturally significant requirement implemented by this work order. Every selected architecture must conform to at least one of the selected specifications. Omit the `architecture` relation only when no active architecture addresses any implemented requirement. Routine requirements without an active `addresses` edge do not require fabricated architecture coverage. A present `architecture` relation must not be empty.

## Objective

## In scope

## Out of scope

## Authorized decision envelope

What may the implementation agent decide locally?

## Constraints

## Expected change surface

Use components rather than guessed files when the code has not yet been inspected.

## Required verification

## Evidence to record

## Stop and escalate conditions

## Completion report format

State what the report carries. The completion decision follows from the
front matter, not from this section: it is the engineering owner's, or the
`delegated-executor`'s under `[delegation] class = "execution"` while the
required pull-request check is `success`.
