from pathlib import Path
Path(__file__).with_name('EXECUTED').write_text('unsafe')
