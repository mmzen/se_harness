+++
id = "REQ-LEG-001"
type = "requirement"
title = "REQ-LEG-001"
status = "draft"
owners = ["owner"]
created = "2026-08-11"
updated = "2026-08-11"
statement = "THE SYSTEM SHALL retain the test observation."
verification_method = "automated-test"

[relations]
derives_from = ["CAP-LEG-001"]
+++

# REQ-LEG-001
