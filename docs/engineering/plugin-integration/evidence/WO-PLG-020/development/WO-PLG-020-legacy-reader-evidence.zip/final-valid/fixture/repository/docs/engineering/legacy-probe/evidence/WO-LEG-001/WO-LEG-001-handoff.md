```toml
artifact = "WO-LEG-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "b3cf8e9402909e6c384c7ce1a85c469db844054d2544f182ee34b3093faf8b1c"
rebound_at = "2026-09-12T15:28:00Z"
```

# WO-LEG-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
