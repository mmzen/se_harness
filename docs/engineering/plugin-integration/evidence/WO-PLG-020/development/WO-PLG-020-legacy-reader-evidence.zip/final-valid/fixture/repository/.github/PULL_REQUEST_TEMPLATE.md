## Harness work order

Harness-Work-Order: WO-...

Replace the placeholder with exactly one approved or completed work-order ID. Required CI validates the ID and its governing chain and fails on any path of the diff outside the work order's declared scope, whatever the work order's lifecycle state. Write the body with LF line endings; a carriage return on that line fails selection with `W-ADS-001`.

`harnessctl pr-body . --artifact WO-...` emits this body with LF line endings, the work-order line, the restitution line when a Git-derived handoff result is retained, and the evidence list; paste its output rather than typing it. Optionally add one standalone `Harness-Restitution: <sha256>` line carrying the `result_sha256` of the handoff check you returned. While the work order is in progress, CI recomputes the block from the pull request's own changed paths and fails on mismatch; after completion the line is reported as bound at handoff and not recomputed. Leave the line out rather than guessing it.

## Summary

- Describe the bounded change.

## Verification

- List retained evidence and commands.
