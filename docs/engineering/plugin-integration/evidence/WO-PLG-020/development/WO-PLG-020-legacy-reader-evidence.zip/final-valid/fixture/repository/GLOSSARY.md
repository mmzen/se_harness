# Glossary for legacy-writer-probe

<!-- Target expertise: 3/10. The score describes the knowledge expected from the reader, not the quality or complexity of the document. -->

> Repository-owned from the first byte. The harness installs this file once
> and never rewrites, hashes or upgrades it. Every term in it is this
> repository's own.

## Summary

Two vocabularies meet in a requirement. Harness terms, such as work order,
verification record, decision right and checkpoint, are the same in every
repository that uses the harness; they are defined once in the managed
instructions and are not repeated here. Project terms belong to this
repository and its artifacts; this page defines them. Write each entry as
one or two sentences a newcomer understands, and cite the artifact that
fixes the term's meaning when one does. When an amendment changes a term's
meaning, it names the entry.

This file sits at the repository root so a newcomer meets it beside the
README. `harnessctl inspect` reports the frequent project terms of this
repository's artifacts that have no entry here, and the entries whose term
no longer appears in any artifact. Both are informational.

## Terms

## Upkeep

This page is a note: change it by pull request and review, never by a work
order. Add a term when the vocabulary report names it or when a reviewer
asks what a word means; retire an entry when its term has left the
artifacts.
