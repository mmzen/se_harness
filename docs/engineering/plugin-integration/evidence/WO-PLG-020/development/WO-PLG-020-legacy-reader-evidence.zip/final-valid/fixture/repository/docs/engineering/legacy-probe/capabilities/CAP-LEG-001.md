+++
id = "CAP-LEG-001"
type = "capability"
title = "CAP-LEG-001"
status = "draft"
owners = ["owner"]
created = "2026-08-11"
updated = "2026-08-11"


[relations]
derives_from = ["INT-LEG-001"]
+++

# CAP-LEG-001
