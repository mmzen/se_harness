+++
id = "INT-LEG-001"
type = "intent"
title = "INT-LEG-001"
status = "draft"
owners = ["owner"]
created = "2026-08-11"
updated = "2026-08-11"


[relations]

+++

# INT-LEG-001
