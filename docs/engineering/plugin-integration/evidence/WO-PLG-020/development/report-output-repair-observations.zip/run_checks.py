"""Retain subprocess logs directly, without shell stream buffering."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
label = sys.argv[1]
argv = [sys.executable, "-B", "-m", "unittest", *sys.argv[2:], "-v"]
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
environment.pop("SE_HARNESS_OWNERSHIP_PACKAGE", None)
environment["SE_HARNESS_OWNERSHIP_EVIDENCE"] = str(OUT / (label + "-cases"))
start = time.monotonic()
print(json.dumps({"label": label, "argv": argv}), flush=True)
with (OUT / (label + ".stdout.log")).open("wb") as output, (OUT / (label + ".stderr.log")).open("wb") as error:
    result = subprocess.run(argv, cwd=ROOT, env=environment, stdout=output, stderr=error)
record = {"label": label, "argv": argv, "cwd": str(ROOT), "exit": result.returncode, "seconds": time.monotonic() - start}
(OUT / (label + ".json")).write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record), flush=True)
print((OUT / (label + ".stderr.log")).read_text(errors="replace")[-2400:])
raise SystemExit(result.returncode)
