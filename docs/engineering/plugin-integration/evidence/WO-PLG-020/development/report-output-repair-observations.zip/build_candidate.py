"""Build one non-promotable wheel from an identified local snapshot, outside the checkout."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
SOURCE = ROOT.with_name("rp20")
SOURCE.mkdir(exist_ok=False)
ENV = OUT / "candidate-env"
BUILD = OUT.parent / "local-package/build-env/Scripts/python.exe"
DIST = OUT / "dist-final"
DIST.mkdir()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
paths = subprocess.check_output(["git", "-C", str(ROOT), "ls-files", "-z"]).decode().split("\0")
paths += subprocess.check_output(["git", "-C", str(ROOT), "ls-files", "--others", "--exclude-standard", "-z"]).decode().split("\0")
manifest = {}
for name in sorted(set(paths) - {""}):
    path = ROOT / name
    assert path.is_file() and not path.is_symlink(), name
    raw = path.read_bytes()
    destination = SOURCE / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(raw)
    manifest[name] = {"bytes": len(raw), "sha256": sha(raw)}
(OUT / "source-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
records = []

def run(label, argv, cwd=OUT):
    start = time.monotonic()
    result = subprocess.run(list(map(str, argv)), cwd=cwd, env=dict(os.environ, PYTHONPATH="", PYTHONNOUSERSITE="1"),
                            capture_output=True, timeout=300)
    (OUT / (label + ".stdout.log")).write_bytes(result.stdout)
    (OUT / (label + ".stderr.log")).write_bytes(result.stderr)
    records.append({"label": label, "argv": list(map(str, argv)), "cwd": str(cwd), "exit": result.returncode,
                    "seconds": time.monotonic() - start, "stdout_sha256": sha(result.stdout), "stderr_sha256": sha(result.stderr)})
    (OUT / "package-commands.json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(records[-1]), flush=True)
    assert result.returncode == 0, label

run("build-candidate-wheel", [BUILD, "-I", "-B", "-c",
    "import sys; from setuptools.build_meta import build_wheel; print(build_wheel(sys.argv[1]))", DIST], SOURCE)
wheels = list(DIST.glob("*.whl"))
assert len(wheels) == 1
wheel = wheels[0]
run("create-candidate-env", [sys.executable, "-m", "venv", ENV])
python = ENV / "Scripts/python.exe"
run("install-candidate-wheel", [python, "-m", "pip", "install", "--disable-pip-version-check", "--no-index", "--no-deps", wheel])
run("installed-identity", [python, "-I", "-B", "-c",
    "import json,se_harness; from se_harness.evaluator_identity import installed_evaluator_identity; "
    "print(json.dumps({'module':se_harness.__file__,'identity':installed_evaluator_identity().to_lock()}))"])
record = {"classification": "local non-promotable development wheel; not a qualified committed candidate",
          "created_at": datetime.now(timezone.utc).isoformat(), "candidate_commit": None, "promotable": False,
          "base_commit": subprocess.check_output(["git", "-C", str(ROOT), "rev-parse", "HEAD"]).decode().strip(),
          "wheel": str(wheel), "wheel_sha256": sha(wheel.read_bytes()),
          "source_manifest_sha256": sha((OUT / "source-manifest.json").read_bytes())}
identity = json.loads((OUT / "installed-identity.stdout.log").read_bytes())
assert identity["identity"]["archive_sha256"] == record["wheel_sha256"]
(OUT / "candidate-package.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record), flush=True)
