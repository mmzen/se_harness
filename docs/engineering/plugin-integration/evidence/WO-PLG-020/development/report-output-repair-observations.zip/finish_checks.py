"""Retain lightweight repository checks for the report-output repair."""
import json
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
checks = [
    ("candidate-help", [sys.executable, "-B", "-m", "se_harness", "--help"]),
    ("release-distributions", [sys.executable, "-B", "scripts/validate_release_distributions.py", "--root", "."]),
    ("validation-reuse", [sys.executable, "-B", "-m", "unittest",
        "tests.test_one_validation.ValidationCountTests.test_each_governance_command_validates_at_most_once",
        "tests.test_one_validation.ReportTravelsTests.test_the_snapshot_builder_and_qualification_take_the_report", "-v"]),
]
records = []
for label, argv in checks:
    start = time.monotonic()
    with (OUT / (label + ".stdout.log")).open("wb") as output, (OUT / (label + ".stderr.log")).open("wb") as error:
        result = subprocess.run(argv, cwd=ROOT, stdout=output, stderr=error)
    record = {"label": label, "argv": argv, "cwd": str(ROOT), "exit": result.returncode, "seconds": time.monotonic() - start}
    records.append(record)
    print(json.dumps(record), flush=True)
(OUT / "repository-checks.json").write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8")
raise SystemExit(any(record["exit"] for record in records))
