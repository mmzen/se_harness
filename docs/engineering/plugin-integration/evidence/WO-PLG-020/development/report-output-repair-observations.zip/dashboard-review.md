# Candidate dashboard output repair — independent review notes

Read/design review only. Main implements the candidate 0.18 repair. No candidate
source, formal artifacts, historical evidence, or released 0.17 files were edited
by this review. The actual 0.17 protected-output failures remain failures.

Paths and one-based lines below are relative to the candidate checkout
`C:/Users/hok/Documents/Codex/2026-09-12/clo/work/wo20` as inspected.

## Minimal repair recommendation

Add one destination-admission check to the existing dashboard generation path,
using trusted distribution inventory plus the retained discovery catalog. Keep
the existing bundle transaction. Do not gate all reporting on doctor or mutation
authority: producing safe derived output must remain possible when installation
integrity or the artifact graph is invalid.

The current resolver (`se_harness/engine/dashboard_snapshot.py:177`) excludes
repository/ancestor and artifact-root overlap, then resolves before testing for a
symlink. It never compares against installed files. The transaction
(`se_harness/engine/dashboard_bundle.py:700`) replaces the selected directory in
full. Thus `.github` is an admitted output that removes the installed workflow
and seed pull-request template. A similar destination can replace a retained
skill directory or create a directory at an absent retired file path.

Use this protected set, independent of caller-supplied lock contents:

- Every target from `installer.template_files()` (`se_harness/installer.py:131`),
  including managed, fragment and seed targets. This already covers the installed
  config, `.github/workflows/engineering-harness.yml`, the seed
  `.github/PULL_REQUEST_TEMPLATE.md`, root fragments, templates and seven retained
  core paths. Read target names only; do not compute an install/upgrade plan.
- The lock name from `installer.LOCK_NAME`.
- `skill_ownership.DISCOVERY_PATHS` (`se_harness/skill_ownership.py:34`), which adds
  the forbidden Claude operator-brief discovery shadow not in the seven-file
  retirement catalog.

Do not use `effective_template_files(lock)` (`installer.py:137`) as the sole set:
schema-4 ownership deliberately removes the seven paths from that inventory.
Do not trust the lock's `files` keys as the sole set either. A damaged lock must
not turn off destination protection. Supporting extra historical lock-owned
paths can be additive, but requires an explicit malformed-lock policy; it is not
necessary to derive the current known protection set.

For each protected file, reject an output equal to it, an ancestor of it, or a
descendant of it. The last case matters when the protected file is absent and a
caller asks for `.../SKILL.md/reports`. Component-based comparison avoids the
false prefix collision between `.github` and `.github-reports`. Compare both
lexical portable components and resolved destinations. A resolved comparison
catches aliases pointing into the protected tree; lexical comparison preserves
the protection when a protected namespace is itself aliased elsewhere. Casefold
protected comparisons consistently with the installer's existing portable
discovery protection (`installer.py:567`), including on case-sensitive hosts.

Retain the current exclusions for the repository and artifact root. Do not ban
all custom output or all `.github` descendants: `.github/reports` does not overlap
the installed workflow/template and can remain an ordinary explicit report
destination. `.github/workflows`, by contrast, contains a protected file and must
be refused. A directory under a retained skill's directory that overlaps no
protected file is a separate owner-content location, not itself a retired core
copy; avoid silently widening this repair into a whole-tree ownership policy.

## Path validation and transaction placement

Keep the lexical user request available until validation; calling `resolve()`
first makes the existing `is_symlink()` check ineffective for supplied links.
Use `artifact_layout.validate_existing_chain` (`se_harness/artifact_layout.py:199`)
for ordinary repository-relative candidates, translating its `HarnessError` into
the dashboard's `GenerationError`. Its `_is_link_like` at 189 checks Windows
reparse attributes and works on Python 3.11. In contrast:

- `installer.safe_destination` alone rejects symlinks but has no complete reparse
  check.
- Dashboard `_evidence_path_has_symlink` (`dashboard_snapshot.py:847`) uses
  `Path.is_junction` only when available and misses that route on Python 3.11.
- `interpreter_safety` has a portable traversal implementation, but its private
  helpers are designed around executable provenance; copying that entire policy
  into reporting would add an unrelated coupling.

Preserve safe external destinations and normal `../sibling-report` selection.
Do not blindly pass an external/parent-relative path to the repository-only
helper, which rejects escape by design. For external paths, inspect their actual
lexical parent chain with the same symlink/reparse predicate, then resolve and
compare with selected-repository protected paths. Keep valid Unicode directory
names; reject Windows alias spellings (trailing dots/spaces, alternate data
streams) rather than interpreting them as new ordinary directories. An ordinary
selected repository root may already have been canonicalized by the public root
resolver; do not accidentally invalidate that existing root-selection contract.

Run admission before the first `mkdir` or temporary directory creation. Both the
CLI (`se_harness/cli.py:335`) and direct `generate_bundle`
(`engine/generate_harness_dashboard.py:131`) must reach the same check. Repeat
destination/parent checks immediately before replacing an existing output,
because snapshot/bundle construction separates initial validation from promotion.
Keep enough original lexical path and parent identity to detect a changed alias;
re-resolving and accepting an arbitrary new destination is not a stale-input check.

`write_output_transactionally(output, files)` currently has no repository context.
It can enforce safe parents and resource paths but cannot independently identify
which sibling directory is an installed repository. If it receives an admitted
destination/validation callback or explicit repository boundary from
`generate_bundle`, keep that relationship explicit. Do not claim that a guard in
`generate_bundle` also makes arbitrary direct primitive calls ownership-aware.

A check immediately before write materially narrows a race but is not itself a
proof against every concurrent path swap. Preserve the current transaction's
rollback semantics and test an injected parent/leaf replacement; claim only the
boundaries actually enforced. Do not introduce a new durable transaction system
or silently broaden this bounded repair to every filesystem primitive.

## Focused edge tests

Use independent before/after file/link snapshots, not only return codes or the
reported write list. Keep failures before any output-parent creation observable.

| Case | Expected observation |
| --- | --- |
| `.github`, `.github/workflows`, absolute equivalents | Refusal; workflow, pull-request template, lock and all prior bytes unchanged. |
| `.agents`, `.agents/skills`, either retained core directory; `.claude/skills` | Refusal in repository and plugin ownership; ordinary extras and empty owner directories preserved. |
| Claude operator-brief shadow directory | Refusal despite absence from the seven-file retirement catalog. |
| Each absent retired file path as output, and `SKILL.md/reports` | Refusal; no file-shaped directory, child or parent is created. |
| Component-normalized and mixed-case protected spellings; Windows trailing-dot/space and ADS spellings | Refusal without namespace alias creation. |
| Supplied leaf symlink, parent symlink, Windows junction/reparse alias into `.github` or a retired skill path | Refusal; link itself and actual target remain unchanged. Retain unavailable mechanisms explicitly. |
| Alias of a protected namespace pointing outside the selected root | Refusal; both lexical protected path and outside target remain unchanged. |
| Default output, safe custom nested output, explicit outside sibling, `.github-reports`, safe `.github/reports` | Generation succeeds and the exact bundle is present only at the selected output; protected bytes unchanged. |
| Existing safe output containing an old generated tree | Full normal replacement still works; an injected write/promotion error preserves the prior valid output. |
| Parent/leaf changes between admission and promotion | Refusal or proved rollback; no write into substituted protected target. |
| Direct `generate_bundle` versus CLI | Same destination refusal and preservation; no parser-only or unrelated lock-gate refusal counted. |
| Missing/malformed/older supported lock with safe output | Report availability policy is preserved; static protection still refuses known installed/discovery destinations. |

Tests can use normal synthetic source fixtures for inexpensive path cases, with
an installed-candidate CLI case proving packaged inventory availability and real
candidate routing. Keep the real released-0.17 failure probes separate and
unchanged; candidate fixes do not repair that installed executable.

Existing checks worth retaining:

- `tests/test_harnessctl.py:236`, 271 and 587 cover default dashboard generation
  from initialized/adopted repositories. At 596, distribution-owned command
  execution must continue ignoring target-local script decoys.
- `tests/test_one_validation.py:78` passes an explicit external output and counts
  graph validation. Inventory/path admission must not introduce a second graph
  validation, doctor pass, or runtime-identity requirement.
- `tests/test_dashboard_webui.py:737` covers deterministic bounded bundle output;
  at 940 the raw transaction rejects traversal/case collisions and preserves
  existing `index.html`. It does not currently test protected output roots or
  parent aliases.
- `tests/test_dashboard_publication.py` governs packaging/publication of a
  completed generated tree. This repair should not change manifest schemas,
  generated-resource paths or publication authority.

## Applicable active formal anchors

| Contract and exact line | Constraint relevant to this repair |
| --- | --- |
| `docs/engineering/harness-distribution/specifications/SPEC-DST-013.md:18` | Generated data interface changes do not change source-repository state or formal authority. |
| `SPEC-DST-013.md:54` in that directory | Failure before promotion discards temporary output and preserves the prior valid output. |
| `SPEC-DST-013.md:68` | Generated child paths come from generator constants/digests, never repository IDs/paths. This governs resource paths, not by itself the top-level destination. |
| `SPEC-DST-013.md:70` | Explicitly requires rejection of unsafe parents and collisions, one temporary sibling tree, recursive verification and atomic promotion. |
| `docs/engineering/harness-distribution/verification/VER-DST-013.md:34` | Write/verification/promotion failures preserve prior bytes. |
| `VER-DST-013.md:43` in that directory | Prefix, Unicode, separator, case, symlink, junction and traversal ambiguities must not escape output. |
| `VER-DST-013.md:56` | Includes races around output promotion. |
| `docs/engineering/harness-distribution/specifications/SPEC-DST-023.md:30` | Carries the active SPEC-DST-013 bundle contract unchanged; avoid treating superseded SPEC-DST-008/012 as current independent policy. |
| `SPEC-DST-023.md:229` and 233 in that directory | Carries transactional promotion and preservation of customized managed copies. |
| `docs/engineering/plugin-integration/specifications/SPEC-PLG-020.md:166` | Candidate must preserve selected ownership binding and installed bytes through supported operations. |
| `docs/engineering/plugin-integration/verification/VER-PLG-020.md:101` | Specific report observations require unchanged pre-existing installation/config/lock/formal metadata and external provider bytes; unexpected additional writes remain failures. |

These anchors support destination protection and bounded boundary testing. They
do not turn a candidate-only repair into a passing migration-unaware-reader
observation, authorize changes to historical results, or establish exhaustive
output-path coverage.
