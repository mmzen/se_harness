"""Exercise the installed repair and migrated fixtures without candidate-authority mocks."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import unittest

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
SNAPSHOT = ROOT.with_name("rp20")
WHEEL = OUT / "dist-final/se_harness-0.18.0-py3-none-any.whl"
os.environ["SE_HARNESS_OWNERSHIP_PACKAGE"] = "1"
os.environ["SE_HARNESS_OWNERSHIP_WHEEL"] = str(WHEEL)
os.environ["SE_HARNESS_OWNERSHIP_EVIDENCE"] = str(OUT / "installed-cases")
os.environ["SE_HARNESS_OWNERSHIP_COMMIT"] = "uncommitted-development-snapshot"
import se_harness
from se_harness.evaluator_identity import installed_evaluator_identity
assert sys.flags.isolated
assert Path(se_harness.__file__).resolve().is_relative_to(Path(sys.prefix).resolve())
assert installed_evaluator_identity().archive_sha256 == hashlib.sha256(WHEEL.read_bytes()).hexdigest()

def load(name, relative):
    path = SNAPSHOT / relative
    assert path.read_bytes() == (ROOT / relative).read_bytes(), relative
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

reports = load("installed_report_safety", "tests/test_report_output_safety.py")
ownership = load("installed_ownership_reports", "tests/test_skill_ownership.py")
suite = unittest.defaultTestLoader.loadTestsFromTestCase(reports.ReportOutputSafetyTests)
for name in ("test_own07_candidate_qualification_output_preserves_retired_skill",
             "test_own07_candidate_dashboard_output_preserves_installed_workflow"):
    suite.addTest(ownership.SkillOwnershipAcceptanceTests(name))
start = time.monotonic()
with (OUT / "installed-tests.log").open("w", encoding="utf-8") as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
record = {"tests_run": result.testsRun, "failures": [(case.id(), text) for case, text in result.failures],
          "errors": [(case.id(), text) for case, text in result.errors], "skipped": result.skipped,
          "seconds": time.monotonic() - start, "python": sys.executable, "module": se_harness.__file__,
          "wheel_sha256": hashlib.sha256(WHEEL.read_bytes()).hexdigest(),
          "classification": "installed candidate development checks; not full qualification",
          "authority": "Installed migrations and actual report subprocesses have no authority mocks. Unit role-exception tests explicitly mock only inspection results."}
(OUT / "installed-result.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
print(json.dumps(record), flush=True)
raise SystemExit(not result.wasSuccessful())
