"""Audit and retain local development evidence without changing lifecycle state."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
FROZEN = ROOT.parent / "rp20"
EVIDENCE = ROOT / "docs/engineering/plugin-integration/evidence/WO-PLG-020"
OUTPUTS = ROOT.parents[1] / "outputs"
sha = lambda raw: hashlib.sha256(raw).hexdigest()
read = lambda name: json.loads((OUT / name).read_text(encoding="utf-8-sig"))
dump = lambda path, value: path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
manifest = read("source-manifest.json")
package = read("candidate-package.json")
assert sha((OUT / "source-manifest.json").read_bytes()) == package["source_manifest_sha256"]
assert sha(Path(package["wheel"]).read_bytes()) == package["wheel_sha256"]
sources = ["se_harness/cli.py", "se_harness/integrity.py", "se_harness/release_qualification.py",
    "se_harness/engine/dashboard_bundle.py", "se_harness/engine/dashboard_snapshot.py",
    "se_harness/engine/generate_harness_dashboard.py", "tests/test_report_output_safety.py",
    "tests/test_skill_ownership.py", "tests/fixtures/skill_ownership/legacy_reader.py"]
for name in sources:
    assert (ROOT / name).read_bytes() == (FROZEN / name).read_bytes(), name
    assert sha((ROOT / name).read_bytes()) == manifest[name]["sha256"], name
with zipfile.ZipFile(package["wheel"]) as wheel:
    for name in sources:
        if name.startswith("se_harness/"):
            assert wheel.read(name) == (ROOT / name).read_bytes(), name
installed = read("installed-result.json")
assert installed["tests_run"] == 12 and not any(installed[k] for k in ("failures", "errors", "skipped"))
assert read("candidate-source.json")["exit"] == 0
assert read("report-regressions.json")["exit"] == 0
log = (OUT / "report-regressions.stderr.log").read_text()
assert "Ran 116 tests" in log and "OK (skipped=1)" in log
checks = read("repository-checks.json")
assert all(item["exit"] == 0 for item in checks)
assert read("preflight.json")["ready"]
assert all(item["passed"] for item in read("doctor.json")["checks"])
assert read("validation.json")["valid"] and not read("validation.json")["errors"]

sys.path.insert(0, str(ROOT))
from tests.test_skill_ownership import acceptance_suite
counts = {"smoke": acceptance_suite(smoke=True).countTestCases(), "full": acceptance_suite().countTestCases()}
assert counts == {"smoke": 17, "full": 62}, counts
approval = json.loads((OUT.parent / "own07-amendment/approval-application.json").read_bytes())
for effect in approval["effects"]:
    if effect["artifact"] != "WO-PLG-020":
        assert sha((ROOT / effect["path"]).read_bytes()) == effect["after_sha256"], effect["path"]

case_summary = []
for mode, directory in (("source", "candidate-source-cases"), ("installed", "installed-cases")):
    paths = sorted((OUT / directory).glob("*.json"))
    assert len(paths) == 2
    for path in paths:
        case = json.loads(path.read_bytes())
        assert case["case_outcome"] == "passed", path
        events = [e for e in case["events"] if e["operation"] == "candidate-report-output"]
        assert len(events) in (2, 3)
        for event in events:
            assert event["before"] == event["after"]
            assert event["exit_status"] == (1 if len(events) == 2 else 2)
        case_summary.append({"mode": mode, "case": case["test"], "report_commands": len(events),
            "snapshots_unchanged": True, "evidence": path.relative_to(OUT).as_posix()})

wo_path = "docs/engineering/plugin-integration/work-orders/WO-PLG-020.md"
scope = ["se_harness/release_qualification.py", "se_harness/engine/generate_harness_dashboard.py",
    "se_harness/engine/dashboard_bundle.py", "se_harness/engine/dashboard_snapshot.py", "tests/test_report_output_safety.py"]
receipt = {"schema": "wo-plg-020-report-output-repair-authorization-v1",
    "recorded_at_utc": datetime.now(timezone.utc).isoformat(), "user_instruction": "ok, fix both problems then",
    "work_order": "WO-PLG-020", "scope_additions": scope,
    "effect": "Implement the two reviewed candidate report-output repairs and retain source/package regressions.",
    "work_order_observed_sha256": sha((ROOT / wo_path).read_bytes()),
    "prior_approval_work_order_sha256": approval["effects"][-1]["after_sha256"],
    "hash_semantics": "Prior approval hash is historical application evidence; current WO includes the subsequent authorized repair scope and note.",
    "four_approved_appendices_unchanged": True, "lifecycle": "in_progress", "new_compatibility_exception": False,
    "implementation_verification": False, "release_authority": False}
dump(OUT / "authorization.json", receipt)
shutil.copyfile(OUT / "authorization.json", EVIDENCE / "governance/report-output-repair-authorization.json")

attempts = """# Report-output repair observation notes

The successful observations concern the local candidate only. Released 0.17 and
its two required failing OWN07 cases remain unchanged; no exception, expected
failure or skip was added to those cases. The candidate wheel is non-promotable,
has no candidate commit, and is not a completed qualification.

The first baseline used a fixture missing docs/engineering. It had 16 failed
subcases and five fixture errors, including an unrelated validator error. After
creating that fixture directory, the eight-test baseline had 18 failed subcases
and no errors. These logs are retained as original observations. The first
repaired eight-test run passed; the final ten-test version also covers Windows
namespace spellings and an alias introduced before output promotion. Only the
final test source is frozen in this archive; baseline logs are not exact-source
reproducibility claims.

The initial broader run through PowerShell redirection was interrupted before a
result while extending the Windows checks. Its empty buffered logs are retained
as incomplete, not as a passing or failing test verdict. The replacement run
writes directly to log handles and completed normally: 116 tests, 115 passed,
one existing Windows symlink-privilege skip. The new Windows junction and path
spelling tests passed. Two source migration/report tests and two validation-reuse
tests also passed. The installed candidate ran ten output tests plus two actual
migrated CLI cases: 12 passed, no skips. Unit qualification tests mock inspection
outcomes only. Source migration uses the existing source authority fixture;
installed migration and report subprocesses use the actual isolated wheel.

An initial source-copy attempt exceeded the Windows path-length limit before a
build ran. The partial scratch copy remains. The successful build used the
shorter work/rp20 snapshot, whose file manifest is retained. One development
wheel was built successfully and installed without network/dependency resolution.

Independent read-only contract review is retained in dashboard-review.md. A
subsequent admission review identified Windows extended-path aliases; the root
executor repaired and tested them. The final independent follow-up did not
complete because its provider returned a content-filter error, so no final
independent approval is claimed. Root review and the actual tests provide the
reported local development results.

No full repository or complete ownership matrix was rerun for this repair.
Linux, Python 3.11 and immutable-candidate acceptance remain outstanding. The
original 0.17 compatibility failures still prevent WO completion. Validation and
scope checks are governance observations, not substitutes for those tests.
Arbitrary hostile OS-level races are not claimed to be eliminated by the bounded
destination rechecks exercised here.
"""
(OUT / "observation-notes.md").write_text(attempts, encoding="utf-8")
audit = {"classification": "local candidate repair evidence; not qualification", "package": package,
    "frozen_product_and_test_bytes_match": True, "wheel_product_bytes_match_source": True,
    "original_legacy_test_source_unchanged_since_build": True, "four_approved_appendices_unchanged": True,
    "ownership_suite_counts": counts, "source_regression": {"run": 116, "passed": 115, "skipped": 1, "failed": 0},
    "source_migration_cases": 2, "validation_reuse_cases": 2, "installed_cases": 12,
    "report_snapshot_comparisons": case_summary, "checks": checks,
    "source_hashes": {name: manifest[name] for name in sources}, "lifecycle": "in_progress",
    "vrec_prepared": False, "published": False}
dump(OUT / "repair-audit.json", audit)
diff = subprocess.check_output(["git", "-C", str(ROOT), "-c", "core.safecrlf=false", "diff", "--", *sources], stderr=subprocess.DEVNULL)
(OUT / "candidate-repair.diff").write_bytes(diff)

members = {}
for path in sorted(OUT.iterdir()):
    if path.is_file() and path.suffix in {".json", ".log", ".md", ".py", ".diff"}:
        members[path.name] = path.read_bytes()
for directory in ("candidate-source-cases", "installed-cases"):
    for path in sorted((OUT / directory).glob("*.json")):
        members[path.relative_to(OUT).as_posix()] = path.read_bytes()
for name in sources + [wo_path]:
    members["tested-source/" + name] = (ROOT / name).read_bytes()
archive = EVIDENCE / "development/report-output-repair-observations.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for name, raw in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 9, 12, 19, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        stream.writestr(info, raw)
with zipfile.ZipFile(archive) as stream:
    assert stream.testzip() is None
    assert all(stream.read(name) == raw for name, raw in members.items())
index = {"classification": audit["classification"], "archive": archive.name,
    "archive_sha256": sha(archive.read_bytes()), "bytes": archive.stat().st_size, "audit": audit,
    "members": {name: {"bytes": len(raw), "sha256": sha(raw)} for name, raw in sorted(members.items())}}
index_path = archive.with_name("report-output-repair-index.json")
dump(index_path, index)
shutil.copyfile(archive, OUTPUTS / "WO-PLG-020-report-output-repair-evidence.zip")
shutil.copyfile(index_path, OUTPUTS / "WO-PLG-020-report-output-repair-index.json")
print(json.dumps({"archive_sha256": index["archive_sha256"], "bytes": index["bytes"],
    "members": len(members), "suite_counts": counts, "snapshot_commands": sum(c["report_commands"] for c in case_summary)}))
