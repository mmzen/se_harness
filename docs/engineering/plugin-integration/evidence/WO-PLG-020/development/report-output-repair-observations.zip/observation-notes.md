# Report-output repair observation notes

The successful observations concern the local candidate only. Released 0.17 and
its two required failing OWN07 cases remain unchanged; no exception, expected
failure or skip was added to those cases. The candidate wheel is non-promotable,
has no candidate commit, and is not a completed qualification.

The first baseline used a fixture missing docs/engineering. It had 16 failed
subcases and five fixture errors, including an unrelated validator error. After
creating that fixture directory, the eight-test baseline had 18 failed subcases
and no errors. These logs are retained as original observations. The first
repaired eight-test run passed; the final ten-test version also covers Windows
namespace spellings and an alias introduced before output promotion. Only the
final test source is frozen in this archive; baseline logs are not exact-source
reproducibility claims.

The initial broader run through PowerShell redirection was interrupted before a
result while extending the Windows checks. Its empty buffered logs are retained
as incomplete, not as a passing or failing test verdict. The replacement run
writes directly to log handles and completed normally: 116 tests, 115 passed,
one existing Windows symlink-privilege skip. The new Windows junction and path
spelling tests passed. Two source migration/report tests and two validation-reuse
tests also passed. The installed candidate ran ten output tests plus two actual
migrated CLI cases: 12 passed, no skips. Unit qualification tests mock inspection
outcomes only. Source migration uses the existing source authority fixture;
installed migration and report subprocesses use the actual isolated wheel.

An initial source-copy attempt exceeded the Windows path-length limit before a
build ran. The partial scratch copy remains. The successful build used the
shorter work/rp20 snapshot, whose file manifest is retained. One development
wheel was built successfully and installed without network/dependency resolution.

Independent read-only contract review is retained in dashboard-review.md. A
subsequent admission review identified Windows extended-path aliases; the root
executor repaired and tested them. The final independent follow-up did not
complete because its provider returned a content-filter error, so no final
independent approval is claimed. Root review and the actual tests provide the
reported local development results.

No full repository or complete ownership matrix was rerun for this repair.
Linux, Python 3.11 and immutable-candidate acceptance remain outstanding. The
original 0.17 compatibility failures still prevent WO completion. Validation and
scope checks are governance observations, not substitutes for those tests.
Arbitrary hostile OS-level races are not claimed to be eliminated by the bounded
destination rechecks exercised here.
