import hashlib
import json
from pathlib import Path
import shutil
import tomllib

OUT = Path(__file__).resolve().parent
BASE = OUT.parents[2]
ROOT = OUT.parent.parent / "wo20"
PROPOSAL = BASE / "outputs" / "WO-PLG-020-legacy-reader-reconciliation.md"
raw = PROPOSAL.read_bytes()
digest = hashlib.sha256(raw).hexdigest()
assert digest == "c7224fdd0dc6136753a1e2d42528a571ef2ffae185693e2f34a0b9ab9c7c2020"
proposal = raw.decode("utf-8")
recorded_at = "2026-09-12T18:28:18Z"
instruction = "i approve the 4 amendements"
targets = {
    "SPEC-PLG-020": ("specifications/SPEC-PLG-020.md", "technical-owner"),
    "ARCH-PLG-003": ("architecture/ARCH-PLG-003.md", "technical-owner"),
    "ADR-PLG-003": ("architecture/adr/ADR-PLG-003.md", "technical-owner"),
    "VER-PLG-020": ("verification/VER-PLG-020.md", "assurance-owner"),
}
domain = ROOT / "docs/engineering/plugin-integration"
effects = []
for identifier, (relative, role) in targets.items():
    path = domain / relative
    before = path.read_bytes()
    front = tomllib.loads(before.decode("utf-8").split("+++", 2)[1])
    assert front["status"] == "approved"
    assert b"Approved legacy-reader reconciliation" not in before
    appendix = proposal.split("## Exact proposed appendix: " + identifier + "\n", 1)[1].split("\n## ", 1)[0].strip() + "\n"
    assert appendix.startswith("### Approved applicability:")
    record = ("\n\n## Approved legacy-reader reconciliation — 2026-09-12\n\n"
              f"The operator approved this exact appendix as `{role}` with the instruction "
              f'"{instruction}". The approval was recorded at `{recorded_at}` under WO-PLG-020. '
              "Its reviewed proposal and decision receipt are retained in that work order's governance evidence. "
              "The original definition text, approvals and historical observations remain preserved. "
              "This approval does not establish passing acceptance, completion or verification.\n\n")
    after = before + record.encode("utf-8") + appendix.encode("utf-8")
    path.write_bytes(after)
    assert path.read_bytes().startswith(before)
    assert tomllib.loads(after.decode("utf-8").split("+++", 2)[1]) == front
    effects.append({"artifact": identifier, "role": role, "path": path.relative_to(ROOT).as_posix(),
                    "before_sha256": hashlib.sha256(before).hexdigest(), "after_sha256": hashlib.sha256(after).hexdigest(),
                    "appendix_sha256": hashlib.sha256(appendix.encode()).hexdigest(),
                    "effect": "append exact approved applicability text; front matter and historical prefix unchanged"})

work_order = domain / "work-orders/WO-PLG-020.md"
before = work_order.read_bytes()
assert b"Approved legacy-reader reconciliation" not in before
work_order.write_bytes(before + (
    "\n\n## Approved legacy-reader reconciliation — 2026-09-12\n\n"
    f'The operator approved the four exact OWN07 appendices with "{instruction}"; the approval was recorded at `{recorded_at}`. '
    "The technical-owner decisions apply to SPEC-PLG-020, ARCH-PLG-003 and ADR-PLG-003, and the assurance-owner decision applies to VER-PLG-020. "
    f"The reviewed proposal has SHA-256 `{digest}`. Its exact bytes and the approval receipt are retained under this work order's governance evidence.\n\n"
    "The approved boundary permits only the separately observed evidence/report behavior while retaining required refusal of installation, lock and formal-artifact mutations by the incompatible evaluator. "
    "The expanded real-command census and the required source/package/platform acceptance must pass before completion or VREC preparation. "
    "No lifecycle state, execution-scope path, release authority or native-host claim changes through this approval.\n"
).encode("utf-8"))
effects.append({"artifact": "WO-PLG-020", "path": work_order.relative_to(ROOT).as_posix(),
                "before_sha256": hashlib.sha256(before).hexdigest(), "after_sha256": hashlib.sha256(work_order.read_bytes()).hexdigest(),
                "effect": "record the four approved definition amendments; lifecycle and scope unchanged"})
governance = domain / "evidence/WO-PLG-020/governance"
(governance / "legacy-reader-reconciliation-proposal.md").write_bytes(raw)
receipt = {"schema": "wo-plg-020-legacy-reader-approval-v1", "recorded_at_utc": recorded_at,
           "user_instruction": instruction, "proposal_sha256": digest,
           "proposal_path": "legacy-reader-reconciliation-proposal.md", "effects": effects,
           "lifecycle_before": "in_progress", "lifecycle_after": "in_progress",
           "assurance_decision_on_implementation": False, "release_decision": False,
           "hash_semantics": "Raw local bytes at approval application; original prefixes and front matter preserved exactly."}
(governance / "legacy-reader-reconciliation-approval.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
evidence = domain / "evidence/WO-PLG-020/development"
for name, expected in [("WO-PLG-020-legacy-reader-evidence.zip", "59d0edc2a8e602416b7cdcc671cc673cf68fecdae25ff785a313b831884172f7")]:
    source = BASE / "outputs" / name
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
    shutil.copyfile(source, evidence / name)
shutil.copyfile(BASE / "outputs/WO-PLG-020-legacy-reader-evidence-index.json", evidence / "WO-PLG-020-legacy-reader-evidence-index.json")
(OUT / "approval-application.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"proposal_sha256": digest, "approved_appendices": list(targets), "status": "applied", "work_order_state": "in_progress"}))
