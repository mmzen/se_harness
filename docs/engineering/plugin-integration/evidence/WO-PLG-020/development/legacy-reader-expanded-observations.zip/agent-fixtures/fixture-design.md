# Released 0.17 compatibility-refusal fixture design

Preparation evidence only; this is not an OWN07 acceptance verdict. All mutations
were confined to disposable fixtures beneath this directory. No source or formal
authority in `work/wo20` was changed. The base fixture was copied from the retained
`work/wo20-control/legacy-writer-probe/final-valid/fixture/repository`, not rebuilt
from the latest candidate. Final acceptance must construct its own fixture using
the exact candidate under observation.

Every evaluator probe used the actual released interpreter
`work/evaluator-017/Scripts/python.exe -I -B -m se_harness`. No evaluator authority
was mocked. Every input graph returned `valid=true`, zero errors and zero warnings
under that evaluator. All six mutation probes below returned exit 2, empty stdout,
and a compatibility-specific stderr refusal ending in `unsupported lock schema`.
Before/after snapshots recorded no changed paths.

| Interface | Observed MG001 operation | Raw observations |
| --- | --- | --- |
| Ordinary intent rejection | transition-apply | run-dd09dc0a/transition-reject |
| Decide option | transition-apply | run-dd09dc0a/decision-option-apply |
| Decide defer | transition-apply | run-dd09dc0a/decision-defer-apply |
| Decide withdraw | transition-apply | run-dd09dc0a/decision-withdraw-apply |
| Delegated start | delegated-work-order-start | delegation-4d2f544d/start-apply |
| Delegated completion | delegated-work-order-complete | delegation-4d2f544d/complete-apply |

Each raw directory contains `observation.json`, `stdout.bin` and `stderr.bin`.
The JSON retains full argv, cwd, process status, raw-output SHA256 values, and
before/after path inventories. Delegated snapshots include `.git`. The scripts
and the helper source digest are recorded in each run's `summary.json`;
`delegation-4d2f544d/git-setup.json` records all fixture Git commands and outputs.

## Ordinary rejection and decision modes

The exact reusable construction is `probe.py`.

For rejection, copy the existing minimal draft `INT-LEG-001` to a new unreferenced
`INT-LEG-901`, replacing its ID, then invoke:

```text
transition ROOT --set INT-LEG-901=rejected --decision INT-LEG-901=owner --reason "INT-LEG-901=Disposable compatibility probe" --apply --json
```

For each decision mode use an independent clone with a new open `DEC-LEG-901`.
It has `kind="question"`, a nonempty question and `raised_by`, two options `first`
and `second` with labels, `recommendation="first"`, and both `concerns` and `blocks`
relations naming the existing draft requirement `REQ-LEG-001`.

```text
decide ROOT --artifact DEC-LEG-901 --decision owner --reason "Disposable compatibility probe" --option first --apply --json
decide ROOT --artifact DEC-LEG-901 --decision owner --reason "Disposable compatibility probe" --defer --scope REQ-LEG-001:draft-approved --revisit 2026-12-01 --apply --json
decide ROOT --artifact DEC-LEG-901 --decision owner --reason "Disposable compatibility probe" --withdraw --apply --json
```

## Delegated start and completion

The exact reusable construction is `delegation_probe.py`. It loads only the
candidate's test-data helper by explicit file path; the evaluator subprocess
imports the isolated released package.

Use independent clones for each state, adding the shared `create_base_chain`
with `work_order_status="approved"` for start or `"in_progress"` for completion,
and `operating_contract_status="draft"`. Rename `WO-001` to `WO-PRD-001`, replacing
its ID and references within the synthetic product domain. Give that work order:

```toml
[assurance]
commit_bound_verification = "required"
rationale = "Synthetic fixture requires exact-candidate assurance."
decided_by = "engineering-owner"

[execution_scope]
paths = ["src/"]

[delegation]
class = "execution"
```

Create `.engineering-harness.delegation.toml` with local-file source, check name
`validate`, base ref `main`, and local file `gate.json`. Append those two owner
files to `.gitignore`, initialize a local `main` branch and commit the complete
fixture with the delegation class already present. Create branch `wo/fixture`.
Write `gate.json` with actual `HEAD`, conclusion `success`, and check_run_id `4242`.
The gate is explicitly synthetic. `SE_HARNESS_REHEARSAL=1` suppresses the local
fixture warning; it does not bypass the actual mutation authority guard.

```text
transition ROOT --set WO-PRD-001=in_progress --decision WO-PRD-001=delegated-executor --apply --json
transition ROOT --set WO-PRD-001=implemented --decision WO-PRD-001=delegated-executor --apply --json
```

No handoff packet or successful implementation check is required to reach these
guards. Released `workflow.py:503-513` admits the declared right and synthetic
green gate, then requires the dedicated authority before its generic transition
gate evaluation. This observation does not qualify those later gates.

## Explicit remaining boundaries

- These six probes are fixture-design observations on Windows. The final source
  and isolated-package acceptance matrix must use its current candidate and
  retain each actual process result separately from projected API status.
- `capture-verification` with a delegated owner encounters its common
  `capture-verification` authority guard before the nested
  `delegated-vrec-prepare` guard. An unsupported schema-4 root therefore cannot
  dynamically reach that nested guard through this public CLI; retain the source
  path census as that narrower evidence, rather than inventing a nested refusal.
- Report and output-path interfaces remain separate. The parent has dynamically
  confirmed protected writes via `qualify released-root --output` and
  `dashboard --output .github`; these six refusals do not resolve those failures
  or establish overall OWN07 acceptance.
