"""Scratch-only real 0.17 retained-check observations, without evaluator mocks."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import uuid

BASE = Path(__file__).resolve().parent
CONTROL = BASE.parents[1]
LEGACY = CONTROL.parent / "evaluator-017/Scripts/python.exe"
RUN = BASE / ("check-" + uuid.uuid4().hex[:8])
RUN.mkdir()


def save(path, value):
    assert path.resolve().is_relative_to(BASE)
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def snapshot(root):
    return {p.relative_to(root).as_posix(): {"kind": "directory"} if p.is_dir() else
            {"kind": "file", "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in sorted(root.rglob("*"))}


def invoke(root, label, args):
    out = RUN / label
    out.mkdir()
    before = snapshot(root)
    before_bytes = {path: (root / path).read_bytes() for path, value in before.items() if value["kind"] == "file"}
    argv = [str(LEGACY), "-I", "-B", "-m", "se_harness", *args]
    env = dict(os.environ, SE_HARNESS_REHEARSAL="1", GIT_OPTIONAL_LOCKS="0")
    result = subprocess.run(argv, cwd=RUN, env=env, capture_output=True, timeout=90)
    after = snapshot(root)
    changed = sorted(path for path in before.keys() | after.keys() if before.get(path) != after.get(path))
    (out / "stdout.bin").write_bytes(result.stdout)
    (out / "stderr.bin").write_bytes(result.stderr)
    for index, path in enumerate(changed):
        if path in before_bytes:
            (out / f"changed-{index}-before.bin").write_bytes(before_bytes[path])
        if after.get(path, {}).get("kind") == "file":
            (out / f"changed-{index}-after.bin").write_bytes((root / path).read_bytes())
    save(out / "observation.json", {
        "argv": argv, "cwd": str(RUN), "exit_status": result.returncode,
        "explicit_environment": {"SE_HARNESS_REHEARSAL": "1", "GIT_OPTIONAL_LOCKS": "0"},
        "authority_mocked": False, "before": before, "after": after,
        "changed_destinations": changed,
        "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(),
    })
    try:
        value = json.loads(result.stdout)
        brief = {key: value[key] for key in ("valid", "error_count", "warning_count", "operation", "mutation") if key in value}
        brief["blocked_by"] = value.get("restitution", {}).get("blocked_by")
    except (ValueError, KeyError):
        brief = result.stdout.decode(errors="replace")[-1000:]
    print(json.dumps({"case": label, "exit": result.returncode, "changed": changed, "stdout": brief,
                      "stderr": result.stderr.decode(errors="replace")[-1000:]}), flush=True)


def git(root, *args):
    assert root.resolve().is_relative_to(BASE)
    value = subprocess.run(["git", "-C", str(root), *args], capture_output=True, check=True, timeout=90)
    return value.stdout.decode().strip()


for name, source, work_order, formal_path in (
    ("draft", CONTROL / "legacy-writer-probe/final-valid/fixture/repository", "WO-LEG-001",
     "docs/engineering/legacy-probe/work-orders/WO-LEG-001.md"),
    ("in-progress", BASE / "delegation-4d2f544d/complete", "WO-PRD-001",
     "docs/engineering/product/work-orders/WO-PRD-001.md"),
):
    root = RUN / name
    assert root.resolve().is_relative_to(BASE)
    shutil.copytree(source, root)
    if not (root / ".git").exists():
        git(root, "init", "-q", "-b", "main")
        git(root, "config", "user.email", "fixture@example.invalid")
        git(root, "config", "user.name", "Disposable Fixture")
        git(root, "config", "core.autocrlf", "false")
        git(root, "add", "-A")
        git(root, "commit", "-q", "--allow-empty", "-m", "Synthetic retained-check fixture")
    head = git(root, "rev-parse", "HEAD")
    invoke(root, name + "-graph", ["validate", str(root), "--json"])
    invoke(root, name + "-evidence", ["evidence", str(root), "--artifact", work_order,
           "--checkpoint", "handoff", "--rebound-at", "2026-09-12T18:00:00Z", "--json"])
    # A body-only edit changes the formal snapshot without changing any formal authority.
    path = root / formal_path
    path.write_bytes(path.read_bytes() + b"\n<!-- Synthetic body change for handoff rebind observation. -->\n")
    invoke(root, name + "-moved-graph", ["validate", str(root), "--json"])
    invoke(root, name + "-handoff", ["check", str(root), "--artifact", work_order,
           "--checkpoint", "handoff", "--from-git", head, "--json"])
    invoke(root, name + "-repeat", ["check", str(root), "--artifact", work_order,
           "--checkpoint", "handoff", "--from-git", head, "--json"])

save(RUN / "summary.json", {"classification": "disposable real released-reader observation, not acceptance",
                            "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                            "legacy_python": str(LEGACY)})
print("RETAINED " + str(RUN), flush=True)
