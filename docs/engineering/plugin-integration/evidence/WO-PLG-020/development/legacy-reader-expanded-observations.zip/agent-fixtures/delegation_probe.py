"""Disposable released-reader delegation fixture probes; not acceptance."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import uuid

BASE = Path(__file__).resolve().parent
CONTROL = BASE.parents[1]
SOURCE = CONTROL / "legacy-writer-probe/final-valid/fixture/repository"
LEGACY = CONTROL.parent / "evaluator-017/Scripts/python.exe"
HELPER = CONTROL.parent / "wo20/tests/artifact_support.py"
RUN = BASE / ("delegation-" + uuid.uuid4().hex[:8])
RUN.mkdir()
spec = importlib.util.spec_from_file_location("fixture_artifact_data", HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


def save(path, value):
    assert path.resolve().is_relative_to(BASE)
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def snapshot(root):
    return {p.relative_to(root).as_posix(): {"kind": "directory"} if p.is_dir() else
            {"kind": "file", "bytes": p.stat().st_size,
             "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in sorted(root.rglob("*"))}


def invoke(root, label, arguments):
    assert root.resolve().is_relative_to(BASE)
    out = RUN / label
    out.mkdir()
    argv = [str(LEGACY), "-I", "-B", "-m", "se_harness", *arguments]
    environment = dict(os.environ, SE_HARNESS_REHEARSAL="1")
    before = snapshot(root)
    result = subprocess.run(argv, cwd=RUN, env=environment, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=90)
    after = snapshot(root)
    (out / "stdout.bin").write_bytes(result.stdout)
    (out / "stderr.bin").write_bytes(result.stderr)
    changed = sorted(p for p in before.keys() | after.keys() if before.get(p) != after.get(p))
    save(out / "observation.json", {
        "argv": argv, "cwd": str(RUN), "exit_status": result.returncode,
        "explicit_environment": {"SE_HARNESS_REHEARSAL": "1"},
        "authority_mocked": False, "local_gate_is_synthetic": True,
        "before": before, "after": after, "changed_destinations": changed,
        "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(),
    })
    print(json.dumps({"case": label, "exit": result.returncode, "changed": changed,
                      "stdout": result.stdout.decode(errors="replace")[-2000:],
                      "stderr": result.stderr.decode(errors="replace")[-2000:]}), flush=True)
    return result


def git(root, *args):
    assert root.resolve().is_relative_to(BASE)
    result = subprocess.run(["git", "-C", str(root), *args], stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=90, check=True)
    git_log.append({"root": str(root), "argv": list(args), "exit": result.returncode,
                    "stdout": result.stdout.decode(errors="replace"),
                    "stderr": result.stderr.decode(errors="replace")})
    return result.stdout.decode().strip()


git_log = []
for name, status, target in (("start", "approved", "in_progress"),
                             ("complete", "in_progress", "implemented")):
    root = RUN / name
    assert root.resolve().is_relative_to(BASE)
    shutil.copytree(SOURCE, root)
    helper.create_base_chain(root, work_order_status=status, operating_contract_status="draft")
    original = root / "docs/engineering/product/work-orders/WO-001.md"
    work_order = original.with_name("WO-PRD-001.md")
    work_order.write_text(original.read_text(encoding="utf-8"), encoding="utf-8", newline="\n")
    original.unlink()
    for artifact in (root / "docs/engineering/product").rglob("*.md"):
        content = artifact.read_text(encoding="utf-8")
        if "WO-001" in content:
            artifact.write_text(content.replace("WO-001", "WO-PRD-001"), encoding="utf-8", newline="\n")
    content = work_order.read_text(encoding="utf-8")
    content = content.replace("[relations]", '''[assurance]
commit_bound_verification = "required"
rationale = "Synthetic fixture requires exact-candidate assurance."
decided_by = "engineering-owner"

[execution_scope]
paths = ["src/"]

[delegation]
class = "execution"

[relations]''', 1)
    work_order.write_text(content, encoding="utf-8", newline="\n")
    (root / ".engineering-harness.delegation.toml").write_text('''[delegation]
gate_source = "local-file"
check_name = "validate"
base_ref = "main"
local_file = "gate.json"
''', encoding="utf-8", newline="\n")
    ignore = root / ".gitignore"
    existing = ignore.read_text(encoding="utf-8") if ignore.exists() else ""
    ignore.write_text(existing.rstrip("\n") + "\ngate.json\n.engineering-harness.delegation.toml\n*.log\n",
                      encoding="utf-8", newline="\n")
    git(root, "init", "-q", "-b", "main")
    git(root, "config", "user.email", "fixture@example.invalid")
    git(root, "config", "user.name", "Disposable Fixture")
    git(root, "config", "core.autocrlf", "false")
    git(root, "add", "-A")
    git(root, "commit", "-q", "--allow-empty", "-m", "Synthetic delegated fixture baseline")
    git(root, "checkout", "-q", "-b", "wo/fixture")
    sha = git(root, "rev-parse", "HEAD")
    save(root / "gate.json", {"sha": sha, "conclusion": "success", "check_run_id": "4242"})
    invoke(root, name + "-graph", ["validate", str(root), "--json"])
    invoke(root, name + "-apply", ["transition", str(root), "--set", "WO-PRD-001=" + target,
           "--decision", "WO-PRD-001=delegated-executor", "--apply", "--json"])

save(RUN / "git-setup.json", git_log)
save(RUN / "summary.json", {
    "classification": "disposable fixture-design observations, not acceptance",
    "source_fixture": str(SOURCE), "legacy_python": str(LEGACY),
    "fixture_helper": str(HELPER), "fixture_helper_sha256": hashlib.sha256(HELPER.read_bytes()).hexdigest(),
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
})
print("RETAINED " + str(RUN), flush=True)
