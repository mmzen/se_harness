"""Scratch-only fixture investigation; no checkout or real authority is changed."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid

BASE = Path(__file__).resolve().parent
CONTROL = BASE.parents[1]
SOURCE = CONTROL / "legacy-writer-probe/final-valid/fixture/repository"
LEGACY = CONTROL.parent / "evaluator-017/Scripts/python.exe"
RUN = BASE / ("run-" + uuid.uuid4().hex[:8])
RUN.mkdir()

def snapshot(root):
    return {path.relative_to(root).as_posix():
            {"kind": "directory"} if path.is_dir() else
            {"kind": "file", "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
            for path in sorted(root.rglob("*"))}

def save(path, value):
    assert path.resolve().is_relative_to(BASE)
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n", encoding="utf-8")

def invoke(root, label, arguments, env=None):
    assert root.resolve().is_relative_to(BASE)
    output = RUN / label
    output.mkdir()
    argv = [str(LEGACY), "-I", "-B", "-m", "se_harness", *arguments]
    before = snapshot(root)
    result = subprocess.run(argv, cwd=RUN, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
    after = snapshot(root)
    (output / "stdout.bin").write_bytes(result.stdout)
    (output / "stderr.bin").write_bytes(result.stderr)
    changed = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
    record = {"argv": argv, "cwd": str(RUN), "exit_status": result.returncode,
              "before": before, "after": after, "changed_destinations": changed,
              "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
              "stderr_sha256": hashlib.sha256(result.stderr).hexdigest()}
    save(output / "observation.json", record)
    print(json.dumps({"case": label, "exit": result.returncode, "changed": changed,
                      "stdout": result.stdout.decode(errors="replace")[-1400:],
                      "stderr": result.stderr.decode(errors="replace")[-1400:]}), flush=True)
    return result

def clone(name):
    target = RUN / name
    assert target.resolve().is_relative_to(BASE)
    shutil.copytree(SOURCE, target)
    return target

root = clone("ordinary-transition")
intent = root / "docs/engineering/legacy-probe/intent/INT-LEG-901.md"
intent.write_bytes((SOURCE / "docs/engineering/legacy-probe/intent/INT-LEG-001.md").read_bytes().replace(b"INT-LEG-001", b"INT-LEG-901"))
invoke(root, "transition-graph", ["validate", str(root), "--json"])
invoke(root, "transition-reject", ["transition", str(root), "--set", "INT-LEG-901=rejected",
       "--decision", "INT-LEG-901=owner", "--reason", "INT-LEG-901=Disposable compatibility probe", "--apply", "--json"])

decision = '''+++
id = "DEC-LEG-901"
type = "decision"
title = "Disposable compatibility question"
status = "open"
owners = ["owner"]
created = "2026-09-12"
updated = "2026-09-12"
kind = "question"
question = "Which fixture option applies?"
raised_by = "fixture-author"
recommendation = "first"
[[options]]
id = "first"
label = "Select the first fixture option."
[[options]]
id = "second"
label = "Select the second fixture option."
[relations]
concerns = ["REQ-LEG-001"]
blocks = ["REQ-LEG-001"]
+++

# Disposable compatibility question
'''
for name, mode in (
    ("option", ["--option", "first"]),
    ("defer", ["--defer", "--scope", "REQ-LEG-001:draft-approved", "--revisit", "2026-12-01"]),
    ("withdraw", ["--withdraw"]),
):
    root = clone("decision-" + name)
    path = root / "docs/engineering/legacy-probe/decisions/DEC-LEG-901.md"
    path.parent.mkdir(exist_ok=True)
    path.write_text(decision, encoding="utf-8", newline="\n")
    invoke(root, "decision-" + name + "-graph", ["validate", str(root), "--json"])
    invoke(root, "decision-" + name + "-apply", ["decide", str(root), "--artifact", "DEC-LEG-901",
           "--decision", "owner", "--reason", "Disposable compatibility probe", *mode, "--apply", "--json"])

save(RUN / "summary.json", {"classification": "disposable fixture-design observations, not acceptance",
                            "source_fixture": str(SOURCE), "legacy_python": str(LEGACY),
                            "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
print("RETAINED " + str(RUN), flush=True)
