"""Run real legacy commands only on newly created disposable fixture trees."""
import base64
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
LEGACY = OUT.parent.parent / "evaluator-017/Scripts/python.exe"
WHEEL = OUT / "candidate-dist/se_harness-0.18.0-py3-none-any.whl"
os.environ["SE_HARNESS_OWNERSHIP_PACKAGE"] = "1"
os.environ["SE_HARNESS_OWNERSHIP_WHEEL"] = str(WHEEL)

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

support = load("ownership_output_probe", ROOT / "tests/test_skill_ownership.py")
artifacts = load("ownership_artifact_probe", ROOT / "tests/artifact_support.py")
from se_harness import installer, skill_ownership
from se_harness.evaluator_identity import installed_evaluator_identity
import se_harness
assert not Path(se_harness.__file__).resolve().is_relative_to(ROOT)
assert support.sha(WHEEL.read_bytes()) == "50ad9892255aaf881f643c52e07e237022090393c82054b7983d9cbca58735fe"

def fixture(name):
    item = support.SkillOwnershipAcceptanceTests()
    item.base = OUT / "output-probes" / name / "fixture"
    item.base.mkdir(parents=True, exist_ok=False)
    item.root = item.base / "repository"
    item.identity = installed_evaluator_identity()
    item.wheel_bytes = WHEEL.read_bytes()
    item.events = []
    changes, old = installer.plan_install(item.root, project_name="legacy-output-probe", mode="init")
    installer.apply_changes(item.root, changes, old, allow_updates=False)
    entries = [
        ("intent", "INT-LEG-001", "intent", {}),
        ("capabilities", "CAP-LEG-001", "capability", {"derives_from": ["INT-LEG-001"]}),
        ("requirements", "REQ-LEG-001", "requirement", {"derives_from": ["CAP-LEG-001"]}),
        ("specifications", "SPEC-LEG-001", "specification", {"specifies": ["REQ-LEG-001"]}),
        ("verification", "VER-LEG-001", "verification", {"verifies": ["REQ-LEG-001"]}),
        ("work-orders", "WO-LEG-001", "work_order", {"implements": ["REQ-LEG-001"], "specifications": ["SPEC-LEG-001"], "verification": ["VER-LEG-001"]}),
    ]
    for folder, identifier, kind, relations in entries:
        extra = '[execution_scope]\npaths = ["src/probe.py"]' if kind == "work_order" else ""
        artifacts.write(item.root / "docs/engineering/legacy-probe" / folder / (identifier + ".md"),
                        artifacts.formal(identifier, kind, "draft", relations, extra, complete=True))
    artifacts.write(item.root / ".agents/skills/harness-orient/owner-note.txt", b"Owner content preserves this ordinary parent.\n")
    item.plugins = {}
    item.binding_path = item.base / "binding.json"
    item.binding = item.make_binding(("codex", "claude"))
    item.write_binding()
    plan = skill_ownership.plan_skill_ownership(item.root, provider="plugin", binding_input=item.binding_path)
    assert plan["passed"], plan
    result = skill_ownership.apply_skill_ownership(item.root, provider="plugin", binding_input=item.binding_path, expected_plan_sha256=plan["plan_sha256"])
    assert result["passed"], result
    (item.base.parent / "setup.json").write_bytes(support.canonical({"candidate_wheel_sha256": support.sha(item.wheel_bytes),
        "identity": item.identity.to_lock(), "plan": plan, "result": result}))
    return item

def run(item, name, executable, arguments):
    before = support.snapshot(item.base)
    before_bytes = {path: (item.base / path).read_bytes() for path, entry in before.items() if entry["kind"] == "file"}
    args = [str(executable), "-I", "-B", "-m", "se_harness", *arguments]
    result = subprocess.run(args, cwd=item.base, capture_output=True, timeout=120)
    after = support.snapshot(item.base)
    changed = sorted(path for path in before.keys() | after.keys() if before.get(path) != after.get(path))
    raw_changes = {path: {"before_base64": base64.b64encode(before_bytes[path]).decode() if path in before_bytes else None,
                           "after_base64": base64.b64encode((item.base / path).read_bytes()).decode() if after.get(path, {}).get("kind") == "file" else None}
                   for path in changed}
    observation = {"argv": args, "cwd": str(item.base), "exit_status": result.returncode,
                   "stdout": result.stdout.decode(errors="replace"), "stderr": result.stderr.decode(errors="replace"),
                   "before": before, "after": after, "changed_destinations": changed, "raw_changes": raw_changes}
    (item.base.parent / (name + ".json")).write_bytes(support.canonical(observation))
    (item.base.parent / (name + ".stdout.bin")).write_bytes(result.stdout)
    (item.base.parent / (name + ".stderr.bin")).write_bytes(result.stderr)
    print(json.dumps({"fixture": item.base.parent.name, "probe": name, "exit_status": result.returncode,
                      "changed": changed, "stdout_prefix": observation["stdout"][:650], "stderr": observation["stderr"][:500]}), flush=True)
    return observation

for name in ("qualification-retired-core", "dashboard-installed-workflow"):
    item = fixture(name)
    assert run(item, "candidate-doctor", sys.executable, ["doctor", str(item.root), "--json"])["exit_status"] == 0
    assert run(item, "released-validate", LEGACY, ["validate", str(item.root), "--json"])["exit_status"] == 0
    assert run(item, "released-version", LEGACY, ["--version"])["exit_status"] == 0
    if name.startswith("qualification"):
        target = item.root / ".agents/skills/harness-orient/SKILL.md"
        assert not target.exists() and target.parent.is_dir()
        run(item, "released-protected-output", LEGACY, ["qualify", "released-root", str(item.root), "--output", str(target), "--json"])
    else:
        target = item.root / ".github/workflows/engineering-harness.yml"
        assert target.is_file()
        run(item, "released-protected-output", LEGACY, ["dashboard", str(item.root), "--output", ".github", "--json"])
