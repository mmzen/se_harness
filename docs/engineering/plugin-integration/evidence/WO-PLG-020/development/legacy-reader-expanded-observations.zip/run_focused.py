"""Retain development observations of the added OWN07 cases, including failures."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import unittest

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
mode, attempt = sys.argv[1:3]
destination = OUT / (mode + "-" + attempt)
destination.mkdir(exist_ok=False)
os.environ["SE_HARNESS_OWNERSHIP_LEGACY_PYTHON"] = str(OUT.parent.parent / "evaluator-017/Scripts/python.exe")
os.environ["SE_HARNESS_OWNERSHIP_EVIDENCE"] = str(destination / "cases")
os.environ["SE_HARNESS_OWNERSHIP_COMMIT"] = "69e655686fdc460cb2da7bb882645e2471aecdc9+uncommitted-approved-OWN07-tests"
if mode == "installed":
    os.environ["SE_HARNESS_OWNERSHIP_PACKAGE"] = "1"
    os.environ["SE_HARNESS_OWNERSHIP_WHEEL"] = str(OUT / "candidate-dist/se_harness-0.18.0-py3-none-any.whl")
else:
    os.environ.pop("SE_HARNESS_OWNERSHIP_PACKAGE", None)
    sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location("ownership_focused", ROOT / "tests/test_skill_ownership.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
names = [name for name in unittest.defaultTestLoader.getTestCaseNames(module.SkillOwnershipAcceptanceTests)
         if name.startswith("test_own07_released_017_") and name != "test_own07_released_017_cli_format_and_command_refusals"]
if len(sys.argv) > 3:
    names = [name for name in names if any(part in name for part in sys.argv[3:])]
suite = unittest.TestSuite(module.SkillOwnershipAcceptanceTests(name) for name in names)
start = time.monotonic()
with (destination / "tests.log").open("w", encoding="utf-8") as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
summary = {"classification": "focused development observations; not complete acceptance",
           "mode": mode, "executable": sys.executable, "seconds": time.monotonic() - start,
           "tests_run": result.testsRun, "failures": [(case.id(), failure) for case, failure in result.failures],
           "errors": [(case.id(), error) for case, error in result.errors], "skipped": result.skipped,
           "test_sources": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
                            for name in ("tests/test_skill_ownership.py", "tests/fixtures/skill_ownership/legacy_reader.py")}}
(destination / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"destination": str(destination), "tests": result.testsRun, "failures": len(result.failures),
                  "errors": len(result.errors), "skipped": len(result.skipped), "seconds": summary["seconds"]}), flush=True)
raise SystemExit(not result.wasSuccessful())
