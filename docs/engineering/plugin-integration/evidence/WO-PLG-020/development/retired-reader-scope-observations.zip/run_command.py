import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
label = sys.argv[1]
argv = [sys.executable, "-B", *sys.argv[2:]]
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
environment.pop("SE_HARNESS_OWNERSHIP_PACKAGE", None)
environment.pop("SE_HARNESS_OWNERSHIP_LEGACY_PYTHON", None)
start = time.monotonic()
with (OUT / (label + ".stdout.log")).open("wb") as output, (OUT / (label + ".stderr.log")).open("wb") as error:
    result = subprocess.run(argv, cwd=ROOT, env=environment, stdout=output, stderr=error)
record = {"argv": argv, "cwd": str(ROOT), "exit": result.returncode, "seconds": time.monotonic() - start}
(OUT / (label + ".json")).write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(record), flush=True)
print((OUT / (label + ".stderr.log")).read_text(errors="replace")[-1800:], flush=True)
raise SystemExit(result.returncode)
