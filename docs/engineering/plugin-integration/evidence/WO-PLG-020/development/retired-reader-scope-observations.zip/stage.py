import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tomllib

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
EVIDENCE = "docs/engineering/plugin-integration/evidence/WO-PLG-020/"
TRANSPORT = EVIDENCE + "governance/retired-reader-scope-byte-transport.json"
if sys.argv[1] == "reserve":
    (ROOT / TRANSPORT).write_text("{}\n", encoding="utf-8")
    raise SystemExit()
def git(*args):
    return subprocess.check_output(["git", "-c", "core.safecrlf=false", *args], cwd=ROOT)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert not git("diff", "--cached", "--name-only")
assert not git("diff", "--name-only", "--", "se_harness", "tests/test_suite_hygiene.py", ".github")
handoff = json.loads((OUT / "handoff.json").read_bytes())
assert handoff["operation"]["outcome"] == "completed" and not handoff["restitution"]["blocked_by"]
approval = json.loads((OUT / "scope-approval.json").read_bytes())
for effect in approval["effects"]:
    assert sha((ROOT / effect["path"]).read_bytes()) == effect["after_sha256"], effect["path"]
metadata = tomllib.loads((ROOT / "docs/engineering/plugin-integration/work-orders/WO-PLG-020.md").read_text().split("+++", 2)[1])
assert metadata["status"] == "in_progress"
scope = metadata["execution_scope"]["paths"]
changes = set(filter(None, git("diff", "--name-only", "-z").decode().split("\0")))
changes.update(filter(None, git("ls-files", "--others", "--exclude-standard", "-z").decode().split("\0")))
for name in changes:
    assert any(name == item or item.endswith("/") and name.startswith(item) for item in scope), name
normal = sorted(name for name in changes if not name.startswith(EVIDENCE))
git("add", "--", *normal)
git("-c", "core.autocrlf=false", "add", "--", EVIDENCE)
entries = []
for name in sorted(changes - {TRANSPORT}):
    raw, staged = (ROOT / name).read_bytes(), git("show", ":" + name)
    assert staged == (raw if name.startswith(EVIDENCE) else raw.replace(b"\r\n", b"\n")), name
    entries.append({"path": name, "working_sha256": sha(raw), "git_blob_sha256": sha(staged),
        "transport": "identical" if staged == raw else "CRLF-to-LF normalization only"})
record = {"schema": "wo-plg-020-retired-reader-scope-transport-v1", "parent_commit": git("rev-parse", "HEAD").decode().strip(),
    "user_instruction": approval["user_instruction"], "scope_decision": "exclude old 0.17 migration behavior from required acceptance",
    "files": entries, "self_excluded": TRANSPORT, "local_handoff_result_sha256": handoff["result_sha256"],
    "hygiene_checker_and_product_source_unchanged": True, "historical_failures_preserved": True,
    "lifecycle": "in_progress", "vrec_prepared": False}
(ROOT / TRANSPORT).write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n")
git("-c", "core.autocrlf=false", "add", "--", TRANSPORT)
git("-c", "core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol", "diff", "--cached", "--check")
assert not git("diff", "--name-only")
(OUT / "commit-message.txt").write_text("""Limit ownership acceptance to the migration-capable candidate

Record the operator's explicit exclusion of old 0.17 behavior on migrated
schema-4 targets. Preserve historical failures and keep candidate output
protection and unsupported-lock checks required.

Remove the nine legacy-reader cases from active acceptance. Removing the
eight inherited cases also restores exact test discovery without changing
the hygiene checker. Keep WO-PLG-020 in progress pending candidate CI.

Harness-Work-Order: WO-PLG-020
""", encoding="utf-8", newline="\n")
print(json.dumps({"files": len(changes), "byte_transport": "verified", "lifecycle": "in_progress"}))
