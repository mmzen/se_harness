"""Retain changed acceptance evidence and make the current boundary prominent."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
EVIDENCE = ROOT / "docs/engineering/plugin-integration/evidence/WO-PLG-020"
sha = lambda raw: hashlib.sha256(raw).hexdigest()
source = json.loads((OUT / "source-regression.json").read_bytes())
assert source["exit"] == 0
logs = "\n".join((OUT / ("source-regression." + channel + ".log")).read_text(errors="replace") for channel in ("stdout", "stderr"))
counts = re.search(r"Ran (\d+) tests in ([\d.]+)s", logs)
assert counts and "FAILED" not in logs
source_run = int(counts.group(1))
skipped = re.search(r"OK \(skipped=(\d+)\)", logs)
source_skipped = int(skipped.group(1)) if skipped else 0
installed = json.loads((OUT / "installed-smoke.json").read_bytes())
assert installed["tests"] == 8 and not any(installed[k] for k in ("failures", "errors", "skipped"))
focused = (OUT / "focused.stderr.log").read_text()
assert "Ran 18 tests" in focused and "\nOK" in focused
approval = json.loads((OUT / "scope-approval.json").read_bytes())
for effect in approval["effects"]:
    assert sha((ROOT / effect["path"]).read_bytes()) == effect["after_sha256"]
for archive, expected in {
    "WO-PLG-020-legacy-reader-evidence.zip": "59d0edc2a8e602416b7cdcc671cc673cf68fecdae25ff785a313b831884172f7",
    "legacy-reader-expanded-observations.zip": "9f7795a56f5ca978a1f72d866f75c71d11a64541b5e70ddaa69c9bda48dee095",
    "report-output-repair-observations.zip": "bffcee4bd31e0afba18fb30f1ed2f537a60364d3ed47549b812cfb75cd429466",
}.items():
    assert sha((EVIDENCE / "development" / archive).read_bytes()) == expected
summary = {"classification": "Revised candidate acceptance scope; historical 0.17 findings excluded, not passed.",
    "source_tests": source_run, "source_skipped": source_skipped, "source_failed": 0,
    "source_process_seconds": source["seconds"], "focused_tests": 18,
    "installed_smoke_tests": 8, "installed_smoke_seconds": installed["seconds"],
    "active_ownership_selection": {"smoke": 8, "full": 53},
    "old_017_cases_removed_from_required_selection": 9,
    "installed_wheel_sha256": installed["wheel_sha256"],
    "limits": ["Local development source and unchanged development wheel; new committed-candidate CI is still required.",
        "Local source regression uses the runner's default reduced scale; hosted full-scale source and OS/Python matrix remain required.",
        "No product source, hygiene checker, predecessor rehearsal or installed root file was changed.",
        "Scope exclusion is the operator's explicit decision; historical failing outputs and assertions remain unchanged in evidence."],
    "lifecycle": "in_progress", "vrec_prepared": False}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
members = {}
for path in OUT.iterdir():
    if path.is_file() and path.suffix in {".json", ".log", ".py"}:
        members[path.name] = path.read_bytes()
for path in (OUT / "installed-cases").glob("*.json"):
    value = json.loads(path.read_bytes())
    assert value["case_outcome"] == "passed", path
    members[path.relative_to(OUT).as_posix()] = path.read_bytes()
for name in ["tests/test_skill_ownership.py", "tests/test_report_output_safety.py", "tests/test_suite_hygiene.py", "tests/fixtures/skill_ownership/README.md"]:
    members["tested-source/" + name] = (ROOT / name).read_bytes()
archive = EVIDENCE / "development/retired-reader-scope-observations.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
    for name, raw in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 9, 12, 21, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        stream.writestr(info, raw)
with zipfile.ZipFile(archive) as stream:
    assert stream.testzip() is None
    assert all(stream.read(name) == raw for name, raw in members.items())
index = {"archive": archive.name, "archive_sha256": sha(archive.read_bytes()), "bytes": archive.stat().st_size,
    "summary": summary, "members": {name: {"bytes": len(raw), "sha256": sha(raw)} for name, raw in sorted(members.items())}}
(archive.with_name("retired-reader-scope-index.json")).write_text(json.dumps(index, indent=2) + "\n", encoding="utf-8", newline="\n")
for name in ("preflight", "doctor", "validation"):
    shutil.copyfile(OUT / (name + ".json"), EVIDENCE / "governance" / ("retired-reader-scope-" + name + ".json"))

current = f"""## Current acceptance after the operator's 0.17 exclusion

The operator instructed "we don't care about 0.17, just ignore". The
[scope receipt](governance/retired-reader-scope-approval.json) records the
technical-owner, assurance-owner and engineering-owner decisions. New appendices
in SPEC-PLG-020, ARCH-PLG-003, ADR-PLG-003 and VER-PLG-020 supersede the prior
requirement to qualify already distributed 0.17 against migrated schema-4 targets.
Those historical results remain unchanged and no longer block this work order.

The active candidate still must preserve ownership and protected report paths,
refuse unsupported locks, recover safely and satisfy the remaining acceptance
matrix. Nine old-reader cases were removed from the required selection. The
eight inherited cases caused the CI discovery-count mismatch; removing their
inheritance restores exact discovery without changing the hygiene checker.
`legacy_reader.py` remains an unimported historical fixture. Current ownership
selections contain 8 smoke and 53 full tests, with both candidate report-output
cases included.

Local validation: {source_run} source tests completed with {source_skipped} explicit
skips and no failures; all 18 focused discovery/report checks and all 8 installed
smoke cases passed. The installed run used the unchanged development wheel
`{installed['wheel_sha256']}`;
all product Python bytes match modulo recorded line-ending transport, but this
is not a newly qualified committed candidate. Local source regression used the
default reduced scale. See the [new index](development/retired-reader-scope-index.json)
and its raw archive for commands, counts, original bytes and limitations.

The root-pinned released governor, released-verifier package lane and ordinary
predecessor upgrade rehearsal remain unchanged. Required full-scale source and
source/package platform results for the new immutable head remain pending.
WO-PLG-020 stays `in_progress`; VREC-PLG-015 is unprepared. Select `continue`
until those candidate results and the completion gate actually pass.

The dated sections below retain the prior iterations' facts and former blockers.

"""
for filename, marker in (("README.md", "## Governing start"), ("WO-PLG-020-handoff.md", "## Implementation review")):
    path = EVIDENCE / filename
    raw = path.read_bytes()
    assert b"## Current acceptance after the operator" not in raw
    assert marker.encode() in raw
    path.write_bytes(raw.replace(marker.encode(), current.encode() + marker.encode(), 1))
report = f"""# WO-PLG-020: old 0.17 excluded from migration acceptance

Your instruction is recorded in the governing criteria. Old 0.17 behavior on a
migrated repository no longer blocks this work order. Its historical failures
remain in the evidence; they are not counted as passes.

The new candidate's two report protections stay required. The discovery mismatch
is fixed by removing the old test inheritance. The hygiene check is unchanged.

- Source regression: {source_run - source_skipped} passed, {source_skipped} explicit skips.
- Focused discovery/report checks: 18 passed.
- Installed candidate smoke: all 8 passed, no skips.
- Active ownership selections: 8 smoke and 53 full tests.

These are local development results. New committed-candidate CI must still pass
before WO-PLG-020 can be completed. VREC-PLG-015 remains unprepared.
"""
(ROOT.parents[1] / "outputs/WO-PLG-020-current-acceptance.md").write_text(report, encoding="utf-8", newline="\n")
print(json.dumps({"source_tests": source_run, "source_skips": source_skipped, "installed_smoke": 8,
    "archive_sha256": index["archive_sha256"], "members": len(members)}))
