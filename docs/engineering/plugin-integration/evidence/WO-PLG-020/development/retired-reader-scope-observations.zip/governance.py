import json
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
EVALUATOR = ROOT.parent / "evaluator-017/Scripts/python.exe"
BASE = "6559568e995fc6e28f64e6bc5a6d4a6dc5dcf7de"
phase = sys.argv[1]
selected = [("preflight", ["preflight", str(ROOT), "--work-order", "WO-PLG-020", "--phase", "review", "--json"]),
    ("doctor", ["doctor", str(ROOT), "--json"]), ("validation", ["validate", str(ROOT), "--json"])] if phase == "pre" else [
    (name, ["check", str(ROOT), "--artifact", "WO-PLG-020", "--checkpoint", name, "--from-git", BASE, "--json"])
    for name in ("scope", "handoff")]
records = []
for label, args in selected:
    argv = [str(EVALUATOR), "-I", "-B", "-m", "se_harness", *args]
    start = time.monotonic()
    result = subprocess.run(argv, cwd=OUT, capture_output=True)
    (OUT / (label + ".json")).write_bytes(result.stdout)
    (OUT / (label + ".stderr.log")).write_bytes(result.stderr)
    data = json.loads(result.stdout)
    assert result.returncode == 0, (label, data)
    if label == "preflight":
        assert data["ready"]
    elif label == "doctor":
        assert all(item["passed"] for item in data["checks"])
    elif label == "validation":
        assert data["valid"] and not data["errors"]
    else:
        assert data["operation"]["outcome"] == "completed" and not data["restitution"]["blocked_by"]
    record = {"label": label, "argv": argv, "cwd": str(OUT), "exit": result.returncode,
        "seconds": time.monotonic() - start, "decision_required": data.get("restitution", {}).get("decision_required"),
        "result_sha256": data.get("result_sha256")}
    records.append(record)
    print(json.dumps(record), flush=True)
(OUT / (phase + "-commands.json")).write_text(json.dumps(records, indent=2) + "\n", encoding="utf-8", newline="\n")
