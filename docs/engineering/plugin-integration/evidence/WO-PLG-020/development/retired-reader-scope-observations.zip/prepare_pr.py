"""Obtain the declaration from released code using the CI checkout's ref layout."""
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
CHECKOUT = ROOT.parent / "wp20"
EVALUATOR = ROOT.parent / "evaluator-017/Scripts/python.exe"
BASE = "6559568e995fc6e28f64e6bc5a6d4a6dc5dcf7de"
records = []
def run(argv, cwd=OUT):
    result = subprocess.run(argv, cwd=cwd, capture_output=True)
    records.append({"argv": argv, "cwd": str(cwd), "exit": result.returncode})
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors="replace"))
    return result.stdout
HEAD = run(["git", "-C", str(ROOT), "rev-parse", "HEAD"]).decode().strip()
assert CHECKOUT.resolve().parent == ROOT.resolve().parent and CHECKOUT != ROOT
assert run(["git", "-C", str(CHECKOUT), "remote", "get-url", "origin"]).decode().strip() == "https://github.com/mmzen/se_harness.git"
generated = {"docs/engineering/plugin-integration/evidence/WO-PLG-020/handoff.json",
    "docs/engineering/plugin-integration/evidence/WO-PLG-020/WO-PLG-020-handoff.md"}
dirty = set(filter(None, run(["git", "-C", str(CHECKOUT), "diff", "--name-only", "-z"]).decode().split("\0")))
assert dirty <= generated
assert not run(["git", "-C", str(CHECKOUT), "diff", "--cached", "--name-only"])
if dirty:
    run(["git", "-C", str(CHECKOUT), "restore", "--source=HEAD", "--", *sorted(dirty)])
run(["git", "-C", str(CHECKOUT), "fetch", "--quiet", "--depth=1", str(ROOT), HEAD, BASE])
run(["git", "-C", str(CHECKOUT), "checkout", "--quiet", "--detach", HEAD])
assert subprocess.run(["git", "-C", str(CHECKOUT), "show-ref", "--verify", "refs/remotes/origin/main"], capture_output=True).returncode != 0
raw = run([str(EVALUATOR), "-I", "-B", "-m", "se_harness", "check", str(CHECKOUT),
    "--artifact", "WO-PLG-020", "--checkpoint", "handoff", "--from-git", BASE, "--json"])
(OUT / "ci-shape-handoff.json").write_bytes(raw)
data = json.loads(raw)
assert data["operation"]["outcome"] == "completed" and not data["restitution"]["blocked_by"]
assert data["restitution"]["decision_required"]["role"] == "engineering-owner"
summary = json.loads((OUT / "summary.json").read_bytes())
digest = data["result_sha256"]
body = f"""Harness-Work-Order: WO-PLG-020
Harness-Restitution: {digest}

## Summary

Add explicit migration and restoration of retained repository skills through `skill-ownership <target>`. An exact reviewed plan digest controls a recoverable transaction over the seven-file catalog. Shared installation and integrity checks preserve plugin ownership through supported operations and compatible upgrades.

Protect report destinations in the candidate. Qualification retains its repository output exclusion even when inspection fails. Dashboard generation refuses output trees overlapping installed templates, ownership controls, Git metadata or protected discovery paths; normal report folders remain usable. Windows aliases and destination changes before promotion are covered.

Retain the approved CI/CLI reconciliation and the bounded-read optimization. The earlier Windows full ownership steps fell from 20m27s to 10m46s combined across hosted runs; the controlled same-VM experiments and their limits remain in the evidence. CI uses one non-promotable candidate wheel across Ubuntu/Windows source and package observations, with Python 3.11 smoke and Python 3.13 full ownership coverage.

## Current acceptance scope

The operator explicitly instructed **"we don't care about 0.17, just ignore"** after reviewing its report-output failures. The new approved SPEC-PLG-020, ARCH-PLG-003, ADR-PLG-003 and VER-PLG-020 appendices exclude already distributed 0.17 behavior on migrated schema-4 repositories from this work order's acceptance. The earlier contrary observations remain historical failures; they are no longer completion blockers and are not counted as passing tests.

Remove the nine old-reader migration cases from active acceptance. Removing the eight inherited cases also fixes the previous CI discovery mismatch without modifying the hygiene checker. The retained historical fixture is no longer imported. Current ownership selections have **8 smoke and 53 full tests**, including candidate qualification/dashboard protection and unsupported-lock refusal. Every remaining candidate test method and helper is unchanged.

The root-pinned released governor, released-verifier package lane and ordinary predecessor upgrade rehearsal retain their existing roles. The support decision changes neither the installed 0.17 executable nor the candidate's required protection and recovery behavior.

## Validation

- Local source regression: {summary['source_tests']} tests, {summary['source_skipped']} explicit skips, no failures, using the runner's default reduced scale.
- All 18 focused discovery/report checks passed.
- All 8 revised installed-candidate smoke tests passed with no skips and no authority mocks. They use the unchanged development wheel `{summary['installed_wheel_sha256']}`; product Python bytes match modulo recorded line endings. These are development observations, not new immutable-candidate qualification.
- Released-evaluator preflight, doctor, graph, scope and handoff checks passed. The PR declaration comes from an actual released-evaluator run with the CI checkout's ref layout.
- Historical archives and failure bytes remain unchanged. Product source, the hygiene checker and the CI workflow were not changed by this acceptance-scope continuation.

Fresh hosted full-scale source and source/package platform observations must pass for this commit. Earlier green CI applies only to its recorded candidate. **WO-PLG-020 remains in_progress; VREC-PLG-015 is unprepared.** Evaluator release/adoption, live WO-PLG-009 connection, native activation and the accepted C10/C11 limitation remain outside this implementation result.

## Retained evidence

- [Current evidence index](docs/engineering/plugin-integration/evidence/WO-PLG-020/README.md)
- [Current handoff](docs/engineering/plugin-integration/evidence/WO-PLG-020/WO-PLG-020-handoff.md)
- [Operator scope decision](docs/engineering/plugin-integration/evidence/WO-PLG-020/governance/retired-reader-scope-approval.json)
- [Revised selection and local results](docs/engineering/plugin-integration/evidence/WO-PLG-020/development/retired-reader-scope-index.json)
- [Candidate output repairs](docs/engineering/plugin-integration/evidence/WO-PLG-020/development/report-output-repair-index.json)
- [Historical 0.17 observations](docs/engineering/plugin-integration/evidence/WO-PLG-020/development/legacy-reader-expanded-index.json)
- [Publication byte transport](docs/engineering/plugin-integration/evidence/WO-PLG-020/governance/retired-reader-scope-byte-transport.json)
"""
body = body.replace("](docs/", f"](https://github.com/mmzen/se_harness/blob/{HEAD}/docs/")
(OUT / "pr-body.md").write_text(body, encoding="utf-8", newline="\n")
(OUT / "publication-preparation.json").write_text(json.dumps({"head": HEAD, "base": BASE, "digest": digest, "commands": records}, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"head": HEAD, "digest": digest, "outcome": "completed"}))
