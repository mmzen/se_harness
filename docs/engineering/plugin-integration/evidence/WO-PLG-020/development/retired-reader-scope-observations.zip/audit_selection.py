import ast
import json
from pathlib import Path
import subprocess
import sys
import unittest

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
name = "tests/test_skill_ownership.py"
before = ast.parse(subprocess.check_output(["git", "show", "HEAD:" + name], cwd=ROOT))
after = ast.parse((ROOT / name).read_bytes())
def methods(tree):
    case = next(item for item in tree.body if isinstance(item, ast.ClassDef) and item.name == "SkillOwnershipAcceptanceTests")
    return {item.name: ast.dump(item, include_attributes=False) for item in case.body if isinstance(item, ast.FunctionDef)}
old, new = methods(before), methods(after)
assert set(old) - set(new) == {"test_own07_released_017_cli_format_and_command_refusals"}
assert all(value == old[key] for key, value in new.items())
sys.path.insert(0, str(ROOT))
from tests import test_skill_ownership as module
active = unittest.defaultTestLoader.getTestCaseNames(module.SkillOwnershipAcceptanceTests)
assert not any("released_017" in value for value in active)
assert all(name in active and name in module.SMOKE_TESTS for name in (
    "test_own07_candidate_qualification_output_preserves_retired_skill",
    "test_own07_candidate_dashboard_output_preserves_installed_workflow",
    "test_own07_unsupported_old_lock_refuses_before_writes"))
assert module.acceptance_suite(True).countTestCases() == 8
assert module.acceptance_suite().countTestCases() == 53
assert not subprocess.check_output(["git", "diff", "--name-only", "--", "se_harness", "tests/test_report_output_safety.py", "tests/test_suite_hygiene.py", ".github/workflows/candidate-evidence.yml", "tests/fixtures/skill_ownership/legacy_reader.py"], cwd=ROOT)
result = {"removed_direct_cases": sorted(set(old) - set(new)), "removed_inherited_cases": 8,
    "remaining_test_methods_and_helpers_unchanged": True,
    "candidate_report_and_unsupported_lock_cases_still_in_smoke": True,
    "smoke": 8, "full": 53, "hygiene_checker_unchanged": True,
    "product_source_unchanged": True, "ci_workflow_unchanged": True, "historical_fixture_unchanged": True}
(OUT / "selection-audit.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(result))
