"""Record the operator's explicit acceptance-scope decision without rewriting history."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
EVIDENCE = ROOT / "docs/engineering/plugin-integration/evidence/WO-PLG-020"
instruction = "we don't care about 0.17, just ignore"
recorded = datetime.now(timezone.utc).isoformat()
sha = lambda raw: hashlib.sha256(raw).hexdigest()
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT)
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
assert head == "113bec75c8e985b1306ff896cb236db093f99642"
changes = {
    "specifications/SPEC-PLG-020.md": ("technical-owner", """This appendix supersedes the released-0.17 obligations in PLG-OWN-012, its old-evaluator failure row and the preceding legacy-reader reconciliation. Already distributed 0.17 executables acting on plugin-owned schema-4 repositories are outside this migration's supported and required acceptance scope. Their refusal, reporting and mutation behavior does not block WO-PLG-020. No claim is made that those executables preserve the migrated installation or that the new candidate repairs them.

The explicit versioned lock remains required. The migration-capable candidate MUST reject unsupported lock inputs before mutation, preserve ownership during supported operations and refuse qualification/dashboard outputs that overlap protected installation or discovery paths. The two candidate report-output repairs and their regression coverage remain required. All other candidate ownership, integrity, recovery and path-preservation obligations remain unchanged.

This decision does not change the evaluator currently governing the implementation checkout, ordinary predecessor-to-candidate upgrade rehearsal, the released-verifier package lane, or release/adoption authority. Historical 0.17 failures remain failures in retained evidence; they are excluded observations, not successful acceptance results."""),
    "architecture/ARCH-PLG-003.md": ("technical-owner", """This appendix supersedes the Compatibility section and preceding legacy-reader appendix only where they require already distributed 0.17 to refuse operations on plugin-owned schema 4. The supported migration architecture depends on the migration-capable evaluator. A versioned lock describes and validates that evaluator's ownership boundary; it does not harden an executable already distributed without those checks.

Released 0.17 behavior on migrated targets is outside this work order's acceptance scope, as selected by the operator. Preserve the old observations without a supported-compatibility claim. Schema-3 defaults, schema-4 ownership, candidate refusal/preservation rules, transactions, recovery and all other architectural decisions remain unchanged. The root-pinned development governor and ordinary predecessor upgrade rehearsal retain their separate roles."""),
    "architecture/adr/ADR-PLG-003.md": ("technical-owner", """The operator's decision supersedes this ADR's earlier requirement to establish old-0.17 refusal across migrated-target interfaces, including the preceding legacy-reader reconciliation. Retain the selected schema-4 representation and the candidate's supported ownership/preservation behavior; exclude already distributed 0.17 behavior on schema-4 targets from migration qualification.

The recorded two protected-output counterexamples remain factual failures of 0.17. They no longer block this work order under the revised scope and are not reclassified as passes. This is a support and acceptance decision, not a repair to 0.17, a lifecycle completion, release/adoption or native-host qualification."""),
    "verification/VER-PLG-020.md": ("assurance-owner", """This appendix supersedes the released-0.17 part of OWN07 and the preceding requirement to run the expanded 0.17 interface census in every source/package/platform selection. The nine cases that invoke actual 0.17 against migrated schema-4 fixtures are removed from required acceptance. Their original test definitions, command outputs, snapshots and failures remain available in the retained historical archives. Excluded observations are neither passing tests nor expected failures or skipped required coverage.

The active OWN07 observations exercise the migration-capable candidate: unsupported old/future lock schemas refuse before mutation; qualification output cannot recreate a retired skill on either a supported lock or an inspection-failure path; dashboard output cannot replace installed workflow or retained discovery paths. Keep the candidate report-output unit regressions, ordinary destination success cases and applicable real linked-path/promotion-boundary cases.

Run the revised candidate selection in the existing Python 3.11 smoke and Python 3.13 full source/package observations on Ubuntu and Windows. All remaining OWN01-OWN14 criteria, canonical source regression, package checks, root-pinned released-evaluator governance and ordinary predecessor upgrade rehearsal remain required. This scope change removes the old-0.17 acceptance blocker only; implementation completion, VREC preparation, verification and release still require their own actual results and gates."""),
    "work-orders/WO-PLG-020.md": ("engineering-owner", """The operator explicitly excluded old 0.17 from migration acceptance after reviewing its two report-output failures. Apply the corresponding SPEC-PLG-020, ARCH-PLG-003, ADR-PLG-003 and VER-PLG-020 scope amendments above the preserved historical definitions. Remove the nine old-reader migration cases from active acceptance while retaining the two candidate report-output cases and unsupported-lock refusal coverage.

Removing the inherited eight-case census also resolves the published test-discovery mismatch without changing or weakening suite hygiene. Existing execution scope already includes the governing documents, ownership test module, fixtures, notes and evidence. No additional path or lifecycle change is required. Publish this continuation through PR #462 under the operator's existing publication authorization. WO-PLG-020 remains in progress until the revised candidate acceptance and completion gates pass; VREC-PLG-015 remains unprepared."""),
}
effects = []
for relative, (role, paragraph) in changes.items():
    path = ROOT / "docs/engineering/plugin-integration" / relative
    before = path.read_bytes()
    appendix = ("\n\n## Approved exclusion of released-0.17 migration acceptance — 2026-09-12\n\n"
        f'The operator instructed "{instruction}" after review of the old-tool acceptance issue. '
        f'This instruction authorizes the following scope decision as `{role}`. '
        f'The receipt was recorded at `{recorded}` under WO-PLG-020. Earlier approvals and observations are preserved.\n\n'
        + paragraph + "\n").encode("utf-8")
    path.write_bytes(before + appendix)
    effects.append({"path": path.relative_to(ROOT).as_posix(), "role": role, "before_sha256": sha(before),
        "after_sha256": sha(path.read_bytes()), "appendix_sha256": sha(appendix), "historical_prefix_preserved": True})
receipt = {"schema": "wo-plg-020-retired-reader-scope-v1", "recorded_at_utc": recorded,
    "user_instruction": instruction, "parent_commit": head, "effects": effects,
    "scope": "Already distributed 0.17 behavior against migrated schema-4 targets is not required candidate acceptance.",
    "removed_required_cases": 9, "candidate_protections_required": True,
    "historical_failures_reclassified_as_passes": False, "lifecycle": "in_progress", "vrec_prepared": False,
    "unchanged": ["root-pinned 0.17 governor", "ordinary predecessor upgrade rehearsal", "released-verifier package lane",
        "candidate ownership/integrity/recovery and protected output", "verification/release/adoption decisions", "C10/C11 limitation"]}
(EVIDENCE / "governance/retired-reader-scope-approval.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8", newline="\n")
(OUT / "scope-approval.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"amended_documents": len(effects), "instruction": instruction, "lifecycle": "in_progress"}))
