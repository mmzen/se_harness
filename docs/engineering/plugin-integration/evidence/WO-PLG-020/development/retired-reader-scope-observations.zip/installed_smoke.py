"""Run the revised candidate selection with the unchanged installed development wheel."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
import unittest
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent / "wo20"
WHEEL = OUT.parent / "report-output-repair/dist-final/se_harness-0.18.0-py3-none-any.whl"
os.environ["SE_HARNESS_OWNERSHIP_PACKAGE"] = "1"
os.environ["SE_HARNESS_OWNERSHIP_WHEEL"] = str(WHEEL)
os.environ["SE_HARNESS_OWNERSHIP_EVIDENCE"] = str(OUT / "installed-cases")
os.environ["SE_HARNESS_OWNERSHIP_COMMIT"] = "113bec75-plus-acceptance-scope-change"
os.environ.pop("SE_HARNESS_OWNERSHIP_LEGACY_PYTHON", None)
import se_harness
from se_harness.evaluator_identity import installed_evaluator_identity
assert sys.flags.isolated
assert Path(se_harness.__file__).resolve().is_relative_to(Path(sys.prefix).resolve())
wheel_sha = hashlib.sha256(WHEEL.read_bytes()).hexdigest()
assert installed_evaluator_identity().archive_sha256 == wheel_sha
with zipfile.ZipFile(WHEEL) as wheel:
    for name in wheel.namelist():
        if name.startswith("se_harness/") and name.endswith(".py"):
            assert wheel.read(name).replace(b"\r\n", b"\n") == (ROOT / name).read_bytes().replace(b"\r\n", b"\n"), name
path = ROOT / "tests/test_skill_ownership.py"
spec = importlib.util.spec_from_file_location("installed_ownership_scope", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
smoke = module.acceptance_suite(smoke=True)
assert smoke.countTestCases() == 8
assert module.acceptance_suite().countTestCases() == 53
assert not any("released_017" in item.id() for item in smoke)
start = time.monotonic()
with (OUT / "installed-smoke.log").open("w", encoding="utf-8", newline="\n") as stream:
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(smoke)
record = {"tests": result.testsRun, "failures": [(case.id(), text) for case, text in result.failures],
    "errors": [(case.id(), text) for case, text in result.errors], "skipped": result.skipped,
    "seconds": time.monotonic() - start, "python": sys.executable, "module": se_harness.__file__,
    "wheel_sha256": wheel_sha, "test_source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    "classification": "Revised installed smoke against unchanged development wheel; not new committed-candidate qualification.",
    "product_python_matches_wheel_modulo_line_endings": True, "authority_mocks": False}
(OUT / "installed-smoke.json").write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(record), flush=True)
raise SystemExit(not result.wasSuccessful())
