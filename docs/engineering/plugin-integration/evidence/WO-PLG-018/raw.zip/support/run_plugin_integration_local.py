from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
root=Path(__file__).resolve().parent
repo=root/'se-harness-plugin-integration-proposal'
label=sys.argv[1]
control=root/'plugin-probe-control'/repo.name/'local'/label
control.mkdir(parents=True,exist_ok=False)
argv=sys.argv[2:]
env=os.environ.copy()
env.pop('PYTHONPATH',None)
env.pop('PYTHONHOME',None)
env['PYTHONDONTWRITEBYTECODE']='1'
env.update(GIT_CONFIG_COUNT='3',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=repo.as_posix(),
           GIT_CONFIG_KEY_1='core.longpaths',GIT_CONFIG_VALUE_1='true',
           GIT_CONFIG_KEY_2='core.autocrlf',GIT_CONFIG_VALUE_2='false')
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
start=time.monotonic()
result=subprocess.run(argv,cwd=repo,env=env,capture_output=True,timeout=1200)
(control/'stdout').write_bytes(result.stdout)
(control/'stderr').write_bytes(result.stderr)
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],env=env).decode().strip()
data={'argv':argv,'cwd':str(repo),'head':head,'started_at':started,
      'duration_seconds':round(time.monotonic()-start,3),'exit_status':result.returncode,
      'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),
      'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()}
(control/'command.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(data))
print(result.stdout.decode('utf8',errors='replace')[-1800:])
print(result.stderr.decode('utf8',errors='replace')[-1800:])
raise SystemExit(result.returncode)
