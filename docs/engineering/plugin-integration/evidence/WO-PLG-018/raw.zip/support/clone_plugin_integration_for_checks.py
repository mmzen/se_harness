from pathlib import Path
import datetime, json, os, subprocess
root=Path(__file__).resolve().parent
source=root/'se_harness'
target=root/'plugin-integration-fresh-checkout-4'
control=root/'plugin-probe-control/se-harness-plugin-integration-proposal'
assert not target.exists()
env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
env.update(GIT_CONFIG_COUNT='4',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=source.as_posix(),
           GIT_CONFIG_KEY_1='core.longpaths',GIT_CONFIG_VALUE_1='true',
           GIT_CONFIG_KEY_2='core.autocrlf',GIT_CONFIG_VALUE_2='false',
           GIT_CONFIG_KEY_3='safe.directory',GIT_CONFIG_VALUE_3=source.as_posix()+'/.git')
bundle=root/'plugin-integration-reachable.bundle'
assert not bundle.exists()
active=root/'se-harness-plugin-integration-proposal'
bundle_argv=['git','-c','safe.directory='+active.as_posix(),'-c','core.longpaths=true',
             '-C',str(active),'bundle','create',str(bundle),'refs/heads/work/plugin-stack-integration']
bundle_result=subprocess.run(bundle_argv,env=env,capture_output=True)
(control/'fresh-bundle.stderr').write_bytes(bundle_result.stderr)
assert bundle_result.returncode==0,bundle_result.stderr.decode('utf8',errors='replace')[-1000:]
argv=['git','clone','--no-checkout','--single-branch','--branch',
      'work/plugin-stack-integration',str(bundle),str(target)]
result=subprocess.run(argv,env=env,capture_output=True)
(control/'fresh-clone-4.stdout').write_bytes(result.stdout)
(control/'fresh-clone-4.stderr').write_bytes(result.stderr)
assert result.returncode==0,result.stderr.decode('utf8',errors='replace')[-1000:]
git=['git','-c','safe.directory='+target.as_posix(),'-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(target)]
head=subprocess.check_output(git+['rev-parse','HEAD']).decode().strip()
expected='dbc52b56a3820c8765aec2aa5de250c3e1d7a379'
missing=subprocess.run(git+['cat-file','-e',expected],capture_output=True)
assert missing.returncode!=0,'Expected preview object unexpectedly transferred'
plan='docs/engineering/plugin-integration/evidence/WO-PLG-018/plan-main.json'
subprocess.run(git+['restore','--source',head,'--worktree','--',plan],check=True)
data={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'argv':argv,'head':head,'exit_status':result.returncode,
      'no_local_object_copy':True,'only_selected_branch_history_transferred':True,
      'transport':'Reachable-only bundle, avoiding local upload-pack ownership ambiguity',
      'bundle_argv':bundle_argv,
      'preview_tree_absent':expected,'plan_materialized':plan,
      'purpose':'Exercise the verifier against reachable history without accidental preview objects; no implementation checkout or lifecycle action.'}
(control/'fresh-clone.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps(data))
