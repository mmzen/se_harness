"""Extract tested checkout identities from retained, completed hosted job logs."""
from pathlib import Path
import hashlib, json, re, sys

control = Path(__file__).resolve().parent / 'plugin-probe-control/se-harness-plugin-integration-proposal'
label, output = sys.argv[1:3]
folder = control / 'ci' / label
observation = json.loads((folder / 'result.json').read_bytes())
assert observation['all_reported_checks_successful'] is True
head = observation['pull_request']['headRefOid']
base = observation['pull_request']['baseRefOid']
assert base == 'fc1f087371b100d5fda7a1f254ee00ebde8cbadf'
jobs = []
for path in sorted(folder.glob('j*.json')):
    job = json.loads(path.read_bytes())
    log_path = path.with_suffix('.log')
    raw = log_path.read_bytes()
    lines = raw.decode('utf8').splitlines()
    checkout = None
    for index, line in enumerate(lines):
        if 'log -1 --format=%H' in line:
            match = re.search(r'\b([a-f0-9]{40})\s*$', lines[index + 1])
            assert match, (job['name'], lines[index + 1])
            checkout = match[1]
            break
    assert checkout, job['name']
    assert job['head_sha'] == head and job['conclusion'] == 'success'
    if job['name'] == 'validate':
        actual_bases = set(re.findall(r'HARNESS_BASE_SHA:\s*([a-f0-9]{40})', raw.decode('utf8')))
        assert actual_bases == {base}, actual_bases
    jobs.append({'name': job['name'], 'job_id': job['id'], 'run_id': job['run_id'],
                 'api_head_sha': head, 'tested_checkout': checkout,
                 'url': job['html_url'], 'log': log_path.relative_to(control).as_posix(),
                 'log_sha256': hashlib.sha256(raw).hexdigest()})
assert len(jobs) == 9, len(jobs)
checkouts = {job['tested_checkout'] for job in jobs}
assert len(checkouts) == 1, checkouts
result = {'schema': 'plugin-integration-hosted-identity-v1',
          'pr_head': head, 'actual_pr_base': base, 'tested_merge_checkout': next(iter(checkouts)),
          'checks': observation['checks'], 'jobs': jobs,
          'meaning': 'The Actions API head identifies the PR head. Checkout logs identify the synthetic merge tested by the hosted jobs. The validate log independently names its scope base.'}
target = control / output
assert not target.exists(), target
target.write_text(json.dumps(result, indent=2) + '\n', encoding='utf8', newline='\n')
print(json.dumps({key: result[key] for key in ('pr_head', 'actual_pr_base', 'tested_merge_checkout')}))
