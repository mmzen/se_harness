from pathlib import Path
import hashlib, json, subprocess, tomllib
root=Path(__file__).resolve().parent
repo=root/'se-harness-plugin-integration-proposal'
control=root/'plugin-probe-control'/repo.name
prefix='docs/engineering/plugin-integration/'
git=['git','-c','safe.directory='+repo.as_posix(),'-c','core.longpaths=true','-c','core.autocrlf=false','-C',str(repo)]
def g(*args):return subprocess.check_output(git+list(args))
def sha(raw):return hashlib.sha256(raw).hexdigest()
head=g('rev-parse','HEAD').decode().strip()
plan=json.loads((repo/(prefix+'evidence/WO-PLG-018/plan-main.json')).read_bytes())
records=[]
for expected in plan['verified_records_and_preserved_history']:
    path=prefix+'verification-records/'+expected['id']+'.md'
    raw=g('cat-file','blob',head+':'+path)
    assert sha(raw)==expected['record_sha256']
    m=tomllib.loads(raw.decode('utf8').split('+++')[1])
    assert m['status']==expected['status'] and m['commit']==expected['candidate']
    assert len(m['evidence_paths'])==expected['selected_evidence_files']
    assert m['relations']['verifies_work_order']==expected['verifies_work_order']
    subprocess.run(git+['merge-base','--is-ancestor',m['commit'],head],check=True)
    evidence=[]
    for p in m['evidence_paths']:
        old=g('cat-file','blob',m['commit']+':'+p)
        imported=g('cat-file','blob',head+':'+p)
        evidence.append({'path':p,'candidate_bytes':len(old),'candidate_sha256':sha(old),
                         'imported_sha256':sha(imported),'same_as_bound_candidate':old==imported})
    sidecar=g('cat-file','blob',head+':'+m['evaluator_evidence_path'])
    assert sha(sidecar)==m['evaluator_evidence_sha256']==expected['evaluator_sha256']
    records.append({'id':m['id'],'status':m['status'],'candidate':m['commit'],
                    'record_sha256':sha(raw),'sidecar_sha256':sha(sidecar),
                    'lifecycle_events':m.get('lifecycle_events',[]),'selected_evidence':evidence,
                    'historical_post_candidate_differences':[e for e in evidence if not e['same_as_bound_candidate']]})
wos=[]
for number in ('010','011','012','017'):
    path=prefix+'work-orders/WO-PLG-'+number+'.md'
    raw=g('cat-file','blob',head+':'+path)
    m=tomllib.loads(raw.decode('utf8').split('+++')[1])
    assert m['status']=='implemented'
    wos.append({'id':m['id'],'status':m['status'],'sha256':sha(raw)})
result={'method':'Independent parent readback using immutable Git blobs, separate from the new checker.',
        'head':head,'plan_sha256':sha((repo/(prefix+'evidence/WO-PLG-018/plan-main.json')).read_bytes()),
        'records':records,'work_orders':wos,'selected_evidence_total':sum(len(r['selected_evidence']) for r in records),
        'interpretation':'Old VRECs retain their exact source bytes and bound candidates. Later already-pinned evidence receipt changes are disclosed, never rebound.'}
(control/'history-inspection.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'head':head,'work_orders':wos,'records':[{'id':r['id'],'status':r['status'],
    'read_at_candidate':len(r['selected_evidence']),
    'later_receipt_differences':len(r['historical_post_candidate_differences'])} for r in records]}))
