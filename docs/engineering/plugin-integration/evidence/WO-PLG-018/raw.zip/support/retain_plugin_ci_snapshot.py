"""Retain an exact PR-head CI observation and selected complete job logs."""
from pathlib import Path
import datetime, hashlib, json, re, subprocess, sys

work = Path(__file__).resolve().parent
repo_name, pr, label = sys.argv[1:4]
control = work / 'plugin-probe-control' / repo_name / 'ci' / label
control.mkdir(parents=True, exist_ok=False)
commands = []
def run(arguments, filename):
    result = subprocess.run(['gh', *arguments], cwd=work, capture_output=True)
    (control / filename).write_bytes(result.stdout)
    (control / (filename + '.stderr')).write_bytes(result.stderr)
    commands.append({'argv':['gh',*arguments], 'exit_status':result.returncode,
                     'stdout':filename,'sha256':hashlib.sha256(result.stdout).hexdigest()})
    # gh pr checks returns 1 for failing checks and 8 for pending checks; both
    # still return the requested structured observation, rather than an API error.
    if result.returncode and not (arguments[:2] == ['pr', 'checks'] and result.returncode in (1, 8)):
        (control / 'commands.json').write_text(json.dumps(commands,indent=2)+'\n',newline='\n')
        raise SystemExit(result.returncode)
    return result.stdout

pull = json.loads(run(['pr','view',pr,'-R','mmzen/se_harness','--json','headRefOid,headRefName,baseRefOid,baseRefName,state,url'],'pull.json'))
checks = json.loads(run(['pr','checks',pr,'-R','mmzen/se_harness','--json','name,state,link'],'checks.json'))
all_pass = bool(checks) and all(row['state']=='SUCCESS' for row in checks)
assert all_pass or '--retain-failure' in sys.argv[4:], 'A required run is unfinished or unsuccessful'
required = {'validate', 'Candidate source evidence', 'Candidate package evidence',
            'Upgrade rehearsal (Windows)', 'Upgrade rehearsal (Linux)',
            'Build deterministic integration package', 'Verify integration package (Windows)',
            'Verify integration package (Linux)', 'Retain verified integration package'}
assert required <= {row['name'] for row in checks}, 'Required jobs missing from observation'
runs = {}
for row in checks:
    match = re.search(r'/actions/runs/(\d+)/job/', row['link'])
    if not match or match[1] in runs:
        continue
    run_id = match[1]
    run_data = json.loads(run(['api', f'repos/mmzen/se_harness/actions/runs/{run_id}'], f'run-{run_id}.json'))
    assert run_data['head_sha'] == pull['headRefOid']
    assert run_data['status'] == 'completed', 'Workflow still running; logs are not final'
    runs[run_id] = {'head_sha': run_data['head_sha'], 'status': run_data['status'], 'conclusion': run_data['conclusion']}
selected = ('Candidate package evidence','Candidate source evidence','Upgrade rehearsal (Windows)','Upgrade rehearsal (Linux)',
            'Verify integration package (Windows)','Verify integration package (Linux)',
            'Build deterministic integration package','Retain verified integration package','validate')
for index, row in enumerate(checks):
    if row['name'] not in selected or row['state'] not in ('SUCCESS','FAILURE'):
        continue
    parts = row['link'].split('/')
    run_id,job_id = parts[-3],parts[-1]
    job = json.loads(run(['api',f'repos/mmzen/se_harness/actions/jobs/{job_id}'],f'j{index:02d}.json'))
    assert job['head_sha'] == pull['headRefOid']
    run(['run','view',run_id,'-R','mmzen/se_harness','--job',job_id,'--log'],f'j{index:02d}.log')
(control / 'commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf8',newline='\n')
(control / 'result.json').write_text(json.dumps({'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'pull_request':pull,'checks':checks,'runs':runs,'all_reported_checks_successful':all_pass,
    'scope':'Observed CI outcomes at this exact head; no assurance decision or merge'},indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'head':pull['headRefOid'],'checks':len(checks),'retained':str(control)}))
