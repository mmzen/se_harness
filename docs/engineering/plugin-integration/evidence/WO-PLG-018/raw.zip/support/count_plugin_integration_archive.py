"""Count actual Git tar entries without extracting or changing the repository."""
from pathlib import Path
import io, json, subprocess, sys, tarfile

repo = Path.cwd().resolve()
commit = sys.argv[1]
git = ['git', '-c', 'safe.directory=' + repo.as_posix(), '-c', 'core.longpaths=true', '-C', str(repo)]
assert subprocess.check_output(git + ['rev-parse', commit]).decode().strip() == commit
raw = subprocess.check_output(git + ['archive', '--format=tar', commit])
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:') as archive:
    members = archive.getmembers()
    result = {'candidate': commit, 'tar_members': len(members),
              'files': sum(m.isfile() for m in members), 'directories': sum(m.isdir() for m in members),
              'expanded_bytes': sum(m.size for m in members), 'limit': 10000}
assert result['tar_members'] <= result['limit']
print(json.dumps(result, indent=2))
