import hashlib,json,os,pathlib,subprocess,time
OUT=pathlib.Path(__file__).resolve().parent
SRC=OUT.parent/'se-harness-plugin-retained-skills'
C='6db8bd61d91a0785d79a7bb1db3b70f815f58d39'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(n,b):
    p=OUT/n
    if p.exists():raise RuntimeError('Refusing overwrite '+n)
    p.write_bytes(b)
def js(n,v):save(n,(json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
env=dict(os.environ,GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_NOSYSTEM='1',GIT_OPTIONAL_LOCKS='0')
git=['git','-c','safe.directory='+SRC.as_posix(),'-c','core.longpaths=true','-C',str(SRC)]
def call(n,args):
    t=time.monotonic();out=err=b'';code=None;error=None
    try:
        p=subprocess.run(args,capture_output=True,env=env,timeout=180)
        out,err,code=p.stdout,p.stderr,p.returncode
    except subprocess.TimeoutExpired as e:out,err=e.stdout or b'',e.stderr or b'';error={'type':'TimeoutExpired','message':str(e)}
    except OSError as e:error={'type':type(e).__name__,'message':str(e)}
    save(n+'.stdout',out);save(n+'.stderr',err)
    js(n+'.json',dict(argv=args,returncode=code,error=error,elapsed_seconds=time.monotonic()-t,stdout_bytes=len(out),stdout_sha256=sha(out),stderr_sha256=sha(err)))
    assert code==0 and not error,n
    return out
save('committed-review-source2.py',pathlib.Path(__file__).read_bytes())
base=call('d01-parent',git+['rev-parse','731014d8^{commit}']).decode().strip()
assert call('d02-commit',git+['rev-parse',C+'^{commit}']).decode().strip()==C
diff=call('d03-committed-diff',git+['diff','--no-renames','--name-status',base,C]).decode().splitlines()
oracle=json.loads((OUT/'oracle.json').read_bytes());prefix=oracle['prefix'].rstrip('/')
before=json.loads((OUT/'source-before.json').read_bytes())
bound={}
for num,(name,expected) in enumerate(sorted(before.items()),10):
    data=call('d'+str(num)+'-blob',git+['cat-file','blob',C+':'+prefix+'/'+name])
    assert sha(data)==expected['sha256'] and len(data)==expected['bytes'],name
    bound[name]=dict(bytes=len(data),sha256=sha(data))
checkerpath='tests/plugin_integration/retained-skills/check_raw_archive.py'
checker=call('d20-checker',git+['cat-file','blob',C+':'+checkerpath])
assert checker==(OUT/'checker.py').read_bytes()
rows=[dict(status=line.split('\t')[0],path=line.split('\t')[1]) for line in diff]
package=[r for r in rows if r['path'].startswith(prefix+'/')]
assert {r['path'][len(prefix)+1:] for r in package if r['status']=='D'}==set(oracle['raw_files'])
assert {r['path'][len(prefix)+1:] for r in package if r['status']=='A'}=={'raw.zip','raw-index.json'}
assert len(package)==417
outside=[r for r in rows if r not in package]
allowed=('docs/engineering/plugin-integration/evidence/WO-PLG-012/',)
assert all(r['path']==checkerpath or r['path'].startswith(allowed) for r in outside),outside
result=dict(passed=True,candidate_commit=C,scope_base_commit=base,checker_sha256=sha(checker),bound_package_files=bound,package_changes=package,outside_package_changes=outside,scope_note='The earlier r01 working-tree diff used original evidence base 5aba and lacked Windows core.longpaths=true, yielding long-path working-tree deletion projections and inherited governance differences. This immutable committed comparison is authoritative for candidate scope. Original observations were preserved.')
js('committed-result.json',result)
print(json.dumps(dict(passed=True,candidate=C,parent=base,package_change_count=len(package),outside_package_changes=outside,checker_sha256=sha(checker))))
