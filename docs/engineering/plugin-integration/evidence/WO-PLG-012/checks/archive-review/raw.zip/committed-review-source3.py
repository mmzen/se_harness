import hashlib,json,os,pathlib,subprocess,time
OUT=pathlib.Path(__file__).resolve().parent
SRC=OUT.parent/'se-harness-plugin-retained-skills'
C='6db8bd61d91a0785d79a7bb1db3b70f815f58d39'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(n,b):
    p=OUT/n
    if p.exists():raise RuntimeError('Refusing overwrite '+n)
    p.write_bytes(b)
def js(n,v):save(n,(json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
env=dict(os.environ,GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_NOSYSTEM='1',GIT_OPTIONAL_LOCKS='0')
git=['git','-c','safe.directory='+SRC.as_posix(),'-c','core.longpaths=true','-C',str(SRC)]
def call(n,args):
    t=time.monotonic();out=err=b'';code=None;error=None
    try:
        p=subprocess.run(args,capture_output=True,env=env,timeout=180)
        out,err,code=p.stdout,p.stderr,p.returncode
    except subprocess.TimeoutExpired as e:out,err=e.stdout or b'',e.stderr or b'';error={'type':'TimeoutExpired','message':str(e)}
    except OSError as e:error={'type':type(e).__name__,'message':str(e)}
    save(n+'.stdout',out);save(n+'.stderr',err)
    js(n+'.json',dict(argv=args,returncode=code,error=error,elapsed_seconds=time.monotonic()-t,stdout_bytes=len(out),stdout_sha256=sha(out),stderr_sha256=sha(err)))
    assert code==0 and not error,n
    return out
save('committed-review-source3.py',pathlib.Path(__file__).read_bytes())
base=call('e01-parent',git+['rev-parse','731014d8^{commit}']).decode().strip()
assert call('e02-commit',git+['rev-parse',C+'^{commit}']).decode().strip()==C
whole_diff=call('e03-committed-diff',git+['diff','--no-renames','--name-status',base,C]).decode().splitlines()
repack='290f4425cc644a863ec9d4652fee82b49a113292'
diff=call('e04-repack-diff',git+['diff','--no-renames','--name-status','5aba54143d43d1b64be4b6cb2529c30570cabc26',repack]).decode().splitlines()
call('e05-ancestry',git+['merge-base','--is-ancestor',repack,C])
call('e06-original-ancestry',git+['merge-base','--is-ancestor','5aba54143d43d1b64be4b6cb2529c30570cabc26',repack])
productdiff=call('e07-product-diff',git+['diff','--name-only','5aba54143d43d1b64be4b6cb2529c30570cabc26',C,'--','plugins/verity-plane/common/skills/harness-operator-brief','plugins/verity-plane/common/skills/harness-orient','.github'])
assert not productdiff
oracle=json.loads((OUT/'oracle.json').read_bytes());prefix=oracle['prefix'].rstrip('/')
before=json.loads((OUT/'source-before.json').read_bytes())
bound={}
for num,(name,expected) in enumerate(sorted(before.items()),10):
    data=call('e'+str(num)+'-blob',git+['cat-file','blob',C+':'+prefix+'/'+name])
    assert sha(data)==expected['sha256'] and len(data)==expected['bytes'],name
    bound[name]=dict(bytes=len(data),sha256=sha(data))
checkerpath='tests/plugin_integration/retained-skills/check_raw_archive.py'
checker=call('e20-checker',git+['cat-file','blob',C+':'+checkerpath])
assert checker==(OUT/'checker.py').read_bytes()
rows=[dict(status=line.split('\t')[0],path=line.split('\t')[1]) for line in diff]
package=[r for r in rows if r['path'].startswith(prefix+'/')]
assert {r['path'][len(prefix)+1:] for r in package if r['status']=='D'}==set(oracle['raw_files'])
assert {r['path'][len(prefix)+1:] for r in package if r['status']=='A'}=={'raw.zip','raw-index.json'}
assert len(package)==417
outside=[r for r in rows if r not in package]
allowed=('docs/engineering/plugin-integration/evidence/WO-PLG-012/',)
assert all(r['path']==checkerpath or r['path'].startswith(allowed) for r in outside),outside
whole_rows=[dict(status=line.split('\t')[0],path=line.split('\t')[1]) for line in whole_diff]
whole_allowed=('docs/engineering/plugin-integration/evidence/WO-PLG-012/','tests/plugin_integration/retained-skills/','plugins/verity-plane/common/skills/harness-operator-brief/','plugins/verity-plane/common/skills/harness-orient/')
assert all(r['path']=='docs/engineering/plugin-integration/work-orders/WO-PLG-012.md' or r['path'].startswith(whole_allowed) for r in whole_rows)
result=dict(passed=True,candidate_commit=C,scope_base_commit=base,repack_commit=repack,repack_base_commit=oracle['base_commit'],checker_sha256=sha(checker),bound_package_files=bound,package_changes=package,outside_package_changes=outside,whole_scope_changes=whole_rows,product_and_ci_changed_since_original=False,scope_note='The earlier r01 working-tree diff used original evidence base 5aba and lacked Windows core.longpaths=true, yielding long-path working-tree deletion projections and inherited governance differences. The initial committed review also joined a trailing slash twice, then incorrectly expected original package removals in a full WO012 diff against 731014d8. Those script setup failures are retained. This review separately records the whole WO012 committed comparison requested by root and narrow repack comparison; product and CI files are unchanged from original 5aba.')
js('committed-result.json',result)
print(json.dumps(dict(passed=True,candidate=C,parent=base,package_change_count=len(package),outside_package_changes=outside,checker_sha256=sha(checker))))
