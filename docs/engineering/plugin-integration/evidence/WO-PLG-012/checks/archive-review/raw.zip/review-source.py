import hashlib,io,json,os,pathlib,stat,subprocess,sys,time,traceback,zipfile

OUT=pathlib.Path(__file__).resolve().parent;SRC=OUT.parent/'se-harness-plugin-retained-skills'
oracle=json.loads((OUT/'oracle.json').read_bytes());PREFIX=oracle['prefix'];folder=SRC/PREFIX
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(name,b):
    p=OUT/name
    if p.exists():raise RuntimeError('Refusing overwrite: '+name)
    p.write_bytes(b)
def js(name,x):save(name,(json.dumps(x,indent=2,sort_keys=True)+'\n').encode())
env=dict(os.environ,GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_NOSYSTEM='1',GIT_OPTIONAL_LOCKS='0')
def call(name,args,expected=0):
    start=time.time();stdout=stderr=b'';code=None;error=None
    try:p=subprocess.run([str(x) for x in args],capture_output=True,env=env,timeout=180);stdout,stderr,code=p.stdout,p.stderr,p.returncode
    except subprocess.TimeoutExpired as e:stdout,stderr=e.stdout or b'',e.stderr or b'';error=dict(type='TimeoutExpired',message=str(e))
    except OSError as e:error=dict(type=type(e).__name__,message=str(e))
    save(name+'.stdout',stdout);save(name+'.stderr',stderr);js(name+'.json',dict(argv=[str(x) for x in args],returncode=code,error=error,expected=expected,elapsed_seconds=time.time()-start,stdout_sha256=sha(stdout),stderr_sha256=sha(stderr)))
    assert code==expected and not error,name
    return stdout
git=['git','-c','safe.directory='+SRC.as_posix(),'-C',str(SRC)]
save('review-source.py',pathlib.Path(__file__).read_bytes())
result=dict(passed=False,base_commit=oracle['base_commit'],candidate='Observed working tree/index; no candidate commit inferred',oracle_sha256=sha((OUT/'oracle.json').read_bytes()))
try:
    expected_names=set(oracle['retained_files'])|{'raw.zip','raw-index.json'}
    assert {p.name for p in folder.iterdir()}==expected_names
    source_before={p.name:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in folder.iterdir()}
    js('source-before.json',source_before)
    originals=(OUT/'original-blobs.bin').read_bytes()
    for name in oracle['retained_files']:
        info=oracle['original_files'][name];data=(folder/name).read_bytes()
        assert data==originals[info['blob_offset']:info['blob_offset']+info['bytes']]
    archive=(folder/'raw.zip').read_bytes();index_bytes=(folder/'raw-index.json').read_bytes();index=json.loads(index_bytes)
    assert not (folder/'raw.zip').is_symlink()
    save('candidate-index.json',index_bytes)
    assert index['archive']=='raw.zip' and index['archive_sha256']==sha(archive) and index['archive_bytes']==len(archive)
    assert index['source_commit']==oracle['base_commit'] and index['original_inventory_sha256']==oracle['original_inventory_sha256']
    assert set(index['retained_loose_files'])==set(oracle['retained_files'])
    rows=index['entries'];assert len(rows)==len({r['path'] for r in rows})==415
    assert {r['path'] for r in rows}==set(oracle['raw_files'])
    for row in rows:
        original=oracle['original_files'][row['path']];assert row['bytes']==original['bytes'] and row['sha256']==original['sha256']
    observed=[]
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        infos=z.infolist();assert len(infos)==415 and len({i.filename for i in infos})==415
        assert {i.filename for i in infos}==set(oracle['raw_files'])
        assert len({i.filename.casefold() for i in infos})==415
        for info in infos:
            name=info.filename;p=pathlib.PurePosixPath(name)
            assert str(p)==name and not p.is_absolute() and len(p.parts)==1 and '..' not in p.parts
            assert '\\' not in name and ':' not in name and '\0' not in name and not info.is_dir() and not (info.flag_bits&1)
            kind=stat.S_IFMT(info.external_attr>>16);assert kind in (0,stat.S_IFREG)
            assert info.compress_type in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED)
            original=oracle['original_files'][name];assert info.file_size==original['bytes']
            data=z.read(info);assert data==originals[original['blob_offset']:original['blob_offset']+original['bytes']]
            assert sha(data)==original['sha256']
            observed.append(dict(path=name,bytes=len(data),sha256=sha(data),compressed_bytes=info.compress_size,crc32=info.CRC,mode=info.external_attr>>16))
        assert z.testzip() is None
    js('zip-reconciliation.json',dict(passed=True,entries=observed,raw_bytes=sum(x['bytes'] for x in observed),archive_bytes=len(archive),archive_sha256=sha(archive)))
    diff_raw=call('r01-whole-diff',git+['diff','--no-renames','--name-status',oracle['base_commit']])
    untracked_raw=call('r02-untracked',git+['ls-files','--others','--exclude-standard'])
    index_raw=call('r03-index',git+['ls-files','--stage','-z'])
    statuses={}
    for line in diff_raw.decode().splitlines():status,path=line.split('\t',1);statuses[path]=status
    for path in untracked_raw.decode().splitlines():statuses.setdefault(path,'untracked')
    package_diff={p:s for p,s in statuses.items() if p.startswith(PREFIX)}
    expected_removed={PREFIX+n for n in oracle['raw_files']}
    assert {p for p,s in package_diff.items() if s=='D'}==expected_removed
    assert set(package_diff)==expected_removed|{PREFIX+'raw.zip',PREFIX+'raw-index.json'}
    assert all(package_diff[PREFIX+n] in ('A','untracked') for n in ['raw.zip','raw-index.json'])
    outside={p:s for p,s in statuses.items() if not p.startswith(PREFIX)}
    js('scope-diff.json',dict(package_deletions=415,package_additions=2,retained_four_changed=False,whole_observed_diff=statuses,outside_package_diff=outside))
    fixture=OUT/'fixture';fixture_folder=fixture/PREFIX;fixture_folder.mkdir(parents=True)
    for name in expected_names:(fixture_folder/name).write_bytes((folder/name).read_bytes())
    checker=SRC/'tests/plugin_integration/retained-skills/check_raw_archive.py';checker_bytes=checker.read_bytes();save('checker.py',checker_bytes)
    command=[sys.executable,'-I','-B',OUT/'checker.py','--root',fixture]
    assert json.loads(call('r04-positive',command))['raw_entries']==415
    fixture_before={name:sha((fixture_folder/name).read_bytes()) for name in expected_names};js('fixture-before.json',fixture_before)
    chosen=oracle['raw_files'][0]
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        output=io.BytesIO()
        with zipfile.ZipFile(output,'w') as w:
            for info in z.infolist():
                payload=z.read(info)
                if info.filename==chosen:payload=bytes([payload[0]^1])+payload[1:];changed_payload=payload
                w.writestr(info,payload)
        corrupted_archive=output.getvalue()
    changed_index=json.loads(index_bytes);changed_index['archive_bytes']=len(corrupted_archive);changed_index['archive_sha256']=sha(corrupted_archive)
    changed_index_bytes=(json.dumps(changed_index,indent=2)+'\n').encode()
    (fixture_folder/'raw.zip').write_bytes(corrupted_archive);(fixture_folder/'raw-index.json').write_bytes(changed_index_bytes)
    js('tamper-payload.json',dict(path=chosen,byte_offset=0,changed_payload_sha256=sha(changed_payload),archive_sha256=sha(corrupted_archive),index_sha256=sha(changed_index_bytes),outer_archive_metadata_updated=True,original_entry_expectation_preserved=True))
    try:
        call('r05-payload-reject',command,expected=1);assert 'Raw payload changed' in (OUT/'r05-payload-reject.stderr').read_text()
    finally:(fixture_folder/'raw.zip').write_bytes(archive);(fixture_folder/'raw-index.json').write_bytes(index_bytes)
    assert json.loads(call('r06-restored',command))['passed']
    original_inventory=(folder/'inventory.json').read_bytes();changed_inventory=json.loads(original_inventory)
    changed_inventory['files'][chosen]['sha256']=sha(changed_payload);changed_inventory_bytes=(json.dumps(changed_inventory,indent=2)+'\n').encode()
    coordinated_index=json.loads(changed_index_bytes);coordinated_index['original_inventory_sha256']=sha(changed_inventory_bytes)
    for row in coordinated_index['entries']:
        if row['path']==chosen:row['sha256']=sha(changed_payload)
    coordinated_index_bytes=(json.dumps(coordinated_index,indent=2)+'\n').encode()
    (fixture_folder/'inventory.json').write_bytes(changed_inventory_bytes);(fixture_folder/'raw-index.json').write_bytes(coordinated_index_bytes);(fixture_folder/'raw.zip').write_bytes(corrupted_archive)
    js('tamper-coordinated.json',dict(path=chosen,inventory_sha256=sha(changed_inventory_bytes),index_sha256=sha(coordinated_index_bytes),archive_sha256=sha(corrupted_archive),mutable_inventory_index_payload_consistent=True))
    try:
        call('r07-inventory-reject',command,expected=1);assert 'Original helper inventory changed' in (OUT/'r07-inventory-reject.stderr').read_text()
    finally:
        (fixture_folder/'inventory.json').write_bytes(original_inventory);(fixture_folder/'raw-index.json').write_bytes(index_bytes);(fixture_folder/'raw.zip').write_bytes(archive)
    assert json.loads(call('r08-final-restored',command))['passed']
    fixture_after={name:sha((fixture_folder/name).read_bytes()) for name in expected_names};js('fixture-after.json',fixture_after);assert fixture_before==fixture_after
    source_after={p.name:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in folder.iterdir()};js('source-after.json',source_after);assert source_before==source_after
    result.update(passed=True,archive_sha256=sha(archive),archive_bytes=len(archive),raw_entries=415,raw_bytes=sum(x['bytes'] for x in observed),
        unchanged_retained_files=oracle['retained_files'],zip_names_types_sizes_crc_bytes_safe=True,checker_sha256=sha(checker_bytes),one_byte_rejected=True,
        coordinated_inventory_index_rejected=True,fixture_restored=True,source_helper_package_unchanged_by_review=True,outside_package_diff=outside)
except BaseException as e:result['error']=dict(type=type(e).__name__,message=str(e),traceback=traceback.format_exc());raise
finally:js('result.json',result);print(json.dumps(result,indent=2))
