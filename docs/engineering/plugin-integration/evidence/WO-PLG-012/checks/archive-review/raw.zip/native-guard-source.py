import hashlib,importlib.util,json,os,pathlib,subprocess,sys,tarfile,tempfile,time,traceback
OUT=pathlib.Path(__file__).resolve().parent
COMMON=OUT.parent/'se_harness'
C='6db8bd61d91a0785d79a7bb1db3b70f815f58d39'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(n,b):
    p=OUT/n
    if p.exists():raise RuntimeError('Refusing overwrite '+n)
    p.write_bytes(b)
def js(n,v):save(n,(json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
save('native-guard-source.py',pathlib.Path(__file__).read_bytes())
env=dict(os.environ,GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1',GIT_OPTIONAL_LOCKS='0')
git=['git','-c','safe.directory='+COMMON.as_posix(),'-C',str(COMMON)]
def call(n,args):
    t=time.monotonic();out=err=b'';code=None;error=None
    try:
        p=subprocess.run(args,capture_output=True,env=env,timeout=240)
        out,err,code=p.stdout,p.stderr,p.returncode
    except subprocess.TimeoutExpired as e:out,err=e.stdout or b'',e.stderr or b'';error={'type':'TimeoutExpired','message':str(e)}
    except OSError as e:error={'type':type(e).__name__,'message':str(e)}
    save(n+'.stdout',out);save(n+'.stderr',err)
    js(n+'.json',dict(argv=args,returncode=code,error=error,elapsed_seconds=time.monotonic()-t,stdout_bytes=len(out),stdout_sha256=sha(out),stderr_sha256=sha(err)))
    assert code==0 and not error,n
    return out
tmp=pathlib.Path(tempfile.mkdtemp(prefix='hraw-'))
result=dict(passed=False,candidate_commit=C,python=sys.version,executable=sys.executable,scratch=str(tmp),full_build_run=False,source_suite_run=False)
try:
    assert call('n01-commit',git+['rev-parse',C+'^{commit}']).decode().strip()==C
    code=tmp/'code';sources={}
    for num,name in enumerate(('.github/scripts/build_integration_package.py','repository_tools/__init__.py','repository_tools/json_bytes.py'),2):
        data=call('n'+str(num).zfill(2)+'-source',git+['cat-file','blob',C+':'+name])
        p=code/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        sources[name]=dict(bytes=len(data),sha256=sha(data))
    helper=code/'.github/scripts/build_integration_package.py'
    spec=importlib.util.spec_from_file_location('observed_build_integration_package',helper)
    mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
    assert mod.MAX_ARCHIVE_MEMBERS==10000
    archive=tmp/'candidate.tar'
    args=git+['archive','--format=tar','--output='+str(archive),C]
    call('n05-git-archive',args)
    h=hashlib.sha256()
    with archive.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    with tarfile.open(archive,mode='r:') as tar:
        members=tar.getmembers();counts=dict(total=len(members),regular_files=sum(m.isfile() for m in members),directories=sum(m.isdir() for m in members),other=sum(not(m.isfile() or m.isdir()) for m in members))
        assert tar.pax_headers.get('comment')==C
    dest=tmp/'extracted'
    start=time.monotonic();mod.extract_safe_archive(archive,dest);elapsed=time.monotonic()-start
    prefix=json.loads((OUT/'oracle.json').read_bytes())['prefix'];expected=json.loads((OUT/'source-before.json').read_bytes());bound={}
    for name,row in expected.items():
        data=(dest/prefix/name).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256'],name
        bound[name]=row
    result.update(passed=True,guard_sources=sources,archive=dict(argv=args,path=str(archive),bytes=archive.stat().st_size,sha256=h.hexdigest(),members=counts,git_pax_commit=C,retained=False,omission_reason='Bulk Git archive and extracted tree remain outside retained evidence; exact stream is reproducible with recorded Git commit and argv.'),guard=dict(call='extract_safe_archive(archive_path, destination)',max_archive_members=mod.MAX_ARCHIVE_MEMBERS,elapsed_seconds=elapsed,completed=True,destination=str(dest)),extracted_package_files=bound)
except Exception as e:
    result['error']=dict(type=type(e).__name__,message=str(e),traceback=traceback.format_exc())
    raise
finally:
    js('native-result.json',result)
    print(json.dumps(result,sort_keys=True))
