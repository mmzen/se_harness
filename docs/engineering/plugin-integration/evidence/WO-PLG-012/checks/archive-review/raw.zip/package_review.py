import hashlib,json,pathlib,zipfile
OUT=pathlib.Path(__file__).resolve().parent
PKG=OUT/'retained'
sha=lambda b:hashlib.sha256(b).hexdigest()
def encode(x):return (json.dumps(x,sort_keys=True,indent=2)+'\n').encode()
def write(n,b):
    p=PKG/n
    if p.exists():raise RuntimeError('Refusing overwrite '+str(p))
    p.write_bytes(b)
native=json.loads((OUT/'native-result.json').read_bytes())
committed=json.loads((OUT/'committed-result.json').read_bytes())
review=json.loads((OUT/'result.json').read_bytes())
assert native['passed'] and committed['passed'] and review['passed']
assert (OUT/'source-before.json').read_bytes()==(OUT/'source-after.json').read_bytes()
assert (OUT/'fixture-before.json').read_bytes()==(OUT/'fixture-after.json').read_bytes()
for name,expected in [('r04-positive',0),('r05-payload-reject',1),('r06-restored',0),('r07-inventory-reject',1),('r08-final-restored',0)]:
    row=json.loads((OUT/(name+'.json')).read_bytes());assert row['returncode']==expected
PKG.mkdir()
notes=dict(execution_note='The outer execution records below are transcribed from actual exec_command results. Inner subprocess calls retain exact raw stdout/stderr files and hashes.',invocations=[
dict(script='committed-review-source.py',exit_code=1,error='AssertionError: c10-blob',cause='Review script joined the frozen prefix trailing slash twice. Actual Git exit 128 stderr and original source retained; no candidate failure.'),
dict(script='committed-review-source2.py',exit_code=1,error='AssertionError at package deletion-set comparison',cause='Review expected original package removals in full WO012 scope diff against parent 731014d8. That parent predates WO012 additions; corrected script separates original 5aba to repack290f from whole7310 to candidate6db. No candidate failure.'),
dict(script='committed-review-source3.py',exit_code=0),
dict(script='native-guard-source.py',exit_code=0,argv=['wsl.exe','-d','Ubuntu-24.04','--','/mnt/c/Users/mathi/Documents/Codex/2026-09-04/hel/work/plugin-linux-evaluators-20260910/0.16.0/bin/python','-I','-B','/mnt/c/Users/mathi/Documents/Codex/2026-09-04/hel/work/plugin-helper-archive-review-20260911/native_guard.py'])])
(OUT/'outer-observations.json').write_bytes(encode(notes))
# Preserve exact raw files in one flat ZIP. The original payload stream includes only
# the frozen 419 helper package files, not a recursively retained repository archive.
files=sorted(p for p in OUT.iterdir() if p.is_file())
entries=[]
with zipfile.ZipFile(PKG/'raw.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:
        data=p.read_bytes();z.writestr(p.name,data);entries.append(dict(path=p.name,bytes=len(data),sha256=sha(data)))
with zipfile.ZipFile(PKG/'raw.zip') as z:
    assert len(z.infolist())==len(entries)
    for row in entries:
        data=z.read(row['path']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
report='''# Independent WO012 helper archive review

Passed bounded retention review at `6db8bd61d91a0785d79a7bb1db3b70f815f58d39`.

The oracle was frozen from Git `5aba54143d43d1b64be4b6cb2529c30570cabc26` before candidate ZIP inspection. Its SHA-256 is `ec08a100e7e352dc468f8aadf003601b0b71765ed8c0b5793da7e6827256a9fd`; the original inventory remains `332a379e7fc242ab869998495de624135718115743ebffe145d9b3cb42800119`.

All 415 ZIP payloads, totaling 4,785,760 bytes, equal their original Git blobs byte for byte. Entry names, uniqueness, file types, sizes, CRCs, and hashes pass independent reconciliation. The original REPORT.md, audit.json, inventory.json, and source-path-map.json are unchanged. All 415 former loose payloads are absent. Candidate raw.zip is 1,196,071 bytes, SHA-256 `77989599bf2db7c68636cf614e285a9794c191cee0a64c92576b4882a9314311`.

The actual committed checker passed the exact disposable package; rejected a one-byte raw payload mutation after outer archive/index metadata was updated; and rejected coordinated payload, original-inventory, and index alteration. Both refusals returned 1. Restored checks returned 0, and independent six-file snapshots prove the fixture restored and source package unchanged. Checker SHA-256: `f931406a355890a91d4f18c5c41b705fec0b1165524e4f7a335c588236e82c22`.

Native Linux Python 3.12.3 called the actual committed build_integration_package.py `extract_safe_archive` against the exact Git archive. It successfully extracted 9,816 members (8,127 regular files and 1,689 directories), under the unchanged 10,000-member limit. The 138,752,000-byte archive has SHA-256 `0b2577a1a27fcefb0858c1e0d212aa3badc1ad449129c28b54dc251bc017c178`. The actual guard source SHA-256 is `2f8228f5a1b054def1787922d24f98efe21a4a9158c6d1cf3fe5767f5147bf89`. All six extracted helper package files match the Windows-reviewed and committed bytes.

The complete committed diff against parent `731014d8fa58ba193f6eaf05af3408ed5c41e43f` is retained and stays within WO012 product, tests, evidence, and work-order paths. The narrow repack diff `5aba5414..290f4425` removes exactly 415 raw copies and adds two archive files; its other changes are the retention checker and WO012 evidence/retention records. Product skill and CI bytes are unchanged since the original 5aba commit. The repack is an ancestor of the tested merge candidate.

Original review setup failures remain visible: an initial working-tree scope read omitted Windows longpaths and showed projected deletions plus inherited governance; the first committed review formed a double slash in one Git blob path; the second used the whole WO012 parent for a narrow removal expectation. Each was corrected without source changes. Original raw records and executed source snapshots are retained alongside the corrected committed result. These are review setup defects, not candidate failures.

This review covers byte preservation, scoped checker tamper behavior, and native archive/extraction only. It does not rerun native helpers, model reasoning, full source tests, a full integration build, or CI, and makes no lifecycle or assurance decision.

The four-file bundle contains this report, audit.json, inventory.json, and raw.zip of exact flat raw records/scripts/original helper bytes. inventory.json binds every member. The whole-repository tar stream, extracted repository, and disposable fixture remain outside this bundle; the tar is reproducible from the immutable Git commit and exact recorded archive argv. No source files or Git state were changed by this review.
'''
write('REPORT.md',report.encode())
audit=dict(passed=True,candidate_commit=committed['candidate_commit'],original_commit=committed['repack_base_commit'],scope_base_commit=committed['scope_base_commit'],raw_payloads=415,raw_payload_bytes=4785760,retained_loose_files=4,package_reconciled=True,path_safety_passed=True,payload_tamper_rejected=True,coordinated_inventory_tamper_rejected=True,source_package_unchanged=True,disposable_restored=True,committed_scope_passed=True,native_guard=native,scope_record='committed-result.json',reconciliation_record='zip-reconciliation.json',raw_record_count=len(entries),raw_entries_verified=True,setup_failures_retained=True,full_build_run=False,full_source_suite_run=False,helper_behavior_rerun=False)
write('audit.json',encode(audit))
top={p.name:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in PKG.iterdir() if p.is_file()}
inventory=dict(schema='independent-helper-archive-review-v1',candidate_commit=committed['candidate_commit'],files=top,raw_entries=entries,omissions=[dict(path=native['archive']['path'],bytes=native['archive']['bytes'],sha256=native['archive']['sha256'],reason='Whole repository archive omitted; reproduce exact recorded Git archive command at immutable candidate commit.'),dict(path=native['guard']['destination'],reason='Disposable native extracted repository omitted; regenerated by recorded actual guard.'),dict(path=str(OUT/'fixture'),reason='Disposable package copy omitted; original inputs and before/after hashes retained in raw.zip.')])
write('inventory.json',encode(inventory))
print(json.dumps(dict(package=str(PKG),files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in PKG.iterdir()},raw_members=len(entries)),sort_keys=True))
