import concurrent.futures,hashlib,json,os,pathlib,subprocess,time

OUT=pathlib.Path(__file__).resolve().parent;SRC=OUT.parent/'se-harness-plugin-retained-skills'
BASE='5aba54143d43d1b64be4b6cb2529c30570cabc26';PREFIX='docs/engineering/plugin-integration/evidence/WO-PLG-012/acceptance/helpers/'
sha=lambda b:hashlib.sha256(b).hexdigest()
env=dict(os.environ,GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_NOSYSTEM='1',GIT_OPTIONAL_LOCKS='0')
def save(name,b):
    p=OUT/name
    if p.exists():raise RuntimeError('Refusing overwrite')
    p.write_bytes(b)
def js(name,x):save(name,(json.dumps(x,indent=2,sort_keys=True)+'\n').encode())
def command(args):
    argv=['git','-c','safe.directory='+SRC.as_posix(),'-C',str(SRC),*args]
    start=time.time()
    try:
        p=subprocess.run(argv,capture_output=True,env=env,timeout=60)
        return dict(argv=argv,returncode=p.returncode,elapsed_seconds=time.time()-start,stderr=p.stderr.decode('utf-8',errors='replace'),stderr_sha256=sha(p.stderr)),p.stdout
    except (OSError,subprocess.TimeoutExpired) as e:
        return dict(argv=argv,returncode=None,error=dict(type=type(e).__name__,message=str(e))),getattr(e,'stdout',None) or b''
save('freeze-source.py',pathlib.Path(__file__).read_bytes())
record,tree=command(['ls-tree','-r','-z',BASE]);save('base-tree.stdout',tree);js('base-tree.json',record);assert record['returncode']==0
entries={}
for raw in tree.split(b'\0'):
    if not raw:continue
    meta,path=raw.split(b'\t',1);mode,kind,oid=meta.decode().split();entries[path.decode()]=dict(mode=mode,type=kind,oid=oid)
paths=sorted(p for p in entries if p.startswith(PREFIX));assert len(paths)==419
def get(path):return path,command(['cat-file','blob',BASE+':'+path])
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:results=list(pool.map(get,paths))
records=[];observed={};blob_bytes=bytearray();contents={}
for path,(record,data) in results:
    record.update(path=path,stdout_offset=len(blob_bytes),stdout_bytes=len(data),stdout_sha256=sha(data));records.append(record)
    blob_bytes.extend(data);contents[path[len(PREFIX):]]=data
    observed[path[len(PREFIX):]]=dict(**entries[path],bytes=len(data),sha256=sha(data),blob_offset=record['stdout_offset'])
save('original-blobs.bin',bytes(blob_bytes));js('blob-calls.json',records);assert all(r['returncode']==0 for r in records)
inventory=contents['inventory.json'];assert sha(inventory)=='332a379e7fc242ab869998495de624135718115743ebffe145d9b3cb42800119'
parsed=json.loads(inventory);assert set(parsed['files'])==set(contents)-{'inventory.json'} and parsed['payload_files']==418
for name,info in parsed['files'].items():assert len(contents[name])==info['bytes'] and sha(contents[name])==info['sha256'],name
retained=['REPORT.md','audit.json','inventory.json','source-path-map.json'];raw=sorted(set(contents)-set(retained));assert len(raw)==415
for name in retained:save('original-'+name,contents[name])
oracle=dict(schema='wo012-helper-repack-independent-v1',base_commit=BASE,prefix=PREFIX,
    original_inventory_sha256=sha(inventory),retained_files=retained,raw_files=raw,original_files=observed,
    expected_zip='raw.zip',expected_index='raw-index.json',expected_zip_entries=415,
    whole_base_tree=entries,scope='ZIP repacking only; no native helper/model/source-suite replay',candidate_zip_read=False)
js('oracle.json',oracle);js('freeze.json',dict(oracle_sha256=sha((OUT/'oracle.json').read_bytes()),base_commit=BASE,original_files=419,raw_files=415,
    original_bytes=len(blob_bytes),original_inventory_sha256=sha(inventory),candidate_zip_read=False))
print((OUT/'freeze.json').read_text())
