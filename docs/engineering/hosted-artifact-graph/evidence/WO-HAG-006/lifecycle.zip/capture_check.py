"""Assess exact retained correction inputs and a fresh complete candidate."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

C, results_sha, transition_path, transition_sha = sys.argv[1:]
R = Path.cwd()
D = 'docs/engineering/hosted-artifact-graph/'
E = R / D / 'evidence/WO-HAG-006'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()

assert git('rev-parse', 'HEAD') == C and not git('status', '--porcelain')
assert sha(E / 'results.json') == results_sha
r = json.loads((E / 'results.json').read_text())
for path, digest in r['assessed_file_sha256'].items():
    assert sha(R / path) == digest, path
changes = git('diff', '--name-only', r['implementation_commit'], C).splitlines()
allowed = (D + 'evidence/WO-HAG-005/', D + 'evidence/WO-HAG-006/')
exact = {D + 'README.md', D + 'work-orders/WO-HAG-005.md', D + 'work-orders/WO-HAG-006.md'}
assert all(path in exact or path.startswith(allowed) for path in changes), changes
assert sha(E / 'checks.zip') == r['checks_sha256']
with zipfile.ZipFile(E / 'checks.zip') as archive:
    for name in ('focused-windows-2', 'focused-linux-2', 'source-full', 'distribution-check', 'cli-smoke', 'evaluator-facts', 'correction-validation', 'actual-plan', 'actual-assess'):
        assert json.loads(archive.read(name + '.json'))['exit'] == 0, name
    assert json.loads(archive.read('preservation-final.json'))['all_pass']
with zipfile.ZipFile(E / 'lifecycle.zip') as archive:
    for name in ('combined-handoff-final', 'completion-preview', 'completion-apply'):
        assert json.loads(archive.read(name + '.json'))['exit'] == 0, name
preserved = json.loads((E / 'preservation.json').read_text())
for entry in preserved['unchanged_hag_files']:
    assert sha(R / entry['path']) == entry['sha256'], entry['path']
for entry in preserved['verified_record_bindings']:
    assert sha(R / entry['path']) == entry['sha256'], entry['path']
assert sha(E / 'WO-HAG-001-handoff-before.txt') == preserved['packet_archive_sha256']
t = Path(transition_path)
assert sha(t) == transition_sha
tr = json.loads(t.read_text())
assert tr['passed'] and tr['assessment'] == 'passed' and tr['target']['commit'] == C
assert tr['base']['commit'] == r['base']
env = dict(os.environ, PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1')
env.pop('PYTHONPATH', None)
argv = [sys.executable, '-B', '-X', 'utf8', '-m', 'se_harness', 'qualify', 'complete-candidate', '.', '--candidate-commit', C, '--json']
p = subprocess.run(argv, env=env, capture_output=True, text=True, encoding='utf-8', timeout=900)
print(json.dumps({'candidate_commit': C, 'retained_results_sha256': results_sha, 'final_transition_sha256': transition_sha, 'final_transition': tr, 'candidate_check': {'argv': argv, 'cwd': str(R), 'exit_code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}, 'claim': 'Exact tested implementation and preserved evidence match. Fresh complete-candidate check and independent released-governor assessment are passes only when their observed exits are zero. Zero hosted service scenarios executed.'}))
assert p.returncode == 0
