import json, sys
import hag221_execute as h
h.O = h.W / 'hag-phase3-execution-20261006'
stage = sys.argv[1]
if stage == 'client':
    candidate = h.git('rev-parse', 'HEAD')
    h.run('p3-build02-client', [h.HOST, '-X', 'utf8', '-B', '-m', 'repository_tools.release_build', 'replay',
        '--repository', h.R, '--commit', candidate, '--version', '0.22.2',
        '--output-directory', h.O / 'build02', '--result', h.O / 'build02-replay.json'], cwd=h.R, timeout=1800)
elif stage == 'server':
    wheel = h.NEW.parent.parent / 'se_harness-0.22.1-py3-none-any.whl'
    # The plugin keeps the original wheel alongside the isolated environment.
    choices = list(h.NEW.parent.parent.rglob('se_harness-0.22.1-py3-none-any.whl'))
    if not choices:
        choices = list((h.W / 'hag-bounded-20261006').rglob('se_harness-0.22.1-py3-none-any.whl'))
    if not choices:
        choices = list((h.W / 'hag-final-20261006').rglob('se_harness-0.22.1-py3-none-any.whl'))
    assert choices, 'Locate exact public wheel before package preparation'
    wheel = choices[0]
    h.run('p3-build02-service', [h.HOST, '-X', 'utf8', '-B', h.R / 'server/scripts/qualify.py', 'prepare',
        '--repository', h.R, '--output', h.O / 'package02', '--client-wheel', h.O / 'build02/se_harness-0.22.2-py3-none-any.whl',
        '--client-replay', h.O / 'build02-replay.json', '--evaluator-wheel', wheel,
        '--image', 'harness-hag:phase3-02', '--phase3'], timeout=1800)
