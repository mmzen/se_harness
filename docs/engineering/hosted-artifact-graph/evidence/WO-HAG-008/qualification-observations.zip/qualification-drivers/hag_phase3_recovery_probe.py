import json,os,sys
import hag221_execute as h
h.O=h.W/'hag-phase3-execution-20261006';P=h.O/'package02'
state=json.loads((h.O/'transport04/transport.json').read_text())
credentials=json.loads((P/'credentials.json').read_text());token=next(p['token'] for p in credentials['principals'] if p['id']=='operator')
environment=dict(os.environ,HAG_TEST_TOKEN=token)
python=h.O/'client02/Scripts/python.exe';wheel=h.O/'build02/se_harness-0.22.2-py3-none-any.whl'
for label,port in [('original',18281),('restore',18282)]:
    common=['--endpoint',f'http://127.0.0.1:{port}','--project',state['request']['project_id'],'--token-env','HAG_TEST_TOKEN','--json']
    receipt=h.run('p3-recovery-'+label+'-receipt',[python,'-I','-m','se_harness','remote','operation',*common,'--key',state['request']['operation_key']],env=environment)
    assert receipt==state['result']
    result=h.run('p3-recovery-'+label+'-retry',[python,'-I','-m','se_harness','remote','rehearse',*common,'--client-wheel',wheel,'--test-copy',
        '--request',h.O/'transport04/002-lost-reply-request.json'],env=environment)
    assert result==receipt
    exported=h.run('p3-recovery-'+label+'-export',[python,'-I','-m','se_harness','remote','export',*common,'--client-wheel',wheel,'--test-copy',
        '--request',h.O/'transport04/006-after-lost-reply-request.json','--destination',h.O/('recovery-'+label+'-export')],env=environment)
    expected=h.O/'transport04/after-lost-reply'
    actual=h.O/('recovery-'+label+'-export')
    assert (actual/'history.bundle').read_bytes()==(expected/'history.bundle').read_bytes()
    for p in (expected/'files').rglob('*'):
        if p.is_file():assert p.read_bytes()==(actual/'files'/p.relative_to(expected/'files')).read_bytes()
h.write(h.O/'recovery-receipts.json',{'outcome':'passed','receipt':state['result']['receipt_id'],
    'original_and_restored_identical_receipt':True,'identical_retry_no_new_write':True,'exact_exports_match':True})
