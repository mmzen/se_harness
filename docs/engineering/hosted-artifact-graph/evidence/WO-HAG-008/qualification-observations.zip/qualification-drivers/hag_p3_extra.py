"""Extra real HTTP/MCP test-copy boundaries; no server code is replaced."""
import argparse,asyncio,copy,json,urllib.request,urllib.error
from pathlib import Path
from hosted_artifact_graph.service import Service
from hosted_artifact_graph.protocol import Refusal
from qualify_pilot_store import fingerprint

parser=argparse.ArgumentParser();parser.add_argument('--state',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();args.output.mkdir(exist_ok=False)
service=Service(json.loads(Path('/run/config/config.json').read_text()),json.loads(Path('/run/secrets/sandbox_credentials').read_text()))
principal=next(p for p in service.credentials['principals'] if p['id']=='operator');state=json.loads(args.state.read_text());events=[]
def record(name,value):
    events.append(name);(args.output/(name+'.json')).write_text(json.dumps(value,indent=2)+'\n')
def http(request,*,auth=True,route=None):
    header={'Content-Type':'application/json'}
    if auth:header['Authorization']='Bearer '+principal['token']
    target=route or '/v1/projects/'+service.project_id+'/reads/'+request['operation']
    req=urllib.request.Request('http://127.0.0.1:8080'+target,json.dumps(request).encode(),headers=header)
    try:response=urllib.request.urlopen(req,timeout=180)
    except urllib.error.HTTPError as exc:response=exc
    with response:return response.status,json.load(response)
async def run():
    import httpx
    from mcp import ClientSession
    from mcp.client.streamable_http import streamable_http_client
    baseline={'kind':'baseline','baseline_id':state['final_baseline']}
    early={'kind':'baseline','baseline_id':state['first_baseline']}
    with service.store.transaction() as tx:selected=service.store.view(tx,baseline)
    def read(operation,**fields):return {'schema':'se-harness-graph-read/v1','project_id':service.project_id,
        'operation':operation,'view':baseline,'budget':{'rows':500,'bytes':2097152,'depth':8},**fields}
    revision=selected['revisions']['REQ-P3-001']['revision_id']
    requests=[read('revision',artifact_id='REQ-P3-001',revision_id=revision),read('work-context',work_order_id='WO-P3-001'),
        read('compare',view={'kind':'comparison','left':early,'right':baseline}),read('impact',artifact_id='CAP-P3-001'),
        read('lineage',artifact_id='VREC-P3-001'),read('check',artifact_id='RLS-P3-001'),
        read('cypher',query='MATCH (r:Revision) RETURN r.artifact_id AS id LIMIT 5',parameters={})]
    before=fingerprint(service)
    async with httpx.AsyncClient(headers={'Authorization':'Bearer '+principal['token']},timeout=180) as client:
        async with streamable_http_client('http://127.0.0.1:8080/mcp',http_client=client) as (incoming,outgoing,_):
            async with ClientSession(incoming,outgoing) as session:
                await session.initialize();tools=await session.list_tools()
                assert {t.name for t in tools.tools}=={r['operation'] for r in requests}
                for request in requests:
                    status,value=await asyncio.to_thread(http,request)
                    mcp=await session.call_tool(request['operation'],request);observed=json.loads(mcp.content[0].text)
                    record('mcp-'+request['operation'],{'request':request,'status':status,'http':value,'mcp':observed})
                    assert status==200 and observed==value and value['test_copy'] is True
    request=copy.deepcopy(state['last_request']);request.update(mode='preview',preview_digest=None,
        expected_project_version=service.store.ready())
    request['action']={'kind':'publish','destination':'never-invoked'}
    status,result=http(request,route='/v2/projects/'+service.project_id+'/rehearsals')
    assert status==400;record('publication-operation-refused',result)
    status,result=http(request,auth=False,route='/v2/projects/'+service.project_id+'/rehearsals')
    assert status==401;record('missing-credential-refused',result)
    status,result=http(request,route='/v1/projects/'+service.project_id+'/commands')
    assert status==400;record('v1-cannot-dispatch-v2',result)
    assert fingerprint(service)==before
    record('result',{'outcome':'passed','cases':events,'graph_unchanged':True,
        'limits':'Sandbox key and application controls only; no authenticated-human or database ACL qualification.'})
try:asyncio.run(run())
finally:service.store.driver.close()
