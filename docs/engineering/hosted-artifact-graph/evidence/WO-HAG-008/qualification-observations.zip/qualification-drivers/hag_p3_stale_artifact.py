"""Invalidate a lifecycle preview by changing an actual selected draft artifact."""
import argparse,base64,copy,json
from pathlib import Path
from hosted_artifact_graph.service import Service
from hosted_artifact_graph.protocol import Refusal
from lifecycle_fixture import files
from qualify_pilot_store import fingerprint

parser=argparse.ArgumentParser();parser.add_argument('--state',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args();state=json.loads(args.state.read_text());events=[]
s=Service(json.loads(Path('/run/config/config.json').read_text()),json.loads(Path('/run/secrets/sandbox_credentials').read_text()))
p=next(p for p in s.credentials['principals'] if p['id']=='operator');context=state['context'];version=state['project_version']
def command(operation,key,**fields):return {'schema':'se-harness-remote-command/v1','operation':operation,'operation_key':key,
    'project_id':s.project_id,'client':s.config['client'],'expected_evaluator':s.config['components']['evaluator'],
    'expected_project_version':version,'context_id':context['context_id'],'expected_context_version':context['context_version'],**fields}
def accept(value):
    global context,version
    result=s.command(p,value);context=result['view'];version=result['versions']['project']['after']
    events.append({'request':value,'result':result});args.output.write_text(json.dumps(events,indent=2)+'\n')
    return result
try:
    created=accept(command('create-artifact','stale-artifact-create',domain='lifecycle-pilot',artifact_type='intent',artifact_id='INT-P3-060'))
    raw=next(v for k,v in files().items() if k.endswith('/INT-P3-001.md')).replace(b'INT-P3-001',b'INT-P3-060')
    complete=accept(command('revise-artifact','stale-artifact-complete',artifact_id='INT-P3-060',expected_revision_id=created['affected_revision_ids'][0],document_base64=base64.b64encode(raw).decode()))
    request=copy.deepcopy(state['request']);request.update(operation_key='stale-artifact-preview',mode='preview',preview_digest=None,
        expected_project_version=version,expected_context_version=context['context_version'])
    request['action']['id']='RISK-P3-060'
    preview=s.rehearse(p,request);events.append({'request':request,'result':preview})
    revised=accept(command('revise-artifact','stale-artifact-revise',artifact_id='INT-P3-060',expected_revision_id=complete['affected_revision_ids'][0],
        document_base64=base64.b64encode(raw+b'\nAdditional selected test content.\n').decode()))
    request.update(mode='apply',preview_digest=preview['preview_digest'],expected_project_version=version,expected_context_version=context['context_version'])
    before=fingerprint(s)
    try:s.rehearse(p,request)
    except Refusal as exc:
        assert exc.code=='HAG_REMOTE_STALE_PREVIEW'
        assert fingerprint(s)==before
        events.append({'request':request,'refusal':exc.result(),'before':before,'after':fingerprint(s),'outcome':'passed'})
    else:raise AssertionError('Changed selected artifact did not invalidate preview')
    args.output.write_text(json.dumps({'outcome':'passed','events':events,'context':context,'project_version':version,
        'recovery_cutoff_note':'This separate refusal test ran after the retained restart/restore cutoff.'},indent=2)+'\n')
finally:s.store.driver.close()
