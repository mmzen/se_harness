import json,os,sys
import hag221_execute as h
h.O=h.W/'hag-phase3-execution-20261006';P=h.O/'package02'
stage=sys.argv[1]
if stage=='mcp':
    h.run('p3-extra-copy',['docker','cp',h.W/'hag_p3_extra.py','hagphase320261006b-service-1:/tmp/qualification/extra.py'])
    h.run('p3-extra04',['docker','exec','hagphase320261006b-service-1','python','/tmp/qualification/extra.py',
        '--state','/tmp/walkthrough04/walkthrough.json','--output','/tmp/extra04'],timeout=600)
    h.run('p3-extra04-copy',['docker','cp','hagphase320261006b-service-1:/tmp/extra04',h.O/'extra04'])
elif stage=='export':
    credentials=json.loads((P/'credentials.json').read_text());token=next(p['token'] for p in credentials['principals'] if p['id']=='operator')
    h.run('p3-export-negative',[h.O/'client02/Scripts/python.exe','-I',h.W/'hag_p3_export_negative.py',
        '--state',h.O/'transport04/transport.json','--configuration',P/'configuration/config.json',
        '--output',h.O/'export-negative04','--endpoint','http://127.0.0.1:18281'],env=dict(os.environ,HAG_TEST_TOKEN=token))
elif stage=='linux-export':
    for source,target in [(h.W/'hag_p3_export_negative.py','/tmp/negative.py'),(h.O/'transport04/transport.json','/tmp/transport.json'),
                          (h.O/'build02/se_harness-0.22.2-py3-none-any.whl','/tmp/se_harness-0.22.2-py3-none-any.whl')]:
        h.run('p3-linux-copy-'+source.stem,['docker','cp',source,'hagphase320261006b-service-1:'+target])
    code='''import json,os,subprocess
from pathlib import Path
subprocess.run(['python','-m','venv','/tmp/client02'],check=True)
subprocess.run(['/tmp/client02/bin/python','-I','-m','pip','install','--no-index','--no-deps','/tmp/se_harness-0.22.2-py3-none-any.whl'],check=True)
credentials=json.loads(Path('/run/secrets/sandbox_credentials').read_text())
token=next(p['token'] for p in credentials['principals'] if p['id']=='operator')
subprocess.run(['/tmp/client02/bin/python','-I','/tmp/negative.py','--state','/tmp/transport.json','--configuration','/run/config/config.json','--endpoint','http://127.0.0.1:8080','--output','/tmp/export-negative-linux'],env=dict(os.environ,HAG_TEST_TOKEN=token),check=True)
'''
    h.run('p3-export-negative-linux',['docker','exec','hagphase320261006b-service-1','python','-c',code])
    h.run('p3-export-negative-linux-copy',['docker','cp','hagphase320261006b-service-1:/tmp/export-negative-linux',h.O/'export-negative-linux04'])
elif stage=='stale':
    h.run('p3-stale-script-copy',['docker','cp',h.W/'hag_p3_stale_artifact.py','hagphase320261006b-service-1:/tmp/qualification/stale.py'])
    h.run('p3-stale-selected-artifact',['docker','exec','hagphase320261006b-service-1','python','/tmp/qualification/stale.py',
        '--state','/tmp/transport.json','--output','/tmp/stale-artifact.json'],timeout=300)
    h.run('p3-stale-selected-artifact-copy',['docker','cp','hagphase320261006b-service-1:/tmp/stale-artifact.json',h.O/'stale-artifact04.json'])
