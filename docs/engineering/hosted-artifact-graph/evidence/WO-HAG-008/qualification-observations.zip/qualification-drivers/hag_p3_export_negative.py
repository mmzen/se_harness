"""Installed client corruption probes using a real hosted export as input."""
import argparse,base64,copy,hashlib,json,os
from pathlib import Path
from se_harness.remote import RemoteError,send,save_export

parser=argparse.ArgumentParser()
for name in ('state','configuration','output'):parser.add_argument('--'+name,type=Path,required=True)
parser.add_argument('--endpoint',required=True)
args=parser.parse_args();args.output.mkdir(exist_ok=False)
state=json.loads(args.state.read_text());config=json.loads(args.configuration.read_text())
request={'schema':'se-harness-lifecycle-export-request/v2','test_copy':True,'project_id':config['project_id'],
    'baseline_id':state['result']['baseline_id'],'client':config['client'],'expected_evaluator':config['components']['evaluator']}
status,value=send(args.endpoint,os.environ['HAG_TEST_TOKEN'],'POST','/v2/projects/'+config['project_id']+'/exports',request)
assert status==200
def digest(scheme,v):return hashlib.sha256(scheme.encode()+b'\n'+json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def rebind(v):
    snapshot=v['snapshot'];snapshot.pop('snapshot_id');snapshot['snapshot_id']='sha256:'+digest(snapshot['schema'],snapshot)
    baseline=v['baseline'];baseline['manifest']['provenance']['snapshot_id']=snapshot['snapshot_id']
    baseline['baseline_id']=baseline['schema']+':sha256:'+digest(baseline['schema'],baseline['manifest'])
observations=[]
for case in ('corrupt-evidence','unsafe-path','existing-destination','symlink-parent'):
    mutated=copy.deepcopy(value);target=args.output/case
    if case=='corrupt-evidence':
        path=next(p for p in mutated['snapshot']['files'] if p.endswith('assertion.json'))
        mutated['snapshot']['files'][path]['content_base64']=base64.b64encode(b'corrupt evidence\n').decode()
        rebind(mutated)
    elif case=='unsafe-path':
        path=next(iter(mutated['snapshot']['files']))
        mutated['snapshot']['files']['../escape']=mutated['snapshot']['files'].pop(path)
        rebind(mutated)
    elif case=='existing-destination':
        target.mkdir();(target/'owner.txt').write_bytes(b'preserve me')
    else:
        # Use when the host supports links. A denied creation is not a pass.
        parent=args.output/'real-parent';parent.mkdir();link=args.output/'linked-parent'
        try:link.symlink_to(parent,target_is_directory=True)
        except OSError as exc:
            observations.append({'case':case,'outcome':'unperformed','reason':type(exc).__name__});continue
        target=link/'child'
    try:save_export(mutated,target)
    except RemoteError as exc:
        observations.append({'case':case,'outcome':'passed','error':str(exc)})
    else:raise AssertionError('Invalid export accepted: '+case)
    if case=='existing-destination':assert (target/'owner.txt').read_bytes()==b'preserve me'
    else:assert not target.exists()
(args.output/'result.json').write_text(json.dumps({'request':request,'cases':observations,'credentials_retained':False},indent=2)+'\n')
print(json.dumps(observations))
