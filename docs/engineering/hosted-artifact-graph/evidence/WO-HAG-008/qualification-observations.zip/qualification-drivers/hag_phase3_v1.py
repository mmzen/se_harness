import copy,hashlib,ipaddress,json,os,subprocess,sys,time
import hag221_execute as h
h.O=h.W/'hag-phase3-execution-20261006';P=h.O/'package02';V=h.O/'v1compat02';project='hagphase3v120261006'
env=dict(os.environ,HAG_SERVICE_IMAGE='harness-hag:phase3-02',HAG_HTTP_PORT='18283',
    HAG_SOURCE_VOLUME='hagphase220261005_source',HAG_CONFIG_DIRECTORY=str(V/'configuration'),HAG_CREDENTIAL_FILE=str(P/'credentials.json'))
compose=['docker','compose','-p',project,'-f',P/'candidate-source/server/compose.yaml','-f',V/'network.json']
canonical=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
stage=sys.argv[1]
if stage=='setup':
    V.mkdir(exist_ok=False);(V/'configuration').mkdir()
    config=json.loads((P/'configuration/config.json').read_text());config.pop('test_copy')
    config['protocols']=[x for x in config['protocols'] if not x.endswith('/v2')]
    components=config.pop('components');components['schema_revision']=1;components['protocols']=config['protocols']
    components['deployment_sha256']=hashlib.sha256(canonical({'configuration':config,
        'compose_sha256':hashlib.sha256((P/'candidate-source/server/compose.yaml').read_bytes()).hexdigest()})).hexdigest()
    config['components']=components;h.write(V/'configuration/config.json',config)
    h.write(V/'combination.json',{'combination_id':'sha256:'+hashlib.sha256(b'se-harness-hosted-combination/v1\n'+canonical(components)).hexdigest(),
        'payload':components,'state':'Phase 2 compatibility qualification pending'})
    ids=subprocess.check_output(['docker','network','ls','-q']).decode().split()
    networks=h.run('p3-v1-networks',['docker','network','inspect',*ids])
    existing=[ipaddress.ip_network(c['Subnet']) for n in networks for c in (n.get('IPAM',{}).get('Config') or []) if 'Subnet' in c]
    pairs=[('private','10.231.60.96/28'),('client','10.231.60.112/28')]
    assert not any(ipaddress.ip_network(s).overlaps(e) for _,s in pairs for e in existing)
    h.write(V/'network.json',{'networks':{key:{'ipam':{'config':[{'subnet':s}]}} for key,s in pairs}})
    h.run('p3-v1-volume-absence',['docker','volume','inspect',project+'_graph_data'],allow=(1,))
    h.run('p3-v1-graph-up',compose+['up','-d','graph'],env=env)
    time.sleep(3)
    h.run('p3-v1-init',compose+['run','--rm','service','init'],env=env)
    h.run('p3-v1-service-up',compose+['up','-d','service'],env=env)
elif stage=='walkthrough':
    original=h.W/'hag-phase2-20261005'
    # Read-only extraction of the exact original source manifest from its volume.
    h.run('p3-v1-source-manifest',compose+['exec','-T','service','cat','/source/source-manifest.json'],env=env)
    observed=json.loads(json.loads((h.O/'p3-v1-source-manifest.json').read_text())['stdout']);h.write(V/'source-manifest.json',observed)
    h.run('p3-v1-walkthrough',[h.HOST,'-X','utf8','-B',h.R/'tests/hosted_artifact_graph/qualify_service.py',
        '--client-python',h.O/'client02/Scripts/python.exe','--client-wheel',h.O/'build02/se_harness-0.22.2-py3-none-any.whl',
        '--configuration',V/'configuration/config.json','--credentials',P/'credentials.json','--source-manifest',V/'source-manifest.json',
        '--scenario-fixture',h.R/'tests/hosted_artifact_graph/fixtures/scenarios-v1.json','--output',V/'walkthrough',
        '--endpoint','http://127.0.0.1:18283'],timeout=1800)
elif stage=='boundaries':
    h.run('p3-v1-boundaries',compose+['run','--rm','--entrypoint','python','-v',str(h.O/'qualification02')+':/qualification:ro',
        '-v',str(V)+':/observations','service','-B','/qualification/qualify_boundaries.py',
        '--walkthrough','/observations/walkthrough','--output','/observations/boundaries'],env=env,timeout=1800)
elif stage=='wire':
    h.run('p3-v1-wire',['docker','run','--rm','--network','none','--mount',f'type=bind,source={h.R},target=/fixture,readonly',
        '--entrypoint','python','harness-hag:phase3-02','-I','-B','/fixture/tests/hosted_artifact_graph/validate_wire_contracts.py'])
