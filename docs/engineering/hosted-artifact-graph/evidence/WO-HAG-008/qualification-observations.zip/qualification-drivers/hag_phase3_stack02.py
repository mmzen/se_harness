import ipaddress,json,os,sys
import hag221_execute as h
h.O=h.W/'hag-phase3-execution-20261006'
package=h.O/'package02';compose=package/'candidate-source/server/compose.yaml'
project='hagphase320261006b'
env=dict(os.environ,HAG_SERVICE_IMAGE='harness-hag:phase3-02',HAG_HTTP_PORT='18281',
    HAG_CONFIG_DIRECTORY=str(package/'configuration'),HAG_CREDENTIAL_FILE=str(package/'credentials.json'),
    HAG_SOURCE_VOLUME='hagphase320261006-source02')
def dc(*args):return ['docker','compose','-p',project,'-f',compose,'-f',h.O/'network02.json',*args]
def common(output):return [h.HOST,'-X','utf8','-B',h.R/'tests/hosted_artifact_graph/qualify_pilot.py',
    '--client-python',h.O/'client02/Scripts/python.exe','--client-wheel',h.O/'build02/se_harness-0.22.2-py3-none-any.whl',
    '--configuration',package/'configuration/config.json','--credentials',package/'credentials.json',
    '--source-manifest',h.O/'pilot-input/staged/source-manifest.json','--repository',h.R,
    '--output',h.O/output,'--endpoint','http://127.0.0.1:18281']
stage=sys.argv[1]
if stage=='start':
    import subprocess
    ids=subprocess.check_output(['docker','network','ls','-q']).decode().split()
    networks=h.run('p3-networks02-retry',['docker','network','inspect',*ids])
    existing=[ipaddress.ip_network(c['Subnet']) for n in networks for c in (n.get('IPAM',{}).get('Config') or []) if 'Subnet' in c]
    subnets=['10.231.60.32/28','10.231.60.48/28','10.231.60.64/28','10.231.60.80/28']
    assert not any(ipaddress.ip_network(s).overlaps(e) for s in subnets for e in existing)
    for name,pair in [('network02.json',subnets[:2]),('network02-restore.json',subnets[2:])]:
        h.write(h.O/name,{'networks':{key:{'ipam':{'config':[{'subnet':s}]}} for key,s in zip(('private','client'),pair)}})
    h.run('p3-source02-absence',['docker','volume','inspect',env['HAG_SOURCE_VOLUME']],allow=(1,))
    h.run('p3-source02-create',['docker','volume','create',env['HAG_SOURCE_VOLUME']])
    h.run('p3-source02-copy',['docker','run','--rm','--network','none','--mount',f'type=bind,source={h.O/"pilot-input/staged"},target=/input,readonly',
        '--mount',f'type=volume,source={env["HAG_SOURCE_VOLUME"]},target=/source','--entrypoint','python','harness-hag:phase3-02','-c',
        'import shutil;shutil.copytree("/input","/source",dirs_exist_ok=True)'])
    h.run('p3-stack02-config',dc('config','--format','json'),env=env)
    h.run('p3-stack02-start',dc('up','-d','graph','service'),env=env)
    h.run('p3-stack02-init',dc('run','--rm','service','init'),env=env)
    h.run('p3-client02-venv',[h.HOST,'-m','venv',h.O/'client02'])
    h.run('p3-client02-install',[h.O/'client02/Scripts/python.exe','-I','-m','pip','install','--no-deps',h.O/'build02/se_harness-0.22.2-py3-none-any.whl'])
elif stage=='walkthrough':h.run('p3-walkthrough04-command',common('walkthrough04'),timeout=1800)
elif stage=='supplemental':
    import subprocess
    candidate=json.loads((package/'combination.json').read_text())['payload']['source']['candidate_commit']
    destination=h.O/'qualification02';destination.mkdir(exist_ok=False)
    prefix='tests/hosted_artifact_graph/'
    for name in subprocess.check_output(['git','ls-tree','-r','--name-only',candidate,'--',prefix],cwd=h.R).decode().splitlines():
        target=destination/name.removeprefix(prefix);target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(subprocess.check_output(['git','show',candidate+':'+name],cwd=h.R))
    h.run('p3-copy-qualification',dc('cp',destination,'service:/tmp/qualification'),env=env)
    h.run('p3-copy-walkthrough04',dc('cp',h.O/'walkthrough04','service:/tmp/walkthrough04'),env=env)
    h.run('p3-store04',dc('exec','-T','service','python','/tmp/qualification/qualify_pilot_store.py',
        '--state','/tmp/walkthrough04/walkthrough.json','--output','/tmp/store04.json'),env=env,timeout=1800)
    h.run('p3-store04-copy',dc('cp','service:/tmp/store04.json',h.O/'store04.json'),env=env)
elif stage=='parity':
    h.run('p3-replay04',dc('exec','-T','service','python','/tmp/qualification/qualify_pilot_replay.py',
        '--walkthrough','/tmp/walkthrough04','--output','/tmp/replay04'),env=env,timeout=1800)
    h.run('p3-replay04-copy',dc('cp','service:/tmp/replay04',h.O/'replay04'),env=env)
elif stage=='transport':
    argv=common('transport04');argv[4]=h.R/'tests/hosted_artifact_graph/qualify_pilot_transport.py'
    h.run('p3-transport04',argv+['--state',h.O/'store04.json'],timeout=600)
elif stage=='recover':
    h.run('p3-recovery04',[h.HOST,'-X','utf8','-B',package/'candidate-source/server/scripts/qualify.py','recover',
        '--compose',compose,'--project',project,'--output',h.O/'recovery04','--restore-port','18282',
        '--compose-override',h.O/'network02.json','--restore-override',h.O/'network02-restore.json'],env=env,timeout=900)
