import argparse
import json
from pathlib import Path
import platform
import subprocess
import sys
import time

p = argparse.ArgumentParser()
p.add_argument('label')
p.add_argument('--cwd', required=True)
p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args()
argv = a.command[1:] if a.command[:1] == ['--'] else a.command
out = Path(__file__).resolve().parent / ('correction-' + a.label)
assert not out.with_suffix('.json').exists(), out
started = time.time()
with out.with_suffix('.log').open('wb') as log:
    result = subprocess.run(argv, cwd=a.cwd, stdout=log, stderr=subprocess.STDOUT)
record = {'command': argv, 'cwd': a.cwd, 'exit_code': result.returncode,
          'started_unix': started, 'duration_seconds': time.time()-started,
          'observer_python': sys.version, 'platform': platform.platform(), 'log': out.with_suffix('.log').name}
out.with_suffix('.json').write_text(json.dumps(record, indent=2), encoding='utf-8')
print(json.dumps(record))
raise SystemExit(result.returncode)
