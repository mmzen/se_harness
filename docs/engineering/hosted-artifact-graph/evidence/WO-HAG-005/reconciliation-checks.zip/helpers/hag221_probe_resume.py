from hag221_execute import *
root=O/'reference-projection'
ref='82f5a0ed7438a73da8f03aee23ad02a9b8cc09e1'
j=json.loads((O/'reference-projection.json').read_text());overlay=j['selection_overlay'];checks=j['formal_source_blobs']
assert not (root/'.git').exists()
run('projection-git-init',['git','init',root])
run('projection-fetch-refs',['git','fetch',R,'+refs/heads/*:refs/remotes/source/*','--tags'],cwd=root)
run('projection-reference-head',['git','update-ref','HEAD',ref],cwd=root)
run('projection-reference-index',['git','read-tree',ref],cwd=root)
# Allocate through the real released authoring route, then use its ID.
preview=run('probe-create-preview-retry',[NEW,'-I','-m','se_harness','create-artifact',root,'--domain','instruction-architecture','--type','requirement','--dry-run','--json'])
ident=preview['allocated_id']
made=run('probe-create',[NEW,'-I','-m','se_harness','create-artifact',root,'--domain','instruction-architecture','--type','requirement','--id',ident,'--json'])
selected=root/made['changes'][0]['path']; template=selected.read_bytes()
complete=('+++\nid = "'+ident+'"\ntype = "requirement"\ntitle = "Isolated admission probe"\nstatus = "draft"\nowners = ["test-author"]\ncreated = "2026-10-05"\nupdated = "2026-10-05"\nstatement = "A sandbox draft remains a draft."\nverification_method = ["test"]\n[relations]\nderives_from = ["CAP-IAR-002"]\n+++\n\n# Isolated admission probe\n').encode()
cases=[('generated-incomplete',template,True,True),('empty-link',complete.replace(b'["CAP-IAR-002"]',b'[]'),True,True),('valid-capability',complete,True,False),('release-record-link',complete.replace(b'CAP-IAR-002',b'RLS-SEH-001'),False,None),('missing-real-target',complete.replace(b'CAP-IAR-002',b'CAP-MISSING-999'),False,None),('duplicate-toml',complete.replace(b'type = "requirement"',b'type = "requirement"\ntype = "requirement"'),False,None),('id-type-mismatch',complete.replace(b'type = "requirement"',b'type = "capability"'),False,None)]
results=[]
for name,data,admissible,incomplete in cases:
    write(selected,data)
    j=run('draft-probe-'+name,[NEW,'-I','-m','se_harness','validate-draft',root,'--artifact',ident,'--json'],allow=(0,) if admissible else (1,))
    assert j['admissible']==admissible and selected.read_bytes()==data,(name,j)
    if incomplete is not None:assert bool(j['incomplete'])==incomplete,(name,j)
    assert not j.get('next'),name
    results.append({'case':name,'admissible':j['admissible'],'incomplete':j['incomplete'],'errors':j['errors'],'unchanged_bytes':True,'passed':True})
write(O/'draft-probe-results.json',{'evaluator':'0.22.1','source':ref,'selected_draft':ident,'projection_selection':overlay,'cases':results,'all_pass':True,'hosted_scenarios_run':0})
print(json.dumps({'cases':len(results),'all_pass':True,'formal_files_preserved':len(checks),'hosted_scenarios_run':0}))
