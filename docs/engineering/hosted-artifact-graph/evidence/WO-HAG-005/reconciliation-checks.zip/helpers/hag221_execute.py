"""Apply the exact human-approved HAG reconciliation, retaining command results."""
import datetime,hashlib,json,os,re,subprocess,sys,tomllib,zipfile
from pathlib import Path
W=Path(__file__).resolve().parent; R=W/'hag221proposal'; REVIEW=W/'hag-amendment-review-20261005'; O=W/'hag221-execution-20261005'; O.mkdir(exist_ok=True)
D='docs/engineering/hosted-artifact-graph/'; EP=D+'evidence/WO-HAG-005/'
OLD=Path(r'C:\Users\mathi\.codex\plugins\data\verity-plane-se-harness\evaluators\0.22.0\44543f242ed19bb30cfd65da415372a87508a6e439204d7f3e37f9f45aefe4e4\Scripts\python.exe')
NEW=Path(r'C:\Users\mathi\.codex\plugins\data\verity-plane-se-harness\evaluators\0.22.1\cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053\Scripts\python.exe')
HOST=Path(r'C:\Users\mathi\AppData\Local\Python\pythoncore-3.14-64\python.exe')
H='64b4feb0cbaff06111876a1d4c0cc35a6c814415'; M='d7eeb2ae785928925669695074be7bdd6ccb1e0a'; B='be1812e7042081014cc7682da8b9cd3822d9071f'
binding=json.loads((REVIEW/'review-binding.json').read_text())
assert hashlib.sha256((REVIEW/'review-binding.json').read_bytes()).hexdigest()=='2dd5104adee7a1f8cc94df384ae62f6cbc0169448d91dae738dedb7292acab0a'
AUTH=('Human mmzen answered "I approve" to the reviewed WO-HAG-005 / VER-HAG-004 request, including DEC-HAG-002 bounded-manual-revision for the exact SPEC-HAG-003 and VER-HAG-001 replacements, required commit-bound verification, and ordinary updates to draft PR #535 in mmzen/se_harness from codex/hosted-artifact-phase1 to codex/hosted-artifact-graph-inputs, including ready-record review and the later separately supplied verification decision. The review binding SHA-256 is 2dd5104adee7a1f8cc94df384ae62f6cbc0169448d91dae738dedb7292acab0a. Earlier accepted bytes and lifecycle history are preserved. This is an explicit bounded manual amendment authorization; it grants no general amendment mechanism, verification acceptance, risk acceptance, merge, release or deployment. No machine lifecycle rule or required gate is waived.')
def sha(b):return hashlib.sha256(b).hexdigest()
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    if isinstance(value,(dict,list)):value=json.dumps(value,indent=2,ensure_ascii=False)+'\n'
    path.write_bytes(value.encode('utf-8') if isinstance(value,str) else value)
def record(rel):return tomllib.loads((R/rel).read_text(encoding='utf-8').split('+++',2)[1])
def run(label,args,cwd=W,allow=(0,),env=None,timeout=1800):
    dest=O/(label+'.json'); assert not dest.exists(),dest
    stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=subprocess.run([str(a) for a in args],cwd=cwd,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout,env=env)
    write(dest,{'argv':[str(a) for a in args],'cwd':str(cwd),'observed_at':stamp,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    try:j=json.loads(p.stdout)
    except ValueError:j={}
    print(json.dumps({'label':label,'exit':p.returncode,'log':str(dest),'result':{k:j[k] for k in ('restitution','valid','error_count','warning_count','artifact_count','status','outcome') if k in j},'tail':p.stdout[-1600:] if not j else '', 'stderr':p.stderr[-400:]}),flush=True)
    assert p.returncode in allow,(label,p.returncode)
    return j
def gov(label,*args,new=False,allow=(0,)):
    return run(label,[NEW if new else OLD,'-I','-m','se_harness',args[0],R,*args[1:],'--json'],allow=allow)
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True,encoding='utf-8').strip()
def blob(ref,path):return subprocess.check_output(['git','show',ref+':'+path],cwd=R)
def args_dec():return ['decide','--artifact','DEC-HAG-002','--option','bounded-manual-revision','--decision','mmzen','--reason',AUTH]
def args_approval():
    a=['transition']
    for ident in ('VER-HAG-004','WO-HAG-005'):a+=['--set',ident+'=approved','--decision',ident+'=mmzen','--reason',ident+'='+AUTH]
    return a
def check_review():
    for x in binding['records']:assert sha((R/x['path']).read_bytes())==x['sha256'],x['id']
    for x in binding['definition_revisions']:
        assert sha((R/x['path']).read_bytes())==x['before_sha256'],x['id']
        assert sha((REVIEW/x['proposed_transient_file']).read_bytes())==x['after_sha256'],x['id']
    assert git('rev-parse','HEAD')==H
mode=sys.argv[1] if __name__=='__main__' else None
if mode=='decision-preview':
    check_review(); gov('fresh-wo005','check','--artifact','WO-HAG-005')
    write(O/'approval.json',{'human':'mmzen','response':'I approve','reason':AUTH,'review_binding':binding})
    gov('dec002-preview',*args_dec())
elif mode=='decision-apply':
    check_review();gov('dec002-apply',*args_dec(),'--apply')
    assert record(D+'decisions/DEC-HAG-002.md')['status']=='decided'
    gov('dec002-readback','check','--artifact','DEC-HAG-002')
    p=R/D/'work-orders/WO-HAG-005.md';s=p.read_text();assert '[assurance]' not in s
    table='[assurance]\ncommit_bound_verification = "required"\nrationale = "mmzen confirmed required commit-bound verification because subsequent hosted work depends on the exact evaluator, revised definitions, integrated code and preserved evidence."\ndecided_by = "mmzen"\n\n'
    write(p,s.replace('[execution_scope]',table+'[execution_scope]',1))
    write(O/'approval-apply-binding.json',{x['path']:sha((R/x['path']).read_bytes()) for x in binding['records']})
    gov('approval-preview',*args_approval())
elif mode=='approve':
    for path,digest in json.loads((O/'approval-apply-binding.json').read_text()).items():assert sha((R/path).read_bytes())==digest,path
    gov('approval-apply',*args_approval(),'--apply')
    assert record(D+'work-orders/WO-HAG-005.md')['status']=='approved'
    assert record(D+'verification/VER-HAG-004.md')['status']=='approved'
    gov('approved-context','check','--artifact','WO-HAG-005')
    gov('start-preflight','preflight','--work-order','WO-HAG-005','--phase','start')
    gov('start-preview','transition','--set','WO-HAG-005=in_progress','--decision','WO-HAG-005=Codex')
elif mode=='start':
    assert record(D+'work-orders/WO-HAG-005.md')['status']=='approved'
    gov('start-apply','transition','--set','WO-HAG-005=in_progress','--decision','WO-HAG-005=Codex','--apply')
    gov('started-context','check','--artifact','WO-HAG-005')
    paths=json.loads((REVIEW/'planned-paths.json').read_text()); a=['check','--artifact','WO-HAG-005','--checkpoint','scope','--changes-complete']
    for path in paths:a+=['--changed-path',path]
    gov('implementation-scope',*a)
    run('approval-stage',['git','add','--',*[x['path'] for x in binding['records']]],cwd=R)
    run('approval-commit',['git','commit','-m','Authorize bounded HAG evaluator reconciliation','-m','Harness-Work-Order: WO-HAG-005'],cwd=R)
elif mode=='amend':
    assert record(D+'work-orders/WO-HAG-005.md')['status']=='in_progress'
    dec=record(D+'decisions/DEC-HAG-002.md');assert dec['status']=='decided'
    for x in binding['definition_revisions']:
        old=(R/x['path']).read_bytes(); new=(REVIEW/x['proposed_transient_file']).read_bytes()
        assert sha(old)==x['before_sha256'] and sha(new)==x['after_sha256']
        assert not (R/x['previous_evidence_path']).exists()
        write(R/x['previous_evidence_path'],old);write(R/x['path'],new)
    write(R/EP/'amendment.json',{'actor':'mmzen','response':'I approve','authority':AUTH,'decision':'DEC-HAG-002','work_order':'WO-HAG-005','mechanism':'Explicitly authorized bounded manual linked revision; no supported revision command is claimed and no lifecycle history is invented.','activated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'previous_source_commit':H,'revisions':binding['definition_revisions'],'earlier_evidence':'Original candidates and definition references remain unchanged.'})
    write(R/EP/'approval.json',json.loads((O/'approval.json').read_text()))
    run('amendment-stage',['git','add','--',*[x['path'] for x in binding['definition_revisions']],EP],cwd=R)
    run('amendment-commit',['git','commit','-m','Bind future hosted work to released evaluator 0.22.1','-m','Harness-Work-Order: WO-HAG-005'],cwd=R)
elif mode=='merge-preview':
    assert not git('status','--porcelain')
    run('merge-main',['git','merge','--no-commit','--no-ff',M],cwd=R,allow=(1,))
    conflicts=git('diff','--name-only','--diff-filter=U').splitlines()
    assert conflicts==['docs/engineering/README.md'],conflicts
    proposed=(REVIEW/'engineering-index-proposed.md').read_bytes();assert sha(proposed)==binding['index_resolution_sha256']
    write(R/'docs/engineering/README.md',proposed)
    run('resolve-index',['git','add','--','docs/engineering/README.md'],cwd=R)
    for x in json.loads((REVIEW/'integration-manifest-proposed.json').read_text())['files']:assert sha((R/x['path']).read_bytes())==x['proposed_sha256'],x['path']
    run('integration-diff-check',['git','diff','--cached','--check'],cwd=R)
    run('integration-commit',['git','commit','-m','Integrate released 0.22.1 adoption into hosted work','-m','Harness-Work-Order: WO-HAG-005'],cwd=R)
    gov('merged-doctor','doctor',new=True)
elif mode=='resolve-known-amendments':
    assert git('rev-parse','MERGE_HEAD')==M
    conflicts=git('diff','--name-only','--diff-filter=U').splitlines()
    expected=['docs/engineering/README.md']+[x['path'] for x in binding['definition_revisions']]
    assert sorted(conflicts)==sorted(expected),conflicts
    evidence=[]
    for x in binding['definition_revisions']:
        ours=blob(':2',x['path']); theirs=blob(':3',x['path'])
        assert sha(ours)==x['after_sha256'] and sha(theirs)==x['before_sha256'],x['path']
        assert sha((R/x['previous_evidence_path']).read_bytes())==x['before_sha256']
        write(R/x['path'],ours)
        evidence.append({'path':x['path'],'ours_sha256':sha(ours),'main_sha256':sha(theirs),'resolution':'Exact reviewed replacement; main has its unchanged preserved predecessor.'})
    write(R/'docs/engineering/README.md',(REVIEW/'engineering-index-proposed.md').read_bytes())
    write(O/'merge-amendment-conflicts.json',{'reason':'Applying the approved amendment before merging makes two formerly identical add/add paths differ. No reviewed bytes or scope changed.','conflicts':evidence})
    run('resolve-reviewed-conflicts',['git','add','--',*expected],cwd=R)
    assert not git('diff','--name-only','--diff-filter=U')
    for x in json.loads((REVIEW/'integration-manifest-proposed.json').read_text())['files']:assert sha((R/x['path']).read_bytes())==x['proposed_sha256'],x['path']
    run('integration-diff-check',['git','diff','--cached','--check'],cwd=R)
    run('integration-commit',['git','commit','-m','Integrate released 0.22.1 adoption into hosted work','-m','Harness-Work-Order: WO-HAG-005'],cwd=R)
elif mode=='finish-integration':
    assert git('rev-parse','MERGE_HEAD')==M and not git('diff','--name-only','--diff-filter=U')
    for x in json.loads((REVIEW/'integration-manifest-proposed.json').read_text())['files']:assert sha((R/x['path']).read_bytes())==x['proposed_sha256'],x['path']
    run('integration-crlf-diff-check',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'],cwd=R)
    run('integration-commit',['git','commit','-m','Integrate released 0.22.1 adoption into hosted work','-m','Harness-Work-Order: WO-HAG-005'],cwd=R)
elif mode=='finish-preserved-integration':
    assert git('rev-parse','MERGE_HEAD')==M and not git('diff','--name-only','--diff-filter=U')
    expected={x['path']:x for x in json.loads((REVIEW/'integration-manifest-proposed.json').read_text())['files']}
    for path,x in expected.items():assert sha((R/path).read_bytes())==x['proposed_sha256'],path
    oldcheck=json.loads((O/'integration-crlf-diff-check.json').read_text())
    findings=re.findall(r'^(.+):[0-9]+: (?:trailing whitespace|new blank line at EOF|space before tab in indent)\.',oldcheck['stdout'],re.M)
    assert findings
    for path in findings:assert expected[path]['matches_main'] and (R/path).read_bytes()==blob(M,path),path
    authored=['docs/engineering/README.md']+[x['path'] for x in binding['records']]+[x['path'] for x in binding['definition_revisions']]
    run('authored-integration-whitespace',['git','diff','--cached','--check','--',*authored],cwd=R)
    write(O/'preserved-whitespace-assessment.json',{'historical_paths':sorted(set(findings)),'all_match_approved_main_bytes':True,'assessment':'Warnings concern byte-preserved imported evidence, including significant blank-context lines in patch evidence. Preserve the original failure results and exact bytes. Repository AGENTS.md configures no formatter; the check of newly authored files passes.'})
    run('integration-commit',['git','commit','-m','Integrate released 0.22.1 adoption into hosted work','-m','Harness-Work-Order: WO-HAG-005'],cwd=R)
elif mode=='activate':
    j=run('activate-0221',[HOST,'-I',r'C:\Users\mathi\.codex\plugins\cache\se-harness\verity-plane\0.2.6\scripts\activate.py','--host','codex','--session-id','01a0bd7b-24c7-7503-8955-4a24231fb2a4','--data-root',r'C:\Users\mathi\.codex\plugins\data\verity-plane-se-harness','--target',R])
    assert j['status']=='available';print(j['content'],flush=True)
elif mode=='existing-decision-preview':
    gov('merged-doctor','doctor',new=True)
    gov('merged-current-work','check','--artifact','WO-HAG-005',new=True)
    gov('dec001-current','check','--artifact','DEC-HAG-001',new=True)
    reason='mmzen already selected extend-evaluator, as explicitly confirmed in the human handoff and retained correction work. Public evaluator 0.22.1 now contains the verified draft-admission and attribution fixes. WO-HAG-005 records the separately approved pin amendment and integration. This applies that existing choice only; hosted work remains in_progress and no hosted verification, risk acceptance, merge or release is supplied.'
    write(O/'dec001-reason.txt',reason)
    gov('dec001-preview','decide','--artifact','DEC-HAG-001','--option','extend-evaluator','--decision','mmzen','--authority-owner','engineering-owner','--reason',reason,new=True)
elif mode=='existing-decision-apply':
    assert record(D+'decisions/DEC-HAG-001.md')['status']=='open'
    gov('dec001-apply','decide','--artifact','DEC-HAG-001','--option','extend-evaluator','--decision','mmzen','--authority-owner','engineering-owner','--reason',(O/'dec001-reason.txt').read_text(),'--apply',new=True)
    meta=record(D+'decisions/DEC-HAG-001.md');assert meta['status']=='decided'
    print(json.dumps(meta['disposition']),flush=True)
    gov('dec001-readback','check','--artifact','DEC-HAG-001',new=True)
    run('decision-stage',['git','add','--',D+'decisions/DEC-HAG-001.md'],cwd=R)
    run('decision-commit',['git','commit','-m','Record the existing hosted evaluator extension decision','-m','Harness-Work-Order: WO-HAG-005'],cwd=R)
    write(O/'implementation-commit.txt',git('rev-parse','HEAD')+'\n')
else:
    if mode is not None:raise ValueError(mode)
