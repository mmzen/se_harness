"""Observed reconciliation checks; never use candidate source as governor."""
import hashlib,json,os,subprocess,sys,tarfile
from pathlib import Path
from hag221_execute import W,R,O,REVIEW,D,EP,H,M,B,NEW,HOST,run,gov,sha,write,blob,record,git
mode=sys.argv[1]
if mode=='full':
    run('source-full',[HOST,'-B','-X','utf8','scripts/run_tests.py','--scale','full'],cwd=R)
elif mode=='other':
    run('distribution-check',[HOST,'-B','-X','utf8','scripts/validate_release_distributions.py','--root','.'],cwd=R)
    run('cli-smoke',[HOST,'-B','-X','utf8','-m','se_harness','--help'],cwd=R)
    run('evaluator-facts',[HOST,'-B','-X','utf8','-m','repository_tools.evaluator_facts','derive','--repository',R,'--json'],cwd=R)
    run('released-identity',[NEW,'-I','-m','se_harness','identity','--role','released-evaluator','--expected-version','0.22.1','--expected-root',NEW.parent.parent,'--checkout-root',R,'--evaluator-payload-sha256','0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff','--evaluator-wheel-sha256','cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053','--require-isolated-python','--json'])
    gov('integrated-validation','validate',new=True)
elif mode=='preserve':
    rows=subprocess.check_output(['git','ls-tree','-r','-z',H,'--',D,'server/','tests/hosted_artifact_graph/','tests/test_hosted_artifact_graph.py'],cwd=R)
    allowed={D+'specifications/SPEC-HAG-003.md',D+'verification/VER-HAG-001.md',D+'decisions/DEC-HAG-001.md',D+'README.md'}
    original=[]
    for row in rows.split(b'\0'):
        if not row:continue
        meta,path=row.decode().split('\t',1)
        if path in allowed:continue
        expected=meta.split()[2];b=(R/path).read_bytes();actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
        original.append({'path':path,'original_blob':expected,'current_blob':actual,'equal':actual==expected})
    assert all(x['equal'] for x in original)
    integration=json.loads((REVIEW/'integration-manifest-proposed.json').read_text()); imported=[]
    for e in integration['files']:
        actual=sha((R/e['path']).read_bytes()); imported.append(dict(e,actual_sha256=actual,equal_to_reviewed=actual==e['proposed_sha256']))
    assert all(x['equal_to_reviewed'] for x in imported)
    revisions=json.loads((REVIEW/'definition-revisions.json').read_text())
    for e in revisions:
        assert sha((R/e['path']).read_bytes())==e['after_sha256']
        assert sha((R/e['previous_evidence_path']).read_bytes())==e['before_sha256']
        old=__import__('tomllib').loads(blob(H,e['path']).decode().split('+++',2)[1]);new=record(e['path'])
        assert old['lifecycle_events']==new['lifecycle_events']
    wo=record(D+'work-orders/WO-HAG-001.md');assert wo['status']=='in_progress' and wo['owners']==['engineering-owner']
    assert record(D+'risks/RISK-HAG-001.md')['status']=='raised'
    result={'baseline':H,'integrated_main':M,'unchanged_hag_files':original,'reviewed_transport':imported,'revisions':revisions,'all_pass':True}
    write(O/'preservation.json',result);write(R/EP/'integration-manifest.json',result)
    print(json.dumps({'unchanged_hag_files':len(original),'transport_files':len(imported),'passed':True}))
elif mode=='draft-probes':
    ref='82f5a0ed7438a73da8f03aee23ad02a9b8cc09e1';root=O/'reference-projection';assert not root.exists()
    archive=O/'reference-source.tar'
    run('reference-export',['git','archive','--format=tar','--output',archive,ref],cwd=R)
    root.mkdir()
    with tarfile.open(archive) as t:t.extractall(root,filter='data')
    # Exact formal source bytes must survive the projection. Record the two
    # selection files separately; they are test overlay, not imported history.
    rows=subprocess.check_output(['git','ls-tree','-r','-z',ref,'--','docs/engineering'],cwd=R)
    checks=[]
    for row in rows.split(b'\0'):
        if not row:continue
        meta,path=row.decode().split('\t',1); data=(root/path).read_bytes()
        actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();expected=meta.split()[2]
        assert actual==expected,path;checks.append({'path':path,'blob':expected})
    overlay=[]
    for p in ('.engineering-harness.toml','.engineering-harness.lock'):
        old=(root/p).read_bytes();new=(R/p).read_bytes();write(root/p,new)
        overlay.append({'path':p,'source_sha256':sha(old),'projection_sha256':sha(new)})
    write(O/'reference-projection.json',{'source':ref,'formal_source_file_count':len(checks),'formal_source_blobs':checks,'selection_overlay':overlay})
    run('reference-0221-validation',[NEW,'-I','-m','se_harness','validate',root,'--json'])
    context=run('reference-0221-context',[NEW,'-I','-m','se_harness','check',root,'--artifact','WO-RLS-038','--json'])
    # Allocate through the real released authoring route, then use its ID.
    preview=run('probe-create-preview',[NEW,'-I','-m','se_harness','create-artifact',root,'--domain','instruction-architecture','--type','requirement','--dry-run','--json'])
    ident=preview['allocated_id']
    made=run('probe-create',[NEW,'-I','-m','se_harness','create-artifact',root,'--domain','instruction-architecture','--type','requirement','--id',ident,'--json'])
    selected=root/made['changes'][0]['path']; template=selected.read_bytes()
    complete=('+++\nid = "'+ident+'"\ntype = "requirement"\ntitle = "Isolated admission probe"\nstatus = "draft"\nowners = ["test-author"]\ncreated = "2026-10-05"\nupdated = "2026-10-05"\nstatement = "A sandbox draft remains a draft."\nverification_method = ["test"]\n[relations]\nderives_from = ["CAP-IAR-002"]\n+++\n\n# Isolated admission probe\n').encode()
    cases=[('generated-incomplete',template,True,True),('empty-link',complete.replace(b'["CAP-IAR-002"]',b'[]'),True,True),('valid-capability',complete,True,False),('release-record-link',complete.replace(b'CAP-IAR-002',b'RLS-SEH-001'),False,None),('missing-real-target',complete.replace(b'CAP-IAR-002',b'CAP-MISSING-999'),False,None),('duplicate-toml',complete.replace(b'type = "requirement"',b'type = "requirement"\ntype = "requirement"'),False,None),('id-type-mismatch',complete.replace(b'type = "requirement"',b'type = "capability"'),False,None)]
    results=[]
    for name,data,admissible,incomplete in cases:
        write(selected,data)
        j=run('draft-probe-'+name,[NEW,'-I','-m','se_harness','validate-draft',root,'--artifact',ident,'--json'],allow=(0,) if admissible else (1,))
        assert j['admissible']==admissible and selected.read_bytes()==data,(name,j)
        if incomplete is not None:assert bool(j['incomplete'])==incomplete,(name,j)
        assert not j.get('next'),name
        results.append({'case':name,'admissible':j['admissible'],'incomplete':j['incomplete'],'errors':j['errors'],'unchanged_bytes':True,'passed':True})
    write(O/'draft-probe-results.json',{'evaluator':'0.22.1','source':ref,'selected_draft':ident,'projection_selection':overlay,'cases':results,'all_pass':True,'hosted_scenarios_run':0})
    print(json.dumps({'cases':len(results),'all_pass':True,'formal_files_preserved':len(checks),'hosted_scenarios_run':0}))
else:raise ValueError(mode)
