import hag221_execute as h
h.O=h.W/'hag-codex-20261006'
h.run('client-inspection-sandbox',[
    r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe',
    '--no-daemon','sandbox','-C',h.O,'-c','sandbox_mode="read-only"',
    h.W/'hag-claude-20261006/client-environment-05/Scripts/python.exe',
    '-I',h.O/'diagnose_client.py'],allow=(0,1))
