"""One-shot native Codex observations, with the normal host sandbox and auth."""
import datetime, json, os, re, subprocess, sys, threading
from pathlib import Path
import hag221_execute as h
O=h.W/'hag-codex-20261006'; P=h.W/'hag-claude-20261006'
C=r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe'
mode=sys.argv[1]
dest=O/('native-'+mode+'.json');assert not dest.exists()
options=['--sandbox','read-only']
env=dict(os.environ,PYTHONUTF8='1',NO_COLOR='1')
creds=json.loads((P/'package-05/credentials.json').read_text())
if mode=='diagnose':
    cmd="& '"+str(P/'client-environment-05/Scripts/python.exe')+"' -I '"+str(O/'diagnose_client.py')+"'"
    prompt=('The user requested continued Codex testing and analysis. The exact hosted client failed before sending any mutation: Cannot inspect the exact client wheel. '
        'Perform this read-only diagnosis under the normal sandbox. Read '+str(O/'diagnose_client.py')+' then run exactly once: '+cmd+'. '
        'The script only checks the installed candidate against its exact wheel and prints an exception chain. It reads no credentials and uses no network. '
        'Do not edit, install, change permissions, retry through an alternate route, or run any other commands. Report the actual exception and path; do not infer a cause that is not observed.')
elif mode=='walkthrough-retry':
    old=json.loads((O/'walkthrough/002-import-reference-result.json').read_text())
    assert json.loads(old['stderr'])['outcome']=='not_sent'
    token=next(p['token'] for p in creds['principals'] if p['id']=='operator')
    h.O=O
    ready=h.run('readiness-before-retry',[P/'client-environment-05/Scripts/python.exe','-I','-m','se_harness','remote','status',
        '--endpoint','http://127.0.0.1:18089','--project','11111111-1111-4111-8111-111111111111','--token-env','HAG_TEST_TOKEN','--json'],
        env=dict(os.environ,HAG_TEST_TOKEN=token))
    assert ready['ready'] and ready['project_version']==0
    launcher=O/'run_walkthrough_retry.py';assert not launcher.exists()
    text=(O/'run_walkthrough.py').read_text()
    text=text.replace(repr(str(O/'walkthrough')),repr(str(O/'walkthrough-retry')))
    h.write(launcher,text)
    options=['--approve-for-me']
    cmd="& '"+str(h.HOST)+"' -B '"+str(launcher)+"'"
    plugin=O/'candidate-plugin/verity-plane'
    prompt=('Continue the user-requested native Codex qualification of WO-HAG-001. The previous real walkthrough stopped with PermissionError opening the exact candidate wheel, before sending its import. '
        'The retained result is '+str(O/'walkthrough/002-import-reference-result.json')+'. Current readback '+str(O/'readiness-before-retry.json')+' confirms ready and project version zero; there is no uncertain mutation to repeat. '
        'Read the exact setup/change candidate skills at '+str(plugin/'skills/setup/SKILL.md')+' and '+str(plugin/'skills/change/SKILL.md')+', then the inspected launcher '+str(launcher)+'. '
        'This launcher has the same test, executable, wheel, credentials and loopback endpoint as before; only the output path differs to preserve failure evidence. '
        'Use the normal request for sandbox_permissions=require_escalated for exactly this command, explaining its read of the sandbox-inaccessible wheel and its private test purpose: '+cmd+'. '
        'Automatic review must authorize it before execution. If denied, stop. Do not switch route, copy the protected wheel, change ACLs, weaken settings or bypass review. '
        'Run once, allow 600 seconds, wait for completion. It accesses only the local private service at http://127.0.0.1:18089 and test artifacts; the helper keeps sandbox credentials out of output. '
        'No credentials inspection, installations, edits, other commands, subagents, Git, public deployment or lifecycle decisions. Read the resulting walkthrough JSON and report actual assertions, failures and limits. '
        'Disclose that this run needed a normally reviewed execution escalation. It does not prove all commands work within the unextended sandbox, automatic candidate-plugin delivery, desktop coverage or full qualification.')
elif mode in ('mcp','mcp-reviewed','partial'):
    walk=json.loads((O/'walkthrough-retry/walkthrough.json').read_text())
    revised=json.loads(json.loads((O/'walkthrough-retry/009-revise-body-and-relation-result.json').read_text())['stdout'])
    config=json.loads((P/'package-05/configuration/config.json').read_text())
    baseline=walk['baseline']; context=walk['context'];binding=revised['affected_artifacts'][0]
    def request(op,view=baseline,**kw):
        return dict(schema='se-harness-graph-read/v1',project_id=config['project_id'],operation=op,view=view,budget={'rows':500,'bytes':2097152,'depth':8},**kw)
    requests=[request('revision',context,**binding),request('work-context',work_order_id='WO-RLS-038'),
        request('compare',{'kind':'comparison','left':baseline,'right':context}),request('impact',artifact_id='CAP-IAR-002'),
        request('lineage',artifact_id='VREC-RLS-002'),request('check',artifact_id='WO-RLS-038'),
        request('cypher',query='MATCH (r:Revision) WHERE r.artifact_id = $id RETURN r.artifact_id AS id LIMIT 5',parameters={'id':'WO-RLS-038'})]
    if mode=='partial':
        requests=[request('impact',artifact_id='CAP-IAR-002')];requests[0]['budget']['rows']=1
    selected=O/(mode+'-requests.json');assert not selected.exists();h.write(selected,requests)
    if mode=='mcp-reviewed':
        assert requests==json.loads((O/'mcp-requests.json').read_text())
        options=['--approve-for-me']
    env['HAG_NATIVE_TEST_TOKEN']=next(p['token'] for p in creds['principals'] if p['id']=='operator')
    options+=['-c','mcp_servers.hag.url="http://127.0.0.1:18089/mcp"',
        '-c','mcp_servers.hag.bearer_token_env_var="HAG_NATIVE_TEST_TOKEN"',
        '-c','mcp_servers.hag.required=true','-c','mcp_servers.hag.tool_timeout_sec=180']
    plugin=O/'candidate-plugin/verity-plane'
    prompt=('Test the user-authorized WO-HAG-001 private hosted sandbox through the actual configured hag MCP tools. '
        'Read the hosted sandbox sections of '+str(plugin/'skills/setup/SKILL.md')+' and '+str(plugin/'skills/harness-orient/SKILL.md')+'. '
        'The exact candidate uses plugin guidance 0.2.7, client 0.22.2, service 0.1.0.dev1 and public evaluator 0.22.1. '
        'Read '+str(selected)+' and call each corresponding hag tool exactly once with the full unchanged JSON request. '
        'Keep the project, view and budget inputs. These are read-only operations on public reference data in a private local test service. Authentication is already configured outside the prompt. '
        'Read the actual results and report each operation, complete field, continuation/error and what can be concluded. '
        'Do not run other commands, edit files, inspect credentials, make mutations, install anything, spawn agents, weaken permissions or retry through a different route after refusal. '
        'A checkpoint-free check reports lifecycle context, not evaluated gates. Do not claim lifecycle authority, full qualification, native candidate-plugin installation or desktop coverage.')
    if mode=='mcp-reviewed':
        prompt+=(' The previous read-only exec profile refused every call because its approval policy was never. This session uses the normal automatic approval reviewer. '
            'Submit the same seven calls once for that normal review. If review denies a call, retain the denial and do not change settings, switch route or retry it. No tool-specific approval bypass is configured.')
else:
    raise ValueError(mode)
args=[C,'--no-daemon','exec','--ephemeral','--skip-git-repo-check','--json','-C',str(O),
      '-c','plugins."verity-plane@se-harness".enabled=false',*options,prompt]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();lines=[]
with subprocess.Popen(args,cwd=O,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',stdin=subprocess.DEVNULL) as child:
    timer=threading.Timer(900,child.kill);timer.start()
    try:
        for line in child.stdout:
            assert all(p['token'] not in line for p in creds['principals'])
            assert not re.search(r'sk-ant-(?:oat|ort|api)\S+',line)
            lines.append(line)
            try:e=json.loads(line)
            except ValueError:continue
            item=e.get('item',{})
            if e.get('type')=='item.completed':
                print(json.dumps({'type':item.get('type'),'tool':item.get('tool'),'status':item.get('status'),
                      'message':item.get('text') if item.get('type')=='agent_message' else None}),flush=True)
        code=child.wait()
    finally:timer.cancel()
h.write(dest,{'argv':args,'cwd':str(O),'observed_at':started,'exit':code,'stdout':''.join(lines),
    'claim':'Native Codex observation. Normal credential store and sandbox; exact candidate guidance explicitly selected, not automatic candidate plugin installation.'})
print(json.dumps({'exit':code,'record':str(dest)}),flush=True)
raise SystemExit(code)
