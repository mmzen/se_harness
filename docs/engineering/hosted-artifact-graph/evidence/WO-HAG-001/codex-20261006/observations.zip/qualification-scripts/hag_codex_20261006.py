"""Native Codex qualification using its normal credential store; no credential copies."""
import datetime, hashlib, json, os, re, subprocess, sys, threading, zipfile
from pathlib import Path

W=Path(__file__).resolve().parent
O=W/'hag-codex-20261006'
P=W/'hag-claude-20261006'
C=Path(r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe')
combo=json.loads((P/'package-05/combination.json').read_text())
plugin=O/'candidate-plugin/verity-plane'
project=O/'read-project'
mode=sys.argv[1]

def sha(b): return hashlib.sha256(b).hexdigest()
def save(p,value):
    assert not p.exists(),p
    raw=(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()
    assert not re.search(rb'sk-ant-(?:oat|ort|api)[0-9A-Za-z_-]{16,}',raw)
    p.write_bytes(raw)

if mode=='prepare':
    archive=P/'package-05/plugin/verity-plane-codex.zip'
    assert sha(archive.read_bytes())==combo['payload']['plugins']['codex']['archive_sha256']
    assert not plugin.exists()
    paths=[]
    with zipfile.ZipFile(archive) as z:
        for member in z.infolist():
            if member.is_dir(): continue
            target=O/'candidate-plugin'/member.filename
            assert target.resolve().is_relative_to(plugin.resolve()),member.filename
            assert '..' not in Path(member.filename).parts
            target.parent.mkdir(parents=True,exist_ok=True)
            raw=z.read(member);target.write_bytes(raw)
            paths.append({'path':member.filename,'sha256':sha(raw),'bytes':len(raw)})
    project.mkdir(exist_ok=False)
    save(O/'candidate-binding.json',{'combination_id':combo['combination_id'],'candidate':combo['payload']['source']['candidate_commit'],'plugin':combo['payload']['plugins']['codex'],'plugin_root':str(plugin),'files':paths,'credential_handling':'Normal host credential store; no OAuth files copied or read by this helper.'})
    print(json.dumps({'prepared':str(plugin),'files':len(paths)}))
elif mode=='read':
    dest=O/'native-read-normal-profile.json'
    assert not dest.exists()
    prompt=('Perform the user-authorized read-only diagnostic for WO-HAG-001 native Codex testing. '
      'The test uses the normal host Windows sandbox configuration and keeps read-only protection. '
      'Read these exact two files through normal shell tools: '+str(plugin/'skills/setup/SKILL.md')+' and '+str(plugin/'skills/change/SKILL.md')+'. '
      'They are exact bytes from the separately packaged unpublished candidate plugin 0.2.7. The normal published Verity Plane plugin is disabled only for this invocation to avoid mixing versions. '
      'Report the actual file paths read, the released evaluator version that governs the hosted service, the separate remote client role, and the required handling of an uncertain remote write. '
      'Do not run hosted commands or other tests, read authentication or credential files, inspect environment variables, edit files, install anything, spawn subagents, change permissions, or request escalations. '
      'If a tool is refused, stop and report the exact refusal. Do not retry through another executable or path. '
      'This tests actual native reading of exact packaged files; it does not establish automatic plugin loading, desktop delivery or full qualification.')
    args=[str(C),'--no-daemon','exec','--ephemeral','--sandbox','read-only','--skip-git-repo-check','--json','-C',str(project),'-c','plugins."verity-plane@se-harness".enabled=false',prompt]
    env=dict(os.environ,PYTHONUTF8='1',NO_COLOR='1')
    stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=subprocess.run(args,cwd=project,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=480,stdin=subprocess.DEVNULL)
    save(dest,{'argv':args,'cwd':str(project),'observed_at':stamp,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'claim':'Exact packaged instruction read through native Codex using normal auth/config and read-only sandbox; no automatic candidate-plugin loading claim.'})
    print(json.dumps({'record':str(dest),'exit':p.returncode,'stderr':p.stderr[-2500:]},ensure_ascii=False))
    for line in p.stdout.splitlines():
        try: x=json.loads(line)
        except ValueError: continue
        if x.get('type')=='item.completed':
            item=x.get('item',{})
            if item.get('type')=='agent_message': print(item.get('text',''))
            elif item.get('type')=='command_execution': print(json.dumps({'command':item.get('command'),'exit_code':item.get('exit_code'),'status':item.get('status')}))
    sys.exit(p.returncode)
else: raise ValueError(mode)
