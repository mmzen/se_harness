"""Prepare/run native Codex against a fresh private graph with the existing exact tuple."""
import datetime, hashlib, json, os, re, subprocess, sys, time
from pathlib import Path
import hag221_execute as h

O=h.W/'hag-codex-20261006';h.O=O
P=h.W/'hag-claude-20261006'
C=r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe'
combo=json.loads((P/'package-05/combination.json').read_text())
project='hagcodex20261006'
compose=['docker','compose','-p',project,'-f',P/'package-05/candidate-source/server/compose.yaml']
env=dict(os.environ,HAG_SERVICE_IMAGE='harness-hag:mcp-05',HAG_HTTP_PORT='18089',HAG_SOURCE_VOLUME='hagphase220261005_source',HAG_CONFIG_DIRECTORY=str(P/'package-05/configuration'),HAG_CREDENTIAL_FILE=str(P/'package-05/credentials.json'))
mode=sys.argv[1]
if mode=='prepare':
    h.run('codex-sandbox-volume-absent',['docker','volume','inspect',project+'_graph_data'],allow=(1,))
    h.write(O/'sandbox-selection.json',{'compose_argv':list(map(str,compose)),'environment':{k:v for k,v in env.items() if k.startswith('HAG_')},'endpoint':'http://127.0.0.1:18089'})
    h.run('codex-sandbox-graph-up',compose+['up','-d','graph'],env=env)
    time.sleep(3)
    h.run('codex-sandbox-initialize',compose+['run','--rm','service','init'],env=env)
    h.run('codex-sandbox-service-up',compose+['up','-d','service'],env=env)
    time.sleep(2)
    h.run('codex-sandbox-ready',compose+['exec','-T','service','python','-m','hosted_artifact_graph','ready'],env=env)
    identity=h.run('codex-service-identity',['docker','inspect','--format','{{json .}}',project+'-service-1'])
    assert identity['Image']==combo['payload']['server']['image_manifest']
    original=json.loads((h.W/'hag-phase2-20261005/protocol04-walkthrough.json').read_text())['argv']
    for flag,value in {'--client-python':P/'client-environment-05/Scripts/python.exe','--client-wheel':P/'client-build-05/se_harness-0.22.2-py3-none-any.whl','--configuration':P/'package-05/configuration/config.json','--credentials':P/'package-05/credentials.json','--endpoint':'http://127.0.0.1:18089','--output':O/'walkthrough'}.items():
        original[original.index(flag)+1]=str(value)
    assert hashlib.sha256((P/'client-build-05/se_harness-0.22.2-py3-none-any.whl').read_bytes()).hexdigest()==combo['payload']['client']['wheel_sha256']
    for rel in ('tests/hosted_artifact_graph/qualify_service.py','tests/hosted_artifact_graph/fixtures/scenarios-v1.json'):
        assert (h.R/rel).read_bytes().replace(b'\r\n',b'\n')==h.blob(combo['payload']['source']['candidate_commit'],rel).replace(b'\r\n',b'\n')
    entry=O/'run_walkthrough.py';assert not entry.exists()
    h.write(entry,'import subprocess,sys\nargs='+repr(original)+'\np=subprocess.run(args,cwd='+repr(str(O))+')\nsys.exit(p.returncode)\n')
    print(json.dumps({'prepared':str(entry),'endpoint':'http://127.0.0.1:18089'}))
elif mode=='run':
    dest=O/'native-walkthrough.json';assert not dest.exists() and not (O/'walkthrough').exists()
    plugin=O/'candidate-plugin/verity-plane'
    command='& '+"'"+str(h.HOST)+"' -B '"+str(O/'run_walkthrough.py')+"'"
    prompt=('Continue user-authorized WO-HAG-001 native Codex qualification in this disposable private sandbox. '
      'Read the exact candidate setup/change skills at '+str(plugin/'skills/setup/SKILL.md')+' and '+str(plugin/'skills/change/SKILL.md')+'. '
      'Read the component identity report at '+str(P/'package-05/combination.json')+' and the inspected launcher '+str(O/'run_walkthrough.py')+'. '
      'The source candidate is '+combo['payload']['source']['candidate_commit']+'. Client 0.22.2, plugin guidance 0.2.7 and service 0.1.0.dev1 are unpublished; governor and service evaluator stay public 0.22.1. '
      'The test service is already running privately at http://127.0.0.1:18089. Its graph is a fresh disposable projection of public reference data. '
      'Run exactly this PowerShell command once: '+command+'. Allow at least 600 seconds and wait for completion. '
      'The launcher performs the actual installed CLI sequence: import, context, draft creation/revision, invalid/stale/key-reuse refusal, accepted retry, unchanged baseline, comparison, Cypher, context check and freeze. '
      'It reads the sandbox credential internally for the authorized local endpoint and writes test observations only under this workspace. Do not inspect or print credential contents yourself. '
      'Normal sandbox and automatic review remain enabled. If this exact command requires network or filesystem approval, use the normal approval mechanism with its bounded purpose. If approval is denied, stop; do not switch executables or weaken controls. '
      'Do not run other commands except reading the named files and resulting walkthrough JSON/command results. Do not edit files, install anything, spawn agents, change permissions, push, make lifecycle decisions or expose the service. '
      'After completion, read walkthrough/walkthrough.json and report only actual outcomes. Do not invent timing totals. A checkpoint-free check does not evaluate gates. Freeze creates a baseline, not approval. '
      'This tests exact packaged guidance through an explicitly directed read and launcher. It does not prove automatic candidate-plugin loading, desktop delivery or full qualification.')
    args=[C,'--no-daemon','exec','--ephemeral','--approve-for-me','--skip-git-repo-check','--json','-C',str(O),'-c','plugins."verity-plane@se-harness".enabled=false',prompt]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=subprocess.run(args,cwd=O,env=dict(os.environ,PYTHONUTF8='1',NO_COLOR='1'),capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=900,stdin=subprocess.DEVNULL)
    record={'argv':args,'cwd':str(O),'observed_at':start,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'claim':'Native guided run of actual installed CLI. Normal credential store and Windows sandbox retained; exact candidate files explicitly selected, not automatically installed.'}
    raw=json.dumps(record,ensure_ascii=False)
    secrets=[v['token'] for v in json.loads((P/'package-05/credentials.json').read_text())['principals']]
    assert all(s not in raw for s in secrets)
    assert not re.search(r'sk-ant-(?:oat|ort|api)[0-9A-Za-z_-]{16,}',raw)
    h.write(dest,record)
    print(json.dumps({'exit':p.returncode,'record':str(dest),'walkthrough_complete':(O/'walkthrough/walkthrough.json').exists(),'stderr':p.stderr[-1500:]}))
    for line in p.stdout.splitlines():
        try: x=json.loads(line)
        except ValueError: continue
        if x.get('type')=='item.completed' and x.get('item',{}).get('type')=='agent_message':print(x['item']['text'])
    sys.exit(p.returncode)
else:raise ValueError(mode)
