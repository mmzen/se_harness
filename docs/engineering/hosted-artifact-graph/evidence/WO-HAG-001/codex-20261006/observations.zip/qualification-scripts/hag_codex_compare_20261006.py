"""Compare retained native Codex MCP calls with HTTP on the unchanged view."""
import datetime,json,time,urllib.request
import hag221_execute as h
O=h.W/'hag-codex-20261006';P=h.W/'hag-claude-20261006'
record=json.loads((O/'native-mcp-reviewed.json').read_text())
expected={r['operation']:r for r in json.loads((O/'mcp-reviewed-requests.json').read_text())}
events=[]
for line in record['stdout'].splitlines():
    try:events.append(json.loads(line))
    except ValueError:pass
actual={}
for e in events:
    item=e.get('item',{})
    if e.get('type')!='item.completed' or item.get('type')!='mcp_tool_call' or item.get('server')!='hag':continue
    op=item['tool'];assert op not in actual
    assert item['arguments']==expected[op],op
    assert item['status']=='completed' and not item.get('error'),(op,item)
    result=item['result'];assert not result.get('isError')
    content=result['content'];assert len(content)==1 and content[0]['type']=='text'
    response=json.loads(content[0]['text'])
    assert response['operation']==op
    actual[op]=response
assert record['exit']==0 and set(actual)==set(expected)
credentials=json.loads((P/'package-05/credentials.json').read_text())
token=next(p['token'] for p in credentials['principals'] if p['id']=='operator')
out=[]
for op,request in expected.items():
    url='http://127.0.0.1:18089/v1/projects/'+request['project_id']+'/reads/'+op
    started=time.monotonic()
    req=urllib.request.Request(url,data=json.dumps(request).encode(),headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=180) as response:
        status=response.status;http=json.load(response)
    equal=status==200 and http==actual[op]
    out.append({'operation':op,'url':url,'request':request,'http_status':status,'http':http,'native_mcp':actual[op],
                'equal':equal,'complete':actual[op]['complete'],'continuation':actual[op].get('continuation'),'seconds':round(time.monotonic()-started,3)})
    print(json.dumps({'operation':op,'exact_http_mcp_match':equal,'complete':actual[op]['complete'],'continuation':actual[op].get('continuation')}),flush=True)
data={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'comparisons':out,
      'claim':'Exact request/response transport comparison from retained native Codex tool events. Completeness and agent narrative are assessed separately.'}
raw=json.dumps(data,ensure_ascii=False)
assert all(p['token'] not in raw for p in credentials['principals'])
dest=O/'http-mcp-comparison.json';assert not dest.exists();h.write(dest,data)
assert all(x['equal'] for x in out)
