"""Read-only inspection of the installed candidate; no credentials or network."""
import json, pathlib, traceback
from se_harness.remote import installed_client

wheel = pathlib.Path(__file__).resolve().parent.parent / 'hag-claude-20261006/client-build-05/se_harness-0.22.2-py3-none-any.whl'
try:
    print(json.dumps({'identity': installed_client(wheel)}))
except Exception:
    traceback.print_exc()
    raise SystemExit(1)
