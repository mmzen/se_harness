"""Run dependent qualification stages once, retaining each outcome."""
import datetime,json,subprocess,sys,time
import hag221_execute as h
O=h.W/'hag-bounded-20261006'
groups={
    'prepare':[('hag_bounded_20261006.py','prepare'),('hag_bounded_sandbox_20261006.py','setup'),
               ('hag_bounded_sandbox_20261006.py','schema'),('hag_bounded_sandbox_20261006.py','wire')],
    'native':[('hag_bounded_native_20261006.py','walkthrough'),('hag_bounded_native_20261006.py','mcp'),
              ('hag_bounded_compare_20261006.py','mcp'),('hag_bounded_codex_20261006.py',),('hag_bounded_codex_compare_20261006.py',)],
    'qualify':[('hag_bounded_refusal_20261006.py',),
               *[('hag_bounded_sandbox_20261006.py',m) for m in ('history','imports','imported-bytes','boundaries','integrity','variants','receipt-inputs','time','recover')]]}
group=sys.argv[1]
for step in groups[group]:
    key=step[0].removesuffix('.py')+('-'+step[1] if len(step)>1 else '')
    record=O/('sequence-'+key+'.json');assert not record.exists(),record
    argv=[str(h.HOST),'-X','utf8','-B',str(h.W/step[0]),*step[1:]]
    start=time.monotonic();stamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
    print(json.dumps({'starting':key}),flush=True)
    result=subprocess.run(argv,cwd=h.W)
    h.write(record,{'argv':argv,'cwd':str(h.W),'observed_at':stamp,'exit':result.returncode,'seconds':round(time.monotonic()-start,3)})
    if result.returncode:raise SystemExit(result.returncode)
    print(json.dumps({'completed':key}),flush=True)
