"""Prepare and qualify one fresh final candidate graph; preserve older graphs."""
import json,os,sys,time,zipfile
import hag221_execute as h
O=h.W/'hag-final-20261006';h.O=O;P=O/'package'
combo=json.loads((P/'combination.json').read_text());project='hagfinal20261006'
assert combo['payload']['source']['candidate_commit']==json.loads((O/'candidate.json').read_text())['candidate']
env=dict(os.environ,HAG_SERVICE_IMAGE='harness-hag:final-06',HAG_HTTP_PORT='18090',HAG_SOURCE_VOLUME='hagphase220261005_source',
    HAG_CONFIG_DIRECTORY=str(P/'configuration'),HAG_CREDENTIAL_FILE=str(P/'credentials.json'))
compose=['docker','compose','-p',project,'-f',P/'candidate-source/server/compose.yaml']
def container(label,script,*args,python='python'):
    return h.run(label,compose+['run','--rm','--entrypoint',python,'-v',str(h.R/'tests/hosted_artifact_graph')+':/qualification:ro',
        '-v',str(O)+':/observations','service',*(['-I'] if python=='/opt/evaluator/bin/python' else []),'-B','/qualification/'+script,*args],env=env)
mode=sys.argv[1]
if mode=='setup':
    client=O/'client-environment';assert not client.exists()
    h.run('client-environment',[h.HOST,'-m','venv',client])
    h.run('client-install',[client/'Scripts/python.exe','-I','-m','pip','install','--no-deps','--no-index',O/'client-build/se_harness-0.22.2-py3-none-any.whl'])
    for host in ('codex','claude'):
        dest=O/'plugins'/host;assert not dest.exists()
        with zipfile.ZipFile(P/'plugin'/('verity-plane-'+host+'.zip')) as z:
            for name in z.namelist():
                assert name.startswith('verity-plane/') and '..' not in name.split('/'),name
                path=dest/name;assert path.resolve().is_relative_to(dest.resolve())
            z.extractall(dest)
    h.run('fresh-volume-absent',['docker','volume','inspect',project+'_graph_data'],allow=(1,))
    h.write(O/'sandbox-selection.json',{'compose_argv':list(map(str,compose)),'environment':{k:v for k,v in env.items() if k.startswith('HAG_')},'endpoint':'http://127.0.0.1:18090'})
    h.run('graph-up',compose+['up','-d','graph'],env=env)
    time.sleep(3)
    h.run('initialize',compose+['run','--rm','service','init'],env=env)
    h.run('service-up',compose+['up','-d','service'],env=env)
    time.sleep(2)
    h.run('ready',compose+['exec','-T','service','python','-m','hosted_artifact_graph','ready'],env=env)
    identity=h.run('service-identity',['docker','inspect','--format','{{json .}}',project+'-service-1'])
    assert identity['Image']==combo['payload']['server']['image_manifest']
    h.run('runtime-tests',['docker','run','--rm','--mount','type=bind,src='+str(h.R/'tests/hosted_artifact_graph')+',dst=/qualification,readonly',
        '--entrypoint','python','harness-hag:final-06','-m','unittest','discover','-s','/qualification','-p','test_runtime.py','-v'])
elif mode=='boundaries':
    container('live-boundaries','qualify_boundaries.py','--walkthrough','/observations/walkthrough','--output','/observations/boundaries')
elif mode=='history':
    container('independent-history','qualify_history.py','--source','/source/source','--manifest','/source/source-manifest.json',
        '--fixture','/qualification/fixtures/scenarios-v1.json','--hosted-result','/observations/walkthrough/005-work-context-result.json',
        '--output','/observations/history',python='/opt/evaluator/bin/python')
elif mode=='imports':
    container('import-fidelity','qualify_imports.py','--walkthrough','/observations/walkthrough','--output','/observations/imports')
elif mode=='time':
    container('read-time-bound','qualify_time.py')
elif mode=='integrity':
    results=list((O/'boundaries').glob('*-completed.json'));assert len(results)==1
    end='/observations/boundaries/'+results[0].name
    code='''import subprocess,sys
subprocess.run([sys.executable,"-m","venv","/tmp/candidate-client"],check=True)
subprocess.run(["/tmp/candidate-client/bin/python","-I","-m","pip","install","--no-deps","/observations/client-build/se_harness-0.22.2-py3-none-any.whl"],check=True)
subprocess.run([sys.executable,"-B","/qualification/qualify_integrity.py","--walkthrough","/observations/walkthrough","--continuation",END,"--output","/observations/integrity","--client-python","/tmp/candidate-client/bin/python"],check=True)
subprocess.run([sys.executable,"-B","/qualification/qualify_boundaries.py","--walkthrough","/observations/walkthrough","--continuation",END,"--output","/observations/lost-reply","--only","lost_reply","--client-python","/tmp/candidate-client/bin/python","--client-wheel","/observations/client-build/se_harness-0.22.2-py3-none-any.whl"],check=True)
'''.replace('END',repr(end))
    h.run('integrity-and-lost-reply',compose+['run','--rm','--entrypoint','python','-v',str(h.R/'tests/hosted_artifact_graph')+':/qualification:ro',
        '-v',str(O)+':/observations','service','-B','-c',code],env=env)
elif mode=='variants':
    helper=h.W/'hag-phase2-20261005/qualify_context_variant_v2.py'
    target=O/helper.name;assert not target.exists();target.write_bytes(helper.read_bytes())
    results=list((O/'lost-reply').glob('*-completed.json'));assert len(results)==1
    h.run('context-variants',compose+['run','--rm','--entrypoint','python','-v',str(h.R/'tests/hosted_artifact_graph')+':/qualification:ro',
        '-v',str(O)+':/observations','service','-B','/observations/'+helper.name,'--walkthrough','/observations/walkthrough',
        '--continuation','/observations/lost-reply/'+results[0].name,'--output','/observations/context-variants'],env=env)
elif mode=='recover':
    h.run('restart-restore',[h.HOST,'-B','-X','utf8',h.R/'server/scripts/qualify.py','recover','--compose',P/'candidate-source/server/compose.yaml',
        '--project',project,'--output',O/'recovery','--restore-port','18091'],env=env)
else:raise ValueError(mode)
