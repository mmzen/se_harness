"""Replay an observed server refusal through the unchanged installed client."""
import json, subprocess, sys, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hag221_execute as h
O=h.W/'hag-readable-20261006';h.O=O
observed=json.loads((O/'boundaries/001-malformed-toml.json').read_text())
wire=json.dumps(observed['result'],ensure_ascii=False,separators=(',',':')).encode()
class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        self.rfile.read(int(self.headers.get('Content-Length','0')))
        self.send_response(422);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(wire)));self.end_headers();self.wfile.write(wire)
    def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
code='''import json,sys
from se_harness.remote import send,TransportUncertain
try:
    status,result=send(sys.argv[1],"non-secret-test-placeholder","POST","/observed-refusal",{})
    print(json.dumps({"status":status,"result":result}))
except TransportUncertain as exc:
    print(json.dumps({"outcome":"unknown","message":str(exc)}))
'''
try:
    result=h.run('oversize-refusal-client-replay',[O/'client-environment/Scripts/python.exe','-I','-B','-c',code,'http://127.0.0.1:'+str(server.server_port)])
finally:
    server.shutdown();server.server_close()
assert result['outcome']=='unknown'
h.write(O/'oversize-refusal-analysis.json',{'source':'boundaries/001-malformed-toml.json','observed_server_status':422,'observed_server_code':observed['result']['error']['code'],'response_bytes':len(wire),'client_limit_bytes':2097152,'replay_scope':'Real retained service response replayed through installed candidate transport at local test server; not a new live hosted mutation.','observed_client_outcome':result,'finding':'Catalog parse refusal includes 1909 unrelated valid records, exceeding the installed client bound and hiding the specific invalidity.'})
print(json.dumps({'confirmed':'installed client reports unknown for observed invalid draft refusal','response_bytes':len(wire)}))
