"""Native Codex read test using normal reviewed permissions and exact candidate guidance."""
import datetime,json,os,re,subprocess,threading
import hag221_execute as h
O=h.W/'hag-bounded-20261006';N=O/'native-codex';N.mkdir(exist_ok=True)
dest=N/'mcp-session.json';assert not dest.exists()
requests=json.loads((O/'native-claude/project/mcp-requests.json').read_text())
h.write(N/'mcp-requests.json',requests)
plugin=O/'plugins/codex/verity-plane'
creds=json.loads((O/'package/credentials.json').read_text())
env=dict(os.environ,PYTHONUTF8='1',NO_COLOR='1',HAG_NATIVE_TEST_TOKEN=next(p['token'] for p in creds['principals'] if p['id']=='operator'))
prompt=('Test the user-authorized WO-HAG-001 private hosted sandbox through the actual configured hag MCP tools. '
    'Read the hosted sandbox sections of '+str(plugin/'skills/setup/SKILL.md')+' and '+str(plugin/'skills/harness-orient/SKILL.md')+'. '
    'The exact candidate uses plugin guidance 0.2.7, client 0.22.2, service 0.1.0.dev1 and public evaluator 0.22.1. '
    'Read '+str(N/'mcp-requests.json')+' and call each corresponding hag tool exactly once with the full unchanged JSON request. '
    'Keep project, view and budget inputs. These are read-only operations on public reference data in a private local test service. Authentication is configured outside the prompt. '
    'Report each operation, complete field, continuation/error and what the observed response supports. A checkpoint-free check reports context, not passed gates. '
    'Use normal tool approval review. If denied, retain the refusal and stop that operation; do not change settings or switch route. '
    'Do not run unrelated commands, edit files, inspect credentials, mutate the graph, install software, spawn agents, publish or perform lifecycle actions. '
    'Do not claim automatic candidate-plugin installation, desktop coverage or full qualification. The candidate guidance is explicitly read in this session.')
args=[r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe','--no-daemon','exec','--ephemeral','--skip-git-repo-check',
      '--json','-C',str(N),'--approve-for-me','-c','plugins."verity-plane@se-harness".enabled=false',
      '-c','mcp_servers.hag.url="http://127.0.0.1:18094/mcp"','-c','mcp_servers.hag.bearer_token_env_var="HAG_NATIVE_TEST_TOKEN"',
      '-c','mcp_servers.hag.required=true','-c','mcp_servers.hag.tool_timeout_sec=180',prompt]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();lines=[]
with subprocess.Popen(args,cwd=N,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',stdin=subprocess.DEVNULL) as child:
    timer=threading.Timer(900,child.kill);timer.start()
    try:
        for line in child.stdout:
            assert all(p['token'] not in line for p in creds['principals'])
            assert not re.search(r'sk-ant-(?:oat|ort|api)\S+',line)
            lines.append(line)
            try:e=json.loads(line)
            except ValueError:continue
            item=e.get('item',{})
            if e.get('type')=='item.completed':print(json.dumps({'type':item.get('type'),'tool':item.get('tool'),'status':item.get('status'),'text':item.get('text') if item.get('type')=='agent_message' else None}),flush=True)
        code=child.wait()
    finally:timer.cancel()
h.write(dest,{'argv':args,'cwd':str(N),'observed_at':started,'exit':code,'stdout':''.join(lines),
             'claim':'Native Codex read test with normal automatic review, explicit exact candidate guidance, no permanent plugin change.'})
raise SystemExit(code)
