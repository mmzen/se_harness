"""Qualify the bounded MCP formatting correction without changing read semantics."""
import json,sys
import hag221_execute as h
O=h.W/'hag-readable-20261006';O.mkdir(exist_ok=True);h.O=O
mode=sys.argv[1]
if mode=='focused':
    base=['docker','run','--rm','--mount','type=bind,src='+str(h.R/'tests/hosted_artifact_graph')+',dst=/qualification,readonly','--entrypoint','python']
    h.run('old-image-regression',base+['harness-hag:final-06','-m','unittest','discover','-s','/qualification','-p','test_runtime.py','-v'],allow=(1,))
    h.run('corrected-source-regression',base+['--mount','type=bind,src='+str(h.R/'server')+',dst=/candidate,readonly','harness-hag:final-06',
        '-c',"import sys,unittest;sys.path.insert(0,'/candidate');suite=unittest.defaultTestLoader.discover('/qualification',pattern='test_runtime.py');r=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(not r.wasSuccessful())"])
elif mode=='commit':
    paths=['server/hosted_artifact_graph/app.py','tests/hosted_artifact_graph/test_runtime.py']
    assert h.git('rev-parse','HEAD')=='9e0199480a40e7cd207c9f682bb17d66bf977513'
    assert sorted(h.git('diff','--name-only').splitlines())==sorted(paths)
    assert json.loads((O/'corrected-source-regression.json').read_text())['exit']==0
    h.run('diff-check',['git','diff','--check'],cwd=h.R)
    h.run('stage',['git','add','--',*paths],cwd=h.R)
    h.run('commit',['git','commit','-m','Keep saved MCP response metadata readable','-m','Harness-Work-Order: WO-HAG-001'],cwd=h.R)
    assert not h.git('status','--porcelain')
    h.write(O/'candidate.json',{'candidate':h.git('rev-parse','HEAD'),'previous_candidate':'9e0199480a40e7cd207c9f682bb17d66bf977513'})
elif mode=='build':
    candidate=json.loads((O/'candidate.json').read_text())['candidate']
    assert h.git('rev-parse','HEAD')==candidate and not h.git('status','--porcelain')
    args=json.loads((h.W/'hag-final-20261006/client-replay.json').read_text())['argv']
    for flag,value in {'--commit':candidate,'--output-directory':O/'client-build','--result':O/'client-replay-result.json'}.items():args[args.index(flag)+1]=str(value)
    h.run('client-replay',args,cwd=h.R)
elif mode=='prepare':
    args=json.loads((h.W/'hag-final-20261006/prepare-package.json').read_text())['argv']
    for flag,value in {'--output':O/'package','--client-wheel':O/'client-build/se_harness-0.22.2-py3-none-any.whl',
        '--client-replay':O/'client-replay-result.json','--image':'harness-hag:readable-07'}.items():args[args.index(flag)+1]=str(value)
    h.run('prepare-package',args)
elif mode=='source-checks':
    h.run('source-suite',[h.HOST,'-B','-X','utf8','scripts/run_tests.py'],cwd=h.R)
    h.run('distribution-checks',[h.HOST,'-B','-X','utf8','scripts/validate_release_distributions.py','--root','.'],cwd=h.R)
    h.run('cli-smoke',[h.HOST,'-B','-X','utf8','-m','se_harness','--help'],cwd=h.R)
    h.gov('released-validation','validate',new=True)
elif mode=='helpers':
    for name in ('sandbox','codex','codex_compare','compare','native'):
        source=h.W/('hag_final_'+name+'_20261006.py')
        text=source.read_text(encoding='utf-8').replace('hag-final-20261006','hag-readable-20261006').replace('hagfinal20261006','hagreadable20261006').replace('18090','18092').replace('18091','18093').replace('harness-hag:final-06','harness-hag:readable-07')
        if name=='native':
            start=text.index("    if mode=='mcp':\n        # Only one impact")
            end=text.index("    args+=['--mcp-config'",start)
            text=text[:start]+'''    prompt+=' Hosted setup is already complete: selected endpoint http://127.0.0.1:18092, token environment-variable name HAG_NATIVE_TEST_TOKEN, selected project/view in the requests, and readiness/component identity verified by the operator. Use the configured hag MCP tools directly; no CLI installation or setup action is needed. Only Read and ToolSearch are available. If a response is saved, use a bounded Read of that returned file to inspect its metadata. If content is unavailable, report unassessed rather than inferring completeness. Do not ask for shell tools or additional permissions.'
'''+text[end:]
        target=h.W/('hag_readable_'+name+'_20261006.py');assert not target.exists();h.write(target,text)
else:raise ValueError(mode)
