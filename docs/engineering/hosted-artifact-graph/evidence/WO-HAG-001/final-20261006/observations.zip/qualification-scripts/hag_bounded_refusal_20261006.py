"""Exercise malformed drafts through the exact installed client and live service."""
import base64,json,os,uuid
import hag221_execute as h
O=h.W/'hag-bounded-20261006';h.O=O
walk=json.loads((O/'walkthrough/walkthrough.json').read_text());assert walk['state']=='client_sequence_passed'
config=json.loads((O/'package/configuration/config.json').read_text())
creds=json.loads((O/'package/credentials.json').read_text())
env=dict(os.environ,HAG_REFUSAL_TOKEN=next(p['token'] for p in creds['principals'] if p['id']=='author-one'))
revised=json.loads(json.loads((O/'walkthrough/009-revise-body-and-relation-result.json').read_text())['stdout'])
binding=revised['affected_artifacts'][0]
original=json.loads((O/'walkthrough/009-revise-body-and-relation-request.json').read_text())
document=base64.b64decode(original['document_base64']).decode()
observations=[]
for label,raw in [('malformed-toml',document.replace('+++','+++\nbroken = [',1)),('duplicate-metadata',document.replace('+++','+++\nstatus = "draft"',1))]:
    request=dict(original,operation_key='refusal-'+str(uuid.uuid4()),expected_project_version=walk['project_version'],
                 expected_context_version=walk['context']['context_version'],expected_revision_id=binding['revision_id'],
                 document_base64=base64.b64encode(raw.encode()).decode())
    path=O/('live-cli-'+label+'-request.json');assert not path.exists();h.write(path,request)
    result=h.run('live-cli-'+label,[O/'client-environment/Scripts/python.exe','-I','-B','-m','se_harness','remote','revise-artifact',
        '--endpoint','http://127.0.0.1:18094','--project',config['project_id'],'--token-env','HAG_REFUSAL_TOKEN',
        '--client-wheel',O/'client-build/se_harness-0.22.2-py3-none-any.whl','--request',path,'--json'],env=env,allow=(1,))
    assert result['outcome']=='refused' and result['http_status']==422 and result['error']['code']=='HAG_REMOTE_INVALID_DRAFT'
    assert result['evaluator_output']['errors'] and result['evaluator_output']['artifacts']==[]
    encoded=json.dumps(result,ensure_ascii=False,separators=(',',':')).encode()
    assert len(encoded)<=2097152 and all(p['token'].encode() not in encoded for p in creds['principals'])
    observations.append({'case':label,'status':422,'code':result['error']['code'],'response_bytes':len(encoded),'specific_refusal_visible_to_installed_client':True})
h.write(O/'live-cli-refusal-assessment.json',observations)
print(json.dumps(observations))
