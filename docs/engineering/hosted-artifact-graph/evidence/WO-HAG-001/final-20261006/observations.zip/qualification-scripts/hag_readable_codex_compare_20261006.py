import json,urllib.request
import hag221_execute as h
O=h.W/'hag-readable-20261006';N=O/'native-codex'
record=json.loads((N/'mcp-session.json').read_text(encoding='utf-8'))
expected={r['operation']:r for r in json.loads((N/'mcp-requests.json').read_text(encoding='utf-8'))}
actual={};messages=[]
for line in record['stdout'].splitlines():
    try:e=json.loads(line)
    except ValueError:continue
    item=e.get('item',{})
    if e.get('type')!='item.completed':continue
    if item.get('type')=='agent_message':messages.append(item['text'])
    if item.get('type')!='mcp_tool_call' or item.get('server')!='hag':continue
    op=item['tool'];assert op not in actual and item['arguments']==expected[op]
    assert item['status']=='completed' and not item.get('error') and not item['result'].get('isError')
    actual[op]=json.loads(item['result']['content'][0]['text'])
assert record['exit']==0 and set(actual)==set(expected)
creds=json.loads((O/'package/credentials.json').read_text());token=next(p['token'] for p in creds['principals'] if p['id']=='operator')
results=[]
for op,request in expected.items():
    req=urllib.request.Request('http://127.0.0.1:18092/v1/projects/'+request['project_id']+'/reads/'+op,data=json.dumps(request).encode(),headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=180) as response:http=json.load(response)
    assert http==actual[op],op
    results.append({'request':request,'http':http,'native_mcp':actual[op],'equal':True})
value={'comparisons':results,'native_messages':messages};raw=json.dumps(value);assert all(p['token'] not in raw for p in creds['principals'])
dest=N/'http-mcp-comparison.json';assert not dest.exists();h.write(dest,value)
print(json.dumps({'comparisons':len(results),'equal':True}))
