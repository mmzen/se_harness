"""Retain actual native Claude responses and compare the unchanged HTTP view."""
import datetime,hashlib,json,re,sys,urllib.request
from pathlib import Path
import hag221_execute as h
O=h.W/'hag-bounded-20261006';mode=sys.argv[1]
assert mode in ('mcp','limited')
N=O/('native-claude' if mode=='mcp' else 'native-claude-limited')
record=json.loads((N/(mode+'-session.json')).read_text())
events=[]
for line in record['stdout'].splitlines():
    try:events.append(json.loads(line))
    except ValueError:pass
expected={r['operation']:r for r in json.loads((N/'project'/(mode+'-requests.json')).read_text())}
uses={};actual={};spills=[];helper_results=[]
for event in events:
    for block in event.get('message',{}).get('content',[]) if isinstance(event.get('message'),dict) else []:
        if not isinstance(block,dict):continue
        if block.get('type')=='tool_use':uses[block['id']]=block
        if block.get('type')!='tool_result':continue
        use=uses.get(block.get('tool_use_id'),{})
        if use.get('name')=='Bash':helper_results.append({'invocation':use,'result':block})
        if not use.get('name','').startswith('mcp__hag__'):continue
        op=use['input']['operation'];assert use['input']==expected[op]
        content=block['content']
        if isinstance(content,str):
            found=re.search(r'Output has been saved to (.+?\.txt)',content);assert found,content[:200]
            file=Path(found.group(1));root=Path(r'C:\Users\mathi\.claude\projects')/re.sub(r'[^A-Za-z0-9]','-',str(N/'project'))
            assert file.resolve().is_relative_to(root.resolve()) and file.stat().st_size<4194304
            raw=file.read_bytes();content=json.loads(raw)
            dest=N/(mode+'-impact-spill.json')
            if dest.exists():assert dest.read_bytes()==raw
            else:dest.write_bytes(raw)
            spills.append({'operation':op,'source':str(file),'retained':dest.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
        if isinstance(content,list):
            assert len(content)==1 and content[0]['type']=='text'
            value=json.loads(content[0]['text'])
        else:
            assert isinstance(content,dict)
            value=content
        assert value['operation']==op and not value['unresolved_references']
        assert op not in actual;actual[op]=value
        assert value['complete'] is (op!='impact')
        if op=='impact':assert value['continuation']['reason']=='row_limit'
assert set(actual)==set(expected) and record['exit']==0
final=next(e for e in events if e.get('type')=='result');assert not final['is_error']
creds=json.loads((O/'package/credentials.json').read_text())
token=next(p['token'] for p in creds['principals'] if p['id']=='operator')
comparisons=[]
for op,request in expected.items():
    url='http://127.0.0.1:18094/v1/projects/'+request['project_id']+'/reads/'+op
    req=urllib.request.Request(url,data=json.dumps(request).encode(),headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=180) as response:http=json.load(response);status=response.status
    equal=status==200 and http==actual[op]
    comparisons.append({'request':request,'http_status':status,'http':http,'native_mcp':actual[op],'equal':equal})
    print(json.dumps({'operation':op,'equal':equal,'complete':actual[op]['complete']}),flush=True)
value={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'comparisons':comparisons,'host_spills':spills,
       'helper_results':helper_results,'model_final':final,'claim':'Exact transport comparison. Native reporting is assessed from retained tool use, results and final text; reading by this comparison does not establish reading by the model.'}
raw=json.dumps(value,ensure_ascii=False);assert all(p['token'] not in raw for p in creds['principals'])
dest=N/(mode+'-http-comparison.json');assert not dest.exists();h.write(dest,value)
assert all(item['equal'] for item in comparisons)
