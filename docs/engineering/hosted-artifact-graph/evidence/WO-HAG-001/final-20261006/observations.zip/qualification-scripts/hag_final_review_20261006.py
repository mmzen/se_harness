"""Bounded final assessment and released lifecycle preparation; never verifies."""
import hashlib,json,re,sys,zipfile
import hag221_execute as h
h.O=h.W/'hag-bounded-20261006'
E=h.D+'evidence/WO-HAG-001/final-20261006/'
PRODUCT='21d268664ffeb111b8b9e9e94921073c7bc99ec1'
WOS=('WO-HAG-001','WO-HAG-007')
def changed():
    return h.git('diff','--name-only').splitlines()+h.git('ls-files','--others','--exclude-standard').splitlines()
def allowed(p):
    return p.startswith(E) or p in [h.D+'README.md','docs/notes/hosted-artifact-graph.md',*[h.D+'work-orders/'+w+'.md' for w in WOS],*[h.D+'evidence/'+w+'/'+w+'-handoff.md' for w in WOS]]
def inventory():
    root=h.R/E;v=json.loads((root/'inventory.json').read_text())
    assert hashlib.sha256((root/'observations.zip').read_bytes()).hexdigest()==v['sha256']
    with zipfile.ZipFile(root/'observations.zip') as z:
        assert set(z.namelist())=={f['path'] for f in v['files']}
        for f in v['files']:
            b=z.read(f['path']);assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
    return v
def body(head='REVIEW_HEAD_PENDING',vrec=None,candidate=None):
    prior=json.loads(json.loads((h.O/'review-before-publication.json').read_text())['stdout'])['body']
    earlier=prior[prior.index('## Earlier result — prerequisite reconciliation verified'):]
    url='https://github.com/mmzen/se_harness/blob/'+head+'/'
    records=(f'Ready record: [{vrec}]({url}{h.D}verification-records/{vrec}.md). Assurance candidate: `{candidate}`.\n\n' if vrec else 'The completed observations are being processed through the released completion and verification-capture procedure. No ready record is claimed at this preparation step.\n\n')
    return '''Harness-Work-Orders: WO-HAG-001, WO-HAG-003, WO-HAG-004, WO-HAG-005, WO-HAG-006, WO-HAG-007

## Current result — Phase 2 sandbox qualified; verification pending

The sandbox retrieves the agreed work context, creates and revises drafts against an immutable baseline, refuses invalid or stale requests, and recovers accepted writes after a lost reply. All twelve VER-HAG-001 scenarios have observed evidence for product candidate `21d268664ffeb111b8b9e9e94921073c7bc99ec1`: client 0.22.2, plugin 0.2.7, service 0.1.0.dev1, and isolated public evaluator 0.22.1. No public release is claimed.

Claude completed the packaged 18-operation guided walkthrough. Codex and Claude each exercised all seven native MCP reads; every response matched HTTP. Tests also cover all 1,909 original imported documents, real concurrent writes, stale dependencies, rollback, operation-key conflicts, and consistent restart/restore. Source checks report 1,319 tests with 23 skips; seven installed runtime tests and 60 schema checks pass. Skips remain unperformed coverage.

Two final corrections make saved MCP output readable in bounded file reads and prevent malformed-draft errors from exceeding the installed client's response bound. Original failures and regressions are retained. Native model prose contains some inaccurate labels/counts; the assessment uses exact commands and responses, and identifies the discrepancies.

**Verification pending.** Human acceptance and merge remain separate. RISK-HAG-001 remains raised: application controls do not prove database-enforced read-only access. Automatic Codex candidate-plugin loading, startup/compaction and desktop were not exercised. This guided private-sandbox result does not qualify hosted human decisions, production, public deployment or authority cutover.

'''+records+f'[Assessment and scenario matrix]({url}{E}report.md) · [component identities]({url}{E}combination.json) · [raw observations]({url}{E}observations.zip) · [evidence inventory]({url}{E}inventory.json)\n\n'+f'Review head: `{head}`. Preserve draft PR #535, target `codex/hosted-artifact-graph-inputs`, and original comparison base `{h.B}`. Prior published head `690b19de1128eba7bec4245fd23fd29c057f8d22` had 13 successful and two skipped CI checks; new-head CI is pending at publication. Historical VREC-HAG-001/002/003 bindings are unchanged.\n\n'+earlier
def event(head='REVIEW_HEAD_PENDING',vrec=None,candidate=None):
    value=body(head,vrec,candidate)
    h.write(h.O/'proposed-pr-body.md',value)
    h.write(h.O/'proposed-pr-event.json',{'pull_request':{'body':value}})
    return h.O/'proposed-pr-event.json'
def completion_args():
    a=['transition']
    for wo in WOS:
        a+=['--set',wo+'=implemented','--decision',wo+'=Codex','--reason',wo+'=Completed the approved Phase 2 private sandbox and supporting correction. Final product candidate '+PRODUCT+' has all twelve VER-HAG-001 scenarios observed, with actual native CLI, transaction and restart/restore evidence. Historical failures and raised RISK-HAG-001 remain retained. This records implementation completion only; human verification remains separate.']
    return a
mode=sys.argv[1] if __name__=='__main__' else None
if mode=='check':
    inventory();assert h.git('rev-parse','HEAD')==PRODUCT
    assert changed() and all(allowed(p) for p in changed()),changed()
    h.run('final-retention-diff-check',['git','diff','--check'],cwd=h.R)
    h.gov('final-retention-validation','validate',new=True)
    for wo in WOS:h.gov('final-review-'+wo,'preflight','--work-order',wo,'--phase','review',new=True)
    h.gov('final-combined-pr-check','check-pr','--event',event(),'--from-git',h.B,new=True,allow=(0,1,2))
elif mode=='rebind':
    inventory()
    for wo in WOS:h.gov('final-supported-rebind-'+wo,'evidence','--artifact',wo,'--checkpoint','handoff',new=True)
    h.gov('final-combined-pr-recheck','check-pr','--event',event(),'--from-git',h.B,new=True)
elif mode=='retain-checks':
    root=h.R/E;dest=root/'observations.zip';inventory()
    with zipfile.ZipFile(dest) as z:entries={n:z.read(n) for n in z.namelist()}
    labels=['final-retention-diff-check','final-retention-validation',*['final-review-'+wo for wo in WOS],'final-combined-pr-check',*['final-supported-rebind-'+wo for wo in WOS],'final-combined-pr-recheck']
    for label in labels:
        p=h.O/(label+'.json')
        if p.exists():
            key='review-checks/'+p.name;assert key not in entries;entries[key]=p.read_bytes()
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(entries.items()):
            info=zipfile.ZipInfo(name,(2026,10,6,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,raw)
    inv=json.loads((root/'inventory.json').read_text());inv.update(sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),bytes=dest.stat().st_size,files=[{'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in sorted(entries.items())]);h.write(root/'inventory.json',inv)
    h.gov('final-combined-handoff','check-pr','--event',event(),'--from-git',h.B,new=True)
elif mode=='complete-preview':
    inventory();assert json.loads((h.O/'final-combined-handoff.json').read_text())['exit']==0
    assert all(h.record(h.D+'work-orders/'+wo+'.md')['status']=='in_progress' for wo in WOS)
    h.gov('final-completion-preview',*completion_args(),new=True)
elif mode=='complete-apply':
    inventory();assert json.loads((h.O/'final-completion-preview.json').read_text())['exit']==0
    assert all(h.record(h.D+'work-orders/'+wo+'.md')['status']=='in_progress' for wo in WOS)
    h.gov('final-completion-apply',*completion_args(),'--apply',new=True)
    for wo in WOS:
        assert h.record(h.D+'work-orders/'+wo+'.md')['status']=='implemented'
        h.gov('final-completed-'+wo,'check','--artifact',wo,new=True)
elif mode=='candidate':
    inventory();assert h.git('rev-parse','HEAD')==PRODUCT
    assert all(h.record(h.D+'work-orders/'+wo+'.md')['status']=='implemented' for wo in WOS)
    files=changed();assert all(allowed(p) for p in files),files
    assert not h.git('diff','--cached','--name-only')
    h.run('final-evidence-stage',['git','add','--',*files],cwd=h.R)
    assert set(h.git('diff','--cached','--name-only').splitlines())==set(files)
    h.run('final-evidence-commit',['git','commit','-m','Retain complete hosted sandbox qualification','-m','Harness-Work-Orders: WO-HAG-001, WO-HAG-007'],cwd=h.R)
    candidate=h.git('rev-parse','HEAD');assert not h.git('status','--porcelain')
    diff=h.git('diff','--name-only',PRODUCT,candidate).splitlines();assert all(allowed(p) for p in diff)
    h.write(h.O/'assurance-candidate.json',{'candidate':candidate,'product_candidate':PRODUCT,'changed_paths':diff,'reason':'Only assessed evidence, index/guide updates, generated handoff packets and implementation-completion events differ. Product bytes are unchanged.'})
elif mode=='allocate':
    assert not h.git('status','--porcelain')
    refs=h.git('for-each-ref','--format=%(refname)').splitlines();ids=set()
    for ref in refs:ids.update(re.findall(r'(?m)(VREC-HAG-\d{3})\.md$',h.git('ls-tree','-r','--name-only',ref,'--','docs/engineering')))
    ids.update(p.stem for p in (h.R/h.D/'verification-records').glob('VREC-HAG-*.md'))
    ident=next('VREC-HAG-%03d'%n for n in range(1,1000) if 'VREC-HAG-%03d'%n not in ids)
    files=[E+n for n in ('report.md','observations.zip','inventory.json','combination.json','continuation.json')]
    files += [str(p.relative_to(h.R)).replace('\\','/') for p in sorted((h.R/h.D/'evidence/WO-HAG-007').iterdir()) if p.is_file()]
    files += [h.D+'evidence/WO-HAG-001/WO-HAG-001-handoff.md']
    h.write(h.O/'final-vrec-allocation.json',{'id':ident,'checked_refs':refs,'existing_ids':sorted(ids),'evidence_files':files,'record_path':h.D+'verification-records/'+ident+'.md','evaluator_path':h.D+'evidence/'+ident+'-evaluator.json'})
    print(json.dumps({'selected':ident,'evidence_files':files}))
elif mode=='capture':
    inventory();a=json.loads((h.O/'final-vrec-allocation.json').read_text());candidate=json.loads((h.O/'assurance-candidate.json').read_text())['candidate']
    assert h.git('rev-parse','HEAD')==candidate and not h.git('status','--porcelain')
    assert not (h.R/a['record_path']).exists() and not (h.R/a['evaluator_path']).exists()
    args=['capture-verification','--id',a['id']]
    for wo in WOS:args+=['--work-order',wo]
    args+=['--verification','VER-HAG-001']
    for p in a['evidence_files']:args+=['--evidence',p]
    h.gov('final-verification-capture',*args,'--owner','Codex','--domain','hosted-artifact-graph',new=True)
    record=h.record(a['record_path']);assert record['status']=='ready'
    h.gov('final-ready-context','check','--artifact',a['id'],new=True)
elif mode is not None:raise ValueError(mode)
