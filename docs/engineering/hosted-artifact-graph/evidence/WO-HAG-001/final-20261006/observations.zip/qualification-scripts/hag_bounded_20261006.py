"""Build and qualify the parser-refusal correction as a distinct exact tuple."""
import json,sys
import hag221_execute as h
O=h.W/'hag-bounded-20261006';O.mkdir(exist_ok=True);h.O=O
prior=h.W/'hag-readable-20261006'
mode=sys.argv[1]
if mode=='commit':
    paths=['server/hosted_artifact_graph/evaluator_bridge.py','tests/hosted_artifact_graph/test_runtime.py']
    assert h.git('rev-parse','HEAD')=='b55d096a510a5517addd69f504922438bf03b1e0'
    assert sorted(h.git('diff','--name-only').splitlines())==sorted(paths)
    assert json.loads((prior/'catalog-refusal-regression-after.json').read_text())['exit']==0
    h.run('diff-check',['git','diff','--check'],cwd=h.R)
    h.run('stage',['git','add','--',*paths],cwd=h.R)
    h.run('commit',['git','commit','-m','Keep parser refusals readable by the bounded client','-m','Harness-Work-Order: WO-HAG-001'],cwd=h.R)
    assert not h.git('status','--porcelain')
    h.write(O/'candidate.json',{'candidate':h.git('rev-parse','HEAD'),'previous_candidate':'b55d096a510a5517addd69f504922438bf03b1e0'})
elif mode=='build':
    candidate=json.loads((O/'candidate.json').read_text())['candidate']
    assert h.git('rev-parse','HEAD')==candidate and not h.git('status','--porcelain')
    args=json.loads((prior/'client-replay.json').read_text())['argv']
    for flag,value in {'--commit':candidate,'--output-directory':O/'client-build','--result':O/'client-replay-result.json'}.items():args[args.index(flag)+1]=str(value)
    h.run('client-replay',args,cwd=h.R)
elif mode=='prepare':
    args=json.loads((prior/'prepare-package.json').read_text())['argv']
    for flag,value in {'--output':O/'package','--client-wheel':O/'client-build/se_harness-0.22.2-py3-none-any.whl','--client-replay':O/'client-replay-result.json','--image':'harness-hag:bounded-08'}.items():args[args.index(flag)+1]=str(value)
    h.run('prepare-package',args)
elif mode=='source-checks':
    h.run('source-suite',[h.HOST,'-B','-X','utf8','scripts/run_tests.py'],cwd=h.R)
    h.run('distribution-checks',[h.HOST,'-B','-X','utf8','scripts/validate_release_distributions.py','--root','.'],cwd=h.R)
    h.run('cli-smoke',[h.HOST,'-B','-X','utf8','-m','se_harness','--help'],cwd=h.R)
    h.gov('released-validation','validate',new=True)
elif mode=='helpers':
    for name in ('sandbox','codex','codex_compare','compare','native'):
        source=h.W/('hag_readable_'+name+'_20261006.py')
        value=source.read_text(encoding='utf-8').replace('hag-readable-20261006','hag-bounded-20261006').replace('hagreadable20261006','hagbounded20261006').replace('hagreadableschema20261006','hagboundedschema20261006').replace('18092','18094').replace('18093','18095').replace('harness-hag:readable-07','harness-hag:bounded-08')
        target=h.W/('hag_bounded_'+name+'_20261006.py');assert not target.exists();h.write(target,value)
    for name in ('qualify_imported_bytes.py','qualify_receipt_inputs.py'):
        assert not (O/name).exists();(O/name).write_bytes((prior/name).read_bytes())
else:raise ValueError(mode)
