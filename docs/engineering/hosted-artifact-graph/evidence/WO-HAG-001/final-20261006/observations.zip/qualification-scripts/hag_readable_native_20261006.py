"""Native Claude observations of the exact packaged final candidate."""
import datetime,hashlib,json,os,re,shlex,subprocess,sys,threading,zipfile
import hag221_execute as h
O=h.W/'hag-readable-20261006';P=O/'package';mode=sys.argv[1]
assert mode in ('walkthrough','mcp','limited')
N=O/('native-claude-limited' if mode=='limited' else 'native-claude');N.mkdir(exist_ok=True)
project=N/'project';project.mkdir(exist_ok=True)
plugin=O/'plugins/claude/verity-plane'
combo=json.loads((P/'combination.json').read_text());candidate=json.loads((O/'candidate.json').read_text())['candidate']
assert combo['payload']['source']['candidate_commit']==candidate
creds=json.loads((P/'credentials.json').read_text());secrets=[p['token'] for p in creds['principals']]
dest=N/(mode+'-session.json');assert not dest.exists()
archive=P/'plugin/verity-plane-claude.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==combo['payload']['plugins']['claude']['archive_sha256']
with zipfile.ZipFile(archive) as z:
    assert all((plugin/n.removeprefix('verity-plane/')).read_bytes()==z.read(n) for n in z.namelist() if not n.endswith('/'))
args=[r'C:\Users\mathi\.local\bin\claude.exe','--plugin-dir',str(plugin),'-p','--model','claude-haiku-4-5-20251001','--no-session-persistence']
env=dict(os.environ,CLAUDE_CONFIG_DIR=r'C:\Users\mathi\.claude',PYTHONUTF8='1',NO_COLOR='1')
prefix='The user authorized continuing WO-HAG-001 hosted qualification. Use the exact session-loaded plugin guidance 0.2.7; candidate client 0.22.2 and service 0.1.0.dev1 are separate from the released governor and service evaluator 0.22.1. '
limits=(' Do not read authentication/credential files or environment values, edit or install anything, spawn agents, change permissions, perform lifecycle actions, publish or expose the service. '
    'If a tool is denied, report that refusal and do not switch route or weaken controls. Report observed results and limits only. Do not claim desktop, release or complete qualification.')
if mode=='walkthrough':
    assert not (O/'walkthrough').exists()
    commands=json.loads((h.W/'hag-phase2-20261005/protocol04-walkthrough.json').read_text())['argv']
    for flag,value in {'--client-python':O/'client-environment/Scripts/python.exe','--client-wheel':O/'client-build/se_harness-0.22.2-py3-none-any.whl',
        '--configuration':P/'configuration/config.json','--credentials':P/'credentials.json','--endpoint':'http://127.0.0.1:18092','--output':O/'walkthrough'}.items():commands[commands.index(flag)+1]=str(value)
    entry=project/'run_walkthrough.py';assert not entry.exists()
    h.write(entry,'import subprocess,sys\nargs='+repr(commands)+'\np=subprocess.run(args,cwd='+repr(str(O))+')\nsys.exit(p.returncode)\n')
    command=shlex.quote(h.HOST.as_posix())+' -B run_walkthrough.py'
    prompt=prefix+'Read '+str(plugin/'skills/setup/SKILL.md')+' and '+str(plugin/'skills/change/SKILL.md')+' and the inspected launcher '+str(entry)+'. '
    prompt+='The exact private service is already ready at http://127.0.0.1:18092 with a fresh graph and public fixture data. Run exactly once through Bash: '+command+'. Allow 600000 ms and wait for completion. '
    prompt+='Then read '+str(O/'walkthrough/walkthrough.json')+' and relevant retained results to report actual assertions. Expected refusal exits are part of the test. A checkpoint-free check does not evaluate gates; freeze creates a baseline, not lifecycle approval. Do not run other shell commands or invent timing totals.'+limits
    args+=['--tools','Read,Bash','--allowedTools','Read','Bash('+command+')']
else:
    walk=json.loads((O/'walkthrough/walkthrough.json').read_text());assert walk['state']=='client_sequence_passed'
    revised=json.loads(json.loads((O/'walkthrough/009-revise-body-and-relation-result.json').read_text())['stdout'])
    config=json.loads((P/'configuration/config.json').read_text())
    baseline=walk['baseline'];context=walk['context'];binding=revised['affected_artifacts'][0]
    def request(op,view=baseline,**kw):return dict(schema='se-harness-graph-read/v1',project_id=config['project_id'],operation=op,view=view,budget={'rows':500,'bytes':2097152,'depth':8},**kw)
    requests=[request('revision',context,**binding),request('work-context',work_order_id='WO-RLS-038'),
        request('compare',{'kind':'comparison','left':baseline,'right':context}),request('impact',artifact_id='CAP-IAR-002'),
        request('lineage',artifact_id='VREC-RLS-002'),request('check',artifact_id='WO-RLS-038'),
        request('cypher',query='MATCH (r:Revision) WHERE r.artifact_id = $id RETURN r.artifact_id AS id LIMIT 5',parameters={'id':'WO-RLS-038'})]
    if mode=='limited':requests=[requests[3]]
    selected=project/(mode+'-requests.json');assert not selected.exists();h.write(selected,requests)
    mcp=N/(mode+'-config.json');assert not mcp.exists()
    h.write(mcp,{'mcpServers':{'hag':{'type':'http','url':'http://127.0.0.1:18092/mcp','headers':{'Authorization':'Bearer ${HAG_NATIVE_TEST_TOKEN}'},'timeout':180000}}})
    env['HAG_NATIVE_TEST_TOKEN']=next(p['token'] for p in creds['principals'] if p['id']=='operator')
    prompt=prefix+'Read the hosted sandbox sections of '+str(plugin/'skills/setup/SKILL.md')+' and '+str(plugin/'skills/harness-orient/SKILL.md')+'. '
    prompt+='Read '+str(selected)+' and use the actual configured hag MCP tools to submit each unchanged request once. Keep exact views and budgets. Report each result, completeness, continuation/error and what it supports. A checkpoint-free check reports lifecycle context, not passed gates. '+limits
    tools=['Read','ToolSearch'];allowed=['Read','ToolSearch',*[f"mcp__hag__{r['operation']}" for r in requests]]
    prompt+=' Hosted setup is already complete: selected endpoint http://127.0.0.1:18092, token environment-variable name HAG_NATIVE_TEST_TOKEN, selected project/view in the requests, and readiness/component identity verified by the operator. Use the configured hag MCP tools directly; no CLI installation or setup action is needed. Only Read and ToolSearch are available. If a response is saved, use a bounded Read of that returned file to inspect its metadata. If content is unavailable, report unassessed rather than inferring completeness. Do not ask for shell tools or additional permissions.'
    args+=['--mcp-config',str(mcp),'--strict-mcp-config','--tools',','.join(tools),'--allowedTools',*allowed]
args+=['--output-format','stream-json','--verbose',prompt]
started=datetime.datetime.now(datetime.timezone.utc).isoformat();lines=[]
with subprocess.Popen(args,cwd=project,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace') as child:
    timer=threading.Timer(900,child.kill);timer.start()
    try:
        for line in child.stdout:
            assert all(secret not in line for secret in secrets)
            assert not re.search(r'sk-ant-(?:oat|ort|api)\S+',line)
            lines.append(line)
            try:e=json.loads(line)
            except ValueError:continue
            if e.get('type')=='system' and e.get('subtype')=='init':print(json.dumps({'event':'native_init','model':e.get('model'),'plugins':e.get('plugins'),'mcp_servers':e.get('mcp_servers')}),flush=True)
            for b in e.get('message',{}).get('content',[]) if isinstance(e.get('message'),dict) else []:
                if isinstance(b,dict) and b.get('type')=='tool_use':print(json.dumps({'event':'tool_use','tool':b.get('name')}),flush=True)
            if e.get('type')=='result':print(json.dumps({'event':'result','is_error':e.get('is_error'),'result':e.get('result')}),flush=True)
        code=child.wait()
    finally:timer.cancel()
h.write(dest,{'argv':args,'cwd':str(project),'observed_at':started,'exit':code,'stdout':''.join(lines),
    'candidate':candidate,'combination_id':combo['combination_id'],'claim':'Actual native Claude with session-loaded exact candidate plugin; normal credential store, no permanent installation.'})
print(json.dumps({'record':str(dest),'exit':code}),flush=True)
raise SystemExit(code)
