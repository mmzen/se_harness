"""Continue approved HAG qualification; retain failures and exact identities."""
import json,os,sys
import hag221_execute as h
O=h.W/'hag-final-20261006';O.mkdir(exist_ok=True);h.O=O
mode=sys.argv[1]
paths=['plugins/verity-plane/common/skills/harness-orient/SKILL.md',h.D+'README.md','docs/notes/hosted-artifact-graph.md',
       h.D+'evidence/WO-HAG-001/WO-HAG-001-handoff.md']
paths += [h.D+'evidence/WO-HAG-001/final-20261006/'+n for n in ('report.md','observations.zip','inventory.json','combination.json','continuation.json')]
if mode=='scope':
    assert h.git('rev-parse','HEAD')=='690b19de1128eba7bec4245fd23fd29c057f8d22' and not h.git('status','--porcelain')
    h.gov('current-context','check','--artifact','WO-HAG-001',new=True)
    h.write(O/'planned-paths.json',paths)
    args=['check','--artifact','WO-HAG-001','--checkpoint','scope','--changes-complete']
    for path in paths:args+=['--changed-path',path]
    h.gov('implementation-scope',*args,new=True)
elif mode=='commit':
    assert h.git('diff','--name-only').splitlines()==[paths[0]]
    h.run('guidance-diff-check',['git','diff','--check'],cwd=h.R)
    h.run('guidance-focused-checks',[h.HOST,'-B','-X','utf8','-m','unittest','discover','-s','tests/plugin_integration','-p','test_simple_plugin.py'],cwd=h.R)
    h.run('guidance-stage',['git','add','--',paths[0]],cwd=h.R)
    h.run('guidance-commit',['git','commit','-m','Require inspection of saved hosted read responses','-m','Harness-Work-Order: WO-HAG-001'],cwd=h.R)
    assert not h.git('status','--porcelain')
    h.write(O/'candidate.json',{'candidate':h.git('rev-parse','HEAD'),'previous_candidate':'5fa50787dba1fdd010f625335d844416dd3bf002'})
elif mode=='build':
    candidate=json.loads((O/'candidate.json').read_text())['candidate']
    assert h.git('rev-parse','HEAD')==candidate and not h.git('status','--porcelain')
    args=json.loads((h.W/'hag-claude-20261006/client-replay-05.json').read_text())['argv']
    for flag,value in {'--commit':candidate,'--output-directory':O/'client-build','--result':O/'client-replay-result.json'}.items():args[args.index(flag)+1]=str(value)
    h.run('client-replay',args,cwd=h.R)
elif mode=='prepare':
    args=json.loads((h.W/'hag-claude-20261006/prepare-package-05.json').read_text())['argv']
    for flag,value in {'--output':O/'package','--client-wheel':O/'client-build/se_harness-0.22.2-py3-none-any.whl',
                       '--client-replay':O/'client-replay-result.json','--image':'harness-hag:final-06'}.items():args[args.index(flag)+1]=str(value)
    h.run('prepare-package',args)
elif mode=='source-checks':
    h.run('source-suite',[h.HOST,'-B','-X','utf8','scripts/run_tests.py'],cwd=h.R)
    h.run('distribution-checks',[h.HOST,'-B','-X','utf8','scripts/validate_release_distributions.py','--root','.'],cwd=h.R)
    h.run('cli-smoke',[h.HOST,'-B','-X','utf8','-m','se_harness','--help'],cwd=h.R)
    h.gov('released-validation','validate',new=True)
else:raise ValueError(mode)
