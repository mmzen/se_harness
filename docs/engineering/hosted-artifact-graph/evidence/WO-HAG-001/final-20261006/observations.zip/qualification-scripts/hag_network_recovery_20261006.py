"""Release only completed task-owned networks; preserve all named data volumes."""
import json,os
import hag221_execute as h
h.O=h.W/'hag-bounded-20261006'
for folder,project in [('hag-readable-20261006','hagreadable20261006'),('hag-final-20261006','hagfinal20261006')]:
    root=h.W/folder
    selection=json.loads((root/'sandbox-selection.json').read_text())
    args=selection['compose_argv'];assert args[:4]==['docker','compose','-p',project]
    assert args[4]=='-f' and str((root/'package/candidate-source/server/compose.yaml').resolve())==str(__import__('pathlib').Path(args[5]).resolve())
    for surface in ('private','client'):
        data=h.run(project+'-'+surface+'-network-before',['docker','network','inspect',project+'_'+surface])
        assert data[0]['Labels']['com.docker.compose.project']==project
    before=h.run(project+'-volume-before',['docker','volume','inspect',project+'_graph_data'])
    assert before[0]['Labels']['com.docker.compose.project']==project
    h.run(project+'-retire-containers-and-networks',args+['down'],env=dict(os.environ,**selection['environment']))
    after=h.run(project+'-volume-preserved',['docker','volume','inspect',project+'_graph_data'])
    assert before==after
print(json.dumps({'retired_projects':['hagreadable20261006','hagfinal20261006'],'named_volumes_preserved':True,'images_and_evidence_preserved':True}))
