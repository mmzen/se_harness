"""Resume only the schema probe that Docker never started."""
import json,os,subprocess
import hag221_execute as h
O=h.W/'hag-bounded-20261006';h.O=O
failed=json.loads((O/'stored-schema-boundaries.json').read_text())
assert failed['exit']==1 and 'all predefined address pools have been fully subnetted' in failed['stderr']
selection=json.loads((O/'sandbox-selection.json').read_text())
env=dict(os.environ,**selection['environment'])
h.run('stored-schema-boundaries-retry',failed['argv'],env=env)
compose=failed['argv'][:6]
assert compose[:4]==['docker','compose','-p','hagboundedschema20261006']
h.run('schema-graph-stop',compose+['stop','graph'],env=env)
subprocess.run([str(h.HOST),'-X','utf8','-B',str(h.W/'hag_bounded_sandbox_20261006.py'),'wire'],cwd=h.W,check=True)
