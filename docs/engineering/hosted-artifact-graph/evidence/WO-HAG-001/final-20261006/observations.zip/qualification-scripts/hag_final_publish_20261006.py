"""Prepare/publish only the granted ready review package; no acceptance or merge."""
import hashlib,json,subprocess,sys
import hag_final_review_20261006 as review
h=review.h
a=json.loads((h.O/'final-vrec-allocation.json').read_text())
candidate=json.loads((h.O/'assurance-candidate.json').read_text())['candidate']
fields='url,headRefOid,headRefName,baseRefName,isDraft,body,state,statusCheckRollup'
def current(label):
    v=h.run(label,['gh','pr','view','535','--repo','mmzen/se_harness','--json',fields])
    assert v['headRefName']=='codex/hosted-artifact-phase1' and v['baseRefName']=='codex/hosted-artifact-graph-inputs'
    assert v['isDraft'] and v['state']=='OPEN'
    return v
mode=sys.argv[1]
if mode=='prepare':
    assert h.git('rev-parse','HEAD')==candidate
    files=review.changed();assert set(files)=={a['record_path'],a['evaluator_path']},files
    record=h.record(a['record_path']);assert record['status']=='ready'
    h.run('ready-record-diff-check',['git','diff','--check'],cwd=h.R)
    h.gov('ready-record-validation','validate',new=True)
    h.gov('ready-record-publish-preflight','check','--artifact',a['id'],'--checkpoint','pre-action','--procedure','PROC-REVIEW-PUBLISH',new=True)
    h.gov('ready-record-assurance-check','check','--artifact',a['id'],'--checkpoint','transition','--target','verified',new=True)
    h.run('ready-record-stage',['git','add','--',*files],cwd=h.R)
    assert set(h.git('diff','--cached','--name-only').splitlines())==set(files)
    h.run('ready-record-commit',['git','commit','-m','Prepare hosted sandbox verification for human review','-m','Harness-Work-Orders: WO-HAG-001, WO-HAG-007'],cwd=h.R)
    head=h.git('rev-parse','HEAD');assert not h.git('status','--porcelain')
    assert set(h.git('diff','--name-only',candidate,head).splitlines())==set(files)
    h.write(h.O/'publication-head.json',{'head':head,'candidate':candidate,'product_candidate':review.PRODUCT,'vrec':a['id'],'parent_remote':'690b19de1128eba7bec4245fd23fd29c057f8d22'})
    h.gov('publication-final-pr-check','check-pr','--event',review.event(head,a['id'],candidate),'--from-git',h.B,new=True)
    assert not h.git('status','--porcelain')
    h.gov('publication-final-ready-context','check','--artifact',a['id'],new=True)
elif mode in ('push','body','readback'):
    selection=json.loads((h.O/'publication-head.json').read_text());head=selection['head']
    assert h.git('rev-parse','HEAD')==head and not h.git('status','--porcelain')
    assert json.loads((h.O/'publication-final-pr-check.json').read_text())['exit']==0
    assert h.git('remote','get-url','origin') in ('https://github.com/mmzen/se_harness.git','https://github.com/mmzen/se_harness')
    if mode=='push':
        v=current('publication-before-push');assert v['headRefOid']==selection['parent_remote']
        old=json.loads(json.loads((h.O/'review-before-publication.json').read_text())['stdout'])
        assert v['body']==old['body'],'The remote body changed; inspect before updating.'
        branch=h.run('publication-source-branch',['gh','api','repos/mmzen/se_harness/branches/codex%2Fhosted-artifact-phase1'])
        assert branch['commit']['sha']==selection['parent_remote']
        h.run('publication-push',['git','push','origin',head+':refs/heads/codex/hosted-artifact-phase1'],cwd=h.R)
        v=current('publication-push-readback');assert v['headRefOid']==head
    elif mode=='body':
        v=current('publication-before-body');assert v['headRefOid']==head
        old=json.loads(json.loads((h.O/'review-before-publication.json').read_text())['stdout'])
        assert v['body']==old['body'],'The remote body changed; inspect before updating.'
        text=(h.O/'proposed-pr-body.md').read_text();assert head in text and a['id'] in text
        h.run('publication-body',['gh','pr','edit','535','--repo','mmzen/se_harness','--title','Implement and qualify the Hosted Artifact Graph sandbox','--body-file',h.O/'proposed-pr-body.md'])
        v=current('publication-body-readback');assert v['headRefOid']==head and v['body'].strip()==text.strip()
    else:
        v=current('publication-final-readback');assert v['headRefOid']==head
        observed=[]
        for rel in (a['record_path'],a['evaluator_path'],review.E+'report.md',review.E+'inventory.json',review.E+'combination.json'):
            args=['gh','api','-H','Accept: application/vnd.github.raw+json','repos/mmzen/se_harness/contents/'+rel+'?ref='+head]
            p=subprocess.run(args,cwd=h.W,capture_output=True)
            remote=hashlib.sha256(p.stdout).hexdigest();local=hashlib.sha256(h.blob(head,rel)).hexdigest()
            observed.append({'argv':args,'exit':p.returncode,'path':rel,'remote_sha256':remote,'git_sha256':local,'bytes':len(p.stdout),'equal':remote==local})
            h.write(h.O/'publication-review-readback.json',observed)
            assert p.returncode==0 and remote==local,rel
        print(json.dumps({'head':head,'vrec':a['id'],'candidate':candidate,'review_files_confirmed':len(observed),'ci':[{'name':c.get('name'),'status':c.get('status'),'conclusion':c.get('conclusion')} for c in v['statusCheckRollup']]}))
else:raise ValueError(mode)
