"""Recover the real lost-reply operation through the exact installed CLI."""
import json,os
import hag221_execute as h
O=h.W/'hag-bounded-20261006';h.O=O
assert json.loads((O/'recovery/recovery.json').read_text())['state']=='restart_and_consistent_restore_passed'
records=list((O/'lost-reply').glob('*-lost-reply-identical-recovery.json'));assert len(records)==1
record=json.loads(records[0].read_text());request=O/'lost-reply/lost-reply-request.json'
expected=record['result']
config=json.loads((O/'package/configuration/config.json').read_text())
creds=json.loads((O/'package/credentials.json').read_text())
env=dict(os.environ,HAG_RECOVERY_TOKEN=next(p['token'] for p in creds['principals'] if p['id']=='author-one'))
base=[O/'client-environment/Scripts/python.exe','-I','-B','-m','se_harness','remote']
options=['--endpoint','http://127.0.0.1:18094','--project',config['project_id'],'--token-env','HAG_RECOVERY_TOKEN',
         '--client-wheel',O/'client-build/se_harness-0.22.2-py3-none-any.whl','--json']
before=h.run('lost-reply-cli-status-before',base+['status',*options],env=env)
lookup=h.run('lost-reply-cli-lookup',base+['operation',*options,'--key',expected['operation_key']],env=env)
recovered=h.run('lost-reply-cli-retry',base+['revise-artifact',*options,'--request',request],env=env)
after=h.run('lost-reply-cli-status-after',base+['status',*options],env=env)
assert lookup==expected and recovered==expected
assert before['project_version']==after['project_version']
h.write(O/'lost-reply-cli-assessment.json',{'recovered_exact_original_result':True,'operation_key':expected['operation_key'],
    'project_version_before':before['project_version'],'project_version_after':after['project_version'],
    'meaning':'After real committed-response loss and subsequent qualification, the installed CLI looks up and identically retries the original operation. Both return the exact retained receipt without another version increment.'})
print(json.dumps({'installed_cli_recovery':'passed','version':after['project_version']}))
