"""Retain completed qualification; refuse to turn pending runs into passes."""
import datetime,hashlib,json,re,zipfile
import hag221_execute as h
O=h.W/'hag-bounded-20261006';h.O=O
E=h.R/h.D/'evidence/WO-HAG-001/final-20261006'
candidate='21d268664ffeb111b8b9e9e94921073c7bc99ec1'
assert h.git('rev-parse','HEAD')==candidate
assert not E.exists()
combo=json.loads((O/'package/combination.json').read_text())
assert combo['payload']['source']['candidate_commit']==candidate
required=['source-suite','distribution-checks','cli-smoke','released-validation','client-replay','prepare-package',
          'ready','runtime-tests','stored-schema-boundaries-retry','wire-shape-checks','independent-history',
          'import-fidelity','imported-byte-comparison','live-boundaries','integrity-and-lost-reply','context-variants',
          'receipt-inputs','read-time-bound','restart-restore']
for name in required:assert json.loads((O/(name+'.json')).read_text())['exit']==0,name
walk=json.loads((O/'walkthrough/walkthrough.json').read_text())
assert walk['state']=='client_sequence_passed' and len(walk['observations'])==18
recovery=json.loads((O/'recovery/recovery.json').read_text());assert recovery['state']=='restart_and_consistent_restore_passed'
for host,file in [('codex','http-mcp-comparison.json'),('claude','mcp-http-comparison.json')]:
    comp=json.loads((O/('native-'+host)/file).read_text())
    assert len(comp['comparisons'])==7 and all(x['equal'] for x in comp['comparisons']),host
for name in ('boundaries','integrity','lost-reply','context-variants','receipt-inputs'):
    endings=list((O/name).glob('*-completed.json'));assert len(endings)==1,name
    assert json.loads(endings[0].read_text())['state']=='selected_live_boundary_checks_passed'
assert json.loads((O/'lost-reply-cli-assessment.json').read_text())['recovered_exact_original_result']
refusals=json.loads((O/'live-cli-refusal-assessment.json').read_text())
assert len(refusals)==2 and all(x['specific_refusal_visible_to_installed_client'] for x in refusals)
for name in ('native-claude/walkthrough-session.json','native-claude/mcp-session.json','native-codex/mcp-session.json'):
    assert json.loads((O/name).read_text())['exit']==0,name

roots=[('bounded',O),('readable',h.W/'hag-readable-20261006'),('guidance-only',h.W/'hag-final-20261006')]
secrets=[]
for _,root in roots:
    secrets.extend(p['token'].encode() for p in json.loads((root/'package/credentials.json').read_text())['principals'])
def sha(raw):return hashlib.sha256(raw).hexdigest()
def safe(raw,name):
    assert all(value not in raw for value in secrets),name
    assert not re.search(rb'sk-ant-(?:oat|ort|api)[0-9A-Za-z_-]{16,}',raw),name
    return raw
entries={}
def add(path,name):
    assert name not in entries,name
    entries[name]=safe(path.read_bytes(),name)
directories=['walkthrough','native-claude','native-claude-limited','native-codex','boundaries','history','imports',
             'integrity','lost-reply','context-variants','receipt-inputs','recovery']
for prefix,root in roots:
    for p in sorted(root.glob('*.json')):add(p,prefix+'/'+p.name)
    for p in sorted(root.glob('*.py')):add(p,prefix+'/'+p.name)
    for name in directories:
        for p in sorted((root/name).glob('*.json')):add(p,prefix+'/'+name+'/'+p.name)
        for p in sorted((root/name/'project').glob('*.py')):add(p,prefix+'/'+name+'/project/'+p.name)
        for p in sorted((root/name/'project').glob('*requests.json')):add(p,prefix+'/'+name+'/project/'+p.name)
    add(root/'package/combination.json',prefix+'/package/combination.json')
    add(root/'package/configuration/config.json',prefix+'/package/non-secret-configuration.json')
for prefix in ('hag_final_','hag_readable_','hag_bounded_'):
    for p in sorted(h.W.glob(prefix+'*20261006.py')):add(p,'qualification-scripts/'+p.name)
for name in ('hag_error_diagnose_20261006.py','hag_network_recovery_20261006.py','hag_schema_resume_20261006.py','hag_retain_final_20261006.py'):
    add(h.W/name,'qualification-scripts/'+name)
for wo in ('WO-HAG-001','WO-HAG-007'):
    packet=h.R/h.D/('evidence/'+wo+'/'+wo+'-handoff.md')
    if packet.exists():add(packet,'historical/'+wo+'-handoff-before.md')
E.mkdir(parents=True)
archive=E/'observations.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(entries.items()):
        info=zipfile.ZipInfo(name,(2026,10,6,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,raw)
h.write(E/'inventory.json',{'candidate':candidate,'archive':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,
    'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(entries.items())],
    'scope':'Actual bounded commands, native sessions, requests, responses, failures, qualification helpers, component identities and previous handoffs. No credential files, host profiles, package/source trees, images or database dumps.',
    'credential_check':'All included bytes scanned against known sandbox credentials and provider-token patterns. OAuth credential files were neither read nor copied.'})
(E/'combination.json').write_bytes((O/'package/combination.json').read_bytes())
h.write(E/'continuation.json',{'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,
    'combination_id':combo['combination_id'],'selected_work':['WO-HAG-001','WO-HAG-007'],'repository':str(h.R),'outputs':str(O),
    'sandbox':{'project':'hagbounded20261006','endpoint':'http://127.0.0.1:18094','restored_project':'hagbounded20261006-restore','restored_endpoint':'http://127.0.0.1:18095','selection_file':str(O/'sandbox-selection.json')},
    'qualification':'Required Phase 2 observations completed for this tuple; human verification remains a separate decision.',
    'remaining':['Use released preflight/handoff/completion/capture procedures and confirm their actual results.','Publish the ready review package to existing draft PR #535 under the recorded grant.','Obtain human verification of the exact prepared record; do not infer acceptance from these tests.'],
    'next_context_command':['harnessctl','check',str(h.R),'--artifact','WO-HAG-001','--json'],
    'notice':'This is a retention-time continuation. Obtain fresh lifecycle context rather than replaying completed steps. No human decision is supplied.'})
durations={}
for p in sorted((O/'walkthrough').glob('*-result.json')):
    value=json.loads(p.read_text());durations[p.stem]=value.get('seconds')
report=f'''# Hosted Artifact Graph: Phase 2 qualification

The private sandbox completes the agreed read, draft-authoring and recovery outcome on product candidate `{candidate}`. The assessment covers WO-HAG-001 and the supporting WO-HAG-007 correction under VER-HAG-001. These are observed test results, not human verification or merge approval.

## Result and component identity

An agent retrieves the fixed work context, creates and revises an incomplete draft through the installed client, receives specific refusals, recovers an accepted operation after a lost reply, and retrieves the original baseline unchanged. Claude runs the packaged walkthrough with the candidate plugin loaded. Both native CLIs exercise all seven MCP reads, which match the corresponding HTTP responses. Large partial impact results remain partial.

| Component | Tested identity |
| --- | --- |
| Product source | `{candidate}` |
| Combination | `{combo['combination_id']}` |
| Client | Unpublished 0.22.2; wheel `{combo['payload']['client']['wheel_sha256']}` |
| Plugin | Unpublished 0.2.7; both host ZIP and inventory digests in [combination.json](combination.json) |
| Service | 0.1.0.dev1; image `{combo['payload']['server']['image_manifest']}` |
| Runtime/store | Linux/amd64, CPython 3.13.16, Memgraph 3.13.1; immutable pins in the combination |
| Evaluator | Separate public 0.22.1, archive `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053` |

The client and plugin archives and service image derive from the same clean source commit. The generated combination file retains its original build-time statement, `built; qualification pending`; this report records the later qualification observations. A later evidence or governance commit does not change the product identity above. The checkout governor remains the isolated public evaluator.

## Requirement and scenario assessment

Paths below refer to members of [observations.zip](observations.zip), under `bounded/`, unless another prefix is stated. [inventory.json](inventory.json) gives every retained member's byte count and SHA-256.

| VER-HAG-001 case | Observed evidence and result | Assessment |
| --- | --- | --- |
| SC-01 — Import fidelity | `imported-bytes.json` compares all 1,909 original Git documents, byte hashes, IDs, paths, relations and provenance. `imports/` refuses duplicate IDs, unresolved targets, changed declared bytes and Explorer input. Imported lifecycle claims remain original bytes. | Pass for the public reference snapshot. |
| SC-02 — Repetition and immutability | `walkthrough/` returns the same import receipt on identical retry and retains B after draft edits. Fixed pre-implementation canonical vectors remain in the source fixtures; `wire-shape-checks.json` and the source suite exercise them. | Pass. |
| SC-03 — Work context | `history/released-oracle.json` and `history/historical-bindings.json` compare the independently installed release with the hosted result. The fixed context has twelve governing IDs, eleven paths and two dependencies. `context-variants/` retains an open blocking decision and a separate missing-evidence result while preserving the reference source. | Pass. |
| SC-04 — Read consistency | `native-claude/mcp-http-comparison.json`, `native-codex/http-mcp-comparison.json` and `boundaries/` establish seven exact HTTP/MCP comparisons, explicit views, unknown-identity refusals and row/byte/depth bounds. Impact reports `complete=false`, `row_limit`. | Pass for the tested views and limits. |
| SC-05 — Valid drafts | `walkthrough/` uses the released authoring template through the installed remote client, accepts legitimate incompleteness and appends a body/relationship revision. B stays unchanged. | Pass. |
| SC-06 — Invalidity and protected inputs | `boundaries/` refuses malformed TOML, duplicate metadata, type/ID mismatch, prohibited relations, imported decisions/evidence/state, forged actor fields and incompatible rights/identities. Before/after store fingerprints match on refusals. `live-cli-refusal-assessment.json` confirms specific malformed/duplicate refusals reach the real installed CLI. | Pass. |
| SC-07 — Concurrent and stale inputs | `boundaries/` races independent connections: one different request accepts and identical keys recover one receipt. `receipt-inputs/` creates another real artifact, keeps the pending request's selected revision unchanged, and receives `STALE_PROJECT`. | Pass on this run. Earlier unexplained race failure remains recorded below. |
| SC-08 — Retry and transaction recovery | `lost-reply/` suppresses an actual committed response, then recovers the same result with no extra increment. `lost-reply-cli-assessment.json` confirms that installed-CLI lookup and retry after restart also return the exact original result without another increment. `receipt-inputs/` refuses changed context/baseline under an accepted key. `boundaries/` checks principal-scoped lookup and rollback after graph writes, before commit and at failed commit. | Pass. |
| SC-09 — Cypher boundaries | `boundaries/` exercises parsed allowed reads, unsupported forms, selected-view restriction, budgets and rollback. `read-time-bound.json` records the real five-second database transaction limit. | Pass for the application contract. Direct time stress is not a public-grammar/HTTP exhaustion or database-authorization test. |
| SC-10 — Packaged agent walkthrough | `native-claude/walkthrough-session.json` records the session-loaded candidate plugin and guided execution of eighteen real installed-client operations covering the twelve required steps. The two native MCP sessions exercise the read surface. | Pass for this guided CLI path. |
| SC-11 — Historical bindings/evaluator | `history/` independently recomputes the original legacy digest, including original paths, scoped code and line-ending rules. `integrity/` refuses substituted archive/payload, candidate-as-governor and damaged stored links/contracts. The missing-evidence variant stays incomplete. | Pass. |
| SC-12 — Packages and recovery | Pinned two-build replay matches; installed runtime checks and exact package readback pass. Explicit initialization and stored schema/index refusals pass. `recovery/recovery.json` records real restart, quiesced backup and restore into a new volume with matching store, baseline and receipt identities. | Pass for the declared private Docker sandbox. |

REQ-HAG-001 is covered by SC-01/02; REQ-HAG-002 by SC-02/05/10; REQ-HAG-003 by SC-03/04; REQ-HAG-004 by SC-05/06; REQ-HAG-005 by SC-07/08; REQ-HAG-006 by SC-04/09; REQ-HAG-007 by SC-03/06/11; REQ-HAG-008 by SC-10/12. WO-HAG-007's three supporting files are covered by the full suite and preserved [correction assessment](../../WO-HAG-007/correction-assessment.json).

The synthetic pending-decision fixture does not invent a human decision. It introduces separate synthetic active work, retains the exact decision predicate and compares the installed service handler to the independent evaluator. The missing-evidence variant reports `binding_unavailable`; it does not reinterpret missing input as a pass. The original imported fixture stays unchanged.

## Checks and measurements

- Source runner: 1,319 tests, 23 reported skips, exit 0. Skips remain unperformed coverage.
- Installed service runtime: seven tests, exit 0, including the saved-response and oversized-refusal regressions.
- Wire schemas and canonical fixtures: 60 checks pass.
- Distribution checks: 23 records pass. CLI smoke passes.
- Released validation before evidence retention: 1,970 artifacts, zero errors, 63 existing warnings. Warnings are not risk acceptance.
- Walkthrough command durations are retained individually in `walkthrough/*-result.json`; their sum is {round(sum(x for x in durations.values() if x is not None),3)} seconds. Model reasoning and approval-review time are excluded.
- Restart: {recovery['restart_seconds']} seconds. Restore: {recovery['restore_seconds']} seconds. The acknowledged cutoff is project version {recovery['cutoff']['project_version']}; exact baseline/receipt identities and logical-store digest are in `recovery/recovery.json`.

The backup is {recovery['backup']['bytes']} bytes, SHA-256 `{recovery['backup']['sha256']}`, retained at `{recovery['backup']['path']}`. It is excluded from Git. The exact packages, build records and configuration remain at `{O}`. Images remain in the local Docker store under their immutable identities. The report includes no production RPO, RTO or power-loss guarantee.

## Corrections and preserved failures

1. Candidate `9e0199480a40e7cd207c9f682bb17d66bf977513` added explicit saved-response guidance. Claude still misreported an unread large response after shell helper commands were refused. Its second restricted probe made no MCP call. `guidance-only/` retains both outcomes; neither is a pass. That helper was not executed. Its original saved-file shape assumption and an analysis decoding error are retained as analysis failures.
2. Candidate `b55d096a510a5517addd69f504922438bf03b1e0` changed commas in MCP text from spaces to line breaks. JSON values and byte count stay the same. The regression fails on the prior image and passes with the correction. Claude reads the saved result with its ordinary bounded file tool and correctly reports partial coverage; Codex does likewise. `readable/` retains those actual sessions and the 52 boundary observations. No helper shell permission was needed to read that result.
3. Review of those observations found a separate client defect. A malformed draft returned a 3,384,949-byte refusal containing 1,909 unrelated valid records. Replaying that actual response through the unchanged installed client produced `outcome=unknown`. The final candidate keeps all released parser errors and omits the unusable catalog only when parsing fails. Its regression proves large successful catalogs still retain their content. Final live CLI probes now show the specific `HAG_REMOTE_INVALID_DRAFT` refusal for both malformed TOML and duplicate metadata. The original failed replay and regression remain under `readable/`.
4. The final schema test first could not start because Docker's address pools were exhausted. Two completed task-owned environments were taken down without deleting named volumes, images or evidence. The exact volume readbacks match. The unstarted probe was then run successfully; the failed command and scoped recovery remain in this archive.

Earlier [Claude](../claude-20261006/report.md), [Codex](../codex-20261006/report.md) and [Phase 2](../phase2-20261005/protocol04-assessment.md) reports retain their identities and failures. The early equal-key race once returned unknown results with no effects; its exact cause was not isolated. Later actual races, including this final run, pass. No causal fix or general reliability guarantee is inferred from those passes. Historical VREC-HAG-001/002/003 and their bound evidence are unchanged.

## Review and limits

Review traced admission through `Service.command`, isolated released parsing/evaluation, guarded `Store.commit`, and one shared `read` handler for HTTP/MCP. Revision content, declared edges, draft head, version and receipt commit together. Read transactions roll back. Source/evidence resolution checks contained regular files and original byte identities; imported prose is never executed. Default logs exclude document bodies and credentials. The latest corrections reuse these paths and add no second lifecycle policy or general response framework.

The project-wide guard and complete materialization are deliberate simple choices. They produce conservative conflicts and measurable per-command cost. The retained command timings expose that cost; this result makes no production performance claim.

Claude's candidate plugin was loaded for the test session. Codex explicitly read the exact candidate guidance under its normal profile and automatic approval reviewer. **Automatic Codex candidate-plugin installation/loading, startup/compaction and desktop behavior were not exercised.** The walkthrough is guided execution of an inspected launcher, not unscripted authoring. Controlled response-loss and changed-dependency variants use the retained test drivers on the same tuple; the final installed CLI separately confirms lookup and retry after recovery. These boundaries do not borrow any earlier release waiver. Native model prose is not the test oracle; actual commands, assertions and exact responses govern this assessment. Claude's walkthrough summary still mislabels a context read as creation, a simple Cypher read as cryptographic verification, and an identical accepted retry as retrying with current state. Those claims are unsupported by the actual commands and are not adopted here. Its MCP summary also miscounts the impact and lineage artifacts. The exact responses contain 123 impact artifacts and 377 relations, and five lineage artifacts and eight relations. Both native comparisons use these actual responses; the report does not adopt the incorrect prose counts. The exact duration is computed from retained results above, not its approximate total. Successful sessions do not guarantee future model behavior or authentication lifetime.

RISK-HAG-001 remains **raised**, not accepted or closed. Application restrictions and a private loopback sandbox do not establish Memgraph-enforced read-only authorization. Authenticated human lifecycle decisions, hosted authority cutover, untrusted-network exposure, production deployment, multi-tenancy, power-loss recovery, HA, migrations and public release remain outside Phase 2.

## Review handoff

Use the released evaluator to record eligible implementation completion and prepare one commit-bound verification record for WO-HAG-001 and WO-HAG-007 under VER-HAG-001. Publish that ready record and this assessment in existing draft PR #535, preserving target `codex/hosted-artifact-graph-inputs` and original comparison base `be1812e7042081014cc7682da8b9cd3822d9071f`. Only the accountable human can accept verification. This report supplies no merge, release, risk-acceptance or deployment decision.

[continuation.json](continuation.json) retains exact local selections. Obtain fresh evaluator context before continuing; do not replay completed transitions from this report. All earlier packet bytes were saved in the archive before any supported handoff rebind.
'''
h.write(E/'report.md',report)
readme=h.R/h.D/'README.md';text=readme.read_text(encoding='utf-8')
start=text.index('The [current Codex qualification report]')
text=text[:start]+f'''The [Phase 2 qualification report](evidence/WO-HAG-001/final-20261006/report.md)
assesses all twelve VER-HAG-001 scenarios on product candidate `{candidate}`.
It includes the real Claude guided walkthrough, seven native MCP reads in each
CLI with exact HTTP comparisons, concurrent/stale writes, retry/rollback and
restart/restore. It retains the saved-response and oversized-error failures
alongside their corrections. The exact packages are identified in its component
manifest. Human verification remains separate.

[WO-HAG-007](work-orders/WO-HAG-007.md) covers the supporting command documentation
and package checks. Read the two work orders and any directly linked verification
record for current lifecycle state. The earlier [Claude](evidence/WO-HAG-001/claude-20261006/report.md),
[Codex](evidence/WO-HAG-001/codex-20261006/report.md), and
[Phase 2](evidence/WO-HAG-001/phase2-20261005/protocol04-assessment.md) observations
remain historical evidence with their original candidate identities.

Automatic Codex candidate-plugin loading and desktop were not exercised.
RISK-HAG-001 remains raised. This private-sandbox qualification establishes no
human verification decision, public deployment, authority cutover or release.
'''
text=text.replace('The 16 definitions above are approved; WO-HAG-001 is in_progress.', 'The 16 definitions above are approved; the linked WO-HAG-001 records the current work state.')
text=text.replace('WO-HAG-001 remains in_progress for the complete Phase 2 outcome. Development', 'The following paragraph records the reconciliation-stage handoff. Development')
h.write(readme,text)
notes=h.R/'docs/notes/hosted-artifact-graph.md';text=notes.read_text(encoding='utf-8')
text=text.replace('## Deferred boundary and remaining qualification','## Deferred boundary and historical qualification')
text+='''

## Current Phase 2 qualification

The [current assessment](../engineering/hosted-artifact-graph/evidence/WO-HAG-001/final-20261006/report.md)
records all twelve required scenarios for the final candidate, its exact component
tuple, real native CLI observations and restart/restore. It preserves the earlier
failures above. Large saved MCP responses expose their completeness metadata to
bounded file reads. Parser failures preserve their errors without returning an
unusable catalog that exceeds the CLI response bound.

The assessment distinguishes tested behavior from human verification. Read the
linked work orders and verification record for current lifecycle state. Codex
candidate guidance was read explicitly; automatic loading and desktop were not
tested. Database-side read-only enforcement remains RISK-HAG-001. Phase 3 pilot
authority and Phase 4 production/release obligations require later work.
'''
h.write(notes,text)
print(json.dumps({'report':str(E/'report.md'),'members':len(entries),'archive_bytes':archive.stat().st_size}))
