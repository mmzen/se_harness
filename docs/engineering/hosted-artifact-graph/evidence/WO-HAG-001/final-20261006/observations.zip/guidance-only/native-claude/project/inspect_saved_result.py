"""Bounded, read-only inspection of this test project's one saved MCP impact response."""
import hashlib,json,stat
from pathlib import Path
root=Path('C:\\Users\\mathi\\.claude\\projects\\C--Users-mathi-Documents-Codex-2026-09-20-verity-plane-plugin-verity-plane-se-work-hag-final-20261006-native-claude-project')
files=list(root.glob('*/tool-results/mcp-hag-impact-*.txt'))
if len(files)!=1:raise RuntimeError('Expected one saved impact response for this test project')
file=files[0]
if not file.resolve(strict=True).is_relative_to(root.resolve(strict=True)):raise RuntimeError('Path escapes test project')
for part in (file,*file.parents):
    if part==root.parent:break
    if getattr(part.lstat(),'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0):raise RuntimeError('Reparse point refused')
if not file.is_file() or file.stat().st_size>4194304:raise RuntimeError('Expected bounded regular file')
raw=file.read_bytes();blocks=json.loads(raw)
if not isinstance(blocks,list) or len(blocks)!=1 or blocks[0].get('type')!='text':raise RuntimeError('Unexpected saved response shape')
result=json.loads(blocks[0]['text'])
if result.get('schema')!='se-harness-graph-read/v1' or result.get('operation')!='impact':raise RuntimeError('Unexpected result contract')
metadata={key:result[key] for key in ('schema','operation','project_id','view','observed_project_version','evaluator','complete','continuation','unresolved_references')}
metadata['collection_counts']={key:len(value) for key,value in result.get('data',{}).items() if isinstance(value,list)}
print(json.dumps({'source':str(file),'sha256':hashlib.sha256(raw).hexdigest(),'inspection_scope':'Result metadata and collection counts only; no graph-content summary.', 'result':metadata}))
