"""Actual artifact-change guard and full-request receipt key tests."""
import argparse,copy,json,sys
from pathlib import Path
sys.path.insert(0,'/qualification')
from qualify_boundaries import Boundaries

class Inputs(Boundaries):
    def cases(self):
        # Reuse already accepted requests; different semantic fields must refuse
        # before any current-version or selected-view lookup can hide key misuse.
        changed=json.loads((self.args.walkthrough/'009-revise-body-and-relation-request.json').read_text())
        changed['context_id']='aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'
        self.refuse('same-key-different-context',changed,'KEY_REUSE')
        changed=json.loads((self.args.walkthrough/'006-open-context-request.json').read_text())
        changed['base_baseline_id']='se-harness-artifact-baseline/v1:sha256:'+'0'*64
        before=self.snapshot()
        status,result=self.http(f'/v1/projects/{self.project}/contexts',changed,'operator')
        after=self.snapshot()
        self.record('same-key-different-baseline',{'request':changed,'status':status,'result':result,'before':before,'after':after})
        assert status==409 and result['error']['code']=='HAG_REMOTE_KEY_REUSE' and before==after
        # Add a different real artifact, leaving the selected requirement's bytes
        # and revision unchanged. The previously prepared request must be stale.
        pending=self.command()
        with self.service.store.transaction() as tx:
            original=self.service.store.view(tx,self.context)['revisions'][self.binding['artifact_id']]
        create=self.command('create-artifact',context_id=self.context['context_id'],expected_context_version=self.context['context_version'],
                            domain='instruction-architecture',artifact_type='requirement',artifact_id=None)
        status,result=self.http(f'/v1/projects/{self.project}/commands',create)
        self.record('create-other-artifact',{'request':create,'status':status,'result':result})
        assert status==200 and result['outcome']=='accepted'
        self.context=result['view']
        with self.service.store.transaction() as tx:
            preserved=self.service.store.view(tx,self.context)['revisions'][self.binding['artifact_id']]
        assert preserved==original
        self.refuse('other-artifact-makes-prepared-request-stale',pending,'STALE_PROJECT')
        self.record('selected-revision-preserved',{'binding':self.binding,'context':self.context,'full_revision_equal':True})

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--config',type=Path,default=Path('/run/config/config.json'))
p.add_argument('--credentials',type=Path,default=Path('/run/secrets/sandbox_credentials'))
p.add_argument('--endpoint',default='http://service:8080')
p.add_argument('--walkthrough',type=Path,required=True)
p.add_argument('--continuation',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();a.only='cases';suite=Inputs(a)
try:suite.run()
finally:suite.service.store.driver.close()
