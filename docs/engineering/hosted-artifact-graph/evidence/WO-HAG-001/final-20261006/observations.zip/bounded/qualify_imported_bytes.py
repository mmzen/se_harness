"""Independently compare every imported document with its original Git blob."""
import base64,hashlib,json,tomllib
from pathlib import Path
from hosted_artifact_graph.service import Service
config=json.loads(Path('/run/config/config.json').read_text())
credentials=json.loads(Path('/run/secrets/sandbox_credentials').read_text())
walk=json.loads(Path('/observations/walkthrough/walkthrough.json').read_text())
manifest=json.loads(Path('/source/source-manifest.json').read_text())
service=Service(config,credentials)
try:
    with service.store.transaction() as tx:
        baseline=service.store.baseline(tx,walk['baseline']['baseline_id'])
        revisions=service.store.revisions(tx,baseline['manifest']['selection'])
    by_id={r['envelope']['artifact_id']:r for r in revisions.values()}
    assert set(by_id)=={e['artifact_id'] for e in manifest['artifacts']}
    checked=[]
    for entry in manifest['artifacts']:
        r=by_id[entry['artifact_id']];envelope=r['envelope']
        raw=base64.b64decode(r['document_base64'],validate=True)
        original=(Path('/source/source')/entry['path']).read_bytes()
        assert raw==original and len(raw)==entry['bytes']
        assert hashlib.sha256(raw).hexdigest()==entry['raw_sha256']==envelope['document_sha256']
        assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==entry['blob_oid']
        metadata=tomllib.loads(raw.decode('utf-8').split('+++',2)[1])
        expected={k:sorted(set(v)) for k,v in metadata.get('relations',{}).items()}
        assert envelope['declared_relations']==expected
        assert envelope['artifact_id']==metadata['id']==entry['artifact_id']
        assert envelope['original_path']==entry['path']
        assert envelope['provenance']=={'kind':'git','source':manifest['source'],'blob_oid':entry['blob_oid']}
        checked.append({'id':entry['artifact_id'],'path':entry['path'],'raw_sha256':entry['raw_sha256'],'revision_id':r['revision_id'],'status':metadata['status']})
    output={'state':'every_imported_git_blob_preserved','source':manifest['source'],'baseline':walk['baseline'],'artifact_count':len(checked),
            'checks':'Exact bytes, SHA-256, Git blob identity, artifact identity, original path, declared relations and provenance compared independently with stdlib parsing and hashing.',
            'artifacts':checked}
    dest=Path('/observations/imported-bytes.json');assert not dest.exists();dest.write_text(json.dumps(output,indent=2)+'\n')
    print(json.dumps({'state':output['state'],'artifact_count':len(checked)}))
finally:service.store.driver.close()
