"""SC-03: independent released oracle and a synthetic source, never historical edits."""
import argparse
import copy
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import uuid
from pathlib import Path

sys.path.insert(0, '/qualification')
from qualify_boundaries import Boundaries
from hosted_artifact_graph.canonical import canonical_json
from hosted_artifact_graph.protocol import EVALUATOR
from hosted_artifact_graph.service import Service
from hosted_artifact_graph.reads import read

DECISION = '''+++
id = "DEC-RLS-999"
type = "decision"
title = "Synthetic pending decision for hosted qualification"
status = "open"
owners = ["sandbox-owner"]
created = "2026-10-05"
updated = "2026-10-05"
kind = "question"
question = "Should the synthetic selected work proceed?"
raised_by = "sandbox-author"
recommendation = "proceed"
[[options]]
id = "proceed"
label = "Proceed with the synthetic test work."
[[options]]
id = "stop"
label = "Stop the synthetic test work."
[relations]
concerns = ["WO-RLS-038"]
blocks = ["WO-RLS-038"]
+++

# Synthetic pending decision

This disposable test record has no human decision or production authority.
'''

ORACLE = '''import json,sys,subprocess
from pathlib import Path
from se_harness.installer import plan_install,apply_changes
from se_harness.evaluator_identity import installed_evaluator_identity
r=Path(sys.argv[1]); changes,lock=plan_install(r,project_name="hosted-artifact-poc",mode="upgrade")
apply_changes(r,changes,lock,allow_updates=True)
results={"identity":installed_evaluator_identity().to_lock()}
for label,extra in [("context",[]),("handoff",["--checkpoint","handoff"])]:
 cmd=[sys.executable,"-I","-m","se_harness","check",str(r),"--artifact","WO-RLS-038",*extra,"--json"]
 p=subprocess.run(cmd,cwd=r.parent,capture_output=True,text=True,timeout=120)
 results[label]={"argv":cmd,"exit":p.returncode,"stderr":p.stderr,"result":json.loads(p.stdout)}
print(json.dumps(results))
'''


class Variant(Boundaries):
    def oracle(self, source, label):
        with tempfile.TemporaryDirectory(prefix='hag-independent-variant-oracle-') as tmp:
            root = Path(tmp)/'source'
            shutil.copytree(source, root, ignore=shutil.ignore_patterns('.git'))
            argv = ['/opt/evaluator/bin/python', '-I', '-B', '-c', ORACLE, str(root)]
            child = subprocess.run(argv, cwd=tmp, capture_output=True, text=True, timeout=360)
            self.record(label+'-oracle-process', {'argv':argv,'exit':child.returncode,
                'stdout':child.stdout,'stderr':child.stderr})
            assert child.returncode == 0
            result = json.loads(child.stdout)
            assert all(result['identity'][k] == v for k,v in EVALUATOR.items())
            return result

    def variants(self):
        with tempfile.TemporaryDirectory(prefix='hag-context-variant-') as tmp:
            base=Path(tmp); source=base/'source'
            original_manifest=copy.deepcopy(self.service.evaluator.manifest)
            original_baseline=self.service.baseline(self.principal(),self.project,self.baseline['baseline_id'])
            shutil.copytree(self.service.evaluator.source,source)
            path='docs/engineering/release-0-22-0/decisions/DEC-RLS-999.md'
            raw=DECISION.encode(); (source/path).write_bytes(raw)
            env={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
            env.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_SYSTEM=os.devnull)
            def git(*args):
                return subprocess.check_output(['git','-c','core.hooksPath=/dev/null','-c','core.autocrlf=false',
                    '-c','user.name=Sandbox fixture','-c','user.email=sandbox@example.invalid',*args],
                    cwd=source,env=env,stderr=subprocess.PIPE).decode().strip()
            git('init','--quiet','--template=');git('add','--all')
            git('commit','--quiet','--no-gpg-sign','-m','Disposable SC-03 pending decision fixture')
            manifest=copy.deepcopy(original_manifest);manifest['source']['commit']=git('rev-parse','HEAD')
            entry={'artifact_id':'DEC-RLS-999','path':path,'bytes':len(raw),
                'raw_sha256':hashlib.sha256(raw).hexdigest(),'blob_oid':git('rev-parse','HEAD:'+path)}
            # Preserve any schema fields shared by existing manifest entries.
            prototype=next(x for x in manifest['artifacts'] if x['artifact_id']=='DEC-RLS-007')
            assert set(entry)==set(prototype),(set(entry),set(prototype))
            manifest['artifacts'].append(entry);manifest['artifacts'].sort(key=lambda x:(x['path'],x['artifact_id']))
            support=copy.deepcopy(self.service.evaluator.support);support['source']=manifest['source']
            support['files'].append({'path':path,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'blob_oid':entry['blob_oid']})
            support['files'].sort(key=lambda x:x['path'])
            config=copy.deepcopy(self.config);config.update(source_directory=str(source),
                source_manifest=str(base/'manifest.json'),source_inventory=str(base/'inventory.json'))
            (base/'manifest.json').write_bytes(canonical_json(manifest));(base/'inventory.json').write_bytes(canonical_json(support))
            config['components']['deployment_sha256']=hashlib.sha256(canonical_json({
                'configuration':{k:v for k,v in config.items() if k!='components'},
                'compose_sha256':hashlib.sha256(Path('/opt/compose.yaml').read_bytes()).hexdigest()})).hexdigest()
            self.record('synthetic-fixture',{'derived_from':original_manifest['source'],'source':manifest['source'],
                'added_artifact':entry,'document_utf8':DECISION,'deployment_sha256':config['components']['deployment_sha256'],
                'no_original_input_changed':True})
            oracle=self.oracle(source,'pending-decision')
            other=Service(config,self.credentials)
            try:
                command={'schema':'se-harness-remote-command/v1','project_id':self.project,'operation':'import',
                    'operation_key':str(uuid.uuid4()),'expected_project_version':self.snapshot()['version'],
                    'expected_evaluator':EVALUATOR,'client':config['client'],'source_manifest':manifest}
                accepted=other.command(self.principal('operator'),command)
                self.record('synthetic-import',{'request':command,'result':accepted})
                assert accepted['outcome']=='accepted'
                request=self.read('work-context',accepted['view'],work_order_id='WO-RLS-038')
                hosted=read(other,self.principal(),request)
                self.record('pending-decision-context',{'request':request,'result':hosted})
                assert hosted['evaluator_output']==oracle['context']['result']
                assert hosted['complete']
                assert 'DEC-RLS-999' in {v['artifact_id'] for v in hosted['data']['relevant_decisions']}
                gates=oracle['handoff']['result']
                encoded=json.dumps(gates)
                assert 'DEC-RLS-999' in encoded and 'QGP-G4I-DECISION' in encoded
                # The fixture intentionally leaves the question open. No disposition is inserted.
                missing='docs/engineering/release-0-22-0/evidence/VREC-RLS-002-evaluator.json'
                removed=(source/missing).read_bytes();(source/missing).unlink()
                absent_oracle=self.oracle(source,'missing-evidence')
                unavailable=read(other,self.principal(),request)
                self.record('unavailable-evidence-context',{'request':request,'removed_path':missing,
                    'removed_sha256':hashlib.sha256(removed).hexdigest(),'result':unavailable})
                assert unavailable['evaluator_output']==absent_oracle['context']['result']
                assert unavailable['complete'] is False
                assert unavailable['continuation']['reason']=='binding_unavailable'
                assert missing in unavailable['continuation']['instructions']
                assert (source/path).read_bytes()==raw
            finally:
                other.store.driver.close()
            after=self.service.baseline(self.principal(),self.project,self.baseline['baseline_id'])
            assert original_baseline==after
            for e in original_manifest['artifacts']:
                assert hashlib.sha256((self.service.evaluator.source/e['path']).read_bytes()).hexdigest()==e['raw_sha256']
            self.record('original-preserved',{'baseline':self.baseline,'all_original_artifact_hashes_match':True,
                'qualification_limit':'Synthetic context uses the installed service read handler; packaged CLI reference context is separately observed.'})


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',type=Path,default=Path('/run/config/config.json'))
    p.add_argument('--credentials',type=Path,default=Path('/run/secrets/sandbox_credentials'))
    p.add_argument('--endpoint',default='http://service:8080')
    p.add_argument('--walkthrough',type=Path,required=True)
    p.add_argument('--continuation',type=Path)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();a.only='variants';suite=Variant(a)
    try:suite.run()
    finally:suite.service.store.driver.close()
