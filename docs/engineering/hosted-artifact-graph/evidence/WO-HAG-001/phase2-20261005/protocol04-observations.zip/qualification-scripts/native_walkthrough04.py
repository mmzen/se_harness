"""A native Claude session reads the exact candidate skills and launches the real CLI qualification.

The only allowed shell command is the prepared local qualification entry point.
Credentials are copied locally for this process, then removed; never printed.
This tests the packaged CLI route, not desktop or the full legacy host matrix.
"""
import hashlib
import json
import os
import shlex
import subprocess
import sys
from pathlib import Path

base=Path(__file__).resolve().parent
root=base/'native04-exact'
profile=root/'claude/profile'
project=root/'claude/project'
plugin=root/'marketplace/claude/verity-plane'
observation=root/'claude-walkthrough-session.json'
assert not observation.exists()
argv=json.loads((base/'protocol04-walkthrough.json').read_text())['argv']
argv=[v.replace('protocol04-walkthrough','native04-walkthrough') for v in argv]
entry=project/'run_walkthrough.py'
assert not entry.exists()
entry.write_text('import subprocess,sys\nargs='+repr(argv)+'\np=subprocess.run(args,cwd='+repr(str(base))+')\nsys.exit(p.returncode)\n',encoding='utf-8')
command=shlex.quote(Path(sys.executable).as_posix())+' -B run_walkthrough.py'
prompt=('Qualify the unpublished Verity Plane 0.2.7 hosted sandbox guidance. Read the hosted sandbox sections of '
    +str(plugin/'skills/setup/SKILL.md')+' and '+str(plugin/'skills/change/SKILL.md')+'. '
    'The human approved WO-HAG-001 sandbox qualification. The exact packaged candidate is already built, separately installed and '
    'running privately on loopback. No repository authority cutover, lifecycle decisions, installation into the user profile, '
    'publication, merge or deployment is allowed. The entry point run_walkthrough.py executes the inspected integration procedure '
    'against this candidate: explicit import, context read, draft creation and revision, invalid and stale refusal, '
    'retry recovery, unchanged baseline, bounded Cypher and released evaluator check. It retains each actual CLI request and result. '
    'Read that entry point, then launch it once through Bash with exactly this command: '+command+'. '
    'Do not read authentication or credential files, print environment variables, edit files, spawn subagents or run other commands. '
    'Report actual observed steps and any failure. A process exit is not human verification, desktop coverage or full host qualification. '
    'If a tool is denied, report it without changing permissions or switching to another execution route.')
args=[r'C:\Users\mathi\.local\bin\claude.exe','--plugin-dir',str(plugin),'-p',
    '--no-session-persistence','--tools','Read,Bash','--allowedTools','Read','Bash('+command+')',
    '--output-format','stream-json','--verbose',prompt]
env=dict(os.environ,CLAUDE_CONFIG_DIR=str(profile/'claude'),CODEX_HOME=str(profile/'codex'),PYTHONUTF8='1',NO_COLOR='1')
source=Path(r'C:\Users\mathi\.claude\.credentials.json');target=profile/'claude/.credentials.json'
assert source.is_file() and not target.exists()
raw=source.read_bytes();before=hashlib.sha256(raw).hexdigest();target.write_bytes(raw)
def secret_values(value):
    if isinstance(value,dict):
        for item in value.values():yield from secret_values(item)
    elif isinstance(value,list):
        for item in value:yield from secret_values(item)
    elif isinstance(value,str) and len(value)>30:yield value
try:
    child=subprocess.run(args,cwd=project,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=900)
    record={'argv':args,'cwd':str(project),'exit':child.returncode,'stdout':child.stdout,'stderr':child.stderr,
        'claim':'Native Claude reads exact candidate guidance and launches the separately installed CLI procedure. No desktop or human-verification claim.'}
    encoded=json.dumps(record,ensure_ascii=False)
    secrets=list(secret_values(json.loads(raw)))
    secrets.extend(p['token'] for p in json.loads((base/'package-04/credentials.json').read_text())['principals'])
    assert all(s not in encoded for s in secrets)
    observation.write_text(encoded+'\n',encoding='utf-8')
    print(json.dumps({'exit':child.returncode,'record':str(observation)}))
finally:
    target.unlink(missing_ok=True)
    assert hashlib.sha256(source.read_bytes()).hexdigest()==before
