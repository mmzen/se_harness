"""Exercise exact candidate skill discovery through native, read-only sessions.

Credentials remain local. Temporary copies are removed after each process and
are never included in observations. This does not qualify a hosted write.
"""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

base = Path(__file__).resolve().parent
root = base/'native03-exact'
host = sys.argv[1]
profile = root/host/'profile'
project = root/host/'project'
env = os.environ.copy()
env.update(CODEX_HOME=str(profile/'codex'), CLAUDE_CONFIG_DIR=str(profile/'claude'),
           PYTHONUTF8='1', NO_COLOR='1')
if host == 'codex':
    source = Path(r'C:\Users\mathi\.codex\auth.json')
    target = profile/'codex/auth.json'
    plugin = Path(json.loads(json.loads((root/'codex-installation.json').read_text())['stdout'])['installedPath'])
    args = [r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe',
            'exec','--ephemeral','--sandbox','read-only','--skip-git-repo-check','--json','-C',str(project)]
else:
    source = Path(r'C:\Users\mathi\.claude\.credentials.json')
    target = profile/'claude/.credentials.json'
    plugin = root/'marketplace/claude/verity-plane'
    args = [r'C:\Users\mathi\.local\bin\claude.exe','--plugin-dir',str(plugin),'-p',
            '--tools','Read','--allowedTools','Read','--output-format','json']
prompt = ('This is a read-only qualification of the locally installed unpublished Verity Plane plugin 0.2.7. '
          'Use its setup and change skills from this exact plugin root: '+str(plugin)+'. '
          'Read their hosted sandbox sections. Do not read authentication files, use secrets, modify files, '
          'install software, or make a remote write. Report the exact instruction files you read; explain '
          'which evaluator governs the repository and service, which separately installed client provides remote commands, '
          'and what to do after an uncertain remote write. Distinguish reading guidance from running the hosted walkthrough. '
          'No claims of approval, verification or completed qualification.')
args.append(prompt)
assert source.is_file() and not target.exists()
raw = source.read_bytes()
before = hashlib.sha256(raw).hexdigest()
target.write_bytes(raw)
try:
    child = subprocess.run(args,cwd=project,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180)
    record = {'host':host,'argv':args,'exit':child.returncode,'stdout':child.stdout,'stderr':child.stderr,
              'scope':'Native model read of exact candidate instructions; no hosted operation or desktop proof.'}
    # Refuse retention if any credential string appears in the captured output.
    def values(value):
        if isinstance(value,dict):
            for v in value.values(): yield from values(v)
        elif isinstance(value,list):
            for v in value: yield from values(v)
        elif isinstance(value,str) and len(value)>30: yield value
    encoded = json.dumps(record,ensure_ascii=False)
    assert all(secret not in encoded for secret in values(json.loads(raw)))
    (root/f'{host}-model-probe.json').write_text(encoded+'\n',encoding='utf-8')
    print(json.dumps({'host':host,'exit':child.returncode,'record':str(root/f'{host}-model-probe.json')}))
finally:
    target.unlink(missing_ok=True)
    assert hashlib.sha256(source.read_bytes()).hexdigest() == before, 'Original auth file changed externally; inspect before retrying.'
