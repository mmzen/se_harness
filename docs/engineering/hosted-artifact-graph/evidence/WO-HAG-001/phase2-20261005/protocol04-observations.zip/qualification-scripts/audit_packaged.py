"""Read-only checks plus rollback-only graph corruption in a disposable process."""
import copy
import json
from pathlib import Path

from hosted_artifact_graph.service import Service
from hosted_artifact_graph.protocol import Refusal, contract_path

config = json.loads(Path('/run/config/config.json').read_text())
credentials = json.loads(Path('/run/secrets/sandbox_credentials').read_text())
service = Service(config, credentials)
results = []

def assess(name, action):
    try:
        action()
        result = {'name': name, 'outcome': 'accepted'}
    except Refusal as exc:
        result = {'name': name, 'outcome': 'refused', 'status': exc.status, 'code': exc.code}
    results.append(result)

try:
    assess('original-component-tuple', service.compatibility)
    original = config['components']['deployment_sha256']
    config['components']['deployment_sha256'] = 'ab' * 32
    assess('substituted-deployment-digest', service.compatibility)
    config['components']['deployment_sha256'] = original
    # Container writable layer only; no source, running service or host file edits.
    path = contract_path('result-v1.json')
    raw = path.read_bytes()
    try:
        path.write_bytes(raw + b'\n')
        assess('changed-installed-contract-bytes', service.compatibility)
    finally:
        path.write_bytes(raw)
    continuation = json.loads(Path('/observations/c067-original-concurrency-readback/006-completed.json').read_text())
    with service.store.transaction() as tx:
        service.store.view(tx, continuation['context'])
        tx.run('MATCH (c:DraftContext {project_id:$p, context_id:$c})-[e:BASED_ON]->() DELETE e',
               p=service.project_id, c=continuation['context']['context_id']).consume()
        assess('missing-derived-context-base-edge', lambda: service.store.view(tx, continuation['context']))
        # The context manager always rolls back; the running graph stays unchanged.
finally:
    service.store.driver.close()
print(json.dumps({'schema': 'hag-packaged-audit-v1', 'results': results}, indent=2))
