"""Use a separate empty store to test real stored schema mismatches; never migrate."""
import json
import uuid
from pathlib import Path
from hosted_artifact_graph.service import Service
from hosted_artifact_graph.protocol import EVALUATOR, Refusal

config=json.loads(Path('/run/config/config.json').read_text())
credentials=json.loads(Path('/run/secrets/sandbox_credentials').read_text())
service=Service(config,credentials)
observations=[]
def snapshot():
    with service.store.driver.session() as s:
        return {'nodes':s.run('MATCH (n) RETURN count(n) AS n').single()['n'],
            'project':dict(s.run('MATCH (p:Project) RETURN properties(p) AS p').single()['p']),
            'schema':service.store.schema_inventory(s)}
def refused(name,action):
    before=snapshot()
    try:action()
    except Refusal as exc:result=exc.result()
    else:result={'unexpected_acceptance':True}
    after=snapshot()
    observations.append({'name':name,'result':result,'before':before,'after':after})
    assert result.get('error',{}).get('code')=='HAG_REMOTE_SCHEMA_MISMATCH', name
    assert before==after and after['nodes']==1 and after['project']['command_version']==0
def command():
    return service.command(next(p for p in credentials['principals'] if p['id']=='operator'),
      {'schema':'se-harness-remote-command/v1','project_id':config['project_id'],
       'operation':'import','operation_key':str(uuid.uuid4()),'expected_project_version':0,
       'expected_evaluator':EVALUATOR,'client':config['client'],'source_manifest':service.evaluator.manifest})
try:
    service.store.initialize();service.readiness()
    observations.append({'name':'explicit-initialization','result':snapshot()})
    with service.store.driver.session() as s:
        s.run('MATCH (p:Project) SET p.schema_revision=2').consume()
    refused('stored-revision-readiness',service.readiness)
    refused('stored-revision-init-does-not-migrate',service.store.initialize)
    refused('stored-revision-import-does-not-write',command)
    with service.store.driver.session() as s:
        s.run('MATCH (p:Project) SET p.schema_revision=1').consume()
        s.run('DROP INDEX ON :Project(project_id)').consume()
    refused('missing-index-readiness',service.readiness)
    refused('missing-index-init-does-not-repair',service.store.initialize)
    refused('missing-index-import-does-not-write',command)
    print(json.dumps({'state':'incompatible_stored_schema_refused','observations':observations,
        'boundary':'Dedicated negative-test volume. Original service and restoration volumes were not changed.'}))
finally:service.store.driver.close()
