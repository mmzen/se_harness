"""Native discovery of exact built archives, in fresh disposable profiles."""
import hashlib
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

base = Path(__file__).resolve().parent
package = base / 'package-04'
output = base / 'native04-exact'
output.mkdir(exist_ok=False)
marketplace = output / 'marketplace'
combination = json.loads((package/'combination.json').read_text())['payload']
results = []

for host in ('codex', 'claude'):
    archive = package/'plugin'/f'verity-plane-{host}.zip'
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == combination['plugins'][host]['archive_sha256']
    with zipfile.ZipFile(archive) as z:
        z.extractall(marketplace/host)
catalog = marketplace/'.agents/plugins/marketplace.json'
catalog.parent.mkdir(parents=True)
catalog.write_text(json.dumps({'name':'hag-exact', 'plugins':[{
    'name':'verity-plane', 'source':{'source':'local', 'path':'./codex/verity-plane'},
    'policy':{'installation':'AVAILABLE','authentication':'ON_INSTALL'}, 'category':'Productivity'}]}), encoding='utf-8')

for host, executable in [('codex', r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe'),
                         ('claude', r'C:\Users\mathi\.local\bin\claude.exe')]:
    home = output/host/'profile'; project = output/host/'project'
    project.mkdir(parents=True)
    env = {k:os.environ[k] for k in ('SYSTEMROOT','WINDIR','COMSPEC','PATHEXT','NUMBER_OF_PROCESSORS','PROCESSOR_ARCHITECTURE') if k in os.environ}
    env.update(HOME=str(home), USERPROFILE=str(home), CODEX_HOME=str(home/'codex'), CLAUDE_CONFIG_DIR=str(home/'claude'),
               APPDATA=str(home/'AppData/Roaming'),LOCALAPPDATA=str(home/'AppData/Local'),TEMP=str(home/'tmp'),TMP=str(home/'tmp'),
               PATH=os.pathsep.join([str(Path(sys.executable).parent), os.path.join(os.environ.get('SYSTEMROOT','/'),'System32'),r'C:\Program Files\Git\cmd']),NO_COLOR='1')
    for key in ('CODEX_HOME','CLAUDE_CONFIG_DIR','APPDATA','LOCALAPPDATA','TEMP'):
        Path(env[key]).mkdir(parents=True,exist_ok=True)
    (home/'codex/config.toml').write_text('cli_auth_credentials_store = "file"\ncheck_for_update_on_startup = false\n',encoding='utf-8')
    def run(name, args):
        argv = [str(x) for x in args]
        p = subprocess.run(argv,cwd=project,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=120)
        value = {'host':host,'name':name,'argv':argv,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
        (output/f'{host}-{name}.json').write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
        assert p.returncode == 0, (name,p.stderr[-500:])
        results.append({'host':host,'name':name,'exit':p.returncode})
        print(host,name,p.returncode,flush=True)
        return p.stdout
    run('version',[executable,'--version'])
    if host == 'codex':
        run('marketplace',[executable,'plugin','marketplace','add',marketplace,'--json'])
        installed = json.loads(run('installation',[executable,'plugin','add','verity-plane@hag-exact','--json']))
        plugin = Path(installed['installedPath'])
        discovered = run('discovery',[executable,'debug','prompt-input','Use verity-plane:setup for the explicitly selected private hosted sandbox.'])
        assert 'verity-plane:setup' in discovered and '/setup/SKILL.md' in discovered.replace('\\','/')
    else:
        plugin = marketplace/host/'verity-plane'
        discovered = run('discovery',[executable,'--plugin-dir',plugin,'plugin','details','verity-plane'])
        assert 'verity-plane 0.2.7' in discovered and 'change' in discovered and 'harness-orient' in discovered
    with zipfile.ZipFile(package/'plugin'/f'verity-plane-{host}.zip') as z:
        for name in z.namelist():
            if name.endswith('/'):
                continue
            actual = plugin/Path(name).relative_to('verity-plane')
            assert actual.read_bytes() == z.read(name), str(actual)
    results.append({'host':host,'installed_or_session_plugin':str(plugin),'archive_sha256':combination['plugins'][host]['archive_sha256'],'all_archive_files_match':True})
(output/'summary.json').write_text(json.dumps({'results':results,'scope':'Native CLI discovery and exact file comparison only; no model-driven walkthrough, desktop, compaction or assurance claim.'},indent=2)+'\n',encoding='utf-8')
