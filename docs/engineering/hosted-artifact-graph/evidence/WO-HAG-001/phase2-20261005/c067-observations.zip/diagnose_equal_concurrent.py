import json, traceback
from pathlib import Path
from hosted_artifact_graph.service import Service
s=Service(json.loads(Path('/run/config/config.json').read_text()),json.loads(Path('/run/secrets/sandbox_credentials').read_text()))
request=json.loads(Path('/observations/c067-boundaries/017-concurrent-equal.json').read_text())['request']
principal=next(p for p in s.credentials['principals'] if p['id']=='author-one') if hasattr(s,'credentials') else next(p for p in json.loads(Path('/run/secrets/sandbox_credentials').read_text())['principals'] if p['id']=='author-one')
class NoCommit(Exception):pass
with s.store.transaction() as tx:
 print(json.dumps({'current_version':s.store.project(tx)['command_version'],'receipt_exists':s.store.operation(tx,principal['id'],request['operation_key']) is not None}))
from concurrent.futures import ThreadPoolExecutor
before=None
with s.store.transaction() as tx:
 before=s.store.project(tx)['command_version']
def attempt():
 try:return {'result':s.command(principal,request)}
 except Exception:return {'trace':traceback.format_exc()}
with ThreadPoolExecutor(2) as pool:
 futures=[pool.submit(attempt) for _ in range(2)]
 results=[f.result() for f in futures]
with s.store.transaction() as tx:
 receipt=s.store.operation(tx,principal['id'],request['operation_key'])
 after=s.store.project(tx)['command_version']
result={'before':before,'after':after,'attempts':results,'receipt':receipt}
encoded=json.dumps(result,indent=2)
assert all(p['token'] not in encoded for p in json.loads(Path('/run/secrets/sandbox_credentials').read_text())['principals'])
Path('/observations/c067-identical-readback.json').write_text(encoded)
print(json.dumps({'before':before,'after':after,'errors':[r.get('trace') for r in results],'receipt_exists':receipt is not None}))
s.store.driver.close()
