import json, traceback
from pathlib import Path
from hosted_artifact_graph.service import Service
s=Service(json.loads(Path('/run/config/config.json').read_text()),json.loads(Path('/run/secrets/sandbox_credentials').read_text()))
request=json.loads(Path('/observations/c067-boundaries/017-concurrent-equal.json').read_text())['request']
principal=next(p for p in s.credentials['principals'] if p['id']=='author-one') if hasattr(s,'credentials') else next(p for p in json.loads(Path('/run/secrets/sandbox_credentials').read_text())['principals'] if p['id']=='author-one')
class NoCommit(Exception):pass
with s.store.transaction() as tx:
 print(json.dumps({'current_version':s.store.project(tx)['command_version'],'receipt_exists':s.store.operation(tx,principal['id'],request['operation_key']) is not None}))
def stop(stage,tx):
 if stage=='after_evaluation':raise NoCommit('Preparation succeeded; diagnostic stopped before transaction')
try:s.command(principal,request,fault=stop)
except NoCommit as exc:print(str(exc))
except Exception:traceback.print_exc()
finally:s.store.driver.close()
