import json,logging,sys,traceback
from hosted_artifact_graph.__main__ import main
class Diagnostic(logging.Handler):
 def emit(self,record):
  kind,exc,tb=sys.exc_info()
  if kind is not None:
   print(json.dumps({'diagnostic_error_type':kind.__name__,'frames':[{'file':f.filename,'line':f.lineno,'function':f.name} for f in traceback.extract_tb(tb)]}),flush=True)
logging.getLogger('harness.hosted').addHandler(Diagnostic())
sys.argv=['harness-hosted','serve']
main()
