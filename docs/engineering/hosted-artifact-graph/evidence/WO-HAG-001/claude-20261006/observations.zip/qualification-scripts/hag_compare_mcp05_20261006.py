"""Compare actual native MCP responses with HTTP, retaining the host-spilled response."""
import datetime, hashlib, json, re, time, urllib.request
from pathlib import Path
W=Path(__file__).resolve().parent;O=W/'hag-claude-20261006';N=O/'native05'
j=json.loads((N/'mcp-session.json').read_text())
events=[json.loads(line) for line in j['stdout'].splitlines() if line.startswith('{')]
expected={r['operation']:r for r in json.loads((N/'project/mcp-requests.json').read_text())}
uses={};actual={};spills=[]
for event in events:
    for block in event.get('message',{}).get('content',[]) if isinstance(event.get('message'),dict) else []:
        if not isinstance(block,dict):continue
        if block.get('type')=='tool_use':uses[block['id']]=block
        if block.get('type')!='tool_result':continue
        use=uses.get(block.get('tool_use_id'),{})
        if not use.get('name','').startswith('mcp__hag__'):continue
        op=use['input']['operation'];assert use['input']==expected[op]
        content=block['content']
        if isinstance(content,str):
            found=re.search(r'Output has been saved to (.+?\.txt)',content)
            assert found,content[:200]
            file=Path(found.group(1));raw=file.read_bytes()
            content=json.loads(raw)
            copy=N/'impact-native-tool-output.json'
            if copy.exists():assert copy.read_bytes()==raw
            else:copy.write_bytes(raw)
            spills.append({'operation':op,'source':str(file),'retained':copy.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'model_read_full_spill':False})
        if isinstance(content,list):
            assert len(content)==1 and content[0]['type']=='text'
            response=json.loads(content[0]['text'])
        else:response=content
        assert response['operation']==op and not response['unresolved_references']
        if op=='impact':
            assert response['complete'] is False and response['continuation']['reason']=='row_limit'
        else:
            assert response['complete'] is True and response['continuation'] is None
        assert op not in actual
        actual[op]=response
assert set(actual)==set(expected)
final=next(e for e in events if e.get('type')=='result')
assert j['exit']==0 and not final['is_error'] and not final.get('permission_denials')
credentials=json.loads((O/'package-05/credentials.json').read_text())
token=next(p['token'] for p in credentials['principals'] if p['id']=='operator')
out=[]
for op,request in expected.items():
    url='http://127.0.0.1:18088/v1/projects/'+request['project_id']+'/reads/'+op
    started=time.monotonic()
    req=urllib.request.Request(url,data=json.dumps(request).encode(),headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=180) as response:
        status=response.status;http=json.load(response)
    assert status==200 and http==actual[op],op
    out.append({'operation':op,'url':url,'request':request,'http_status':status,'http':http,'native_mcp':actual[op],'equal':True,'complete':actual[op]['complete'],'seconds':round(time.monotonic()-started,3)})
    print(json.dumps({'operation':op,'exact_http_mcp_match':True,'complete':actual[op]['complete']}),flush=True)
data={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'comparisons':out,'host_output_spills':spills,'limits':'Seven native tools ran. Six responses are complete; impact correctly reports row_limit and complete=false. Claude incorrectly called that response complete without inspecting the spill. Impact was saved by Claude Code rather than fully exposed to the model. This comparison inspected and retained that exact spill. Native narrative text is not a gate verdict.'}
encoded=json.dumps(data,ensure_ascii=False,indent=2)
assert all(p['token'] not in encoded for p in credentials['principals'])
dest=N/'http-mcp-comparison.json';assert not dest.exists();dest.write_text(encoded+'\n',encoding='utf-8')
