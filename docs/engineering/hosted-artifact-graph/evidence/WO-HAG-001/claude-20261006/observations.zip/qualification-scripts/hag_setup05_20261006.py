"""Prepare an isolated local candidate-05 sandbox; preserve every prior volume."""
import json, os, sys, time, zipfile
import hag221_execute as h
h.O=h.W/'hag-claude-20261006'
O=h.O
package=O/'package-05'
combo=json.loads((package/'combination.json').read_text())
assert combo['payload']['source']['candidate_commit']=='5fa50787dba1fdd010f625335d844416dd3bf002'
client=O/'client-environment-05'
assert not client.exists()
h.run('client-environment-05',[sys.executable,'-m','venv',client])
h.run('client-install-05',[client/'Scripts/python.exe','-I','-m','pip','install','--no-deps','--no-index',O/'client-build-05/se_harness-0.22.2-py3-none-any.whl'])
extracted=O/'native05-exact/marketplace/claude'
assert not extracted.exists()
with zipfile.ZipFile(package/'plugin/verity-plane-claude.zip') as z:
    assert all(name.startswith('verity-plane/') and '..' not in name.split('/') for name in z.namelist())
    z.extractall(extracted)
project='hagmcp20261006'
env=dict(os.environ,HAG_SERVICE_IMAGE='harness-hag:mcp-05',HAG_HTTP_PORT='18088',HAG_SOURCE_VOLUME='hagphase220261005_source',HAG_CONFIG_DIRECTORY=str(package/'configuration'),HAG_CREDENTIAL_FILE=str(package/'credentials.json'))
compose=['docker','compose','-p',project,'-f',package/'candidate-source/server/compose.yaml']
h.run('sandbox-05-volume-absent',['docker','volume','inspect',project+'_graph_data'],allow=(1,))
h.write(O/'sandbox-05-selection.json',{'compose_argv':list(map(str,compose)),'environment':{k:v for k,v in env.items() if k.startswith('HAG_')},'endpoint':'http://127.0.0.1:18088'})
h.run('sandbox-05-graph-up',compose+['up','-d','graph'],env=env)
time.sleep(3)
h.run('sandbox-05-initialize',compose+['run','--rm','service','init'],env=env)
h.run('sandbox-05-service-up',compose+['up','-d','service'],env=env)
time.sleep(2)
h.run('sandbox-05-ready',compose+['exec','-T','service','python','-m','hosted_artifact_graph','ready'],env=env)
h.run('runtime-installed-05',['docker','run','--rm','--mount','type=bind,src='+str(h.R/'tests/hosted_artifact_graph')+',dst=/qualification,readonly','--entrypoint','python','harness-hag:mcp-05','-m','unittest','discover','-s','/qualification','-p','test_runtime.py','-v'])
print(json.dumps({'sandbox':project,'endpoint':'http://127.0.0.1:18088','combination':combo['combination_id']}),flush=True)
