"""Observe the exact candidate through a native Claude session; retain no credentials."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import threading
import zipfile

W = Path(__file__).resolve().parent
R = W / 'hag221proposal'
P = W / 'hag-claude-20261006'
O = W / 'hag-claude-20261006/native05'
O.mkdir(exist_ok=False)
project = O / 'project'
project.mkdir()
plugin = P / 'native05-exact/marketplace/claude/verity-plane'
combo = json.loads((P / 'package-05/combination.json').read_text())
payload = combo['payload']
assert payload['source']['candidate_commit'] == '5fa50787dba1fdd010f625335d844416dd3bf002'
secrets = [v['token'] for v in json.loads((P / 'package-05/credentials.json').read_text())['principals']]

def safe(text):
    assert all(s not in text for s in secrets), 'Sandbox secret in output; not retained'
    assert not re.search(r'sk-ant-(?:oat|ort|api)\S+', text), 'Possible provider secret; not retained'
    return text

def save(name, data):
    path = O / name
    assert not path.exists()
    path.write_text(safe(json.dumps(data, ensure_ascii=False, indent=2)) + '\n', encoding='utf-8')

def observed(name, argv, cwd=W):
    result = subprocess.run([str(x) for x in argv], cwd=cwd, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120)
    save(name, {'argv':[str(x) for x in argv], 'cwd':str(cwd), 'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit':result.returncode, 'stdout':result.stdout, 'stderr':result.stderr})
    assert result.returncode == 0, name
    return result.stdout

archive = P / 'package-05/plugin/verity-plane-claude.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == payload['plugins']['claude']['archive_sha256']
files = []
with zipfile.ZipFile(archive) as z:
    for name in z.namelist():
        if name.endswith('/'):
            continue
        file = plugin / Path(name).relative_to('verity-plane')
        raw = file.read_bytes()
        assert raw == z.read(name), name
        files.append({'path':str(file), 'sha256':hashlib.sha256(raw).hexdigest()})
wheel = P / 'client-build-05/se_harness-0.22.2-py3-none-any.whl'
assert hashlib.sha256(wheel.read_bytes()).hexdigest() == payload['client']['wheel_sha256']
for rel in ('tests/hosted_artifact_graph/qualify_service.py', 'tests/hosted_artifact_graph/fixtures/scenarios-v1.json'):
    raw = subprocess.check_output(['git','show',payload['source']['candidate_commit']+':'+rel], cwd=R)
    assert (R/rel).read_bytes().replace(b'\r\n',b'\n') == raw.replace(b'\r\n',b'\n'), rel
service = json.loads(observed('service-identity.json',['docker','inspect','--format','{{json .}}','hagmcp20261006-service-1']))
assert service['Image'] == payload['server']['image_manifest']
assert service['State']['Running']
claude = r'C:\Users\mathi\.local\bin\claude.exe'
version = observed('claude-version.json',[claude,'--version']).strip()
save('candidate-binding.json', {'combination_id':combo['combination_id'], 'candidate':payload['source']['candidate_commit'], 'plugin_archive_sha256':payload['plugins']['claude']['archive_sha256'], 'client_wheel_sha256':payload['client']['wheel_sha256'], 'service_image_manifest':service['Image'], 'claude_version':version, 'model':'claude-haiku-4-5-20251001', 'plugin_files':files, 'credential_handling':'Normal host credential store; no OAuth credentials copied; no permanent plugin installation.'})
argv = json.loads((W/'hag-phase2-20261005/protocol04-walkthrough.json').read_text())['argv']
for flag,value in {'--client-python':P/'client-environment-05/Scripts/python.exe','--client-wheel':P/'client-build-05/se_harness-0.22.2-py3-none-any.whl','--configuration':P/'package-05/configuration/config.json','--credentials':P/'package-05/credentials.json','--endpoint':'http://127.0.0.1:18088'}.items():
    argv[argv.index(flag)+1]=str(value)
argv[argv.index('--output')+1] = str(O/'walkthrough')
entry = project/'run_walkthrough.py'
entry.write_text('import subprocess,sys\nargs='+repr(argv)+'\np=subprocess.run(args,cwd='+repr(str(O))+')\nsys.exit(p.returncode)\n', encoding='utf-8')
command = shlex.quote(Path(sys.executable).as_posix()) + ' -B run_walkthrough.py'
prompt = ('Run the authorized WO-HAG-001 private hosted sandbox qualification. The user explicitly requested Claude tests. '
    'First read the hosted sandbox sections of '+str(plugin/'skills/setup/SKILL.md')+' and '+str(plugin/'skills/change/SKILL.md')+'. '
    'The exact candidate plugin 0.2.7 is loaded only for this session; candidate client 0.22.2 is separately installed. '
    'The repository and hosted service continue to use released evaluator 0.22.1. The candidate combination was byte-checked before this call. '
    'The private service is already running on http://127.0.0.1:18088 with public disposable reference data. '
    'Read '+str(entry)+', then use Bash to run exactly: '+command+'. Set timeout 600000 and wait for its result. '
    'This inspected entry executes the actual installed remote CLI for import, context, draft creation and valid revision, '
    'invalid/stale/key-reuse refusals, accepted retry, unchanged baseline, comparison, Cypher, evaluator check and freeze. '
    'Its expected refusal exits are part of the test. Each real command/result is retained outside the repository. '
    'Read '+str(O/'walkthrough/walkthrough.json')+' after completion and report only actual observations. '
    'Call Cypher a graph query, freeze a baseline snapshot rather than a lifecycle decision, and retry the recovery of the original accepted receipt. '
    'The embedded checkpoint-free check reports context and does not mean its gates passed. Do not invent timing totals. '
    'Do not read authentication or credential files, print environment variables, edit files, install anything, spawn subagents, '
    'make lifecycle decisions, push, deploy or run other commands. No desktop or full qualification claim is permitted. '
    'If any tool is denied, stop and report it; do not change permissions or choose another execution route.')
args = [claude,'--plugin-dir',str(plugin),'-p','--model','claude-haiku-4-5-20251001','--no-session-persistence',
    '--tools','Read,Bash','--allowedTools','Read','Bash('+command+')','--output-format','stream-json','--verbose',prompt]
env = dict(os.environ, CLAUDE_CONFIG_DIR=r'C:\Users\mathi\.claude', PYTHONUTF8='1', NO_COLOR='1')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
lines = []
with subprocess.Popen(args,cwd=project,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace') as child:
    timer = threading.Timer(900, child.kill)
    timer.start()
    try:
        for line in child.stdout:
            safe(line)
            lines.append(line)
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if event.get('type') == 'system' and event.get('subtype') == 'init':
                print(json.dumps({'event':'native_init','model':event.get('model'),'plugins':event.get('plugins')}),flush=True)
            for block in event.get('message',{}).get('content',[]) if isinstance(event.get('message'),dict) else []:
                if isinstance(block,dict) and block.get('type') == 'tool_use':
                    print(json.dumps({'event':'tool_use','tool':block.get('name')}),flush=True)
            if event.get('type') == 'result':
                print(json.dumps({'event':'result','is_error':event.get('is_error'),'result':event.get('result')}),flush=True)
        code = child.wait()
    finally:
        timer.cancel()
save('native-session.json', {'argv':args,'cwd':str(project),'observed_at':started,'exit':code,'stdout':''.join(lines),'claim':'Native Claude reads exact candidate guidance and launches a real installed-client walkthrough; not desktop or full host qualification.'})
print(json.dumps({'exit':code,'record':str(O/'native-session.json'),'walkthrough_exists':(O/'walkthrough/walkthrough.json').exists()}),flush=True)
sys.exit(code)
