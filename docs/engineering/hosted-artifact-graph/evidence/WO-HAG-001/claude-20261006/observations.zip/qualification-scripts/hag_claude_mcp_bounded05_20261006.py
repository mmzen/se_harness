"""Native Claude MCP reads on the same candidate and explicit walkthrough views."""
import datetime, hashlib, json, os, re, subprocess, threading
from pathlib import Path
W=Path(__file__).resolve().parent
O=W/'hag-claude-20261006/native05'
P=W/'hag-claude-20261006'
project=O/'project'
plugin=P/'native05-exact/marketplace/claude/verity-plane'
dest=O/'mcp-bounded-session.json'
assert not dest.exists()
config=json.loads((P/'package-05/configuration/config.json').read_text())
credentials=json.loads((P/'package-05/credentials.json').read_text())
token=next(p['token'] for p in credentials['principals'] if p['id']=='operator')
walk=json.loads((O/'walkthrough/walkthrough.json').read_text())
revised=json.loads(json.loads((O/'walkthrough/009-revise-body-and-relation-result.json').read_text())['stdout'])
baseline=walk['baseline'];context=walk['context'];binding=revised['affected_artifacts'][0]
def request(op,view=baseline,**kw):
    return dict(schema='se-harness-graph-read/v1',project_id=config['project_id'],operation=op,view=view,budget={'rows':500,'bytes':2097152,'depth':8},**kw)
requests=[request('revision',context,**binding),request('work-context',work_order_id='WO-RLS-038'),
    request('compare',{'kind':'comparison','left':baseline,'right':context}),request('impact',artifact_id='CAP-IAR-002'),
    request('lineage',artifact_id='VREC-RLS-002'),request('check',artifact_id='WO-RLS-038'),
    request('cypher',query='MATCH (r:Revision) WHERE r.artifact_id = $id RETURN r.artifact_id AS id LIMIT 5',parameters={'id':'WO-RLS-038'})]
requests=[r for r in requests if r['operation']=='impact']
requests[0]['budget']['rows']=1
selection=project/'mcp-bounded-request.json'
assert not selection.exists()
selection.write_text(json.dumps(requests,indent=2)+'\n',encoding='utf-8')
mcpconfig=O/'mcp-bounded-config.json'
mcpconfig.write_text(json.dumps({'mcpServers':{'hag':{'type':'http','url':'http://127.0.0.1:18088/mcp','headers':{'Authorization':'Bearer ${HAG_NATIVE_TEST_TOKEN}'},'timeout':180000}}},indent=2)+'\n',encoding='utf-8')
prompt=('Test the same authorized WO-HAG-001 private sandbox through native Claude MCP tools. '
    'Read the hosted sandbox sections of '+str(plugin/'skills/setup/SKILL.md')+' and '+str(plugin/'skills/harness-orient/SKILL.md')+'. '
    'The exact candidate tuple is plugin 0.2.7, remote client 0.22.2, service 0.1.0.dev1, released evaluator 0.22.1; the operator verified readiness and identities immediately before this read-only test. '
    'Use ToolSearch if needed to discover the configured hag impact tool. Read '+str(selection)+' and call the hag impact tool once with its exact corresponding JSON request. '
    'Keep the complete given project, baseline/context, guards and budgets. This is a real private HTTP MCP endpoint with public disposable fixture data; authentication is configured outside the prompt. '
    'Do not use Bash, edit files, run other commands, inspect credentials, make mutations, spawn subagents, change permissions or substitute an execution route after refusal. '
    'Report the returned complete field, continuation.reason and whether this response supports a complete governing-context claim. Do not infer completeness from transport success. A checkpoint-free evaluator check is lifecycle context, not passed gates. '
    'Cypher is a graph query, not cryptographic verification. Freeze creates an immutable baseline, not a lifecycle approval. '
    'Do not claim full qualification, desktop coverage, verification acceptance, or lifecycle actions from successful reads.')
claude=r'C:\Users\mathi\.local\bin\claude.exe'
args=[claude,'--plugin-dir',str(plugin),'--mcp-config',str(mcpconfig),'--strict-mcp-config','-p','--model','claude-haiku-4-5-20251001',
    '--no-session-persistence','--tools','Read,ToolSearch','--allowedTools','Read','ToolSearch',*[f"mcp__hag__{r['operation']}" for r in requests],'--output-format','stream-json','--verbose',prompt]
env=dict(os.environ,CLAUDE_CONFIG_DIR=r'C:\Users\mathi\.claude',HAG_NATIVE_TEST_TOKEN=token,PYTHONUTF8='1',NO_COLOR='1')
started=datetime.datetime.now(datetime.timezone.utc).isoformat(); lines=[]
with subprocess.Popen(args,cwd=project,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace') as child:
    timer=threading.Timer(600,child.kill);timer.start()
    try:
        for line in child.stdout:
            assert all(p['token'] not in line for p in credentials['principals'])
            assert not re.search(r'sk-ant-(?:oat|ort|api)\S+',line)
            lines.append(line)
            try:e=json.loads(line)
            except ValueError:continue
            if e.get('type')=='system' and e.get('subtype')=='init':print(json.dumps({'event':'mcp_init','servers':e.get('mcp_servers'),'tools':[t for t in e.get('tools',[]) if 'hag' in t]}),flush=True)
            for b in e.get('message',{}).get('content',[]) if isinstance(e.get('message'),dict) else []:
                if isinstance(b,dict) and b.get('type')=='tool_use':print(json.dumps({'event':'tool_use','tool':b.get('name')}),flush=True)
            if e.get('type')=='result':print(json.dumps({'event':'result','is_error':e.get('is_error'),'result':e.get('result')}),flush=True)
        code=child.wait()
    finally:timer.cancel()
record={'argv':args,'cwd':str(project),'observed_at':started,'exit':code,'stdout':''.join(lines),'claim':'Native Claude MCP read observations; no lifecycle or desktop qualification claim.'}
dest.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'exit':code,'record':str(dest)}),flush=True)
raise SystemExit(code)
