from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_efficiency_close08.py').read_text()
source=source.replace('hag-efficiency-entry-20261009','hag-efficiency-diagnostic-20261010').replace('hag-efficiency08-','hag-efficiency21-')
source=source.replace("assert trial in ('claude-21','claude-22','claude-23','claude-24')", "assert trial in ('claude-151','claude-152','claude-153','claude-154','codex-151','codex-152')")
exec(compile(source,'close16','exec'),{'__file__':__file__,'__name__':'__main__'})
