import json,sys
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'hag-efficiency-diagnostic-20261010';trial=sys.argv[1];root=O/trial;native=root/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8'))
entry=load(native/'instruction-entry.json')
instruction_bytes=sum(len(s['content'].encode()) for r in entry['instruction_view']['resources'] for s in r['sections'])
task_bytes=(native/'task.md').stat().st_size
breakdown={'canonical_instruction_bytes':instruction_bytes,'selected_reference_bytes':entry['reference_bytes'],'complete_fixture_bytes':entry['source_bytes'],'selection_provenance_fences_and_labels_bytes':entry['entry_bytes']-instruction_bytes-entry['reference_bytes']-entry['source_bytes'],'remaining_task_and_host_instructions_bytes':task_bytes-entry['entry_bytes'],'total_task_bytes':task_bytes}
calls={};results=[]
for line in (native/'events.jsonl').read_text(encoding='utf-8').splitlines():
    try:e=json.loads(line)
    except ValueError:continue
    if e.get('type') in ('assistant','user'):
        message=e.get('message',{})
        for block in message.get('content',[]) if isinstance(message,dict) else []:
            if block.get('type')=='tool_use':calls[block['id']]={'tool':block['name'],'path':block.get('input',{}).get('file_path')}
            elif block.get('type')=='tool_result':
                content=block.get('content','')
                text=content if isinstance(content,str) else json.dumps(content,ensure_ascii=False)
                results.append({**calls.get(block.get('tool_use_id'),{}),'characters':len(text),'error':block.get('is_error',False)})
    elif e.get('type')=='item.completed' and e.get('item',{}).get('type')=='command_execution':
        item=e['item'];results.append({'tool':'command_execution','item':item['id'],'characters':len(item.get('aggregated_output','')),'exit':item.get('exit_code')})
records=[]
for f in (native/'work').iterdir():
    if not f.is_file() or f.stat().st_size>4194304:continue
    try:x=load(f)
    except (ValueError,UnicodeError):continue
    if isinstance(x,dict) and isinstance(x.get('argv'),list) and isinstance(x.get('elapsed_seconds'),(int,float)):
        records.append({'file':f.name,'elapsed_seconds':x['elapsed_seconds'],'exit':x.get('exit')})
value={'trial':trial,'entry_bytes':breakdown,'visible_tool_result_characters':sum(x['characters'] for x in results),'tool_results':results,'client_commands':records,'recorded_client_seconds':sum(x['elapsed_seconds'] for x in records),'limits':'Characters and bytes are not token counts. Private reasoning is excluded. Captured command times do not explain all native wall time; the remainder is unclassified. Codex event capture does not expose a verified complete call or peak-token total.'}
dest=O/(trial+'-costs.json');assert not dest.exists();dest.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'trial':trial,'entry_bytes':breakdown,'recorded_client_seconds':value['recorded_client_seconds'],'visible_tool_result_characters':value['visible_tool_result_characters']},indent=2))
