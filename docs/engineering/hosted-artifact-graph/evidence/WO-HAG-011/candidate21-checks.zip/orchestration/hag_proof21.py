import hashlib,json,subprocess,sys,zipfile
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'hag-efficiency-diagnostic-20261010'
trial=sys.argv[1];N=O/trial/'native'
load=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda raw:hashlib.sha256(raw).hexdigest()
candidate=load(O/'candidate-21.json')['commit']
packet=load(N/'instruction-entry.json');task=(N/'task.md').read_bytes()
assert len(task)<=65536
assert b'diagnostic_scope' not in task and b'EFF-04A2' not in task
if trial.endswith('-151'):
 contract=(p.D/'verification/VER-HAG-008.md').read_text()
 section=contract.split('#### EFF-04A2',1)[1].split('#### EFF-04B',1)[0]
 request=' '.join(line.removeprefix('> ').strip() for line in section.splitlines() if line.startswith('>'))
 assert request.encode() in task
invocation=load(N/'invocation.json');assert invocation['input_delivery']=='complete-inputs'
assert invocation['input_sha256']['driver']==sha(subprocess.check_output(['git','show',candidate+':tests/hosted_artifact_graph/qualify_agents.py'],cwd=p.R))
assert invocation['input_sha256']['task_file']==sha(task)
assert invocation['prompt_transport']=='stdin-complete-entry'
assert invocation['initial_prompt'].encode()==task
assert invocation['input_sha256']['effective_prompt']==sha(task)
sections=0
for resource in packet['instruction_view']['resources']:
 raw=Path(resource['path']).read_bytes();assert sha(raw)==resource['sha256']
 assert resource['release']['version']=='0.22.1'
 lines=raw.decode().splitlines(keepends=True)
 for section in resource['sections']:
  exact=''.join(lines[section['start_line']-1:section['end_line']])
  assert exact==section['content'] and sha(exact.encode())==section['content_sha256']
  assert task.count(exact.encode())==1
  sections+=1
assert sections==9
source=N/'inputs/source'
files=packet['complete_input_files']['sources']
assert {str(x) for x in source.rglob('*') if x.is_file()}=={x['path'] for x in files}
for item in files+packet['complete_input_files']['references']:
 raw=Path(item['path']).read_bytes()
 assert raw==item['text'].encode() and len(raw)==item['bytes'] and sha(raw)==item['sha256']
 assert task.count(raw)==1, item['path']
manifest=load(N/'inputs/source-manifest.json')
assert len(manifest['artifacts'])==7
for item in manifest['artifacts']:
 raw=(source/item['path']).read_bytes();assert sha(raw)==item['raw_sha256']
setting=load(N/'selection.json');original=load(O/trial/'selection.json')
git_files=subprocess.check_output(['git','ls-tree','-r','--name-only',setting['source_commit']],cwd=original['source_directory'],text=True).splitlines()
assert set(git_files)=={Path(x['path']).relative_to(source).as_posix() for x in files}
for name in git_files:
 raw=subprocess.check_output(['git','show',setting['source_commit']+':'+name],cwd=original['source_directory'])
 assert raw==(source/name).read_bytes(),name
variants={}
for host in ('claude','codex'):
 archive=O/'package21/plugin'/('verity-plane-'+host+'.zip')
 references={}
 with zipfile.ZipFile(archive) as z:
  for relative in ('skills/change/references/hosted-drafts.md','skills/setup/references/hosted-context.md'):
   names=[n for n in z.namelist() if n.endswith(relative)]
   assert len(names)==1
   raw=z.read(names[0]);assert raw==subprocess.check_output(['git','show',candidate+':plugins/verity-plane/common/'+relative],cwd=p.R)
   references[relative]=sha(raw)
 variants[host]={'archive_sha256':sha(archive.read_bytes()),'reference_sha256':references}
wheel=O/'build21/se_harness-0.22.2-py3-none-any.whl'
previous=p.W/'hag-efficiency-inputs-20261010/build15/se_harness-0.22.2-py3-none-any.whl'
with zipfile.ZipFile(wheel) as a,zipfile.ZipFile(previous) as b:
 assert set(a.namelist())==set(b.namelist())
 changed=[n for n in a.namelist() if a.read(n)!=b.read(n)]
 assert changed==[],changed
 runtime={'candidate_archive_sha256':sha(wheel.read_bytes()),'reference_archive_sha256':sha(previous.read_bytes()),'members':len(a.namelist()),'changed_member_payloads':changed,'changed_member_timestamps':sum(a.getinfo(n).date_time!=b.getinfo(n).date_time for n in a.namelist()),'reuse_limit':'Candidate15 EFF-02/03 evidence applies to identical runtime member contents, not archive identity or the changed native input delivery.'}
record={'candidate':candidate,'trial':trial,'sections_exact':sections,'source_files_exact':len(files),'imported_source_records':7,'task_bytes':len(task),'source_bytes':packet['source_bytes'],'reference_bytes':packet['reference_bytes'],'entry_preparation_seconds':invocation['entry_preparation_seconds'],'packaged_variants':variants,'runtime_comparison':runtime,'limit':'Explicit complete-input test route. No automatic startup, desktop or compaction qualification. Content quality requires independent assessment.'}
dest=O/(trial+'-component-review.json');assert not dest.exists();dest.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
