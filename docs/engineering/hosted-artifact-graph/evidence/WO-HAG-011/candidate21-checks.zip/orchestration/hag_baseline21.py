import base64,json,os,subprocess,sys
from pathlib import Path
import hag221_execute as h
h.O=h.W/'hag-efficiency-diagnostic-20261010';trial=sys.argv[1];root=h.O/trial;native=root/'native'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
s=load(root/'selection.json');token=next(x['token'] for x in load(root/'credentials.json')['principals'] if x['id']=='operator')
manifest={x['artifact_id']:x for x in load(native/'inputs/source-manifest.json')['artifacts']}
imports=[]
for path in (native/'work').rglob('*'):
    if not path.is_file() or path.stat().st_size>4*1024*1024:continue
    try:record=load(path);response=json.loads(record['stdout']);result=response.get('result',response)
    except (ValueError,KeyError,TypeError,UnicodeError):continue
    if 'import' in record.get('argv',[]) and result.get('outcome')=='accepted':imports.append(result)
assert len(imports)==1
result=imports[0];rows=[]
for item in result['affected_artifacts']:
    key=item['artifact_id'];source=manifest[key]
    request={'schema':'se-harness-graph-read/v1','operation':'revision','project_id':s['project_id'],'view':result['view'],'artifact_id':key,'revision_id':item['revision_id'],'budget':{'rows':1,'bytes':2097152,'depth':0}}
    path=root/('baseline-'+key+'.json');assert not path.exists();h.write(path,request)
    observed=h.run(trial+'-baseline-'+key,[s['client_python'],'-I','-m','se_harness','remote','read','--endpoint',s['endpoint'],'--project',s['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--request',path,'--json'],env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token))
    raw=base64.b64decode(observed['data']['document_base64'],validate=True)
    assert raw==(native/'inputs/source'/source['path']).read_bytes() and h.sha(raw)==source['raw_sha256']
    rows.append({'id':key,'revision_id':item['revision_id'],'sha256':h.sha(raw),'exact_bytes':True})
path=root/'immutable-baseline-review.json';assert not path.exists();h.write(path,{'baseline':result['view'],'records':rows,'source':'Separate post-run service reads compared with exact source-manifest Git-blob bytes.'})
print(json.dumps({'trial':trial,'unchanged_imported_records':len(rows)}))
