"""Run the existing clean-candidate checker with a separate evidence destination."""
from pathlib import Path
source=(Path(__file__).parent/'hag_native_candidate_checks.py').read_text()
source=source.replace("workspace/'hag-native-verification'/'candidate-test-outputs'", "workspace/'hag-c45'/'candidate-test-outputs'")
exec(compile(source,'candidate45-checks','exec'))
