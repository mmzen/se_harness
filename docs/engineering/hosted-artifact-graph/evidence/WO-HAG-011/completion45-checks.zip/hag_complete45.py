"""Released completion and verification preparation for reviewed WO-HAG-011."""
import hashlib,json,subprocess,sys,tomllib,zipfile
from pathlib import Path
import hag_efficiency_plan as p
W,R,D=p.W,p.R,p.D;O=W/'hag-c45/closeout';O.mkdir(exist_ok=True);p.O=O
E=D/'evidence/WO-HAG-011';F=E/'qualified45-result'
C='829e6f05f2915492be1c7b541e7944a5d33c45ca';BASE='55caaada508495bea7d97effd27644d1ce8373da';ID='VREC-HAG-007'
load=lambda f:json.loads(f.read_bytes());sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R).decode().strip()
def put(f,v):f.write_bytes((v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
def brief(v):return {k:v.get(k) for k in ['operation','state','compliance','restitution']}
def retain():
 files=list(O.glob('*.json'))+[W/'hag_complete45.py',W/'hag_candidate45_checks.py',W/'hag_native_candidate_checks.py']
 with zipfile.ZipFile(E/'completion45-checks.zip','w',zipfile.ZIP_DEFLATED) as z:
  for f in sorted(files):z.writestr(f.name,f.read_bytes())
 put(E/'completion45-checks-inventory.json',{'archive':'completion45-checks.zip','sha256':sha((E/'completion45-checks.zip').read_bytes()),'files':[{'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in sorted(files)]})
mode=sys.argv[1]
if mode=='scope':
 paths=['docs/engineering/hosted-artifact-graph/README.md','docs/notes/hosted-artifact-graph.md','docs/engineering/hosted-artifact-graph/work-orders/WO-HAG-011.md']
 paths += [(E/n).relative_to(R).as_posix() for n in ['WO-HAG-011-handoff.md','handoff.json','verification45-change-set.json','completion45-checks.zip','completion45-checks-inventory.json','candidate45-tests.zip','candidate45-tests-inventory.json','verification45-preparation.json']]
 v=p.gov('preparation-scope','check',R,'--artifact','WO-HAG-011','--checkpoint','scope','--changes-complete',*[a for path in paths for a in ('--changed-path',path)],'--json');assert v['compliance']['status']=='pass';print('Completion/preparation scope passes',flush=True)
elif mode=='prepare':
 assert git('rev-parse','HEAD')==C
 assert json.loads(load(O/'preparation-scope.json')['stdout'])['compliance']['status']=='pass'
 for f in F.glob('*-inventory.json'):
  inv=load(f);archive=F/inv['archive'];assert sha(archive.read_bytes())==inv['sha256']
  with zipfile.ZipFile(archive) as z:
   assert set(z.namelist())=={x['path'] for x in inv['files']}
   assert all(sha(z.read(x['path']))==x['sha256'] for x in inv['files'])
 f=D/'README.md';s=f.read_text();start=s.index('## Current native qualification');end=s.index('## Historical qualification observations')
 s=s[:start]+'''## Current native qualification

mmzen verified [VREC-HAG-006](verification-records/VREC-HAG-006.md) for
WO-HAG-009/010 at its exact recorded candidate. Both CLI hosts passed all five
VER-HAG-007 lifecycle cases. The [consolidation](evidence/WO-HAG-009/consolidation.md)
retains twelve replayed operations and seven MCP/HTTP comparisons per host,
including the disclosed Codex two-tool read-only supplement.

The [new focused drafting assessment](evidence/WO-HAG-011/qualified45-result/assessment.md)
records the WO-HAG-011 correction and its exact candidate. Both missing-input
diagnostics, three fresh Claude positive drafts and one Codex positive draft pass.
Earlier failures remain in their original reports. Duration and context goals
remain missed or unavailable; they are separate from correctness. Human
verification of this correction is pending. PR #543 remains draft.

Git remains authoritative. No production, desktop, public delivery, host update
or risk acceptance is claimed.

'''+s[end:];put(f,s)
 f=R/'docs/notes/hosted-artifact-graph.md';s=f.read_text();old='records their exact inputs and limits. Human verification remains pending.\nThe separate WO-HAG-011 focused drafting failures remain unresolved.';assert old in s
 s=s.replace(old,'records their exact inputs and limits. mmzen verified\n[VREC-HAG-006](../engineering/hosted-artifact-graph/verification-records/VREC-HAG-006.md)\nfor that recorded candidate. The subsequent\n[WO-HAG-011 drafting correction](../engineering/hosted-artifact-graph/evidence/WO-HAG-011/qualified45-result/assessment.md)\npasses its focused content checks and awaits separate human verification.\nDuration and context goals remain missed or unavailable.');put(f,s)
 retain()
 rel=(E/'verification45-change-set.json').relative_to(R).as_posix()
 paths=set(git('diff','--name-only',BASE).splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())|{rel,(E/'WO-HAG-011-handoff.md').relative_to(R).as_posix(),(E/'handoff.json').relative_to(R).as_posix()}
 scope=tomllib.loads((D/'work-orders/WO-HAG-011.md').read_text().split('+++')[1])['execution_scope']['paths']
 selected=[q for q in sorted(paths) if any(q==s or (s.endswith('/') and q.startswith(s)) for s in scope)]
 put(R/rel,{'schema':'se-harness-change-set-v1','complete':True,'paths':selected})
 print('Prepared current indexes, reviewed archives and complete admitted WO change manifest.',flush=True)
elif mode=='handoff':
 v=p.gov('review-preflight','preflight',R,'--work-order','WO-HAG-011','--phase','review','--json');assert v['ready']
 v=p.gov('evidence-packet','evidence',R,'--artifact','WO-HAG-011','--checkpoint','handoff','--json');print('evidence',json.dumps(v),flush=True)
 f=E/'WO-HAG-011-handoff.md';assert f.exists();raw=f.read_bytes();marker=b'## Qualified correction 45';assert marker not in raw
 f.write_bytes(raw+b'\n## Qualified correction 45\n\nSee [qualified45-result/assessment.md](qualified45-result/assessment.md) for the requirement assessment, exact candidate, native results, earlier failures and measured limits. The six case archives retain original inputs, commands, saved records, independent readback and visible transcripts. Provenance binds the installed packages and unchanged-client evidence reuse. Source, distribution, CLI and released checks are retained in correction45/checks.zip.\n\nThe complete multi-work-order PR uses original base 55caaada508495bea7d97effd27644d1ce8373da. verification45-change-set.json lists every actual/planned changed path admitted by WO-HAG-011; the full PR union remains separate. This evidence does not grant human verification, merge or release.\n')
 v=p.gov('handoff','check',R,'--artifact','WO-HAG-011','--checkpoint','handoff','--change-manifest',(E/'verification45-change-set.json').relative_to(R).as_posix(),'--json',allowed=(0,1,2));print(json.dumps(brief(v)),flush=True)
elif mode=='complete':
 v=json.loads(load(O/'handoff.json')['stdout']);assert v['compliance']['status']=='pass'
 args=['transition',R,'--set','WO-HAG-011=implemented','--decision','WO-HAG-011=Codex']
 v=p.gov('complete-preview',*args,'--json',allowed=(0,1,2));print(json.dumps(brief(v)),flush=True);assert v['compliance']['status']=='pass' and v['operation']['outcome']=='completed'
 v=p.gov('complete-apply',*args,'--apply','--json');print(json.dumps(brief(v)),flush=True)
elif mode=='commit':
 assert git('rev-parse','HEAD')==C
 m=tomllib.loads((D/'work-orders/WO-HAG-011.md').read_text().split('+++')[1]);assert m['status']=='implemented'
 v=p.gov('candidate-validation','validate',R,'--json');assert v['error_count']==0
 v=p.gov('completed-context','check',R,'--artifact','WO-HAG-011','--json');print(json.dumps(brief(v)),flush=True)
 retain()
 files=sorted(set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines()))
 allowed=['docs/engineering/hosted-artifact-graph/README.md','docs/notes/hosted-artifact-graph.md','docs/engineering/hosted-artifact-graph/work-orders/WO-HAG-011.md']
 assert all(f in allowed or f.startswith('docs/engineering/hosted-artifact-graph/evidence/WO-HAG-011/') for f in files)
 p.run('stage',['git','add','--',*files],cwd=R)
 p.run('diff-check',['git','-c','core.whitespace=trailing-space,space-before-tab,cr-at-eol','diff','--cached','--check'],cwd=R)
 p.run('commit',['git','commit','-m','Complete focused hosted drafting qualification','-m','Harness-Work-Order: WO-HAG-011'],cwd=R)
 assert not git('status','--porcelain');put(O/'candidate.json',{'candidate':git('rev-parse','HEAD'),'native_test_candidate':C,'files':files});print('Candidate',git('rev-parse','HEAD'),flush=True)
elif mode=='capture':
 c=load(O/'candidate.json')['candidate'];assert git('rev-parse','HEAD')==c and not git('status','--porcelain')
 assert not git('log','--all','--pretty=format:','--name-only','--',f'docs/engineering/hosted-artifact-graph/verification-records/{ID}.md')
 files=sorted(F.glob('*'))+sorted((E/'correction45').glob('*'))+[E/x for x in ['candidate26-checks.zip','candidate26-checks-inventory.json','implementation-review.md','completion45-checks.zip','completion45-checks-inventory.json','verification45-change-set.json','WO-HAG-011-handoff.md']]
 args=['capture-verification',R,'--id',ID,'--work-order','WO-HAG-011','--verification','VER-HAG-008','--owner','Codex','--domain','hosted-artifact-graph']
 for f in files:assert f.is_file();args+=['--evidence',f.relative_to(R).as_posix()]
 put(O/'capture-inputs.json',{'candidate':c,'record':ID,'files':[{'path':f.relative_to(R).as_posix(),'sha256':sha(f.read_bytes())} for f in files]})
 args+=['--candidate-commit',c,'--json','--test-command',r'C:\Users\mathi\AppData\Local\Python\pythoncore-3.14-64\python.exe','-X','utf8','-B',str(W/'hag_candidate45_checks.py')]
 v=p.gov('capture',*args,allowed=(0,1,2));print(json.dumps(brief(v)),flush=True)
else:raise ValueError(mode)
