"""Supporting checks for one clean candidate; no lifecycle writes."""
import hashlib,json,os,platform,subprocess,sys,tempfile,time
from pathlib import Path

root=Path.cwd().resolve()
workspace=Path(__file__).resolve().parent
output=workspace/'hag-native-verification'/'candidate-test-outputs'
output.mkdir(exist_ok=False)
governor=Path(r'C:\Users\mathi\.codex\plugins\data\verity-plane-se-harness\evaluators\0.22.1\cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053\Scripts\python.exe')
candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()
env=os.environ.copy()
index=int(env.get('GIT_CONFIG_COUNT','0'));env['GIT_CONFIG_COUNT']=str(index+1)
env[f'GIT_CONFIG_KEY_{index}']='core.longpaths';env[f'GIT_CONFIG_VALUE_{index}']='true'
scratch=Path(tempfile.mkdtemp(prefix='hagnative-checks-'))
env['TEMP']=str(scratch);env['TMP']=str(scratch)
commands=[('source',[sys.executable,'-X','utf8','-B','scripts/run_tests.py','--timings',str(output/'source-timings.json')],root),('distribution',[sys.executable,'-X','utf8','-B','scripts/validate_release_distributions.py','--root','.'],root),('cli',[sys.executable,'-X','utf8','-B','-m','se_harness','--help'],root),('validation',[str(governor),'-I','-m','se_harness','validate',str(root),'--json'],workspace)]
summary={'candidate':candidate,'checkout':str(root),'python':sys.version,'platform':platform.platform(),'governor':str(governor),'environment_changes':{'process_only_git_config':'core.longpaths=true','TEMP':str(scratch),'TMP':str(scratch)},'commands':[]}
for name,args,cwd in commands:
 print('Running '+name+' for '+candidate,flush=True)
 start=time.monotonic();result=subprocess.run(args,cwd=cwd,env=env,capture_output=True,encoding='utf-8',errors='replace')
 record={'argv':args,'cwd':str(cwd),'exit':result.returncode,'elapsed_seconds':time.monotonic()-start,'stdout':result.stdout,'stderr':result.stderr}
 raw=(json.dumps(record,indent=2)+'\n').encode();(output/(name+'.json')).write_bytes(raw)
 item={'check':name,'argv':args,'cwd':str(cwd),'exit':result.returncode,'seconds':record['elapsed_seconds'],'full_result_sha256':hashlib.sha256(raw).hexdigest()}
 if name=='source':item['result']=result.stdout[-400:]
 if name=='distribution':item['result']=result.stdout.strip()
 if name=='validation':
  value=json.loads(result.stdout);item['result']={k:value.get(k) for k in ['valid','artifact_count','error_count','warning_count','advisory_count']}
 summary['commands'].append(item)
 if result.returncode:
  summary['failed']=name;(output/'summary.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode());print(json.dumps(summary),flush=True);sys.exit(result.returncode)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root).strip()
summary['clean_after']=True
(output/'summary.json').write_bytes((json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps(summary,ensure_ascii=False),flush=True)
