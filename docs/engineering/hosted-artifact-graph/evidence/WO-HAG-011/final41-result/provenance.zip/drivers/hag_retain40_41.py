"""Retain completed trials and observed entry refusal without raw provider reasoning."""
import json,sys,hashlib,re,zipfile
from pathlib import Path
import hag_efficiency_plan as p
W=p.W;load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
mode=sys.argv[1];p.O=W/'hag42'
groups=[('WO-HAG-009','final40-result',['claude-361','codex-361']),('WO-HAG-011','final41-result',['claude-371','codex-371'])]
if mode=='scope':
 for wo,name,trials in groups:
  names=['assessment.md','provenance.zip','provenance-inventory.json']+[t+s for t in trials for s in ('-evidence.zip','-visible.md','-inventory.json')]
  paths=[(p.D/'evidence'/wo/name/n).relative_to(p.R).as_posix() for n in names]
  x=p.gov(name+'-scope','check',p.R,'--artifact',wo,'--checkpoint','scope','--changes-complete',*[x for path in paths for x in ('--changed-path',path)],'--json')
  assert x['compliance']['status']=='pass';print(wo,'scope pass',flush=True)
elif mode=='retain':
 for wo,name,trials in groups:
  assert json.loads(load(W/'hag42'/(name+'-scope.json'))['stdout'])['compliance']['status']=='pass'
  E=p.D/'evidence'/wo/name
  if E.exists():
   index=load(E/'provenance-inventory.json')
   assert sha((E/index['archive']).read_bytes())==index['sha256']
   for trial in trials:
    index=load(E/(trial+'-inventory.json'));assert sha((E/index['archive']).read_bytes())==index['sha256']
   print('Preserved completed archives:',name);continue
  E.mkdir(exist_ok=False)
  folder='hag-final40-20261012' if wo.endswith('009') else 'hag-eff41-20261012'
  source=(W/'hag_retain36.py').read_text().replace('hag-procedure36-20261011',folder).replace('WO-HAG-009/procedure36-result',wo+'/'+name)
  source=source.replace("names=['initial-status.json'","names=['persisted-instruction-recovery.json','reader-boundary-gap.json','package-reuse.json','initial-status.json'")
  source=source.replace('replay36','replay40').replace('native-parity-*36','native-parity-*40')
  source=source.replace('extra="""for directory', 'extra="""for f in (root/\'persisted-instructions\').glob(\'*.txt\'):\n files[\'assessment/persisted-instructions/\'+f.name]=f.read_bytes()\nfor directory')
  for trial in trials:
   sys.argv=[__file__,trial];exec(compile(source,'retain40-41','exec'),{'__file__':str(W/'hag_retain36.py'),'__name__':'__main__'})
  O=W/folder;files={}
  tokens=[x['token'].encode() for f in O.glob('*/credentials.json') for x in load(f)['principals']]
  drivers=['hag_full40.py','hag_eff41.py','hag_native26.py','hag_native27.py','hag_full27.py','hag221_execute.py','hag_efficiency_plan.py','hag_full40_probe.py','hag_eff41_probe.py','hag_review40.py','hag_full27_review.py','hag_assess40.py','hag_trace40.py','hag_full27_trace.py','hag_facts40.py','hag_observe41.py','hag_retain40_41.py','hag_retain36.py','hag_retain26.py','hag_close41.py','hag_full40_parity.py','hag_native_parity19.py']
  for n in drivers:files['drivers/'+n]=(W/n).read_bytes()
  for f in O.glob('*.json'):
   if any(x in f.name for x in ('live-probe','version','auth-review','auth-failure')) and 'review' not in f.name:continue
   files['observations/'+f.name]=f.read_bytes()
  for n in ('entry-refusal-assessment.json','selection.json'):
   f=O/'claude-372'/n
   if f.exists():files['prelaunch-refusal/'+n]=f.read_bytes()
  for f in O.glob('prototype-tests*.txt'):files['prototype-checks/'+f.name]=f.read_bytes()
  P=W/'hag-authority38-20261012'
  for n in ('candidate-38.json','package-guidance-comparison.json','service-reuse-comparison.json','server-wheel-members.json','build38-replay.json'):files['reused-package/'+n]=(P/n).read_bytes()
  for n,raw in files.items():
   assert not any(t in raw for t in tokens),n
   assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),n
  with zipfile.ZipFile(E/'provenance.zip','x',zipfile.ZIP_DEFLATED) as z:
   for n,raw in sorted(files.items()):z.writestr(n,raw)
  (E/'provenance-inventory.json').write_text(json.dumps({'archive':'provenance.zip','sha256':sha((E/'provenance.zip').read_bytes()),'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())],'omissions':'No raw provider events, private reasoning, credential stores or test tokens. Setup failures and later successful probes remain separate; exact package identities reused.'},indent=2)+'\n',encoding='utf-8')
else:raise ValueError(mode)
