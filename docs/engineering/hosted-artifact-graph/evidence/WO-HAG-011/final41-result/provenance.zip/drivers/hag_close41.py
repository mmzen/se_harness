import json,os,sys
import hag221_execute as h
h.O=h.W/'hag-eff41-20261012';trial=sys.argv[1]
assert trial in ('claude-371','codex-371','claude-372','claude-373','claude-374','codex-372')
root=h.O/trial;s=json.loads((root/'selection.json').read_text())
token=next(x['token'] for x in json.loads((root/'credentials.json').read_text())['principals'] if x['id']=='operator')
status_label=trial+'-final-status'
while (h.O/(status_label+'.json')).exists():status_label+='-recheck'
status=h.run(status_label,[s['client_python'],'-I','-m','se_harness','remote','status','--endpoint',s['endpoint'],'--project',s['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--json'],env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token))
assert status['ready']
project='hag-eff41-'+trial;assert s['compose_project']==project
names=[project+'-service-1',project+'-graph-1']
label=trial+'-containers'
while (h.O/(label+'.json')).exists():label+='-recheck'
h.run(label,['docker','inspect','--format','{{.Name}} {{index .Config.Labels "com.docker.compose.project"}}',*names])
rows=json.loads((h.O/(label+'.json')).read_text())['stdout']
assert set(rows.splitlines())=={'/'+name+' '+project for name in names}
h.run(trial+'-stop',['docker','stop',*names])
print(json.dumps({'trial':trial,'project_version':status['project_version'],'containers_stopped':names,'volumes':'preserved'}))
