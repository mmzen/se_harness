"""Independent focused-case readback and boundary observations; no service writes."""
import hashlib,json,sys,subprocess,os
from pathlib import Path
import hag_efficiency_plan as p
W=p.W;O=W/'hag-eff41-20261012';trial=sys.argv[1];root=O/trial;native=root/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
 assert not f.exists(),f
 f.write_bytes((json.dumps(v,indent=2)+'\n').encode())
source=(W/'hag_observe26.py').read_text().replace('hag-efficiency-compact-pointers-20261010','hag-eff41-20261012')
exec(compile(source,'eff41-readback','exec'),{'__file__':str(W/'hag_observe26.py'),'__name__':'__main__'})
s=load(root/'selection.json');token=next(x['token'] for x in load(root/'credentials.json')['principals'] if x['id']=='operator')
argv=[s['client_python'],'-I','-m','se_harness','remote','status','--endpoint',s['endpoint'],'--project',s['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--json']
cp=subprocess.run(argv,cwd=W,capture_output=True,env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token),check=True)
put(O/(trial+'-final-status.json'),{'argv':argv,'cwd':str(W),'exit':cp.returncode,'stdout':cp.stdout.decode(),'stderr':cp.stderr.decode()})
before=load(root/'boundary-before-native.json');after=load(root/'boundary-after-native.json')
put(root/'boundary-comparison.json',{'equal':before==after,'before_sha256':sha((root/'boundary-before-native.json').read_bytes()),'after_sha256':sha((root/'boundary-after-native.json').read_bytes())})
print(json.dumps({'trial':trial,'independent_project_version':json.loads(cp.stdout)['project_version'],'boundary_equal':before==after}))
