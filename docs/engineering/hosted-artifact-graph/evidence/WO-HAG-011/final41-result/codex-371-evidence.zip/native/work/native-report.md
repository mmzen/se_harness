# Focused intent drafting diagnostic

## Content readiness

Blocked against the intent checklist. The request supplies an activity, “Adapt the existing greeting for a new audience.” It does not identify the audience, the present problem for that audience, the improvement needed, or how the owner will know the change helped. The intended outcome and scope have not been confirmed. No formal draft was authored.

Proposed outcome for clarification: The intended new audience observes an adapted greeting from the existing fixture.

Known limits: prepare exactly one new intent draft in domain `lifecycle-pilot`, with synthetic owner `test-owner`; keep it draft. Preserve imported `-900` records and the fixture. Other artifacts, approvals, work execution, baseline freezing and lifecycle decisions are excluded.

Questions: Who is the new audience, what problem does the existing greeting cause for that audience, and how will `test-owner` know the adaptation helped? Does the proposed outcome, refined with those answers, and the stated scope match the request?

## Saved state

Selected project: `25ccdfee-76e8-4cff-8e21-097308e0438e` at `http://127.0.0.1:26381`. Status reported project version `0`, `test_copy: true`, and authority mode `sandbox-projection`. No hosted mutation was attempted in this turn. No import baseline, draft context, artifact ID, revision or authored document exists from this work.

The service reported readiness and component identities matching the supplied combination, including evaluator `0.22.1` and client `0.22.2`. The identity operation returned the wheel SHA-256 specified in that combination.

## Validation and review

Method: inspection of the complete source and definition text supplied in the conversation. `greeting()` returns `Hello rehearsal`. The existing intent concerns a disposable rehearsal; the requirement, specification and verification definition all use that exact greeting. They do not supply the new audience's problem or success measure. No test or draft evaluator check was executed; there are no actual draft authoring findings to report.

The selected [change skill](../inputs/plugin/verity-plane/skills/change/SKILL.md) routes this action to [Hosted drafting](../inputs/plugin/verity-plane/skills/change/references/hosted-drafts.md), which requires: “State a missing required fact as a question and stop dependent writing.” The supplied `DEFINE_CHANGE.md` procedure also requires requester confirmation before dependent definitions. These requirements block drafting until the missing intent facts and confirmation are available.

Original evidence: [status capture](status-check.json), [status response](status-check.json.stdout.txt), and [observation snapshot](call-observations). The snapshot has empty `native_failures` and `failed_command_records`, but reports `native_call_count_complete: false`. Capture completeness and exhaustive failure counts remain unassessed. The snapshot excludes subsequent reads and this report write. No lifecycle, MCP parity, reply recovery, export or complete NQ-01 through NQ-05 claim is made.
