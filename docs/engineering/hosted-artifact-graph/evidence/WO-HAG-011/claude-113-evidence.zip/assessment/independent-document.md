+++
id = "VER-P3-901"
type = "verification"
title = "Assert greeting return value independently"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert greeting return value independently

## Independence

The expected value `Hello rehearsal` is fixed by REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The pass condition derives from those definitions, not from candidate output or prior test results.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import `greeting` from `src/greeting.py` and compare the return value against the independently fixed expected string. | `greeting()` returns exactly the string `Hello rehearsal`. Platform: Python 3.13 on linux/amd64. Evaluator: 0.22.1. |

## Acceptance scenarios

**Scenario: exact greeting match.** Call `greeting()` once. The returned value equals `Hello rehearsal` with no leading or trailing whitespace and no other content. A mismatch, an exception, or a missing function fails the check.

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-greeting-check.json`. The evidence file records the actual returned value, the expected value, the comparison outcome, and the candidate commit.
