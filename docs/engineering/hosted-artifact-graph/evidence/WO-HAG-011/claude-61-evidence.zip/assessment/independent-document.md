+++
id = "INT-P3-001"
type = "intent"
title = "Establish that the rehearsal fixture returns the expected greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"
outcome = "The test operator confirms that greeting() returns exactly Hello rehearsal."

[relations]
+++

# Intent: Establish that the rehearsal fixture returns the expected greeting

## In plain words

A test operator needs assurance that the rehearsal fixture in `src/greeting.py` produces the exact greeting string before relying on it in lifecycle rehearsal steps.

## Problem

The rehearsal fixture provides a `greeting()` function whose return value serves as the fixed reference point for lifecycle rehearsal exercises. Without explicit confirmation that `greeting()` returns exactly `Hello rehearsal`, later rehearsal steps that depend on this value lack a verified starting point.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| The test operator has a confirmed greeting value from the fixture | not measured | greeting() returns `Hello rehearsal` | Operator inspection of retained test evidence after each rehearsal run |

## Not this

- Changes to the greeting() function or its return value
- Coverage of other fixture functions or modules
- Production release of the fixture
- Modification of imported -900 records
