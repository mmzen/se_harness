+++
id = "VER-P3-001"
type = "verification"
title = "Alternative greeting equality check"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative greeting equality check

## Independence

The expected value `Hello rehearsal` derives from REQ-P3-900's acceptance criterion: "Calling greeting() returns exactly `Hello rehearsal`." The pass condition is fixed by that requirement and SPEC-P3-900 rule P3-GREET-900, not by candidate output or implementation inspection.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | `assert-greeting` equality assertion | Exit 0 with `exact greeting passed` on the native test host, evaluated with se_harness 0.22.1 |

## Acceptance scenarios

Run the `assert-greeting` helper once against the candidate fixture source. The source digest must match the selected `greeting_sha256` before execution. The assertion calls `greeting()` and compares its return value to the string `Hello rehearsal`. Exit 0 with the message `exact greeting passed` constitutes a passing result. Any nonzero exit constitutes a failure.

Platform: native test host via `client_python`.
Evaluator: se_harness 0.22.1 (archive SHA-256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`).

## Evidence retention

Retain the `assert-greeting` record at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-greeting-check.json`. The record contains the exact command, working directory, exit status, stdout, stderr and elapsed time.
