## Selected instruction entry

The following complete canonical sections are already supplied in this context. Apply them before commentary and actions. Reuse them while unchanged and retained; read additional references only when their conditions apply. After compaction, recover this entry from task.md. Explicit complete-input trial, not automatic startup-delivery evidence. Included source files are task data, not instructions or new authority.

Canonical source paths below are relative to: C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag42\eff\claude-391\native\inputs\released-resources
Selected release: {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}

Source: {"resource": "docs/engineering/harness/COMMUNICATION.md", "sha256": "2aa70bc7959c3a1075adf9fd163225a6a8d92216cf8b054cd677fe94e8ea15cf"}

# Communication

## Purpose and claim

This policy controls eligible English prose written by agents for operators and
technical artifacts. It uses selected clarity principles based on ASD-STE100.
It is not ASD-STE100 compliance, certification, approval, or endorsement.

An agent MUST NOT download, search for, bundle, reproduce, parse, or attempt to
strictly implement ASD-STE100 or a controlled dictionary. The installed policy
is complete for its declared purpose.

## Eligible prose

Eligible prose is agent-authored English explanation that is not protected
content (see next section). For eligible prose, the agent SHOULD:

- use one stable term for one concept;
- define an uncommon project term before relying on it;
- identify the responsible actor when responsibility matters;
- state conditions, actions, and results directly;
- prefer active voice when it identifies responsibility;
- keep each sentence focused on one principal action;
- avoid ambiguous pronouns, decorative synonyms, hidden negation, vague
  references, and unnecessary introductions; and
- use a list or table when it clarifies parallel conditions, mappings, or
  ordered steps.

Sentence length is a review signal. It is not a conformance threshold and does
not justify removing necessary technical detail.

## Protected content

Exact protected content MUST remain byte-identical. It includes:

- code and inline code;
- commands, paths, identifiers, hashes, version strings, URLs, schemas, and
  field names;
- JSON, TOML, YAML, XML, and other machine-readable data;
- logs, diagnostics, evidence, evaluator output, and canonical restitution
  blocks;
- quotations; and
- operator-supplied text that is presented as supplied text.

Protected content MUST NOT be automatically paraphrased. It includes BCP 14 obligations, 
requirement statements, lifecycle and decision meanings, safety or legal qualifications, 
acceptance thresholds, formulas, and established terminology.

Source: {"resource": "docs/engineering/harness/DEFINE_CHANGE.md", "sha256": "7f41ea6b62df110755524d88293019406d6cf6a238abc67e795db98234024f52"}

## Read this when

A new change needs an outcome, limits or selection of existing artifacts.


## Before this action

Before selecting artifacts, read [ARTIFACTS.md#artifact-types](ARTIFACTS.md#artifact-types) and [DEFINITION_LINKS.md#links-between-definitions](DEFINITION_LINKS.md#links-between-definitions).


### Describe the intended outcome

**Inputs:** The change request and any clarifications already provided by
the requester.

**Output:**

- **Formal artifacts:** None created or modified.
- **Transient working material:** The confirmed intended-outcome statement and the
  requester's confirmation. This material is needed only for the current
  change-definition context. The agent SHALL retain it in the conversation
  or, at its discretion, in a temporary location outside the repository.
  It SHALL NOT be persisted in the repository. The agent chooses whether a
  temporary file is needed and, if so, its filename and format.

**Actions:**

1. Read the change request and existing clarifications.
2. Draft one statement describing the observable result for the intended
   human, agent, or system. Include the conditions under which it is needed.
3. Present the statement to the requester. When the proposed scope is also
   clear, present its inclusions, exclusions, and constraints in the same
   exchange. Obtain confirmation of both before drafting dependent definitions.
4. Ask the requester to resolve any missing information or competing
   interpretations that would change the outcome.
5. Revise the statement using the feedback. Repeat the exchange until the
   requester confirms the wording. Reuse an existing confirmation of the
   same wording.
6. Retain the confirmed statement and the confirmation as transient working
   material.

**Harness command:** None.

**Completion:** One intended-outcome statement is confirmed by the requester
and available for the following steps. This confirmation does not approve a
formal artifact or authorize implementation.

**Later use:** The statement guides scope definition in [Define the limits of the change](DEFINE_CHANGE.md#define-the-limits-of-the-change) and artifact
selection in [Identify the existing artifacts that apply to the change](DEFINE_CHANGE.md#identify-the-existing-artifacts-that-apply-to-the-change). It supplies the outcome for a missing intent (INT) drafted
in [Draft any missing definitions](DRAFT_DEFINITIONS.md#draft-any-missing-definitions) or an amendment proposed in [Propose any needed amendments to existing definitions](AMEND_DEFINITIONS.md#propose-any-needed-amendments-to-existing-definitions). Any lasting definition belongs
in those formal artifacts.


Source: {"resource": "docs/engineering/ARTIFACT_AUTHORING.md", "sha256": "71de2cc92a470e2da25d525e3ad002b77faedb6ef0e69e2fa476a2fa4cb78ff5"}

## intent

### Checklist

- Explain the present problem, who it affects, and the outcome wanted.
- What is the smallest useful outcome, and which needs and constraints are actually agreed?
- Say how the owner will know the change helped; an honest baseline may be `not measured`.
- State the important scope limits. Create a new intent when the desired outcome changes.


## Complete selected inputs

The selection, references and entire staged fixture below are supplied once. Apply the applicable instructions and inspect these exact source contents; reuse them while retained and unchanged. The original paths remain available. Reading this delivered content satisfies its read instruction; reread a file only if its required content is missing, changed or no longer retained. The agent selects all operations, authored content and conclusions.

File identities below use paths relative to this input root: C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag42\eff\claude-391\native\inputs

### Effective selection

{
  "host": "claude",
  "project_id": "78f732be-0ccf-4658-a7f3-079e2c7014a0",
  "endpoint": "http://127.0.0.1:26391",
  "source_manifest": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\inputs\\source-manifest.json",
  "configuration": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\inputs\\configuration.json",
  "source_directory": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\inputs\\source",
  "client_python": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\client42\\Scripts\\python.exe",
  "client_wheel": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\inputs\\se_harness-0.22.2-py3-none-any.whl",
  "plugin": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\inputs\\plugin\\verity-plane",
  "combination": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\inputs\\combination.json",
  "compose_project": "hag-eff42-claude-391",
  "source_volume": "hag-eff42-claude-391-source",
  "source_commit": "5820415917e87b64d80bad2f7c39c6d18d692829",
  "source_kind": "Exact tracked Git-blob snapshot without Git metadata.",
  "reference_root": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\inputs\\reference",
  "released_resources": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\inputs\\released-resources",
  "native_helper": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\inputs\\native_call.py",
  "greeting_sha256": "dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1",
  "inputs_inventory": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\inputs\\inventory.json",
  "helper_python": "C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe",
  "approved_shell_argv_prefix": [
    "C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe",
    "-I",
    "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag42/eff/claude-391/native/inputs/native_call.py"
  ],
  "native_task_file": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\task.md",
  "output_directory": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\work",
  "tool_index": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\inputs\\native-tools.md",
  "evaluator_version": "0.22.1",
  "evaluator_file": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag42\\eff\\claude-391\\native\\inputs\\evaluator.json",
  "qualification_candidate": "1da445cb743295c441cf46f421653b092d042378",
  "token_variable": "HAG_NATIVE_TEST_TOKEN",
  "instruction_delivery": "session-local plugin"
}

### Selected reference

{"path": "native-tools.md", "sha256": "ffb63e46c4625cdca42c43b13664d5dc5368e7cb1394edc24cf697b6d2d1b6a8", "bytes": 8664}

````text
# Native test tools

Use `selection.json` for the exact `approved_shell_argv_prefix` and absolute
input/output paths. Append one helper operation per shell call. Use native
Write/Edit for files; read with native Read or the documented `read-text` helper.
Prefer one `read-text` call for independent files whose exact paths are known.
Keep normal permissions: no wrappers, loops, pipes,
directory listing, direct client commands or permission changes. This index
describes capabilities; it supplies no workflow or finished artifact.

All records, their companion evidence and export destinations must be new paths
under the selected `work/` directory. The helper refuses other output locations
before executing the command. Use absolute paths from the selection; relative
paths resolve from the native workspace root, so include `work/`.
The observation index scans that same `work/` directory only.

## Draft mutations

Prefer typed input for the operations below. This table supplies their CLI fields;
you do not also need their raw schemas or help files unless a needed field is
missing. Choose the operation, target, versions, key and content yourself.

```text
remote OPERATION --typed --compact --record ABSOLUTE_NEW_RECORD [FIELDS]
```

Every typed mutation takes `--operation-key KEY --expected-project-version N
--evaluator-file FILE`. Use the selected `evaluator_file` path. The fixed adapter
supplies the selected endpoint/project/token environment and exact installed
client wheel. The client constructs the existing request and verifies its identity.

| Operation | Other fields |
| --- | --- |
| `import` | `--source-manifest FILE`; use selected `source_manifest` |
| `draft-open` | `--baseline ID --work-order WO-ID` |
| `create-artifact` | `--context UUID --context-version N --domain NAME --artifact-type TYPE`; optional `--artifact ID --include-document` |
| `revise-artifact` | `--context UUID --context-version N --artifact ID --expected-revision REVISION --document-file FILE` |

Hosted `create-artifact` allocates the ID and writes the draft in one operation.
It has no `--dry-run` option; the local repository preview command does not apply.

The client never refreshes a version or retries a mutation on its own. Typed and
raw input cannot be mixed. Documents are exact UTF-8 files. No manual base64 or
copied client digest is needed. `--include-document` adds one read of the exact
created revision, returning text or a decoded file path. Inspect it before editing.

`--record` retains the command. Its new `.evidence` directory retains exact
requests/responses and decoded documents. The displayed `client_view` is the
client's own view. Inspect outcomes and findings; read required omitted content.
Do not reread a whole receipt just to extract a small field already displayed.
A capture error after send can leave a committed effect. Reconcile its original
key with `remote operation --key KEY --record ABSOLUTE_NEW_RECORD`.

## Read one revision

```text
remote read --typed --compact --record ABSOLUTE_NEW_RECORD --artifact ID --expected-revision REVISION --context UUID --context-version N
```

For an imported baseline, replace the context fields with `--baseline ID`.
Reads take no `--operation-key`, `--expected-project-version` or `--evaluator-file`.
Choose the exact revision and context from the selected inputs or actual results.

## Reads and discovery

| Need | Operation |
| --- | --- |
| Service readiness and selected components | `remote status --record ABSOLUTE_NEW_RECORD` |
| Local wheel metadata | `identity` |
| Captured calls, reads and failures so far | `observations --record ABSOLUTE_NEW_RECORD`; retains the full snapshot and returns its field pointers, no content verdict |
| Complete released instruction sections | `instructions --section "RESOURCE_ID#HEADING"`; repeat for up to 12 sections |
| One unknown input location | `find-file BASENAME --under RELATIVE_DIRECTORY/` |
| One exact inventory entry | `lookup-file RELATIVE_NAME` |
| One saved JSON field | `read-json ABSOLUTE_FILE --pointer '"/field"'`; omit pointer for root; optional `--keys` |
| A raw base64 field | Add `--decode-base64` to that field read |
| One text file or independent reads together | `read-text ABSOLUTE_FILE [ABSOLUTE_FILE ...]`; up to eight selected inventoried inputs, the launcher-pinned task.md, or work files, at most 64 KiB output |
| Recover a truncated text read | `read-text ABSOLUTE_FILE --offset 0 --limit 4096`; one file, character offsets; continue from next_offset until complete is true |

For `instructions`, use canonical IDs such as `docs/engineering/harness/DRAFT_DEFINITIONS.md#read-this-when`. The earlier `released-resources/` inventory prefix also works. Request known sections together. The public reader includes the selected file's exact entry conditions when present; read their applicable references before acting. It does not follow links or select the next action.
For authoring checklists and the repeated released 0.22.1 continuation heading,
use the exact selectors in the selected plugin's `change/references/hosted-drafts.md`.

For known paths, use them directly. Inventory names are relative to the staged
inputs directory: `released-resources/docs/engineering/ARTIFACT_AUTHORING.md`,
`source/src/greeting.py`, `client-help/create-artifact.txt`. **Do not add `inputs/`
to these names.** Native Read takes the absolute path, not an inventory name.
A digest or lookup is not a content read. Batch independent reads when their exact
paths are known. Unknown headings must not be guessed;
read the named file once to locate its actual headings. Request known current
sections together and reuse unchanged content. A full inventory is not required.

Read [Execution tools](native-execution-tools.md) when choosing a planned check
or executing an authorized one. The description establishes the available
assertion and evidence fields; reading it does not run a test. Source inspection
is not test execution, and drafting a verification contract grants no execution
authority.

## Other operations

Raw mode remains `remote OPERATION --request ABSOLUTE_FILE --record ABSOLUTE_NEW_RECORD`.
Use it for operations without typed input, or when explicitly checking a raw
contract. Original schemas are under `reference/server/contracts/`. Selected
schema views use `schemas/remote-v1/OPERATION.json` or `schemas/read-v1/OPERATION.json`.
Each view retains its original pointer/digest. Lifecycle test-copy schemas are
separate; do not load them for drafting alone. `--key` reads a receipt, not a document.

For lifecycle rehearsal use `remote rehearse --request ABSOLUTE_FILE --record
ABSOLUTE_NEW_RECORD`. The helper supplies the direct client's `--test-copy` flag;
do not add that flag yourself. The request still needs `test_copy: true`.
The selected plugin's `change/references/hosted-test-lifecycle.md` provides exact
released section selectors and pointers to individual action schemas.
For a handoff file, `encode-file ABSOLUTE_FILE` returns its actual byte count,
SHA-256 and base64 content. It takes no output flag. Copy those returned values
unchanged; do not compute or guess a replacement digest.

Use `observations --record ABSOLUTE_NEW_RECORD` before the final report. Read its
selected fields as needed. `observed_content_reads` contains successful visible
read metadata; `file_reads` retains Claude Read attempts, including failures.
Use the observed trace instead of rebuilding it with inventory lookups. Missing
reads remain unknown; rereading now does not prove an earlier read. The capture
may be incomplete, and subsequent report writes are not yet counted. Keep the
record path as evidence instead of copying every command. This supplies no draft
text, content judgement or lifecycle decision.

The returned `record` is the exact JSON **file**, even when it has no extension.
Use its `read_arguments` with the approved helper prefix. Do not append a filename
or treat it as a directory. Add `--pointer` only to select a field in that file.

`command_records` includes extensionless record names. Each row points to its
original capture and copies selected exact `response_fields`, including available
receipt, outcome and provenance values. Rows are sorted by filename, not time.
Use an indexed row to locate evidence, then inspect its original request/result
for the claim. The index does not select a handoff base or certify a retry.

Retain failed calls and recoveries. Template admission is not a content review.
Report only inspected facts and actual outcomes; distinguish unresolved content
from a completed definition. Do not claim an exhaustive failure count from memory.

````

### Selected reference

{"path": "combination.json", "sha256": "e5442f89206d8fa3af4f60e91863e540fce00bcbb95cf2ff2d7ab05f5f323904", "bytes": 2542}

```text
{
  "payload": {
    "client": {
      "version": "0.22.2",
      "wheel_sha256": "b100618780631da7b4c15940df99ec06a283918a8c9d50d1d56633df428e24dc"
    },
    "database": {
      "image": "memgraph/memgraph@sha256:4710bee1ab5b47599876e30f17ae1679d0bbb2262d84dc06641521fecb7c89ce",
      "version": "3.13.1"
    },
    "deployment_sha256": "fb3cf9dc578f4041d9c112d36b6a357ec9078cbe0cad061a0cf1a985f3df0339",
    "evaluator": {
      "archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053",
      "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff",
      "version": "0.22.1"
    },
    "plugins": {
      "claude": {
        "archive_sha256": "e7fa7ea06625c0208dbc42bc8b36dc6f3db8895f36f42c0a1d342791656b8d56",
        "inventory_sha256": "a6e1cc0855fadac31c2a19a869aa49221b17ef99f15beed5d3b0bebcb7b05c9e",
        "version": "0.2.7"
      },
      "codex": {
        "archive_sha256": "eb2e35641d742e80f26042c22e1e0040f3414239795ded14e3da22b85339a20c",
        "inventory_sha256": "2e83f3954f637dbb48302e1e30ab7817d8200831c87ec01f07f3fc0ba88c97d8",
        "version": "0.2.7"
      }
    },
    "protocols": [
      "se-harness-remote-command/v1",
      "se-harness-remote-result/v1",
      "se-harness-graph-read/v1",
      "se-harness-artifact-revision/v1",
      "se-harness-artifact-baseline/v1",
      "se-harness-lifecycle-command/v2",
      "se-harness-lifecycle-result/v2",
      "se-harness-lifecycle-export/v2",
      "se-harness-graph-read/v2"
    ],
    "required_secret_keys": [
      "principals[].token"
    ],
    "runtime": {
      "image": "python@sha256:88310c082760d93ac7c74d579e95e53a4ab6ea52dd8901abc61a103daf488ac4",
      "platform": "linux/amd64",
      "python": "3.13.16"
    },
    "schema": "se-harness-hosted-combination/v1",
    "schema_revision": 2,
    "server": {
      "dependency_lock_sha256": "b1b1f24330aeafc5f13b00d138e0b87a501975c7bc65fd92fb9c519a2f02eeca",
      "image_manifest": "sha256:a480ad3d960aab19abca9dbbe60f8955225d284c4fc8938b46b00f737f75d948",
      "system_packages_sha256": "3b79cfbc2fb5844a952a7e17b401771dc412dfaae78723c9b0665111212c278d",
      "version": "0.1.0.dev1",
      "wheel_sha256": "130af6c28283e1f8df08f20bdf586e3c9a5ba71544941b8c4767ff1582e32b5d"
    },
    "source": {
      "candidate_commit": "1da445cb743295c441cf46f421653b092d042378",
      "repository": "https://github.com/mmzen/se_harness.git"
    }
  },
  "combination_id": "sha256:9d37d90db88c6d0bb0e9a25678d37bdbe56b8a3f13ecbc7b2cb960827f9cc42e"
}

```

### Selected reference

{"path": "plugin/verity-plane/skills/setup/SKILL.md", "sha256": "46fde63e6cd9dee9cc27ed20c4b80b9b676858f20d49e63653e141242118ba89", "bytes": 804}

```text
---
name: setup
description: Prepare or repair the SE Harness checker, connect a project to plugin skills, or carry out a requested harness upgrade using the existing tools.
---

# Set up a project

Use the selected target and requested action. Read only its route:

| Target | Read |
| --- | --- |
| Explicit hosted sandbox or test copy | [Hosted selection](references/hosted-context.md) |
| Clone, select, repair or upgrade a checkout | [Checkout setup](references/checkout.md) |

Select Python 3.11 or later with venv and ensurepip. If unavailable, report the
missing prerequisite; do not install Python or change host settings. Use the
repository's selected released evaluator. Plugin source does not pin its release.
A development wheel is only for disposable testing. Ask only for missing choices.

```

### Selected reference

{"path": "plugin/verity-plane/skills/setup/references/hosted-context.md", "sha256": "53f9620e035f06925f678efcff12079d3ad780a0f0b82eadb6762e48206a3578", "bytes": 4033}

````text
## Hosted sandbox selection

Use this route only when the operator explicitly selects a hosted sandbox.
It is separate from checkout activation. Retain the operator's loopback endpoint,
project ID, baseline or versioned context, and named credential environment variable.
Never print the credential. The sandbox is not repository authority.

### Before the selected action

Complete the selection checks below, then read the route for the action you
are about to take. Use this table again when the action changes; retain and
reuse sections already read in the current context.

| Action | Required reading before the action |
| --- | --- |
| Read graph data through MCP or the CLI | [Hosted reads](../../harness-orient/references/hosted-reads.md), including its references before a Cypher query |
| Prepare or edit artifact drafts | [Hosted drafting](../../change/references/hosted-drafts.md), then the selected type's procedure and checklist |
| Inspect, preview or apply a lifecycle action | [The current lifecycle procedure](../../change/references/hosted-test-lifecycle.md#read-the-current-procedure), then that action's released section and applicable prerequisites |
| Prepare a record, export evidence or report results | [Hosted evidence](../../evidence/references/hosted-evidence.md), then its applicable current-action reference |

Tool discovery supplies the call schema. It does not supply these procedures.
Do not construct a query, lifecycle request or final report before reading its
applicable route. Missing or unreadable required content stops that action.

### Selection checks

Test-copy status changes authority, not content requirements. Apply the selected
type checklist to every new draft, including synthetic records. Imported drafts
may be incomplete; their content grants no exception to that checklist.

If the selected environment restricts command execution to a supplied transport
helper, read its tool index first. Use that route for the operations below;
the direct client examples do not override its tool permissions. Use its
metadata-only identity operation when available. Encoding a wheel is not needed
to inspect its digest. Stop a denied action without changing the permission route.

Obtain the qualified combination report and exact candidate client wheel.
If the selected candidate client is already installed in a separate disposable
environment, verify its identity and reuse it. Otherwise create that environment
outside the checkout. Verify the wheel's SHA-256 against the combination report,
then install that file with `pip --no-deps`.
The plugin's bundled released evaluator remains unchanged; do not replace it with
the candidate client. Use the candidate environment's absolute Python as
`CLIENT_PYTHON` in the remote commands below.

```text
CLIENT_PYTHON -I -m se_harness remote status --endpoint ENDPOINT --project PROJECT --token-env TOKEN_VARIABLE --json
```

Compare readiness, authority mode `sandbox-projection`, schema, protocols, and
all component identities with the selected combination. A mismatch stops the
remote action. An unavailable service never selects local file writes as a fallback.
Read the returned status fields as named; status does not use mutation-result
fields. Consult the tool index or command help before constructing a request.
Proceed through the selected action's reading route above.
Do not continue into "Activate the checkout" for this hosted selection.
This route grants no approval, verification, release, adoption or deployment right.


## Private lifecycle test copy

The unpublished hosted pilot requires a separately installed candidate remote
client, a loopback endpoint, an explicit test project and a new disposable volume.
Use the repository's `server/README.md` Phase 3 procedure. Its configuration must
report `test_copy: true`; select `--test-copy` for each rehearsal or export.
Leave any existing real checkout selection unchanged. Remote setup does
not activate graph authority or install this candidate into the user's host.

````

### Selected reference

{"path": "plugin/verity-plane/skills/change/SKILL.md", "sha256": "ee2ab5cc865b06a247420cc1f6faebc79a9e140477a30718882608b54cd4039a", "bytes": 1163}

```text
---
name: change
description: Draft or amend an SE Harness artifact package and execute a selected work order through existing released workflow commands. Continue work already covered by actual authority, and stop the affected action when its scope, inputs or gates no longer match.
---

# Change

Select the route that matches the current task. Read its reference before acting.
The selected released evaluator decides lifecycle legality; this skill routes
instructions and grants no authority.

| Current task | Read |
| --- | --- |
| Author drafts in an explicit hosted sandbox/test copy | [Hosted drafting](references/hosted-drafts.md) |
| Rehearse lifecycle actions in an explicit hosted test copy | [Hosted lifecycle](references/hosted-test-lifecycle.md) |
| Define or execute work in a repository | [Repository change](references/repository-change.md) |

Load only the selected route and its applicable prerequisites. Reuse unchanged
material retained in context; recover it after compaction. Do not preload the
other routes or future lifecycle procedures.

Before an external mutation, read [Provider controls](references/authority.md#external-actions).

```

### Selected reference

{"path": "plugin/verity-plane/skills/change/references/hosted-drafts.md", "sha256": "430ef9eab115f2410f03f7f21f628b382641b859d31da41661095d0f433cea72", "bytes": 9455}

```text
## Select the current step

Use exact instructions already delivered with their source identity. Reading that
content satisfies its read instruction. Open its file only if required content
is missing, changed or no longer retained. A pointer alone is not content.

Complete [Hosted selection](../../setup/references/hosted-context.md) once for
the unchanged selection. Draft preparation grants no decision right or Git authority.

Match the request and existing confirmed context to the current step:

| Available inputs | Read from the selected release |
| --- | --- |
| The intended outcome or scope still needs clarification | `docs/engineering/harness/DEFINE_CHANGE.md`: **Read this when**, **Before this action**, then **Describe the intended outcome**. Use **Define the limits of the change** when its inputs are available. |
| Confirmed outcome, scope and selected definitions; a definition draft is needed | `docs/engineering/harness/DRAFT_DEFINITIONS.md`: **Read this when**, **Before this action**, then the requested type's procedure below. |

The clarification procedure produces transient discussion, not a formal artifact.
Use its requester-confirmation process and reuse an existing matching confirmation.
An instruction to create a draft does not supply the inputs that procedure requires.
Do not import, open a draft context or create a template merely to ask a question.
For a clarification stop, include three short parts in the final reply:

- **Actions:** State whether any hosted change was attempted. Include observed
  failures or denials.
- **Known inputs:** Keep existing definitions and supplied scope limits.
- **Questions:** Ask only for missing facts needed now.

This retained reply is the transient report only if no hosted mutation command
was invoked and the captured attempted-call record is complete. Refused or denied
mutation commands are still attempts. If capture is incomplete or its completeness
is unknown, use the saved report in **Report and recover** and state that limit,
even when no change was observed. The clarification reply
needs no duplicate file or new lifecycle checkpoint.

For a requested intent, consult `docs/engineering/ARTIFACT_AUTHORING.md#intent`
when identifying missing content. Read other prerequisites when their stated
condition applies. Before selecting artifacts, load the clarification procedure's
artifact and link references. Before drafting, use this type table:

| Type | Drafting procedure |
| --- | --- |
| Verification | **Define how the result will be verified** |
| Release or operating contract | **Prepare a release or operating contract** |
| Other definition | **Draft any missing definitions** |

Apply the drafting procedure's prerequisites, including
`ARTIFACT_AUTHORING.md#design-simplicity` and the type checklist. Use full type
names such as `#intent`, `#verification`, or `#work_order`, not codes.

For a release contract in a private lifecycle test, the source fixture commit
is not the disposable Git candidate that verification will capture. Do not
complete or approve a contract with a guessed candidate. If the final candidate
is not yet known, defer completing and approving the contract. Take its exact
`candidate_commit` from the final verified VREC, complete the release scope and
evidence requirements, then obtain the contract's required decision. An explicitly
supplied candidate constraint remains binding.

The released `harnessctl ... REPO` examples act on repository files. Hosted work
uses the selected tool index or `docs/notes/harnessctl-reference.md#concise-hosted-authoring`.
Do not combine their arguments. The canonical content rules still apply.

Obtain missing sections together from the selected resource root; batch independent
file reads with known paths. Missing, ambiguous or changed sources
stop the affected action. For 0.22.1's repeated
`CONTINUE.md#continue-selected-work` title, read its unique `#procedure` parent.
Load [lifecycle instructions](hosted-test-lifecycle.md) only for that task.

## Check the inputs before writing

Compare the requested type's required content with the request and definitions:

| Content | Source or authoring authority |
| --- | --- |
| User problem, improvement, success measure, existing gap | Require a source that supplies it. A creation request supplies no missing fact. |
| Proposed method, check, evidence destination | Choose within the requested design scope; label it planned. |

For an intent, ask which change in the user's situation is needed and how the
owner will know it helped, when those inputs are missing. An audience name or
replacement output alone does not answer those questions. Reuse supplied answers;
do not invent a purpose or measure from an engineering activity or baseline.

Before claiming a coverage gap, read the applicable requirements, specifications
and verification contracts. Code or one same-type record cannot establish their
absence. For a verification plan, derive expected values from definitions; name
the check, pass condition and full proposed evidence path, including filename
and any work-order directory. In an environment with restricted execution tools,
read their capability descriptions before choosing the check. This is a planning
read, not test execution. Match the planned assertions, platform and evidence
fields to those tools. Do not infer a local test runtime from the service runtime.
If a required condition cannot be assessed with the available tools, report that
gap before requesting approval; do not promise an unavailable check.

State a missing required fact as a question and stop dependent writing. A partial
draft may omit it and remain incomplete. Do not call an unsupported required claim
a non-blocking observation. Report a type/outcome mismatch without changing type.

## Author and submit

Choose the operation, target, expected versions, retry key and content. Use the
documented typed fields and evaluator identity file; do not also load raw schemas
for those fields. Import is operator-only and uses the complete source manifest.

Use `--typed --compact --record-directory NEW_DIRECTORY`, or the selected helper's
documented permission route. Raw `--request FILE` needs its schema and referenced
definitions. Do not mix modes or manually encode typed documents. Freeze is
raw-only and grants no approval. Explicit IDs permit a new domain; automatic
allocation requires an existing domain with an evaluable ID token.

Inspect the created template through `--include-document` or
[an exact revision read](../../harness-orient/references/hosted-reads.md#read-one-hosted-revision).
Findings are not the document. Complete only supported content and review it
against the type checklist. Remove unsupported claims, duplicate checks and
constraints absent from definitions. For every verification pass condition,
identify the planned check that assesses it. Add a missing check or narrow the
claim; an untested condition prevents a complete-content claim. Report this
review separately from template checks.

Submit the complete UTF-8 file with `revise-artifact`. Apply that review to the saved
document, then inspect its versions, receipt and findings before another draft.
`revise-artifact` edits an editable draft, not an approved or imported record.
Lifecycle history, decisions and evidence stay immutable. If a protected-record
refusal occurs, stop that revision. Do not retry it with changed state, history
or content. A separate draft proposal does not amend or replace an accepted
record; use the selected release's amendment boundary and obtain any missing
authority before dependent work. Resolve blocked reads first.

## Report and recover

For the clarification reply, use **Select the current step**. Otherwise retain
complete requests/results and one short report outside the repository, including
after a mutation attempt or uncertain effect. Read required omitted findings.
The report contains:

- **Content readiness:** complete, incomplete or blocked against the selected
  type checklist. Give the supported content or exact missing input; saving alone
  establishes no completeness.
- **Saved state:** selection, revision, versions and exact document/result paths.
- **Validation and review:** evaluator findings, independent content findings,
  captured command observations including recovered failures and denials, uncertain
  effects, and any returned procedure/step. Use mechanical observations before an
  exhaustive failure claim. Link original evidence; do not copy its inventories.

Draft validation checks template shape and required links. `content_review`
being `not_assessed` means only that the evaluator did not assess content. It
does not invalidate your separate review; an empty `incomplete` list does not
complete it. Name the method: source inspection, executed test or evaluator check.
Planned checks are not executed tests. Keep report and final reply consistent
about readiness and actual checks. Use only confirmed paths/digests.
After compaction, recover the retained reply or report and obtain fresh context.

For stale input, inspect the selection without silently refreshing versions.
For an uncertain reply or capture failure, look up `remote operation --key KEY`
with the same selection and credential, or retry identical bytes and key. Resolve
the effect before selecting another key. Changed bytes under an accepted key are
refused. Never fall back to local writes.

```

### Source data

{"path": "source/.engineering-harness.lock", "sha256": "1ec80dbed14b379d2b33a53ba8d84d1af87d7ab2436dcf753761bcd1bcbf8252", "bytes": 656}

```text
{
  "evaluator": {
    "archive_name": "se_harness-0.22.1-py3-none-any.whl",
    "archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053",
    "payload_manifest": "se-harness-installed-payload-v1",
    "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff",
    "version": "0.22.1"
  },
  "files": {
    ".gitattributes": {
      "mode": "fragment",
      "sha256": "fba4cf22b45939f8c705f2a9c3bd964408b5003d0599993e72735ce865b97e3b"
    }
  },
  "hash_algorithm": "sha256",
  "hash_mode": "utf8-text-lf-v1",
  "resource_layout": "released-resources-v1",
  "schema": 5,
  "tool_version": "0.22.1"
}

```

### Source data

{"path": "source/.engineering-harness.toml", "sha256": "069622e02d80bdec13240889f7e83b1063b01208b9e4a5f6f37fdcdcf53a8d22", "bytes": 237}

```text
[harness]
resource_layout = "released-resources-v1"
tool_version = "0.22.1"
installed_at = "2026-10-07"
project_name = "Disposable lifecycle rehearsal"

[revision_provenance]
required_for_verified_work = true
required_for_release = true

```

### Source data

{"path": "source/.gitattributes", "sha256": "fba4cf22b45939f8c705f2a9c3bd964408b5003d0599993e72735ce865b97e3b", "bytes": 173}

```text
# se-harness:begin
# Preserve canonical evaluator-evidence bytes and their bound SHA-256 on every platform.
docs/engineering/**/evidence/*.json text eol=lf
# se-harness:end

```

### Source data

{"path": "source/REHEARSAL.txt", "sha256": "feb75968b83b4fa18865b23e3b2a8b498915e4c7ab770fee2dd9cd3418ac8e8c", "bytes": 46}

```text
Synthetic test copy. No real human authority.

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/capabilities/CAP-P3-900.md", "sha256": "f00af6febc1d62752cab0364e3f4e80e227438f494d98d9f02a9a5c7fdc30bc0", "bytes": 426}

```text
+++
id = "CAP-P3-900"
type = "capability"
title = "Read the rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"
ability = "Read the exact rehearsal greeting."

[relations]
derives_from = ["INT-P3-900"]
+++

# Read the rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

The operator can read the fixed greeting from the local test fixture.

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/intent/INT-P3-900.md", "sha256": "20649db79738fdf649578286679d6fe05491e460c5a41e68ba0ed3161c47e7ed", "bytes": 516}

```text
+++
id = "INT-P3-900"
type = "intent"
title = "Inspect one rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"
outcome = "The test operator observes Hello rehearsal."

[relations]
+++

# Inspect one rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

An operator needs a fixed greeting for a disposable lifecycle rehearsal.
Success is an observed exact greeting and exported test evidence. No real product or release is involved.

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/release/REL-P3-900.md", "sha256": "a7cc92f770027bae2ffbf987a1a83eb36bd5e012632e1db07cf5f377f6b12935", "bytes": 529}

```text
+++
id = "REL-P3-900"
type = "release_contract"
title = "Prepare a test release record only"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"

[relations]
gates = ["WO-P3-900"]
+++

# Prepare a test release record only

Synthetic rehearsal input. This is not a real human decision.

Test version 0.0.1 binds this work and its verified test candidate. No tags, publication or deployment. Discard the disposable test project if replay fails. Retain the verification record and exact evidence.

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/requirements/REQ-P3-900.md", "sha256": "99028b8605edfd6e85d3cbfb0ee5243f43df69059e314ed1f0b9ab0bde0bbba4", "bytes": 539}

```text
+++
id = "REQ-P3-900"
type = "requirement"
title = "Return the exact rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"
statement = "Calling greeting() returns Hello rehearsal."
verification_method = ["test"]
priority = "must"
source = "Synthetic Phase 3 fixture"

[relations]
derives_from = ["CAP-P3-900"]
+++

# Return the exact rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

## Acceptance

Calling greeting() returns exactly `Hello rehearsal`.

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/specifications/SPEC-P3-900.md", "sha256": "0904f98bddc075f26c87e2e2ce603e3d74a497b8df85e1093bf3b0f5f35a45f9", "bytes": 539}

```text
+++
id = "SPEC-P3-900"
type = "specification"
title = "Fixed rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"
contract = "Return the fixed greeting without external effects."

[relations]
specifies = ["REQ-P3-900"]
+++

# Fixed rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

**P3-GREET-900.** The fixture function greeting() returns the string `Hello rehearsal`.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-900 | P3-GREET-900 |

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/verification/VER-P3-900.md", "sha256": "9c975ff911c736f30dab7688df8f136e66eefd81eebc09362d0345cef813e8b4", "bytes": 688}

```text
+++
id = "VER-P3-900"
type = "verification"
title = "Independently assert the greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"

[relations]
verifies = ["REQ-P3-900"]
+++

# Independently assert the greeting

Synthetic rehearsal input. This is not a real human decision.

## Independence

Expected text is fixed by REQ-P3-900, not candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-900 | test | exact greeting assertion | Equals Hello rehearsal |

Retain the actual assertion result in docs/engineering/lifecycle-pilot/evidence/WO-P3-900/assertion.json.

```

### Source data

{"path": "source/docs/engineering/lifecycle-pilot/work-orders/WO-P3-900.md", "sha256": "98ac1fa85021ac8a6f4d7a74973e2148dac97aa6ca69064d847818efc3771332", "bytes": 1096}

```text
+++
id = "WO-P3-900"
type = "work_order"
title = "Implement the synthetic greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"

[assurance]
commit_bound_verification = "required"
rationale = "Synthetic fixture decision for test assurance."
decided_by = "test-owner"

[execution_scope]
paths = ["src/greeting.py", "docs/engineering/lifecycle-pilot/"]

[relations]
implements = ["REQ-P3-900"]
specifications = ["SPEC-P3-900"]
verification = ["VER-P3-900"]
+++

# Implement the synthetic greeting

Synthetic rehearsal input. This is not a real human decision.

## Objective

Return the exact test greeting.

## In scope

Only the synthetic source, pilot definitions and test evidence.

## Out of scope

Real engineering records, real human decisions and external actions.

## Authorized decision envelope

All supplied actors are synthetic test labels.

## Required verification

Run VER-P3-900 on the exact clean fixture commit.

## Stop conditions

Stop when the released evaluator refuses.

## Completion

Retain actual outputs and candidate identity.

```

### Source data

{"path": "source/src/greeting.py", "sha256": "dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1", "bytes": 45}

```text
def greeting():
    return 'Hello rehearsal'

```
Before your first explanation, apply the supplied sections and read only the applicable plugin instructions and prerequisites still missing from context. Use the existing file tools below. This explicit test setup does not establish automatic startup instruction delivery.

# Focused hosted drafting diagnostic

You are Claude under WO-HAG-011. Work independently in the fresh private project
selected by `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag42\eff\claude-391\native\selection.json`. Git governs real work.

## Requested outcome

Prepare exactly one new intent draft for this request: "Adapt the existing greeting for a new audience." Inspect the fixture and its existing definitions. Author only supported content in the selected private service. Use domain lifecycle-pilot and synthetic owner test-owner. Keep the artifact draft. Imported -900 records are immutable history. Do not create other artifacts, change the fixture, approve anything, start work, freeze a baseline or exercise lifecycle decisions. Stop when this one draft is complete and its actual authoring findings are retained, or report the exact blocker.

## Inputs and boundaries

Apply the complete entry if supplied; otherwise read the selection. Follow the
selected plugin's skills/setup/SKILL.md route. Native Skill must resolve that
candidate. Reuse unchanged content; read missing prerequisites before acting.
After compaction recover the task, selection and original evidence.

Use tool_index for syntax and native file tools or its bounded readers.
Shell calls must use approved_shell_argv_prefix, one helper invocation each.
No scripts, wrappers, pipes, loops, direct client calls or other shell commands.
Normal permissions and hooks apply. Stop denials; do not change routes or permissions.

Write only under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag42\eff\claude-391\native\work`, using absolute paths. It exists; inputs are
read-only. Do not install software, activate a checkout, print credentials,
inspect auth stores, or change accounts or host settings. Authentication is
in the environment. Do not read prior trials. Choose operations yourself;
helpers supply no workflow.

## Report

Follow change/references/hosted-drafts.md: use the eligible clarification-only
reply or one short native-report.md in the work directory. Include its required
fields, readiness result and evidence links; keep the final reply consistent.
Do not duplicate captured metrics, observations or inventories. Before exhaustive
failure claims, use observations; it excludes later calls. Incomplete or unknown
capture requires a saved report stating that limit. Lifecycle, MCP parity,
reply recovery and export remain outside this draft-only qualification.
