+++
id = "VER-P3-901"
type = "verification"
title = "Verify greeting returns the required rehearsal string"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verify greeting returns the required rehearsal string

## Independence

The expected value `Hello rehearsal` is fixed by REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The pass condition derives from those definitions, not from candidate output or implementation inspection.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import `greeting` from `src/greeting.py` and capture the return value of `greeting()`. | The return value is the exact Python string `Hello rehearsal` with no leading or trailing whitespace. |

## Acceptance scenarios

1. **Exact match.** Call `greeting()` once. Assert `greeting() == "Hello rehearsal"`. The check passes when the assertion holds.
2. **Type.** Assert `isinstance(greeting(), str)`. The check passes when the return value is a `str`, not a subclass or other type.

## Evidence retention

Retain the assertion result as a JSON file at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-greeting-assertion.json`. The file records the actual return value, the expected value, the comparison result (pass or fail), and a UTC timestamp. The evaluator version is 0.22.1 on linux/amd64 (Python 3.13).

## Residual uncertainty

This contract verifies only the return value of `greeting()` at a single invocation. It does not verify side effects, concurrency behavior, or import-time effects, because REQ-P3-900 specifies only the return value.
