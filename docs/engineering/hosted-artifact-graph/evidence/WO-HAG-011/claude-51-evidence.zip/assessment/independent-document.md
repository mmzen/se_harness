+++
id = "INT-P3-001"
type = "intent"
title = "Confirm greeting fixture returns expected value"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"
outcome = "The test operator can confirm that greeting() returns exactly Hello rehearsal."

[relations]
+++

# Intent: Confirm greeting fixture returns expected value

## In plain words

The operator needs to confirm that the greeting fixture in `src/greeting.py` produces the exact string `Hello rehearsal` before further rehearsal steps proceed.

## Problem

The operator has no confirmed evidence that the greeting fixture returns the expected value. Without this confirmation, subsequent lifecycle rehearsal steps lack a verified starting point.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| Greeting fixture returns `Hello rehearsal` | not measured | Confirmed by source inspection or test execution | Single check at rehearsal time |

## Not this

- Changes to the greeting fixture behavior or return value.
- Automated production monitoring of the greeting output.
- Approval, release, or deployment of the greeting fixture.
- Coverage of requirements, specifications, or verification contracts beyond this intent.
- Real product or operational decisions.
