# Native drafting diagnostic report

Diagnostic scope: VER-HAG-008 EFF-04B
Candidate: `a99a00a1502753165ef1a85de725c87815d7b6a5`
Evaluator: 0.22.1 (`cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`)
Client: 0.22.2 (`a1689e9ef7e5716040df1d982feeb3a3e2287de062d92e37e28334ae01b498a4`)
Project: `eb465db9-98f5-427e-8d06-daaa896139a2`
Authority mode: `sandbox-projection`

## Outcome

One new verification-contract draft VER-P3-001 was authored in the hosted sandbox. It plans independent verification of `greeting()` against REQ-P3-900. The draft is admissible with zero incomplete fields. Existing VER-P3-900 and all imported -900 records remain unchanged.

## Reads performed

| Source | Content |
|---|---|
| `selection.json` | Endpoint, project, paths, evaluator, approved shell prefix |
| `inputs/combination.json` | Client and component identities for verification |
| `inputs/source-manifest.json` | Artifact list and source commit |
| `inputs/source/src/greeting.py` | Fixture: `greeting()` returns `'Hello rehearsal'` |
| `inputs/source/docs/engineering/lifecycle-pilot/requirements/REQ-P3-900.md` | Acceptance: calling `greeting()` returns exactly `Hello rehearsal` |
| `inputs/source/docs/engineering/lifecycle-pilot/verification/VER-P3-900.md` | Existing verification contract verifying REQ-P3-900 |
| `inputs/evaluator.json` | Evaluator identity for mutation commands |
| `inputs/native-tools.md` | Tool index: capabilities, typed fields, read operations |
| Plugin `setup/references/hosted-context.md` | Hosted selection route |
| Plugin `change/references/hosted-drafts.md` | Drafting procedure and content checks |

## Released instructions read

| Section | Source digest |
|---|---|
| `DRAFT_DEFINITIONS.md#read-this-when` | `43fb74d3...` |
| `DRAFT_DEFINITIONS.md#before-this-action` | `fef13ff6...` |
| `DRAFT_DEFINITIONS.md#draft-any-missing-definitions` | `c38865671...` |
| `DRAFT_DEFINITIONS.md#define-how-the-result-will-be-verified` | `16a9ea73...` |
| `ARTIFACT_AUTHORING.md#design-simplicity` | `29e9b629...` |
| `ARTIFACT_AUTHORING.md#verification` | `e6d36e5f...` |
| `COMMUNICATION.md#communication` | `2aa70bc7...` |
| `CONTINUE.md#procedure` | `c2906603...` |

## Operations and evidence

| # | Operation | Key | Outcome | Evidence path |
|---|---|---|---|---|
| 1 | `identity` | — | Client SHA-256 matches combination | (inline) |
| 2 | `remote status` | — | Ready, all components match | `work/status-001.json` |
| 3 | `remote import` | `import-source-001` | Accepted; baseline created; project 0→1 | `work/import-001.json` + `.evidence/` |
| 4 | `remote draft-open` | `draft-open-001` | Context `559cdba0-0ca0-43fb-9aa3-1bc228275cbb` opened; project 1→2 | `work/draft-open-001.json` + `.evidence/` |
| 5 | `remote create-artifact` | `create-ver-001` | VER-P3-001 created, template returned; project 2→3 | `work/create-ver-001.json` + `.evidence/` |
| 6 | `remote revise-artifact` | `revise-ver-001` | VER-P3-001 completed, admissible, 0 incomplete; project 3→4 | `work/revise-ver-001.json` + `.evidence/` |
| 7 | `remote read` | `read-ver-001` | **Failed** (exit 2): mutation fields passed to read operation | `work/read-ver-001.json` |
| 8 | `remote read` | — | Recovery: VER-P3-001 document confirmed, complete, no unresolved refs | `work/read-ver-002.json` + `.evidence/` |
| 9 | `assert-greeting` | — | Passed: `exact greeting passed` | `work/assert-greeting-001.json` |

## Draft artifact

- **ID:** VER-P3-001
- **Revision:** `sha256:a0941ef753b869cb580decd63c670c20c5c48269dc892b1596ae6068b5c0fcd7`
- **Document SHA-256:** `d47c529c24d81bd343828ab1c261a3c4c8e8ce99ba7994cdc51aab2b8c053bc2`
- **Path:** `docs/engineering/lifecycle-pilot/verification/VER-P3-001.md`
- **Verifies:** REQ-P3-900
- **Domain:** lifecycle-pilot
- **Owner:** test-owner
- **Local draft file:** `work/VER-P3-001-draft.md`

## Verification contract content summary

The contract defines one acceptance test: import `greeting` from `src/greeting.py`, call it with no arguments, and assert the return value equals `Hello rehearsal` using strict equality. The expected value derives from REQ-P3-900 acceptance criteria, not from candidate output. The pass condition requires an exact string match. Evidence retention specifies the assertion result in the work order evidence directory.

## Failures

1. **read-ver-001 (exit 2):** Typed read does not accept `--evaluator-file`, `--operation-key`, or `--expected-project-version`. The tool index states "no mutation fields" for read operations. Recovered by retrying as read-ver-002 without those fields. No data loss; the failed call was not sent to the server.

## Findings

1. The native helper's typed `remote read` rejects mutation-only flags (`--evaluator-file`, `--operation-key`, `--expected-project-version`) with exit 2 and outcome `not_sent`. The tool index documents this as "no mutation fields" but the exact excluded flags must be inferred.
2. The evaluator produced one background advisory (`W-AUT-022`) on SPEC-P3-900 referencing undefined rule `P3-GREET-900`. This is a pre-existing condition in the imported source, not introduced by this draft.
3. Template creation with `--include-document` returns the template in the same evidence directory, saving a separate read call.
4. Automatic ID allocation in an existing domain (`lifecycle-pilot`) assigned `VER-P3-001` following the domain's ID pattern.

## Limits

- This diagnostic covers draft preparation only. No lifecycle decisions, approvals, work starts, baseline freezes, or verification execution occurred.
- No complete NQ-01 through NQ-05 claim: lifecycle exercise, MCP parity, reply recovery, and export are outside this focused scope.
- The fixture assertion confirms `greeting()` returns `Hello rehearsal` in the local environment; this is not a hosted verification record.
- Content quality is the drafter's assessment; template admission does not establish content correctness.
