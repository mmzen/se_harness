Before your first explanation, read the selected task inputs, applicable plugin instructions and their required communication policy. Use the existing file tools below. This explicit test setup does not establish automatic startup instruction delivery.

# Focused hosted drafting diagnostic

You are Claude under the approved WO-HAG-011 efficiency comparison. Work independently
in the fresh private hosted project in C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-efficiency-revised-20261009\claude-12\native\selection.json. This run tests instruction
discovery during draft preparation only. Git remains authoritative for real work.

## Requested outcome

Prepare exactly one new verification-contract draft for an independent reviewer
who needs a plan to check the existing fixture against REQ-P3-900: greeting()
returns exactly Hello rehearsal. This is an explicitly requested alternative
authoring exercise; existing VER-P3-900 and all imported -900 records remain
unchanged. Do not claim a missing requirement or verification contract.

Inspect the relevant fixture and governing requirement. Author the new contract
in the selected private service, using domain lifecycle-pilot and synthetic owner
test-owner. Define an independently derived expected result, the check to perform,
its pass condition and the evidence to retain. Plan verification only; do not claim
that tests ran or that the result is verified. Keep the artifact draft. Do not
create other artifacts, approve anything, start work, freeze a baseline or make
lifecycle decisions. Stop when the draft and actual authoring findings are saved,
or report the precise blocker.

## Entry and tools

Read C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-efficiency-revised-20261009\claude-12\native\selection.json. Begin with the candidate plugin's normal verity-plane:setup
Skill for this explicit hosted selection, then follow its current-task routes.
The client is installed; do not install software or activate a checkout. The
selected released_resources directory contains the exact 0.22.1 procedures.

The selection's tool_index is the single command/file-discovery reference.
Read it before choosing tool syntax. It lists capabilities and exact schema
locations without request values or a workflow sequence. Read only applicable
procedure sections and the typed client inputs (or raw schema) for the operation you select.

Use native Read/Write/Edit and only the approved_shell_argv_prefix for shell
calls, one helper call per invocation. No scripts, wrappers, pipes, loops, direct
client calls or other shell commands. Normal permissions and hooks apply. Stop
a denied action; do not change permissions or try alternate routes.

Keep every draft, request, result and transient progress note under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-efficiency-revised-20261009\claude-12\native\work`
using absolute paths. This output directory already exists. Inputs are read-only.
Keep current IDs, versions and exact result paths in the note; after compaction,
recover task, selection, note and original evidence before acting.

Never print credentials, inspect auth stores, change account/host settings or
read prior trials. Authentication is in the process environment. Helpers perform
no hidden workflow; construct your requests from current inputs and instructions.

Finish with native-report.md and native-observations.json at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-efficiency-revised-20261009\claude-12\native`. Report actual
reads and triggers, exact evidence/digest sources, draft IDs/paths, findings,
failures and limits. No complete NQ-01--05 claim: lifecycle, MCP parity, reply
recovery and export are outside this focused diagnostic.
