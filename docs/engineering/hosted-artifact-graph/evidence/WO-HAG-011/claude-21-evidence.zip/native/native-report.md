# Native drafting diagnostic report

**Diagnostic scope:** VER-HAG-008 EFF-04A
**Agent:** Claude Opus 4.6 (claude-21, native route)
**Date:** 2026-10-09
**Evaluator:** 0.22.1 (archive `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`)
**Client:** 0.22.2 (wheel `d0e13c52fe644a0f7b7d935bb8bd61e22fa8867e9c6a8c446f7e0a6b8334188d`)

## Requested outcome

Prepare one new intent draft establishing that the existing fixture's
`greeting()` returns exactly `Hello rehearsal`. Use domain `lifecycle-pilot`
and synthetic owner `test-owner`.

## Fixture inspection

Source file: `inputs/source/src/greeting.py`
Observed content: `def greeting(): return 'Hello rehearsal'`
The function returns the exact string `Hello rehearsal`.

## Operations performed

| # | Operation | Key | Project version | Outcome | Evidence path |
|---|-----------|-----|-----------------|---------|---------------|
| 1 | `remote status` | — | 0 | Service ready, `sandbox-projection`, `test_copy: true` | `work/status-01` |
| 2 | `remote import` | `import-baseline-900` | 0 → 1 | 7 baseline artifacts imported, valid, 0 errors | `work/import-01.evidence` |
| 3 | `remote draft-open` | `draft-open-01` | 1 → 2 | Context `3dab9926-ebdc-4a52-bf44-119a0c8f6531` opened at version 0 | `work/draft-open-01.evidence` |
| 4 | `remote create-artifact` | `create-intent-01` | 2 → 3 | `INT-P3-001` created, template returned via `--include-document` | `work/create-intent-01.evidence` |
| 5 | `remote revise-artifact` | `revise-intent-01` | 3 → 4 | Completed draft accepted, 0 errors, 0 incomplete | `work/revise-intent-01.evidence` |

## Draft artifact

- **Artifact ID:** `INT-P3-001`
- **Type:** `intent`
- **Domain:** `lifecycle-pilot`
- **Status:** `draft`
- **Path:** `docs/engineering/lifecycle-pilot/intent/INT-P3-001.md`
- **Initial revision (template):** `sha256:e99fd285aa56764a3665d0124e5ae58f4431c831813b777209941e9080d893a4`
- **Final revision (completed):** `sha256:3a989e3b2909a1f9a60aa7440015efe4c0c001b63760ba2b4fc6844f12556986`
- **Completed document file:** `work/INT-P3-001-draft.md`

## Authoring findings

The evaluator's draft validation after revision reports:

- **Admissible:** true
- **Errors:** 0
- **Incomplete fields:** 0
- **Background advisories:** 1 (pre-existing, unrelated to this draft)
  - `W-AUT-022`: Coverage row `REQ-P3-900` names undefined rule `P3-GREET-900` in `SPEC-P3-900.md`. This advisory belongs to the imported -900 baseline and is not caused by `INT-P3-001`.

All template placeholders were replaced. The intent checklist items from
`docs/engineering/ARTIFACT_AUTHORING.md` were applied:

1. The problem, affected party (operator), and outcome are stated.
2. The smallest useful outcome is a confirmed exact return value.
3. The success measure baseline is stated as `not measured`.
4. Scope limits exclude fixture modification, lifecycle decisions, and
   changes to imported -900 records.

## Content review observations

- The `outcome` field names the observable result: the operator confirms
  `greeting()` returns exactly `Hello rehearsal`.
- The success measure is observable by manual inspection or test execution.
  It is not an acceptance test; it names what an operator confirms after delivery.
- The "Not this" section states four explicit scope limits.
- No relations are declared. Intent artifacts require no declared links per
  the DEFINITION_LINKS definition table.

## Reads performed

| File | Purpose |
|------|---------|
| `selection.json` | Selected project, endpoint, paths, evaluator |
| `task.md` | Task instructions |
| `native-tools.md` | Tool index and command syntax |
| `hosted-context.md` | Setup route for hosted selection |
| `hosted-drafts.md` | Drafting procedure and content checks |
| `source/src/greeting.py` | Fixture inspection |
| `combination.json` | Component identity verification |
| `configuration.json` | Authority mode and service configuration |
| `source/docs/engineering/lifecycle-pilot/intent/INT-P3-900.md` | Existing imported intent |

## Not performed

- No other artifacts were created.
- No approvals, lifecycle transitions, or baseline freezes occurred.
- No work was started or authorized.
- No decisions (DEC) were exercised.
- Imported -900 records were not modified.
- No complete NQ-01 through NQ-05 claim is made. Lifecycle rehearsal,
  MCP parity, reply recovery, and export are outside this focused diagnostic.

## Failures and denials

None. All five remote operations succeeded on the first attempt.

## Limits

- Draft admission does not establish content quality or approval readiness.
- The background advisory on `SPEC-P3-900` is pre-existing; this diagnostic
  did not assess or resolve it.
- This diagnostic tests instruction discovery during draft preparation only.
  Git remains authoritative for real work.
