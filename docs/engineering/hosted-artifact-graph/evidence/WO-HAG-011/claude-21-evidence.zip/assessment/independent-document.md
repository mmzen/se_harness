+++
id = "INT-P3-001"
type = "intent"
title = "Establish that the fixture greeting returns the expected value"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"
outcome = "The operator can confirm that greeting() returns exactly Hello rehearsal."

[relations]
+++

# Intent: Establish that the fixture greeting returns the expected value

## In plain words

An operator needs to confirm that the existing fixture function `greeting()`
in `src/greeting.py` returns the exact string `Hello rehearsal`. This intent
establishes the purpose for that confirmation.

## Problem

The operator has no accepted definition that states the expected return value of
the `greeting()` function. Without a governing intent, verification of the
greeting output has no agreed purpose or success condition.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| The operator confirms that `greeting()` returns exactly `Hello rehearsal` | not measured | The operator observes the exact return value | Manual inspection of the fixture source or a test execution |

## Not this

- This intent does not cover changes to the greeting value or function signature.
- This intent does not establish a new fixture or modify `src/greeting.py`.
- This intent does not authorize lifecycle decisions, approvals, or releases.
- This intent does not replace or modify the imported INT-P3-900 record.
