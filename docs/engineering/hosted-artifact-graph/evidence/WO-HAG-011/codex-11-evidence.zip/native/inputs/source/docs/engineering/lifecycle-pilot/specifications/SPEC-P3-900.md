+++
id = "SPEC-P3-900"
type = "specification"
title = "Fixed rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"
contract = "Return the fixed greeting without external effects."

[relations]
specifies = ["REQ-P3-900"]
+++

# Fixed rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

**P3-GREET-900.** The fixture function greeting() returns the string `Hello rehearsal`.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-900 | P3-GREET-900 |
