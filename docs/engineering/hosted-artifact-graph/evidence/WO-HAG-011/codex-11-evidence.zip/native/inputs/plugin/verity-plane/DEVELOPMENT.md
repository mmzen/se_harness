Development-only package. Not a release or publication artifact.
