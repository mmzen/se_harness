def greeting():
    return 'Hello rehearsal'
