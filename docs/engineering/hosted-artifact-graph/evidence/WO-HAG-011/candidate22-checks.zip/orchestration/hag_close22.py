from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_efficiency_close08.py').read_text()
source=source.replace('hag-efficiency-entry-20261009','hag-efficiency-clarification-20261010').replace('hag-efficiency08-','hag-efficiency22-')
source=source.replace("assert trial in ('claude-21','claude-22','claude-23','claude-24')", "assert trial in ('claude-161','claude-162','claude-163','claude-164','codex-161','codex-162')")
exec(compile(source,'close16','exec'),{'__file__':__file__,'__name__':'__main__'})
