# Native diagnostic report

## Content readiness

**Incomplete.** The draft template validation passed (admissible, no errors, no
incomplete items), but the content review identifies unresolved findings that
affect content readiness.

## Saved artifact

- **Artifact:** `INT-P3-001`
- **Type:** `intent`
- **Domain:** `lifecycle-pilot`
- **Owner:** `test-owner`
- **Title:** Establish fixture greeting correctness for lifecycle rehearsal
- **Current revision:** `sha256:7892e255e0ea6b77b2842fa0f5c99bdc5b659e816674ecffae534352b01e5c82`
- **Context:** `adfa30b1-e17c-4492-82da-b87913e8aeac` (version 2)
- **Project version:** 4

## Current versions

- **Evaluator:** 0.22.1 (`archive_sha256: cb35c3c4...863053`)
- **Client:** 0.22.2 (`wheel_sha256: a8a39420...10af8`)

## Document and result paths

| Item | Path |
| --- | --- |
| Completed document | `work/INT-P3-001-draft.md` |
| Create result | `work/create-intent-001.json` |
| Create template | `work/create-intent-001.json.evidence/2-document-1.md` |
| Revise result | `work/revise-intent-001.json` |
| Revise evidence | `work/revise-intent-001.json.evidence/` |
| Import result | `work/import-001.json` |
| Draft-open result | `work/draft-open-001.json` |
| Service status | `work/status-001.json` |

## Template-validation result

Draft validation (`se-harness-draft-validation-v1`) returned:

- **Admissible:** true
- **Errors:** 0
- **Incomplete:** 0
- **Background:** 1 advisory (`W-AUT-022` on SPEC-P3-900 — pre-existing, unrelated
  to INT-P3-001)

All template placeholders resolved. No required authoring links are missing
(intent has no required `[relations]`).

## Content-review findings (agent-performed)

Template validation checks shape and required links only. The evaluator states
`content_review: "not_assessed"`. The following findings are from the agent's
content review against the intent checklist and the hosted-drafts input checks.

### 1. Purpose-and-measure mismatch

The success measure — "Operator confirms greeting fixture returns
`Hello rehearsal`" — describes confirming expected program output. The
hosted-drafts procedure notes that confirming expected program output alone
describes preparation or verification, not an operational benefit. The measure
resembles an acceptance check rather than an operational observation. The
supplied task inputs do not provide a distinct operational benefit beyond fixture
confirmation. This finding is unresolved: the operator would need to supply a
clearer operational benefit, or accept this as a verification-scoped intent.

### 2. Existing coverage overlap

INT-P3-900 already covers "Inspect one rehearsal greeting" with outcome "The
test operator observes Hello rehearsal." INT-P3-001 addresses a similar purpose.
The task explicitly requests a new intent, and the imported -900 records are
immutable baseline history. This overlap is noted, not blocked.

### 3. Success-measure table guidance

The intent template states that a measure proved by a test, validator, or
verification belongs in the verification contract. The stated measure
("Operator confirms greeting fixture returns `Hello rehearsal`") is borderline:
it names operator confirmation (operational), but "confirms returns" resembles
a test assertion. A clearer separation between the operational measure and the
acceptance check would strengthen the intent.

## Unresolved inputs or effects

- The operational benefit distinct from verification has not been supplied by
  the task inputs. The intent was completed with the best available
  interpretation (reliable rehearsal input).
- No lifecycle transitions, approvals, or other artifacts were created.

## Fixture inspection

Source: `inputs/source/src/greeting.py`

The `greeting()` function returns exactly `'Hello rehearsal'`. This is confirmed
by direct file inspection (method: source inspection, not executed test).

## Result

One intent draft (`INT-P3-001`) was created and revised in domain
`lifecycle-pilot`. Template validation passed with no errors and no incomplete
items. Content review identified three findings, of which the purpose-and-measure
mismatch is the primary unresolved item. Content readiness is incomplete pending
operator input on the operational benefit.

Report path: `work/native-report.md`
