+++
id = "INT-P3-001"
type = "intent"
title = "Establish fixture greeting correctness for lifecycle rehearsal"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
outcome = "The test operator can rely on a confirmed greeting fixture for lifecycle rehearsal."

[relations]
+++

# Establish fixture greeting correctness for lifecycle rehearsal

## In plain words

The operator needs to know that the greeting fixture returns the expected value before using it as a stable input for lifecycle rehearsal.

## Problem

The greeting fixture in `src/greeting.py` provides a `greeting()` function used as a stable input for disposable lifecycle rehearsal. The operator has no independent confirmation that this function returns exactly `Hello rehearsal`. Without that confirmation, downstream rehearsal activities that depend on the fixture output cannot be trusted.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| Operator confirms greeting fixture returns `Hello rehearsal` | not measured | Confirmed once during rehearsal setup | Manual operator check before rehearsal |

## Not this

- Changes to the greeting fixture itself.
- Real product or release decisions.
- Approval or lifecycle transitions beyond draft preparation.
- Modification of imported baseline records (INT-P3-900 and related -900 artifacts).
- Automated continuous monitoring of fixture output.
