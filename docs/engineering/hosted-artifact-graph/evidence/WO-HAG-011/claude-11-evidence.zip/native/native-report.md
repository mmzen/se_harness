# Native diagnostic report — WO-HAG-011 EFF-04A

## Scope

Focused hosted drafting diagnostic under WO-HAG-011. One intent draft
prepared in a private sandbox. No lifecycle decisions, approvals, baseline
freezes or complete NQ-01–05 claims.

## Selection

| Field | Value |
| --- | --- |
| Project ID | `54295c07-e9d9-42fe-9b56-46e71621c974` |
| Endpoint | `http://127.0.0.1:18611` |
| Authority mode | `sandbox-projection` |
| Test copy | `true` |
| Evaluator | 0.22.1 (payload SHA-256 `0e7b7c2bc...79e7ff`) |
| Client | 0.22.2 (wheel SHA-256 `a1689e9ef...b498a4`) |
| Combination ID | `sha256:f28a9b478d64a11b9258fb1889fee0524b6d86510660039f732d60601de8f520` |
| Source commit | `a99a00a1502753165ef1a85de725c87815d7b6a5` |

## Operations performed

| # | Operation | Key | Record | Outcome |
| --- | --- | --- | --- | --- |
| 1 | `identity` | — | (stdout) | Client wheel SHA-256 matches combination |
| 2 | `remote status` | — | `work/status-001` | Service ready, all components match combination |
| 3 | `assert-greeting` | — | `work/assert-greeting-001` | Passed: `greeting()` returns `Hello rehearsal` |
| 4 | `remote import` | `import-source-001` | `work/import-001` | Accepted; 7 artifacts imported; project 0→1 |
| 5 | `remote draft-open` | `draft-open-001` | `work/draft-open-001` | Context `4b9a99ee-55f6-4de7-a300-4cb10bdd3e57` opened; project 1→2 |
| 6 | `remote create-artifact` | `create-intent-001` | `work/create-intent-001` | INT-P3-001 created; admissible, 10 incomplete fields; project 2→3 |
| 7 | `remote revise-artifact` | `revise-intent-001` | `work/revise-intent-001` | INT-P3-001 revised; admissible, 0 incomplete, 0 errors; project 3→4 |
| 8 | `remote read` | `read-intent-001` | `work/read-intent-001` | Failed: `--evaluator-file` not valid for read |
| 9 | `remote read` | `read-intent-001` | `work/read-intent-002` | Read confirmed; document matches authored content |

## Instruction reads

| Resource | Method |
| --- | --- |
| `docs/engineering/harness/DRAFT_DEFINITIONS.md` sections: read-this-when, before-this-action, draft-any-missing-definitions | `instructions` helper |
| `docs/engineering/ARTIFACT_AUTHORING.md` sections: design-simplicity, intent | `instructions` helper |
| `docs/engineering/harness/COMMUNICATION.md#communication` | `instructions` helper |
| `change/references/hosted-drafts.md` | Native Read |
| `setup/references/hosted-context.md` | Native Read |
| `inputs/native-tools.md` (tool index) | Native Read |
| `inputs/combination.json` | Native Read |
| `inputs/source/src/greeting.py` | Native Read |

## Draft artifact

| Field | Value |
| --- | --- |
| Artifact ID | `INT-P3-001` |
| Type | `intent` |
| Domain | `lifecycle-pilot` |
| Owner | `test-owner` |
| Status | `draft` |
| Final revision | `sha256:e64e2ad15817708ce3efd91355abd4ba4f40c32a87269e65c55fb15067ef02bd` |
| Document SHA-256 | `9fe0ef5f6c48b84337011918fa8a17d8fb963f56c99486bbc6d02f5f05bed2b5` |
| Path | `docs/engineering/lifecycle-pilot/intent/INT-P3-001.md` |
| Context | `4b9a99ee-55f6-4de7-a300-4cb10bdd3e57` version 2 |
| Project version | 4 |

## Authoring findings

### Evaluator validation

- Admissible: `true`
- Errors: 0
- Incomplete fields: 0
- Background advisory: `W-AUT-022` — coverage row `REQ-P3-900` names undefined rule `P3-GREET-900` (pre-existing from imported SPEC-P3-900; not caused by this draft)

### Content review (agent assessment)

The intent checklist has four items. All four are addressed in the document:

1. **Problem, who it affects, outcome** — stated in Problem section and frontmatter `outcome`.
2. **Smallest useful outcome and agreed constraints** — the outcome is confirmation that `greeting()` returns `Hello rehearsal`.
3. **How the owner will know; baseline** — success measures table with baseline `not measured`.
4. **Scope limits** — four items in the Not this section.

**Unresolved content concern:** The success measures "Observed" column describes an acceptance check method ("Confirmed by executing the fixture and comparing the return value") rather than an operational observation point ("where and how often, in operation"). The template distinguishes operational measures from acceptance checks; the latter belongs in a verification contract. Template admission and zero incomplete fields do not resolve this content quality issue. The draft is structurally complete but has this unresolved content distinction.

### Fixture verification

Source inspection of `src/greeting.py` confirmed `greeting()` returns `'Hello rehearsal'`. The `assert-greeting` helper confirmed the same result independently.

## Failures

1. `read-intent-001` (record `work/read-intent-001`): `--evaluator-file` is not valid for the typed `read` operation. Recovered by retrying without mutation fields as `read-intent-002`.

## Limits

- This diagnostic covers draft preparation only.
- No lifecycle decisions, approvals, verification, release, or export actions were performed.
- Lifecycle, MCP parity, reply recovery, and export are outside this focused diagnostic.
- No complete NQ-01–05 claim is made.
- Git remains authoritative; sandbox-projection authority grants no approval or deployment right.
- The content quality concern in the Observed column is noted but not resolved within this diagnostic.
