+++
id = "INT-P3-001"
type = "intent"
title = "Adapt the rehearsal greeting for a new audience"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
outcome = "A new audience receives a greeting adapted to their context instead of the fixed rehearsal text."

[relations]
+++

# Intent: Adapt the rehearsal greeting for a new audience

## In plain words

The greeting fixture currently returns a single fixed string for rehearsal operators. A different audience needs a greeting that addresses them directly.

## Problem

Today, `greeting()` returns `Hello rehearsal`. This fixed text serves only the rehearsal operator described in INT-P3-900. When a different audience needs the greeting, they receive text that does not address them. No mechanism exists to produce a greeting adapted to another audience.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| The new audience receives a greeting that addresses them | not measured | The adapted greeting is returned by the greeting function | Manual inspection after delivery |

## Not this

- Changing the existing `Hello rehearsal` behavior covered by INT-P3-900.
- Internationalisation or locale selection.
- Dynamic per-user personalisation beyond the stated audience adaptation.
- Deployment, release or operational monitoring of the greeting.
