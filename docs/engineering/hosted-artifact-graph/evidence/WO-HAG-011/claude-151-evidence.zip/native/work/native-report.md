# Native report — INT-P3-001 intent draft

## Content readiness

**Complete** against the `intent` checklist in `docs/engineering/ARTIFACT_AUTHORING.md`.

| Checklist item | Status | Source |
| --- | --- | --- |
| Present problem, who it affects, outcome wanted | Complete | Problem section: `greeting()` returns fixed text, other audiences receive text that does not address them |
| Smallest useful outcome and agreed constraints | Complete | Outcome field and "Not this" limit scope to one audience adaptation |
| How the owner knows the change helped | Complete | Success measures table; baseline is "not measured" |
| Important scope limits | Complete | Four explicit exclusions in "Not this" |

Content review method: source inspection of the existing fixture (`src/greeting.py`), existing intent INT-P3-900, and the submitted document. No executed tests; no evaluator content assessment (evaluator reports `content_review: not_assessed`, meaning shape-only validation).

## Saved state

| Field | Value |
| --- | --- |
| Artifact | `INT-P3-001` |
| Type | `intent` |
| Domain | `lifecycle-pilot` |
| Owner | `test-owner` |
| Revision | `sha256:a1edf6c4e48b7a5d02c1bd70fa3cc6d735644a815354089e34f249340efe83f3` |
| Document SHA-256 | `e9ae9576d21802dc554f2e65397a9029b6413fde76eb7c817647ada835492bd7` |
| Context | `639f6a32-07f9-44b2-93fa-de41ad34488e` version 2 |
| Project version | 4 |
| Baseline | `se-harness-artifact-baseline/v1:sha256:cc355215b060872695949b5e0763d581d5ad6bf146b84a207fd6c8be023cc666` |
| Receipt (create) | `bc95ad35-de26-4222-8325-c6a4547d2731` |
| Receipt (revise) | `8efc8b9c-f212-4015-876b-f90dd411267b` |

## Validation and review

**Evaluator draft validation** (revise-artifact response):
- `admissible: true`
- Errors: 0
- Incomplete fields: 0
- Background: 1 advisory (`W-AUT-022` on SPEC-P3-900 — pre-existing, unrelated to this draft)

**Content review** (agent, source inspection):
- All template placeholders replaced with supported content.
- Problem identifies the present situation, the affected party, and why it must change.
- Outcome field names who benefits and the observable result.
- Success measure uses `not measured` as baseline; target and observation method are stated.
- Scope limits exclude changes to existing INT-P3-900 behavior, internationalisation, dynamic personalisation, and operational concerns.
- No unsupported claims, duplicate checks, or constraints absent from the request.

**Observations:** Zero native failures, zero denied calls. Evidence retained in command record directories under `work/`.

## Evidence paths

- Service status: `work/status-001.evidence/`
- Import: `work/import-001.evidence/`
- Draft-open: `work/draft-open-001.evidence/`
- Create artifact: `work/create-intent-001.evidence/`
- Revise artifact: `work/revise-intent-001.evidence/`
- Read-back: `work/read-intent-001.evidence/`
- Authored document: `work/INT-P3-001.md`
