+++
id = "VER-P3-001"
type = "verification"
title = "Verify greeting return value by direct call"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verify greeting return value by direct call

## Independence

The expected value `Hello rehearsal` is fixed by REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The pass condition derives from those definitions, not from candidate output or implementation inspection.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Direct call to greeting() and string comparison | greeting() returns exactly the string `Hello rehearsal` |

## Acceptance scenarios

1. Import `greeting` from `src/greeting.py`.
2. Call `greeting()` with no arguments.
3. Assert that the return value equals the string `Hello rehearsal` using a strict equality check (`==`).
4. Assert that the return type is `str`.

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-assertion.json`. The evidence file records the actual return value, the expected value, the comparison result, and the platform. The evaluator is se_harness 0.22.1 on linux/amd64, Python 3.13.16.
