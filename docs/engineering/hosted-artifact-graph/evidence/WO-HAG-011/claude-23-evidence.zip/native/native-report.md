# Native drafting diagnostic report

## Task

Prepare one new verification-contract draft (VER) for REQ-P3-900 in the hosted sandbox, using domain `lifecycle-pilot` and owner `test-owner`. The existing VER-P3-900 and all imported -900 records remain unchanged.

## Reads performed

| Source | Path | Purpose |
|---|---|---|
| selection.json | `inputs/selection.json` | Endpoint, project, evaluator, paths, token variable |
| task.md | `native/task.md` | Task instructions and selected instruction entry |
| native-tools.md | `inputs/native-tools.md` | Tool index for command syntax |
| REQ-P3-900 | `inputs/source/docs/engineering/lifecycle-pilot/requirements/REQ-P3-900.md` | Acceptance criteria: `greeting()` returns exactly `Hello rehearsal` |
| SPEC-P3-900 | `inputs/source/docs/engineering/lifecycle-pilot/specifications/SPEC-P3-900.md` | Rule P3-GREET-900: `greeting()` returns `Hello rehearsal` |
| VER-P3-900 | `inputs/source/docs/engineering/lifecycle-pilot/verification/VER-P3-900.md` | Existing verification contract (unchanged) |
| src/greeting.py | `inputs/source/src/greeting.py` | Fixture: `def greeting(): return 'Hello rehearsal'` |
| hosted-context.md | `inputs/plugin/verity-plane/skills/setup/references/hosted-context.md` | Hosted selection route |
| hosted-drafts.md | `inputs/plugin/verity-plane/skills/change/references/hosted-drafts.md` | Hosted drafting procedure |
| Template document | `work/create-ver-001.evidence/2-document-1.md` | Created template for VER-P3-001 |

## Triggers

1. `verity-plane:setup` skill invoked for hosted selection.
2. `remote status` — confirmed service readiness, `sandbox-projection` authority, evaluator 0.22.1, `test_copy: true`.
3. `remote import` — imported source baseline (7 artifacts, valid, 1 advisory about P3-GREET-900 rule).
4. `remote draft-open` — opened drafting context against baseline with WO-P3-900.
5. `remote create-artifact` — created VER-P3-001 in domain `lifecycle-pilot`, type `verification`, with `--include-document`.
6. `remote revise-artifact` — submitted authored document for VER-P3-001.
7. `remote read` — read back the revised document to verify content integrity.
8. `observations` — gathered native call summary.

## Draft artifact

- **ID:** `VER-P3-001`
- **Type:** `verification`
- **Path:** `docs/engineering/lifecycle-pilot/verification/VER-P3-001.md`
- **Revision:** `sha256:30bec8de3ef61c09baebcb8e344df7184a68d9b403c30b6e54735f77bcbb349b`
- **Document SHA-256:** `fd4f0f792a14be3b615aa17d35f9216b1cfcc3c2d3ca97ef090b5a4f6fd5313d`
- **Relations:** `verifies = ["REQ-P3-900"]`
- **Status:** `draft`
- **Owner:** `test-owner`
- **Admissible:** yes
- **Errors:** 0
- **Incomplete fields:** 0

## Evidence and digest sources

| Record | Evidence directory | Purpose |
|---|---|---|
| status-001 | `work/status-001` | Service status |
| import-001 | `work/import-001.evidence/` | Baseline import |
| draft-open-001 | `work/draft-open-001.evidence/` | Draft context |
| create-ver-001 | `work/create-ver-001.evidence/` | Artifact creation and template |
| revise-ver-001 | `work/revise-ver-001.evidence/` | Document revision |
| read-ver-001 | `work/read-ver-001.evidence/` | Read-back verification |

Authored document retained at `work/VER-P3-001-authored.md`.

## Verification contract content summary

- **Independence:** Expected value `Hello rehearsal` derives from REQ-P3-900 and SPEC-P3-900 rule P3-GREET-900, not from candidate output.
- **Method:** test
- **Check:** Call `greeting()` from `src/greeting.py` with no arguments and compare the return value.
- **Pass condition:** Return value equals exactly `Hello rehearsal`.
- **Evidence retention:** `docs/engineering/lifecycle-pilot/evidence/VER-P3-001/greeting-assertion.json`

## Findings

1. All draft validation passed: admissible, zero errors, zero incomplete fields.
2. One background advisory persists from the imported baseline: `W-AUT-022` — coverage row `REQ-P3-900` in SPEC-P3-900 names undefined rule `P3-GREET-900`. This is a pre-existing condition in the imported source, not introduced by this draft.
3. No tests were executed. The contract plans verification; it does not claim execution or verified status.
4. The existing VER-P3-900 and all other -900 artifacts remain unchanged.

## Failures and denials

None. All six remote operations succeeded. No native call failures were reported.

## Limits

- This diagnostic covers draft preparation only. Lifecycle transitions (approval, start, freeze, verification record, release) are outside scope.
- MCP parity, reply recovery, and export are not assessed.
- No complete NQ-01 through NQ-05 claim is made.
- The observations snapshot (before this report) recorded 20 native calls and a peak input context of 57,425 tokens.
