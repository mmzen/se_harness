+++
id = "VER-P3-001"
type = "verification"
title = "Verify exact rehearsal greeting output"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verify exact rehearsal greeting output

## Independence

The expected value `Hello rehearsal` derives from REQ-P3-900 and SPEC-P3-900 rule P3-GREET-900. The verifier compares the actual return value of `greeting()` against this independently fixed string. The expected result does not depend on candidate output or implementation details.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Call `greeting()` and capture the return value | Return value equals exactly `Hello rehearsal` |

## Acceptance scenarios

1. Import `greeting` from `src/greeting.py`.
2. Call `greeting()` with no arguments.
3. Assert that the return value is the string `Hello rehearsal`.
4. Record the actual return value and the assertion result (pass or fail) in structured JSON evidence.

Platform: Python 3.11 or later.
Evaluator: se_harness 0.22.1.

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/VER-P3-001/greeting-assertion.json`. The evidence file records the actual return value, the expected value, the comparison result, and the timestamp of execution.
