"""Independent post-run metrics, immutable-input check and exact remote readback."""
import base64,json,os,sys
from pathlib import Path
import hag221_execute as h
h.O=h.W/'hag-efficiency-proposal-20261008';trial=sys.argv[1];root=h.O/trial;native=root/'native'
assert (native/'session.json').exists()
sys.path.insert(0,str(h.R/'tests/hosted_artifact_graph'))
from summarize_native import summarize
summary=summarize(native);h.write(h.O/(trial+'-summary.json'),summary)
s=json.loads((root/'selection.json').read_text());inventory=json.loads((native/'inputs/inventory.json').read_text())
changes=[x['relative'] for x in inventory['files'] if h.sha(Path(x['path']).read_bytes())!=x['sha256']]
receipts=[]
for path in (native/'work').rglob('*.json'):
 try:v=json.loads(path.read_text());response=json.loads(v['stdout'])
 except (ValueError,KeyError,TypeError):continue
 if isinstance(response,dict):
  result=response.get('result',response)
  if 'revise-artifact' in v.get('argv',[]) and result.get('outcome')=='accepted':receipts.append((result,v))
assessment={'input_changes':changes,'metrics':trial+'-summary.json','content_review':'pending independent human-readable assessment'}
if receipts:
 result,record=max(receipts,key=lambda x:x[0]['versions']['project']['after'])
 artifact=result['affected_artifacts'][0]
 request={'schema':'se-harness-graph-read/v1','operation':'revision','project_id':s['project_id'],'view':result['view'],'artifact_id':artifact['artifact_id'],'revision_id':artifact['revision_id'],'budget':{'rows':1,'bytes':2097152,'depth':0}}
 request_file=root/'independent-read-request.json';h.write(request_file,request)
 token=next(x['token'] for x in json.loads((root/'credentials.json').read_text())['principals'] if x['id']=='operator')
 observed=h.run(trial+'-independent-read',[s['client_python'],'-I','-m','se_harness','remote','read','--endpoint',s['endpoint'],'--project',s['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--request',request_file,'--json'],env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token))
 raw=base64.b64decode(observed['data']['document_base64'],validate=True)
 argv=record['argv'];submitted=Path(argv[argv.index('--document-file')+1]).read_bytes()
 assert raw==submitted
 h.write(root/'independent-document.md',raw)
 assessment.update(exact_saved_document=True,document_sha256=h.sha(raw),artifact=artifact,final_version=result['versions']['project']['after'])
else:assessment['exact_saved_document']='no accepted revision found'
h.write(root/'independent-observation.json',assessment)
print(json.dumps({k:v for k,v in summary.items() if k in ('wall_seconds','native_calls','peak_input_context','goals','native_failures','model_turns','calls_by_tool')},indent=2));print(json.dumps(assessment,indent=2))
