"""Freeze the Codex read-only test-driver repair, then build its exact inputs."""
import json,sys,zipfile,tomllib
import hag221_execute as h
h.O=h.W/'hag-efficiency-proposal-20261008';E=h.R/h.D/'evidence/WO-HAG-011'
if sys.argv[1]=='checkpoint':
 assert json.loads((h.O/'codex-portability-08.json').read_text())['exit']==0
 with zipfile.ZipFile(E/'codex-portability-checks.zip','x',zipfile.ZIP_DEFLATED) as z:
  z.write(h.O/'codex-portability-08.json','codex-portability-08.json')
 assert h.git('rev-parse','HEAD')=='e5f3a2214e80ccffbf49e9634d3e8a6b351f5aa5'
 # No product runtime changed since the full passing suite and installed cases.
 assert not h.git('diff','--name-only','--','se_harness','server','plugins')
 paths=h.git('diff','--name-only').splitlines()+h.git('ls-files','--others','--exclude-standard').splitlines()
 scope=tomllib.loads((h.R/h.D/'work-orders/WO-HAG-011.md').read_text().split('+++')[1])['execution_scope']['paths']
 assert all(any(p==s or s.endswith('/') and p.startswith(s) for s in scope) for p in paths)
 h.run('checkpoint05-diff',['git','diff','--check'],cwd=h.R)
 h.run('checkpoint05-stage',['git','add','--',*paths],cwd=h.R)
 h.run('checkpoint05-commit',['git','commit','-m','Expose bounded text reads to native hosts without a Read tool','-m','Harness-Work-Order: WO-HAG-011'],cwd=h.R)
 assert not h.git('status','--porcelain')
 h.write(h.O/'candidate-05.json',{'commit':h.git('rev-parse','HEAD'),'base':'55caaada508495bea7d97effd27644d1ce8373da'})
elif sys.argv[1]=='build':
 source=(h.W/'hag_efficiency_package03.py').read_text()
 source=source.replace('candidate-03','candidate-05').replace('build03','build05').replace('package03','package05').replace('client03','client05').replace('native-efficiency03','native-efficiency05')
 source=source.replace("'client-build-03'","'client-build-05'").replace("'package-03'","'package-05'").replace("'client-env-03'","'client-env-05'").replace("'client-install-03'","'client-install-05'")
 exec(compile(source,'hag_efficiency_package03.py:build05','exec'))
else:raise ValueError(sys.argv[1])
