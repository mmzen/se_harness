"""Retain actual final candidate preparation and independent observations."""
import json,re,zipfile,hashlib
from hag_efficiency_plan import W,R,O,D
dest=D/'evidence/WO-HAG-011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
tokens=[x['token'].encode() for p in O.glob('*/credentials.json') for x in load(p)['principals']]
files={}
for pattern in ('candidate-05.json','build05-replay.json','client-build-05.json','package-05.json','client-env-05.json','client-install-05.json','runtime-candidate05-comparison.json','codex-portability-08.json','source-suite-06.json','distribution-06.json','cli-smoke-06.json','review-preflight-05.json','codex02-*.json','codex-02-independent-read.json'):
 for p in O.glob(pattern):files['observations/'+p.name]=p
for name in ('package05/combination.json','codex-02/independent-observation.json','codex-02/independent-document.md'):
 p=O/name
 if p.exists():files[name]=p
for name in ('hag_efficiency_package05.py','hag_efficiency_native.py','hag_efficiency_observe.py','hag_efficiency_retain.py','hag_efficiency_retain05.py'):
 files['operator/'+name]=W/name
archive=dest/'candidate05-checks.zip';inventory=[]
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):
  raw=p.read_bytes()
  assert not any(t in raw for t in tokens),name
  assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
  z.writestr(name,raw)
  inventory.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
index={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':inventory,'limits':'Exact candidate05 build/install and native-support checks; unchanged candidate04 product behavior reuses its full suite and installed-client evidence with the retained byte comparison. Native evidence has its own archive. No raw private events, credentials, wheels or account stores.'}
(dest/'candidate05-checks-inventory.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
print(json.dumps({'files':len(files),'bytes':archive.stat().st_size}))
