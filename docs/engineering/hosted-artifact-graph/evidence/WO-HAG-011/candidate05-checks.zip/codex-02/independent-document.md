+++
id = "INT-P3-001"
type = "intent"
title = "Establish the existing rehearsal greeting for the operator"
status = "draft"
owners = ["test-owner"]
created = "2026-10-08"
updated = "2026-10-08"
outcome = "The operator can establish whether the existing fixture's greeting() returns exactly Hello rehearsal."

[relations]
+++

# Intent: Establish the existing rehearsal greeting for the operator

## In plain words

The operator needs to establish that the existing fixture's greeting() returns exactly `Hello rehearsal`. This draft records that narrow need and the observed source for the private hosted drafting diagnostic.

## Problem

The request concerns confidence in an existing result, rather than a requested behavior change. Source inspection of `src/greeting.py` in the selected snapshot shows `def greeting():` followed by `return 'Hello rehearsal'`. The inspected file has SHA-256 `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`; the selected snapshot identifies source commit `5820415917e87b64d80bad2f7c39c6d18d692829`. This diagnostic has not executed the function, so source inspection is not reported as a runtime test.

The existing immutable `INT-P3-900` describes a broader lifecycle rehearsal, including exported test evidence. Definitions and behavior are therefore not claimed to be absent. The operator explicitly requested this separate draft for the focused authoring diagnostic. The affected user is the operator; `test-owner` is the synthetic accountable owner, not evidence of a human approval.

The smallest agreed outcome is to establish the exact existing greeting. No implementation change is requested. An equality assertion against `Hello rehearsal` would be an acceptance check; this draft does not treat that check as a post-delivery operational success measure or create a verification contract.

## Success measures

An operational success measure has not been supplied. The request specifies an exact acceptance observation, but it does not specify a count or duration observed in operation after delivery, a target, or an observation place and cadence. The operational baseline is not measured. These fields remain unresolved authoring findings for `test-owner`; this draft does not invent them or claim readiness for approval.

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| Unresolved: the owner has not defined a post-delivery operational measure | not measured | Unresolved: no operational target supplied | Unresolved: no operational observation place or cadence supplied |

## Not this

- Changing the fixture, its behavior, or any Git-authoritative material.
- Editing imported `-900` records or claiming existing definitions are missing.
- Creating any other formal artifact or expanding this diagnostic into a full package.
- Approving, starting work, freezing a baseline, or making lifecycle decisions.
- Claiming lifecycle, MCP parity, reply recovery, export, or complete NQ-01--05 qualification.
