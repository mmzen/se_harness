+++
id = "VER-P3-901"
type = "verification"
title = "Assert greeting returns the required string"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert greeting returns the required string

## Independence

The expected value `Hello rehearsal` is derived from REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900, not from the candidate implementation in `src/greeting.py`.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import `greeting` from `src/greeting.py` and capture its return value. | `greeting()` returns exactly the string `Hello rehearsal`. |

## Acceptance scenarios

1. A test script imports the `greeting` function from `src/greeting.py`.
2. The script calls `greeting()` and stores the return value.
3. The script asserts that the return value equals `Hello rehearsal` using strict string equality.
4. The assertion result (pass or fail) and the actual return value are recorded in the evidence file.

## Evidence retention

Retain the assertion result, the actual return value, and the timestamp in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-greeting-check.json`.

Platform: Python 3.11 or later.
Evaluator: se_harness 0.22.1.
