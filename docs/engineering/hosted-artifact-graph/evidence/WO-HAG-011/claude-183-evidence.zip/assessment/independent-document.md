+++
id = "VER-P3-901"
type = "verification"
title = "Independently verify the rehearsal greeting return value"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Independently verify the rehearsal greeting return value

## Independence

The expected string `Hello rehearsal` is fixed by REQ-P3-900 and SPEC-P3-900 rule P3-GREET-900. The pass condition derives from those definitions, not from candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import and call `greeting()` from `src/greeting.py`; compare the return value to the independently fixed expected string. | The return value equals the string `Hello rehearsal` exactly, with no leading or trailing whitespace and no other content. |

## Acceptance scenarios

**Scenario: exact greeting match.** Import the module `src/greeting.py` and call `greeting()`. Assert that the returned value is the Python string `'Hello rehearsal'`. The assertion uses direct string equality. Platform: linux/amd64 Python 3.13 runtime. Evaluator: se_harness 0.22.1.

## Evidence retention

Retain the assertion result as a JSON file at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-assertion.json`. The file records the actual return value, the expected value, the comparison result (pass or fail), and a UTC timestamp.
