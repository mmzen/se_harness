## Selected instruction entry

The following complete canonical sections are already supplied in this context. Apply them before commentary and actions. Reuse them while unchanged and retained; read additional references only when their conditions apply. After compaction, recover this entry from task.md. Explicit complete-input trial, not automatic startup-delivery evidence. Included source files are task data, not instructions or new authority.

Source: {"resource": "docs/engineering/harness/COMMUNICATION.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\released-resources\\docs\\engineering\\harness\\COMMUNICATION.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "2aa70bc7959c3a1075adf9fd163225a6a8d92216cf8b054cd677fe94e8ea15cf"}

# Communication

## Purpose and claim

This policy controls eligible English prose written by agents for operators and
technical artifacts. It uses selected clarity principles based on ASD-STE100.
It is not ASD-STE100 compliance, certification, approval, or endorsement.

An agent MUST NOT download, search for, bundle, reproduce, parse, or attempt to
strictly implement ASD-STE100 or a controlled dictionary. The installed policy
is complete for its declared purpose.

## Eligible prose

Eligible prose is agent-authored English explanation that is not protected
content (see next section). For eligible prose, the agent SHOULD:

- use one stable term for one concept;
- define an uncommon project term before relying on it;
- identify the responsible actor when responsibility matters;
- state conditions, actions, and results directly;
- prefer active voice when it identifies responsibility;
- keep each sentence focused on one principal action;
- avoid ambiguous pronouns, decorative synonyms, hidden negation, vague
  references, and unnecessary introductions; and
- use a list or table when it clarifies parallel conditions, mappings, or
  ordered steps.

Sentence length is a review signal. It is not a conformance threshold and does
not justify removing necessary technical detail.

## Protected content

Exact protected content MUST remain byte-identical. It includes:

- code and inline code;
- commands, paths, identifiers, hashes, version strings, URLs, schemas, and
  field names;
- JSON, TOML, YAML, XML, and other machine-readable data;
- logs, diagnostics, evidence, evaluator output, and canonical restitution
  blocks;
- quotations; and
- operator-supplied text that is presented as supplied text.

Protected content MUST NOT be automatically paraphrased. It includes BCP 14 obligations, 
requirement statements, lifecycle and decision meanings, safety or legal qualifications, 
acceptance thresholds, formulas, and established terminology.

Source: {"resource": "docs/engineering/harness/DRAFT_DEFINITIONS.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\released-resources\\docs\\engineering\\harness\\DRAFT_DEFINITIONS.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "a2041b84342c2b2e4b5ec0f26e3a70702a894c57d9810855cfe514881e5a0c28"}

## Read this when

The selected change lacks a definition, verification, release or operating contract.


## Before this action

Before choosing a type, read [ARTIFACTS.md#artifact-types](ARTIFACTS.md#artifact-types) and [ARTIFACTS.md#artifact-locations](ARTIFACTS.md#artifact-locations). Before links, read [DEFINITION_LINKS.md#links-between-definitions](DEFINITION_LINKS.md#links-between-definitions). Before authoring, read [../ARTIFACT_AUTHORING.md#design-simplicity](../ARTIFACT_AUTHORING.md#design-simplicity) and the exact type checklist linked in this file.


### Define how the result will be verified

**Inputs:** The selected requirements (REQ), specifications (SPEC), proposed
amendments, and existing verification contracts (VER).

**Output:**

- **Formal artifacts:** New or updated verification contracts (VER) in
  `draft` where coverage is missing. None created or modified where existing
  contracts provide unchanged coverage. Accepted contracts remain unchanged.
- **Transient working material:** The selection of reused verification
  contracts (VER), any amendment proposals prepared through [Propose any needed amendments to existing definitions](AMEND_DEFINITIONS.md#propose-any-needed-amendments-to-existing-definitions), coverage
  gaps, and unresolved questions. Retain these under the same conditions
  as [Describe the intended outcome](DEFINE_CHANGE.md#describe-the-intended-outcome).

**Actions:**

1. Read each selected requirement's (REQ) acceptance criteria and linked
   specifications (SPEC).
2. Compare those criteria with the existing verification contracts (VER).
3. Select unchanged contracts that cover the proposed behavior.
4. For each coverage gap, create a verification contract (VER) with the
   commands below, or use [Propose any needed amendments to existing definitions](AMEND_DEFINITIONS.md#propose-any-needed-amendments-to-existing-definitions) to propose an amendment to an existing one.
5. Complete `Requirement-to-evidence matrix`. For each requirement (REQ),
   record its ID, method, case or evidence, and pass condition. Use `test`,
   `analysis`, `inspection`, or `demonstration` as the method.
6. Specify the inputs, platform, evaluator, and command or manual actions for
   each check. Derive expected results from the requirement (REQ) and
   specification (SPEC), not from candidate output.
7. Set `[relations].verifies` to the covered requirement (REQ) IDs.
8. Complete `Independence`, `Evidence retention`, and applicable assessment
   sections in each new or edited draft.
9. Apply `## verification` → `### Checklist` in
   `docs/engineering/ARTIFACT_AUTHORING.md`.
10. Retain questions about missing criteria or methods for [Record unresolved decisions (DEC)](RISKS_AND_DECISIONS.md#record-unresolved-decisions-dec).

**Harness commands:**

For each new verification contract (VER), run the creation sequence from
[Draft any missing definitions](DRAFT_DEFINITIONS.md#draft-any-missing-definitions) with these arguments. Inspect the preview before creation; replace
`VER-ID` with its `allocated_id`:

```text
harnessctl create-artifact REPO --domain DOMAIN --type verification --dry-run --json
harnessctl create-artifact REPO --domain DOMAIN --type verification --id VER-ID --json
```

No harness command writes the verification method or pass criteria. The human
or agent completes that content. No verification record (VREC) is created here.

**Completion:** Every selected requirement (REQ) has a defined verification
method and pass condition, or an explicit unresolved question. Each proposed
check identifies how to perform it and where its evidence will be retained.

**Later use:** [Prepare work orders (WO) linking the definitions, scope, planned work, and verification requirements](DRAFT_WORK_ORDERS.md#prepare-work-orders-wo-linking-the-definitions-scope-planned-work-and-verification-requirements) links these contracts to work orders (WO). The execution
and verification processes later perform the checks and assess the evidence.


Source: {"resource": "docs/engineering/harness/ARTIFACTS.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\released-resources\\docs\\engineering\\harness\\ARTIFACTS.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "2fa84648afedc03f3b811cb0e61d77ee1a1d52421ba3b3fa3eb435c4abd6eb89"}

## Artifact types

“Required” means the selected work needs coverage of that type. It does not
mean every change must create a new file. Reuse an existing active artifact
when its accepted meaning and scope still cover the work. Create a conditional
artifact only when its condition applies.

For an existing selected work order (WO), get its current state and next
action with:

```text
harnessctl check REPO --artifact WO-ID --json
```

Before implementation, check whether that work order (WO) and its linked
definitions are eligible to start:

```text
harnessctl preflight REPO --work-order WO-ID --phase start --json
```

The first command reports lifecycle context without evaluating checkpoint
gates. The second evaluates start readiness, including the states and coverage
of the selected definitions. Neither command approves or starts work.
Here, `REPO` is the absolute repository path and `WO-ID` is the actual ID of
the selected work order (WO). Use the repository's selected released evaluator.

| Type                  | ID prefix | Purpose                                                                                                                                                                      | When needed                                                                                                                                              |
|-----------------------|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|
| `intent`              | `INT-`    | States the problem, intended outcome, and limits of responsibility.                                                                                                          | The work needs an accepted purpose. Reuse an intent (INT) when that purpose still applies.                                                               |
| `capability`          | `CAP-`    | Describes an ability that a human or agent should have.                                                                                                                      | Requirements (REQ) need a link to the capability (CAP) they support.                                                                                     |
| `requirement`         | `REQ-`    | States required behavior or a constraint, with a condition for acceptance.                                                                                                   | The change creates or changes an obligation. Reuse a requirement (REQ) only if its meaning stays unchanged.                                              |
| `specification`       | `SPEC-`   | Defines the detailed behavior, interfaces, constraints, and rejection conditions.                                                                                            | Each requirement (REQ) selected for implementation needs specification (SPEC) coverage.                                                                  |
| `architecture`        | `ARCH-`   | Defines system structure and boundaries needed to meet significant requirements (REQ).                                                                                       | An active architecture (ARCH) directly addresses a requirement (REQ) selected by the work order (WO).                                                    |
| `adr`                 | `ADR-`    | Records an architecture decision (ADR), the alternatives, and their consequences.                                                                                            | An applicable architecture (ARCH) declares that a significant decision is required.                                                                      |
| `verification`        | `VER-`    | Defines how requirements (REQ) will be checked and what counts as a pass.                                                                                                    | Each selected requirement (REQ) needs verification coverage. This is the verification contract (VER), not a test result.                                 |
| `work_order`          | `WO-`     | Defines the bounded work to execute and its governing artifacts. Approval grants work authority.                                                                             | Before execution. One work order (WO) may cover several requirements (REQ). Completed scope does not authorize later work.                               |
| `verification_record` | `VREC-`   | Binds work orders (WO), verification contracts (VER), evidence, and one exact candidate commit for assessment.                                                               | When verification tied to a commit is required. One record may cover several work orders (WO) at the same commit.                                        |
| `release_contract`    | `REL-`    | Defines permitted release scope, gates, rollback conditions, and authority limits.                                                                                           | When a release record (RLS) is proposed.                                                                                                                 |
| `release_record`      | `RLS-`    | Records preparation and the later release decision for verified work at one exact commit.                                                                                    | When a formal release is proposed. Preparing the record does not release the work.                                                                       |
| `decision`            | `DEC-`    | Records a question, options, recommendation, decision maker, affected artifacts, and the eventual answer. It can also record a deviation from one specification (SPEC) rule. | A question blocks a transition, affects more than one artifact, or must remain recorded after approval; or work cannot meet a specification (SPEC) rule. |
| `risk`                | `RISK-`   | Records a threat, an owner, and a next action. Scoring and categories are optional.                                                                                          | A concern needs follow-up. A separate decision (DEC) is used when the concern must block work.                                                           |
| `operating_contract`  | `OPS-`    | Defines continuing service, support, monitoring, or operational assurance obligations.                                                                                       | Ongoing operational commitments apply. Omitting the record does not prove those commitments have been met.                                               |

Code, tests, acceptance scenarios, evidence files, commits, dashboards, tickets,
and conversations are not additional formal artifact types. They may support
or be referenced by formal artifacts but do not grant authority by themselves.


## Artifact locations

New formal artifacts use these directories below
`docs/engineering/DOMAIN/`. `DOMAIN` is the selected domain name. These paths
describe storage, not authority; the artifact ID, metadata, and typed links
remain authoritative. Use the supported authoring command to obtain the actual
path. Do not move existing records merely to match this table.

| Artifact | TYPE | Directory |
| --- | --- | --- |
| Intent (INT) | `intent` | `intent/` |
| Capability (CAP) | `capability` | `capabilities/` |
| Requirement (REQ) | `requirement` | `requirements/` |
| Specification (SPEC) | `specification` | `specifications/` |
| Architecture (ARCH) | `architecture` | `architecture/` |
| Architecture decision (ADR) | `adr` | `architecture/adr/` |
| Verification contract (VER) | `verification` | `verification/` |
| Work order (WO) | `work_order` | `work-orders/` |
| Verification record (VREC) | `verification_record` | `verification-records/` |
| Release contract (REL) | `release_contract` | `release/` |
| Release record (RLS) | `release_record` | `releases/` |
| Operating contract (OPS) | `operating_contract` | `operations/` |
| Decision (DEC) | `decision` | `decisions/` |
| Risk (RISK) | `risk` | `risks/` |

The same domain has `evidence/` for retained work-order evidence and
`acceptance/` for acceptance scenarios. These are supporting files, not new
formal artifact types. Legacy flat artifact locations remain readable and
MUST NOT be moved by an upgrade without separate authority.

Templates under `docs/engineering/templates/` are authoring assets. They are
excluded from active-artifact validation and grant no authority. Use
`capture-verification` and `prepare-release` for commit-bound VREC and RLS
instances; an edited template is not a substitute for their derived evidence.

Source: {"resource": "docs/engineering/harness/DEFINITION_LINKS.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\released-resources\\docs\\engineering\\harness\\DEFINITION_LINKS.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "75b0c06f90fbb219fc31684a1a2d97987215dbada20e335656e45a57532c3010"}

## Links between definitions

An arrow points from the artifact that records the link to the artifact it
references. These links describe meaning and coverage, not execution order.

Repository validation, draft validation and work-order preflight share the
declared source/relation/target types. A supplied undeclared relation or a target
of the wrong type is invalid even when no work order selects the artifact.
Preflight still evaluates readiness only for its selected governing chain.
The read-only draft query permits specific unfinished authoring slots; ordinary
validation and approval retain their completeness requirements.

```mermaid
flowchart LR
    CAP["Capability (CAP)"] -->|derives_from| INT["Intent (INT)"]
    REQ["Requirement (REQ)"] -->|derives_from| CAP
    SPEC["Specification (SPEC)"] -->|specifies| REQ
    VER["Verification contract (VER)"] -->|verifies| REQ
    ARCH["Architecture (ARCH)"] -->|addresses| REQ
    ARCH -->|conforms_to| SPEC
    ADR["Architecture decision (ADR)"] -->|decides| ARCH
```

| Source → target | Relation | Meaning and coverage |
| --- | --- | --- |
| Capability (CAP) → Intent (INT) | `derives_from` | Each active capability (CAP) names one or more active intents (INT). |
| Requirement (REQ) → Capability (CAP) | `derives_from` | Each active requirement (REQ) names one or more active capabilities (CAP). |
| Specification (SPEC) → Requirement (REQ) | `specifies` | Each requirement (REQ) selected by a work order (WO) needs one or more selected active specifications (SPEC). |
| Architecture (ARCH) → Requirement (REQ) | `addresses` | The architecture (ARCH) names every requirement (REQ) that materially drives its structure. |
| Architecture (ARCH) → Specification (SPEC) | `conforms_to` | For each addressed requirement (REQ), the selected architecture (ARCH) names at least one selected specification (SPEC) covering it. |
| Architecture decision (ADR) → Architecture (ARCH) | `decides` | Each selected architecture (ARCH) that requires a design decision has at least one selected active architecture decision (ADR). |
| Verification contract (VER) → Requirement (REQ) | `verifies` | Each selected requirement (REQ) has one or more selected active verification contracts (VER). |


Source: {"resource": "docs/engineering/ARTIFACT_AUTHORING.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\released-resources\\docs\\engineering\\ARTIFACT_AUTHORING.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "71de2cc92a470e2da25d525e3ad002b77faedb6ef0e69e2fa476a2fa4cb78ff5"}

## Design simplicity

For unfinished work, `harnessctl validate-draft REPO --artifact ID --json`
reports whether one supported draft has an admissible shape. Only exact values
at the same type and field in this evaluator's canonical template, and missing
or empty required authoring links, can be reported as incomplete. Invalid
identity, dates, metadata shapes, actual endpoints, lifecycle history and
disposition are errors. A missing non-template ID is an error. Background
findings remain visible; this result makes no whole-repository validity claim.
Complete the authoring checklist and pass ordinary approval gates before
requesting approval. Draft admission grants no authority to write or approve.

Choose the least complex design that satisfies the agreed requirements and
constraints. Justify material added complexity by the need it serves and why
a simpler approach is insufficient. Consider the effort to understand, build,
test, operate and change the whole solution. Defer speculative needs. Review
both the necessity of the specified behavior and the simplicity of its
implementation. Preserve correctness and the project's required quality and
safety properties.

Start from the smallest complete solution. Each project supplies its agreed
users, scale, operating conditions and quality constraints. Agreed future needs
can matter; imagined flexibility alone is insufficient. Credible risk analysis
can justify prevention before an incident. Fewer lines, shorter specifications
or fewer tests do not establish simplicity; moving work to users, operations
or dependencies also has a cost.

Apply the relevant questions below before definition approval and during design
and implementation review. Return unjustified obligations or design complexity
for revision through the existing decision process. Explain material choices
in the existing specification, design or review: the need, why a simpler option
is insufficient and the added cost. Scale the explanation to the decision; a
small choice may need one sentence, a significant design may use its existing
architecture decision. Trivial changes need no separate comparison document.

These are human review standards. They introduce no separate KISS artifact,
mandatory score, receipt, automated simplicity gate or additional approval.


## verification

### Checklist

- Independence: expected values derive from the requirements and specifications, never from candidate output.
- A requirement-to-evidence matrix with a pass condition per requirement.
- Cover normal behavior and meaningful failure outcomes or risks; do not invent failure scenarios to fill a template.
- What accepted behavior or quality does each test or CI check establish? Cover distinct relevant outcomes, reuse applicable evidence, and avoid mirroring every implementation branch or combination.
- Pass criteria name the platforms and the evaluator.


## Complete selected inputs

The selection, references and entire staged fixture below are supplied once. Apply the applicable instructions and inspect these exact source contents; reuse them while retained and unchanged. The original paths remain available. The agent selects all operations, authored content and conclusions.

### Effective selection

{
  "host": "claude",
  "project_id": "b91ab798-abb0-4476-870b-11864c2d8c58",
  "endpoint": "http://127.0.0.1:24183",
  "source_manifest": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source-manifest.json",
  "configuration": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\configuration.json",
  "source_directory": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source",
  "client_python": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\client24\\Scripts\\python.exe",
  "client_wheel": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\se_harness-0.22.2-py3-none-any.whl",
  "plugin": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\plugin\\verity-plane",
  "combination": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\combination.json",
  "compose_project": "hag-efficiency24-claude-183",
  "source_volume": "hag-efficiency24-claude-183-source",
  "source_commit": "5820415917e87b64d80bad2f7c39c6d18d692829",
  "source_kind": "Exact tracked Git-blob snapshot without Git metadata.",
  "reference_root": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\reference",
  "released_resources": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\released-resources",
  "native_helper": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\native_call.py",
  "greeting_sha256": "dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1",
  "inputs_inventory": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\inventory.json",
  "helper_python": "C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe",
  "approved_shell_argv_prefix": [
    "C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe",
    "-I",
    "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-efficiency-clarification-reply-20261010/claude-183/native/inputs/native_call.py"
  ],
  "native_task_file": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\task.md",
  "output_directory": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\work",
  "tool_index": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\native-tools.md",
  "evaluator_version": "0.22.1",
  "evaluator_file": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\evaluator.json",
  "qualification_candidate": "89946ef270cd75c26478a166cd56377eeafb3791",
  "token_variable": "HAG_NATIVE_TEST_TOKEN",
  "instruction_delivery": "session-local plugin"
}

### Selected reference

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\native-tools.md", "sha256": "9e42c934381753bfa1fcdbaaec18ddf63d099f4159554149891eac578cd37f10", "bytes": 6431}

````text
# Native test tools

Use `selection.json` for the exact `approved_shell_argv_prefix` and absolute
input/output paths. Append one helper operation per shell call. Use native
Write/Edit for files; read with native Read or the documented `read-text` helper.
Prefer one `read-text` call for independent files whose exact paths are known.
Keep normal permissions: no wrappers, loops, pipes,
directory listing, direct client commands or permission changes. This index
describes capabilities; it supplies no workflow or finished artifact.

## Draft mutations

Prefer typed input for the operations below. This table supplies their CLI fields;
you do not also need their raw schemas or help files unless a needed field is
missing. Choose the operation, target, versions, key and content yourself.

```text
remote OPERATION --typed --compact --record ABSOLUTE_NEW_RECORD [FIELDS]
```

Every typed mutation takes `--operation-key KEY --expected-project-version N
--evaluator-file FILE`. Use the selected `evaluator_file` path. The fixed adapter
supplies the selected endpoint/project/token environment and exact installed
client wheel. The client constructs the existing request and verifies its identity.

| Operation | Other fields |
| --- | --- |
| `import` | `--source-manifest FILE`; use selected `source_manifest` |
| `draft-open` | `--baseline ID --work-order WO-ID` |
| `create-artifact` | `--context UUID --context-version N --domain NAME --artifact-type TYPE`; optional `--artifact ID --include-document` |
| `revise-artifact` | `--context UUID --context-version N --artifact ID --expected-revision REVISION --document-file FILE` |

Hosted `create-artifact` allocates the ID and writes the draft in one operation.
It has no `--dry-run` option; the local repository preview command does not apply.

The client never refreshes a version or retries a mutation on its own. Typed and
raw input cannot be mixed. Documents are exact UTF-8 files. No manual base64 or
copied client digest is needed. `--include-document` adds one read of the exact
created revision, returning text or a decoded file path. Inspect it before editing.

`--record` retains the command. Its new `.evidence` directory retains exact
requests/responses and decoded documents. The displayed `client_view` is the
client's own view. Inspect outcomes and findings; read required omitted content.
Do not reread a whole receipt just to extract a small field already displayed.
A capture error after send can leave a committed effect. Reconcile its original
key with `remote operation --key KEY --record ABSOLUTE_NEW_RECORD`.

## Read one revision

```text
remote read --typed --compact --record ABSOLUTE_NEW_RECORD --artifact ID --expected-revision REVISION --context UUID --context-version N
```

For an imported baseline, replace the context fields with `--baseline ID`.
Reads take no `--operation-key`, `--expected-project-version` or `--evaluator-file`.
Choose the exact revision and context from the selected inputs or actual results.

## Reads and discovery

| Need | Operation |
| --- | --- |
| Service readiness and selected components | `remote status --record ABSOLUTE_NEW_RECORD` |
| Local wheel metadata | `identity` |
| Captured calls/failures so far | `observations`; includes recovered and denied native calls, no content verdict |
| Complete released instruction sections | `instructions --section "RESOURCE_ID#HEADING"`; repeat for up to 12 sections |
| One unknown input location | `find-file BASENAME --under RELATIVE_DIRECTORY/` |
| One exact inventory entry | `lookup-file RELATIVE_NAME` |
| One saved JSON field | `read-json ABSOLUTE_FILE --pointer '"/field"'`; omit pointer for root; optional `--keys` |
| A raw base64 field | Add `--decode-base64` to that field read |
| One text file or independent reads together | `read-text ABSOLUTE_FILE [ABSOLUTE_FILE ...]`; up to eight selected inventoried inputs, the launcher-pinned task.md, or work files, at most 64 KiB output |
| Recover a truncated text read | `read-text ABSOLUTE_FILE --offset 0 --limit 4096`; one file, character offsets; continue from next_offset until complete is true |

For `instructions`, use canonical IDs such as `docs/engineering/harness/DRAFT_DEFINITIONS.md#read-this-when`. The earlier `released-resources/` inventory prefix also works. Request known sections together.
For authoring checklists and the repeated released 0.22.1 continuation heading,
use the exact selectors in the selected plugin's `change/references/hosted-drafts.md`.

For known paths, use them directly. Inventory names are relative to the staged
inputs directory: `released-resources/docs/engineering/ARTIFACT_AUTHORING.md`,
`source/src/greeting.py`, `client-help/create-artifact.txt`. **Do not add `inputs/`
to these names.** Native Read takes the absolute path, not an inventory name.
A digest or lookup is not a content read. Batch independent reads when their exact
paths are known. Unknown headings must not be guessed;
read the named file once to locate its actual headings. Request known current
sections together and reuse unchanged content. A full inventory is not required.

Source inspection and test execution are different actions. Drafting a verification
contract describes future checks; it does not require running them. If the task
authorizes execution, use [Execution tools](native-execution-tools.md).

## Other operations

Raw mode remains `remote OPERATION --request ABSOLUTE_FILE --record ABSOLUTE_NEW_RECORD`.
Use it for operations without typed input, or when explicitly checking a raw
contract. Original schemas are under `reference/server/contracts/`. Selected
schema views use `schemas/remote-v1/OPERATION.json` or `schemas/read-v1/OPERATION.json`.
Each view retains its original pointer/digest. Lifecycle test-copy schemas are
separate; do not load them for drafting alone. `--key` reads a receipt, not a document.

Use `observations` before the final failure report. It reads existing native event/command captures and identifies the snapshot boundary; subsequent report writes are not yet counted. Keep its paths as evidence instead of copying every command. It supplies no draft text, content judgement or lifecycle decision.

Retain failed calls and recoveries. Template admission is not a content review.
Report only inspected facts and actual outcomes; distinguish unresolved content
from a completed definition. Do not claim an exhaustive failure count from memory.

````

### Selected reference

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\combination.json", "sha256": "efe4240e454624ed32bf6eb5462f30af764b26dc7e99989f8f05a438005fd508", "bytes": 2542}

```text
{
  "payload": {
    "client": {
      "version": "0.22.2",
      "wheel_sha256": "d5c25f758a5f2ead36dff9063ef5ded56a96717fed0bca30fdf45ea3a06834e2"
    },
    "database": {
      "image": "memgraph/memgraph@sha256:4710bee1ab5b47599876e30f17ae1679d0bbb2262d84dc06641521fecb7c89ce",
      "version": "3.13.1"
    },
    "deployment_sha256": "5960d9f8eb2ebf0c3b6b4f2b425242f3b9e99b1343d63427aa587b6cbbecf28c",
    "evaluator": {
      "archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053",
      "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff",
      "version": "0.22.1"
    },
    "plugins": {
      "claude": {
        "archive_sha256": "b3dcc245ddf3740f3a814b9ae74b8d620d993bfcdd826dfe5b0a61e9a879b745",
        "inventory_sha256": "7d724926dcde7440ff4328fb2fca4b021e34e6b59eba565724987662e89a2e52",
        "version": "0.2.7"
      },
      "codex": {
        "archive_sha256": "e80b64b67e9aa607c6922e48fa302e4c37125d4989590f4bfc3a9d7e11f65051",
        "inventory_sha256": "6f1e08f45555fe6adf66d34f4b6bebd4e142452e1d12ba8b2b09599f30d58938",
        "version": "0.2.7"
      }
    },
    "protocols": [
      "se-harness-remote-command/v1",
      "se-harness-remote-result/v1",
      "se-harness-graph-read/v1",
      "se-harness-artifact-revision/v1",
      "se-harness-artifact-baseline/v1",
      "se-harness-lifecycle-command/v2",
      "se-harness-lifecycle-result/v2",
      "se-harness-lifecycle-export/v2",
      "se-harness-graph-read/v2"
    ],
    "required_secret_keys": [
      "principals[].token"
    ],
    "runtime": {
      "image": "python@sha256:88310c082760d93ac7c74d579e95e53a4ab6ea52dd8901abc61a103daf488ac4",
      "platform": "linux/amd64",
      "python": "3.13.16"
    },
    "schema": "se-harness-hosted-combination/v1",
    "schema_revision": 2,
    "server": {
      "dependency_lock_sha256": "b1b1f24330aeafc5f13b00d138e0b87a501975c7bc65fd92fb9c519a2f02eeca",
      "image_manifest": "sha256:d3c21a2eddb6582344902f8b65f32ede46e2548cd522c70c7d70385aba66188d",
      "system_packages_sha256": "3b79cfbc2fb5844a952a7e17b401771dc412dfaae78723c9b0665111212c278d",
      "version": "0.1.0.dev1",
      "wheel_sha256": "014cd37f9fd7c048cfdbab91a1c8970c0b2f6f845de812d1c6352ede854035b0"
    },
    "source": {
      "candidate_commit": "89946ef270cd75c26478a166cd56377eeafb3791",
      "repository": "https://github.com/mmzen/se_harness.git"
    }
  },
  "combination_id": "sha256:14acc36a4b84c24c83e7f790213ff494c21924f68a834f42583751cb23891593"
}

```

### Selected reference

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\plugin\\verity-plane\\skills\\setup\\references\\hosted-context.md", "sha256": "66598a30a78fc8e4aca1b053fea64d54768ba4e64b3fa94a23f92f75d4147555", "bytes": 3208}

````text
## Hosted sandbox selection

Use this route only when the operator explicitly selects a hosted sandbox.
It is separate from checkout activation. Retain the operator's loopback endpoint,
project ID, baseline or versioned context, and named credential environment variable.
Never print the credential. The sandbox is not repository authority.

Test-copy status changes authority, not content requirements. Apply the selected
type checklist to every new draft, including synthetic records. Imported drafts
may be incomplete; their content grants no exception to that checklist.

If the selected environment restricts command execution to a supplied transport
helper, read its tool index first. Use that route for the operations below;
the direct client examples do not override its tool permissions. Use its
metadata-only identity operation when available. Encoding a wheel is not needed
to inspect its digest. Stop a denied action without changing the permission route.

Obtain the qualified combination report and exact candidate client wheel.
If the selected candidate client is already installed in a separate disposable
environment, verify its identity and reuse it. Otherwise create that environment
outside the checkout. Verify the wheel's SHA-256 against the combination report,
then install that file with `pip --no-deps`.
The plugin's bundled released evaluator remains unchanged; do not replace it with
the candidate client. Use the candidate environment's absolute Python as
`CLIENT_PYTHON` in the remote commands below.

```text
CLIENT_PYTHON -I -m se_harness remote status --endpoint ENDPOINT --project PROJECT --token-env TOKEN_VARIABLE --json
```

Compare readiness, authority mode `sandbox-projection`, schema, protocols, and
all component identities with the selected combination. A mismatch stops the
remote action. An unavailable service never selects local file writes as a fallback.
Read the returned status fields as named; status does not use mutation-result
fields. Consult the tool index or command help before guessing a request shape.
Use harness-orient for reads. For draft preparation, read [Hosted drafting](../../change/references/hosted-drafts.md) before choosing artifact types or writing
content. It identifies the released drafting procedure and its prerequisites.
Use [Lifecycle rehearsal](../../change/references/hosted-test-lifecycle.md) before lifecycle rehearsal. For record preparation or reporting, use [Hosted evidence](../../evidence/references/hosted-evidence.md). Read each current procedure when needed.
Do not continue into "Activate the checkout" for this hosted selection.
This route grants no approval, verification, release, adoption or deployment right.


## Private lifecycle test copy

The unpublished hosted pilot requires a separately installed candidate remote
client, a loopback endpoint, an explicit test project and a new disposable volume.
Use the repository's `server/README.md` Phase 3 procedure. Its configuration must
report `test_copy: true`; select `--test-copy` for each rehearsal or export.
Leave any existing real checkout selection unchanged. Remote setup does
not activate graph authority or install this candidate into the user's host.

````

### Selected reference

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\plugin\\verity-plane\\skills\\change\\references\\hosted-drafts.md", "sha256": "979ffa4f803da8aae152c55b97d18abaa1f76efc827f8ffd7bfa458462f6c282", "bytes": 7735}

```text
## Select the current step

Complete [Hosted selection](../../setup/references/hosted-context.md) once for
the unchanged selection. Draft preparation grants no decision right or Git authority.

Match the request and existing confirmed context to the current step:

| Available inputs | Read from the selected release |
| --- | --- |
| The intended outcome or scope still needs clarification | `docs/engineering/harness/DEFINE_CHANGE.md`: **Read this when**, **Before this action**, then **Describe the intended outcome**. Use **Define the limits of the change** when its inputs are available. |
| Confirmed outcome, scope and selected definitions; a definition draft is needed | `docs/engineering/harness/DRAFT_DEFINITIONS.md`: **Read this when**, **Before this action**, then the requested type's procedure below. |

The clarification procedure produces transient discussion, not a formal artifact.
Use its requester-confirmation process and reuse an existing matching confirmation.
An instruction to create a draft does not supply the inputs that procedure requires.
Do not import, open a draft context or create a template merely to ask a question.
For a clarification stop, include three short parts in the final reply:

- **Actions:** State whether any hosted change was attempted. Include observed
  failures or denials.
- **Known inputs:** Keep existing definitions and supplied scope limits.
- **Questions:** Ask only for missing facts needed now.

This retained reply is the transient report only if no hosted mutation command
was invoked. Refused or denied mutation commands are still attempts. Missing
observations do not prove that none occurred. Otherwise use **Report and recover**. The clarification reply
needs no duplicate file or new lifecycle checkpoint.

For a requested intent, consult `docs/engineering/ARTIFACT_AUTHORING.md#intent`
when identifying missing content. Read other prerequisites when their stated
condition applies. Before selecting artifacts, load the clarification procedure's
artifact and link references. Before drafting, use this type table:

| Type | Drafting procedure |
| --- | --- |
| Verification | **Define how the result will be verified** |
| Release or operating contract | **Prepare a release or operating contract** |
| Other definition | **Draft any missing definitions** |

Apply the drafting procedure's prerequisites, including
`ARTIFACT_AUTHORING.md#design-simplicity` and the type checklist. Use full type
names such as `#intent`, `#verification`, or `#work_order`, not codes.

The released `harnessctl ... REPO` examples act on repository files. Hosted work
uses the selected tool index or `docs/notes/harnessctl-reference.md#concise-hosted-authoring`.
Do not combine their arguments. The canonical content rules still apply.

Reuse complete sections already delivered with source identity. Obtain missing
sections together from the selected resource root; batch independent file reads
with known paths. A pointer is not a read. Missing, ambiguous or changed sources
stop the affected action. For 0.22.1's repeated
`CONTINUE.md#continue-selected-work` title, read its unique `#procedure` parent.
Load [lifecycle instructions](hosted-test-lifecycle.md) only for that task.

## Check the inputs before writing

Compare the requested type's required content with the request and definitions:

| Content | Source or authoring authority |
| --- | --- |
| User problem, improvement, success measure, existing gap | Require a source that supplies it. A creation request supplies no missing fact. |
| Proposed method, check, evidence destination | Choose within the requested design scope; label it planned. |

For an intent, ask which change in the user's situation is needed and how the
owner will know it helped, when those inputs are missing. An audience name or
replacement output alone does not answer those questions. Reuse supplied answers;
do not invent a purpose or measure from an engineering activity or baseline.

Before claiming a coverage gap, read the applicable requirements, specifications
and verification contracts. Code or one same-type record cannot establish their
absence. For a verification plan, derive expected values from definitions; name
the check, pass condition and full proposed evidence path, including filename
and any work-order directory.

State a missing required fact as a question and stop dependent writing. A partial
draft may omit it and remain incomplete. Do not call an unsupported required claim
a non-blocking observation. Report a type/outcome mismatch without changing type.

## Author and submit

Choose the operation, target, expected versions, retry key and content. Use the
documented typed fields and evaluator identity file; do not also load raw schemas
for those fields. Import is operator-only and uses the complete source manifest.

Use `--typed --compact --record-directory NEW_DIRECTORY`, or the selected helper's
documented permission route. Raw `--request FILE` needs its schema and referenced
definitions. Do not mix modes or manually encode typed documents. Freeze is
raw-only and grants no approval. Explicit IDs permit a new domain; automatic
allocation requires an existing domain with an evaluable ID token.

Inspect the created template through `--include-document` or
[an exact revision read](../../harness-orient/references/hosted-reads.md#read-one-hosted-revision).
Findings are not the document. Complete only supported content and review it
against the type checklist. Remove unsupported claims, duplicate checks and
constraints absent from definitions. Each verification assertion must test its
stated pass condition. Report this content review separately from template checks.

Submit the complete UTF-8 file with `revise-artifact`. Inspect the saved document,
versions, receipt and findings before another draft. Imported records, lifecycle
history, decisions and evidence stay immutable. Resolve blocked reads first.

## Report and recover

For the clarification reply, use **Select the current step**. Otherwise retain
complete requests/results and one short report outside the repository, including
after a mutation attempt or uncertain effect. Read required omitted findings.
The report contains:

- **Content readiness:** complete, incomplete or blocked against the selected
  type checklist. Give the supported content or exact missing input; saving alone
  establishes no completeness.
- **Saved state:** selection, revision, versions and exact document/result paths.
- **Validation and review:** evaluator findings, independent content findings,
  captured command observations including recovered failures and denials, uncertain
  effects, and any returned procedure/step. Use mechanical observations before an
  exhaustive failure claim. Link original evidence; do not copy its inventories.

Draft validation checks template shape and required links. `content_review`
being `not_assessed` means only that the evaluator did not assess content. It
does not invalidate your separate review; an empty `incomplete` list does not
complete it. Name the method: source inspection, executed test or evaluator check.
Planned checks are not executed tests. Keep report and final reply consistent
about readiness and actual checks. Use only confirmed paths/digests.
After compaction, recover the retained reply or report and obtain fresh context.

For stale input, inspect the selection without silently refreshing versions.
For an uncertain reply or capture failure, look up `remote operation --key KEY`
with the same selection and credential, or retry identical bytes and key. Resolve
the effect before selecting another key. Changed bytes under an accepted key are
refused. Never fall back to local writes.

```

### Source data

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source\\.engineering-harness.lock", "sha256": "1ec80dbed14b379d2b33a53ba8d84d1af87d7ab2436dcf753761bcd1bcbf8252", "bytes": 656}

```text
{
  "evaluator": {
    "archive_name": "se_harness-0.22.1-py3-none-any.whl",
    "archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053",
    "payload_manifest": "se-harness-installed-payload-v1",
    "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff",
    "version": "0.22.1"
  },
  "files": {
    ".gitattributes": {
      "mode": "fragment",
      "sha256": "fba4cf22b45939f8c705f2a9c3bd964408b5003d0599993e72735ce865b97e3b"
    }
  },
  "hash_algorithm": "sha256",
  "hash_mode": "utf8-text-lf-v1",
  "resource_layout": "released-resources-v1",
  "schema": 5,
  "tool_version": "0.22.1"
}

```

### Source data

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source\\.engineering-harness.toml", "sha256": "069622e02d80bdec13240889f7e83b1063b01208b9e4a5f6f37fdcdcf53a8d22", "bytes": 237}

```text
[harness]
resource_layout = "released-resources-v1"
tool_version = "0.22.1"
installed_at = "2026-10-07"
project_name = "Disposable lifecycle rehearsal"

[revision_provenance]
required_for_verified_work = true
required_for_release = true

```

### Source data

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source\\.gitattributes", "sha256": "fba4cf22b45939f8c705f2a9c3bd964408b5003d0599993e72735ce865b97e3b", "bytes": 173}

```text
# se-harness:begin
# Preserve canonical evaluator-evidence bytes and their bound SHA-256 on every platform.
docs/engineering/**/evidence/*.json text eol=lf
# se-harness:end

```

### Source data

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source\\REHEARSAL.txt", "sha256": "feb75968b83b4fa18865b23e3b2a8b498915e4c7ab770fee2dd9cd3418ac8e8c", "bytes": 46}

```text
Synthetic test copy. No real human authority.

```

### Source data

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\capabilities\\CAP-P3-900.md", "sha256": "f00af6febc1d62752cab0364e3f4e80e227438f494d98d9f02a9a5c7fdc30bc0", "bytes": 426}

```text
+++
id = "CAP-P3-900"
type = "capability"
title = "Read the rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"
ability = "Read the exact rehearsal greeting."

[relations]
derives_from = ["INT-P3-900"]
+++

# Read the rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

The operator can read the fixed greeting from the local test fixture.

```

### Source data

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\intent\\INT-P3-900.md", "sha256": "20649db79738fdf649578286679d6fe05491e460c5a41e68ba0ed3161c47e7ed", "bytes": 516}

```text
+++
id = "INT-P3-900"
type = "intent"
title = "Inspect one rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"
outcome = "The test operator observes Hello rehearsal."

[relations]
+++

# Inspect one rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

An operator needs a fixed greeting for a disposable lifecycle rehearsal.
Success is an observed exact greeting and exported test evidence. No real product or release is involved.

```

### Source data

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\release\\REL-P3-900.md", "sha256": "a7cc92f770027bae2ffbf987a1a83eb36bd5e012632e1db07cf5f377f6b12935", "bytes": 529}

```text
+++
id = "REL-P3-900"
type = "release_contract"
title = "Prepare a test release record only"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"

[relations]
gates = ["WO-P3-900"]
+++

# Prepare a test release record only

Synthetic rehearsal input. This is not a real human decision.

Test version 0.0.1 binds this work and its verified test candidate. No tags, publication or deployment. Discard the disposable test project if replay fails. Retain the verification record and exact evidence.

```

### Source data

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\requirements\\REQ-P3-900.md", "sha256": "99028b8605edfd6e85d3cbfb0ee5243f43df69059e314ed1f0b9ab0bde0bbba4", "bytes": 539}

```text
+++
id = "REQ-P3-900"
type = "requirement"
title = "Return the exact rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"
statement = "Calling greeting() returns Hello rehearsal."
verification_method = ["test"]
priority = "must"
source = "Synthetic Phase 3 fixture"

[relations]
derives_from = ["CAP-P3-900"]
+++

# Return the exact rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

## Acceptance

Calling greeting() returns exactly `Hello rehearsal`.

```

### Source data

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\specifications\\SPEC-P3-900.md", "sha256": "0904f98bddc075f26c87e2e2ce603e3d74a497b8df85e1093bf3b0f5f35a45f9", "bytes": 539}

```text
+++
id = "SPEC-P3-900"
type = "specification"
title = "Fixed rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"
contract = "Return the fixed greeting without external effects."

[relations]
specifies = ["REQ-P3-900"]
+++

# Fixed rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

**P3-GREET-900.** The fixture function greeting() returns the string `Hello rehearsal`.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-900 | P3-GREET-900 |

```

### Source data

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\verification\\VER-P3-900.md", "sha256": "9c975ff911c736f30dab7688df8f136e66eefd81eebc09362d0345cef813e8b4", "bytes": 688}

```text
+++
id = "VER-P3-900"
type = "verification"
title = "Independently assert the greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"

[relations]
verifies = ["REQ-P3-900"]
+++

# Independently assert the greeting

Synthetic rehearsal input. This is not a real human decision.

## Independence

Expected text is fixed by REQ-P3-900, not candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-900 | test | exact greeting assertion | Equals Hello rehearsal |

Retain the actual assertion result in docs/engineering/lifecycle-pilot/evidence/WO-P3-900/assertion.json.

```

### Source data

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\work-orders\\WO-P3-900.md", "sha256": "98ac1fa85021ac8a6f4d7a74973e2148dac97aa6ca69064d847818efc3771332", "bytes": 1096}

```text
+++
id = "WO-P3-900"
type = "work_order"
title = "Implement the synthetic greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-06"

[assurance]
commit_bound_verification = "required"
rationale = "Synthetic fixture decision for test assurance."
decided_by = "test-owner"

[execution_scope]
paths = ["src/greeting.py", "docs/engineering/lifecycle-pilot/"]

[relations]
implements = ["REQ-P3-900"]
specifications = ["SPEC-P3-900"]
verification = ["VER-P3-900"]
+++

# Implement the synthetic greeting

Synthetic rehearsal input. This is not a real human decision.

## Objective

Return the exact test greeting.

## In scope

Only the synthetic source, pilot definitions and test evidence.

## Out of scope

Real engineering records, real human decisions and external actions.

## Authorized decision envelope

All supplied actors are synthetic test labels.

## Required verification

Run VER-P3-900 on the exact clean fixture commit.

## Stop conditions

Stop when the released evaluator refuses.

## Completion

Retain actual outputs and candidate identity.

```

### Source data

{"path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-clarification-reply-20261010\\claude-183\\native\\inputs\\source\\src\\greeting.py", "sha256": "dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1", "bytes": 45}

```text
def greeting():
    return 'Hello rehearsal'

```
Before your first explanation, apply the supplied sections and read only the applicable plugin instructions and prerequisites still missing from context. Use the existing file tools below. This explicit test setup does not establish automatic startup instruction delivery.

# Focused hosted drafting diagnostic

You are Claude under the approved WO-HAG-011 efficiency comparison. Work
independently in the fresh private project selected by `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-efficiency-clarification-reply-20261010\claude-183\native\selection.json`.
This run tests draft preparation only. Git remains authoritative for real work.

## Requested outcome

Prepare exactly one new verification-contract draft for an independent reviewer
who needs a plan to check the existing fixture against REQ-P3-900: greeting()
returns exactly Hello rehearsal. This is an explicitly requested alternative
authoring exercise; existing VER-P3-900 and all imported -900 records remain
unchanged. Do not claim a missing requirement or verification contract.

Inspect the relevant fixture and governing requirement. Author the new contract
in the selected private service, using domain lifecycle-pilot and synthetic owner
test-owner. Define an independently derived expected result, the check to perform,
its pass condition and the evidence to retain. Plan verification only; do not claim
that tests ran or that the result is verified. Keep the artifact draft. Do not
create other artifacts, approve anything, start work, freeze a baseline or make
lifecycle decisions. Stop when the draft and actual authoring findings are saved,
or report the precise blocker.

## Entry and tools

Use the effective selection from the complete entry when supplied; otherwise
read `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-efficiency-clarification-reply-20261010\claude-183\native\selection.json`. Begin with `skills/setup/SKILL.md` under the selection's
plugin directory, then follow its current-task routes. Invoke the native Skill
tool only when it resolves that selected candidate. The client is installed.
Do not install software or activate
a checkout. The selected released_resources directory contains the exact 0.22.1
procedures. Reuse canonical sections already delivered in this task.

The selection's tool_index is the single command and file-discovery reference.
Apply its content before choosing syntax; reuse it if supplied in the entry.
Read only applicable procedure sections and
the typed inputs (or raw schema) for the operation you select.

Use native file tools or the tool index's bounded file-read operation, and only
approved_shell_argv_prefix for shell calls,
one helper call per invocation. No scripts, wrappers, pipes, loops, direct client
calls or other shell commands. Normal permissions and hooks apply. Stop a denied
action; do not change permissions or try alternate routes.

Keep every draft, request, result and transient note under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-efficiency-clarification-reply-20261010\claude-183\native\work`,
using absolute paths. That directory exists. Inputs are read-only. After
compaction, recover this task, selection and original evidence before acting.
Never print credentials, inspect auth stores, change account or host settings,
or read prior trials. Authentication is in the process environment. Helpers
perform no hidden workflow; choose requests from current inputs and instructions.

## Result

The runner captures calls, read paths, failures, timing and context. Do not copy
those observations into another JSON file or calculate final metrics during the
run. Use the observations command before an exhaustive failure claim; its
in-progress snapshot does not include subsequent calls.

Use the selected plugin's `change/references/hosted-drafts.md` reporting branch.
For its clarification-only branch, the captured final reply is the report.
Otherwise keep one short `native-report.md` in C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-efficiency-clarification-reply-20261010\claude-183\native\work, using that guide's
fields and readiness rules. This is also the transient progress note; keep the
final reply consistent with it and include its path. Link original evidence.
Do not write a separate native-observations.json or read inventory. No complete NQ-01 through NQ-05 claim: lifecycle, MCP parity, reply recovery
and export are outside this focused diagnostic.
