+++
id = "VER-P3-001"
type = "verification"
title = "Plan an independent check of the rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verification Contract: Plan an independent check of the rehearsal greeting

Synthetic alternative authoring exercise for an independent reviewer. This contract is a plan only. It records no executed test, verification decision or real human authority. Existing VER-P3-900 provides coverage; this alternative does not assert a coverage gap or replace that contract. All imported -900 records remain unchanged.

## Independence

The expected value is the string `Hello rehearsal`, derived from the acceptance criterion in REQ-P3-900 and rule P3-GREET-900 in SPEC-P3-900. The reviewer must keep that literal fixed independently of candidate output. The implementation is an input to the check, never the source of the expected value. Synthetic owner test-owner retains responsibility for this draft; an independent reviewer performs and records the planned checks if execution is later authorized.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | G1 exact greeting assertion; `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/VER-P3-001-review.json` | On Linux amd64 with CPython 3.13.16, the G1 Python evaluator exits 0 after confirming that the return value is a string exactly equal to `Hello rehearsal`. An exception, a non-string result or any text difference fails. |

## Acceptance scenarios

All actions below are planned, not executed. Inputs are REQ-P3-900, SPEC-P3-900 and `src/greeting.py` from the supplied tracked-file snapshot at source commit `5820415917e87b64d80bad2f7c39c6d18d692829`. The supplied fixture SHA-256 is `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`. The snapshot has no Git metadata; the source commit is supplied provenance, not a newly verified commit binding.

G1: After separate execution authorization, the reviewer uses Linux amd64 and CPython 3.13.16. From the fixture root, run this planned command with that interpreter:

```text
python -I -c "import runpy; candidate = runpy.run_path('src/greeting.py'); actual = candidate['greeting'](); print(repr(actual)); assert isinstance(actual, str) and actual == 'Hello rehearsal'"
```

Capture the command, interpreter version, platform, stdout, stderr and exit code. Exact equality rejects case changes, added whitespace and added newline characters without separate duplicate cases. Loading or calling errors also fail the check. If the specified platform or interpreter is unavailable, record G1 as not run rather than passed.

## Manual assessments

S1: On the same selected fixture, the independent reviewer inspects the entire `src/greeting.py` module and the `greeting()` body against SPEC-P3-900's contract, `Return the fixed greeting without external effects.` Pass this inspection only if loading the module and calling the function produce no external effects. Trace any calls and operations needed to establish that condition. Record the inspected file identity, reviewer, reasoning and pass/fail result in the same evidence file. A changed implementation requires fresh inspection; unresolved effects are not a pass. This inspection supplements G1 because output equality alone does not assess external effects.

## Evidence retention

The full proposed repository-relative evidence destination is `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/VER-P3-001-review.json`. It is a future supporting evidence file, not a formal artifact and not produced during this drafting exercise. Keep existing `assertion.json` evidence untouched.

Retain the definitions and fixture identities used, source provenance, actual inspected fixture digest, reviewer identity, UTC execution time, platform and interpreter version, exact command, expected literal and its requirement/specification sources, stdout, stderr, exit code, G1 result, S1 inspection reasoning and result, and any not-run reason. Preserve failure output as well as successful output. Report a combined pass only if both G1 and S1 pass on the identified fixture. This record would support later assessment; it would not itself approve or verify work.

## Residual uncertainty

No planned checks have run in this authoring exercise. This plan addresses the fixed fixture and supplied requirement, without claiming coverage of other platforms or changed behavior. Released evaluator 0.22.1 checks draft shape and links; it does not execute G1 or assess the contract's content. The imported SPEC-P3-900 has evaluator advisory W-AUT-022, `Coverage row REQ-P3-900 names undefined rule P3-GREET-900.` The supplied specification text explicitly states the expected greeting. Retain the advisory for the reviewer without editing the imported specification or treating this draft as a resolution of that advisory.
