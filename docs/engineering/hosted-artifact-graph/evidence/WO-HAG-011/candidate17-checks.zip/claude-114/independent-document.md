+++
id = "VER-P3-001"
type = "verification"
title = "Alternative assertion of the rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative assertion of the rehearsal greeting

## Independence

The expected value `Hello rehearsal` derives from REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The pass condition is fixed before any candidate output is observed.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import and call `greeting()`, compare return value to the independently fixed string | `greeting()` returns exactly `Hello rehearsal` |

## Acceptance scenarios

Call `greeting()` from `src/greeting.py` and assert the return value equals the string `Hello rehearsal`. The assertion uses a string literal derived from REQ-P3-900 and SPEC-P3-900, not from prior candidate output.

Platform: Python 3.13 on linux/amd64. Evaluator: se_harness 0.22.1.

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-assertion.json`. Record the actual return value, the expected value, the comparison result, and the candidate commit.

## Residual uncertainty

This contract defines planned checks. Execution and evidence collection are separate actions not performed by this draft.
