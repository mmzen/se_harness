+++
id = "INT-P3-001"
type = "intent"
title = "Confirm the rehearsal fixture greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
outcome = "The test operator has confirmed that greeting() returns exactly Hello rehearsal."

[relations]
+++

# Intent: Confirm the rehearsal fixture greeting

## In plain words

The test operator needs to confirm that the existing rehearsal fixture returns the expected greeting before relying on it in lifecycle rehearsal steps.

## Problem

The lifecycle-pilot domain uses a fixture function `greeting()` in `src/greeting.py` that must return exactly `Hello rehearsal`. The fixture exists and the imported definitions (INT-P3-900, REQ-P3-900, SPEC-P3-900) describe the expected behavior. Without independent confirmation of the output, the operator cannot state that the fixture meets the expected contract for this rehearsal.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| Operator has confirmed the fixture contract | not measured | Confirmed once | not measured |

## Not this

- Changing the fixture implementation or its return value.
- Real product decisions, releases or deployments.
- Lifecycle approval beyond draft preparation.
- Work outside the lifecycle-pilot domain.
