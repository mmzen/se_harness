"""Freeze the bounded reference/observation correction and build it exactly."""
import json,sys,zipfile,tomllib
import hag221_execute as h
h.O=h.W/'hag-efficiency-proposal-20261008';E=h.R/h.D/'evidence/WO-HAG-011'
if sys.argv[1]=='checkpoint':
 names=('native-support-07','source-suite-06','distribution-06','cli-smoke-06')
 for name in names:assert json.loads((h.O/(name+'.json')).read_text())['exit']==0,name
 with zipfile.ZipFile(E/'resource-observation-checks.zip','x',zipfile.ZIP_DEFLATED) as z:
  for name in (*names,'unicode-focus-06','native-support-06'):
   p=h.O/(name+'.json');z.write(p,p.name)
 assert h.git('rev-parse','HEAD')=='ebea7148bf189729e93b8c1e99aeeb023f6ea7a7'
 paths=h.git('diff','--name-only').splitlines()+h.git('ls-files','--others','--exclude-standard').splitlines()
 scope=tomllib.loads((h.R/h.D/'work-orders/WO-HAG-011.md').read_text().split('+++')[1])['execution_scope']['paths']
 assert all(any(p==s or s.endswith('/') and p.startswith(s) for s in scope) for p in paths)
 h.run('checkpoint04-diff',['git','diff','--check'],cwd=h.R)
 h.run('checkpoint04-stage',['git','add','--',*paths],cwd=h.R)
 h.run('checkpoint04-commit',['git','commit','-m','Use canonical resource IDs and captured native observations','-m','Harness-Work-Order: WO-HAG-011'],cwd=h.R)
 assert not h.git('status','--porcelain')
 h.write(h.O/'candidate-04.json',{'commit':h.git('rev-parse','HEAD'),'base':'55caaada508495bea7d97effd27644d1ce8373da'})
elif sys.argv[1]=='build':
 # Identical qualified build procedure, only new exact output names.
 source=(h.W/'hag_efficiency_package03.py').read_text()
 source=source.replace('candidate-03','candidate-04').replace('build03','build04').replace('package03','package04').replace('client03','client04').replace('native-efficiency03','native-efficiency04')
 source=source.replace("'client-build-03'","'client-build-04'").replace("'package-03'","'package-04'").replace("'client-env-03'","'client-env-04'").replace("'client-install-03'","'client-install-04'")
 exec(compile(source,'hag_efficiency_package03.py:build04','exec'))
else:raise ValueError(sys.argv[1])
