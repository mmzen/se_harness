"""Fresh native efficiency cases; preparation is outside measured sessions."""
import ipaddress,json,os,secrets,shutil,subprocess,sys,uuid,zipfile
from pathlib import Path
import hag221_execute as h
h.O=h.W/'hag-efficiency-proposal-20261008'
OLD=h.W/'hag-agent-qualification-execution-20261007'
P=h.O/'package04'
mode=sys.argv[1];host=sys.argv[2];trial=sys.argv[3]
root=h.O/(host+'-'+trial);native=root/'native';inputs=native/'inputs'
canon=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def copy(src,dest):
 assert not dest.exists(),dest
 h.write(dest,src.read_bytes())
if mode=='setup':
 root.mkdir(exist_ok=False)
 config=json.loads((P/'configuration/config.json').read_text());config['project_id']=str(uuid.uuid4())
 old=json.loads((OLD/'codex/configuration/config.json').read_text())
 for key in ('source_directory','source_inventory','source_manifest'):config[key]=old[key]
 compose=P/'candidate-source/server/compose.yaml'
 config['components']['deployment_sha256']=h.sha(canon({'configuration':{k:v for k,v in config.items() if k!='components'},'compose_sha256':h.sha(compose.read_bytes())}))
 h.write(root/'configuration/config.json',config)
 payload=config['components'];h.write(root/'combination.json',{'payload':payload,'combination_id':'sha256:'+h.sha(b'se-harness-hosted-combination/v1\n'+canon(payload))})
 credentials=json.loads((P/'credentials.json').read_text())
 for item in credentials['principals']:item['token']=secrets.token_urlsafe(32);item['projects']=[config['project_id']]
 h.write(root/'credentials.json',credentials)
 project='hag-efficiency-'+host+'-'+trial;volume=project+'-source';port=18400+int(trial)+(20 if host=='checks' else 10 if host=='codex' else 0)
 ids=subprocess.check_output(['docker','network','ls','-q']).decode().split()
 networks=h.run(host+trial+'-networks',['docker','network','inspect',*ids])
 used=[ipaddress.ip_network(c['Subnet']) for n in networks for c in (n.get('IPAM',{}).get('Config') or []) if 'Subnet' in c]
 available=[str(s) for s in ipaddress.ip_network('10.231.68.0/22').subnets(new_prefix=28) if not any(s.overlaps(v) for v in used)]
 assert len(available)>=2
 h.write(root/'network.json',{'networks':{k:{'ipam':{'config':[{'subnet':s}]}} for k,s in zip(('private','client'),available)}})
 h.run(host+trial+'-volume-absent',['docker','volume','inspect',volume],allow=(1,))
 h.run(host+trial+'-volume-create',['docker','volume','create',volume])
 h.run(host+trial+'-source-stage',['docker','run','--rm','--network','none','--mount',f'type=bind,source={OLD/"source-staged"},target=/input,readonly','--mount',f'type=volume,source={volume},target=/source','--entrypoint','python','harness-hag:native-efficiency04','-c','import shutil;shutil.copytree("/input","/source",dirs_exist_ok=True)'])
 env=dict(os.environ,HAG_SERVICE_IMAGE='harness-hag:native-efficiency04',HAG_HTTP_PORT=str(port),HAG_CONFIG_DIRECTORY=str(root/'configuration'),HAG_CREDENTIAL_FILE=str(root/'credentials.json'),HAG_SOURCE_VOLUME=volume)
 dc=['docker','compose','-p',project,'-f',compose,'-f',root/'network.json']
 h.run(host+trial+'-up',[*dc,'up','-d','graph','service'],env=env)
 h.run(host+trial+'-init',[*dc,'run','--rm','service','init'],env=env)
 selection=json.loads((OLD/('claude' if host=='claude' else 'codex')/'selection.json').read_text())
 selection.update(project_id=config['project_id'],endpoint='http://127.0.0.1:'+str(port),configuration=str(root/'configuration/config.json'),combination=str(root/'combination.json'),compose_project=project,source_volume=volume,client_python=str(h.O/'client04/Scripts/python.exe'),client_wheel=str(h.O/'build04/se_harness-0.22.2-py3-none-any.whl'))
 selection.pop('credentials',None);h.write(root/'selection.json',selection)
elif mode=='stage':
 assert not native.exists();inputs.mkdir(parents=True);(native/'work').mkdir()
 selection=json.loads((root/'selection.json').read_text());combo=json.loads((root/'combination.json').read_text())
 variant='claude' if host=='checks' else host
 archive=P/'plugin'/('verity-plane-'+variant+'.zip');assert h.sha(archive.read_bytes())==combo['payload']['plugins'][variant]['archive_sha256']
 with zipfile.ZipFile(archive) as z:
  assert all(not Path(x.filename).is_absolute() and '..' not in Path(x.filename).parts for x in z.infolist());z.extractall(inputs/'plugin')
 copy(Path(selection['client_wheel']),inputs/Path(selection['client_wheel']).name)
 for name,src in [('configuration.json',root/'configuration/config.json'),('combination.json',root/'combination.json'),('source-manifest.json',Path(selection['source_manifest']))]:copy(src,inputs/name)
 fixture=Path(selection['source_directory'])
 for name in subprocess.check_output(['git','ls-files','-z'],cwd=fixture).decode().strip('\0').split('\0'):copy(fixture/name,inputs/'source'/name)
 candidate=combo['payload']['source']['candidate_commit']
 for name in ['server/contracts/remote-v1.json','server/contracts/read-v1.json','server/contracts/lifecycle-v2.json','server/contracts/lifecycle-v2.md','server/contracts/export-v2.json','server/README.md','docs/notes/harnessctl-reference.md','docs/notes/hosted-artifact-graph.md']:h.write(inputs/'reference'/name,h.blob(candidate,name))
 resource=h.NEW.parent.parent/'share/se-harness/templates/repository/standard'
 copy(resource/'ENGINEERING_HARNESS.md.tpl',inputs/'released-resources/ENGINEERING_HARNESS.md')
 copy(resource/'docs/engineering/ARTIFACT_AUTHORING.md',inputs/'released-resources/docs/engineering/ARTIFACT_AUTHORING.md')
 shutil.copytree(resource/'docs/engineering/harness',inputs/'released-resources/docs/engineering/harness')
 helper=inputs/'native_call.py';copy(h.R/'tests/hosted_artifact_graph/native_call.py',helper)
 copy(h.R/'tests/hosted_artifact_graph/summarize_native.py',inputs/'summarize_native.py')
 h.write(inputs/'evaluator.json',combo['payload']['evaluator'])
 baseline=OLD/'claude/native02/work/opus10'
 shutil.copytree(baseline/'inputs/schemas',inputs/'schemas')
 index=h.blob(candidate,'tests/hosted_artifact_graph/native-tools.md').decode('utf-8')
 h.write(inputs/'native-tools.md',index)
 for operation in ('read','operation','create-artifact','revise-artifact'):
  h.write(inputs/'client-help'/f'{operation}.txt',subprocess.check_output([selection['client_python'],'-I','-m','se_harness','remote',operation,'--help'],cwd=h.W))
 selection.update(client_wheel=str(inputs/Path(selection['client_wheel']).name),plugin=str(inputs/'plugin/verity-plane'),configuration=str(inputs/'configuration.json'),source_manifest=str(inputs/'source-manifest.json'),source_directory=str(inputs/'source'),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=fixture).decode().strip(),source_kind='Exact tracked Git-blob snapshot without Git metadata.',combination=str(inputs/'combination.json'),reference_root=str(inputs/'reference'),released_resources=str(inputs/'released-resources'),native_helper=str(helper),greeting_sha256=h.sha((inputs/'source/src/greeting.py').read_bytes()),inputs_inventory=str(inputs/'inventory.json'),helper_python=h.HOST.as_posix(),approved_shell_argv_prefix=[h.HOST.as_posix(),'-I',helper.as_posix()],native_task_file=str(native/'task.md'),output_directory=str(native/'work'),tool_index=str(inputs/'native-tools.md'),evaluator_version=combo['payload']['evaluator']['version'],evaluator_file=str(inputs/'evaluator.json'),qualification_candidate=candidate,diagnostic_scope='VER-HAG-008 focused same-task authoring')
 inventory=[{'path':str(p),'relative':p.relative_to(inputs).as_posix(),'bytes':p.stat().st_size,'sha256':h.sha(p.read_bytes())} for p in sorted(inputs.rglob('*')) if p.is_file()]
 h.write(inputs/'inventory.json',{'files':inventory})
 h.write(root/'native-selection.json',selection)
 task=(baseline/'task.md').read_text().replace(str(baseline),str(native)).replace('WO-HAG-009 qualification test','WO-HAG-011 efficiency comparison').replace('You are Claude','You are '+host.capitalize())
 task=task.replace('procedure sections and the schema for the operation you select.','procedure sections and the typed client inputs (or raw schema) for the operation you select.')
 h.write(root/'native-task.md',task)
 rules=json.loads((OLD/'claude-guidance19/permissions.json').read_text())
 oldhelper=OLD/'claude/native02/inputs/native_call.py'
 text=json.dumps(rules)
 for source,target in [(str(oldhelper).replace('\\','/'),helper.as_posix()),(str(baseline).replace('\\','/'),native.as_posix())]:
  text=text.replace(source,target).replace(source.replace('C:','//c'),target.replace('C:','//c'))
 h.write(root/'permissions.json',json.loads(text))
 h.write(root/'stage-evidence.json',{'candidate':candidate,'project':selection['project_id'],'inventory_sha256':h.sha((inputs/'inventory.json').read_bytes()),'task_sha256':h.sha(task.encode()),'helper_sha256':h.sha(helper.read_bytes()),'permission_source':str(OLD/'claude-guidance19/permissions.json'),'effective_permission_sha256':h.sha((root/'permissions.json').read_bytes()),'changes':'Same operation permissions relocated to new disposable paths; typed client inputs and exact section reader under the existing one-call boundary. No supplied draft or workflow sequence.'})
elif mode=='run':
 selection=json.loads((root/'selection.json').read_text());creds=json.loads((root/'credentials.json').read_text());token=next(x['token'] for x in creds['principals'] if x['id']=='operator')
 status=h.run(host+trial+'-initial-status',[selection['client_python'],'-I','-m','se_harness','remote','status','--endpoint',selection['endpoint'],'--project',selection['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--json'],env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token))
 assert status['ready'] and status['project_version']==0
 exe=r'C:\Users\mathi\.local\bin\claude.exe' if host=='claude' else r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe'
 args=[h.HOST,'-X','utf8','-B',h.R/'tests/hosted_artifact_graph/qualify_agents.py','--host',host,'--executable',exe,'--selection',root/'native-selection.json','--credentials',root/'credentials.json','--task',root/'native-task.md','--output',native,'--prepared-inputs','--timeout','1200']
 if host=='claude':args+=['--permission-settings',root/'permissions.json','--model','claude-opus-4-6']
 raise SystemExit(subprocess.call(list(map(str,args)),cwd=h.W))
else:raise ValueError(mode)
