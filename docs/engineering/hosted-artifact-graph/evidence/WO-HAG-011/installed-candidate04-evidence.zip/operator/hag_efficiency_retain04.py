import json,re,zipfile,hashlib
from pathlib import Path
from hag_efficiency_plan import *
dest=D/'evidence/WO-HAG-011';load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
tokens=[x['token'].encode() for p in O.glob('*/credentials.json') for x in load(p)['principals']]
files={}
for pattern in ('installed04-*.json','candidate-04.json','build04-replay.json','client-build-04.json','package-04.json','client-install-04.json','runtime-candidate04-comparison.json','claude-03-independent-read.json'):
 for p in O.glob(pattern):files['observations/'+p.name]=p
for p in (O/'checks-03/checks').rglob('*'):
 if p.is_file():files['checks-03/'+p.relative_to(O/'checks-03').as_posix()]=p
for name in ('package04/combination.json','claude-03/section-assessment.json','checks-03/combination.json'):
 files[name]=O/name
for name in ('hag_efficiency_native.py','hag_efficiency_live04.py','hag_efficiency_sections04.py','hag_efficiency_package04.py','hag_efficiency_observe.py','hag_efficiency_retain.py','hag_efficiency_retain04.py'):
 files['operator/'+name]=W/name
inventory=[];archive=dest/'installed-candidate04-evidence.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):
  raw=p.read_bytes();assert not any(t in raw for t in tokens),name
  assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
  z.writestr(name,raw);inventory.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
index={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':inventory,'limits':'Exact candidate04 installed client and section checks. Expected refusals and deliberate unknown outcomes retained, not claimed as successful operations. Private tokens checked absent; credential files and account stores excluded. Historical checks are in installed-client-evidence.zip.'}
(dest/'installed-candidate04-inventory.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
print(json.dumps({'files':len(files),'bytes':archive.stat().st_size}))
