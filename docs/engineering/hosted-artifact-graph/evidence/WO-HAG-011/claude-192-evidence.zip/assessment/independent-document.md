+++
id = "VER-P3-001"
type = "verification"
title = "Assert greeting return value by independent comparison"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert greeting return value by independent comparison

## Independence

The expected string `Hello rehearsal` is derived from REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The pass condition does not reference candidate output or implementation detail.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import `greeting` and compare its return value to the independently fixed expected string | `greeting()` returns the exact string `Hello rehearsal` on Python 3.13, linux/amd64, evaluated by se_harness 0.22.1 |

## Acceptance scenarios

Call `greeting()` and assert the return value equals the string `Hello rehearsal`. The assertion compares the full string value, including case and whitespace. If `greeting()` returns a different value or raises an exception, the check fails.

## Evidence retention

Retain the assertion result as JSON at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-result.json`. Record the actual return value, the expected value, the comparison outcome, and the platform.

## Residual uncertainty

This contract verifies only the return value of `greeting()`. It does not verify call-site behavior, side effects, or integration with other components.
