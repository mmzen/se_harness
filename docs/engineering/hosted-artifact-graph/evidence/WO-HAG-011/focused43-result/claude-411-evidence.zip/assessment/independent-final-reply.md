Service is ready. All component identities match the combination report: evaluator 0.22.1, client 0.22.2, authority mode `sandbox-projection`, test copy confirmed, project version 0.

I inspected the existing fixture definitions and the change request. The request is "Adapt the existing greeting for a new audience." Per the DEFINE_CHANGE.md "Describe the intended outcome" procedure, I need to draft an outcome statement and obtain confirmation before creating a formal intent draft. The intent checklist requires the present problem, who it affects, the outcome wanted, and how the owner will know the change helped.

The existing INT-P3-900 establishes a clear baseline: the test operator observes the exact greeting "Hello rehearsal." The new request asks to "adapt" this greeting for a "new audience," but several required facts are missing.

---

**Actions:** No hosted change was attempted. Service status was read and verified against the combination report. No mutation, import, draft-open, create-artifact, or revise-artifact command was invoked.

**Known inputs:**
- Domain: `lifecycle-pilot`, owner: `test-owner`.
- Existing INT-P3-900 defines outcome "The test operator observes Hello rehearsal."
- The fixture `greeting()` returns `'Hello rehearsal'`.
- The existing -900 definition chain (CAP, REQ, SPEC, VER, WO, REL) covers the current greeting.
- The new intent must describe a different desired outcome involving a new audience.

**Questions** (missing required facts for the intended-outcome statement):

1. **Who is the new audience?** The request names "a new audience" without identifying it. The intent needs a concrete actor or group to state who is affected and what observable result they need.
2. **What does "adapt" mean here?** Should the greeting text change (e.g., a different message), should the same greeting be delivered through a different channel, or should the function accept a parameter? The outcome depends on what adaptation is intended.
3. **How will the owner know the change helped?** A success measure is required by the intent checklist. If no measure is agreed, the intent can state `not measured`, but the requester must confirm that choice.

These three facts determine the outcome statement. I will draft the intent once they are resolved.