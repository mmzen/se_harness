# Native drafting diagnostic — INT-P3-001

## Selected artifact

- **Artifact:** INT-P3-001 (intent)
- **Domain:** lifecycle-pilot
- **Owner:** test-owner
- **Revision after revision:** `sha256:633c36ae774c4d00ee7b4380323865b79e9a4836a66165ba230985ade9c5d905`
- **Context:** `1f3d16f1-bc71-4052-8545-5aa2bc7461ec` version 2
- **Project version:** 4
- **Evaluator:** 0.22.1 (`archive_sha256: cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`)

## Fixture inspection

Source: `inputs/source/src/greeting.py`

The function `greeting()` returns exactly `'Hello rehearsal'`. This was confirmed by reading the source file directly.

## Operations performed

| Step | Operation | Key | Record path | Outcome |
| --- | --- | --- | --- | --- |
| 1 | `remote status` | — | `work/status-001` | Ready, sandbox-projection, project version 0 |
| 2 | `remote import` | `import-baseline-001` | `work/import-001` | Accepted, 7 artifacts imported, project version 0→1 |
| 3 | `remote draft-open` | `draft-open-001` | `work/draft-open-001` | Accepted, context opened, project version 1→2 |
| 4 | `remote create-artifact` | `create-intent-001` | `work/create-intent-001` | Accepted, INT-P3-001 template created, 10 incomplete placeholders |
| 5 | Write completed document | — | `work/INT-P3-001.md` | All placeholders replaced |
| 6 | `remote revise-artifact` | `revise-intent-001` | `work/revise-intent-001` | Accepted, admissible, 0 errors, 0 incomplete |

## Draft validation findings

**After revision (revise-intent-001):**

- `admissible: true`
- `errors: []`
- `incomplete: []`
- **Background (pre-existing):** `W-AUT-022` — Coverage row REQ-P3-900 names undefined rule P3-GREET-900 in `SPEC-P3-900.md`. This advisory belongs to the imported baseline and does not affect INT-P3-001.

## Content review (agent assessment)

Checked against the intent checklist in `docs/engineering/ARTIFACT_AUTHORING.md`:

1. **Problem, who it affects, outcome:** States that no definition covers the expected greeting value, affecting the operator who needs to verify the fixture. Outcome: the operator can confirm the exact return value.
2. **Smallest useful outcome:** Scoped to a single function and a single expected string. No additional behavior or deployment is included.
3. **How the owner will know:** Success measure baseline is honestly `not measured`. The target is an active intent naming the expected value. Observation method is manual review — this is a governance measure, not an acceptance test.
4. **Scope limits:** Four explicit exclusions cover implementation changes, other functions, deployment, and lifecycle decisions.

**Content limits:** The success measure describes a governance state (having an accepted definition), not a runtime observation. Verifying that `greeting()` actually returns `Hello rehearsal` at runtime is an acceptance check and belongs in a verification contract (VER), not in the intent's success measures. This is a deliberate separation per the template guidance. No operational deployment exists for this diagnostic fixture, so a runtime-observable measure is not available.

## Document and evidence paths

- Completed draft: `work/INT-P3-001.md`
- Import evidence: `work/import-001.evidence/`
- Draft-open evidence: `work/draft-open-001.evidence/`
- Create evidence: `work/create-intent-001.evidence/`
- Revise evidence: `work/revise-intent-001.evidence/`
- Status evidence: `work/status-001`

## Result

One intent draft (INT-P3-001) prepared and submitted. The evaluator reports it as admissible with zero errors and zero incomplete fields. The draft remains in `draft` status — no approval, lifecycle transition, or other artifacts were created. Observations are captured by the native runner.

Report path: `work/native-report.md`
