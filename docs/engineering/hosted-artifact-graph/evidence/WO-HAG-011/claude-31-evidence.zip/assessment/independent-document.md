+++
id = "INT-P3-001"
type = "intent"
title = "Establish that the rehearsal greeting fixture returns the expected value"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"
outcome = "An operator can confirm that greeting() returns exactly Hello rehearsal."

[relations]
+++

# Intent: Establish that the rehearsal greeting fixture returns the expected value

## In plain words

An operator needs to verify that the greeting fixture in `src/greeting.py` produces the exact string `Hello rehearsal`. This intent covers only that single assertion.

## Problem

The project contains a greeting fixture at `src/greeting.py` that returns a fixed string. No current definition establishes what value `greeting()` must return or provides a verification path for an operator to confirm the output. Without this, the operator cannot point to an accepted intent when checking the fixture.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| Operator can cite an accepted definition that states the expected greeting value | not measured | An active intent names the exact expected return value | Manual review of the artifact registry |

## Not this

- Changes to the greeting fixture implementation.
- Verification of any function other than `greeting()`.
- Deployment, release, or operational use of the greeting fixture.
- Approval or lifecycle decisions beyond draft preparation.
