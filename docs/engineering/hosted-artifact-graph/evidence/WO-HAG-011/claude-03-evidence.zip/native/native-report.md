# Native drafting diagnostic report

## Scope

Focused diagnostic under WO-HAG-011 efficiency comparison. Prepared one new
intent draft (INT-P3-001) to establish that the existing fixture's `greeting()`
returns exactly `Hello rehearsal`. Operated in the private hosted sandbox
(project 95b90842-d105-45a3-b0b0-eed82c9b297c) using the native transport
helper route. No lifecycle decisions, approvals, baseline freezes, or work
starts were exercised.

## Fixture inspection

- **Source read:** `src/greeting.py` contains `def greeting(): return 'Hello rehearsal'`
- **Assertion:** `assert-greeting` helper confirmed `exact greeting passed`
  (record: `work/greeting-001.json`)
- **Greeting SHA-256 (selection):** `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`

## Setup verification

- **Client identity:** wheel SHA `d4bf8b5e1f32a039a48c30c6fcc54085c5ca4bba2b05e50f938e88d23c785ac9`
  matches combination report exactly.
- **Service status:** ready, authority mode `sandbox-projection`, test_copy true.
  All component identities (evaluator 0.22.1, database 3.13.1, server, plugins,
  protocols) match the combination report. Record: `work/status-001.json`.

## Instruction discovery

The following released instruction sections were read before authoring:

| Resource | Section | SHA-256 |
| --- | --- | --- |
| DRAFT_DEFINITIONS.md | read-this-when | 43fb74d3453a8d13b76f867e87622559941ae3672acbf2aa9c26d9e9e6fde02f |
| DRAFT_DEFINITIONS.md | before-this-action | fef13ff697eca3188c35b224644f1baf22534d9cb30142f440882d170d28bc6c |
| DRAFT_DEFINITIONS.md | draft-any-missing-definitions | c38865671a81429dd291d9f9bb333deae02a4098d4afcf034f293ee919e990e0 |
| ARTIFACTS.md | artifact-types | 47268c9ec1e3551fb547ad3d1ef7b8da0b773b52b3a4364f42c36cc64f98bf83 |
| ARTIFACTS.md | artifact-locations | 8df276d2f837c4dcc663dbdb42c67cbb6f8fe3bf4abcb53acf86bc7538269a72 |
| ARTIFACT_AUTHORING.md | design-simplicity | 29e9b6296f39215c4b2ad36659c0674f0b20650682db9aa1187fc97871cfdb06 |
| ARTIFACT_AUTHORING.md | intent | 291e8274f0c400a3d2d1ecdd56f2c10d68ab6cb40f667076a034e44d87c05e42 |

The hosted drafting procedure was read from the plugin at
`skills/change/references/hosted-drafts.md`.

## Operations performed

| # | Operation | Key | Project version | Outcome | Record |
| --- | --- | --- | --- | --- | --- |
| 1 | status | (read) | 0 | ready | work/status-001.json |
| 2 | assert-greeting | (read) | 0 | passed | work/greeting-001.json |
| 3 | import | import-source-001 | 0 -> 1 | accepted | work/import-001.json |
| 4 | draft-open | draft-open-001 | 1 -> 2 | accepted | work/draft-open-001.json |
| 5 | create-artifact | create-intent-001 | 2 -> 3 | accepted | work/create-intent-001.json |
| 6 | revise-artifact | revise-intent-001 | 3 -> 4 | accepted | work/revise-intent-001.json |
| 7 | read (failed) | - | 4 | not_sent (exit 2) | work/read-intent-001.json |
| 8 | read (recovered) | - | 4 | completed | work/read-intent-002.json |

## Draft artifact

- **ID:** INT-P3-001
- **Type:** intent
- **Status:** draft
- **Domain:** lifecycle-pilot
- **Owner:** test-owner
- **Path:** docs/engineering/lifecycle-pilot/intent/INT-P3-001.md
- **Revision:** sha256:55864330a3d59628af622c8614d36e073d5a7def10ae6566ebdbbe2342dbb253
- **Document SHA-256:** 779b65a3f8783349e3b5614f83f7e8879478252445c6fb4152179badb02520b3
- **Context:** dbbdb263-69cf-46ff-8fe3-a803d0b52f57 (version 2)

## Authoring findings (from revise-intent-001)

- **Admissible:** true
- **Errors:** 0
- **Incomplete fields:** 0
- **Background advisories:** 1 (W-AUT-022 on SPEC-P3-900: coverage row
  REQ-P3-900 names undefined rule P3-GREET-900; pre-existing from import)

The draft passed template admission with all required fields completed.
Template admission is not a content review.

## Content assessment

The intent draft states:
- **Problem:** The fixture greeting() returns `Hello rehearsal` but no formal
  intent documents this expected behavior.
- **Outcome:** An operator can establish that greeting() returns exactly
  `Hello rehearsal`.
- **Success measure:** greeting() returns exactly `Hello rehearsal`, observed
  during verification against the fixture source. Baseline is `not measured`.
- **Scope limits:** Does not change implementation, define downstream artifacts,
  or authorize work/release.

The problem and outcome are supported by source inspection (Read of
`src/greeting.py`) and the mechanical greeting assertion. The success measure
describes an observable operational fact (fixture output), not an acceptance
test. The "not measured" baseline is honest — no prior formal measure exists.

**Unresolved content:** The success measure's "Observed" column says "During
verification against the fixture source." This describes method but does not
name a specific operational location or cadence that an operator would
independently recognise. This is an honest limitation; the measure applies to
a test fixture, not a production service with a monitoring endpoint.

## Failures and recovery

1. **read-intent-001 (exit 2):** Supplied `--evaluator-file` to a typed read
   operation. The tool index specifies "no mutation fields" for reads. Error
   message: "Input does not apply to this typed operation: --evaluator-file".
   **Recovery:** Re-issued as read-intent-002 without mutation fields. Succeeded.
   No data loss or unresolved effect.

## Limits

- This is a focused diagnostic, not a complete NQ-01 through NQ-05 claim.
- Lifecycle decisions (approve, start, freeze, release) were not exercised.
- MCP parity, reply recovery, and export are outside this diagnostic scope.
- The background advisory W-AUT-022 on SPEC-P3-900 is a pre-existing imported
  condition, not introduced by this draft.
- Template admission with zero incomplete fields does not establish content
  quality; the checklist was applied manually but has no mechanical gate.
- The observations snapshot reports 22 native calls and 1 failed command record.
  Peak input context exceeded the 40000 goal.
