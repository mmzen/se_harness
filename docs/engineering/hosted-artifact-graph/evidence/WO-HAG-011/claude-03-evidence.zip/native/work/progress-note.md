# Progress note — focused hosted drafting diagnostic

## Selection

- Project: 95b90842-d105-45a3-b0b0-eed82c9b297c
- Endpoint: http://127.0.0.1:18403
- Evaluator: 0.22.1
- Client: 0.22.2 (sha256:d4bf8b5e1f32a039a48c30c6fcc54085c5ca4bba2b05e50f938e88d23c785ac9)
- Authority mode: sandbox-projection
- Test copy: true

## Current state

- Project version: 4
- Baseline: se-harness-artifact-baseline/v1:sha256:6f4dc74dee3daf5a2bb3d7791f8ccc0ddc21fde5d1609f357190f891abac14e0
- Draft context: dbbdb263-69cf-46ff-8fe3-a803d0b52f57 (version 2)
- Work order: WO-P3-900 (imported, draft)

## Draft artifact

- ID: INT-P3-001
- Type: intent
- Status: draft
- Domain: lifecycle-pilot
- Owner: test-owner
- Path: docs/engineering/lifecycle-pilot/intent/INT-P3-001.md
- Current revision: sha256:55864330a3d59628af622c8614d36e073d5a7def10ae6566ebdbbe2342dbb253
- Document SHA: 779b65a3f8783349e3b5614f83f7e8879478252445c6fb4152179badb02520b3

## Validation result (revise-intent-001)

- Admissible: true
- Errors: 0
- Incomplete fields: 0
- Background: 1 advisory (W-AUT-022 on SPEC-P3-900, pre-existing from import)

## Evidence paths

- Status: work/status-001.json
- Greeting assertion: work/greeting-001.json
- Import: work/import-001.json
- Draft open: work/draft-open-001.json
- Create intent: work/create-intent-001.json
- Revise intent: work/revise-intent-001.json
- Read intent (failed): work/read-intent-001.json
- Read intent (recovered): work/read-intent-002.json
- Draft document: work/INT-P3-001-draft.md

## Failures

- read-intent-001 (exit 2): supplied --evaluator-file to a read operation which accepts no mutation fields. Recovered with read-intent-002.

## Unresolved effects

None. All operations completed or recovered.
