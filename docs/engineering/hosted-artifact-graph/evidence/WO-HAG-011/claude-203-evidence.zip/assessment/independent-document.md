+++
id = "VER-P3-001"
type = "verification"
title = "Assert greeting return value against REQ-P3-900"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert greeting return value against REQ-P3-900

## Independence

The expected string `Hello rehearsal` is fixed by the acceptance criterion in REQ-P3-900. The pass condition derives from that requirement, not from candidate output or implementation inspection.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Call `greeting()` from `src/greeting.py` at the verified commit and compare the return value | The return value equals the string `Hello rehearsal` exactly, with no leading or trailing whitespace. Platform: linux/amd64, Python 3.13. Evaluator: se_harness 0.22.1. |

## Acceptance scenarios

1. Import `greeting` from `src/greeting.py` at the exact candidate commit.
2. Call `greeting()` with no arguments.
3. Assert that the return value is the Python string `'Hello rehearsal'`.

## Evidence retention

Retain the assertion result as a JSON file at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-assertion.json`. The file records the actual return value, the expected value, the comparison result, and the candidate commit hash.

## Residual uncertainty

This contract covers the exact return value only. It does not verify encoding, locale behavior, or concurrent-call safety, because REQ-P3-900 constrains only the returned string.
