"""Exercise the installed Windows section transport with real Unicode resources."""
import json,os,sys,hashlib
from pathlib import Path
import hag221_execute as h
h.O=h.W/'hag-efficiency-proposal-20261008'
root=h.O/'checks-02';native=root/'native'
s=json.loads((root/'native-selection.json').read_text())
env=dict(os.environ,HAG_NATIVE_WORK_DIRECTORY=str(native),HAG_NATIVE_SELECTION=str(root/'native-selection.json'),PYTHONIOENCODING='cp1252')
selectors=['released-resources/docs/engineering/harness/ARTIFACTS.md#artifact-types','released-resources/docs/engineering/harness/ARTIFACTS.md#artifact-locations','released-resources/docs/engineering/ARTIFACT_AUTHORING.md#intent','released-resources/docs/engineering/ARTIFACT_AUTHORING.md#design-simplicity']
argv=[h.HOST,'-I',s['native_helper'],'instructions']
for selector in selectors:argv+=['--section',selector]
v=h.run('installed03-multisection',argv,cwd=native,env=env)
count=0
for resource in v['resources']:
 raw=Path(resource['path']).read_bytes()
 assert h.sha(raw)==resource['sha256']
 lines=raw.decode('utf-8').splitlines(keepends=True)
 assert resource['release']['version']=='0.22.1'
 for item in resource['sections']:
  exact=''.join(lines[item['start_line']-1:item['end_line']])
  assert exact==item['content'],item['heading']
  assert h.sha(exact.encode())==item['content_sha256']
  count+=1
assert count==4
assert any(ord(c)>127 for r in v['resources'] for s in r['sections'] for c in s['content'])
h.write(root/'section-assessment.json',{'passed':True,'sections':count,'console_encoding':'cp1252 forced for parent and child','provenance':'Compared returned section bytes/digests to exact staged released 0.22.1 bytes; Unicode content preserved. No task or draft content supplied.'})
print(json.dumps({'section_fidelity':True,'sections':count}))
