"""Retain package/client boundary evidence without private runtime credentials."""
import datetime,json,re,zipfile,hashlib
from pathlib import Path
import hag_efficiency_plan as h
dest=h.D/'evidence/WO-HAG-011';load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
tokens=[x['token'].encode() for p in h.O.glob('*/credentials.json') for x in load(p)['principals']]
files={}
for pattern in ('installed-*.json','installed03-*.json','candidate-*.json','build0*-replay.json','client-build-*.json','package-0*.json','client-install-*.json','service-*comparison.json','entry-sizes03.json','validation-05.json'):
 for p in h.O.glob(pattern):files['observations/'+p.name]=p
for trial in ('checks-01','checks-02'):
 root=h.O/trial
 for p in (root/'checks').rglob('*'):
  if p.is_file():files[trial+'/'+p.relative_to(root).as_posix()]=p
 for name in ('combination.json','selection.json','section-assessment.json'):
  p=root/name
  if p.exists():files[trial+'/'+name]=p
for package in ('package02','package03'):
 for name in ('combination.json','image-inspect.json'):
  p=h.O/package/name
  if p.exists():files[package+'/'+name]=p
for name in ('hag_efficiency_native.py','hag_efficiency_live.py','hag_efficiency_live03.py','hag_efficiency_sections03.py','hag_efficiency_package03.py','hag_efficiency_observe.py','hag_efficiency_retain.py','hag_efficiency_retain_mechanical.py'):
 files['operator/'+name]=h.W/name
inventory=[]
archive=dest/'installed-client-evidence.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):
  raw=p.read_bytes();assert not any(t in raw for t in tokens),name
  assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
  z.writestr(name,raw);inventory.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
timings=[]
for name in ('client-build-03','package-03','client-env-03','client-install-03'):
 p=h.O/(name+'.json');v=load(p);start=datetime.datetime.fromisoformat(v['observed_at']).timestamp()
 timings.append({'command':name,'capture_interval_seconds':round(p.stat().st_mtime-start,3),'method':'Recorded command-start UTC to completed log file timestamp; includes log serialization, not provider/model time.'})
index={'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':inventory,'preparation_capture_intervals':timings,'limitations':'Mechanical client and exact-package observations. Deliberate stale/key/capture/lost-reply failures are expected tests; no native content verdict inferred. Original schema/transport test bodies may retain template placeholders. Credential files excluded and known private project tokens checked absent.'}
(dest/'installed-client-inventory.json').write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'files':len(files),'bytes':archive.stat().st_size,'timings':timings},indent=2))
