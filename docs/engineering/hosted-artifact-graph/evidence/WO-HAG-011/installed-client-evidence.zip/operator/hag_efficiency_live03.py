"""Installed client EFF-02/03 against a private service; deliberate faults only."""
import base64,hashlib,json,os,sys,subprocess
from pathlib import Path
import hag221_execute as h
h.O=h.W/'hag-efficiency-proposal-20261008'
root=h.O/'checks-02';out=root/'checks';out.mkdir(exist_ok=False)
s=json.loads((root/'selection.json').read_text());config=json.loads(Path(s['configuration']).read_text())
creds=json.loads((root/'credentials.json').read_text());token=next(x['token'] for x in creds['principals'] if x['id']=='operator')
env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token)
py=s['client_python'];common=['--endpoint',s['endpoint'],'--project',s['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--json']
ev=out/'evaluator.json';h.write(ev,config['components']['evaluator'])
client=config['client'];project=s['project_id'];observed=[]
def invoke(label,op,extra,allow=(0,),fault=None):
 argv=[py,'-I','-m','se_harness','remote',op,*common,*map(str,extra)]
 if op in ('import','draft-open','create-artifact','revise-artifact'):argv+=['--client-wheel',s['client_wheel']]
 if fault:
  script='import sys; from se_harness.cli import main; from se_harness.remote_authoring import Capture; '+fault+'; raise SystemExit(main(sys.argv[1:]))'
  argv=[py,'-I','-c',script,*argv[4:]]
 value=h.run('installed03-'+label,argv,cwd=out,env=env,allow=allow)
 observed.append({'case':label,'operation':op,'result_file':str(h.O/('installed03-'+label+'.json'))})
 return value

def mutate(label,op,version,flags,fields,include=False):
 expected={'schema':'se-harness-remote-command/v1','operation':op,'project_id':project,'operation_key':label,'expected_project_version':version,'expected_evaluator':config['components']['evaluator'],'client':client,**fields}
 capture=out/label
 value=invoke(label,op,['--typed','--operation-key',label,'--expected-project-version',version,'--evaluator-file',ev,'--compact','--record-directory',capture,*flags,*(['--include-document'] if include else [])])
 actual=json.loads((capture/'1-request.json').read_bytes());assert actual==expected,(label,actual,expected)
 raw=out/(label+'-raw.json');h.write(raw,expected)
 replay=invoke(label+'-raw-replay',op,['--request',raw]);assert replay==value['result'],label
 return value
manifest=json.loads(Path(s['source_manifest']).read_text())
value=mutate('import','import',0,['--source-manifest',s['source_manifest']],{'source_manifest':manifest})
baseline=value['result']['view']['baseline_id']
value=mutate('open','draft-open',1,['--baseline',baseline,'--work-order','WO-P3-900'],{'base_baseline_id':baseline,'work_order_id':'WO-P3-900'})
context=value['result']['view']['context_id']
value=mutate('create','create-artifact',2,['--context',context,'--context-version',0,'--domain','lifecycle-pilot','--artifact-type','intent','--artifact','INT-EFF-001'],{'context_id':context,'expected_context_version':0,'domain':'lifecycle-pilot','artifact_type':'intent','artifact_id':'INT-EFF-001'},True)
original=value['result'];revision=original['affected_artifacts'][0]['revision_id'];doc=Path(value['document_read']['documents'][0]['path']).read_bytes()
changed=doc+b'\nTransport fixture: exact UTF-8 caf\xc3\xa9.\r\n';document=out/'authored.md';h.write(document,changed)
value=mutate('revise','revise-artifact',3,['--context',context,'--context-version',1,'--artifact','INT-EFF-001','--expected-revision',revision,'--document-file',document],{'context_id':context,'expected_context_version':1,'artifact_id':'INT-EFF-001','expected_revision_id':revision,'document_base64':base64.b64encode(changed).decode()})
revision=value['result']['affected_artifacts'][0]['revision_id'];view=value['result']['view']
readflags=['--typed','--context',context,'--context-version',2,'--artifact','INT-EFF-001','--expected-revision',revision,'--compact','--record-directory',out/'read']
value=invoke('read','read',readflags)
assert Path(value['documents'][0]['path']).read_bytes()==changed
expected={'schema':'se-harness-graph-read/v1','operation':'revision','project_id':project,'view':view,'artifact_id':'INT-EFF-001','revision_id':revision,'budget':{'rows':1,'bytes':2097152,'depth':0}}
assert json.loads((out/'read/1-request.json').read_bytes())==expected
raw=out/'read-raw.json';h.write(raw,expected)
read=invoke('read-raw','read',['--request',raw]);assert base64.b64decode(read['data']['document_base64'])==changed
# Service-side conflicts are retained with no implicit version refresh/retry.
request=json.loads((out/'revise-raw.json').read_bytes());request['operation_key']='stale';h.write(out/'stale.json',request)
x=invoke('stale','revise-artifact',['--request',out/'stale.json','--compact','--record-directory',out/'stale'],allow=(1,));assert x['result']['outcome']!='accepted'
request['operation_key']='revise';request['expected_project_version']=4;h.write(out/'reused-key.json',request)
x=invoke('reused-key','revise-artifact',['--request',out/'reused-key.json'],allow=(1,));assert x['outcome']!='accepted'
# Local capture failure occurs after a real accepted revision. Keep original key.
changed2=changed+b'Capture interruption fixture.\r\n';h.write(out/'capture-fault.md',changed2)
flags=['--typed','--operation-key','capture-fault','--expected-project-version',4,'--evaluator-file',ev,'--context',context,'--context-version',2,'--artifact','INT-EFF-001','--expected-revision',revision,'--document-file',out/'capture-fault.md','--compact','--record-directory',out/'capture-fault']
invoke('capture-fault','revise-artifact',flags,allow=(2,),fault="Capture.finish=lambda *a,**k: (_ for _ in ()).throw(OSError('deliberate capture fault'))")
log=json.loads((h.O/'installed03-capture-fault.json').read_text());error=json.loads(log['stderr']);assert error['outcome']=='unknown' and error['operation_key']=='capture-fault'
receipt=invoke('capture-reconcile','operation',['--key','capture-fault']);assert receipt['outcome']=='accepted' and receipt['versions']['project']['after']==5
revision=receipt['affected_artifacts'][0]['revision_id']
# Fault proxy discards one accepted draft reply; it makes no recovery choice.
sys.path.insert(0,str(h.R/'tests/hosted_artifact_graph'))
import qualify_agents
source=(h.R/'tests/hosted_artifact_graph/qualify_agents.py').read_text()
source=source.replace("sent.get('schema') == 'se-harness-lifecycle-command/v2'","sent.get('schema') == 'se-harness-remote-command/v1'").replace("sent.get('mode') == 'apply'","sent.get('operation_key') == 'lost-reply'")
module={'__name__':'draft_reply_fault'};exec(compile(source,'observed-draft-reply-fault','exec'),module)
fault=module['ReplyFault'](s['endpoint'],out)
real_endpoint=common[1];common[1]=fault.endpoint
try:
 changed3=changed2+b'Lost reply fixture.\r\n';h.write(out/'lost.md',changed3)
 flags=['--typed','--operation-key','lost-reply','--expected-project-version',5,'--evaluator-file',ev,'--context',context,'--context-version',3,'--artifact','INT-EFF-001','--expected-revision',revision,'--document-file',out/'lost.md','--compact','--record-directory',out/'lost-reply']
 invoke('lost-reply','revise-artifact',flags,allow=(2,))
 assert fault.dropped
finally:common[1]=real_endpoint;fault.close()
receipt=invoke('lost-reconcile','operation',['--key','lost-reply']);assert receipt['versions']['project']['after']==6
x=invoke('lost-exact-retry','revise-artifact',['--request',out/'lost-reply/1-request.json']);assert x==receipt
status=invoke('final-status','status',[]);assert status['project_version']==6
revision=receipt['affected_artifacts'][0]['revision_id']
x=invoke('final-read','read',['--typed','--context',context,'--context-version',4,'--artifact','INT-EFF-001','--expected-revision',revision,'--compact','--record-directory',out/'final-read'])
assert Path(x['documents'][0]['path']).read_bytes()==changed3
h.write(out/'assessment.json',{'cases':observed,'wire_equivalence':['import','draft-open','create-artifact','revise-artifact','revision read'],'exact_final_bytes':True,'expected_mutations':6,'observed_project_version':status['project_version'],'capture_failure':'real accepted mutation; unknown client outcome; original receipt recovered','reply_failure':'accepted response dropped by fault proxy; identical retry returned original receipt','limits':'Transport fixtures retain draft placeholders; no authored-content or native-agent qualification claim.'})
print(json.dumps({'mechanical_cases_pass':True,'final_project_version':6}))
