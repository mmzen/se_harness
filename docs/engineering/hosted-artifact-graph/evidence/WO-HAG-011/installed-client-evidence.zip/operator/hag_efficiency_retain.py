"""Retain exact bounded test inputs/results and visible messages, never reasoning."""
import json,re,sys,zipfile,hashlib
from pathlib import Path
from collections import Counter
import hag_efficiency_plan as h
trial=sys.argv[1];root=h.O/trial;native=root/'native';dest=h.D/'evidence/WO-HAG-011'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
assert (native/'session.json').exists()
tokens=[x['token'].encode() for p in h.O.glob('*/credentials.json') for x in load(p)['principals']]
omissions=Counter();visible=[]
for line,s in enumerate((native/'events.jsonl').read_text(encoding='utf-8').splitlines(),1):
 e=json.loads(s)
 if e.get('type') not in ('assistant','user'):
  omissions['nonmessage_events']+=1;continue
 m=e.get('message',{})
 for b in m.get('content',[]) if isinstance(m,dict) else []:
  typ=b.get('type')
  if typ in ('thinking','redacted_thinking'):
   omissions['private_reasoning_blocks']+=1;continue
  if typ=='text':text=b['text']
  elif typ=='tool_use':text=json.dumps({'tool':b['name'],'id':b['id'],'input':b['input']},ensure_ascii=False,indent=2)
  elif typ=='tool_result':text=json.dumps(b,ensure_ascii=False,indent=2)
  else:omissions['other_blocks']+=1;continue
  text=re.sub(r'<system-reminder>.*?</system-reminder>','[Host reminder omitted.]',text,flags=re.S)
  visible.append(f'\n## Event {line}: {e["type"]} {typ}\n\n{text}\n')
intro='# Visible native transcript: '+trial+'\n\nPrivate reasoning and host/system events are omitted. This is not a reconstruction of the full model input. Visible text and tool exchanges follow in recorded order. Original unredacted events remain private and unchanged.\n'
export=(intro+''.join(visible)).encode()
files={}
for name in ('session.json','invocation.json','selection.json','task.md','native-report.md','native-observations.json','stderr.txt'):
 p=native/name
 if p.is_file():files['native/'+name]=p.read_bytes()
for sub in ('work','inputs'):
 for p in (native/sub).rglob('*'):
  if p.is_file() and not p.name.endswith(('.whl','.pyc')) and not any(s in p.parts for s in ('__pycache__','.git')):
   files['native/'+p.relative_to(native).as_posix()]=p.read_bytes()
for name in ('selection.json','combination.json','stage-evidence.json','permissions.json','independent-assessment.json','independent-read-request.json'):
 p=root/name
 if p.exists():files['assessment/'+name]=p.read_bytes()
summary=h.O/(trial+'-summary.json')
if summary.exists():files['assessment/metrics.json']=summary.read_bytes()
files['native/visible-transcript.md']=export
inventory=[]
for name,raw in files.items():
 assert not any(t in raw for t in tokens),name
 assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
 assert 'events.jsonl' not in name and 'credentials' not in name
 inventory.append({'path':name,'bytes':len(raw),'sha256':sha(raw)})
archive=dest/(trial+'-evidence.zip')
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
(dest/(trial+'-visible.md')).write_bytes(export)
index={'archive':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':inventory,'omissions':dict(omissions),'original_events_sha256':sha((native/'events.jsonl').read_bytes()),'publication':'No raw events, private reasoning, host/system messages, credentials, wheel binaries or account stores. Bounded fixture inputs and command records retained; exact known test tokens checked absent. Original event digest identifies private local evidence only.'}
(dest/(trial+'-inventory.json')).write_text(json.dumps(index,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'archive':str(archive),'files':len(files),'bytes':archive.stat().st_size,'omissions':dict(omissions)}))
