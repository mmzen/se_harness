"""Bounded WO-HAG-011 correction checkpoint and exact disposable build."""
import json,sys,zipfile,tomllib
import hag221_execute as h
h.O=h.W/'hag-efficiency-proposal-20261008'
E=h.R/h.D/'evidence/WO-HAG-011'
mode=sys.argv[1]
if mode=='checkpoint':
 names=('unicode-focus-05','native-support-05','source-suite-05','distribution-05','cli-smoke-05')
 for name in names:
  d=json.loads((h.O/(name+'.json')).read_text());assert d['exit']==0,(name,d['exit'])
 with zipfile.ZipFile(E/'unicode-discovery-checks.zip','x',zipfile.ZIP_DEFLATED) as z:
  for name in (*names,'installed-multisection-reproduction'):
   p=h.O/(name+'.json');z.write(p,p.name)
 assert h.git('rev-parse','HEAD')=='4905b0ae9ad47e8636926bad1aad97ca5e90319d'
 paths=h.git('diff','--name-only').splitlines()+h.git('ls-files','--others','--exclude-standard').splitlines()
 scope=tomllib.loads((h.R/h.D/'work-orders/WO-HAG-011.md').read_text().split('+++')[1])['execution_scope']['paths']
 assert all(any(p==s or s.endswith('/') and p.startswith(s) for s in scope) for p in paths)
 h.run('checkpoint03-diff',['git','diff','--check'],cwd=h.R)
 h.run('checkpoint03-stage',['git','add','--',*paths],cwd=h.R)
 h.run('checkpoint03-commit',['git','commit','-m','Preserve Windows Unicode and clarify hosted instruction discovery','-m','Harness-Work-Order: WO-HAG-011'],cwd=h.R)
 assert not h.git('status','--porcelain')
 h.write(h.O/'candidate-03.json',{'commit':h.git('rev-parse','HEAD'),'base':'55caaada508495bea7d97effd27644d1ce8373da'})
elif mode=='build':
 candidate=json.loads((h.O/'candidate-03.json').read_text())['commit']
 assert h.git('rev-parse','HEAD')==candidate and not h.git('status','--porcelain')
 h.run('client-build-03',[h.HOST,'-X','utf8','-B','-m','repository_tools.release_build','replay','--repository',h.R,'--commit',candidate,'--version','0.22.2','--output-directory',h.O/'build03','--result',h.O/'build03-replay.json'],cwd=h.R,timeout=1800)
 wheel=h.W/'hag-phase3-execution-20261006/package02/candidate-source/server/vendor/se_harness-0.22.1-py3-none-any.whl'
 assert h.sha(wheel.read_bytes())=='cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053'
 h.run('package-03',[h.HOST,'-X','utf8','-B',h.R/'server/scripts/qualify.py','prepare','--repository',h.R,'--output',h.O/'package03','--client-wheel',h.O/'build03/se_harness-0.22.2-py3-none-any.whl','--client-replay',h.O/'build03-replay.json','--evaluator-wheel',wheel,'--image','harness-hag:native-efficiency03','--phase3'],timeout=1800)
 h.run('client-env-03',[h.HOST,'-m','venv',h.O/'client03'])
 h.run('client-install-03',[h.O/'client03/Scripts/python.exe','-I','-m','pip','install','--no-deps',h.O/'build03/se_harness-0.22.2-py3-none-any.whl'])
else:raise ValueError(mode)
