+++
id = "VER-P3-001"
type = "verification"
title = "Plan an independent exact greeting check"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verification Contract: Plan an independent exact greeting check

This synthetic alternative authoring exercise defines a future check of the existing fixture. REQ-P3-900 and SPEC-P3-900 define the greeting. VER-P3-900 already covers the requirement; this draft does not claim a coverage gap or replace that contract. The imported records remain unchanged. Owner test-owner is a synthetic label.

## Independence

The independent reviewer fixes the expected string `Hello rehearsal` from REQ-P3-900 acceptance and SPEC-P3-900 rule P3-GREET-900 before calling the fixture. The reviewer must not derive the expected value from source code, candidate output or a previous test result. The check compares the full returned value without trimming, case conversion or substring matching.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-900 | test | Exact greeting assertion; proposed evidence file in Evidence retention | On Windows with CPython 3.14, loading the identified fixture and calling greeting() succeeds, and Python equality against the independently fixed string `Hello rehearsal` is true. A load error, call exception or unequal result fails the check. |

## Acceptance scenarios

This is a verification plan. No test execution or verified outcome is asserted.

Inputs are the supplied REQ-P3-900 and SPEC-P3-900 definitions and the existing source snapshot at commit `5820415917e87b64d80bad2f7c39c6d18d692829`. The fixture is `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-efficiency-complete-inputs-20261010/codex-112/native/inputs/source/src/greeting.py`, with supplied SHA-256 `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`. The snapshot has no Git metadata; identify any later candidate separately before applying this plan to it.

The planned platform is Windows with CPython 3.14. The behavioral evaluator is Python's assertion of full string equality. SE Harness 0.22.1 evaluates the draft's shape and links; its admission is not the behavioral test.

When execution is separately authorized, the independent reviewer will:

1. Confirm the fixture identity and record the actual Python version and platform. A different fixture requires an explicit candidate identity before assessment.
2. Start `C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe -I -B` and enter the following statements. Fix `expected` from the governing definitions before loading the fixture.

```python
expected = "Hello rehearsal"
import runpy
fixture = runpy.run_path("C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-efficiency-complete-inputs-20261010/codex-112/native/inputs/source/src/greeting.py")
actual = fixture["greeting"]()
print(repr(actual))
assert actual == expected, (repr(actual), repr(expected))
```

3. Record the observed value and assertion outcome, or the actual load/call exception. Report pass only when the matrix condition is met. Retain failures as evidence; do not substitute the expected text for the observed value.

The single case covers the fixed return-value requirement. Errors and mismatches are failure outcomes of this case. No additional failure scenarios or platform guarantees are introduced.

## Evidence retention

The complete proposed destination is `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-efficiency-complete-inputs-20261010/codex-112/native/work/VER-P3-001-assertion.json`.

After an authorized run, the reviewer will retain a UTF-8 JSON record there containing the contract and requirement IDs, source snapshot commit, fixture path and observed SHA-256, reviewer identity, UTC time, actual Python version and platform, exact statements executed, independently derived expected string, observed value as repr and its type (or exception), complete transcript, and pass/fail assessment with its reason. This is a proposed evidence file, not existing evidence. No work-order evidence directory is assumed, and no evidence file is created by this drafting exercise.

## Residual uncertainty

This plan has not been executed. Its single check supports only the exact return-value requirement for the identified fixture and planned platform. It makes no assurance claim about side effects or other platforms. This draft grants no execution, approval or lifecycle authority.
