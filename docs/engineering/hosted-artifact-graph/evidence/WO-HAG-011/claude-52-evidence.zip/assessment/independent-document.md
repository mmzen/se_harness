+++
id = "VER-P3-901"
type = "verification"
title = "Verify greeting returns the exact rehearsal string"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verify greeting returns the exact rehearsal string

Alternative verification contract for REQ-P3-900. This contract defines an independent check that the `greeting()` function returns the exact string required by the requirement. Existing VER-P3-900 remains unchanged.

## Independence

The expected value `Hello rehearsal` is derived from REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The pass condition is fixed before any candidate output is observed. The verifier compares the actual return value of `greeting()` against this independently derived literal.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Call `greeting()` and compare the return value to the expected literal | `greeting()` returns exactly the string `Hello rehearsal` on Python 3.11 or later, evaluated with se_harness 0.22.1 |

## Acceptance scenarios

1. **Normal behavior:** Import `greeting` from `src/greeting.py`. Call `greeting()` with no arguments. Assert the return value equals `Hello rehearsal` (exact string, case-sensitive, no leading or trailing whitespace).
2. **Type check:** Assert the return value is of type `str`.

## Evidence retention

Retain the test result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-result.json`. The evidence file records the actual return value, the expected value, the comparison result, the Python version, and a timestamp.

## Residual uncertainty

This contract verifies the return value against the literal string from REQ-P3-900. It does not verify behavior under import errors or module-level side effects, as those are outside the scope of REQ-P3-900.
