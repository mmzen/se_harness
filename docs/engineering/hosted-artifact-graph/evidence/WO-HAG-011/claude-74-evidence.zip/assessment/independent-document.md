+++
id = "VER-P3-901"
type = "verification"
title = "Alternative greeting return-value assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative greeting return-value assertion

## Independence

The expected value `Hello rehearsal` derives from the acceptance criteria in REQ-P3-900 and the specification rule P3-GREET-900 in SPEC-P3-900. The check compares the candidate return value against this independently fixed string. No candidate output influences the expected result.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Call `greeting()` and compare its return value to the fixed expected string | `greeting()` returns exactly `Hello rehearsal` |

## Acceptance scenarios

**Scenario: greeting returns the exact rehearsal string**

- Platform: Python 3.11 or later.
- Evaluator: se_harness 0.22.1.
- Action: Import `greeting` from `src/greeting.py` and call `greeting()`.
- Expected result: The return value is the string `Hello rehearsal`, verified by exact equality (`==`).
- Pass condition: The assertion `greeting() == "Hello rehearsal"` evaluates to `True`.
- Failure: Any other return value, any raised exception, or a missing `greeting` function.

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/alternative-greeting-assertion.json`. The file records the actual return value, the expected value, the comparison outcome and a timestamp.

## Residual uncertainty

This contract defines the planned check. Execution and evidence capture occur during a future verification step under an approved work order.
