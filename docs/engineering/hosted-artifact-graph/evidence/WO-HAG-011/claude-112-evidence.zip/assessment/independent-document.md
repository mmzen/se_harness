+++
id = "VER-P3-901"
type = "verification"
title = "Assert the exact rehearsal greeting by independent comparison"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert the exact rehearsal greeting by independent comparison

## Independence

The expected string `Hello rehearsal` is fixed by REQ-P3-900 and SPEC-P3-900 rule P3-GREET-900. The pass condition compares candidate output against this requirement-derived constant, not against any value produced by the implementation.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Call `greeting()` and compare the return value to the independently fixed string | Return value equals exactly `Hello rehearsal`. Platform: Python 3.13 on linux/amd64. Evaluator: se_harness 0.22.1. |

## Acceptance scenarios

Call the function `greeting()` from `src/greeting.py`. Compare the returned string to the fixed expected value `Hello rehearsal`. The check passes when the two strings are identical. Any other return value, including differences in case, whitespace or punctuation, is a failure.

## Evidence retention

Retain the check result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/greeting-check.json`. The evidence file records the actual return value, the expected value, the comparison outcome and the evaluator version.
