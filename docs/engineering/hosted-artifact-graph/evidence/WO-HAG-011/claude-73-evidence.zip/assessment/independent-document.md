+++
id = "VER-P3-901"
type = "verification"
title = "Alternative greeting return-value assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative greeting return-value assertion

## Independence

The expected value `Hello rehearsal` derives from the acceptance criterion in REQ-P3-900, not from candidate output or implementation inspection.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import `greeting` from `src/greeting.py` and call `greeting()`. Compare the return value to the string `Hello rehearsal`. | The return value equals `Hello rehearsal` exactly. Evaluator: SE Harness 0.22.1. Platform: Python runtime in the candidate environment. |

## Acceptance scenarios

1. Import the `greeting` function from `src/greeting.py`.
2. Call `greeting()` with no arguments.
3. Assert that the return value is the exact string `Hello rehearsal`.

A return value that differs in case, spacing, punctuation, or content is a failure.

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-result.json`. The file records the actual return value, the expected value, the comparison outcome, and the timestamp.
