+++
id = "VER-P3-001"
type = "verification"
title = "Independent plan for the exact rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verification Contract: Independent plan for the exact rehearsal greeting

This is the requested alternative authoring exercise for REQ-P3-900. Existing
VER-P3-900 already covers that requirement. This draft does not replace it or
change WO-P3-900. All actors are synthetic test labels.

## Independence

The expected Python string is `"Hello rehearsal"`, taken from the Acceptance
section of REQ-P3-900 and rule P3-GREET-900 in SPEC-P3-900. The reviewer must fix
this expected value before execution and must not derive it from candidate output
or source code. A reviewer independent of the implementation performs the planned
check and assesses its retained evidence.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | GREETING-EXACT: invoke the fixture's greeting() with no arguments; retain the record at the complete path in Evidence retention. | The call completes without an exception, returns a Python string, and its value equals `"Hello rehearsal"` exactly, including case and whitespace. |

## Acceptance scenarios

This is a plan, not an execution result.

Inputs: the existing fixture at
`C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-efficiency-inputs-20261010/codex-92/native/inputs/source/src/greeting.py`,
REQ-P3-900 and SPEC-P3-900 from the same supplied source snapshot.
The source snapshot is identified by commit
`5820415917e87b64d80bad2f7c39c6d18d692829`; it contains tracked Git blobs
without Git metadata. The inspected fixture SHA-256 is
`dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`.

Planned platform: Windows x64 with CPython 3.14. The test evaluator is CPython's
string type check and exact equality comparison, assessed by the independent
reviewer. SE Harness 0.22.1 checks draft structure and links; it does not execute
this behavior test.

After separate execution authority is available, the reviewer performs these
manual actions:

1. Record the input path, actual input SHA-256, source snapshot identity, Python
   version, operating system, reviewer and UTC execution time. If the input differs
   from the identified fixture, stop and record the mismatch without a pass.
2. Start a fresh isolated Python interpreter with `-I`. Use
   `runpy.run_path` on the absolute fixture path above and select the returned
   namespace's `greeting` callable.
3. Call `greeting()` once with no arguments and retain the actual return value's
   type and `repr`. Do not strip whitespace or otherwise normalize the result.
4. Evaluate `isinstance(actual, str) and actual == "Hello rehearsal"`.
   A true result with successful loading and invocation passes GREETING-EXACT.
   A false result, missing callable, or exception fails the check. Retain any
   exception and captured standard output and standard error.

Exact comparison detects wrong wording, capitalization and added or missing
whitespace. A separate set of duplicate calls or invented failure inputs is not
needed for this fixed, no-argument behavior.

## Evidence retention

Proposed destination:
`C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-efficiency-inputs-20261010/codex-92/native/work/planned-verification-GREETING-EXACT.json`.

This filename is a future evidence destination, not an existing test result.
It is under this diagnostic's work directory and does not rely on an unresolved
work-order evidence directory.

Retain one JSON record containing case ID, requirement and specification IDs,
contract revision, input path and digest, source snapshot identity, platform and
interpreter version, reviewer, UTC time, exact actions, fixed expected string,
actual type and representation, comparison result, exceptions, standard output,
standard error and pass/fail or input-mismatch disposition. Preserve failure
details as well as successful results. Keep the record with this diagnostic's
retained authoring evidence for reviewer handoff.

## Residual uncertainty

No behavior test has been run under this contract. Source inspection alone does
not establish a verification result. This contract covers REQ-P3-900's exact
return value; it does not establish broader side-effect, security, performance,
lifecycle or release assurance. Execution and any later formal assessment require
their own authority. This draft grants none.

