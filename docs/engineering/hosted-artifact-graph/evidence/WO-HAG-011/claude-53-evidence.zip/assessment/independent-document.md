+++
id = "VER-P3-901"
type = "verification"
title = "Verify greeting returns exact rehearsal text"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verify greeting returns exact rehearsal text

Alternative verification contract for the rehearsal greeting fixture.

## Independence

The expected value `Hello rehearsal` derives from REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The expected result is not obtained from candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import and call `greeting()` from `src/greeting.py`; compare the return value to the independently fixed string. | The return value equals exactly `Hello rehearsal` with no leading or trailing whitespace and no other content. |

## Acceptance scenarios

**Scenario: exact greeting string.**

- Platform: Python 3.11 or later.
- Evaluator: se_harness 0.22.1.
- Inputs: the `src/greeting.py` module at the candidate commit.
- Action: import `greeting` from the module and call `greeting()`.
- Expected result: the string `Hello rehearsal`.
- Pass condition: `greeting() == "Hello rehearsal"` evaluates to `True`.
- Evidence: retain the assertion result (actual value, expected value, pass/fail, timestamp) in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-assertion.json`.

## Evidence retention

Retain the assertion result at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-assertion.json`. The file records the actual return value, the expected value, the comparison result, and the execution timestamp.
