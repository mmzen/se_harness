+++
id = "VER-P3-901"
type = "verification"
title = "Alternative greeting return-value assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative greeting return-value assertion

## Independence

The expected value `Hello rehearsal` derives from REQ-P3-900 acceptance criteria
and SPEC-P3-900 rule P3-GREET-900. Neither value is read from candidate output
or the fixture implementation. The verifier compares the function return value
against this independently fixed string.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Call `greeting()` and capture the return value | Return value equals exactly `Hello rehearsal` |

## Acceptance scenarios

**Scenario: greeting returns the exact rehearsal string**

1. Import `greeting` from `src/greeting.py`.
2. Call `greeting()` with no arguments.
3. Capture the return value as `actual`.
4. Assert `actual == "Hello rehearsal"`.
5. Assert `type(actual)` is `str`.

**Pass condition:** Both assertions hold. The test uses Python 3.11 or later
on the candidate commit. The evaluator is SE Harness 0.22.1
(`payload_sha256: 0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff`).

## Evidence retention

Retain the assertion result as a JSON object in
`docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-assertion.json`.
The object records the actual return value, the expected value, the comparison
result, and the candidate commit hash.
