# Native drafting diagnostic report

Diagnostic scope: VER-HAG-008 EFF-04B
Host: claude (Opus 4.6)
Date: 2026-10-09

## Task

Prepare one new verification-contract draft (VER-P3-901) for an independent
reviewer to check the existing fixture `src/greeting.py` against REQ-P3-900.
This is an alternative authoring exercise. Existing VER-P3-900 and all imported
-900 records remain unchanged.

## Reads performed

| Source | Path | SHA-256 |
|---|---|---|
| selection.json | `inputs/selection.json` (via native root) | read from disk |
| task.md | `native/task.md` | read from disk |
| native-tools.md | `inputs/native-tools.md` | read from disk |
| REQ-P3-900 | `inputs/source/docs/engineering/lifecycle-pilot/requirements/REQ-P3-900.md` | `99028b8605edfd6e85d3cbfb0ee5243f43df69059e314ed1f0b9ab0bde0bbba4` |
| SPEC-P3-900 | `inputs/source/docs/engineering/lifecycle-pilot/specifications/SPEC-P3-900.md` | `0904f98bddc075f26c87e2e2ce603e3d74a497b8df85e1093bf3b0f5f35a45f9` |
| VER-P3-900 | `inputs/source/docs/engineering/lifecycle-pilot/verification/VER-P3-900.md` | `9c975ff911c736f30dab7688df8f136e66eefd81eebc09362d0345cef813e8b4` |
| greeting.py | `inputs/source/src/greeting.py` | `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1` |
| configuration.json | `inputs/configuration.json` | read from disk |
| combination.json | `inputs/combination.json` | read from disk |
| hosted-context.md | `inputs/plugin/verity-plane/skills/setup/references/hosted-context.md` | read from disk |
| hosted-drafts.md | `inputs/plugin/verity-plane/skills/change/references/hosted-drafts.md` | read from disk |

## Triggers and operations

| Step | Operation | Key | Exit | Evidence |
|---|---|---|---|---|
| 1 | `identity` | — | 0 | (inline) |
| 2 | `remote status` | — | 0 | `work/status-001.json` |
| 3 | `lookup-file` | — | 0 | (inline) |
| 4 | `remote import` | `import-baseline-001` | 0 | `work/import-001.json` |
| 5 | `remote draft-open` | `draft-open-001` | 0 | `work/draft-open-001.json` |
| 6 | `remote create-artifact` | `create-ver-001` | 0 | `work/create-ver-001.json` |
| 7 | `remote revise-artifact` | `revise-ver-001` | 0 | `work/revise-ver-001.json` |
| 8 | `remote read` | — | 0 | `work/read-ver-001.json` |
| 9 | `observations` | — | 0 | (inline) |

All commands exited 0. No failures or denials.

## Draft result

- **Artifact ID:** VER-P3-901
- **Type:** verification
- **Domain:** lifecycle-pilot
- **Owner:** test-owner
- **Relation:** `verifies` → REQ-P3-900
- **Final revision ID:** `sha256:e5a5ba540a5a6e5a186ff181e1cbeb721bb20c98e4ff04c56e715cb3edca3847`
- **Document SHA-256:** `7f749f90585b07dbdccb8d7d37b0acc8bf4bb67400d012478fbc6c0748d11661`
- **Draft validation:** admissible, 0 errors, 0 incomplete fields
- **Background advisory (pre-existing):** W-AUT-022 — SPEC-P3-900 coverage row names undefined rule P3-GREET-900

## Digest sources

- Fixture digest `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1` confirmed via `lookup-file source/src/greeting.py` and matches `selection.json` field `greeting_sha256`.
- REQ-P3-900 digest `99028b8605edfd6e85d3cbfb0ee5243f43df69059e314ed1f0b9ab0bde0bbba4` matches the existing artifact pointer in task.md.
- Document revision digest `7f749f90585b07dbdccb8d7d37b0acc8bf4bb67400d012478fbc6c0748d11661` confirmed by read-back of the exact stored revision.

## Content derivation

The expected value `Hello rehearsal` derives independently from:

1. REQ-P3-900 acceptance: "Calling greeting() returns exactly `Hello rehearsal`."
2. SPEC-P3-900 rule P3-GREET-900: "The fixture function greeting() returns the string `Hello rehearsal`."

The fixture source was inspected (`def greeting(): return 'Hello rehearsal'`) to confirm the candidate behavior is observable. The expected value in VER-P3-901 does not depend on the fixture implementation.

## Findings

1. **Draft admissible.** VER-P3-901 passed draft validation with zero errors and zero incomplete fields.
2. **Independence maintained.** The expected string derives from the requirement and specification, not from candidate output.
3. **Requirement coverage.** REQ-P3-900 has a defined verification method (test), case (call and compare), and pass condition (exact string equality).
4. **Pre-existing advisory.** SPEC-P3-900 references rule P3-GREET-900 that the evaluator does not recognize as a defined rule (W-AUT-022). This is a background finding from the imported source, not introduced by VER-P3-901.
5. **No test execution.** This draft defines planned verification. No tests were run and no verification record (VREC) was created.

## Limits

- **No complete NQ-01 through NQ-05 claim.** Lifecycle transitions, MCP parity, reply recovery, and export are outside this focused diagnostic.
- **Efficiency targets missed.** Observations report 22 tool calls (target: 15) and peak input context 61261 tokens (target: 40000). The overrun results from reading the full task context, all governing artifacts, both plugin references, the tool index, and the configuration/combination files on the first turns.
- **No existing `DRAFT_DEFINITIONS.md#draft-any-missing-definitions` section read.** The task.md context already supplied the "Define how the result will be verified" procedure and the artifact types/locations tables. The `create-artifact` command fields were taken from the tool index rather than a separate instruction section read.
- **Wall time unavailable.** The observations snapshot reports `wall_seconds: null`; total elapsed cannot be confirmed mechanically.
