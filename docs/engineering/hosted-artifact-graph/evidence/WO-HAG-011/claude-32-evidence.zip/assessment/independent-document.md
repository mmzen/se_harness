+++
id = "VER-P3-901"
type = "verification"
title = "Verify greeting returns exact rehearsal text"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verify greeting returns exact rehearsal text

## Independence

The expected value `Hello rehearsal` derives from the acceptance criterion in REQ-P3-900, not from candidate output or implementation inspection.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import and call `greeting()`, compare return value to the independently fixed string | `greeting()` returns the exact string `Hello rehearsal` with no extra whitespace, casing variation or additional characters |

## Acceptance scenarios

1. Import `greeting` from `src/greeting.py`.
2. Call `greeting()` with no arguments.
3. Assert the return value equals the string `Hello rehearsal` exactly.

Platform: Python 3.11 or later.
Evaluator: se_harness 0.22.1.

## Evidence retention

Retain the assertion result (pass or fail with the actual returned value) in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-result.json`.

## Residual uncertainty

None identified. The acceptance criterion specifies one exact deterministic string.
