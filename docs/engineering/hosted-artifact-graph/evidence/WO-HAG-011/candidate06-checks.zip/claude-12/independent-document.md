+++
id = "VER-P3-001"
type = "verification"
title = "Assert greeting returns the exact rehearsal string"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert greeting returns the exact rehearsal string

## Independence

The expected value `Hello rehearsal` derives from REQ-P3-900 acceptance criteria, not from the candidate implementation output. The reviewer obtains the expected string from the requirement statement before inspecting `src/greeting.py`.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Call `greeting()` and compare return value to the fixed expected string | `greeting()` returns exactly `Hello rehearsal` |

## Acceptance scenarios

1. Import `greeting` from `src/greeting.py`.
2. Call `greeting()` with no arguments.
3. Assert that the return value is the Python string `'Hello rehearsal'` using strict equality.
4. The check passes when the assertion succeeds. The check fails when the return value differs in any character, casing, or whitespace.

Platform: Python 3.11 or later.
Evaluator: SE Harness 0.22.1.

## Evidence retention

Retain the assertion result, including the actual return value and pass/fail outcome, in the work order evidence directory.
