+++
id = "INT-P3-001"
type = "intent"
title = "Confirm greeting fixture returns the expected value"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"
# The desired outcome and who benefits. The Explorer shows this summary under the title.
outcome = "An operator can establish that greeting() returns exactly 'Hello rehearsal'."

[relations]
+++

# Intent: Confirm greeting fixture returns the expected value

Before approval, apply the shared design principle and `intent` checklist in
`docs/engineering/ARTIFACT_AUTHORING.md`.

## In plain words

The project needs a verified assertion that the greeting fixture produces the
exact string `Hello rehearsal`. This intent defines the problem and the
observable outcome so that verification can proceed.

## Problem

The `greeting()` function in `src/greeting.py` returns the string
`Hello rehearsal`. No existing definition explicitly establishes that this
exact return value is the required behavior. Without an intent that names the
expected output, an operator cannot distinguish a correct result from an
accidental one, and verification has no stated goal to confirm.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| `greeting()` returns exactly `Hello rehearsal` | not measured | The function returns the exact string on every invocation | Confirmed by executing the fixture and comparing the return value |

## Not this

- Changes to the greeting text or function signature.
- Verification of any function other than `greeting()`.
- Lifecycle decisions, approvals, or release actions.
- Performance, concurrency, or deployment behavior of the fixture.
