# Native drafting diagnostic report

Diagnostic scope: `VER-HAG-008 EFF-04B`
Host: claude (Opus 4.6)
Date: 2026-10-09

## Outcome

One new verification-contract draft (`VER-P3-901`) was authored and submitted
to the hosted sandbox. The evaluator accepted the revision with zero errors and
zero incomplete fields. The contract plans verification of `REQ-P3-900` and
does not claim that tests ran or that the result is verified.

## Draft artifact

| Field | Value |
|---|---|
| ID | `VER-P3-901` |
| Type | `verification` |
| Status | `draft` |
| Path | `docs/engineering/lifecycle-pilot/verification/VER-P3-901.md` |
| Revision | `sha256:d2558b64daecaeb05f733e7c9fe9fd9e261ab154ec2d6479c9edd4720c4329fc` |
| Document SHA-256 | `109cc690fa971690c24fc9e73955e8453f68d21083f5761b54f92266aaa352d3` |
| Admissible | true |
| Errors | 0 |
| Incomplete | 0 |
| Verifies | `REQ-P3-900` |
| Owner | `test-owner` |

## Reads performed

### Source artifacts

- `src/greeting.py` — inspected the fixture. The function `greeting()` returns
  `'Hello rehearsal'`. Selection records `greeting_sha256`:
  `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`.
- `REQ-P3-900` — acceptance criterion: calling `greeting()` returns exactly
  `Hello rehearsal`.
- `SPEC-P3-900` — specification rule P3-GREET-900: the fixture function
  `greeting()` returns the string `Hello rehearsal`.
- `VER-P3-900` — existing verification contract that already covers
  `REQ-P3-900`. The new `VER-P3-901` is an alternative authoring exercise as
  explicitly requested.

### Instructions and configuration

- `selection.json` — endpoint, project, evaluator, approved shell prefix,
  tool index.
- `task.md` — task description and selected instruction entry.
- `native-tools.md` — tool index for command syntax.
- `evaluator.json` — evaluator identity (0.22.1).
- `configuration.json` — combination report confirming `authority_mode:
  sandbox-projection`, `test_copy: true`.
- `hosted-context.md` — setup route for hosted sandbox.
- `hosted-drafts.md` — drafting procedure prerequisites.

## Remote operations

All operations succeeded. No failures or denials occurred.

| # | Operation | Key | Record | Outcome | Project version |
|---|---|---|---|---|---|
| 1 | `status` | — | `work/status-001` | ready | 0 |
| 2 | `import` | `import-001` | `work/import-001` | accepted | 0 → 1 |
| 3 | `draft-open` | `draft-open-001` | `work/draft-open-001` | accepted | 1 → 2 |
| 4 | `create-artifact` | `create-ver-001` | `work/create-ver-001` | accepted | 2 → 3 |
| 5 | `revise-artifact` | `revise-ver-001` | `work/revise-ver-001` | accepted | 3 → 4 |
| 6 | `read` | — | `work/read-ver-001` | complete | 4 |

Context ID: `73652808-5c2f-40ff-88a5-ffc8328463fe` (final version: 2).

## Content derivation

The expected value `Hello rehearsal` was derived from `REQ-P3-900` (acceptance
criterion) and `SPEC-P3-900` (rule P3-GREET-900). The contract's independence
section states this derivation. The expected value was not derived from
candidate output or from running the fixture.

## Findings

- **Draft admission:** The evaluator accepted the authored revision with zero
  errors and zero incomplete fields.
- **Background advisory:** `W-AUT-022` on `SPEC-P3-900` reports that coverage
  row `REQ-P3-900` names undefined rule `P3-GREET-900`. This is pre-existing
  in the imported source and unrelated to the new draft.
- **Existing coverage:** `VER-P3-900` already covers `REQ-P3-900`. The new
  contract is the explicitly requested alternative authoring exercise.
- **No lifecycle actions:** No approval, start, freeze, or lifecycle decision
  was performed.

## Failures

None.

## Limits

- No complete NQ-01 through NQ-05 claim. Lifecycle progression, MCP parity,
  reply recovery, and export are outside this focused diagnostic.
- No tests were executed. The contract plans verification only.
- Efficiency goals `calls_at_most_15` and `peak_under_40000` were missed per
  the observations snapshot.
- The `wall_under_180` goal was reported as unavailable by the observations
  tool.

## Evidence

All command records and evidence directories are retained under
`work/` in the native output directory. The authored document is at
`work/VER-P3-901.md`. The full observations snapshot is in
`native-observations.json` alongside this report.
