+++
id = "VER-P3-901"
type = "verification"
title = "Alternative greeting assertion contract"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative greeting assertion contract

## Independence

The expected value `Hello rehearsal` derives from the acceptance criterion in
REQ-P3-900 and the specification rule P3-GREET-900 in SPEC-P3-900. It does not
derive from candidate output or implementation inspection.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import `greeting` from `src/greeting.py` and call `greeting()`. Compare the return value to the expected string. | The return value equals exactly `Hello rehearsal` with no leading or trailing whitespace, no additional characters, and type `str`. |

## Acceptance scenarios

**Scenario: greeting returns the exact rehearsal string**

- **Inputs:** None. The function `greeting()` takes no arguments.
- **Action:** Call `greeting()` and capture the return value.
- **Expected result:** The string `Hello rehearsal`.
- **Evaluator:** se_harness evaluator 0.22.1 (archive SHA-256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`).
- **Platform:** Python 3.11 or later on linux/amd64 or win32.

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/` under
the governing work order directory. The evidence file records the actual return
value, the expected value, the comparison result (pass or fail), and the
timestamp of execution.
