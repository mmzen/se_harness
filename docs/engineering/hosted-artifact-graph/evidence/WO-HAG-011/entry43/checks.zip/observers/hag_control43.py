from pathlib import Path
import sys
W=Path(__file__).parent
source=(W/'hag_correction36.py').read_text().replace('hag-procedure36-20261011','h43')
source=source.replace('WO-HAG-011/procedure36','WO-HAG-011/entry43')
start=source.index('changed=');end=source.index('\n',start)
source=source[:start]+"changed=['tests/hosted_artifact_graph/qualify_agents.py', 'tests/hosted_artifact_graph/native_call.py', 'tests/hosted_artifact_graph/test_native_support.py', 'tests/hosted_artifact_graph/native-tools.md', 'plugins/verity-plane/common/skills/change/references/hosted-drafts.md', 'plugins/verity-plane/common/skills/change/references/hosted-test-lifecycle.md']"+source[end:]
for a,b in [('candidate-36','candidate-43'),('build36','build43'),('package36','package43'),('client36','client43'),('native-procedure36','native-entry43'),("-36'","-43'"),('hag36','h43')]:source=source.replace(a,b)
assert sys.argv[1] in ('scope','focused','checks','governor','build')
exec(compile(source,'entry42-control','exec'),{'__file__':str(W/'hag_correction36.py'),'__name__':'__main__'})
