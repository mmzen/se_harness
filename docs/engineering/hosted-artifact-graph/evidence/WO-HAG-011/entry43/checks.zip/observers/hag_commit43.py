"""Freeze the bounded correction and preserve C42 failures under existing work authority."""
import json,hashlib,subprocess,tomllib,zipfile
from pathlib import Path
import hag_efficiency_plan as p
W,R,D=p.W,p.R,p.D;O=W/'h43';p.O=O;E=D/'evidence/WO-HAG-011/entry43'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
assert git('rev-parse','HEAD')=='1da445cb743295c441cf46f421653b092d042378'
names=['source','distribution','smoke','resources-recovery','native-recovery','plugin-recovery','scope36','WO-HAG-009-preflight36','WO-HAG-011-preflight36','validation']
assert all(load(O/(x+'.json'))['exit']==0 for x in names)
E.mkdir(exist_ok=False);files={x+'.json':(O/(x+'.json')).read_bytes() for x in names+['resources']}
for f in (W/'hag42').glob('*/**/*-stop.json'):
 files['completed-test-cleanup/'+f.relative_to(W/'hag42').as_posix()]=f.read_bytes()
for name in ('hag_assess_full42.py','hag_retain42.py','hag_control43.py','hag_commit43.py'):
 files['observers/'+name]=(W/name).read_bytes()
for name in ('msys-pointer-reproduction.json','resume43-WO-HAG-009.json','resume43-WO-HAG-010.json','resume43-WO-HAG-011.json'):
 files['observations/'+name]=(W/'hag42'/name).read_bytes()
with zipfile.ZipFile(E/'checks.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
(E/'inventory.json').write_bytes((json.dumps({'archive':'checks.zip','sha256':sha((E/'checks.zip').read_bytes()),'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())]},indent=2)+'\n').encode())
review='''# Review: literal JSON pointers and precise native reports

The C42 runs remain incomplete. Their retained reports are in
[the full lifecycle assessment](../../WO-HAG-009/final42-result/assessment.md)
and [the focused assessment](../focused42-result/assessment.md).

This six-file correction is within WO-HAG-011's approved test-driver and
instruction paths:

- Preserve literal JSON pointers in Windows Claude child processes with
  `MSYS_NO_PATHCONV=1`. No host configuration or permission rule changes.
- Return exact small failure lists with observation summaries. Keep full snapshots
  and explicit pointers for larger lists. State that later calls are excluded.
- Clarify that reports include local recovered errors and later snapshot-read
  failures, and distinguish the test runtime from the lifecycle evaluator.
- Clarify the existing scope review: compare each generated path, including a
  paired record, to `execution_scope.paths`. A prose note adds no path.
- Distinguish REL definition approval from the RLS release decision. Supplied
  decisions determine the actor; an artifact owner field grants no right.

No evaluator, service, protocol, dependency, fixture outcome, host permission or
qualification criterion changed. The helper neither authors artifacts nor selects
the workflow. These changes address observed failures without another framework.

Validation: 1,339 source tests, 24 reported skips; 52 native checks, one skip;
28 resource checks, two skips; 11 plugin checks, one skip. Distribution and CLI
checks passed. Released validation: 1,991 artifacts, zero errors, 63 existing
warnings. Scope and both review preflights passed. The initial sandboxed resource
check failed on atomic hard-link creation in disposable files; its log is retained
beside the successful permitted rerun.

The next candidate needs fresh native results. Start the focused sequence with
Claude's missing-input case and review it before proceeding. Keep the PR draft
and all three work orders in progress. No assurance, merge or release is claimed.
'''
(E/'review.md').write_bytes(review.encode())
paths=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
allowed=[]
for aid in ['WO-HAG-009','WO-HAG-011']:
 allowed+=tomllib.loads((D/'work-orders'/f'{aid}.md').read_text().split('+++')[1])['execution_scope']['paths']
assert all(any(x==s or s.endswith('/') and x.startswith(s) for s in allowed) for x in paths)
p.run('diff-check',['git','diff','--check'],cwd=R)
p.run('stage',['git','add','--',*paths],cwd=R)
p.run('staged-check',['git','diff','--cached','--check'],cwd=R)
p.run('commit',['git','commit','-m','Correct native JSON pointer handling and qualification guidance','-m','Harness-Work-Orders: WO-HAG-009, WO-HAG-011'],cwd=R)
assert not git('status','--porcelain')
(O/'candidate-43.json').write_bytes((json.dumps({'commit':git('rev-parse','HEAD'),'base':'55caaada508495bea7d97effd27644d1ce8373da'},indent=2)+'\n').encode())
print(git('rev-parse','HEAD'))
