+++
id = "VER-P3-901"
type = "verification"
title = "Verify greeting returns exact rehearsal string"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verify greeting returns exact rehearsal string

Alternative verification contract for REQ-P3-900. This contract defines an independent check that `greeting()` returns the exact string required by the acceptance criteria.

## Independence

The expected value `Hello rehearsal` is fixed by REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. It is not derived from candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import and call `greeting()` from `src/greeting.py`; compare the return value to the independently fixed expected string. | The return value equals `Hello rehearsal` exactly, with no leading or trailing whitespace and no case variation. |

## Acceptance scenarios

1. Import `greeting` from `src/greeting.py`.
2. Call `greeting()` with no arguments.
3. Assert that the return value is the Python string `'Hello rehearsal'`.

Platform: Python 3.11 or later.
Evaluator: se_harness 0.22.1 (archive SHA-256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`).

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-assertion.json`. The evidence file records the actual return value, the expected value, the comparison result, and the source file digest at the time of execution.

## Residual uncertainty

This contract verifies only the return value of `greeting()`. It does not verify import-time side effects, function signature stability, or thread safety. Those concerns are outside the scope of REQ-P3-900.
