# Native report — INT-P3-001

## Content readiness

**Complete.** The intent's required content is supported and reviewed against the intent checklist:

1. **Problem, who it affects, outcome:** Stated. The fixture `greeting()` in `src/greeting.py` lacks independent confirmation of its return value. The test operator is affected. The outcome is establishing that the return value matches `Hello rehearsal`.
2. **Smallest useful outcome:** Confirming the greeting return value. No broader scope claimed.
3. **Success measure and baseline:** One measure with an honest `not measured` baseline. The "Observed" column names retained assertion evidence in the lifecycle-pilot domain. For this synthetic rehearsal, no operational observation outside the engineering domain applies; this is the most accurate description. A real intent would require discussion with the owner about operational observability.
4. **Scope limits:** Three bullets in "Not this" exclude fixture changes, artifact approval/release, and real product decisions.

No unsupported claims. Protected content (`Hello rehearsal`, `greeting()`, `src/greeting.py`) preserved byte-identical. Planned checks described as planned, not as executed.

## Saved state

| Field | Value |
| --- | --- |
| Artifact | INT-P3-001 |
| Revision | `sha256:9bc47ed5604366d9358bda414af1ad98b00ed150a1228b870db06e9aa5b4cc4b` |
| Document SHA-256 | `73826659ecc16426238d6c2fe91fa5479985458569e13dc0c44bf6cf898231df` |
| Context | `214c196e-df76-48ac-a334-43ba74332d70` version 2 |
| Project version | 4 |
| Domain | lifecycle-pilot |
| Status | draft |
| Create receipt | `c7a9dbc3-d3f5-478f-a0ed-2ec560547b42` |
| Revise receipt | `e1cc4331-ffcf-41ee-91bd-4f4a70c279b3` |
| Authored document | `work/INT-P3-001.md` |
| Create evidence | `work/create-intent-001.evidence/` |
| Revise evidence | `work/revise-intent-001.evidence/` |
| Read-back evidence | `work/read-intent-001.evidence/` |
| Read-back document | `work/read-intent-001.evidence/1-document-1.md` |

## Validation and review

**Evaluator draft validation (revise-artifact):**
- `admissible: true`
- `errors: []`
- `incomplete: []`
- `content_review: not_assessed` (evaluator did not assess content)
- One background advisory: `W-AUT-022` on SPEC-P3-900 (pre-existing imported artifact, unrelated to this intent)

**Content review (agent-performed):**
- All template placeholders replaced with supported content.
- Title, outcome, and body use consistent terminology.
- Problem section derives from inspected fixture source (`src/greeting.py` returns `'Hello rehearsal'`).
- Success measure baseline is `not measured` (honest; no prior confirmation exists).
- One content finding: the "Observed" column describes retained evidence from an assertion, which is an engineering observation rather than a purely operational one. For a synthetic rehearsal fixture, this is the most accurate description; no operational context exists to observe. For a real intent, the owner should confirm an operational observation.
- No duplicate checks, no constraints absent from definitions, no unsupported claims.

**Missing inputs or uncertain effects:** None. All inputs available and inspected.

## Observations

Link: `observations` command output at 11 native calls, 0 failures. No denied or failed commands.
