+++
id = "VER-P3-001"
type = "verification"
title = "Alternative fixture greeting assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative fixture greeting assertion

Synthetic rehearsal input. This is not a real human decision.

## Independence

The expected string `Hello rehearsal` derives from the acceptance criteria stated in REQ-P3-900 and the contract in SPEC-P3-900 rule P3-GREET-900. The expected value is fixed before any candidate output is observed.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import `greeting` from `src/greeting.py` and compare return value to the independently fixed expected string | `greeting()` returns exactly the string `Hello rehearsal` with no leading or trailing whitespace, no other return type, and no side effects observed |

## Acceptance scenarios

Call `greeting()` once. Assert the return value equals `Hello rehearsal`. A mismatch, exception, or non-string return is a failure.

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-result.json`. The evidence file records the actual return value, the expected value, the comparison outcome, the evaluator version (0.22.1), and the platform (linux/amd64, Python 3.13).

## Residual uncertainty

This contract checks only the exact string match for the normal call path. It does not verify behavior under import failure, module reload, or concurrent access, because REQ-P3-900 specifies only the single return value.
