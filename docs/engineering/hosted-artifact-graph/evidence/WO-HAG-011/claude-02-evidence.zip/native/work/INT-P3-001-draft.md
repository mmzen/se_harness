+++
id = "INT-P3-001"
type = "intent"
title = "Establish that greeting() returns the exact rehearsal string"
status = "draft"
owners = ["test-owner"]
created = "2026-10-08"
updated = "2026-10-08"
outcome = "An operator can confirm that the fixture greeting() returns exactly `Hello rehearsal`."

[relations]
+++

# Intent: Establish that greeting() returns the exact rehearsal string

Before approval, apply the shared design principle and `intent` checklist in
`docs/engineering/ARTIFACT_AUTHORING.md`.

## In plain words

The project needs a verified record that the `greeting()` function in `src/greeting.py` returns exactly the string `Hello rehearsal`. This intent establishes the purpose behind that verification.

## Problem

There is no formal definition establishing that the existing fixture's `greeting()` function must return exactly `Hello rehearsal`. Without an accepted intent, an operator cannot trace verification of this behavior back to an agreed purpose. The function exists and returns the expected value, but the obligation to confirm this is not captured in the harness.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| greeting() return value confirmed as `Hello rehearsal` | not measured | Verified through harness assertion | Operator inspection of the assert-greeting evidence, on each verification |

## Not this

- Changing the return value of `greeting()` or any source code.
- Adding new functions or modifying the fixture behavior.
- Lifecycle decisions, approvals, or release authority.
- Verification of any behavior other than the exact `greeting()` return value.
- Performance, scalability, or operational monitoring of the greeting function.
