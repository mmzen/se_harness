"""Bounded WO-HAG-011 guidance correction and qualification preparation."""
import hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
import hag_efficiency_plan as p
W,R,D=p.W,p.R,p.D; O=W/'hag-c45';p.O=O;O.mkdir(exist_ok=True)
H=Path('C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe')
E=D/'evidence/WO-HAG-011/correction45'
changed='plugins/verity-plane/common/skills/change/references/hosted-drafts.md'
base='11a43bfe01e75149f4b6a7fd33e10f9c511182df'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
def put(f,v):
 assert not f.exists(),f
 f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
mode=sys.argv[1]
if mode=='checks':
 scratch=Path(tempfile.mkdtemp(prefix='hag45-'));os.environ.update(TEMP=str(scratch),TMP=str(scratch));tempfile.tempdir=str(scratch)
 os.environ.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true')
 commands=[('source',[H,'-X','utf8','-B','scripts/run_tests.py']),('distribution',[H,'-X','utf8','-B','scripts/validate_release_distributions.py','--root','.']),('smoke',[H,'-X','utf8','-B','-m','se_harness','--help'])]
 for label,args in commands:
  p.run(label,args,cwd=R);x=load(O/(label+'.json'));print(label,x['exit'],round(x['elapsed_seconds'],1),x['stdout'][-500:],x['stderr'][-500:],flush=True)
elif mode=='governor':
 args=['check',R,'--artifact','WO-HAG-011','--checkpoint','scope','--changes-complete']
 for path in [changed,*[(E/n).relative_to(R).as_posix() for n in ['review.md','checks.zip','inventory.json']]]:args+=['--changed-path',path]
 v=p.gov('scope',*args,'--json');assert v['compliance']['status']=='pass';print('Scope pass',flush=True)
 v=p.gov('preflight','preflight',R,'--work-order','WO-HAG-011','--phase','review','--json');assert v['ready'];print('Review preflight pass',flush=True)
 v=p.gov('validation','validate',R,'--json');assert v['error_count']==0;print('Validation',v['artifact_count'],v['warning_count'],flush=True)
elif mode=='commit':
 assert git('rev-parse','HEAD')==base and git('diff','--name-only').splitlines()==[changed]
 names=['source','distribution','smoke','scope','preflight','validation'];assert all(load(O/(x+'.json'))['exit']==0 for x in names)
 old=subprocess.check_output(['git','show',base+':'+changed],cwd=R);new=(R/changed).read_bytes()
 review=f'''# Review: correct known draft omissions and report saved facts

WO-HAG-011 remains in progress. This correction changes only the existing
hosted-drafts.md reference under its approved instruction scope.

C44's two failed Claude positive cases remain in [their assessment](../focused44-result/assessment.md).
One omitted a supplied evaluator version and stopped, then confused response
metadata and read results with artifact content and accepted mutations. Another
gave contradictory readiness conclusions and invented a required type assertion.

The guidance now distinguishes a missing input from an omission that can be
corrected from confirmed inputs. It requires reviewing the corrected saved
revision, tracing pass conditions to definitions, and reporting one readiness
conclusion with reads and mutations separated. It supplies no test answer,
operation sequence, new required check or automatic content verdict.

This replaces existing paragraphs in the canonical plugin reference rather than
adding another checklist or tool. The file changes from {len(old)} to {len(new)}
bytes. Existing package/source checks cover packaging; native qualification must
assess whether the revised guidance corrects the observed behavior. No test that
merely asserts the new wording was added.

Source tests, distribution validation, CLI smoke, released validation, scope and
review preflight passed; exact commands and outputs are in checks.zip. Preparation
used process-local Git long-path support and a new temporary directory. Global
settings are unchanged. No native pass is claimed at this preparation commit.

Next: package the exact candidate, verify source/component identities, run the
unchanged missing-input cases, then the required fresh positive sequence. Keep
the Opus4.6 drafting contract separate from Opus5.5 lifecycle qualification.
Efficiency goals are reported separately; they introduce no lifecycle gate.

VREC-HAG-006 and its bound candidate/evidence remain unchanged. That prior
verification covers WO-HAG-009/010 at its recorded candidate; it does not verify
this correction. No merge, release, host update or risk acceptance is granted.
'''
 E.mkdir(exist_ok=False);put(E/'review.md',review)
 files={x+'.json':(O/(x+'.json')).read_bytes() for x in names};files['observer.py']=Path(__file__).read_bytes()
 with zipfile.ZipFile(E/'checks.zip','x',zipfile.ZIP_DEFLATED) as z:
  for n,b in files.items():z.writestr(n,b)
 put(E/'inventory.json',{'archive':'checks.zip','sha256':sha((E/'checks.zip').read_bytes()),'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in files.items()]})
 paths=[changed,*[(E/n).relative_to(R).as_posix() for n in ['review.md','checks.zip','inventory.json']]]
 assert sorted(git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines())==sorted(paths)
 p.run('stage',['git','add','--',*paths],cwd=R);p.run('diff-check',['git','diff','--cached','--check'],cwd=R)
 p.run('commit',['git','commit','-m','Correct known draft omissions before reporting readiness','-m','Harness-Work-Order: WO-HAG-011'],cwd=R)
 assert not git('status','--porcelain');put(O/'candidate-45.json',{'commit':git('rev-parse','HEAD'),'base':base});print(git('rev-parse','HEAD'))
elif mode=='build':
 c=load(O/'candidate-45.json')['commit'];assert git('rev-parse','HEAD')==c and not git('status','--porcelain')
 p.run('client-build',[H,'-X','utf8','-B','-m','repository_tools.release_build','replay','--repository',R,'--commit',c,'--version','0.22.2','--output-directory',O/'build45','--result',O/'build45-replay.json'],cwd=R);print('Client built',flush=True)
 wheel=W/'hag-phase3-execution-20261006/package02/candidate-source/server/vendor/se_harness-0.22.1-py3-none-any.whl';assert sha(wheel.read_bytes())=='cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053'
 p.run('package',[H,'-X','utf8','-B',R/'server/scripts/qualify.py','prepare','--repository',R,'--output',O/'package45','--client-wheel',O/'build45/se_harness-0.22.2-py3-none-any.whl','--client-replay',O/'build45-replay.json','--evaluator-wheel',wheel,'--image','harness-hag:native-draft45','--phase3']);print('Package built',flush=True)
 p.run('client-env',[H,'-m','venv',O/'client45']);p.run('client-install',[O/'client45/Scripts/python.exe','-I','-m','pip','install','--no-deps',O/'build45/se_harness-0.22.2-py3-none-any.whl']);print('Client installed',flush=True)
