+++
id = "VER-P3-001"
type = "verification"
title = "Assert the fixture greeting independently"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert the fixture greeting independently

## Independence

The expected value `Hello rehearsal` derives from REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. No candidate output or implementation detail informs the expected result.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import `greeting` from `src/greeting.py` and compare the return value to the fixed expected string | `greeting()` returns exactly `Hello rehearsal` on Python 3.13 / linux-amd64, evaluated by se_harness 0.22.1 |

## Acceptance scenarios

1. Import the `greeting` function from `src/greeting.py` at the exact candidate commit.
2. Call `greeting()` with no arguments.
3. Assert that the return value equals the string `Hello rehearsal` using Python string equality (`==`).
4. Record the returned value, the expected value, and the comparison outcome.

Platform: Python 3.13 on linux/amd64.
Evaluator: se_harness 0.22.1.

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-assertion.json`. The record contains the called function, returned value, expected value, and pass/fail outcome.

## Residual uncertainty

None identified. The check is a direct string-equality assertion against a fixed expected value derived from the requirement.
