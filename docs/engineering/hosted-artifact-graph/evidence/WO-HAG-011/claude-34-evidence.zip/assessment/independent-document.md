+++
id = "VER-P3-901"
type = "verification"
title = "Verify exact rehearsal greeting return value"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verify exact rehearsal greeting return value

## Independence

The expected value `Hello rehearsal` is fixed by the acceptance criteria in REQ-P3-900. The check compares the actual return value of `greeting()` against this independently stated string. The expected result does not depend on candidate output or implementation inspection.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Call `greeting()` and compare the return value to the expected string | `greeting()` returns exactly the string `Hello rehearsal` |

## Acceptance scenarios

**Scenario: greeting returns the exact rehearsal string**

1. Import `greeting` from `src/greeting.py`.
2. Call `greeting()` with no arguments.
3. Assert that the return value equals the string `Hello rehearsal` (exact match, no leading or trailing whitespace, no case variation).

Platform: Python 3.11 or later.
Evaluator: se_harness 0.22.1.

## Evidence retention

Retain the assertion result (actual return value, expected value, pass/fail outcome) in `docs/engineering/lifecycle-pilot/evidence/` under the executing work order's directory.

## Residual uncertainty

This contract verifies only the return value of `greeting()`. It does not verify side effects, performance, or thread safety, as REQ-P3-900 constrains only the return value.
