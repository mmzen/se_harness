## Selected instruction entry

The following complete canonical sections are already supplied in this context. Apply them before commentary and actions. Reuse them while unchanged and retained; read additional references only when their conditions apply. After compaction, recover this entry from task.md. Explicit task inputs, not automatic startup-delivery evidence. Pointers are not artifact content reads.

Source: {"resource": "docs/engineering/harness/COMMUNICATION.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-inputs-20261010\\codex-91\\native\\inputs\\released-resources\\docs\\engineering\\harness\\COMMUNICATION.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "2aa70bc7959c3a1075adf9fd163225a6a8d92216cf8b054cd677fe94e8ea15cf"}

# Communication

## Purpose and claim

This policy controls eligible English prose written by agents for operators and
technical artifacts. It uses selected clarity principles based on ASD-STE100.
It is not ASD-STE100 compliance, certification, approval, or endorsement.

An agent MUST NOT download, search for, bundle, reproduce, parse, or attempt to
strictly implement ASD-STE100 or a controlled dictionary. The installed policy
is complete for its declared purpose.

## Eligible prose

Eligible prose is agent-authored English explanation that is not protected
content (see next section). For eligible prose, the agent SHOULD:

- use one stable term for one concept;
- define an uncommon project term before relying on it;
- identify the responsible actor when responsibility matters;
- state conditions, actions, and results directly;
- prefer active voice when it identifies responsibility;
- keep each sentence focused on one principal action;
- avoid ambiguous pronouns, decorative synonyms, hidden negation, vague
  references, and unnecessary introductions; and
- use a list or table when it clarifies parallel conditions, mappings, or
  ordered steps.

Sentence length is a review signal. It is not a conformance threshold and does
not justify removing necessary technical detail.

## Protected content

Exact protected content MUST remain byte-identical. It includes:

- code and inline code;
- commands, paths, identifiers, hashes, version strings, URLs, schemas, and
  field names;
- JSON, TOML, YAML, XML, and other machine-readable data;
- logs, diagnostics, evidence, evaluator output, and canonical restitution
  blocks;
- quotations; and
- operator-supplied text that is presented as supplied text.

Protected content MUST NOT be automatically paraphrased. It includes BCP 14 obligations, 
requirement statements, lifecycle and decision meanings, safety or legal qualifications, 
acceptance thresholds, formulas, and established terminology.

Source: {"resource": "docs/engineering/harness/DRAFT_DEFINITIONS.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-inputs-20261010\\codex-91\\native\\inputs\\released-resources\\docs\\engineering\\harness\\DRAFT_DEFINITIONS.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "a2041b84342c2b2e4b5ec0f26e3a70702a894c57d9810855cfe514881e5a0c28"}

## Read this when

The selected change lacks a definition, verification, release or operating contract.


## Before this action

Before choosing a type, read [ARTIFACTS.md#artifact-types](ARTIFACTS.md#artifact-types) and [ARTIFACTS.md#artifact-locations](ARTIFACTS.md#artifact-locations). Before links, read [DEFINITION_LINKS.md#links-between-definitions](DEFINITION_LINKS.md#links-between-definitions). Before authoring, read [../ARTIFACT_AUTHORING.md#design-simplicity](../ARTIFACT_AUTHORING.md#design-simplicity) and the exact type checklist linked in this file.


### Draft any missing definitions

**Inputs:** The confirmed outcome, scope limits, and missing-definition list
from [Identify the existing artifacts that apply to the change](DEFINE_CHANGE.md#identify-the-existing-artifacts-that-apply-to-the-change).

**Output:**

- **Formal artifacts:** New drafts of the missing intents (INT), capabilities
  (CAP), requirements (REQ), specifications (SPEC), applicable architectures
  (ARCH), and required architecture decisions (ADR). None if no definitions
  are missing.
- **Domain files and directories:** The structure reported by
  `scaffold-domain`, created only if the selected domain is missing.
- **Transient working material:** The inventory updated with generated IDs
  and file paths. Retain it under the same conditions as [Describe the intended outcome](DEFINE_CHANGE.md#describe-the-intended-outcome).

**Actions:**

1. Read `Design simplicity` in `docs/engineering/ARTIFACT_AUTHORING.md`.
2. Select the domain for each missing definition from the inventory. For a
   missing domain, preview its creation with the domain commands below.
3. Inspect the proposed domain paths. Resolve any reported conflict before
   running the domain creation command.
4. Select the first missing artifact type from the table below. Skip types
   already covered by unchanged existing artifacts.
5. Run the artifact preview command. Inspect its type, destination path, and
   `allocated_id`.
6. Run the artifact creation command with that exact ID. If a conflict occurs,
   repeat the preview; do not overwrite an existing record.
7. Open the returned file. Complete its title, owners, dates, content, and
   declared links. Replace all template placeholders.
8. Apply `### Checklist` under the matching `## TYPE` heading in
   `docs/engineering/ARTIFACT_AUTHORING.md`.
9. Read the completed draft. Record its ID and path in the inventory.
10. Repeat actions 4–9 for each remaining missing definition.

| Order | Artifact | TYPE | Content | Declared links |
| --- | --- | --- | --- | --- |
| 1 | Intent (INT) | `intent` | Problem, intended outcome, affected users, and scope limits. | None required here. |
| 2 | Capability (CAP) | `capability` | The ability needed to achieve the outcome. | `derives_from` → intent (INT). |
| 3 | Requirement (REQ) | `requirement` | Observable behavior, conditions, and acceptance criteria. | `derives_from` → capability (CAP). |
| 4 | Specification (SPEC) | `specification` | Detailed behavior, constraints, failure behavior, and checkable examples. | `specifies` → requirement (REQ). |
| 5 | Architecture (ARCH), when applicable | `architecture` | Components, boundaries, and the architecture decision assessment. | `addresses` → requirement (REQ); `conforms_to` → specification (SPEC). |
| 6 | Architecture decision (ADR), when required | `adr` | Context, alternatives, chosen design, and consequences. | `decides` → architecture (ARCH). |

Record an unresolved design choice for [Record unresolved decisions (DEC)](RISKS_AND_DECISIONS.md#record-unresolved-decisions-dec). Do not present a recommendation
as an agreed architecture decision (ADR). Prepare verification contracts (VER)
in [Define how the result will be verified](DRAFT_DEFINITIONS.md#define-how-the-result-will-be-verified).

**Harness commands:**

For a missing domain, use the first command in action 2 and the second only
after reviewing the preview in action 3:

```text
harnessctl scaffold-domain REPO --domain DOMAIN --dry-run --json
harnessctl scaffold-domain REPO --domain DOMAIN --json
```

For each missing artifact, use this **creation sequence** in actions 5–6.
Replace `TYPE` with the table value. Replace `ARTIFACT-ID` in the second
command with the first command's `allocated_id`:

```text
harnessctl create-artifact REPO --domain DOMAIN --type TYPE --dry-run --json
harnessctl create-artifact REPO --domain DOMAIN --type TYPE --id ARTIFACT-ID --json
```

The preview writes nothing and does not reserve an ID. Creation writes one
incomplete template and returns its path. Content completion is a separate
editing action. The JSON output does not contain the authoring checklist.

**Completion:** Each missing definition has a completed draft with an ID and
path. Unresolved choices are identified. If no definitions are missing,
record `None needed` in the transient inventory.

**Later use:** These definitions supply the verification contracts (VER) in
[Define how the result will be verified](DRAFT_DEFINITIONS.md#define-how-the-result-will-be-verified) and the governing links in work orders (WO) in [Prepare work orders (WO) linking the definitions, scope, planned work, and verification requirements](DRAFT_WORK_ORDERS.md#prepare-work-orders-wo-linking-the-definitions-scope-planned-work-and-verification-requirements). Their acceptance
is handled in the authorization process.


Source: {"resource": "docs/engineering/harness/ARTIFACTS.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-inputs-20261010\\codex-91\\native\\inputs\\released-resources\\docs\\engineering\\harness\\ARTIFACTS.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "2fa84648afedc03f3b811cb0e61d77ee1a1d52421ba3b3fa3eb435c4abd6eb89"}

## Artifact types

“Required” means the selected work needs coverage of that type. It does not
mean every change must create a new file. Reuse an existing active artifact
when its accepted meaning and scope still cover the work. Create a conditional
artifact only when its condition applies.

For an existing selected work order (WO), get its current state and next
action with:

```text
harnessctl check REPO --artifact WO-ID --json
```

Before implementation, check whether that work order (WO) and its linked
definitions are eligible to start:

```text
harnessctl preflight REPO --work-order WO-ID --phase start --json
```

The first command reports lifecycle context without evaluating checkpoint
gates. The second evaluates start readiness, including the states and coverage
of the selected definitions. Neither command approves or starts work.
Here, `REPO` is the absolute repository path and `WO-ID` is the actual ID of
the selected work order (WO). Use the repository's selected released evaluator.

| Type                  | ID prefix | Purpose                                                                                                                                                                      | When needed                                                                                                                                              |
|-----------------------|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|
| `intent`              | `INT-`    | States the problem, intended outcome, and limits of responsibility.                                                                                                          | The work needs an accepted purpose. Reuse an intent (INT) when that purpose still applies.                                                               |
| `capability`          | `CAP-`    | Describes an ability that a human or agent should have.                                                                                                                      | Requirements (REQ) need a link to the capability (CAP) they support.                                                                                     |
| `requirement`         | `REQ-`    | States required behavior or a constraint, with a condition for acceptance.                                                                                                   | The change creates or changes an obligation. Reuse a requirement (REQ) only if its meaning stays unchanged.                                              |
| `specification`       | `SPEC-`   | Defines the detailed behavior, interfaces, constraints, and rejection conditions.                                                                                            | Each requirement (REQ) selected for implementation needs specification (SPEC) coverage.                                                                  |
| `architecture`        | `ARCH-`   | Defines system structure and boundaries needed to meet significant requirements (REQ).                                                                                       | An active architecture (ARCH) directly addresses a requirement (REQ) selected by the work order (WO).                                                    |
| `adr`                 | `ADR-`    | Records an architecture decision (ADR), the alternatives, and their consequences.                                                                                            | An applicable architecture (ARCH) declares that a significant decision is required.                                                                      |
| `verification`        | `VER-`    | Defines how requirements (REQ) will be checked and what counts as a pass.                                                                                                    | Each selected requirement (REQ) needs verification coverage. This is the verification contract (VER), not a test result.                                 |
| `work_order`          | `WO-`     | Defines the bounded work to execute and its governing artifacts. Approval grants work authority.                                                                             | Before execution. One work order (WO) may cover several requirements (REQ). Completed scope does not authorize later work.                               |
| `verification_record` | `VREC-`   | Binds work orders (WO), verification contracts (VER), evidence, and one exact candidate commit for assessment.                                                               | When verification tied to a commit is required. One record may cover several work orders (WO) at the same commit.                                        |
| `release_contract`    | `REL-`    | Defines permitted release scope, gates, rollback conditions, and authority limits.                                                                                           | When a release record (RLS) is proposed.                                                                                                                 |
| `release_record`      | `RLS-`    | Records preparation and the later release decision for verified work at one exact commit.                                                                                    | When a formal release is proposed. Preparing the record does not release the work.                                                                       |
| `decision`            | `DEC-`    | Records a question, options, recommendation, decision maker, affected artifacts, and the eventual answer. It can also record a deviation from one specification (SPEC) rule. | A question blocks a transition, affects more than one artifact, or must remain recorded after approval; or work cannot meet a specification (SPEC) rule. |
| `risk`                | `RISK-`   | Records a threat, an owner, and a next action. Scoring and categories are optional.                                                                                          | A concern needs follow-up. A separate decision (DEC) is used when the concern must block work.                                                           |
| `operating_contract`  | `OPS-`    | Defines continuing service, support, monitoring, or operational assurance obligations.                                                                                       | Ongoing operational commitments apply. Omitting the record does not prove those commitments have been met.                                               |

Code, tests, acceptance scenarios, evidence files, commits, dashboards, tickets,
and conversations are not additional formal artifact types. They may support
or be referenced by formal artifacts but do not grant authority by themselves.


## Artifact locations

New formal artifacts use these directories below
`docs/engineering/DOMAIN/`. `DOMAIN` is the selected domain name. These paths
describe storage, not authority; the artifact ID, metadata, and typed links
remain authoritative. Use the supported authoring command to obtain the actual
path. Do not move existing records merely to match this table.

| Artifact | TYPE | Directory |
| --- | --- | --- |
| Intent (INT) | `intent` | `intent/` |
| Capability (CAP) | `capability` | `capabilities/` |
| Requirement (REQ) | `requirement` | `requirements/` |
| Specification (SPEC) | `specification` | `specifications/` |
| Architecture (ARCH) | `architecture` | `architecture/` |
| Architecture decision (ADR) | `adr` | `architecture/adr/` |
| Verification contract (VER) | `verification` | `verification/` |
| Work order (WO) | `work_order` | `work-orders/` |
| Verification record (VREC) | `verification_record` | `verification-records/` |
| Release contract (REL) | `release_contract` | `release/` |
| Release record (RLS) | `release_record` | `releases/` |
| Operating contract (OPS) | `operating_contract` | `operations/` |
| Decision (DEC) | `decision` | `decisions/` |
| Risk (RISK) | `risk` | `risks/` |

The same domain has `evidence/` for retained work-order evidence and
`acceptance/` for acceptance scenarios. These are supporting files, not new
formal artifact types. Legacy flat artifact locations remain readable and
MUST NOT be moved by an upgrade without separate authority.

Templates under `docs/engineering/templates/` are authoring assets. They are
excluded from active-artifact validation and grant no authority. Use
`capture-verification` and `prepare-release` for commit-bound VREC and RLS
instances; an edited template is not a substitute for their derived evidence.

Source: {"resource": "docs/engineering/harness/DEFINITION_LINKS.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-inputs-20261010\\codex-91\\native\\inputs\\released-resources\\docs\\engineering\\harness\\DEFINITION_LINKS.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "75b0c06f90fbb219fc31684a1a2d97987215dbada20e335656e45a57532c3010"}

## Links between definitions

An arrow points from the artifact that records the link to the artifact it
references. These links describe meaning and coverage, not execution order.

Repository validation, draft validation and work-order preflight share the
declared source/relation/target types. A supplied undeclared relation or a target
of the wrong type is invalid even when no work order selects the artifact.
Preflight still evaluates readiness only for its selected governing chain.
The read-only draft query permits specific unfinished authoring slots; ordinary
validation and approval retain their completeness requirements.

```mermaid
flowchart LR
    CAP["Capability (CAP)"] -->|derives_from| INT["Intent (INT)"]
    REQ["Requirement (REQ)"] -->|derives_from| CAP
    SPEC["Specification (SPEC)"] -->|specifies| REQ
    VER["Verification contract (VER)"] -->|verifies| REQ
    ARCH["Architecture (ARCH)"] -->|addresses| REQ
    ARCH -->|conforms_to| SPEC
    ADR["Architecture decision (ADR)"] -->|decides| ARCH
```

| Source → target | Relation | Meaning and coverage |
| --- | --- | --- |
| Capability (CAP) → Intent (INT) | `derives_from` | Each active capability (CAP) names one or more active intents (INT). |
| Requirement (REQ) → Capability (CAP) | `derives_from` | Each active requirement (REQ) names one or more active capabilities (CAP). |
| Specification (SPEC) → Requirement (REQ) | `specifies` | Each requirement (REQ) selected by a work order (WO) needs one or more selected active specifications (SPEC). |
| Architecture (ARCH) → Requirement (REQ) | `addresses` | The architecture (ARCH) names every requirement (REQ) that materially drives its structure. |
| Architecture (ARCH) → Specification (SPEC) | `conforms_to` | For each addressed requirement (REQ), the selected architecture (ARCH) names at least one selected specification (SPEC) covering it. |
| Architecture decision (ADR) → Architecture (ARCH) | `decides` | Each selected architecture (ARCH) that requires a design decision has at least one selected active architecture decision (ADR). |
| Verification contract (VER) → Requirement (REQ) | `verifies` | Each selected requirement (REQ) has one or more selected active verification contracts (VER). |


Source: {"resource": "docs/engineering/ARTIFACT_AUTHORING.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-inputs-20261010\\codex-91\\native\\inputs\\released-resources\\docs\\engineering\\ARTIFACT_AUTHORING.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "71de2cc92a470e2da25d525e3ad002b77faedb6ef0e69e2fa476a2fa4cb78ff5"}

## Design simplicity

For unfinished work, `harnessctl validate-draft REPO --artifact ID --json`
reports whether one supported draft has an admissible shape. Only exact values
at the same type and field in this evaluator's canonical template, and missing
or empty required authoring links, can be reported as incomplete. Invalid
identity, dates, metadata shapes, actual endpoints, lifecycle history and
disposition are errors. A missing non-template ID is an error. Background
findings remain visible; this result makes no whole-repository validity claim.
Complete the authoring checklist and pass ordinary approval gates before
requesting approval. Draft admission grants no authority to write or approve.

Choose the least complex design that satisfies the agreed requirements and
constraints. Justify material added complexity by the need it serves and why
a simpler approach is insufficient. Consider the effort to understand, build,
test, operate and change the whole solution. Defer speculative needs. Review
both the necessity of the specified behavior and the simplicity of its
implementation. Preserve correctness and the project's required quality and
safety properties.

Start from the smallest complete solution. Each project supplies its agreed
users, scale, operating conditions and quality constraints. Agreed future needs
can matter; imagined flexibility alone is insufficient. Credible risk analysis
can justify prevention before an incident. Fewer lines, shorter specifications
or fewer tests do not establish simplicity; moving work to users, operations
or dependencies also has a cost.

Apply the relevant questions below before definition approval and during design
and implementation review. Return unjustified obligations or design complexity
for revision through the existing decision process. Explain material choices
in the existing specification, design or review: the need, why a simpler option
is insufficient and the added cost. Scale the explanation to the decision; a
small choice may need one sentence, a significant design may use its existing
architecture decision. Trivial changes need no separate comparison document.

These are human review standards. They introduce no separate KISS artifact,
mandatory score, receipt, automated simplicity gate or additional approval.


## intent

### Checklist

- Explain the present problem, who it affects, and the outcome wanted.
- What is the smallest useful outcome, and which needs and constraints are actually agreed?
- Say how the owner will know the change helped; an honest baseline may be `not measured`.
- State the important scope limits. Create a new intent when the desired outcome changes.


## Existing artifact pointers

These records are available for inspection. Their presence does not establish that they cover this request. Select and read the applicable records before making content claims.

[{"id": "CAP-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-inputs-20261010\\codex-91\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\capabilities\\CAP-P3-900.md", "sha256": "f00af6febc1d62752cab0364e3f4e80e227438f494d98d9f02a9a5c7fdc30bc0"}, {"id": "INT-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-inputs-20261010\\codex-91\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\intent\\INT-P3-900.md", "sha256": "20649db79738fdf649578286679d6fe05491e460c5a41e68ba0ed3161c47e7ed"}, {"id": "REL-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-inputs-20261010\\codex-91\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\release\\REL-P3-900.md", "sha256": "a7cc92f770027bae2ffbf987a1a83eb36bd5e012632e1db07cf5f377f6b12935"}, {"id": "REQ-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-inputs-20261010\\codex-91\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\requirements\\REQ-P3-900.md", "sha256": "99028b8605edfd6e85d3cbfb0ee5243f43df69059e314ed1f0b9ab0bde0bbba4"}, {"id": "SPEC-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-inputs-20261010\\codex-91\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\specifications\\SPEC-P3-900.md", "sha256": "0904f98bddc075f26c87e2e2ce603e3d74a497b8df85e1093bf3b0f5f35a45f9"}, {"id": "VER-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-inputs-20261010\\codex-91\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\verification\\VER-P3-900.md", "sha256": "9c975ff911c736f30dab7688df8f136e66eefd81eebc09362d0345cef813e8b4"}, {"id": "WO-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-efficiency-inputs-20261010\\codex-91\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\work-orders\\WO-P3-900.md", "sha256": "98ac1fa85021ac8a6f4d7a74973e2148dac97aa6ca69064d847818efc3771332"}]
Before your first explanation, apply the supplied sections and read only the applicable plugin instructions and prerequisites still missing from context. Use the existing file tools below. This explicit test setup does not establish automatic startup instruction delivery.

# Focused hosted drafting diagnostic

You are Codex under the approved WO-HAG-011 efficiency comparison. Work
independently in the fresh private project selected by `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-efficiency-inputs-20261010\codex-91\native\selection.json`.
This run tests draft preparation only. Git remains authoritative for real work.

## Requested outcome

Prepare exactly one new intent draft for an operator who needs to establish that
the existing fixture's greeting() returns exactly `Hello rehearsal`. Inspect the
fixture and author the intent in the selected private service. Keep it as draft
and report its actual authoring findings. Use domain lifecycle-pilot and synthetic
owner test-owner. Imported -900 records are immutable history. Do not create other
artifacts, approve anything, start work, freeze a baseline or exercise lifecycle
decisions. Stop when this one draft is complete and its current findings retained,
or report the exact blocker. This is a focused diagnostic, not a full package.

## Entry and tools

Read `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-efficiency-inputs-20261010\codex-91\native\selection.json`. Begin with the candidate plugin's normal
verity-plane:setup Skill for this explicit hosted selection, then follow its
current-task routes. The client is installed. Do not install software or activate
a checkout. The selected released_resources directory contains the exact 0.22.1
procedures. Reuse canonical sections already delivered in this task.

The selection's tool_index is the single command and file-discovery reference.
Read it before choosing syntax. Read only applicable procedure sections and
the typed inputs (or raw schema) for the operation you select.

Use native file tools or the tool index's bounded file-read operation, and only
approved_shell_argv_prefix for shell calls,
one helper call per invocation. No scripts, wrappers, pipes, loops, direct client
calls or other shell commands. Normal permissions and hooks apply. Stop a denied
action; do not change permissions or try alternate routes.

Keep every draft, request, result and transient note under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-efficiency-inputs-20261010\codex-91\native\work`,
using absolute paths. That directory exists. Inputs are read-only. After
compaction, recover this task, selection and original evidence before acting.
Never print credentials, inspect auth stores, change account or host settings,
or read prior trials. Authentication is in the process environment. Helpers
perform no hidden workflow; choose requests from current inputs and instructions.

## Result

The runner captures calls, read paths, failures, timing and context. Do not copy
those observations into another JSON file or calculate final metrics during the
run. Use the observations command before an exhaustive failure claim; its
in-progress snapshot does not include subsequent calls.

Keep one short `native-report.md` in C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-efficiency-inputs-20261010\codex-91\native\work. Start with content readiness:
complete, incomplete or blocked, with the actual reason. Then record the saved
artifact/revision, current versions, exact document/result paths, template-validation
result, content-review findings and unresolved inputs or effects. A saved draft
and passed template checks do not establish content readiness. This is also the
transient progress note. Distinguish planned checks from executed checks.
Link original evidence instead of reproducing it. Do not write a separate
native-observations.json or read inventory. End with a brief result and the report
path. No complete NQ-01 through NQ-05 claim: lifecycle, MCP parity, reply recovery
and export are outside this focused diagnostic.


## Codex file discovery

If native Read is unavailable, use this existing approved helper prefix:

```json
["C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe", "-I", "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-efficiency-inputs-20261010/codex-91/native/inputs/native_call.py"]
```
Append `read-json ABSOLUTE_FILE` to read selection.json, or `read-text ABSOLUTE_FILE` for an inventoried input or work text file. Use native patch/file tools for writing. This host adaptation replaces only the unavailable native Read route; keep one helper call per invocation, normal permissions, the same selected task and all other restrictions. It supplies no workflow operation, request values, draft or decision.
