+++
id = "VER-P3-001"
type = "verification"
title = "Assert the fixture greeting by direct invocation"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert the fixture greeting by direct invocation

## Independence

The expected value `Hello rehearsal` is fixed by REQ-P3-900's acceptance criterion: "Calling greeting() returns exactly `Hello rehearsal`." The pass condition derives from that requirement, not from candidate output or implementation inspection.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Direct `assert-greeting` invocation on the native test host | Exit 0 with `exact greeting passed`; the retained record confirms equality to `Hello rehearsal` |

## Acceptance scenarios

Run the `assert-greeting` command through the approved shell prefix on the native test host. Before execution, confirm that the source digest of `src/greeting.py` matches the selected `greeting_sha256`. The command calls `greeting()` once and asserts that the returned string equals `Hello rehearsal`.

A passing result is exit code 0 with stdout containing `exact greeting passed`. A nonzero exit code is a failing assertion.

## Evidence retention

Retain the assertion record at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-greeting-assertion.json`. The record contains the exact command, working directory, exit status, stdout, stderr and elapsed time. Use the selected source manifest commit and `greeting_sha256` digest to identify the tested input.

## Residual uncertainty

The `assert-greeting` tool does not record a Python version or perform a separate type assertion. It runs on the native test host, not inside the Linux service runtime. These limits are acceptable for this synthetic rehearsal fixture where the requirement states only string equality.
