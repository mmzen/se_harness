# Hosted intent drafting diagnostic

Content readiness: blocked. No hosted mutation was attempted and no new intent draft was created. The request identifies a proposed adaptation but does not identify the new audience, its present problem, the needed improvement, or how the owner will observe success. These facts are required by the intent checklist. The intended outcome has not been confirmed.

Known inputs: the supplied source and all seven existing definitions were inspected in the delivered context. `INT-P3-900` serves a test operator conducting a disposable rehearsal; its success is an exact greeting and exported test evidence. `REQ-P3-900`, `SPEC-P3-900`, `VER-P3-900`, and `src/greeting.py` consistently specify or implement `Hello rehearsal`. These facts do not establish the needs of a new audience. Existing records remain immutable history.

Requested scope remains exactly one new intent draft in `lifecycle-pilot`, with synthetic owner `test-owner`. No fixture edits, other artifacts, approvals, work execution, baseline freezing, or lifecycle decisions are authorized by this task.

Questions for the requester:

- Who is the new audience, and when does it need the greeting?
- What problem does the existing greeting cause for that audience, and what improvement is wanted?
- How will the owner know the adaptation helped?

After those facts are supplied, present an intended-outcome statement for confirmation before dependent drafting. No purpose or success measure has been inferred from the requested engineering activity.

Saved state: selected project `5bf0f450-4976-40ba-b107-97683ed70cbb` at `http://127.0.0.1:26441`; observed project version `0`; evaluator `0.22.1`; client `0.22.2`. No import baseline, draft context, artifact ID, revision, or artifact document was created. The selection is a hosted test copy with `sandbox-projection` authority; Git remains authoritative for real work.

Validation and review:

| Case | Observed result and evidence | Limit |
| --- | --- | --- |
| Selection checks | Metadata identity matched the selected client wheel digest. [Status capture](selection-status.json) and its [exact result](selection-status.json.stdout.txt) report readiness, test-copy status, schema, protocols, and component identities matching the supplied combination. | Read-only selection checks confer no authoring or lifecycle decision. |
| Intent content review | Source inspection against the delivered `ARTIFACT_AUTHORING.md#intent` checklist found the missing inputs listed above. | No draft was submitted; no artifact evaluator findings or executed tests exist. |
| Attempt capture | [Observation snapshot](observations.json) reports no captured native failures or failed command records. | It reports `native_call_count_complete: false`; an exhaustive failure count remains unassessed. The snapshot excludes the later successful status-result read and this report write. |

The report is saved because capture completeness is not established. No denial or uncertain mutation effect was observed in the available results. No recovery, export, lifecycle rehearsal, or MCP parity claim is made.

The selected [hosted drafting instructions](../inputs/plugin/verity-plane/skills/change/references/hosted-drafts.md) require: “State a missing required fact as a question and stop dependent writing.” This explicit requirement blocks dependent intent drafting until the requester supplies the missing facts.
