+++
id = "VER-P3-001"
type = "verification"
title = "Alternative independent greeting assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative independent greeting assertion

## Independence

The expected value `Hello rehearsal` derives from REQ-P3-900 acceptance criteria
and SPEC-P3-900 rule P3-GREET-900. The check compares the fixture return value
against this independently fixed string. No candidate output or implementation
detail determines the expected result.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Exact greeting equality assertion using `assert-greeting`; evidence retained at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-assertion.json` | `greeting()` returns exactly `Hello rehearsal` on the native test host, evaluator 0.22.1 |

## Acceptance scenarios

Run the `assert-greeting` fixture tool on the native test host. The source
digest must match the selected `greeting_sha256` before execution. Exit 0 with
the message `exact greeting passed` constitutes a passing assertion.

A nonzero exit or a return value other than `Hello rehearsal` constitutes a
failure.

## Evidence retention

Retain the `assert-greeting` record at
`docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-assertion.json`.
The record contains the exact command, exit status, stdout, stderr and elapsed
time. Identify the tested input by the selected source manifest, commit and
`greeting_sha256` digest.

## Residual uncertainty

The `assert-greeting` tool does not assert the Python type of the return value.
A required type assertion remains a gap beyond the available tool.
