+++
id = "VER-P3-001"
type = "verification"
title = "Alternative plan to check the exact rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative plan to check the exact rehearsal greeting

Synthetic alternative authoring exercise for an independent reviewer. This contract plans verification of the existing fixture against REQ-P3-900. Existing VER-P3-900 already covers that requirement; this draft does not assert a coverage gap or replace that contract. All imported records remain unchanged. No test execution or lifecycle decision is recorded here.

## Independence

The expected result is exactly `Hello rehearsal`, derived from the acceptance criterion in REQ-P3-900 and corroborated by SPEC-P3-900 rule P3-GREET-900. The reviewer fixes this value before execution and does not derive it from fixture output. Source inspection shows `greeting()` returns the supplied literal; that inspection is not a test result. Synthetic owner `test-owner` identifies responsibility for this draft and does not authenticate a human decision.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Planned case GREET-EQUALITY-001; exact record path in Evidence retention | On the native Windows test host, the selected helper runs `greeting()` once through the selected client Python and asserts equality with `Hello rehearsal`; the retained command exits 0 and stdout contains `exact greeting passed`. |

## Acceptance scenarios

### GREET-EQUALITY-001 — planned equality assertion

Inputs: the selected `source/src/greeting.py` fixture, source manifest and selection. The fixture source commit is `5820415917e87b64d80bad2f7c39c6d18d692829`; the required greeting file SHA-256 is `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`. The helper requires this digest to match before execution. A mismatch stops the check.

Platform and test evaluator: the native Windows test host, using `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/h44/client44/Scripts/python.exe` as the selected `client_python`. The `assert-greeting` helper evaluates the equality assertion. The service's Linux runtime is not the test platform. Released evaluator `0.22.1` evaluates artifact structure and links; it does not execute this assertion. The assertion record does not establish a Python version.

After separate execution authority is available, the reviewer performs this one planned command in PowerShell:

```powershell
& 'C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe' -I 'C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/h44/e/codex-432/native/inputs/native_call.py' assert-greeting --record 'C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/h44/e/codex-432/native/work/WO-P3-900-VER-P3-001-assertion.json'
```

The reviewer inspects the retained exit status, stdout and stderr. Exit 0 with `exact greeting passed` satisfies the matrix pass condition. An equality assertion failure returns a nonzero exit and fails this case. A source mismatch, launch failure or missing record leaves the requirement unassessed; retain the diagnostic and do not report a pass. This plan does not require changing the fixture to induce a failure.

## Evidence retention

The planned, new assertion record is `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/h44/e/codex-432/native/work/WO-P3-900-VER-P3-001-assertion.json`. Retain its companion files under the same selected work directory. The helper records the exact command, working directory, exit status, stdout, stderr and elapsed time. Retain actual failure results as well as passing results. Do not overwrite existing evidence.

Use `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/h44/e/codex-432/native/inputs/source-manifest.json` and the source commit and digest above to identify the planned input. These identify the fixture; they do not establish a later verification candidate. The planned assertion file does not yet exist and is not evidence of a performed check.

## Residual uncertainty

Verification is planned only. The helper makes one equality assertion; it does not separately assert Python type or absence of external effects. This contract covers the requested REQ-P3-900 acceptance criterion, not an assessment of every SPEC-P3-900 constraint. It creates no commit-bound verification record and supplies no approval, verified state or release authority. The fixture needs only one direct assertion for the requested criterion; additional test suites would not establish a distinct requested outcome.
