Observation snapshot is complete: 4 native calls, no failures, no mutations attempted. The capture is complete through this point.

I now have sufficient context to assess the change request. The intent checklist requires the present problem, who it affects, the outcome wanted, and how the owner will observe improvement. The request "Adapt the existing greeting for a new audience" describes a solution direction, not a problem. Per the hosted-drafts procedure, I must not invent a purpose or measure from engineering activity, and must ask for missing inputs.

This is a clarification stop. No hosted mutation was invoked and the captured record is complete.

---

**Actions:** No hosted change was attempted. One `remote status` read confirmed service readiness, `sandbox-projection` authority mode, test-copy status, and all component identities matching the combination. Project version is 0.

**Known inputs:**
- Domain: `lifecycle-pilot`; owner: `test-owner`
- Existing imported definitions: INT-P3-900, CAP-P3-900, REQ-P3-900, SPEC-P3-900, VER-P3-900, WO-P3-900 (immutable history)
- INT-P3-900 outcome: "The test operator observes Hello rehearsal."
- Source fixture: `greeting()` returns `'Hello rehearsal'`
- Requested direction: "Adapt the existing greeting for a new audience."
- Artifact type: intent

**Questions:** The intent checklist requires three facts the request does not supply. Each is needed before drafting the intent document.

1. **Present problem:** What problem does the current greeting create for the new audience? "Adapt" describes a proposed solution, not the problem it addresses. Why is `'Hello rehearsal'` insufficient?
2. **Audience identity:** Who is the new audience? The current intent (INT-P3-900) serves "the test operator." A new intent needs a stated audience.
3. **Success observation:** How will the owner know the adaptation helped? An unmeasured baseline is allowed, but the way to observe improvement must come from the requester.

Evidence: `work/status-check`, `work/observations-clarification`.