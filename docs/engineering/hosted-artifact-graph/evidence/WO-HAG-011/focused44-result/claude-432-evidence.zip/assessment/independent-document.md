+++
id = "VER-P3-001"
type = "verification"
title = "Assert the rehearsal greeting by independent equality check"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert the rehearsal greeting by independent equality check

## Independence

The expected value `Hello rehearsal` derives from REQ-P3-900 and SPEC-P3-900 rule P3-GREET-900. It is a fixed string stated in the requirement acceptance criteria, not extracted from candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Exact equality assertion via `assert-greeting` | `greeting()` returns the string `Hello rehearsal` and the tool exits 0 with `exact greeting passed` |

## Acceptance scenarios

One automated check covers the required behavior:

1. Verify that the source fixture digest matches the selected `greeting_sha256` before execution.
2. Run the `assert-greeting` command on the native test host.
3. The check calls `greeting()` once and asserts strict equality against the independently fixed expected string `Hello rehearsal`.
4. A passing result is exit code 0 with output `exact greeting passed`.
5. Any other exit code is a failure.

Platform: native test host (the operator's local machine). Evaluator: se_harness 0.22.1.

## Evidence retention

Retain the assertion record at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/greeting-assertion.json`. The record contains the command, exit status, stdout, stderr and elapsed time produced by the execution tool.
