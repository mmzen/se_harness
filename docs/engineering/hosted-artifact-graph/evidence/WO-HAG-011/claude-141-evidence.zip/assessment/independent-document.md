+++
id = "INT-P3-001"
type = "intent"
title = "Establish the exact rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
outcome = "The test operator confirms that greeting() returns exactly Hello rehearsal."

[relations]
+++

# Intent: Establish the exact rehearsal greeting

## In plain words

The test operator needs to know that the rehearsal fixture produces the expected
greeting. This intent covers confirming the exact output of `greeting()` in
`src/greeting.py`.

## Problem

The rehearsal fixture defines a `greeting()` function in `src/greeting.py`. The
test operator has no recorded confirmation that this function returns the
expected string `Hello rehearsal`. Without that confirmation, downstream
verification and release rehearsal lack an established starting point.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| greeting() output matches `Hello rehearsal` | not measured | Exact match confirmed | Single inspection of the fixture output |

## Not this

- Changes to the greeting text or fixture behavior
- Verification of other fixtures or source files
- Approval, release or deployment of any artifact
- Real human authority or production decisions
