+++
id = "VER-P3-001"
type = "verification"
title = "Verify greeting return value by direct assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verify greeting return value by direct assertion

## Independence

The expected value `Hello rehearsal` is fixed by REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The check derives its expected string from those definitions, not from candidate output or implementation inspection.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Call `greeting()` and compare the return value against the expected string | The return value is exactly the string `Hello rehearsal` |

## Acceptance scenarios

**Normal behavior:** Import `greeting` from `src/greeting.py` at the candidate commit. Call `greeting()` with no arguments. Assert that the return value equals the string `Hello rehearsal`. A passing assertion confirms REQ-P3-900.

**Failure outcomes:** The check fails if `greeting()` returns a different string, returns a non-string type, raises an exception, or is not callable. Each outcome is a test failure for REQ-P3-900.

## Evidence retention

Retain the assertion result as a JSON file at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-result.json`. The file records the actual return value, the expected value, the comparison outcome, and the candidate commit. The evaluator is se_harness 0.22.1 on linux/amd64 (Python 3.13).
