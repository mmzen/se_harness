+++
id = "VER-P3-001"
type = "verification"
title = "Plan an independent exact greeting check"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Plan an independent exact greeting check

Synthetic alternative authoring exercise for an independent reviewer. This contract plans verification of the supplied fixture. No check has been executed under this contract. Existing VER-P3-900 and all imported records remain unchanged; this alternative does not claim a coverage gap or replace the work order's selected contract.

## Independence

The expected string `Hello rehearsal` derives from REQ-P3-900 acceptance and SPEC-P3-900 rule P3-GREET-900. The reviewer fixes that expected value before execution and does not derive it from candidate output. Source inspection establishes the function location, not a test result. One exact comparison covers the selected fixed-output requirement without duplicate checks.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Call `greeting()` once and retain the comparison record at the full path in Evidence retention. | On Windows x64 with CPython 3.14, the planned Python evaluator below completes without an exception, records `passed` as true, and exits 0 because the result is a string exactly equal to `Hello rehearsal`. No trimming, case conversion or other normalization is permitted. |

## Acceptance scenarios

Planned inputs: the supplied REQ-P3-900 and SPEC-P3-900, and `src/greeting.py` from source snapshot `5820415917e87b64d80bad2f7c39c6d18d692829`. The supplied fixture SHA-256 is `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`. This identifies source input; it is not executed verification evidence or a clean-checkout claim.

Planned platform: Windows x64, CPython 3.14. The independent reviewer will use Python as the behavioral evaluator. SE Harness 0.22.1 evaluates draft structure and links only.

After execution is separately authorized, the reviewer will:

1. Record the actual Python version, platform, source path and source SHA-256. Confirm that the source hash matches the supplied fixture identity before running the check. A mismatch stops this check pending input review.
2. Run the following Python code against the exact source file. Capture stdout, stderr and the process exit code. The code is a planned check, not an instruction to execute during this drafting task.

```python
import json
import runpy
import sys

source = "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-efficiency-clarification-reply-20261010/codex-182/native/inputs/source/src/greeting.py"
expected = "Hello rehearsal"
actual = runpy.run_path(source)["greeting"]()
passed = isinstance(actual, str) and actual == expected
print(json.dumps({
    "requirement": "REQ-P3-900",
    "contract": "VER-P3-001",
    "expected": expected,
    "actual_repr": repr(actual),
    "actual_type": type(actual).__name__,
    "passed": passed,
}))
sys.exit(0 if passed else 1)
```

3. Assess the pass condition in the matrix. A different value or non-string result fails the comparison. A load error, missing function, exception or absent result cannot pass; retain its diagnostic. No separate injected-failure campaign is required for this fixed-output requirement.
4. Retain the result and execution context at the evidence destination below. Do not mark a missing or interrupted run as passed.

## Evidence retention

Planned full evidence path: `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-efficiency-clarification-reply-20261010/codex-182/native/work/verification/WO-P3-900/VER-P3-001-assertion.json`.

The reviewer will retain one JSON record containing the requirement and contract IDs, exact check code, timestamp, source snapshot identity and measured SHA-256, actual Python version and platform, expected value, captured stdout and stderr, exit code and assessment with its reason. Preserve error diagnostics when no comparison record is produced. This filename separates the alternative plan's future evidence from existing VER-P3-900 evidence. No result file is created during drafting.

## Residual uncertainty

This contract defines a future check only. The fixture has been inspected but has not been run in this task. A future passing result would establish the stated return-value condition for the identified input and platform; this draft grants no execution, assurance or release authority.
