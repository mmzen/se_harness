"""Independent byte comparison of the complete delivered focused entry."""
import hashlib,json,sys
from pathlib import Path
W=Path(__file__).parent;O=W/'h44/e';trial=sys.argv[1];n=O/trial/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
entry=load(n/'instruction-entry.json');raw=(n/'task.md').read_bytes();text=raw.decode();inv=load(n/'inputs/inventory.json')['files']
actual={x['relative'] for x in inv if x['relative'].startswith('source/')}
supplied={Path(x['path']).relative_to(n/'inputs').as_posix() for x in entry['complete_input_files']['sources']}
assert actual==supplied
items=entry['complete_input_files']['sources']+entry['complete_input_files']['references']
for x in items:
 original=Path(x['path']).read_bytes();assert sha(original)==x['sha256'] and len(original)==x['bytes'] and original==x['text'].encode()
 assert text.count(x['text'])==1
sections=[]
for resource in entry['instruction_view']['resources']:
 for section in resource['sections']:
  if 'content' in section:assert text.count(section['content'])==1;sections.append({'resource':resource['resource'],'sha256':sha(section['content'].encode())})
assert len(raw)<=65536
v={'trial':trial,'task_sha256':sha(raw),'task_bytes':len(raw),'limit_bytes':65536,'source_files':len(actual),'references':len(entry['complete_input_files']['references']),'canonical_sections':sections,'result':'Every staged source file, selected reference and canonical section is supplied once with exact content. No input truncation.','limits':'Input fidelity only, not content review or host qualification.'}
f=O/trial/'input-fidelity.json';assert not f.exists();f.write_bytes((json.dumps(v,indent=2)+'\n').encode());print(json.dumps({k:v[k] for k in ('trial','task_bytes','source_files','references')}))
