"""Measure exact candidate prompt construction without launching a native host."""
import ast,json,sys,hashlib
from pathlib import Path
from types import SimpleNamespace
W=Path(__file__).parent;E=W/'hag-c45/e';root=Path(sys.argv[1]) if len(sys.argv)>1 else E/'codex-452'
sys.path.insert(0,str(W/'hag221proposal/tests/hosted_artifact_graph'))
import qualify_agents as q
source=Path(q.__file__).read_text();tree=ast.parse(source)
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run')
# Retain the unchanged function only up to its final complete-task size check.
# No subprocess, network call or native launch is in this prefix (drop_reply=False).
cut=next(i for i,n in enumerate(fn.body) if isinstance(n,ast.If) and 'Complete task entry exceeds' in ast.get_source_segment(source,n))
fn.body=fn.body[:cut]+[ast.Return(value=ast.Name(id='prompt',ctx=ast.Load()))]
module=ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[]))
exec(compile(module,'exact-candidate-prompt-prefix','exec'),q.__dict__)
entry=json.loads((E/'claude-452/native/instruction-entry.json').read_text())
selectors=[]
for r in entry['instruction_view']['resources']:
 for s in r['sections']:
  selectors.append(r['resource']+'#'+s['heading'])
args=SimpleNamespace(output=root/'native',prepared_inputs=True,selection=root/'native-selection.json',host='codex',codex_loopback_network=True,credentials=root/'credentials.json',drop_reply=False,complete_inputs=True,instruction_section=selectors,task=root/'native-task.md')
prompt=q.run(args)
v={'method':'Unchanged candidate run() prefix through complete prompt assembly, stopping before cap check and native launch. No service operations.','bytes':len(prompt.encode()),'limit':65536,'fits':len(prompt.encode())<=65536,'sha256':hashlib.sha256(prompt.encode()).hexdigest()}
path=root/'input-size-preflight.json';assert not path.exists();path.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
(root/'native/selection.json').rename(root/'preflight-selection.json')
