"""Retain reviewed evidence for the approved WO-HAG-011 correction."""
import hashlib,json,re,subprocess,sys,zipfile
from pathlib import Path
import hag_efficiency_plan as p
W,R,D=p.W,p.R,p.D;O=W/'hag-c45';p.O=O;E=D/'evidence/WO-HAG-011/qualified45-result'
trials=['claude-451','codex-451','claude-452','claude-453','claude-454','codex-452']
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
 assert not f.exists(),f
 f.write_bytes((v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
mode=sys.argv[1]
if mode=='scope':
 names=['assessment.md','provenance.zip','provenance-inventory.json']+[t+s for t in trials for s in ('-evidence.zip','-visible.md','-inventory.json')]
 paths=[(E/n).relative_to(R).as_posix() for n in names]
 v=p.gov('retention-scope','check',R,'--artifact','WO-HAG-011','--checkpoint','scope','--changes-complete',*[a for path in paths for a in ('--changed-path',path)],'--json');assert v['compliance']['status']=='pass';print('Retention scope passes',flush=True)
elif mode=='retain':
 assert json.loads(load(O/'retention-scope.json')['stdout'])['compliance']['status']=='pass'
 assert (O/'qualified45-assessment.md').exists()
 assert subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()==b''
 for trial in trials:
  r=W.parent/'q' if trial=='codex-452' else O/'e'/trial
  assert load(r/'independent-assessment.json')['overall']=='pass'
  assert load(r/'boundary-comparison.json')['equal']
 E.mkdir(exist_ok=False)
 source=(W/'hag_retain26.py').read_text().replace('hag-efficiency-compact-pointers-20261010','hag-c45/e')
 source=source.replace("dest=h.D/'evidence/WO-HAG-011'", "dest=h.D/'evidence/WO-HAG-011/qualified45-result'")
 names=['input-fidelity.json','independent-final-reply.md','boundary-before-native.json','boundary-after-native.json','boundary-comparison.json','independent-originals.json','package-reuse.json','relocation.json','input-size-preflight.json']
 source=source.replace("'immutable-baseline-review.json'):","'immutable-baseline-review.json',"+','.join(repr(n) for n in names)+"):")
 extra="""for observed in list(root.glob('original-*-request.json'))+list(root.glob('original-*-read.json')):
 if observed.exists():files['assessment/'+observed.name]=observed.read_bytes()
for suffix in ('-initial-status.json','-final-status.json','-independent-read.json','-stop.json','-boundary-probe.json'):
 observed=h.O/(trial+suffix)
 if observed.exists():files['proctor/'+observed.name]=observed.read_bytes()
"""
 source=source.replace("summary=h.O/(trial+'-summary.json')",extra+"summary=h.O/(trial+'-summary.json')")
 for trial in trials:
  code=source.replace('root=h.O/trial;',"root=h.W.parent/'q';") if trial=='codex-452' else source
  sys.argv=[__file__,trial];exec(compile(code,'retain-reviewed45','exec'),{'__file__':str(W/'hag_retain26.py'),'__name__':'__main__'})
 files={}
 for name in ('candidate-45','build45-replay','package-comparison','service-comparison','server-wheel-members','installed-client-reuse'):
  f=O/(name+'.json');files['candidate/'+f.name]=f.read_bytes()
 for name in ('combination.json','image-metadata.json','image-package.json','plugin-assembly.json','plugin-claude-inventory.json','plugin-codex-inventory.json','server-build.json','source-commit.json','source-status.json'):
  files['package/'+name]=(O/'package45'/name).read_bytes()
 for f in (O/'e').glob('*.json'):
  if any(x in f.name for x in ('-networks','-up','-init','-volume','-source-stage')):continue
  files['observations/'+f.name]=f.read_bytes()
 for name in ('hag_runs45.py','hag_observe45.py','hag_entry45.py','hag_short45.py','hag_reuse45.py','hag_close45.py','hag_native26.py','hag_observe26.py','hag_observe44.py','hag_input44.py','hag_originals44.py','hag_eff44_probe.py','hag221_execute.py','hag_efficiency_plan.py','hag_retain26.py'):
  files['drivers/'+name]=(W/name).read_bytes()
 for path,label in [(O/'e/codex-452/input-size-preflight.json','original-long-path'),(W/'q45c/input-size-preflight.json','first-short-path'),(W.parent/'q/input-size-preflight.json','final-short-path')]:files['entry/'+label+'.json']=path.read_bytes()
 tokens=[x['token'].encode() for f in (O/'e').glob('*/credentials.json') for x in load(f)['principals']]
 for name,raw in files.items():
  assert not any(t in raw for t in tokens),name
  assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
 with zipfile.ZipFile(E/'provenance.zip','x',zipfile.ZIP_DEFLATED) as z:
  for n,b in sorted(files.items()):z.writestr(n,b)
 put(E/'provenance-inventory.json',{'archive':'provenance.zip','sha256':sha((E/'provenance.zip').read_bytes()),'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())],'omissions':'No raw provider events, private reasoning, credential stores or test tokens. Actual native failures are retained in visible transcripts and assessments.'})
 put(E/'assessment.md',(O/'qualified45-assessment.md').read_text())
 print('Retained reviewed six-case qualification and provenance.')
else:raise ValueError(mode)
