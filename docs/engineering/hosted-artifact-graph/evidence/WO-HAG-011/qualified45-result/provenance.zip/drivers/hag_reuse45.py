"""Bind earlier installed-client checks to unchanged current wheel components."""
import hashlib,json,zipfile,subprocess
from pathlib import Path
import hag_efficiency_plan as p
W=p.W;O=W/'hag-c45';E=p.D/'evidence/WO-HAG-011';sha=lambda b:hashlib.sha256(b).hexdigest()
archive=E/'candidate26-checks.zip';inv=json.loads((E/'candidate26-checks-inventory.json').read_text())
assert sha(archive.read_bytes())==inv['sha256']
with zipfile.ZipFile(archive) as z:
 for item in inv['files']:
  raw=z.read(item['path']);assert sha(raw)==item['sha256'] and len(raw)==item['bytes']
 assessment=json.loads(z.read('installed-client/assessment.json'))
 old=json.loads(z.read('package/source-commit.json'))['stdout'].strip()
 assert assessment['exact_final_bytes'] and assessment['expected_mutations']==assessment['observed_project_version']==6
a=W/'hag-efficiency-compact-pointers-20261010/build26/se_harness-0.22.2-py3-none-any.whl';b=O/'build45/se_harness-0.22.2-py3-none-any.whl'
def members(path):
 with zipfile.ZipFile(path) as z:return {n:sha(z.read(n)) for n in z.namelist()}
aa,bb=members(a),members(b);changed=[n for n in sorted(set(aa)|set(bb)) if aa.get(n)!=bb.get(n)]
assert changed==['se_harness-0.22.2.dist-info/RECORD','se_harness/resources.py'],changed
v={'candidate':'829e6f05f2915492be1c7b541e7944a5d33c45ca','reused_candidate':old,'archive':str(archive),'archive_sha256':sha(archive.read_bytes()),'verified_archive_members':len(inv['files']),'old_wheel_sha256':sha(a.read_bytes()),'current_wheel_sha256':sha(b.read_bytes()),'changed_members':changed,'reused_cases':'EFF-02 and EFF-03 installed-client wire equivalence, compact/full fields, exact bytes, refusal and original-key recovery. No typed client or service behavior changed.','limits':'No whole-wheel equality claim. Changed resource behavior is covered by current source/resource tests and exact native-input checks. Changed drafting guidance requires the new EFF-04 sequence; no old native verdict is reused.','assessment':assessment}
out=O/'installed-client-reuse.json';assert not out.exists();out.write_text(json.dumps(v,indent=2)+'\n');print(json.dumps({k:v[k] for k in ('reused_candidate','verified_archive_members','changed_members')}))
