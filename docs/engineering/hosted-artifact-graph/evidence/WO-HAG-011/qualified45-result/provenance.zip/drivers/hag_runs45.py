"""Exact fresh EFF-04 runs using existing boundary/staging implementation."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
import hag_efficiency_plan as p
W=p.W;O=W/'hag-c45/e';O.mkdir(exist_ok=True);P=W/'hag-c45'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
CLAUDE=W/'hag-opus55-availability-20261011/claude-2.1.280.exe'
CODEX=Path(r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\2e5e00daee91c61d\codex.exe')
def put(f,v):
 assert not f.exists(),f
 f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def boundary():
 return {'settings':[{'path':str(f),'sha256':sha(f.read_bytes()) if f.exists() else None} for f in map(Path,('C:/Users/mathi/.codex/config.toml','C:/Users/mathi/.claude/settings.json','C:/Users/mathi/.claude/plugins/installed_plugins.json'))],'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=p.R).decode().strip(),'tracked_diff':subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=p.R).decode()}
mode,host=sys.argv[1:3]
if mode=='auth':
 p.O=O;root=O/(host+'-auth');root.mkdir(exist_ok=True);assert not (root/'private-probe.json').exists()
 exe=CLAUDE if host=='claude' else CODEX
 p.run(host+'-version',[exe,'--version'])
 prompt='Authorized authentication probe. Reply exactly AUTH_OK. Use no tools, read no files, change nothing.'
 argv=([exe,'-p','--no-session-persistence','--tools','','--model','claude-opus-4-6','--output-format','json',prompt] if host=='claude' else [exe,'--no-daemon','exec','--ephemeral','--skip-git-repo-check','--json','-C',root,'--sandbox','read-only',prompt])
 start=time.monotonic();r=subprocess.run(list(map(str,argv)),cwd=root,capture_output=True,encoding='utf-8',errors='replace',timeout=180)
 put(root/'private-probe.json',{'argv':list(map(str,argv)),'cwd':str(root),'exit':r.returncode,'seconds':time.monotonic()-start,'stdout':r.stdout,'stderr':r.stderr})
 if host=='claude':
  v=json.loads(r.stdout);ok=v.get('result','').strip()=='AUTH_OK' and not v.get('is_error')
 else:
  events=[json.loads(x) for x in r.stdout.splitlines() if x.strip().startswith('{')]
  replies=[x.get('item',{}).get('text','') for x in events if x.get('type')=='item.completed' and x.get('item',{}).get('type')=='agent_message']
  ok=bool(replies) and replies[-1].strip()=='AUTH_OK'
 put(O/(host+'-auth-review.json'),{'host':host,'AUTH_OK_observed':ok,'exit':r.returncode,'model':'claude-opus-4-6' if host=='claude' else 'CLI selected model','raw_events':'Private provider log excluded from published evidence.'})
 print(host,'AUTH_OK',ok,'exit',r.returncode,flush=True);assert r.returncode==0 and ok;raise SystemExit(0)
trial=sys.argv[3];assert trial in ('451','452','453','454')
root=O/(host+'-'+trial);C=load(P/'candidate-45.json')['commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=p.R).decode().strip()==C
assert not subprocess.check_output(['git','status','--porcelain'],cwd=p.R).strip()
if mode=='run':
 assert load(O/('claude-live-access.json' if host=='claude' else 'codex-auth-review.json'))['live_access_observed' if host=='claude' else 'AUTH_OK_observed']
 if host=='codex':assert load(O/(host+'-'+trial+'-boundary-probe.json'))['exit']==0
 put(root/'boundary-before-native.json',boundary())
source=(W/'hag_native26.py').read_text()
for a,b in [('hag-efficiency-compact-pointers-20261010','hag-c45/e'),("P=h.O/'package26'","P=h.W/'hag-c45/package45'"),("h.O/'client26/Scripts/python.exe'","h.W/'hag-c45/client45/Scripts/python.exe'"),("h.O/'build26/se_harness-0.22.2-py3-none-any.whl'","h.W/'hag-c45/build45/se_harness-0.22.2-py3-none-any.whl'"),('hag-efficiency26-','hag-draft45-'),('native-efficiency26','native-draft45'),('10.231.84.0/22','10.231.140.0/22'),("'201'","'451'"),(r'C:\Users\mathi\.local\bin\claude.exe',str(CLAUDE)),("split('## Entry and tools'","split('## Inputs and boundaries'")]:source=source.replace(a,b)
source=source.replace(r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\9691020b546a15b2\codex.exe',str(CODEX))
try:exec(compile(source,'native45','exec'),{'__file__':str(W/'hag_native26.py'),'__name__':'__main__'})
finally:
 if mode=='run':put(root/'boundary-after-native.json',boundary())
if mode=='stage':
 n=root/'native';inv=load(n/'inputs/inventory.json')['files'];assert all(sha(Path(x['path']).read_bytes())==x['sha256'] for x in inv)
 for name in ('native_call.py','summarize_native.py'):assert (n/'inputs'/name).read_bytes()==subprocess.check_output(['git','show',C+':tests/hosted_artifact_graph/'+name],cwd=p.R)
 put(root/'package-reuse.json',{'candidate':C,'case':'EFF-04A2' if trial=='451' else 'EFF-04B','package':str(P),'inputs_checked':len(inv),'model':'claude-opus-4-6' if host=='claude' else 'CLI selected model'})
 print(host,trial,'staged',flush=True)
