"""Independent observations; no authored content or hosted mutations."""
import json,sys,subprocess
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-c45/e';mode,trial=sys.argv[1:3]
def invoke_source(name,old,new):
 source=(W/name).read_text().replace(old,new)
 exec(compile(source,'observe45-'+mode,'exec'),{'__file__':str(W/name),'__name__':'__main__'})
sys.argv=[__file__,trial]
if mode=='boundary':
 source=(W/'hag_eff44_probe.py').read_text().replace("O=W/'h44/e'","O=W/'hag-c45/e'")
 source=source.replace('W=Path(__file__).parent;O=',f'W=Path({str(W)!r});O=')
 source=source.replace(r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\9691020b546a15b2\codex.exe',r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\2e5e00daee91c61d\codex.exe')
 # The sandbox child needs the original probe's inside mode.
 path=O/'boundary-probe-driver-v2.py';assert not path.exists() or path.read_text()==source;path.write_text(source)
 subprocess.run([sys.executable,'-X','utf8','-B',path,trial],cwd=W,check=True)
elif mode=='input':invoke_source('hag_input44.py','h44/e','hag-c45/e')
elif mode=='observe':invoke_source('hag_observe44.py','h44/e','hag-c45/e')
elif mode=='originals':invoke_source('hag_originals44.py','h44/e','hag-c45/e')
elif mode=='view':
 r=O/trial;n=r/'native';texts=[]
 for line in (n/'events.jsonl').read_text().splitlines():
  try:e=json.loads(line)
  except ValueError:continue
  if e.get('type')=='assistant':texts.extend(b['text'] for b in e.get('message',{}).get('content',[]) if b.get('type')=='text')
  elif e.get('type')=='item.completed' and e.get('item',{}).get('type')=='agent_message':texts.append(e['item']['text'])
 final=texts[-1] if texts else '';out=r/'independent-final-reply.md';assert not out.exists();out.write_text(final)
 for f in [r/'independent-document.md',n/'work/native-report.md']:
  if f.exists():print('FILE',str(f),'\n'+f.read_text())
 print('FINAL REPLY\n'+final)
elif mode=='stop':
 import os,hag221_execute as h
 h.O=O;s=json.loads((O/trial/'selection.json').read_text());assert s['compose_project']=='hag-draft45-'+trial
 env=dict(os.environ,HAG_SERVICE_IMAGE='harness-hag:native-draft45',HAG_HTTP_PORT=s['endpoint'].rsplit(':',1)[1],HAG_CONFIG_DIRECTORY=str(O/trial/'configuration'),HAG_CREDENTIAL_FILE=str(O/trial/'credentials.json'),HAG_SOURCE_VOLUME=s['source_volume'])
 h.run(trial+'-stop',['docker','compose','-p',s['compose_project'],'-f',W/'hag-c45/package45/candidate-source/server/compose.yaml','-f',O/trial/'network.json','stop','graph','service'],env=env)
