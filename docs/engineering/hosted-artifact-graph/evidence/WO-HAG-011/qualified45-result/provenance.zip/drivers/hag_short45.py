"""Relocate a not-yet-run fixture; all instruction and source bytes stay exact."""
import hashlib,json,shutil,sys,subprocess
from pathlib import Path
W=Path(__file__).parent;E=W/'hag-c45/e';old=E/'codex-452';new=W.parent/'q';mode=sys.argv[1]
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def put(p,v):
 assert not p.exists(),p
 p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def relocate(v):
 if isinstance(v,str):return v.replace(str(old),str(new)).replace(old.as_posix(),new.as_posix())
 if isinstance(v,list):return list(map(relocate,v))
 if isinstance(v,dict):return {k:relocate(x) for k,x in v.items()}
 return v
if mode=='prepare':
 assert not new.exists();assert not (old/'native/session.json').exists()
 new.mkdir();(new/'native').mkdir();(new/'native/work').mkdir()
 shutil.copytree(old/'native/inputs',new/'native/inputs')
 inv=new/'native/inputs/inventory.json';inventory=relocate(load(inv));inv.write_bytes((json.dumps(inventory,indent=2)+'\n').encode())
 for item in inventory['files']:
  assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256']
 for name in ('selection.json','credentials.json','network.json','combination.json','package-reuse.json'):
  shutil.copyfile(old/name,new/name)
 shutil.copytree(old/'configuration',new/'configuration')
 for name in ('native-selection.json','permissions.json'):put(new/name,relocate(load(old/name)))
 (new/'native-task.md').write_bytes(relocate((old/'native-task.md').read_text()).encode())
 put(new/'relocation.json',{'from':str(old),'to':str(new),'reason':'Complete Codex input at original path is 439 bytes over 64 KiB. Shorter temporary paths only.','candidate':'829e6f05f2915492be1c7b541e7944a5d33c45ca','all_input_file_bytes_preserved':True,'changed':'Absolute locator paths in inventory, native selection, permission locators and task working directory. No instructions, task outcome, cap, permissions, source records or package bytes changed.','actual_native_operations':0})
 subprocess.run([sys.executable,'-X','utf8','-B',W/'hag_entry45.py',new],cwd=W,check=True)
elif mode=='run':
 source=(W/'hag_runs45.py').read_text()
 source=source.replace("root=O/(host+'-'+trial);C=", "root=W.parent/'q';C=")
 source=source.replace("try:exec(compile(source", "source=source.replace(\"root=h.O/(host+'-'+trial);native=\",\"root=h.W.parent/'q';native=\")\ntry:exec(compile(source")
 sys.argv=[__file__,'run','codex','452'];exec(compile(source,'relocated-codex45','exec'),{'__file__':str(W/'hag_runs45.py'),'__name__':'__main__'})
elif mode=='boundary':
 source=(E/'boundary-probe-driver-v2.py').read_text().replace('O/trial/',"(W.parent/'q')/")
 path=E/'boundary-short-driver.py';assert not path.exists();path.write_text(source)
 subprocess.run([sys.executable,'-X','utf8','-B',path,'codex-452'],cwd=W,check=True)
elif mode in ('observe','input','originals'):
 name={'observe':'hag_observe44.py','input':'hag_input44.py','originals':'hag_originals44.py'}[mode]
 source=(W/name).read_text().replace('h44/e','hag-c45/e')
 source=source.replace('root=O/trial;',"root=p.W.parent/'q';")
 source=source.replace("n=O/trial/'native'", "n=W.parent/'q/native'")
 source=source.replace("f=O/trial/'input-fidelity.json'", "f=W.parent/'q/input-fidelity.json'")
 if mode=='observe':
  source=source.replace("exec(compile(source", "source=source.replace('root=h.O/trial;',\"root=h.W.parent/'q';\")\nexec(compile(source")
 sys.argv=[__file__,'codex-452'];exec(compile(source,'short45-'+mode,'exec'),{'__file__':str(W/name),'__name__':'__main__'})
elif mode=='view':
 source=(W/'hag_observe45.py').read_text().replace("r=O/trial;n=", "r=W.parent/'q';n=")
 sys.argv=[__file__,'view','codex-452'];exec(compile(source,'short45-view','exec'),{'__file__':str(W/'hag_observe45.py'),'__name__':'__main__'})
else:raise ValueError(mode)
