"""Independently read every imported artifact in the final focused draft context."""
import base64, hashlib, json, os, sys, tomllib
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'h44/e';trial=sys.argv[1];root=O/trial;n=root/'native';p.O=O
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
selection=load(root/'selection.json')
token=next(x['token'] for x in load(root/'credentials.json')['principals'] if x['id']=='operator')
summary=load(O/(trial+'-summary.json'))
imports=[load(Path(v['path'])) for v in summary['command_records'] if 'import' in v['argv']]
assert len(imports)==1
response=json.loads(imports[0]['stdout']);response=response.get('result',response)
view=load(root/'independent-read-request.json')['view']
observed=[]
for artifact in response['affected_artifacts']:
    aid=artifact['artifact_id'];assert aid.endswith('-900')
    request={'schema':'se-harness-graph-read/v1','operation':'revision','project_id':selection['project_id'],'view':view,'artifact_id':aid,'revision_id':artifact['revision_id'],'budget':{'rows':1,'bytes':2097152,'depth':0}}
    request_file=root/('original-'+aid+'-request.json');assert not request_file.exists()
    request_file.write_bytes((json.dumps(request,indent=2)+'\n').encode())
    argv=[selection['client_python'],'-I','-m','se_harness','remote','read','--endpoint',selection['endpoint'],'--project',selection['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--request',str(request_file),'--json']
    import subprocess,time
    started=time.monotonic();cp=subprocess.run(argv,cwd=p.W,env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token),capture_output=True)
    record={'argv':argv,'cwd':str(p.W),'exit':cp.returncode,'elapsed_seconds':time.monotonic()-started,'stdout':cp.stdout.decode(),'stderr':cp.stderr.decode()}
    log=root/('original-'+aid+'-read.json');assert not log.exists();log.write_bytes((json.dumps(record,indent=2)+'\n').encode())
    assert cp.returncode==0
    result=json.loads(cp.stdout);assert result['complete'] and result['continuation'] is None
    raw=base64.b64decode(result['data']['document_base64'],validate=True)
    originals=list((n/'inputs/source').rglob(aid+'.md'));assert len(originals)==1
    assert raw==originals[0].read_bytes(),aid
    observed.append({'artifact':aid,'sha256':sha(raw),'exact_original':True,'read_record':log.name})
assert len(observed)==7
out=root/'independent-originals.json';assert not out.exists()
out.write_bytes((json.dumps({'view':view,'originals':observed,'all_exact':True},indent=2)+'\n').encode())
print(json.dumps({'trial':trial,'imported_originals_exact':len(observed)}))
