+++
id = "VER-P3-001"
type = "verification"
title = "Alternative greeting equality assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative greeting equality assertion

## Independence

The expected value `Hello rehearsal` derives from REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The assertion compares that fixed string against the candidate `greeting()` return value. No candidate output informs the expected result.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Exact equality assertion via `assert-greeting` on the native test host | `greeting()` returns the string `Hello rehearsal`; exit 0 with `exact greeting passed` |

## Acceptance scenarios

Run `assert-greeting` on the native test host using the selected `client_python`. Before execution, confirm the source fixture `src/greeting.py` digest matches the selected `greeting_sha256`. The tool invokes `greeting()` once and asserts that its return value equals `Hello rehearsal`.

**Platform:** Native test host (Windows), using `client_python` from `selection.json`.
**Evaluator:** 0.22.1 (archive `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`).

## Evidence retention

Retain the `assert-greeting` record at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-assertion.json`. The record contains the command, exit status, stdout, stderr and elapsed time.

## Residual uncertainty

The assertion runs on the native test host, not inside the Linux service container. Platform parity is not verified by this check. The tool makes no separate return-type assertion.
