**Blocked by missing intent inputs.** The fixture returns `Hello rehearsal`; its definitions describe only the existing rehearsal. No hosted mutation was attempted.

Please provide:

- The new audience.
- Its problem with the current greeting and the desired improvement.
- How the owner will observe success.

Proposed outcome: “When the existing greeting is used for the new audience, that audience receives a greeting adapted to its needs.” Please confirm or revise this wording. Scope remains one draft intent in `lifecycle-pilot`, owned by `test-owner`, with the supplied exclusions.

[Saved report](work/native-report.md) contains the findings and evidence links. Observation capture was incomplete; no exhaustive failure claim is made.

The selected [change skill](inputs/plugin/verity-plane/skills/change/SKILL.md) routes to [hosted drafting](inputs/plugin/verity-plane/skills/change/references/hosted-drafts.md), which requires: “Ask for a required fact absent from the confirmed inputs and stop dependent writing.” That requirement prevents drafting until these facts are supplied.