Created **VER-P3-001** and retained it as a draft. The plan is complete; validation found no errors or unfinished fields. The existing SPEC advisory remains recorded.

No tests ran. Imported records remain unchanged.

[Saved draft](work/read-final.json.evidence/1-document-1.md) · [Authoring report](work/native-report.md)