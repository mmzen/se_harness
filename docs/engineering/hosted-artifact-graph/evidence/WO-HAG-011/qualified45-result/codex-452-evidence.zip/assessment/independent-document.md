+++
id = "VER-P3-001"
type = "verification"
title = "Plan an independent check of the rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[relations]
verifies = ["REQ-P3-900"]
+++

# Plan an independent check of the rehearsal greeting

Synthetic alternative authoring exercise for an independent reviewer. This draft supplies a verification plan for REQ-P3-900. Existing VER-P3-900 supplies an existing contract; this alternative does not establish a coverage gap or replace that contract. All imported records remain unchanged. No test has been executed under this plan.

## Independence

The expected result is exactly `Hello rehearsal`, derived from the acceptance criterion in REQ-P3-900 and the fixed greeting specified by SPEC-P3-900, rule P3-GREET-900. The expected value is not derived from candidate output. The reviewer uses the documented `assert-greeting` helper, which calls the selected fixture's `greeting()` once and asserts equality with this fixed value. It makes no separate type assertion.

Source inspection of the supplied `src/greeting.py` shows a function returning the literal `'Hello rehearsal'`. This inspection establishes the planned input, not a test result.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Planned exact greeting assertion; `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/q/native/work/assertion-VER-P3-001.json` | On the native Windows test host, the documented helper evaluates `greeting() == 'Hello rehearsal'` through the selected client Python. Exit status is 0 and stdout contains `exact greeting passed`. The source digest must match the selected fixture digest before execution. |

## Acceptance scenarios

This section is planned work only. Drafting grants no execution authority. If execution is later authorized, the reviewer uses these inputs:

- Selection: `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/q/native/selection.json`.
- Fixture: `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/q/native/inputs/source/src/greeting.py`.
- Source manifest: `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/q/native/inputs/source-manifest.json`.
- Source fixture commit: `5820415917e87b64d80bad2f7c39c6d18d692829`.
- Required fixture SHA-256: `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`.
- Assertion runtime: `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-c45/client45/Scripts/python.exe`, selected by the helper, on the native Windows test host.

The planned PowerShell invocation is:

```powershell
& 'C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe' -I 'C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/q/native/inputs/native_call.py' assert-greeting --record 'C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/q/native/work/assertion-VER-P3-001.json'
```

The evidence path must be new when the check runs. The helper checks the fixture digest before execution. A digest mismatch prevents assessment of this selected input. A returned value unequal to the expected value fails the assertion with a nonzero exit. An invocation error or missing success output does not establish a pass; retain its diagnostics for review. Do not change the expected value to match observed output.

The test evaluator is the helper's Python equality assertion. The hosted service runtime, Linux/amd64 with Python 3.13.16, is not the assertion runtime. SE Harness 0.22.1 evaluates draft shape and links; its authoring result does not execute or assess this assertion.

## Evidence retention

Retain the actual command record at `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/q/native/work/assertion-VER-P3-001.json` and all companion output files returned by the helper. The record retains the exact command, working directory, exit status, stdout, stderr and elapsed time. Retain the selected source manifest, source fixture commit and digest references with the result so the reviewer can identify the input. Preserve a failure record as evidence; do not overwrite it.

## Residual uncertainty

This draft defines the check and pass condition only. No execution evidence or verified result exists from this authoring exercise. The assertion record does not contain a Python version and does not establish commit-bound verification. The source fixture commit identifies the supplied snapshot, not a later verification candidate. The selected requirement has one fixed equality outcome; no additional performance, security or resilience checks are proposed for this bounded exercise.
