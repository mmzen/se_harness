# Hosted verification draft report

**Content readiness: complete.** The latest saved revision of VER-P3-001 meets the selected verification checklist for this alternative authoring exercise. It remains `draft`, owned by synthetic `test-owner`, in `lifecycle-pilot`. Exactly one new artifact was created. No imported -900 record was revised. Existing VER-P3-900 already provides coverage; no missing contract is claimed.

## Saved state

- Selection: `http://127.0.0.1:26462`, project `242ec68e-65d9-44eb-b282-1996e47632d9`, `sandbox-projection`, test copy. [Status](status.json.stdout.txt) matched the supplied qualified combination and selected evaluator 0.22.1. The identity operation returned the selected client wheel SHA-256 `5bfa8bb4608187d18e9c9151a0060bc56db0c07654e954205d580d1927aa0b90`.
- Imported baseline B: `se-harness-artifact-baseline/v1:sha256:84379be4d37b4385789454f9f5f0f5683e31c09a0ffe8a71ffe96b0d86458bfe`.
- Context: `bdc37950-7637-4b9c-a206-47433a760a2a`, version 2; project version 4.
- Latest revision: `sha256:52ca33c305f48cd58a9ad2b16f1938ef87598ab8c97c26b9ad67839eebdf39e3`; document SHA-256: `c0f318751572af5f3eb756d781216f06bc883df7dfef9d097ec93b58a2c240ff`.
- Exact saved document: [read-final.json.evidence/1-document-1.md](read-final.json.evidence/1-document-1.md). Exact read result: [read-final.json.evidence/1-response.json](read-final.json.evidence/1-response.json). The read is complete, has no unresolved references, and names the requested revision and context.
- Source fixture commit S: `5820415917e87b64d80bad2f7c39c6d18d692829`. Qualification candidate C from the supplied selection and identity result: `829e6f05f2915492be1c7b541e7944a5d33c45ca`. No disposable Git verification candidate P was established by this exercise.

## Validation and review

| Assessed action | Observed outcome and evidence | Limit |
|---|---|---|
| Import | Accepted; [import.json](import.json) and [exact result](import.json.evidence/1-response.json) | Imported fixture, not real authority. |
| Open draft context | Accepted; [open.json](open.json) and [exact result](open.json.evidence/1-response.json) | Returned `PROC-FOCUS-SELECTED` / `STEP-FOCUS-SELECTED`; selected WO remains draft. |
| Create VER-P3-001 | Accepted; [create.json](create.json) and [exact result](create.json.evidence/1-response.json) | Initial template had unfinished title, owner, body and relation slots; its read reported unresolved `REQ-xxx`. These were resolved by revision. |
| Submit complete draft | Accepted under `draft-ver-revise-01`, receipt `94c67f49-57ea-4e02-9e23-6e2986ac90d7`; [revise.json](revise.json) and [exact result](revise.json.evidence/1-response.json) | `admissible: true`, no errors or incomplete fields. Evaluator content review remains `not_assessed`; its scope is draft shape and required links. |

Independent content review used source inspection of the supplied REQ-P3-900, SPEC-P3-900, VER-P3-900 and fixture, plus the documented execution capabilities and final saved document. The expected value comes from the definitions. The plan names the equality assertion, native Windows runtime, evaluator, failure interpretation, input identity and full evidence filename. It distinguishes planned verification from source inspection and draft validation. No required content gap remains for the requested check.

The evaluator retained background advisory `W-AUT-022`: "Coverage row REQ-P3-900 names undefined rule P3-GREET-900." The supplied specification contains that named rule in prose; its imported bytes were preserved. This advisory is not reported as repaired.

[Observation snapshot](observations.json) reports no captured native failures or failed command records. Capture completeness is unknown: `native_call_count_complete` is false, and the snapshot excludes subsequent report writes. No exhaustive failure count is claimed. No denial, recovery or uncertain mutation effect was observed in the inspected calls. All submitted mutations returned accepted results; reads are reported separately.

No assertion was executed. No approval, work start, baseline freeze, verification decision or release action occurred. This report and the draft establish an authored plan only. Git remains authoritative for real work.
