+++
id = "VER-P3-001"
type = "verification"
title = "Verify greeting output by independent equality assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verify greeting output by independent equality assertion

## Independence

The expected return value `Hello rehearsal` is fixed by REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. Neither value is derived from candidate output or implementation inspection.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | `assert-greeting` equality check; result at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-greeting-assertion.json` | Exit 0 with `exact greeting passed`: greeting() returned exactly `Hello rehearsal` |

## Acceptance scenarios

Call `greeting()` once on the native test host using the selected `client_python`. The `assert-greeting` command compares the returned value against the independently fixed string `Hello rehearsal`.

Pass: exit 0 and stdout contains `exact greeting passed`.

Fail: nonzero exit. The returned value did not equal `Hello rehearsal`, the function raised an exception, or the function was not callable.

Precondition: the source file digest must match the selected `greeting_sha256` before execution, confirming the correct fixture is under test.

## Evidence retention

Retain the `assert-greeting` result record at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-001-greeting-assertion.json`. The record contains the exact command, working directory, exit status, stdout, stderr, and elapsed time.

Platform: native test host, using `client_python` from the selection.
Evaluator: se_harness 0.22.1 (archive_sha256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`).

## Residual uncertainty

The `assert-greeting` tool performs an equality assertion only. It does not assert the return type. A separate type constraint check is outside this tool's capabilities and remains a gap if required.
