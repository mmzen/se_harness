The draft verification contract VER-P3-001 is saved and the report is retained.

**Summary:**

- **Created:** VER-P3-001 — an independent verification contract that plans an equality assertion of `greeting()` against the expected value `Hello rehearsal`, derived from REQ-P3-900.
- **Draft validation:** Admissible, zero errors, zero incomplete fields.
- **Content review:** Complete against the `verification` checklist by source inspection. The expected result derives from the requirement, not from candidate output. The planned check matches the `assert-greeting` execution tool.
- **All hosted operations succeeded:** import, draft-open, create-artifact, revise-artifact, and one read. No failures or denials.
- **No side effects:** No tests executed, no lifecycle decisions made, no existing artifacts modified.
- **Evidence:** `work/observations`, `work/revise-ver.evidence/`, `work/read-ver.evidence/`.
- **Report:** `work/native-report.md`.