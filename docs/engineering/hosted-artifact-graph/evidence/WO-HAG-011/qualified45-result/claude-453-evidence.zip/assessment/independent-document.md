+++
id = "VER-P3-001"
type = "verification"
title = "Assert the rehearsal greeting by independent equality check"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert the rehearsal greeting by independent equality check

## Independence

The expected value `Hello rehearsal` is fixed by REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The assertion derives that text from the requirement, not from candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Equality assertion via `assert-greeting` on the native test host | `greeting()` returns exactly `Hello rehearsal`; exit 0 with `exact greeting passed` |

## Acceptance scenarios

Run `assert-greeting --record <evidence-path>` using the approved shell prefix and `client_python` on the native test host (Windows 11, Python 3.14). The source digest must match `greeting_sha256` before execution. The evaluator is version 0.22.1.

- **Input:** The fixture `src/greeting.py` at the selected source commit.
- **Expected result:** The string `Hello rehearsal`, derived from REQ-P3-900.
- **Pass:** Exit 0 and stdout contains `exact greeting passed`.
- **Fail:** Nonzero exit or stdout does not contain `exact greeting passed`.

## Evidence retention

Retain the assertion record at `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/alt-greeting-assertion.json`. The record contains the command, working directory, exit status, stdout, stderr and elapsed time.

## Residual uncertainty

The `assert-greeting` tool does not perform a separate type assertion. It runs on the native test host, not inside the Linux service runtime. Platform-specific behavior differences remain outside this check.
