Service is ready. Authority mode is `sandbox-projection`, `test_copy: true`, and all component identities match the combination. Now I need to follow the hosted drafting procedure for the intent.

The request is "Adapt the existing greeting for a new audience." Before drafting, I need to apply DEFINE_CHANGE.md's clarification procedure. The existing fixture definitions are already in context. Let me check what the intent checklist requires against what the request supplies.

From the intent checklist (`ARTIFACT_AUTHORING.md#intent`):
- Explain the present problem, who it affects, and the outcome wanted.
- What is the smallest useful outcome, and which needs and constraints are actually agreed?
- Say how the owner will know the change helped.
- State the important scope limits.

The request "Adapt the existing greeting for a new audience" does not supply several required inputs. The procedure states: "A creation request supplies no missing fact." I cannot invent the problem, audience identity, or success measure.

---

**Actions:** No hosted mutation was attempted. One `remote status` confirmed service readiness (record: `work/status-check`). The client identity matches the combination (wheel SHA-256 `5bfa8bb...`).

**Known inputs:**
- Existing fixture definitions: INT-P3-900 through WO-P3-900 are supplied in context. The current greeting is `Hello rehearsal` (source `src/greeting.py`). These imported `-900` records are immutable history.
- Domain: `lifecycle-pilot`. Owner: `test-owner`.
- The request names a change type (intent) and direction ("adapt... for a new audience").
- Scope constraint: one intent only; no other artifacts, no fixture changes, no approval or lifecycle actions.

**Questions:** Three facts are missing from the request and cannot be invented:

1. **Who is the new audience?** The request says "a new audience" without identifying who they are or what distinguishes them from the current rehearsal operator.

2. **What is the present problem?** Why does the existing greeting (`Hello rehearsal`) not serve the new audience? What gap or limitation does the requester observe?

3. **How will the owner know the change helped?** What observable result would confirm that the adapted greeting meets the new audience's need? An unmeasured baseline is acceptable, but the success measure itself is required.

These three inputs are needed before the intent draft can be authored with supported content. Once confirmed, I will import the source baseline, open a draft context, and create the intent in the hosted service.