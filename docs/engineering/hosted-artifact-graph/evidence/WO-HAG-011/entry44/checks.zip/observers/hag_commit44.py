"""Freeze the bounded correction and preserve C42 failures under existing work authority."""
import json,hashlib,subprocess,tomllib,zipfile
from pathlib import Path
import hag_efficiency_plan as p
W,R,D=p.W,p.R,p.D;O=W/'h44';p.O=O;E=D/'evidence/WO-HAG-011/entry44'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
assert git('rev-parse','HEAD')=='f0d042d69e025bdab284695e7e17667eeb38eaf3'
names=['source','distribution','smoke','resources','native','plugin','scope36','WO-HAG-009-preflight36','WO-HAG-011-preflight36','validation']
assert all(load(O/(x+'.json'))['exit']==0 for x in names)
E.mkdir(exist_ok=False);files={x+'.json':(O/(x+'.json')).read_bytes() for x in names+['change','retained-archive-check']}
for name in ('hag_assess_full43.py','hag_retain43.py','hag_control44.py','hag_commit44.py'):
 files['observers/'+name]=(W/name).read_bytes()
with zipfile.ZipFile(E/'checks.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
(E/'inventory.json').write_bytes((json.dumps({'archive':'checks.zip','sha256':sha((E/'checks.zip').read_bytes()),'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())]},indent=2)+'\n').encode())
review="# Review: distinguish the outcome from its implementation\n\nThe C43 full native lifecycle passes for both hosts. The separate first focused\nClaude diagnostic still fails; both results and all failures are retained:\n[full qualification](../../WO-HAG-009/final43-result/assessment.md) and\n[focused diagnostic](../focused43-result/assessment.md).\n\nReplace one paragraph in hosted-drafts.md. It clarifies the existing requirement\nto establish the user's problem, intended improvement and way to observe success.\nA channel, message or function is a solution choice. An unmeasured baseline does\nnot replace the required success measure. Reuse confirmed inputs.\n\nThis is explanatory guidance under WO-HAG-011. No task answer, qualification\ncriterion, canonical instruction, endpoint, lifecycle policy, host setting,\ndependency or test-driver behavior changes. Replacing the existing paragraph\navoids a second rule source or another tool. The diff adds 174 bytes.\n\nFocused resource/native/plugin checks, full source tests, distribution and CLI\nchecks pass. Released validation and both review preflights pass. Exact results\nand the failed prior diagnostic are retained. Both previous disposable service\npairs were stopped with volumes preserved before modifying this checkout.\n\nThe new packaged candidate must first pass a fresh Claude EFF-04A2 diagnostic.\nOnly then may the remaining focused sequence proceed. Required full NQ evidence\nmust be assessed against final guidance. Keep the PR draft; no actual assurance,\nmerge, release or authority switch is inferred. CI's separate 512 MiB archive\nlimit failure remains disclosed and needs new bounded correction authority.\n"
(E/'review.md').write_bytes(review.encode())
paths=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
allowed=[]
for aid in ['WO-HAG-009','WO-HAG-011']:
 allowed+=tomllib.loads((D/'work-orders'/f'{aid}.md').read_text().split('+++')[1])['execution_scope']['paths']
assert all(any(x==s or s.endswith('/') and x.startswith(s) for s in allowed) for x in paths)
p.run('diff-check',['git','diff','--check'],cwd=R)
p.run('stage',['git','add','--',*paths],cwd=R)
p.run('staged-check',['git','diff','--cached','--check'],cwd=R)
p.run('commit',['git','commit','-m','Clarify intent outcomes and retain completed native qualification','-m','Harness-Work-Orders: WO-HAG-009, WO-HAG-011'],cwd=R)
assert not git('status','--porcelain')
(O/'candidate-44.json').write_bytes((json.dumps({'commit':git('rev-parse','HEAD'),'base':'55caaada508495bea7d97effd27644d1ce8373da'},indent=2)+'\n').encode())
print(git('rev-parse','HEAD'))
