from pathlib import Path
import sys
W=Path(__file__).parent
source=(W/'hag_correction36.py').read_text().replace('hag-procedure36-20261011','h44')
source=source.replace('WO-HAG-011/procedure36','WO-HAG-011/entry44')
start=source.index('changed=');end=source.index('\n',start)
source=source[:start]+"changed=['plugins/verity-plane/common/skills/change/references/hosted-drafts.md']"+source[end:]
for a,b in [('candidate-36','candidate-44'),('build36','build44'),('package36','package44'),('client36','client44'),('native-procedure36','native-entry44'),("-36'","-44'"),('hag36','h44')]:source=source.replace(a,b)
assert sys.argv[1] in ('scope','focused','checks','governor','build')
exec(compile(source,'entry42-control','exec'),{'__file__':str(W/'hag_correction36.py'),'__name__':'__main__'})
