+++
id = "VER-P3-901"
type = "verification"
title = "Verify greeting returns the exact rehearsal string"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Verify greeting returns the exact rehearsal string

## Independence

The expected value `Hello rehearsal` derives from REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The pass condition does not use candidate output or implementation details.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Call `greeting()` and compare the return value to the independently fixed string | Return value equals the string `Hello rehearsal` exactly, with no leading or trailing whitespace and no other content |

## Acceptance scenarios

1. Import `greeting` from `src/greeting.py`.
2. Call `greeting()` with no arguments.
3. Assert the return value is the Python string `'Hello rehearsal'`.

Platform: Python 3.11 or later. Evaluator: se_harness 0.22.1.

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-greeting-check.json`. The file records the actual return value, the expected value, the comparison result and the timestamp.
