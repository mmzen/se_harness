import datetime,json,os,socket,subprocess,sys,time,urllib.error,urllib.request
from pathlib import Path

W=Path(__file__).parent
O=W/'hag-codex-network-20261010';O.mkdir(exist_ok=True)
C=Path(r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\9691020b546a15b2\codex.exe')
PROFILE='hag-loopback'
SETTINGS=[
 'windows.sandbox="mxc"','features.network_proxy=true',
 'default_permissions="hag-loopback"',
 'permissions.hag-loopback={extends=":workspace",network={enabled=true,allow_local_binding=true,domains={"127.0.0.1"="allow"},proxy_url="http://127.0.0.1:19991",socks_url="http://127.0.0.1:19992"}}',
]

def run(label,args,timeout=45):
    dest=O/(label+'.json');assert not dest.exists(),dest
    start=time.monotonic()
    r=subprocess.run(list(map(str,args)),cwd=O,capture_output=True,encoding='utf-8',errors='replace',timeout=timeout)
    rec={'argv':list(map(str,args)),'cwd':str(O),'exit':r.returncode,'elapsed_seconds':round(time.monotonic()-start,3),'stdout':r.stdout,'stderr':r.stderr,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    dest.write_bytes((json.dumps(rec,indent=2)+'\n').encode())
    print(json.dumps({'label':label,'exit':r.returncode,'stdout':r.stdout[-3000:],'stderr':r.stderr[-2000:]}),flush=True)
    return r

if sys.argv[1] in ('inside','inside-local'):
    results={}
    for name,action in [
        ('workspace_write',lambda:(O/'sandbox-write.txt').write_text('owned boundary probe',encoding='utf-8')),
        ('outside_write_open',lambda:(W/'codex-network-outside-sentinel.txt').open('r+')),
        ('service_http',lambda:urllib.request.urlopen('http://127.0.0.1:19881/health',timeout=5)),
        ('external_proxy_http',lambda:urllib.request.urlopen('https://example.com/',timeout=6)),
        ('external_direct_tcp',lambda:socket.create_connection(('1.1.1.1',443),timeout=5)),
    ]:
        if sys.argv[1]=='inside-local' and name.startswith('external_'):continue
        try:
            result=action()
            results[name]={'succeeded':True,'status':getattr(result,'status',None)}
            if hasattr(result,'close'):result.close()
        except Exception as exc:
            results[name]={'succeeded':False,'error':type(exc).__name__,'detail':str(exc)}
    results['network_disabled']=os.environ.get('CODEX_SANDBOX_NETWORK_DISABLED')
    results['proxy_present']=bool(os.environ.get('HTTPS_PROXY') or os.environ.get('https_proxy'))
    print(json.dumps(results))
elif sys.argv[1]=='probe':
    sentinel=W/'codex-network-outside-sentinel.txt';assert not sentinel.exists()
    sentinel.write_bytes(b'owned unchanged external sentinel\n')
    names=['hag-efficiency14-claude-81-graph-1','hag-efficiency14-claude-81-service-1']
    checked=run('containers-inspect',['docker','inspect','--format','{{.Name}} {{index .Config.Labels "com.docker.compose.project"}}',*names])
    assert checked.returncode==0 and all('hag-efficiency14-claude-81' in line for line in checked.stdout.splitlines())
    assert run('containers-start',['docker','start',*names]).returncode==0
    time.sleep(3)
    args=[str(C)]
    for setting in SETTINGS:args+=['-c',setting]
    args+=['sandbox','--include-managed-config','--permission-profile',PROFILE,'--cd',str(O),'--',sys.executable,'-I','-B',str(Path(__file__).resolve()),'inside']
    run('sandbox-boundaries',args)
    assert sentinel.read_bytes()==b'owned unchanged external sentinel\n'
elif sys.argv[1]=='probe2':
    args=[str(C)]
    for setting in SETTINGS:args+=['-c',setting]
    args+=['sandbox','--include-managed-config','--permission-profile',PROFILE,'--cd',str(O),'--',sys.executable,'-I','-B',str(Path(__file__).resolve()),'inside']
    run('sandbox-boundaries02',args)
    assert (W/'codex-network-outside-sentinel.txt').read_bytes()==b'owned unchanged external sentinel\n'
elif sys.argv[1] in ('live','live-local'):
    args=[str(C),'--no-daemon','exec','--ephemeral','--skip-git-repo-check','--json','-C',str(O)]
    for setting in [*SETTINGS,'approval_policy="on-request"','approvals_reviewer="auto_review"']:
        args+=['-c',setting]
    operation='inside-local' if sys.argv[1]=='live-local' else 'inside'
    prompt=('Run exactly one shell command without escalation or changing permissions. Invoke the following argv in PowerShell: '+json.dumps([sys.executable,'-I','-B',str(Path(__file__).resolve()),operation])+'. Report the returned boundary results briefly. Do not inspect any other file or credential. The script probes owned boundary targets only.')
    run('live-profile-probe-local' if operation=='inside-local' else 'live-profile-probe',[*args,prompt],timeout=120)
else:raise ValueError(sys.argv[1])
