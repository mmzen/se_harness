+++
id = "INT-P3-001"
type = "intent"
title = "Confirm rehearsal greeting fixture output"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
outcome = "The test operator can confirm that greeting() returns exactly Hello rehearsal."

[relations]
+++

# Intent: Confirm rehearsal greeting fixture output

## In plain words

The test operator needs a confirmed record that the rehearsal fixture produces the expected greeting before downstream rehearsal steps rely on it.

## Problem

The operator conducting a lifecycle rehearsal has no documented confirmation that `src/greeting.py` produces the expected output. The fixture defines `greeting()` with a return value of `Hello rehearsal`. Without a recorded confirmation, downstream rehearsal activities cannot establish that they start from a known baseline.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| The operator has a confirmed record that greeting() returns exactly Hello rehearsal | not measured | Confirmed | During rehearsal setup, once per rehearsal cycle |

## Not this

- Changing the greeting fixture's return value.
- Real product releases or production deployment.
- Automated monitoring of the greeting output.
- Lifecycle decisions beyond confirming the fixture output.
