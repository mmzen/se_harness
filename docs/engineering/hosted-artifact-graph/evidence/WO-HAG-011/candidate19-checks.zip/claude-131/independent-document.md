+++
id = "INT-P3-001"
type = "intent"
title = "Confirm the fixture returns the expected greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
outcome = "The test operator establishes that greeting() returns exactly Hello rehearsal."

[relations]
+++

# Intent: Confirm the fixture returns the expected greeting

## In plain words

A test operator needs independent confirmation that the rehearsal fixture produces the exact expected greeting value before downstream lifecycle steps rely on it.

## Problem

The lifecycle-pilot fixture provides a `greeting()` function in `src/greeting.py`. The operator expects this function to return exactly `Hello rehearsal`. No independent confirmation of the return value exists yet. Without that confirmation, the operator cannot determine whether the fixture meets its stated requirement before subsequent work depends on it.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| Confirmed greeting return value | not measured | greeting() returns exactly `Hello rehearsal` | Retained assertion evidence in lifecycle-pilot domain |

## Not this

- Changes to the greeting text or fixture behavior.
- Approval, verification or release of any artifact.
- Real product decisions beyond the rehearsal scope.
