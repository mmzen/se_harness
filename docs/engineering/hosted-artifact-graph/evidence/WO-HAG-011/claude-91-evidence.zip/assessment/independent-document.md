+++
id = "INT-P3-001"
type = "intent"
title = "Confirm rehearsal greeting output"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
outcome = "The test operator can confirm that greeting() returns exactly 'Hello rehearsal'."

[relations]
+++

# Intent: Confirm rehearsal greeting output

## In plain words

A test operator needs to confirm that the rehearsal fixture produces an exact expected greeting before proceeding with lifecycle rehearsal work.

## Problem

The lifecycle-pilot fixture at `src/greeting.py` provides a `greeting()` function used in a disposable lifecycle rehearsal. Without a recorded intent, there is no accepted purpose stating the expected output or who needs to observe it. The test operator cannot reference a governing artifact for verification of this fixture.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| greeting() returns exactly 'Hello rehearsal' | not measured | Exact match confirmed | During rehearsal, by manual inspection |

## Not this

- Real product or service delivery.
- Changes to the greeting fixture itself.
- Lifecycle decisions beyond draft preparation.
- Automated monitoring or alerting.
