# Native report — INT-P3-001 intent draft

## Content readiness: incomplete

The draft passed template validation (admissible, zero errors, zero incomplete
fields). Content review identifies one unresolved finding: the stated purpose
describes confirming expected program output, which the hosted-drafts procedure
identifies as verification or preparation rather than an operational benefit.
The success measure names a program output match, not an outcome observed in
operation after delivery.

## Saved artifact and revision

| Field | Value |
| --- | --- |
| Artifact | `INT-P3-001` |
| Revision | `sha256:3122a2d21d017d2c1c4b3be319930c2d596aedeffec1165ba2a46e8bd60f9d4d` |
| Document SHA-256 | `0d630d8db5c9854f9f4a3b18afe2e34a6ee6b4f2a4389b872ec87afc697926c6` |
| Context | `e2183679-10c5-4558-872a-3875ec49dc9b` version 2 |
| Project version | 4 |
| Path (hosted) | `docs/engineering/lifecycle-pilot/intent/INT-P3-001.md` |

## Current versions

| Component | Version |
| --- | --- |
| Evaluator | 0.22.1 |
| Client | 0.22.2 |
| Authority mode | `sandbox-projection` |

## Document and result paths

- Authored draft: `work/INT-P3-001-draft.md`
- Create receipt: `work/create-int-002.json`
- Revise receipt: `work/revise-int-001.json`
- Read-back document: `work/read-int-001.json.evidence/1-document-1.md`
- Create template: `work/create-int-002.json.evidence/2-document-1.md`
- Import receipt: `work/import-001.json`
- Draft-open receipt: `work/draft-open-001.json`
- Status receipt: `work/status-001.json`

All paths relative to
`C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-efficiency-inputs-20261010\claude-91\native`.

## Template-validation result (executed)

Returned by revise-artifact, schema `se-harness-draft-validation-v1`:

- `admissible`: true
- `errors`: []
- `incomplete`: []
- `background`: 1 advisory — `W-AUT-022` on `SPEC-P3-900` (pre-existing, unrelated to this draft)

Draft validation checks template shape and required links. It does not assess
content.

## Content-review findings (executed, agent)

1. **Purpose describes verification, not operational benefit.** The hosted-drafts
   procedure states: "Producing an artifact or confirming an expected program
   output alone describes preparation or verification, not an operational
   benefit." The intent's outcome and success measure name a program output
   match (`greeting()` returns exactly `'Hello rehearsal'`). This is a
   verification assertion, not an improvement observed in operation after
   delivery. The intent checklist asks how the owner will know the change
   helped; the current measure answers with fixture output confirmation.

2. **Fixture inspected.** `src/greeting.py` contains `def greeting(): return 'Hello rehearsal'`
   (sha256: `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`).
   The function returns the exact string stated in the intent.

3. **Existing coverage.** INT-P3-900 covers a similar rehearsal greeting scope.
   The new INT-P3-001 is a separate draft as requested; it does not supersede
   INT-P3-900.

## Unresolved inputs

- The operator has not supplied an operational benefit or measure beyond
  confirming the fixture's output. Resolving finding 1 requires operator input
  on the intended improvement in the user's situation.

## Failed calls and recovery

- `create-int-001` (exit 1): Used project UUID as context before importing the
  source baseline. Error `HAG_REMOTE_UNKNOWN_IDENTITY`. Recovered by importing
  the baseline (`import-001`), opening a draft context (`draft-open-001`), and
  retrying (`create-int-002`).

## Result

One intent draft (`INT-P3-001`) saved and read back. Template validation passed.
Content review identifies one unresolved finding: the stated purpose describes
verification rather than an operational benefit. The draft is incomplete pending
operator input on an operational measure.

Report path: `work/native-report.md`
