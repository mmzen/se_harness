+++
id = "INT-P3-001"
type = "intent"
title = "Establish that greeting() returns exactly Hello rehearsal"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"
outcome = "An operator can confirm that the greeting() fixture returns the exact string Hello rehearsal."

[relations]
+++

# Intent: Establish that greeting() returns exactly Hello rehearsal

## In plain words

An operator needs evidence that the `greeting()` function in `src/greeting.py` produces the exact string `Hello rehearsal`. This intent establishes that purpose for verification.

## Problem

The `greeting()` function in `src/greeting.py` returns a fixed string. No formal record establishes the expected return value or gives an operator a defined way to confirm the output. Without an accepted intent, verification of the greeting has no agreed purpose.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| Operator confirms greeting() returns exactly Hello rehearsal | not measured | The return value matches the exact string Hello rehearsal | Manual inspection of the fixture source or a verification record |

## Not this

- Changing the return value of `greeting()`.
- Verifying any function other than `greeting()` in `src/greeting.py`.
- Approving, releasing, or deploying the greeting fixture.
- Creating runtime monitoring or automated test infrastructure.
- Addressing the existing INT-P3-900 scope or its governing chain.
