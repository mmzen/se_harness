+++
id = "INT-P3-001"
type = "intent"
title = "Establish that the rehearsal fixture returns the exact greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
outcome = "The test operator can confirm that greeting() returns exactly Hello rehearsal before dependent lifecycle work proceeds."

[relations]
+++

# Intent: Establish that the rehearsal fixture returns the exact greeting

## In plain words

A test operator needs to confirm that the fixture function `greeting()` in
`src/greeting.py` returns the exact string `Hello rehearsal` before further
lifecycle artifacts depend on that value.

## Problem

The lifecycle-pilot domain contains requirements (REQ-P3-900), specifications
(SPEC-P3-900), and verification contracts (VER-P3-900) that all depend on
`greeting()` returning exactly `Hello rehearsal`. Without an explicit record
that the operator established this fact, subsequent lifecycle work proceeds
on an unverified assumption about the fixture's return value.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| Operator has a confirmed record that greeting() returns Hello rehearsal | not measured | Confirmed once before dependent work begins | Operator inspection during rehearsal setup |

## Not this

- Changing the return value or behavior of `src/greeting.py`.
- Replacing or extending the existing INT-P3-900.
- Approving, releasing, or deploying any rehearsal output.
- Performing real human decisions or product work.
