+++
id = "VER-P3-901"
type = "verification"
title = "Alternative greeting assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative greeting assertion

## Independence

The expected string `Hello rehearsal` derives from REQ-P3-900 acceptance criteria and SPEC-P3-900 rule P3-GREET-900. The pass condition uses that requirement-defined value, not candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Call `greeting()` and compare the return value to the requirement-defined string | Return value equals `Hello rehearsal` exactly (case-sensitive, no trailing whitespace) |

## Acceptance scenarios

1. Import `greeting` from `src/greeting.py`.
2. Call `greeting()` with no arguments.
3. Assert the return value equals the string `Hello rehearsal`.

Platform: `linux/amd64`, Python `3.13.16` (combination runtime).
Evaluator: `0.22.1` (`cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`).

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-assertion.json`.
