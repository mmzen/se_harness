+++
id = "VER-P3-901"
type = "verification"
title = "Assert exact greeting return value"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"

[relations]
verifies = ["REQ-P3-900"]
+++

# Assert exact greeting return value

## Independence

The expected value `Hello rehearsal` derives from the acceptance criterion in REQ-P3-900 and the specification rule P3-GREET-900 in SPEC-P3-900. The expected result is not read from candidate output or implementation source.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Import `greeting` from `src/greeting.py` and call `greeting()`. Compare the return value to the fixed expected string. | `greeting()` returns exactly the string `Hello rehearsal`. |

## Acceptance scenarios

**Scenario: exact greeting string.**
Given the fixture module `src/greeting.py` is importable,
when `greeting()` is called,
then the return value equals `Hello rehearsal` with no additional whitespace, casing variation, or trailing characters.

Platform: Python 3.11 or later.
Evaluator: se_harness 0.22.1.

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-assertion.json`. The file records the actual return value, the expected value, the comparison outcome, and the timestamp.
