# Native test tool index

Read `selection.json` for the exact `approved_shell_argv_prefix`, project and
paths. Append one operation below to that prefix per shell call. Use native
Read/Write/Edit for files. Output directories already exist. Direct client
commands, directory listing, wrappers and permission changes are not permitted.
This index lists capabilities; the agent selects the workflow from its task and
the applicable released instructions.

| Need | Helper operation |
| --- | --- |
| Candidate wheel identity | `identity` returns metadata and SHA-256 only. |
| One known input path and digest | `lookup-file RELATIVE_NAME` |
| Locate a filename | `find-file BASENAME` with optional `--under DIRECTORY/`; the trailing slash is required. No wildcards. |
| Inspect saved JSON | `read-json ABSOLUTE_FILE --pointer '"/field"'`; `--keys` lists names only. Omit the pointer for the root. |
| Read a base64 document field | Add `--decode-base64` to that exact field read; inspect its text and digest. |
| Encode authored document bytes | `encode-file ABSOLUTE_DOCUMENT`; not for wheel identity. |
| Service identity/readiness | `remote status --record ABSOLUTE_NEW_RECORD`; no request file. Status reports `project_version`. |
| One selected remote operation | `remote OPERATION --request ABSOLUTE_REQUEST --record ABSOLUTE_NEW_RECORD` |
| Mutation receipt | `remote operation --key KEY --record ABSOLUTE_NEW_RECORD` |

All draft/request/result paths belong under the selected output directory.
Read each actual result and its omitted fields as needed. `--record` retains
complete output; the displayed `result_fields` are bounded exact values, not an
independent verdict. `remote read` accepts typed revision inputs or a raw request; `--key` cannot read a document.

## Request discovery

For raw request mode, read its one schema view under `inputs/schemas/`.
Typed mode below constructs that same request; no manual envelope or encoding is needed.
Each view cites its original schema, pointer and digest. No values are supplied.

| Family | Available operation names |
| --- | --- |
| `remote-v1` | `import`, `draft-open`, `create-artifact`, `revise-artifact`, `freeze` |
| `read-v1` | `revision`, `work-context`, `compare`, `impact`, `lineage`, `check`, `cypher` |

The relative view name is `schemas/FAMILY/OPERATION.json`. Read operations use
the CLI's `remote read`. The original schemas remain under
`reference/server/contracts/`. `status` and receipt lookup have no request schema.
Captured CLI help is `inputs/client-help/OPERATION.txt` for `read`, `operation`,
`create-artifact` and `revise-artifact`. Other helper syntax is available with
`--help`; do not guess options. Lifecycle schemas are separate and unnecessary
for a drafting-only task.

Input names for lookup are relative to `inputs/`: `plugin/verity-plane/skills/`,
`released-resources/` and `source/`. Read only the required sections after lookup.
A digest or file search is not a content read. To report a digest, cite its exact
lookup/inventory entry or copy that entry's own value. Keep complete inputs and
failures as evidence without loading their entire inventory into context.

## Typed client and section views

`remote OPERATION --typed --compact --record ABSOLUTE_NEW_RECORD` forwards one
chosen operation to the installed client. The record's `.evidence` directory is
new, client-owned local evidence. The adapter passes the complete client view
through; it does not select a workflow, fill a draft or decide content quality.

All typed mutations require `--operation-key KEY --expected-project-version N
--evaluator-file ABSOLUTE_FILE`. The evaluator identity file is `inputs/evaluator.json`.
The configured installed wheel identity is supplied mechanically, not hand copied.

| Operation | Other typed inputs |
| --- | --- |
| import | `--source-manifest FILE` (the selected canonical source manifest) |
| draft-open | `--baseline ID --work-order WO-ID` |
| create-artifact | `--context UUID --context-version N --domain NAME --artifact-type TYPE`; optional `--artifact ID --include-document` |
| revise-artifact | `--context UUID --context-version N --artifact ID --expected-revision REVISION --document-file FILE` |
| read | `--artifact ID --expected-revision REVISION` plus `--baseline ID` or `--context UUID --context-version N`; no mutation fields |

Do not mix typed input and `--request`. The agent supplies versions and operation
keys; the client never refreshes or retries them. Include-document adds only an
exact created-revision read and returns readable template text or its decoded
local file path. Compact findings can be incomplete: read required omitted fields.
A capture error after send can leave a committed effect; reconcile the original key.

`instructions --section RELATIVE_RESOURCE#HEADING` returns complete identified
sections using the installed client reader. Repeat the option for up to 12 selected
sections in one call. Paths start with `released-resources/`, exactly as staged.
Choose the applicable procedure and prerequisites; no sections are preselected.
Unknown or ambiguous headings and changed source bytes fail explicitly. The view
includes the selected release, path, heading and SHA-256. Reuse unchanged content.
