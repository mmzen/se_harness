+++
id = "INT-P3-001"
type = "intent"
title = "Establish that greeting() returns exactly Hello rehearsal"
status = "draft"
owners = ["test-owner"]
created = "2026-10-08"
updated = "2026-10-08"
outcome = "An operator can confirm that the fixture greeting() returns the exact string Hello rehearsal."

[relations]
+++

# Intent: Establish that greeting() returns exactly Hello rehearsal

## In plain words

The project needs a verified record that the existing fixture function
greeting() in src/greeting.py produces the exact string `Hello rehearsal`.
This intent establishes the purpose of that verification so the operator
can trace it through the lifecycle.

## Problem

The greeting() function in src/greeting.py returns a fixed string, but
there is no formal intent establishing that this exact return value is the
agreed expected behavior. Without a governing intent, an operator cannot
trace why the function exists or what outcome its correctness supports.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| greeting() returns exactly `Hello rehearsal` | not measured | Verified by inspection or test | Once, at verification time |

## Not this

- This intent does not cover changing the greeting text.
- This intent does not cover other functions in the codebase.
- This intent does not cover runtime performance or deployment.
