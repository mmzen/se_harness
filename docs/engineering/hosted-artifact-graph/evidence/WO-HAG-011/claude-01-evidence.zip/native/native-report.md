# Native drafting diagnostic report

## Task

Prepare exactly one new intent draft (INT) for an operator who needs to establish
that the existing fixture's `greeting()` returns exactly `Hello rehearsal`.
Domain: lifecycle-pilot. Owner: test-owner. Keep as draft only.

## Source inspection

- **File:** `source/src/greeting.py`
- **Content:** `def greeting(): return 'Hello rehearsal'`
- **SHA-256:** `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`
- **Verified against:** `selection.json` field `greeting_sha256` — match confirmed.

The function returns exactly the string `Hello rehearsal`.

## Operations performed

### 1. Service status check
- **Record:** `work/status-record.json`
- **Outcome:** Service ready, authority mode `sandbox-projection`, test_copy true.
- **Component verification:** All components (client, evaluator, database, plugins, protocols)
  match the combination report `combination.json`.

### 2. Import source (key: import-src-001)
- **Record:** `work/import-record.json`
- **Evidence:** `work/import-record.json.evidence/`
- **Result:** 7 artifacts imported (INT-P3-900, CAP-P3-900, REQ-P3-900, SPEC-P3-900,
  VER-P3-900, WO-P3-900, REL-P3-900). Outcome: accepted.
- **Baseline:** `se-harness-artifact-baseline/v1:sha256:d8e2aaec6cc0e3774d2977381f580e359eeb6da3d3c85b0f7034558490ec14ab`
- **Project version:** 0 → 1
- **Receipt:** `f1ce2021-eb39-4de4-a2aa-6c5e78ae292f`

### 3. Open draft context (key: draft-open-001)
- **Record:** `work/draft-open-record.json`
- **Evidence:** `work/draft-open-record.json.evidence/`
- **Context ID:** `a7ee3d89-6a07-4e7d-b4ac-a99dbc88d73a`
- **Context version:** 0
- **Project version:** 1 → 2
- **Work order:** WO-P3-900
- **Receipt:** `caf9ffd8-12ae-495f-9e9a-1dbd471f979e`

### 4. Create intent artifact (key: create-int-001)
- **Record:** `work/create-intent-record.json`
- **Evidence:** `work/create-intent-record.json.evidence/`
- **Artifact:** INT-P3-001
- **Template revision:** `sha256:731794d2ce94b4364ae0b502292fb80a47bc4f36eedc3f99b1c228bbab13a957`
- **Template document:** `work/create-intent-record.json.evidence/2-document-1.md`
- **Context version:** 0 → 1
- **Project version:** 2 → 3
- **Receipt:** `301f4bbb-7752-4b76-ae61-5626e3a5e11c`

### 5. Revise intent artifact (key: revise-int-001)
- **Record:** `work/revise-intent-record.json`
- **Evidence:** `work/revise-intent-record.json.evidence/`
- **Artifact:** INT-P3-001
- **Final revision:** `sha256:ff7cbd4ab2d6807bbe1e15732957135ccf5c963a6a4df935e291d1c76d89105c`
- **Completed document:** `work/INT-P3-001-draft.md`
- **Context version:** 1 → 2
- **Project version:** 3 → 4
- **Receipt:** `0f43d693-849d-47eb-b3aa-07e19846f66b`

## Draft validation findings

- **Admissible:** true
- **Errors:** 0
- **Incomplete fields:** 0
- **Background advisories:** 1 (pre-existing: W-AUT-022 on SPEC-P3-900 referencing
  undefined rule P3-GREET-900 — unrelated to INT-P3-001)

## Instruction discovery

### Sections read
1. `DRAFT_DEFINITIONS.md#Read this when` — confirmed the task needs a definition.
2. `DRAFT_DEFINITIONS.md#Before this action` — identified prerequisites.
3. `ARTIFACT_AUTHORING.md#design-simplicity` — design simplicity principles applied.
4. `ARTIFACT_AUTHORING.md#intent` — intent checklist applied.
5. `ARTIFACTS.md#artifact-types` and `#artifact-locations` — read via native Read
   (instruction reader failed on ARTIFACTS.md with a Unicode decode error).
6. `DRAFT_DEFINITIONS.md` full file — read via native Read to find section structure.

### Intent checklist compliance
- Explained the present problem (no formal intent for greeting()'s return value),
  who it affects (operators needing traceability), and the outcome wanted.
- Smallest useful outcome: verified record that greeting() returns exactly `Hello rehearsal`.
- Success measure: greeting() returns exactly `Hello rehearsal`; baseline: not measured.
- Scope limits: does not cover changing the text, other functions, or runtime performance.

## Failures and limits

1. **Instruction reader Unicode error:** `instructions --section` failed for
   `ARTIFACTS.md#artifact-types` and `#artifact-locations` with UnicodeDecodeError
   (`'utf-8' codec can't decode byte 0x93`). Worked around by reading ARTIFACTS.md
   directly with native Read.
2. **No complete NQ-01–05 claim:** Lifecycle, MCP parity, reply recovery and export
   are outside this focused diagnostic scope.
3. **No approval or lifecycle advancement:** Draft INT-P3-001 remains in `draft` status.
   No freeze, approval, or work start was performed.

## Evidence paths

All records and evidence are under `work/`:
- `work/status-record.json` — service status
- `work/import-record.json` + `.evidence/` — import result
- `work/draft-open-record.json` + `.evidence/` — draft context
- `work/create-intent-record.json` + `.evidence/` — artifact creation + template
- `work/revise-intent-record.json` + `.evidence/` — final revision
- `work/INT-P3-001-draft.md` — completed document submitted
- `work/progress-note.md` — transient progress tracker
