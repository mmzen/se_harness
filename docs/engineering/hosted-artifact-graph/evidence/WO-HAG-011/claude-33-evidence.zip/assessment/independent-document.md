+++
id = "VER-P3-901"
type = "verification"
title = "Alternative exact greeting assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"

[relations]
verifies = ["REQ-P3-900"]
+++

# Alternative exact greeting assertion

## Independence

The expected value `Hello rehearsal` is fixed by REQ-P3-900 acceptance criteria, not derived from candidate output or implementation source.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-900 | test | Call `greeting()` and compare the return value to the expected string. | `greeting()` returns exactly `Hello rehearsal`. |

## Acceptance scenarios

1. Import `greeting` from `src/greeting.py`.
2. Call `greeting()` with no arguments.
3. Assert that the return value equals the string `Hello rehearsal`.

Platform: Python 3.11 or later.
Evaluator: se_harness 0.22.1.

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-900/ver-p3-901-assertion.json`, recording the actual return value, the expected value, the pass/fail outcome, the Python version, and the timestamp.

## Residual uncertainty

None identified. The requirement specifies a single fixed return value with no variability.
