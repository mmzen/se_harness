+++
id = "INT-P3-001"
type = "intent"
title = "Establish that the rehearsal greeting fixture returns the expected output"
status = "draft"
owners = ["test-owner"]
created = "2026-10-09"
updated = "2026-10-09"
outcome = "The test operator can confirm that greeting() produces exactly Hello rehearsal."

[relations]
+++

# Intent: Establish that the rehearsal greeting fixture returns the expected output

## In plain words

A test operator needs recorded agreement that the `greeting()` function in `src/greeting.py` returns the exact string `Hello rehearsal`. This intent supports a disposable lifecycle rehearsal and does not govern a real product.

## Problem

The lifecycle rehearsal uses a fixture function `greeting()` in `src/greeting.py`. Without an explicit intent, there is no recorded agreement on what output this fixture should produce or who is responsible for confirming it. The test operator needs this agreement before downstream verification and work-order preparation can reference a defined purpose.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| Recorded agreement that greeting() returns Hello rehearsal | not measured | Agreement recorded in this intent | Lifecycle rehearsal review, once |

## Not this

- Changing the fixture implementation or its return value.
- Running a production release based on this fixture.
- Replacing or extending the existing INT-P3-900 intent.
- Automated operational monitoring of the fixture.
- Executing verification or test runs against the fixture.
