"""Retain exact bounded setup and observation drivers; omit private auth logs."""
import json,zipfile,hashlib,re
import hag_efficiency_plan as p
O=p.W/'hag-boundary-correction35-20261011';E=p.D/'evidence/WO-HAG-009/boundary35-result'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
drivers=['hag_correction35.py','hag_full35.py','hag_focus35_task.txt','hag_full27.py','hag_native27.py','hag_efficiency_package03.py','hag_package35_review.py','hag_parity35.py','hag_native_parity19.py','hag_review35.py','hag_full27_review.py','hag_trace35.py','hag_full27_trace.py','hag_full35_facts.py','hag_retain35.py','hag_retain26.py','hag_provenance35.py','hag_watch35.py','hag_assess35.py']
for name in drivers:files['drivers/'+name]=(p.W/name).read_bytes()
for name in ['candidate-35','package-guidance-comparison','service-reuse-comparison','server-wheel-members','client-build-35','package-35','client-env-35','client-install-35','build35-replay','context-WO-HAG-009','context-WO-HAG-011']:
 files['checks/'+name+'.json']=(O/(name+'.json')).read_bytes()
for f in O.glob('claude301-*.json'):
 if 'live-probe' not in f.name:files['setup/'+f.name]=f.read_bytes()
for name in ['combination','image-metadata','image-package','plugin-assembly','plugin-claude-inventory','plugin-codex-inventory','server-build','source-commit','source-status']:
 files['package/'+name+'.json']=(O/'package35'/(name+'.json')).read_bytes()
tokens=[x['token'].encode() for f in O.glob('*/credentials.json') for x in load(f)['principals']]
for name,raw in files.items():
 assert not any(t in raw for t in tokens),name
 assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
with zipfile.ZipFile(E/'provenance.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
index={'archive':'provenance.zip','sha256':sha((E/'provenance.zip').read_bytes()),'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())],'limits':'No raw provider auth, private reasoning, credentials, account stores or full environments. Exact known test tokens checked absent.'}
(E/'provenance-inventory.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());print(len(files),'files')
