"""Clarify the existing query and reporting contracts under WO-HAG-009/011."""
import hashlib,json,os,re,subprocess,sys,tempfile,tomllib,zipfile
from pathlib import Path
import hag_efficiency_plan as p
W,R,D=p.W,p.R,p.D;O=W/'hag-boundary-correction35-20261011';p.O=O
E=D/'evidence/WO-HAG-009/boundary35';H=Path('C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe')
changed=['tests/hosted_artifact_graph/'+n for n in ['native_call.py','test_native_support.py','native-tools.md']]
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,encoding='utf-8').strip()
def put(f,v):
 assert not f.exists(),f
 f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
mode=sys.argv[1]
if mode=='scope':
 groups={'WO-HAG-009':changed+[(E/n).relative_to(R).as_posix() for n in ['review.md','checks.zip','inventory.json']]}
 for ident,paths in groups.items():
  args=['check',R,'--artifact',ident,'--checkpoint','scope','--changes-complete']
  for path in paths:args+=['--changed-path',path]
  v=p.gov(ident+'-scope35',*args,'--json');assert v['compliance']['status']=='pass';print(ident,'scope pass',flush=True)
elif mode=='test':
 for name in changed:
  if not name.endswith('.md'):continue
  f=R/name
  for link in re.findall(r'\]\(([^)]+)\)',f.read_text()):
   path,_,anchor=link.partition('#');target=(f.parent/path).resolve();assert target.is_file()
   if anchor:assert re.search(r'^#+ '+re.escape(anchor.replace('-',' '))+r'\s*$',target.read_text(),re.M|re.I)
 scratch=Path('C:/Users/mathi/AppData/Local/Temp/hag34');scratch.mkdir(exist_ok=True);os.environ.update(TEMP=str(scratch),TMP=str(scratch));tempfile.tempdir=str(scratch)
 for label,args in [('focused-final',[H,'-X','utf8','-B','-m','unittest','discover','-s','tests/hosted_artifact_graph','-p','test_native*.py']),('source',[H,'-X','utf8','-B','scripts/run_tests.py']),('distribution',[H,'-X','utf8','-B','scripts/validate_release_distributions.py','--root','.']),('smoke',[H,'-X','utf8','-B','-m','se_harness','--help'])]:
  p.run(label,args,cwd=R);x=load(O/(label+'.json'));print(label,x['exit'],round(x['elapsed_seconds'],1),flush=True)
elif mode=='check':
 for ident in ['WO-HAG-009','WO-HAG-011']:
  v=p.gov(ident+'-preflight35','preflight',R,'--work-order',ident,'--phase','review','--json');assert v['ready'];print(ident,'preflight pass',flush=True)
 v=p.gov('validation','validate',R,'--json');assert v['error_count']==0;print('validation pass',flush=True)
elif mode=='commit':
 previous='9a18a8aae94456748482b9bd6b3f11324478c6ec';assert git('rev-parse','HEAD')==previous
 assert sorted(git('diff','--name-only').splitlines())==sorted(changed)
 names=['focused-retry','source','distribution','smoke','WO-HAG-009-scope35','WO-HAG-009-preflight35','WO-HAG-011-preflight35','validation','retained-boundary-check']
 assert all(load(O/(n+'.json'))['exit']==0 for n in names)
 E.mkdir(exist_ok=False)
 with zipfile.ZipFile(E/'checks.zip','x',zipfile.ZIP_DEFLATED) as z:
  for n in ['focused']+names:z.write(O/(n+'.json'),n+'.json')
 put(E/'inventory.json',{'archive':'checks.zip','sha256':sha((E/'checks.zip').read_bytes()),'files':[{'path':n+'.json','sha256':sha((O/(n+'.json')).read_bytes())} for n in ['focused']+names]})
 put(E/'review.md',(O/'review.md').read_text())
 paths=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
 scopes=[]
 for ident in ['WO-HAG-009','WO-HAG-011']:scopes+=tomllib.loads((D/'work-orders'/f'{ident}.md').read_text().split('+++')[1])['execution_scope']['paths']
 assert all(x in changed or x.startswith(E.relative_to(R).as_posix()+'/') for x in paths)
 assert all(any(x==s or s.endswith('/') and x.startswith(s) for s in scopes) for x in paths)
 p.run('diff-check',['git','diff','--check'],cwd=R);p.run('stage',['git','add','--',*paths],cwd=R);p.run('staged-check',['git','diff','--cached','--check'],cwd=R)
 p.run('commit',['git','commit','-m','Constrain native test outputs to the selected work directory','-m','Harness-Work-Order: WO-HAG-009'],cwd=R)
 assert not git('status','--porcelain');put(O/'candidate-35.json',{'commit':git('rev-parse','HEAD'),'base':'55caaada508495bea7d97effd27644d1ce8373da'});print(git('rev-parse','HEAD'))
elif mode=='build':
 source=(W/'hag_efficiency_package03.py').read_text().replace('hag-efficiency-proposal-20261008','hag-boundary-correction35-20261011')
 for a,b in [('candidate-03','candidate-35'),('build03','build35'),('package03','package35'),('client03','client35'),('native-efficiency03','native-boundary35'),("-03'","-35'")]:source=source.replace(a,b)
 exec(compile(source,'exact-build35','exec'))
else:raise ValueError(mode)
