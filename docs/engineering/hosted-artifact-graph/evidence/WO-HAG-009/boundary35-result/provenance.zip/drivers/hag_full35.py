"""Native diagnostic first; full qualification only after its independent pass."""
import json,sys,hashlib
from pathlib import Path
W=Path(__file__).parent
mode=sys.argv[1];host=sys.argv[2] if len(sys.argv)>2 else None;trial=sys.argv[3] if len(sys.argv)>3 else '301'
diagnostic=mode.startswith('diagnostic-');actual=mode.removeprefix('diagnostic-')
O=W/'hag-boundary-correction35-20261011';root=O/(host+'-'+trial) if host else O
if actual=='run':
 assert json.loads((O/'package-guidance-comparison.json').read_text())['candidate']==json.loads((O/'candidate-35.json').read_text())['commit']
source=(W/'hag_full27.py').read_text()
source=source.replace('hag-lifecycle-native27-20261010','hag-boundary-correction35-20261011').replace('hag-lifecycle-correction27-20261010','hag-boundary-correction35-20261011')
source=source.replace("trial='221'",'trial='+repr(trial)).replace("host+'-221-boundary-probe.json'","host+'-"+trial+"-boundary-probe.json'")
for a,b in [('candidate-27','candidate-35'),('package27','package35')]:source=source.replace(a,b)
source=source.replace("source=(W/'hag_native27.py').read_text()", "source=(W/'hag_native27.py').read_text().replace('hag-lifecycle-native27-20261010','hag-boundary-correction35-20261011').replace('hag-lifecycle-correction27-20261010','hag-boundary-correction35-20261011').replace('package27','package35').replace('client27','client35').replace('build27','build35').replace('native-lifecycle27','native-boundary35').replace('hag-full27-','hag-full35-')")
source=source.replace("host+'-version'","host+trial+'-version'").replace("host+'-live-probe'","host+trial+'-live-probe'").replace("host+'-auth'","host+trial+'-auth'").replace("host+'-auth-review.json'","host+trial+'-auth-review.json'")
source=source.replace("host+'-live-probe.json'","host+trial+'-live-probe.json'")
source=source.replace(".replace('hag-full27-','hag-full35-')", ".replace('hag-full27-','hag-full35-').replace('10.231.84.0/22','10.231.88.0/22')")
source=source.replace("'--timeout','1800'", "'--timeout','1200'" if diagnostic else "'--timeout','3600'")
if diagnostic:source=source.replace(",'--drop-reply'",'')
sys.argv=[__file__,actual,host,trial]
exec(compile(source,'native31-preparation-and-run','exec'),{'__file__':str(W/'hag_full27.py'),'__name__':'__main__'})

if mode=='diagnostic-stage':
 native=root/'native'
 from qualify_agents import shell_prefix
 selection=json.loads((root/'native-selection.json').read_text())
 task=(W/'hag_focus35_task.txt').read_text().replace('NATIVE_ROOT',str(native)).replace('APPROVED_HELPER_PREFIX',shell_prefix(selection['approved_shell_argv_prefix']))
 (root/'native-task.md').write_bytes(task.encode())
 proof=json.loads((root/'stage-evidence.json').read_text());proof.update(case='Focused NQ-01/NQ-03 diagnostic through handoff; not a full lifecycle qualification',task_sha256=hashlib.sha256(task.encode()).hexdigest(),limits='Fresh project and unchanged canonical fixture. Agent authors its own definitions and requests. No supplied query, completed request, draft answer, workflow sequence or direct operator mutation. No VREC, release, risk or export requested; full qualification remains separate.')
 (root/'stage-evidence.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
 print('Focused refusal/procedure diagnostic staged')
