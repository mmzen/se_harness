+++
id = "CAP-P3-001"
type = "capability"
title = "Inspect the rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
ability = "The test operator can inspect greeting() and confirm its exact return value."

[relations]
derives_from = ["INT-P3-001"]
+++

# Capability: Inspect the rehearsal greeting

## In plain words

The operator reads the return value of the greeting function from the test
fixture and compares it against the specified string.

## Actor and need

The test operator needs to call greeting() from the source fixture and observe
its return value. This confirms that the function produces the expected output
without modifying the source.

## Not decided here

- The exact verification method or tooling.
- Evidence format or retention location.
