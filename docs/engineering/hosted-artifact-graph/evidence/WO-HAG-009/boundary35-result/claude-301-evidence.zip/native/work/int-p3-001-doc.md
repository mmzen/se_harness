+++
id = "INT-P3-001"
type = "intent"
title = "Verify the rehearsal greeting output"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
outcome = "The test operator confirms that greeting() returns exactly Hello rehearsal."

[relations]
+++

# Intent: Verify the rehearsal greeting output

## In plain words

An operator inspects the existing fixture's greeting function and proves that it
returns the exact string `Hello rehearsal`.

## Problem

The synthetic test fixture provides a greeting function. Without an independent
verification step, no evidence confirms that the function produces its specified
output. The operator needs a recorded assertion.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| Greeting assertion passes with exact match | not measured | greeting() equals Hello rehearsal | Retained assertion evidence in work-order evidence directory |

## Not this

- Changing the greeting function or its return value.
- Creating a real product release.
- Modifying any -900 series reference artifacts.
