+++
id = "REQ-P3-001"
type = "requirement"
title = "Return the exact rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
statement = "Calling greeting() returns the string Hello rehearsal."
verification_method = ["test"]
priority = "must"
source = "INT-P3-001"
measure = "exact string match"

[relations]
derives_from = ["CAP-P3-001"]
+++

# Requirement: Return the exact rehearsal greeting

## In plain words

The greeting function in the test fixture returns exactly `Hello rehearsal`
every time it is called.

## Why

The operator needs a fixed, predictable return value to verify the lifecycle
rehearsal procedure. A deterministic greeting enables an exact-match assertion.

## Behavior

| Trigger | Response | On failure |
| --- | --- | --- |
| Caller invokes greeting() | Returns the string `Hello rehearsal` | Not applicable; the function has no failure path |

## Examples

### Normal

**Given** the source fixture at `src/greeting.py` is unchanged.

**When** an operator calls `greeting()`.

**Then** the return value equals `Hello rehearsal`.
