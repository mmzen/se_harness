+++
id = "VER-P3-001"
type = "verification"
title = "Assert the exact greeting return value"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"

[relations]
verifies = ["REQ-P3-001"]
+++

# Verification Contract: Assert the exact greeting return value

## Independence

The expected value `Hello rehearsal` derives from REQ-P3-001 and SPEC-P3-001
rule P3-GREET-001. The pass condition is fixed by definition, not by candidate
output.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-001 | inspection | Source inspection of greeting() return value | The return expression equals the string `Hello rehearsal` |
| REQ-P3-001 | test | Exact greeting assertion | `greeting()` returns exactly `Hello rehearsal` |

## Acceptance scenarios

**Given** the source fixture `src/greeting.py` at the verified commit,
**when** greeting() is called,
**then** the return value equals `Hello rehearsal`.

## Evidence retention

Retain the assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json`.

The evidence file records the actual return value, the expected value, the
comparison result, and the source commit identity.
