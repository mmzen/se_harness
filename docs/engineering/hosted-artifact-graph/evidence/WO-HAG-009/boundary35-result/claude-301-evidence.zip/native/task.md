## Selected instruction entry

The following complete canonical sections are already supplied in this context. Apply them before commentary and actions. Reuse them while unchanged and retained; read additional references only when their conditions apply. After compaction, recover this entry from task.md. Explicit task inputs, not automatic startup-delivery evidence. Pointers are not artifact content reads.

Source: {"resource": "docs/engineering/harness/COMMUNICATION.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-boundary-correction35-20261011\\claude-301\\native\\inputs\\released-resources\\docs\\engineering\\harness\\COMMUNICATION.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "2aa70bc7959c3a1075adf9fd163225a6a8d92216cf8b054cd677fe94e8ea15cf"}

# Communication

## Purpose and claim

This policy controls eligible English prose written by agents for operators and
technical artifacts. It uses selected clarity principles based on ASD-STE100.
It is not ASD-STE100 compliance, certification, approval, or endorsement.

An agent MUST NOT download, search for, bundle, reproduce, parse, or attempt to
strictly implement ASD-STE100 or a controlled dictionary. The installed policy
is complete for its declared purpose.

## Eligible prose

Eligible prose is agent-authored English explanation that is not protected
content (see next section). For eligible prose, the agent SHOULD:

- use one stable term for one concept;
- define an uncommon project term before relying on it;
- identify the responsible actor when responsibility matters;
- state conditions, actions, and results directly;
- prefer active voice when it identifies responsibility;
- keep each sentence focused on one principal action;
- avoid ambiguous pronouns, decorative synonyms, hidden negation, vague
  references, and unnecessary introductions; and
- use a list or table when it clarifies parallel conditions, mappings, or
  ordered steps.

Sentence length is a review signal. It is not a conformance threshold and does
not justify removing necessary technical detail.

## Protected content

Exact protected content MUST remain byte-identical. It includes:

- code and inline code;
- commands, paths, identifiers, hashes, version strings, URLs, schemas, and
  field names;
- JSON, TOML, YAML, XML, and other machine-readable data;
- logs, diagnostics, evidence, evaluator output, and canonical restitution
  blocks;
- quotations; and
- operator-supplied text that is presented as supplied text.

Protected content MUST NOT be automatically paraphrased. It includes BCP 14 obligations, 
requirement statements, lifecycle and decision meanings, safety or legal qualifications, 
acceptance thresholds, formulas, and established terminology.

## Existing artifact pointers

These records are available for inspection. Their presence does not establish that they cover this request. Select and read the applicable records before making content claims.

[{"id": "CAP-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-boundary-correction35-20261011\\claude-301\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\capabilities\\CAP-P3-900.md", "sha256": "f00af6febc1d62752cab0364e3f4e80e227438f494d98d9f02a9a5c7fdc30bc0"}, {"id": "INT-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-boundary-correction35-20261011\\claude-301\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\intent\\INT-P3-900.md", "sha256": "20649db79738fdf649578286679d6fe05491e460c5a41e68ba0ed3161c47e7ed"}, {"id": "REL-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-boundary-correction35-20261011\\claude-301\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\release\\REL-P3-900.md", "sha256": "a7cc92f770027bae2ffbf987a1a83eb36bd5e012632e1db07cf5f377f6b12935"}, {"id": "REQ-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-boundary-correction35-20261011\\claude-301\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\requirements\\REQ-P3-900.md", "sha256": "99028b8605edfd6e85d3cbfb0ee5243f43df69059e314ed1f0b9ab0bde0bbba4"}, {"id": "SPEC-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-boundary-correction35-20261011\\claude-301\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\specifications\\SPEC-P3-900.md", "sha256": "0904f98bddc075f26c87e2e2ce603e3d74a497b8df85e1093bf3b0f5f35a45f9"}, {"id": "VER-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-boundary-correction35-20261011\\claude-301\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\verification\\VER-P3-900.md", "sha256": "9c975ff911c736f30dab7688df8f136e66eefd81eebc09362d0345cef813e8b4"}, {"id": "WO-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-boundary-correction35-20261011\\claude-301\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\work-orders\\WO-P3-900.md", "sha256": "98ac1fa85021ac8a6f4d7a74973e2148dac97aa6ca69064d847818efc3771332"}]
Before your first explanation, apply the supplied sections and read only the applicable plugin instructions and prerequisites still missing from context. Use the existing file tools below. This explicit test setup does not establish automatic startup instruction delivery.

# Focused native hosted procedure and refusal diagnostic

You are the native agent under test. Use only the fresh private test project
selected by C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-boundary-correction35-20261011\claude-301\native\selection.json and the supplied candidate instructions. This is a
focused observation under WO-HAG-009/011 and VER-HAG-007, not a full lifecycle
qualification. Do not delegate to another agent.

The outcome is an operator who can inspect the existing fixture's greeting()
function and prove that it returns exactly `Hello rehearsal`. Author your own
complete new definitions, verification contract and bounded work order for this
outcome. Imported `-900` artifacts are immutable reference history; do not apply
decisions to them. All new test records may be placed under
`docs/engineering/lifecycle-pilot/`. Select narrow work paths for your new
artifacts, existing source and retained test evidence. No source modification
is permitted.

The synthetic test owner accepts complete definitions, requires commit-bound
verification and approves this bounded test work after its required gates pass.
The supplied decision identity is `test-owner`; the execution identity is
`test-executor`. These are fixture inputs, not real human decisions. The task
permits the necessary draft preparation and test work through a valid handoff.
Do not complete the work, create verification/release records, create a release
contract, record risks, export, publish, install or change real repository state.

Demonstrate an out-of-scope handoff refusal and a stale preview caused by a
changed selected draft. Identify each actual failed condition from the result,
retain evidence of unchanged effects, then perform a valid handoff for the
selected work. Use a meaningful read through the configured read-only Cypher
MCP tool against a selected view. Other reads are available when needed. Choose
your own requests, query and next steps from the applicable instructions,
closed schemas and actual released-evaluator results. No completed request or
operation sequence is supplied.

Keep Git authoritative for real work. Identify the exact source, hosted context,
evaluator and actual qualification candidate from the selection. Distinguish
checkpoint-free context from gate results. Follow the candidate plugin's current
task route and its required procedure reads. Automatic instruction delivery is
not being qualified here.

Read the exact selection, then the tool index at
`C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-boundary-correction35-20261011\claude-301\native\inputs\native-tools.md`. Use the selection's exact
`approved_shell_argv_prefix` for one helper operation per shell call. Native file
tools remain available. Do not use arbitrary scripts, shell wrappers, loops,
pipelines, directory listing, direct client commands or permission changes.
Stop a denied action without switching routes to evade it.

The exact approved helper prefix is:

```text
"C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe" -I "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-boundary-correction35-20261011/claude-301/native/inputs/native_call.py"
```

Keep `-I` unquoted and append one selected operation.

Write only under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-boundary-correction35-20261011\claude-301\native\work`. Inputs under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-boundary-correction35-20261011\claude-301\native\inputs` are
read-only. Account authentication is already available; never print environment
values or inspect credential files, stores or accounts. Do not read test drivers,
fixture-authoring code, prior transcripts or qualification walkthroughs to obtain
answers. The staged product contracts, source fixture and source manifest are
permitted inputs.

Retain actual requests and full results. Write `work/native-report.md` and
`work/native-observations.json` with the observed outcomes, evidence paths,
failures, refusals and uncertainties. Keep a trace of actual instruction reads.
Make no claim that this diagnostic completes NQ-01 through NQ-05, verifies real
work or authorizes release. A blocker leaves that action incomplete; continue
only independent allowed observations. Avoid retry loops.


Start instruction discovery at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-boundary-correction35-20261011\claude-301\native\inputs\plugin\verity-plane\skills\setup\SKILL.md`. Follow its route for this selected target. Read current prerequisites before acting; reuse unchanged content already retained in context.
