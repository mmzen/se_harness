+++
id = "SPEC-P3-001"
type = "specification"
title = "Fixed rehearsal greeting behavior"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
contract = "The greeting() function returns the exact string Hello rehearsal with no side effects."

[relations]
specifies = ["REQ-P3-001"]
+++

# Specification: Fixed rehearsal greeting behavior

## In plain words

The greeting function returns a fixed string. It takes no arguments and produces
no side effects.

## Scope

This specification governs the return value of the `greeting()` function in
`src/greeting.py`. It does not govern the calling context, evidence format, or
verification tooling.

## Rules

**P3-GREET-001.** The function `greeting()` MUST return the string `Hello rehearsal`.

**P3-GREET-002.** The function `greeting()` MUST NOT produce side effects.

## Failure behaviour

| Trigger | Response | Diagnostic |
| --- | --- | --- |
| greeting() returns a different string | Verification assertion fails | Exact mismatch reported |

## Examples

**Given** the source fixture `src/greeting.py` is unmodified, **when** an
operator calls `greeting()`, **then** the return value equals `Hello rehearsal`
per P3-GREET-001.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-001 | P3-GREET-001, P3-GREET-002 |

## Not decided here

- How the assertion is executed or retained.
- The calling environment or runtime version.
