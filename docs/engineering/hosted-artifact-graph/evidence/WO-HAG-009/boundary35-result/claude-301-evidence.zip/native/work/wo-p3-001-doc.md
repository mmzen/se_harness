+++
id = "WO-P3-001"
type = "work_order"
title = "Verify the rehearsal greeting fixture"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"

[assurance]
commit_bound_verification = "required"
rationale = "The greeting assertion establishes the fixture's correctness for downstream test decisions."
decided_by = "test-owner"

[execution_scope]
paths = ["src/greeting.py", "docs/engineering/lifecycle-pilot/"]

[relations]
implements = ["REQ-P3-001"]
specifications = ["SPEC-P3-001"]
verification = ["VER-P3-001"]
+++

# Work Order: Verify the rehearsal greeting fixture

## Objective

Confirm that the existing `greeting()` function returns exactly `Hello rehearsal`
and retain the assertion evidence.

## In scope

- Source inspection of `src/greeting.py`.
- Execution of the exact greeting assertion per VER-P3-001.
- Evidence retention under `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/`.

## Out of scope

- Modifying the greeting function or its return value.
- Creating a real release contract or release record.
- Modifying any -900 series reference artifacts.
- Real human decisions or external actions.

## Authorized decision envelope

The executor may choose the assertion method and format the evidence file.
The executor may not change source code, approve definitions, or create
release records.

## Constraints

No source modification is permitted. All actors are synthetic test labels.

## Expected change surface

| Path | Reason |
| --- | --- |
| `src/greeting.py` | Read-only inspection target |
| `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json` | Assertion result evidence |

## Required verification

Run VER-P3-001: call `greeting()` and assert the return value equals
`Hello rehearsal`. The expected value derives from REQ-P3-001 and SPEC-P3-001
rule P3-GREET-001.

## Evidence to record

Retain `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json`
with the actual value, expected value, comparison result, and source commit.

## Stop and escalate conditions

Stop when the released evaluator refuses an operation or when the greeting
function returns an unexpected value.

## Completion report format

State the assertion result, the verified commit identity, the retained evidence
path, and any limitations or next accountable decision.
