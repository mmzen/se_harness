# Native Hosted Procedure and Refusal Diagnostic Report

Diagnostic: WO-HAG-009/011 and VER-HAG-007
Date: 2026-10-11
Decision identity: test-owner | Execution identity: test-executor
Project ID: 8068d8f8-f655-42d1-9906-ca08402446bf
Draft context: 48cea7e7-2509-42a9-8eb5-bafbb9f09322
Authority mode: sandbox-projection, test_copy: true

This diagnostic does NOT complete NQ-01 through NQ-05, verify real work, or authorize release.

## Source verification

File: `src/greeting.py`
SHA-256: `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`
Source commit: `5820415917e87b64d80bad2f7c39c6d18d692829`

The function `greeting()` returns exactly `'Hello rehearsal'`. Confirmed by reading the source file content through the `read-text` helper, matching the SHA-256 recorded in `selection.json`.

## Artifacts authored

Six definition artifacts were created and revised in draft context 48cea7e7:

| Artifact    | Type          | Document file              | Create record     | Revise record      |
|-------------|---------------|----------------------------|--------------------|---------------------|
| INT-P3-001  | Intent        | int-p3-001-doc.md          | create-int-001     | revise-int-001      |
| CAP-P3-001  | Capability    | cap-p3-001-doc.md          | create-cap-001     | revise-cap-001      |
| REQ-P3-001  | Requirement   | req-p3-001-doc.md          | create-req-001     | revise-req-001      |
| SPEC-P3-001 | Specification | spec-p3-001-doc.md         | create-spec-001    | revise-spec-001     |
| VER-P3-001  | Verification  | ver-p3-001-doc.md          | create-ver-001     | revise-ver-001      |
| WO-P3-001   | Work Order    | wo-p3-001-doc.md           | create-wo-001      | revise-wo-001       |

All six created as drafts (project v2-v13), then approved in a single batch transition (project v15->v16).

## Lifecycle transitions

### Approval (batch transition)
- Preview: approve-preview-001 (project v13/context v11) -> initially previewed
- INT-P3-001 revised to v2 to demonstrate stale preview (revise-int-002, project v14->v15)
- Re-preview: approve-preview2-001 (project v15/context v13) -> previewed
- Apply: approve-apply-001 (project v15->v16, context v13->v14, receipt `sha256:30295cc9...`)

### WO-P3-001 start (transition to in_progress)
- Preview: start-preview-001 (project v16/context v14) -> previewed
- Apply: start-apply-001 (project v16->v17, context v14->v15, receipt `sha256:1c23d4bb...`)

### Handoff (implementation evidence)
- Preview: handoff-preview-001 (project v17/context v15) -> previewed with digest `sha256:16a1271b...`
- Apply: handoff-apply-001 (project v17->v18, context v15->v16, receipt `sha256:2f188ca8...`)
- Evidence file: `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json`
- Evidence SHA-256: `c96fc22e9c97f56a84415eccc69c4ddbc0a2eaed61f639edce405db9a2299638`

## Required demonstrations

### 1. Stale preview refusal (DEMONSTRATED)

Record: `work/approve-stale-apply-001`
Trigger: After previewing approval at context v12/project v14, revised INT-P3-001 (advancing to context v13/project v15), then attempted to apply the old preview_digest.
HTTP status: 409
Error code: `HAG_REMOTE_STALE_PREVIEW`
Message: "Apply needs a preview bound to these exact inputs."
Resolution: Performed a fresh preview at the current versions, then applied successfully.

### 2. Out-of-scope handoff refusal (DEMONSTRATED)

Record: `work/handoff-oos-001`
Trigger: Attempted handoff targeting WO-P3-900 (an imported `-900` artifact from reference history).
HTTP status: 422
Error code: `HAG_REMOTE_PROTECTED_FIELD`
Message: "Imported records cannot receive rehearsal decisions or evidence."
Resolution: Stopped the denied action without switching routes. Proceeded with the valid WO-P3-001 handoff instead.

### 3. Cypher MCP read (DEMONSTRATED)

Tool: `mcp__hag__cypher`
Query: `MATCH (a:Artifact {artifact_id: 'WO-P3-001'})-[r:DECLARES]->(t:Artifact) RETURN a.artifact_id, type(r), t.artifact_id LIMIT 10`
Result: Confirmed WO-P3-001 declares relations to REQ-P3-001, SPEC-P3-001, and VER-P3-001.
The query used one MATCH path with labeled nodes and edges, RETURN and LIMIT, as required by the admitted Cypher form.

### 4. Valid handoff (DEMONSTRATED)

Record: `work/handoff-apply-001`
WO-P3-001 handoff accepted with assertion evidence proving `greeting()` returns `'Hello rehearsal'`.
Receipt: `sha256:2f188ca86480e70dde88ae122adb1110d2bb3f7441077dcd7492d5035591f3d6`
Output git head: `f6b6d906c3373f9680abd87ed3798d14ef65ccc1`
Final project version: 18, context version: 16.

## Instruction reads trace

The following released instruction sections were read during this diagnostic:

| File | Section(s) read |
|------|-----------------|
| DRAFT_DEFINITIONS.md | read-this-when, before-this-action, draft-any-missing-definitions, define-how-the-result-will-be-verified |
| ARTIFACT_AUTHORING.md | intent, design-simplicity, verification, work_order |
| ARTIFACTS.md | artifact-types, artifact-locations |
| DEFINITION_LINKS.md | links-between-definitions |
| DRAFT_WORK_ORDERS.md | prepare-work-orders... |
| AUTHORIZE_WORK.md | apply-the-selected-transitions |
| EXECUTE_WORK.md | start-the-selected-work, retain-the-implementation-evidence |
| COMMUNICATION.md | (via task.md) |

Reference materials also read: hosted-context.md, hosted-drafts.md, hosted-reads.md, hosted-test-lifecycle.md, hosted-artifact-graph.md, lifecycle-v2.md, and all -900 reference artifacts.

## Evidence paths

All evidence files are under `work/`:
- `work/assertion.json` — assertion evidence (SHA-256: c96fc22e...)
- `work/handoff-apply-001.stdout.txt` — accepted handoff full response
- `work/handoff-oos-001.stdout.txt` — protected field refusal response
- `work/approve-stale-apply-001.stdout.txt` — stale preview refusal response
- `work/observations-001` — observation trace snapshot (81 native calls)

## Failures and errors

Two intentional refusals (stale preview and out-of-scope handoff) were demonstrated as required.
Two `instructions` helper calls failed with `ValueError` when using `reference/` paths; resolved by using `find-file` + native `Read` instead.

## Uncertainties

- The observation snapshot shows `wall_seconds: null` because the session is still in progress.
- Goals `calls_at_most_15` and `peak_under_40000` were missed (81 calls, peak 163700 tokens). These are efficiency targets, not correctness gates.
- This diagnostic operated entirely within `test_copy: true` / `sandbox-projection` authority. No real repository state was changed.
