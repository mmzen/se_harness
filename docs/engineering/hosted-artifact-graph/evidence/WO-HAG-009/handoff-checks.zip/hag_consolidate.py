import hashlib, json, subprocess, sys, zipfile
from pathlib import Path
import hag_efficiency_plan as p

W,R,D=p.W,p.R,p.D
O=W/'hag-handoff-closeout';p.O=O
E=D/'evidence/WO-HAG-009';E10=D/'evidence/WO-HAG-010'
BASE='55caaada508495bea7d97effd27644d1ce8373da'
HEAD='9fc3f4e2aa857e32ead50da8fa00fdca8e5e639a'
C44='2f6ecb1433ef98cf643e0f604ed2c4258a2261e2'
IPK='039443f333bea8aaa135526a99d7d4ead9c1e295'
def load(f):return json.loads(f.read_bytes())
def put(f,x):f.write_bytes(((x if isinstance(x,str) else json.dumps(x,ensure_ascii=False,indent=2))+'\n').encode('utf-8'))
def digest(b):return hashlib.sha256(b).hexdigest()
def fact(f):
 b=f.read_bytes();return {'path':f.relative_to(R).as_posix(),'bytes':len(b),'sha256':digest(b)}
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def summary(x):return {k:x.get(k) for k in ('operation','compliance','mutation','restitution')}

if sys.argv[1]=='consolidate':
 assert git('rev-parse','HEAD').decode().strip()==HEAD
 assert not git('status','--porcelain')
 for a in ['WO-HAG-009','WO-HAG-010']:
  x=json.loads(load(O/(a+'-consolidation-scope.json'))['stdout']);assert x['compliance']['status']=='pass'
 archives=[]
 inventories=list((E/'final44-result').glob('*inventory.json'))+[E10/'execution-support.json']
 ipkdir=R/'docs/engineering/integration-package/evidence/WO-IPK-002'
 inventories += [ipkdir/'local-checks-inventory.json',ipkdir/'ci-evidence-inventory.json']
 for inv in inventories:
  m=load(inv);a=inv.parent/m['archive'];b=a.read_bytes();assert digest(b)==m['sha256'],a
  with zipfile.ZipFile(a) as z:
   assert z.testzip() is None
   records=m['files'];assert len(records)==len(z.namelist())
   for f in records:
    q=z.read(f['path']);assert ('bytes' not in f or len(q)==f['bytes']) and digest(q)==f['sha256'],(a,f['path'])
  archives.append({**fact(a),'inventory':fact(inv),'verified_members':len(records)})
 native={}
 for trial in ['claude-421','codex-421','codex-421-reads']:
  with zipfile.ZipFile(E/f'final44-result/{trial}-evidence.zip') as z:
   a=json.loads(z.read('assessment/independent-assessment.json'))
   native[trial]={'archive':f'final44-result/{trial}-evidence.zip','assessment_member':'assessment/independent-assessment.json','assessment':a}
   if trial!='codex-421-reads':
    assert a['overall']=='pass' and set(a['cases'].values())=={'pass'}
    native[trial]['component_identity']=json.loads(z.read('assessment/combination.json'))
 comparisons=[]
 for old,kind in [(C44,'native test candidate'),(IPK,'later source and package checks')]:
  x=p.run('compare-'+old[:8],['git','diff','--raw','--no-abbrev',old,HEAD],cwd=R)
  paths=git('diff','--name-only',old,HEAD).decode().splitlines()
  other=[s for s in paths if not s.startswith('docs/engineering/')]
  expected=['.github/scripts/build_integration_package.py','tests/test_integration_package.py'] if old==C44 else []
  assert other==expected,(old,other)
  roots=['server','src','plugins','repository_tools','tests/hosted_artifact_graph','tests/plugin_integration','pyproject.toml']
  roots=[q for q in roots if (R/q).exists()]
  identical=[]
  for q in roots:
   before=git('ls-tree','-r',old,'--',q);after=git('ls-tree','-r',HEAD,'--',q);assert before==after,q
   identical.append({'path':q,'identical_blob_ids_and_modes':True,'file_count':len(before.splitlines()),'listing_sha256':digest(before)})
  comparisons.append({'tested_commit':old,'purpose':kind,'compared_head':HEAD,'all_changed_paths':paths,'changes_outside_formal_artifacts_and_evidence':other,'unchanged_components':identical})
 pr=json.loads(load(O/'pr-current-network.json')['stdout'])
 assert pr['headRefOid']==HEAD and pr['baseRefName']=='main' and pr['isDraft']
 refs=[E/'final44-result/assessment.md',E10/'implementation-review.md',ipkdir/'verification-assessment.md',ipkdir/'candidate-relationship.json',ipkdir/'verification-preparation.json',R/'docs/engineering/integration-package/verification-records/VREC-IPK-002.md']
 data={'scope':['WO-HAG-009','WO-HAG-010'],'contract':'VER-HAG-007','head_before_consolidation':HEAD,'complete_pr_base':BASE,'native_test_candidate':C44,'archive_integrity':archives,'native_qualification':native,'source_comparisons':comparisons,'references':[fact(f) for f in refs],
 'check_reuse':{'local_source':'1,339 tests, 24 skips, exit 0; local-checks.zip/source-retry.json','source_failure_preserved':'Original Windows Git long-path failure and diagnostic remain in local-checks.zip. Retry used process-local core.longpaths=true, not a global or repository setting.','distribution':'23 records, exit 0; local-checks.zip/distribution.json','cli':'exit 0; local-checks.zip/smoke.json','runtime':'local-checks.zip/runtime.json','native_rerun':False,'reason':'Exact Git blob/mode comparisons above establish unchanged native inputs; later IPK correction changes only the CI helper and its tests. No claim that the new consolidation commit itself ran the earlier tests.'},
 'ci_at_inspected_head':{'head':HEAD,'checks':pr['statusCheckRollup']},
 'separate_work':{'WO-HAG-011':'Two focused Claude positive repetitions fail under VER-HAG-008. No criterion waiver or completion claim. Not a declared dependency of WO-HAG-009/010. Combined PR integration remains pending.'},
 'limits':['Handoff checks are recorded separately after packet generation. This file supplies no lifecycle transition or human verification.','Codex MCP parity includes a disclosed separate read-only two-tool recovery. Original stale comparisons and failures remain unchanged.','Synthetic VREC/RLS decisions are test data, not verification of this implementation.','Desktop, automatic startup/compaction, public delivery, production security and Git authority cutover remain excluded.']}
 put(E/'consolidation.json',data)
 report=f'''# Native qualification evidence consolidation

WO-HAG-009 and WO-HAG-010 have passing native qualification evidence under
VER-HAG-007. This consolidation links that evidence to the current branch and
prepares the formal handoff. It does not record implementation completion or
human verification.

## Assessed result

| Required case | Claude CLI | Codex CLI | Retained evidence |
| --- | --- | --- | --- |
| NQ-01: instruction discovery and correct context | Pass | Pass | Each native archive: assessment/instruction-read-trace.json and assessment/independent-assessment.json |
| NQ-02: complete synthetic lifecycle | Pass | Pass | Each native archive: replay/assessment.json; 12 accepted operations replayed per host |
| NQ-03: refusals, recovery and seven MCP reads | Pass | Pass with disclosed read-only supplement | Independent assessments and codex-421-reads-evidence.zip |
| NQ-04: lost reply and idempotent retries | Pass | Pass | Exact requests, responses and independent receipt replay |
| NQ-05: exact export and preserved candidate | Pass | Pass | Two Claude exports and four Codex exports independently reconstructed |

The native archives and their inventories are in [final44-result](final44-result/).
[consolidation.json](consolidation.json) records their digests, checks every
inventory member, and retains exact component identities and evidence references.
Both agents supplied their own requests. There were no corrective prompts,
operator workflow mutations or scripted completion.

Codex's read result combines five tools from the original run with two tools from
a separate read-only session on the same fixed baseline. The independent observer
initially watched old trial directories; four delayed Codex comparisons returned
stale HTTP 409 responses. Those failures remain recorded and do not count as
matches. The supplement changed no graph state. The original C44 assessment
explains this recovery and all other qualification limits.

## Exact candidate and reuse

- Native tests: `{C44}`.
- Branch inspected for this consolidation: `{HEAD}`.
- Complete PR comparison base: `{BASE}`.
- Governor: separately installed released evaluator 0.22.1.
- Native candidate client: 0.22.2; candidate plugins: 0.2.7.

Exact Git blob and mode comparisons establish that the service, client, plugin
instructions, test drivers, build helpers and package definition are unchanged
from the native test candidate. Later changes outside formal artifacts/evidence
are only the two IPK archive-cap correction files. No native run is repeated or
represented as a run against this new evidence commit.

The later source checks passed 1,339 tests with 24 skips, distribution validation
and CLI smoke. Their commands, runtime, outputs, original long-path failures and
successful retry remain in the IPK local-check archive. Source/package checks at
`{IPK}` have no subsequent code changes. Its matching CI merge and package
identities are retained in the [IPK assessment](../../../integration-package/evidence/WO-IPK-002/verification-assessment.md).

At the inspected PR head, all source, package, upgrade, deterministic build,
Windows/Linux installation and retention jobs pass. Harness validation fails;
the current handoff checks will retain its exact remaining findings. Three
conditional release rehearsals are skipped, not passed.

## WO-HAG-010 routing correction

The approved bootstrap/setup correction routes an explicitly selected hosted
request before local checkout activation. Its original checks and failed Claude
trial remain in [WO-HAG-010](../WO-HAG-010/). The final native runs qualify the
unchanged packaged guidance for both hosts. The new digest references supersede
the old report's pending-trial observation without editing that historical report.

## Separate unfinished work

WO-HAG-011 has two focused Claude drafting failures under VER-HAG-008: one omits
a known evaluator version; another gives contradictory readiness conclusions
and invents a type-check obligation. Those results do not become passes here.
The full lifecycle checks above use VER-HAG-007. The evaluator reports no declared
dependency from WO-HAG-009/010 to WO-HAG-011. Combined PR acceptance remains pending.

The old C44 report records the then-unresolved archive-size failure and grouped
work status. WO-IPK-002 has since corrected that limit and VREC-IPK-002 is verified.
This report preserves the original report and distinguishes the separate work.

## Handoff and boundaries

Generated packets and handoff.json files hold the released evaluator results.
The complete multi-work-order PR is checked against its original base with the
released check-pr command; its scope union is not recreated by agent code.
The handoff-check archive retains commands, results and any failure. A passing
gate does not itself complete or verify a work order.

Git remains authoritative. Synthetic decisions grant no real authority. Desktop,
automatic startup/compaction, public publication, production operation,
authentication/database ACL work and real authority cutover remain excluded.
RISK-HAG-001 and RISK-HAG-002 are not accepted or closed by this consolidation.
'''
 put(E/'consolidation.md',report)
 put(E10/'consolidation.md',f'''# Hosted routing qualification evidence

WO-HAG-010 uses the final WO-HAG-009 native runs under VER-HAG-007. Both hosts
pass NQ-01 through NQ-05 for `{C44}`. The approved bootstrap/setup files and
their package inputs are unchanged at `{HEAD}`.

See [the consolidated assessment](../WO-HAG-009/consolidation.md) and
[the digest index](../WO-HAG-009/consolidation.json). The index checks every
member of the native archives, this work order's execution-support.zip, and
the later source/package check archives. It retains the exact tested component
identities and the limits on reuse. Native transcripts stay under WO-HAG-009;
they are not duplicated here.

The earlier failed trials and implementation-review.md remain unchanged.
Codex's seven-tool parity includes the disclosed read-only two-tool supplement.
The separate WO-HAG-011 focused failures remain open. This file records no
completion, human verification, merge or release decision.
''')
 print(json.dumps({'archives_verified':len(archives),'members_verified':sum(a['verified_members'] for a in archives),'reports_written':3}))
elif sys.argv[1]=='packets':
 for a in ['WO-HAG-009','WO-HAG-010']:
  f=D/f'evidence/{a}/{a}-handoff.md';assert not f.exists()
  x=p.gov(a+'-packet','evidence',R,'--artifact',a,'--checkpoint','handoff','--json');print(a,json.dumps(summary(x)),flush=True)
  print(f.read_text(encoding='utf-8'),flush=True)
elif sys.argv[1]=='check':
 pr=json.loads(load(O/'pr-current-network.json')['stdout'])
 event={'pull_request':{'body':pr['body'],'head':{'sha':HEAD,'ref':pr['headRefName']},'base':{'sha':BASE,'ref':'main'}}}
 put(O/'pr-event.json',event)
 x=p.gov('combined-handoff','check-pr',R,'--event',O/'pr-event.json','--from-git',BASE,'--json',allowed=(0,1,2));print(json.dumps(x)[:5000])
 for a in ['WO-HAG-009','WO-HAG-010']:
  f=D/f'evidence/{a}/handoff.json';print(a,json.dumps(summary(load(f))) if f.exists() else 'no handoff.json')
