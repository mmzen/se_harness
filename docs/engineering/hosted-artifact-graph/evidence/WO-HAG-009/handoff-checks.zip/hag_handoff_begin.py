from pathlib import Path
import hag_efficiency_plan as p,json,sys
p.O=p.W/'hag-handoff-closeout'
for a,names in [('WO-HAG-009',['consolidation.md','consolidation.json','handoff-checks.zip','handoff-checks-inventory.json','WO-HAG-009-handoff.md','handoff.json']),('WO-HAG-010',['consolidation.md','WO-HAG-010-handoff.md','handoff.json'])]:
 args=['check',p.R,'--artifact',a,'--checkpoint','scope']
 for n in names:args+=['--changed-path',f'docs/engineering/hosted-artifact-graph/evidence/{a}/{n}']
 x=p.gov(a+'-consolidation-scope',*args,'--changes-complete','--json',allowed=(0,1,2));print(a,json.dumps({'status':x.get('compliance',{}).get('status'),'blockers':x.get('restitution',{}).get('blocked_by')}),flush=True)
x=p.run('pr-current',['gh','pr','view','543','--repo','mmzen/se_harness','--json','body,headRefOid,headRefName,baseRefName,isDraft,state,statusCheckRollup']);print('PR',json.dumps({k:v for k,v in x.items() if k not in ['body','statusCheckRollup']}));print('CHECKS',json.dumps([{k:v for k,v in c.items() if k in ['name','status','conclusion','detailsUrl']} for c in x.get('statusCheckRollup',[])]))
