import hag_efficiency_plan as p,json,zipfile,hashlib
p.O=p.W/'hag-handoff-closeout';E=p.D/'evidence/WO-HAG-009'
x=json.loads((E/'consolidation.json').read_bytes());results={}
for a in ['WO-HAG-009','WO-HAG-010']:
 r=json.loads(json.loads((p.O/(a+'-individual-handoff.json')).read_bytes())['stdout']);assert r['compliance']['status']=='pass' and r['operation']['outcome']=='completed';results[a]={'compliance':r['compliance'],'restitution':r['restitution'],'source_log':a+'-individual-handoff.json','change_manifest':f'docs/engineering/hosted-artifact-graph/evidence/{a}/handoff-change-set.json'}
x['handoff_results']=results;x['repository_validation']={'valid':True,'artifact_count':1994,'error_count':0,'warning_count':63,'advisory_count':0,'source_log':'consolidated-validation.json'}
x['limits'][0]='Individual handoff checks pass; exact results are retained in handoff-checks.zip. No lifecycle transition or human verification was applied.'
(E/'consolidation.json').write_bytes((json.dumps(x,indent=2)+'\n').encode())
f=E/'consolidation.md';s=f.read_text();s+='''
## Recorded handoff outcome

Both individual released handoff checks **pass**, with no blocking predicate.
Both review preflights pass. Released repository validation reports 1,994
artifacts, zero errors, 63 existing warnings and no authoring advisories.
The full PR scope check reaches WO-HAG-011 after passing WO-HAG-009/010,
then stops at its missing QGP-G4I-EVIDENCE handoff packet.

WO-HAG-009 and WO-HAG-010 remain `in_progress`. The individual handoff results
select `PROC-WO-IMPLEMENT / STEP-WO-IMPLEMENT-PREVIEW`: preview their transition
to `implemented` under the existing execution grant. No new human decision is
required for that preview. Completion and real verification were not applied
in this evidence-consolidation step.
''';f.write_bytes(s.encode())
f=p.D/'evidence/WO-HAG-010/consolidation.md';f.write_bytes(f.read_bytes()+b'\nThe individual released handoff and review preflight pass. WO-HAG-010 remains\n`in_progress`; its returned next step is `STEP-WO-IMPLEMENT-PREVIEW`.\n')
files=[q for q in p.O.glob('*.json') if not q.name.startswith('help-')]+[p.W/'hag_consolidate.py',p.W/'hag_handoff_begin.py',p.W/'hag_handoff_individual.py']
with zipfile.ZipFile(E/'handoff-checks.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(files):z.writestr(f.name,f.read_bytes())
b=(E/'handoff-checks.zip').read_bytes();m={'archive':'handoff-checks.zip','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'files':[{'path':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(files)],'status':'Exact consolidation commands, current context, scope, review, validation and individual handoff results. Combined check stops at separate WO-HAG-011. No lifecycle transition.'};(E/'handoff-checks-inventory.json').write_bytes((json.dumps(m,indent=2)+'\n').encode())
x=p.gov('combined-handoff-final','check-pr',p.R,'--event',p.O/'pr-event.json','--from-git','55caaada508495bea7d97effd27644d1ce8373da','--json',allowed=(0,1,2));print(json.dumps(x))
