import hag_efficiency_plan as p,json,subprocess,tomllib,concurrent.futures
p.O=p.W/'hag-handoff-closeout';base='55caaada508495bea7d97effd27644d1ce8373da'
for a in ['WO-HAG-009','WO-HAG-010']:
 rel=f'docs/engineering/hosted-artifact-graph/evidence/{a}/handoff-change-set.json'
 x=p.gov(a+'-manifest-scope','check',p.R,'--artifact',a,'--checkpoint','scope','--changed-path',rel,'--changes-complete','--json');assert x['compliance']['status']=='pass'
 paths=set(subprocess.check_output(['git','diff','--name-only',base],cwd=p.R,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=p.R,text=True).splitlines())|{rel}
 m=tomllib.loads((p.D/f'work-orders/{a}.md').read_text().split('+++')[1]);scope=m['execution_scope']['paths'];selected=[s for s in sorted(paths) if any(s==x or (x.endswith('/') and s.startswith(x)) for x in scope)]
 (p.R/rel).write_bytes((json.dumps({'schema':'se-harness-change-set-v1','complete':True,'paths':selected},indent=2)+'\n').encode())
 print(a,'manifest paths',len(selected),flush=True)
def check(a):
 rel=f'docs/engineering/hosted-artifact-graph/evidence/{a}/handoff-change-set.json'
 x=p.gov(a+'-individual-handoff','check',p.R,'--artifact',a,'--checkpoint','handoff','--change-manifest',rel,'--json',allowed=(0,1,2));return a,{k:x.get(k) for k in ['operation','restitution']}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for a,x in pool.map(check,['WO-HAG-009','WO-HAG-010']):print(a,json.dumps(x),flush=True)
