"""Retain exact visible comparison evidence; exclude private reasoning and secrets."""
from pathlib import Path
import sys
W=Path(__file__).parent
source=(W/'hag_retain36.py').read_text().replace('WO-HAG-009/procedure36-result','WO-HAG-009/opus55-comparison')
source=source.replace("names=['initial-status.json'","names=['model-comparison-inputs.json','initial-status.json'")
source=source.replace("h.O.glob('native-parity-*36')","h.O.glob('native-parity-opus55')")
sys.argv=[__file__,'claude-321']
exec(compile(source,'opus55-retention','exec'),{'__file__':str(W/'hag_retain36.py'),'__name__':'__main__'})
