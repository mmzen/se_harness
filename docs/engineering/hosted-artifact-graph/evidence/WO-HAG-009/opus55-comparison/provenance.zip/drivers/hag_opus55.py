"""User-requested same-task Opus 5.5 diagnostic; no product or test-task changes."""
from pathlib import Path
import sys
W=Path(__file__).parent
source=(W/'hag_full36.py').read_text()
source=source.replace("else '311'", "else '321'")
marker="sys.argv=[__file__,actual,host,trial]"
assert source.count(marker)==1
replacement='''
source=source.replace('claude-opus-4-6','claude-opus-5-5')
source=source.replace(r'C:\\Users\\mathi\\.local\\bin\\claude.exe',str(W/'hag-opus55-availability-20261011/claude-2.1.280.exe'))
# HEAD is an evidence-only descendant. Packages and staged source stay at C36.
source=source.replace("==load(PREV/'candidate-36.json')['commit']", "=='82fc1ca323930ac420e8c3464c0eef1da2358733'")
source=source.replace("'review_head':load(PREV/'candidate-36.json')['commit']", "'review_head':'82fc1ca323930ac420e8c3464c0eef1da2358733'")
sys.argv=[__file__,actual,host,trial]
'''
source=source.replace(marker,replacement)
exec(compile(source,'opus55-same-diagnostic','exec'),{'__file__':str(W/'hag_full36.py'),'__name__':'__main__'})
