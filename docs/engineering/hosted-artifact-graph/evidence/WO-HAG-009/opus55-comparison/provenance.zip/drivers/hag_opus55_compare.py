"""Comparison preparation and read-only observers, never native assistance."""
import hashlib,json,subprocess,sys
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-procedure36-20261011';A=W/'hag-opus55-availability-20261011'
old=O/'claude-311';root=O/'claude-321'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
mode=sys.argv[1]
if mode=='proof':
 assert (old/'native-task.md').read_text()==(root/'native-task.md').read_text().replace('claude-321','claude-311')
 assert load(old/'permissions.json')==json.loads((root/'permissions.json').read_text().replace('claude-321','claude-311'))
 changed=subprocess.check_output(['git','diff','--name-only','c526fcbe7ac59de9fd45cb8ae461cfb558aaf2b7','HEAD','--','se_harness','tests','plugins','server','templates','pyproject.toml','repository_tools'],cwd=W/'hag221proposal').decode()
 assert not changed,changed
 oi=load(old/'native/inputs/inventory.json');ni=load(root/'native/inputs/inventory.json')
 om={x['relative']:x['sha256'] for x in oi['files']};nm={x['relative']:x['sha256'] for x in ni['files']}
 assert set(om)==set(nm)
 differences=[k for k in om if om[k]!=nm[k]]
 # New project identity changes configuration/selection/deployment bindings only.
 same={k:v for k,v in om.items() if nm[k]==v}
 assert all(om[k]==nm[k] for k in om if k.startswith(('source/','plugin/','reference/','released-resources/')))
 manifest=load(A/'manifest-2.1.280.json');exe=A/'claude-2.1.280.exe'
 assert sha(exe)==manifest['platforms']['win32-x64']['checksum']
 probe=load(O/'claude321-live-probe.json');parsed=json.loads(probe['stdout'])
 assert list(parsed['modelUsage'])==['claude-opus-5-5'] and not parsed['is_error']
 host_version=subprocess.check_output([r'C:\Users\mathi\.local\bin\claude.exe','--version']).decode().strip()
 value={'kind':'User-requested Opus 5.5 same-task diagnostic comparison','candidate':'c526fcbe7ac59de9fd45cb8ae461cfb558aaf2b7','review_head':'82fc1ca323930ac420e8c3464c0eef1da2358733','previous_trial':'claude-311','trial':'claude-321','old_model':'claude-opus-4-6','model':'claude-opus-5-5','old_cli':'2.1.273','cli':'2.1.280','executable':str(exe),'executable_sha256':sha(exe),'official_manifest':'https://downloads.claude.ai/claude-code-releases/2.1.280/manifest.json','manifest_sha256':sha(A/'manifest-2.1.280.json'),'live_probe':{'exit':probe['exit'],'model':list(parsed['modelUsage']),'AUTH_OK_observed':parsed['result']=='AUTH_OK'},'host_update':{'user_authorized':True,'from':'2.1.273','reported_current':host_version,'command':[r'C:\Users\mathi\.local\bin\claude.exe','update'],'not_used_for_comparison':True},'timeout_seconds':1200,'task_equal_except_directory':True,'permissions_equal_except_directory':True,'identical_inventoried_files':len(same),'different_inventoried_files':differences,'runtime_guidance_source_changes':[],'limitations':'CLI 2.1.273 refused Opus 5.5 before inference; API required >=2.1.280. This comparison changes model and required CLI version. It does not amend formal qualification criteria or establish a full lifecycle pass. Previous task failures are preserved. No effort override is supplied in either run.'}
 target=root/'model-comparison-inputs.json';assert not target.exists();target.write_text(json.dumps(value,indent=2)+'\n')
 print(json.dumps(value,indent=2))
elif mode=='parity':
 source=(W/'hag_parity36.py').read_text().replace("label='diagnostic36'","label='opus55'")
 sys.argv=[__file__,'321'];exec(compile(source,'opus55-parity','exec'),{'__file__':str(W/'hag_parity36.py'),'__name__':'__main__'})
elif mode=='facts':
 source=(W/'hag_full36_facts.py').read_text().replace('claude-311','claude-321').replace('native-parity-diagnostic36','native-parity-opus55')
 exec(compile(source,'opus55-facts','exec'),{'__file__':str(W/'hag_full36_facts.py'),'__name__':'__main__'})
elif mode in ('audit','refusals'):
 source=(W/'hag_assess36.py').read_text().replace('claude-311','claude-321')
 exec(compile(source,'opus55-observations','exec'),{'__file__':str(W/'hag_assess36.py'),'__name__':'__main__'})
else:raise ValueError(mode)
