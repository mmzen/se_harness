"""Bounded reproducibility material for the unchanged-candidate comparison."""
import hashlib,json,re,zipfile
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'hag-procedure36-20261011';A=p.W/'hag-opus55-availability-20261011';E=p.D/'evidence/WO-HAG-009/opus55-comparison'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
drivers=['hag_opus55.py','hag_opus55_compare.py','hag_opus55_retain.py','hag_opus55_provenance.py','hag_full36.py','hag_focus36_task.txt','hag_full27.py','hag_native27.py','hag_parity36.py','hag_native_parity19.py','hag_review36.py','hag_full27_review.py','hag_trace36.py','hag_full27_trace.py','hag_full36_facts.py','hag_retain36.py','hag_retain26.py','hag_watch36.py','hag_assess36.py']
for name in drivers:files['drivers/'+name]=(p.W/name).read_bytes()
for name in ['candidate-36','package-guidance-comparison','service-reuse-comparison','server-wheel-members','task-comparison']:
 files['reused-candidate/'+name+'.json']=(O/(name+'.json')).read_bytes()
for f in O.glob('claude321-*.json'):
 if 'live-probe' not in f.name:files['setup/'+f.name]=f.read_bytes()
for name in ['context-WO-HAG-009.json','manifest-2.1.280.json','install-official.ps1']:
 files['comparison/'+name]=(A/name).read_bytes()
files['comparison/model-comparison-inputs.json']=(O/'claude-321/model-comparison-inputs.json').read_bytes()
# Record the exact compatibility failure without provider account/session metadata.
probe=load(A/'availability.json')
files['comparison/initial-cli-compatibility.json']=(json.dumps({'purpose':'No-tools Opus 5.5 availability request','old_cli':'2.1.273','outcome':'API 400 before model inference','diagnostic':'Claude Code 2.1.273 does not support this model; version 2.1.280 or newer is required.','private_capture_sha256':sha((A/'availability.json').read_bytes()),'raw_provider_log_retained_privately':True},indent=2)+'\n').encode()
tokens=[x['token'].encode() for f in O.glob('*/credentials.json') for x in load(f)['principals']]
for name,raw in files.items():
 assert not any(t in raw for t in tokens),name
 assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
with zipfile.ZipFile(E/'provenance.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
index={'archive':'provenance.zip','sha256':sha((E/'provenance.zip').read_bytes()),'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())],'limits':'Exact bounded setup and observer sources. No raw provider logs, private reasoning, credentials, account stores, full environments or downloaded executable. Official executable checksum retained; known test tokens checked absent. Existing build qualification is linked, not rerun.'}
(E/'provenance-inventory.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());print(len(files),'files')
