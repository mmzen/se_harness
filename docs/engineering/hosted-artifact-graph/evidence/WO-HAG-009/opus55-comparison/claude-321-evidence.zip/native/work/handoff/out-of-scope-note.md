# Out-of-scope probe

Synthetic test input for a refused handoff. This path is outside WO-P3-001 execution scope.
