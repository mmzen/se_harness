+++
id = "SPEC-P3-001"
type = "specification"
title = "Exact return value of the fixture greeting()"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
# What an implementation must do to conform. The Explorer shows this summary under the title.
contract = "greeting() in src/greeting.py takes no arguments and returns the str Hello rehearsal exactly."

[relations]
specifies = ["REQ-P3-001"]
+++

# Specification: Exact return value of the fixture greeting()

Before approval, apply the shared design principle and `specification` checklist in
`docs/engineering/ARTIFACT_AUTHORING.md`.

Synthetic rehearsal input. `test-owner` is a fixture identity, not a real human decision.

## In plain words

`greeting()` gives back the text `Hello rehearsal`, character for character.

## Scope

This specification governs the return value of the existing function
`greeting()` in `src/greeting.py`. It does not govern other functions, callers
or how the result is displayed.

## Terms

- **Exact match.** The returned value is a `str` equal to `Hello rehearsal` under Python `==`.

## Rules

**P3-GREET-001.** A call to `greeting()` with no arguments MUST return a `str`
equal to `Hello rehearsal`.

**P3-GREET-002.** The returned value MUST NOT contain any character other than
the 15 characters of `Hello rehearsal`, including leading or trailing
whitespace or a newline.

## Failure behaviour

| Trigger | Response | Diagnostic |
| --- | --- | --- |
| `greeting()` returns another value or raises an exception | The implementation does not conform; this function defines no fallback value | none |

## Examples

**Given** the fixture source at the candidate commit, **when** the test
operator calls `greeting()`, **then** the result is `'Hello rehearsal'`
(P3-GREET-001, P3-GREET-002).

**Given** a variant that returns `'Hello rehearsal '`, **when** it is called,
**then** it does not conform (P3-GREET-002).

## Coverage

| Requirement | Rules |
| --- | --- |
| `REQ-P3-001` | P3-GREET-001, P3-GREET-002 |

## Not decided here

- The check command and its evidence file (VER-P3-001).
