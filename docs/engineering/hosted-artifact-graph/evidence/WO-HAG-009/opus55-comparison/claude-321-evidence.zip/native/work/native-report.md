# Native hosted procedure and refusal diagnostic (claude-321)

This is test data from a rehearsal only, and Git remains authoritative. `test-owner` and `test-executor` are synthetic fixture identities, not real human decisions. This diagnostic does not complete NQ-01 through NQ-05. It verifies no real work and authorizes no release.

## Outcome

| Demonstration | Result |
| --- | --- |
| Definitions, verification contract and bounded work order authored | Done: `INT/CAP/REQ/SPEC/VER/WO-P3-001`; validation found 0 errors and 0 warnings |
| Definition and work-order approval, then start | Done: accepted transitions with the synthetic actors |
| Meaningful Cypher read through MCP | Done: 2 complete reads at an explicit context view |
| Out-of-scope handoff refusal | Observed: 2 refusals by the service adapter (`HAG_REMOTE_PROTECTED_FIELD`), not by an evaluator scope gate. No effect. |
| Valid handoff for the selected work | **Blocked**: the released evaluator refused (`WEX201`, `QGP-G4I-PATHS`). No effect. |
| Stale preview after a changed selected draft | **Not performed**: this needs a passing preview digest. No passing preview of an authorized action was available after the handoff blocker. |

## Identities

| Item | Value | Source |
| --- | --- | --- |
| Project | `053a9de0-c376-4187-9693-633f3f481e68` at `http://127.0.0.1:27321` | `selection.json` |
| Hosted context and evaluator | `sandbox-projection`, `test_copy: true`; evaluator `0.22.1` (archive `cb35c3c4…3053`); client `0.22.2` (wheel `cb70099a…0a09`). All components match `combination.json`. | `work/r01-status.stdout.txt` |
| Qualification candidate (service source) | `c526fcbe7ac59de9fd45cb8ae461cfb558aaf2b7` | status `/components/source` |
| Source fixture commit S | `5820415917e87b64d80bad2f7c39c6d18d692829` | `inputs/source-manifest.json` |
| Imported baseline | `se-harness-artifact-baseline/v1:sha256:de6b4774…a20e` | `work/r02-import` |
| Draft context | `cb095e96-f812-4b43-8e58-1e5f6d1b6a9f`, opened on `WO-P3-900`; v15 at the end | `work/r04-draft-open` |
| Retained handoff base | `dc18e29d6536bcb4ff3130f5e2e88fe16a6ea172`: the `input_git_head` of the first accepted lifecycle mutation (`p36-c321-l04-approve-defs-apply`) | `work/l04-approve-defs-apply.stdout.txt` |
| Test Git candidate P, implementation candidate C | Unknown. No capture was made; none is authorized. | n/a |

## Authored records (context `cb095e96…`)

The authoring checklists were applied by source inspection; `content_review` was `not_assessed` by the evaluator. Drafts are in `work/drafts/`.

- `INT-P3-001` (outcome, problem, measure with `not measured` baseline, limits).
- `CAP-P3-001` → `INT-P3-001`.
- `REQ-P3-001` → `CAP-P3-001`: `greeting()` returns exactly `Hello rehearsal`.
- `SPEC-P3-001` → `REQ-P3-001`: rules `P3-GREET-001`, `P3-GREET-002`.
- `VER-P3-001` → `REQ-P3-001`: planned check C1; evidence at `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/greeting-assertion.json`.
- `WO-P3-001` sets `required` assurance, `decided_by = "test-owner"`, and the execution scope `["docs/engineering/lifecycle-pilot/evidence/WO-P3-001/greeting-assertion.json"]`. No source change is in scope.

The imported `-900` records were not changed and received no decision. The context anchor `WO-P3-900` received only a draft-open.

## Lifecycle sequence

| Step | Key / record | Outcome |
| --- | --- | --- |
| Validate | `l01-validate` | inspected; valid, 0 errors. One advisory `W-AUT-022` on the imported `SPEC-P3-900` (unrelated). |
| Check `WO-P3-001` | `l02-check-wo` | inspected; checkpoint-free context only (`compliance.status: not_assessable`, no gates) |
| Approve 5 definitions | `l03` preview → `l04` apply | previewed (all gates pass) → accepted; project 14→15 |
| Approve `WO-P3-001` | `l05` preview → `l06` apply | previewed (`QG-G3-WORK-AUTHORIZATION` pass) → accepted; project 15→16 |
| Start preflight | `l07-preflight-start` | inspected; `ready: true` |
| Start (`test-executor`) | `l08` preview → `l09` apply | previewed (pass) → accepted; `WO-P3-001` `in_progress`; project 16→17 |
| Check C1 executed | `x01-assert-greeting` | exit 0, `exact greeting passed` |
| Out-of-scope handoff (`.md` note) | `l10-handoff-oos-preview` | refused 422 `HAG_REMOTE_PROTECTED_FIELD` |
| Out-of-scope handoff (`.txt` under `scratch/`) | `l11-handoff-oos-preview` | refused 422 `HAG_REMOTE_PROTECTED_FIELD` |
| In-scope handoff preview | `l12-handoff-preview` | refused `HAG_REMOTE_EVALUATOR_REFUSED` |

## Failed conditions

1. **Out-of-scope handoff (`l10`, `l11`).** The service adapter refused the request before evaluation: `HAG_REMOTE_PROTECTED_FIELD`, "Handoff inputs cannot replace formal or instruction files." The result had `evaluator_output: null` and did not name the offending input. Each request carried the in-scope evidence file plus one out-of-scope file. `l12` sent the same evidence file alone and the adapter admitted it, so the refusal is attributable to the added out-of-scope paths. This is an adapter protected-path refusal, not the evaluator's `WEX201` scope gate. The diagnostic intended a scope refusal and did not obtain one.
2. **Valid handoff (`l12`).** The handoff gate `QG-G4-IMPLEMENTATION-EVIDENCE` failed. Predicate `QGP-G4I-PATHS` reported "WEX201: changed path is outside execution scope: docs/engineering/lifecycle-pilot/capabilities/CAP-P3-001.md". All other predicates passed, including `QGP-G4I-EVIDENCE`. The complete change set (`change_set_complete: true`) from base `dc18e29…` also includes the approval writes to `INT/REQ/SPEC/VER-P3-001.md`. Those files are not in `WO-P3-001`'s scope. Evaluator next step: "Escalate QGP-G4I-PATHS under DR-REMEDIATION-SCOPE". The root cause is the work-order scope I authored: the definitions were approved after the retained base, but the scope did not include their paths. The procedure forbids choosing a later base, and forbids expanding approved scope without a decision. No remediation-scope decision was supplied, so the handoff stopped.
3. **Stale preview.** Not demonstrated, for the reason stated in the outcome table.

## Unchanged effects

Refusals have no receipts, no affected revisions and `versions: null`. `r18-status-after-refusals` shows project version 17, the same as after `l09`. MCP Cypher at context v15 (`r19-mcp-cypher-after-refusals.json`) shows `WO-P3-001` `in_progress` at revision `sha256:e1667638…c3a1`.

## Cypher reads (MCP `mcp__hag__cypher`)

- `r17-mcp-cypher.json` (context v12): `WO-P3-001` DECLARES `implements`→`REQ-P3-001`, `specifications`→`SPEC-P3-001`, `verification`→`VER-P3-001`. `complete: true`, no unresolved references.
- `r19-mcp-cypher-after-refusals.json` (context v15): the work-order state, as above.

## Test evidence limits

`x01-assert-greeting` ran the helper assertion against the staged `src/greeting.py` (sha256 `dcbd486a…cab1`). It deviates from VER-P3-001 C1 in four ways:

- It ran on the local Windows client Python, not `linux/amd64` Python 3.13.16.
- It executed no `type(...) is str` assertion.
- It was not bound to a candidate commit.
- The Python version was not recorded.

These limits are recorded in `work/handoff/greeting-assertion.json`. No verification record exists.

## Other failures and recoveries (from `z01-observations`)

The snapshot captured 109 native calls (count complete) and 8 native tool errors:

1. A help-file read failed: `client-help/draft-open.txt` does not exist. Recovered by reading the schema view.
2. `draft-open` with `WO-P3-901` was refused by the service (404 `HAG_REMOTE_UNKNOWN_IDENTITY`). Recovered by anchoring on `WO-P3-900`.
3. A `read-json` call failed because a pointer was mangled by Git Bash path conversion. Recovered by quoting the pointer.
4. Two `instructions` calls failed for reference files outside the section reader. Recovered by native Read.
5. The remaining three errors are the service refusals `l10`, `l11` and `l12` described above.

## Uncertainties

- The specific path rule behind `HAG_REMOTE_PROTECTED_FIELD` is not reported by the service.
- Whether a remediation decision would allow the valid handoff was not tested.
- Report writes after `z01-observations` are not in that snapshot.

## Next accountable decision

`test-owner` decides under `DR-REMEDIATION-SCOPE` whether to authorize a scope correction for `WO-P3-001` that admits the five definition paths. Only after that decision can a new handoff preview be attempted, followed by the stale-preview demonstration.
