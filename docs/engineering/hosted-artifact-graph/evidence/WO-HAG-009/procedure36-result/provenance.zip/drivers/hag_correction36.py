"""Bounded canonical-entry and file-pointer correction under WO-HAG-009/011."""
import hashlib,json,os,re,subprocess,sys,tempfile,tomllib,zipfile
from pathlib import Path
import hag_efficiency_plan as p
W,R,D=p.W,p.R,p.D; O=W/'hag-procedure36-20261011'; p.O=O
E=D/'evidence/WO-HAG-011/procedure36'; H=Path('C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe')
changed=['se_harness/resources.py','tests/test_resources.py','tests/hosted_artifact_graph/native_call.py','tests/hosted_artifact_graph/test_native_support.py','tests/hosted_artifact_graph/native-tools.md','plugins/verity-plane/common/skills/change/references/hosted-test-lifecycle.md','docs/notes/harnessctl-reference.md']
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,encoding='utf-8').strip()
def put(f,v):
 assert not f.exists(),f
 f.parent.mkdir(parents=True,exist_ok=True); f.write_bytes((v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
mode=sys.argv[1]
if mode=='scope':
 paths=changed+[(E/n).relative_to(R).as_posix() for n in ['review.md','checks.zip','inventory.json']]
 args=['check',R,'--artifact','WO-HAG-011','--checkpoint','scope','--changes-complete']
 for path in paths:args+=['--changed-path',path]
 v=p.gov('scope36',*args,'--json'); assert v['compliance']['status']=='pass'; print('scope pass')
elif mode in ('focused','checks'):
 scratch=Path('C:/Users/mathi/AppData/Local/Temp/hag36');scratch.mkdir(exist_ok=True)
 os.environ.update(TEMP=str(scratch),TMP=str(scratch));tempfile.tempdir=str(scratch)
 commands=[('resources',[H,'-X','utf8','-B','-m','unittest','discover','-s','tests','-p','test_resources.py']),('native',[H,'-X','utf8','-B','-m','unittest','discover','-s','tests/hosted_artifact_graph','-p','test_native*.py']),('plugin',[H,'-X','utf8','-B','-m','unittest','discover','-s','tests/plugin_integration','-p','test_simple_plugin.py'])] if mode=='focused' else [('source',[H,'-X','utf8','-B','scripts/run_tests.py']),('distribution',[H,'-X','utf8','-B','scripts/validate_release_distributions.py','--root','.']),('smoke',[H,'-X','utf8','-B','-m','se_harness','--help'])]
 for label,args in commands:
  p.run(label,args,cwd=R);x=load(O/(label+'.json'));print(label,x['exit'],round(x['elapsed_seconds'],1),flush=True)
elif mode=='governor':
 for ident in ['WO-HAG-009','WO-HAG-011']:
  v=p.gov(ident+'-preflight36','preflight',R,'--work-order',ident,'--phase','review','--json');assert v['ready'];print(ident,'ready',flush=True)
 v=p.gov('validation','validate',R,'--json'); assert v['error_count']==0; print('validation',v['artifact_count'],v['warning_count'])
elif mode=='commit':
 assert git('rev-parse','HEAD')=='28b9e95175945a2cf1d084470c24ca1f3cb0f8c8'
 assert sorted(git('diff','--name-only').splitlines())==sorted(changed)
 names=['resources','native','plugin','source','distribution','smoke','scope36','WO-HAG-009-preflight36','WO-HAG-011-preflight36','validation','canonical-section-comparison']
 assert all(load(O/(n+'.json'))['exit']==0 for n in names)
 E.mkdir(exist_ok=False)
 with zipfile.ZipFile(E/'checks.zip','x',zipfile.ZIP_DEFLATED) as z:
  for name in names:z.write(O/(name+'.json'),name+'.json')
 put(E/'inventory.json',{'archive':'checks.zip','sha256':sha((E/'checks.zip').read_bytes()),'files':[{'path':n+'.json','sha256':sha((O/(n+'.json')).read_bytes())} for n in names]})
 put(E/'review.md',(O/'review.md').read_text())
 paths=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
 assert all(x in changed or x.startswith(E.relative_to(R).as_posix()+'/') for x in paths)
 scope=tomllib.loads((D/'work-orders/WO-HAG-011.md').read_text().split('+++')[1])['execution_scope']['paths']
 assert all(any(x==s or s.endswith('/') and x.startswith(s) for s in scope) for x in paths)
 p.run('diff-check',['git','diff','--check'],cwd=R);p.run('stage',['git','add','--',*paths],cwd=R);p.run('staged-check',['git','diff','--cached','--check'],cwd=R)
 p.run('commit',['git','commit','-m','Include canonical entry conditions in focused instruction reads','-m','Harness-Work-Orders: WO-HAG-009, WO-HAG-011'],cwd=R)
 assert not git('status','--porcelain');put(O/'candidate-36.json',{'commit':git('rev-parse','HEAD'),'base':'55caaada508495bea7d97effd27644d1ce8373da'});print(git('rev-parse','HEAD'))
elif mode=='build':
 source=(W/'hag_efficiency_package03.py').read_text().replace('hag-efficiency-proposal-20261008','hag-procedure36-20261011')
 for a,b in [('candidate-03','candidate-36'),('build03','build36'),('package03','package36'),('client03','client36'),('native-efficiency03','native-procedure36'),("-03'","-36'")]:source=source.replace(a,b)
 exec(compile(source,'exact-build36','exec'))
else:raise ValueError(mode)
