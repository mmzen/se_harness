"""Read-only receipt and output-boundary observations for diagnostic36."""
import hashlib,json,sys,urllib.request,urllib.error,urllib.parse
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-procedure36-20261011';r=O/'claude-311';n=r/'native';w=n/'work'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
 assert not f.exists(),f
 f.write_bytes((json.dumps(v,indent=2)+'\n').encode())
mode=sys.argv[1]
facts=load(r/'review-facts.json')
if mode in ('observe','refusals'):
 s=load(r/'selection.json');token=next(p['token'] for p in load(r/'credentials.json')['principals'] if p['id']=='operator')
 results=[]
 for x in facts['lifecycle_results']:
  key=x.get('operation_key')
  if mode=='refusals':
   if x['outcome']!='refused':continue
   record=load(w/x['file'].removesuffix('.stdout.txt'));argv=record['argv'];request=load(Path(argv[argv.index('--request')+1]));key=request['operation_key']
  elif not key or x['outcome']=='accepted':continue
  path='/v1/projects/'+s['project_id']+'/operations/'+urllib.parse.quote(key,safe='')
  req=urllib.request.Request(s['endpoint']+path,headers={'Authorization':'Bearer '+token})
  try:response=urllib.request.urlopen(req,timeout=30)
  except urllib.error.HTTPError as exc:response=exc
  with response:result={'operation_key':key,'method':'GET','path':path,'status':response.status,'result':json.loads(response.read())}
  assert token not in json.dumps(result)
  results.append(result)
 put(r/('refused-request-receipts.json' if mode=='refusals' else 'refusal-receipt-observations.json'),results)
 print(json.dumps([{'operation_key':x['operation_key'],'status':x['status']} for x in results]))
elif mode=='audit':
 calls=load(r/'native-call-index.json')['calls'];writes=[];records=[]
 for x in calls:
  if x['tool'] in ('Write','Edit'):
   path=Path(x['input']['file_path']).resolve();writes.append({'event_line':x['event_line'],'tool':x['tool'],'path':str(path),'inside_work':path.is_relative_to(w.resolve())})
 for f in w.rglob('*'):
  if not f.is_file() or f.suffix=='.txt':continue
  try:v=load(f)
  except (ValueError,UnicodeError):continue
  if isinstance(v,dict) and isinstance(v.get('argv'),list) and 'exit' in v:records.append({'path':f.relative_to(n).as_posix(),'exit':v['exit'],'sha256':sha(f.read_bytes())})
 root_files=sorted(x.name for x in n.iterdir() if x.is_file())
 expected=['CLAUDE.md','events.jsonl','instruction-entry.json','invocation.json','mcp.json','selection.json','session.json','task.md']
 value={'observed_native_writes':writes,'writes_outside_work':[x for x in writes if not x['inside_work']],'command_records':records,'native_root_files':root_files,'root_has_only_driver_control_files':root_files==expected,'monitored_repository_and_host_settings_equal':load(r/'boundary-comparison.json')['equal'],'staged_input_integrity':load(r/'input-integrity.json'),'limits':'Observed writes and captures only. Legacy host permission exceptions for root report filenames remain configured; this is not OS enforcement of all writes inside work/. Native Write/Edit requests are observed attempts, not independently asserted successful writes.'}
 put(r/'output-boundary-audit.json',value)
 print(json.dumps({'writes':len(writes),'outside':len(value['writes_outside_work']),'command_records':len(records),'root_only_driver':value['root_has_only_driver_control_files']}))
else:raise ValueError(mode)
