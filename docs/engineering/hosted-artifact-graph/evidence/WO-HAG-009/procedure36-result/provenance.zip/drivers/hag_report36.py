"""Bind the manual diagnostic assessment to independently checked observations."""
import base64,hashlib,json
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'hag-procedure36-20261011';r=O/'claude-311';n=r/'native';w=n/'work';E=p.D/'evidence/WO-HAG-009/procedure36-result'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
 assert not f.exists(),f
 f.parent.mkdir(exist_ok=True,parents=True);f.write_bytes((v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
facts=load(r/'review-facts.json');metrics=load(O/'claude-311-summary.json');replay=load(r/'replay36/assessment.json');audit=load(r/'output-boundary-audit.json');calls=load(r/'native-call-index.json')['calls']
accepted=[x for x in facts['lifecycle_results'] if x['outcome']=='accepted'];assert len(accepted)==1 and len(replay['cases'])==1 and all(x['outcome']=='passed' for x in replay['cases'])
assert facts['parity']==[{'tool':'cypher','status':200,'exact_match':True,'complete':True,'continuation':None,'unresolved_references':[]}]
assert audit['monitored_repository_and_host_settings_equal'] and audit['staged_input_integrity']['all_unchanged'] and not audit['writes_outside_work']
assert metrics['native_calls']==101 and len(metrics['native_failures'])==14 and not (w/'native-report.md').exists() and not (w/'native-observations.json').exists()
assert not any(' assert-greeting ' in x['input'].get('command','') or ' observations ' in x['input'].get('command','') for x in calls)
old=load(w/'revise-spec-001.evidence/1-request.json');new=load(w/'revise-spec-002.evidence/1-request.json');before=base64.b64decode(old['document_base64']);after=base64.b64decode(new['document_base64']);assert before!=after
preview=load(w/'approve-all-v2-preview.json');stale=load(w/'stale-apply-001.json');result=load(w/'stale-apply-001.stdout.txt')
assert preview['action']==stale['action'] and new['artifact_id']=='SPEC-P3-001'
assert stale['preview_digest']==load(w/'approve-all-v2-preview.stdout.txt')['preview_digest'] and result['error']['code']=='HAG_REMOTE_STALE_CONTEXT'
assert accepted[0]['versions']['project']=={'before':17,'after':18}
assert any(x['operation_key']=='stale-apply-001' and x['status']==404 for x in load(r/'refused-request-receipts.json'))
claim={'native_report':'Absent at timeout; no final report claims can be assessed.','instruction_delivery':'Exact same-file entry conditions returned. Decision-rights read. Correct approved target already present at event 250 before later invalid states.','remaining_reads':'No observed capability, requirement, specification checklists; no approval-package assessment, work-approval authority or RESULTS section.','stale_inputs':'Selected SPEC bytes changed; old preview submitted with project 17 but stale context 0 instead of 1. STALE_CONTEXT refusal, receipt absent, next apply begins at project 17. This does not reach the digest-specific guard.','assertion':'No assert-greeting invocation or executed assertion evidence. REQ method test conflicts with VER inspection-only plan.','file_pointer':'New observations record pointer not invoked in this native trial; deterministic test only.','permission':'One prohibited ls attempt denied. Subsequent permitted lookup/read calls recover exact file.','traceback':'Event 194 is ValueError for a non-inventory instruction path; it is not Unicode or Windows encoding failure.'}
put(r/'claim-audit.json',claim)
assessment={'candidate':load(O/'candidate-36.json')['commit'],'trial':'claude-311','kind':'focused diagnostic, not full NQ-01 through NQ-05','verdict':'incomplete','session':facts['session'],'metrics':{k:metrics[k] for k in ['wall_seconds','native_calls','peak_input_context']},'failed_native_tool_items':14,'accepted_lifecycle_operations':1,'independent_replay':{'state':replay['state'],'accepted_operations_replayed':1,'all_passed':True,'native_exports':0},'findings':[{'check':'canonical entry-condition delivery','outcome':'pass for observed selected reads'},{'check':'required procedure/checklist use','outcome':'fail','details':claim['remaining_reads']},{'check':'Cypher MCP read','outcome':'pass','http':facts['parity']},{'check':'changed-draft stale request','outcome':'partial','details':claim['stale_inputs'],'old_document_sha256':sha(before),'changed_document_sha256':sha(after)},{'check':'approval','outcome':'recovered and independently replayed','history':'Four invalid state previews preserved before a passing approved packet.'},{'check':'start, scope refusal, assertion and valid handoff','outcome':'not completed'},{'check':'observation-file pointer','outcome':'not exercised natively; deterministic regression test passed'},{'check':'reporting','outcome':'incomplete; both required report files absent at timeout'}],'no_effects_evidence':{'stale_receipt_status':404,'next_accepted_before_project':17,'final_project_version':18},'interventions':'No native hints, supplied corrective commands, answers, operator graph mutations or permission changes. Read-only independent observers; declared 1200-second stop.','real_authority':'Git remains authoritative. No actual VREC or decision made.'}
put(r/'independent-assessment.json',assessment)
put(E/'assessment.md',f'''# Canonical entry conditions: focused Claude assessment

Candidate: `{assessment['candidate']}`. Draft PR #543 remains incomplete.

## Result

The correction delivers each selected instruction file's entry conditions and
places existing authority references beside their action. The observation helper
also identifies its saved record as a file and returns exact read arguments.
The native diagnostic confirms entry delivery and the decision-rights read.
It does **not** establish successful Claude qualification.

Claude311 reached its declared 20-minute limit: 101 tool calls, 14 failed tool
items, and 166,173 provider-reported peak input tokens. It authored six records,
froze a baseline, and eventually approved the six-record packet. One accepted
lifecycle operation replayed independently through released evaluator 0.22.1.
Freezing is separately recorded and is not counted as a lifecycle approval.
No start, scope-refusal demonstration, greeting assertion or handoff completed.
Both required report files were absent at timeout.

## Observations

| Check | Observed result |
| --- | --- |
| Entry conditions | DRAFT_DEFINITIONS, AUTHORIZE_WORK and EXECUTE_WORK returned their exact entry sections; no released instruction bytes changed |
| Decision authority | AUTHORITY decision-rights was read at event 250 |
| Remaining required reads | Capability, requirement and specification checklists, approval-package assessment, work-approval authority and RESULTS were not observed |
| Approval states | Four invalid previews used accepted/proposed states. The section already delivered at event 250 explicitly says approved. Recovery eventually applied approved to all six records |
| Cypher | One meaningful read returned HTTP 200 and matched independent HTTP exactly, complete with no unresolved references |
| Changed-draft refusal | Selected SPEC bytes changed. Old preview plus stale context was refused as HAG_REMOTE_STALE_CONTEXT. Independent lookup found no receipt; subsequent accepted apply began at project 17. The digest-specific stale-preview guard was not reached |
| Content consistency | REQ specifies a test, while VER and WO describe source inspection. No assertion ran |
| File discovery | A nonexistent instruction path, guessed local paths and invalid helper arguments caused failures. A prohibited ls was denied. No encoding failure is established by the traceback |
| New observation-file pointer | Not invoked during this trial; its exact-file regression test passed locally |
| Boundaries | 20 observed Write/Edit requests and 31 command captures remained under work/. All 120 staged input hashes and monitored repository/host settings were unchanged |

The earlier statement during observation that a traceback was an encoding error
was incorrect. The complete event 194 traceback is a ValueError for an instruction
path absent from the selected inventory. The report uses that actual cause.

## Checks and exact environment

The source suite ran 1,339 tests with 24 reported skips and exit 0. Focused resource,
native-driver and plugin suites, distribution validation and CLI smoke passed.
Five direct comparisons preserve exact released section bytes, lines and hashes.
Released validation: 1,991 artifacts, zero errors, 63 existing warnings. Scope
and review preflights passed. Implementation evidence is in
[procedure36](../../WO-HAG-011/procedure36/review.md).

Two pinned producer builds reproduced the candidate package. The six inspected
packaged reader/guide/contract files match exact candidate bytes. All 27 service
wheel members and the evaluator, runtime, database, protocol and dependency
identities match the prior qualification chain to VREC-HAG-005. Those service
scenarios were reused with this comparison; they were not rerun.

The native host reported claude-opus-4-6 and loaded candidate plugin 0.2.7 from
its isolated package. A live no-tools authentication probe passed. The candidate
client is 0.22.2; the real governor remains released 0.22.1 outside the checkout.
The task template is byte-identical to Claude301; only exact environment paths
changed. No instructions, answers or corrective hints were supplied during the
run. No operator wrote to the native graph after setup. The test container pair
was stopped after observations and replay; volumes remain preserved.

The write audit records observed behavior. Existing host exceptions for root
report filenames still existed; this is not proof of OS isolation to work/.
Explicit staged instruction reads do not qualify automatic host delivery.

## Assessment and next action

The small reader correction works, but instruction availability is not sufficient
to establish agent compliance. Repeating the same instructions or adding a
workflow runner is not justified by this result. Keep the exact state-selection,
checklist, path-recovery and content failures visible. Do not expand into service,
policy, permission or performance changes on the strength of this diagnostic.

Next, isolate the remaining command/path recovery and content-review problems
under the existing bounded correction scope. Require a successful focused result
before another complete paired run. Both hosts still need final-candidate full
qualification; earlier Codex results remain historical. Performance work stays
deferred. WO-HAG-009/010/011 remain in progress; no completion, real verification,
merge, release, installation or authority switch is recorded. The released
current step remains STEP-WO-IMPLEMENT-CHECK.

Before this update, all applicable technical checks on published head
28b9e95175945a2cf1d084470c24ca1f3cb0f8c8 passed; three conditional rehearsals were
skipped. The harness check failed QGP-G4I-EVIDENCE for unfinished WO-HAG-009.
This update preserves that blocker and the original full comparison base.

## Retained evidence

- [Visible native transcript](claude-311-visible.md): exact visible messages and tool exchanges; private reasoning and host/system messages omitted.
- [Native evidence inventory](claude-311-inventory.json) and [archive](claude-311-evidence.zip): requests, results, selected inputs, independent assessment, receipt observations, replay and boundary checks.
- [Build/driver provenance inventory](provenance-inventory.json) and [archive](provenance.zip): exact package comparisons, task equality, build commands and setup/observation drivers.
- Report checks are retained in report-checks.zip with its matching inventory after validation.

Earlier assessments and bound evidence remain unchanged. Raw account/auth logs,
credentials and private reasoning are excluded. Known test-token checks precede
retention. No failed, skipped or unperformed scenario is counted as a pass.
''')
readme=p.D/'README.md';s=readme.read_text();a=s.index('## Latest functional qualification');b=s.index('## Previous paired functional qualification',a);s=s[:a]+'''## Latest functional qualification

The [canonical entry-condition assessment](evidence/WO-HAG-009/procedure36-result/assessment.md)
records candidate `c526fcbe7ac59de9fd45cb8ae461cfb558aaf2b7`. Exact entry
conditions and decision authority now reach Claude. The focused run still times
out after 20 minutes: one approval replays and Cypher matches, but start, scope
refusal, the assertion and handoff remain incomplete. Required reads and content
consistency still fail. PR #543 remains draft; performance work stays deferred.

The [previous output-boundary result](evidence/WO-HAG-009/boundary35-result/assessment.md)
remains unchanged, including its failures and three replayed lifecycle operations.

'''+s[b:];readme.write_bytes(s.encode())
put(O/'pr-note36.md','''Harness-Work-Orders: WO-HAG-009, WO-HAG-010, WO-HAG-011

## Current result

Canonical instruction reads now include exact same-file entry conditions. Existing authority references sit beside their action, and observation results identify an exact file and read arguments.

[Latest assessment](REPORT_URL) records candidate c526fcbe7ac59de9fd45cb8ae461cfb558aaf2b7; evidence head REVIEW_HEAD. The 1,339-test source suite (24 skips), focused tests, package comparisons and local validation passed. Claude311 confirms entry delivery and one exact Cypher/HTTP match. One accepted approval replayed independently.

Qualification remains incomplete: the focused run timed out after 20 minutes, 101 calls and 14 failed items. Required reads, state selection and content consistency remain problematic; start, scope refusal, greeting assertion, handoff and final reports were not completed. The changed-draft request reached the stale-context guard, not the preview-digest guard. No encoding defect is established. Full evidence and previous failures are preserved.

## Delivery boundary

Keep this PR draft, codex/hosted-agent-qualification to main. Git remains authoritative. WO-HAG-009/010/011 remain in progress; QGP-G4I-EVIDENCE is an expected disclosed blocker. No verification, merge, release, deployment, host-plugin update or risk acceptance is claimed. Authentication and database ACL implementation remain deferred; existing sandbox controls stay. Performance work is deferred.

The next step is to isolate remaining command/path recovery and content-review failures before another complete paired qualification. This is an authorized unfinished-work review update, not a completion or merge request.
''')
print('assessment and report written')
