"""Retain exact bounded setup and observation drivers; omit private auth logs."""
import json,zipfile,hashlib,re
import hag_efficiency_plan as p
O=p.W/'hag-procedure36-20261011';E=p.D/'evidence/WO-HAG-009/procedure36-result'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
drivers=['hag_correction36.py','hag_canonical36.py','hag_full36.py','hag_focus36_task.txt','hag_full27.py','hag_native27.py','hag_efficiency_package03.py','hag_package36_review.py','hag_parity36.py','hag_native_parity19.py','hag_review36.py','hag_full27_review.py','hag_trace36.py','hag_full27_trace.py','hag_full36_facts.py','hag_retain36.py','hag_retain26.py','hag_provenance36.py','hag_watch36.py','hag_assess36.py','hag_report36.py']
for name in drivers:files['drivers/'+name]=(p.W/name).read_bytes()
for name in ['candidate-36','package-guidance-comparison','service-reuse-comparison','server-wheel-members','client-build-36','package-36','client-env-36','client-install-36','build36-replay','context-WO-HAG-009','context-WO-HAG-011','resume36-WO-HAG-009','resume36-WO-HAG-011','canonical-section-comparison','task-comparison']:
 files['checks/'+name+'.json']=(O/(name+'.json')).read_bytes()
for f in O.glob('claude311-*.json'):
 if 'live-probe' not in f.name:files['setup/'+f.name]=f.read_bytes()
for name in ['combination','image-metadata','image-package','plugin-assembly','plugin-claude-inventory','plugin-codex-inventory','server-build','source-commit','source-status']:
 files['package/'+name+'.json']=(O/'package36'/(name+'.json')).read_bytes()
tokens=[x['token'].encode() for f in O.glob('*/credentials.json') for x in load(f)['principals']]
for name,raw in files.items():
 assert not any(t in raw for t in tokens),name
 assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
with zipfile.ZipFile(E/'provenance.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
index={'archive':'provenance.zip','sha256':sha((E/'provenance.zip').read_bytes()),'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())],'limits':'No raw provider auth, private reasoning, credentials, account stores or full environments. Exact known test tokens checked absent.'}
(E/'provenance-inventory.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());print(len(files),'files')
