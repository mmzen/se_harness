"""Compare candidate section rendering with exact selected released bytes."""
import hashlib,json,sys
import hag_efficiency_plan as p
sys.path.insert(0,str(p.R))
from se_harness.resources import section_view
rows=[]
for resource,heading in [('docs/engineering/harness/AUTHORIZE_WORK.md','apply-the-selected-transitions'),('docs/engineering/harness/EXECUTE_WORK.md','start-the-selected-work'),('docs/engineering/harness/DRAFT_WORK_ORDERS.md','prepare-work-orders-wo-linking-the-definitions-scope-planned-work-and-verification-requirements'),('docs/engineering/harness/CONTINUE.md','procedure'),('docs/engineering/ARTIFACT_AUTHORING.md','verification')]:
 path=p.RES/resource; raw=path.read_bytes(); digest=hashlib.sha256(raw).hexdigest()
 view=section_view(raw,resource=resource,path=str(path),release={'version':'0.22.1'},sha256=digest,headings=[heading])
 lines=raw.decode().splitlines(keepends=True)
 for section in view['sections']:
  content=''.join(lines[section['start_line']-1:section['end_line']])
  assert section['content']==content
  assert section['content_sha256']==hashlib.sha256(content.encode()).hexdigest()
 assert len({x['heading'] for x in view['sections']})==len(view['sections'])
 assert heading in [x['heading'] for x in view['sections']]
 if '/harness/' in resource:assert {'read-this-when','before-this-action'}<={x['heading'] for x in view['sections']}
 else:assert len(view['sections'])==1
 rows.append({'resource':resource,'source_sha256':digest,'sections':[{k:v for k,v in s.items() if k!='content'} for s in view['sections']],'exact_source_bytes':True})
print(json.dumps({'release':'0.22.1','comparison':rows,'policy_or_source_changes':False},indent=2))
