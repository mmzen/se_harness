+++
id = "SPEC-P3-001"
type = "specification"
title = "Fixed rehearsal greeting output"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
contract = "Return the fixed greeting without external effects."

[relations]
specifies = ["REQ-P3-001"]
+++

# Fixed rehearsal greeting output

Synthetic rehearsal input. This is not a real human decision.

## In plain words

The fixture function greeting() returns the exact string `Hello rehearsal` with no side effects.

## Scope

This specification governs only the return value of the greeting() function. Implementation language, module location and import mechanism are left to other artifacts.

## Rules

**P3-GREET-001.** The fixture function greeting() MUST return the string `Hello rehearsal`.

**P3-GREET-002.** The fixture function greeting() MUST NOT produce external side effects.

## Failure behaviour

| Trigger | Response | Diagnostic |
| --- | --- | --- |
| greeting() returns a different string | Verification fails | Exact string mismatch |

## Examples

**Given** the greeting module is loaded, **when** greeting() is called, **then** the return value equals `Hello rehearsal` per P3-GREET-001.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-001 | P3-GREET-001, P3-GREET-002 |
