"""Retain exact build/setup and diagnostic drivers without private credentials."""
import json,zipfile,hashlib,re
import hag_efficiency_plan as p
O=p.W/'hag-claude-report32-20261011';E=p.D/'evidence/WO-HAG-009/report32'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
drivers=['hag_correction32.py','hag_full32.py','hag_full27.py','hag_native27.py','hag_efficiency_package03.py','hag_package32_review.py','hag_parity32.py','hag_native_parity19.py','hag_review32.py','hag_full27_review.py','hag_trace32.py','hag_full27_trace.py','hag_diagnostic32_facts.py','hag_retain32.py','hag_full27_retain.py','hag_retain26.py','hag_provenance32.py']
for name in drivers:files['drivers/'+name]=(p.W/name).read_bytes()
for name in ['candidate-32','package-guidance-comparison','service-reuse-comparison','server-wheel-members','client-build-32','package-32','client-env-32','client-install-32','build32-replay','claude271-auth-review','claude271-version','retention32-scope']:
 files['checks/'+name+'.json']=(O/(name+'.json')).read_bytes()
for f in O.glob('claude271-*.json'):
 if 'live-probe' not in f.name and 'auth-review' not in f.name and 'version' not in f.name:files['setup/'+f.name]=f.read_bytes()
for name in ['combination','image-metadata','image-package','plugin-assembly','plugin-claude-inventory','plugin-codex-inventory','server-build','source-commit','source-status']:
 files['package/'+name+'.json']=(O/'package32'/(name+'.json')).read_bytes()
files['setup/task-comparison.json']=(O/'claude-271/task-comparison.json').read_bytes()
tokens=[x['token'].encode() for f in O.glob('*/credentials.json') for x in load(f)['principals']]
for name,raw in files.items():
 assert not any(t in raw for t in tokens),name
 assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
with zipfile.ZipFile(E/'provenance.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
index={'archive':'provenance.zip','sha256':sha((E/'provenance.zip').read_bytes()),'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())],'limits':'No raw provider auth, private reasoning, credentials, account stores or full environments. Exact known test tokens checked absent.'}
(E/'provenance-inventory.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());print(len(files),'files')
