"""Direct hosted discovery and evidence-grounded reporting under WO-HAG-011."""
import json,os,re,subprocess,sys,tempfile,tomllib,zipfile,hashlib
from pathlib import Path
import hag_efficiency_plan as p
W,R,D=p.W,p.R,p.D;O=W/'hag-claude-report32-20261011';p.O=O
E=D/'evidence/WO-HAG-011/report32';H=Path('C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe')
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
changed=['plugins/verity-plane/common/skills/harness-orient/references/hosted-reads.md']
def git(*a):return subprocess.check_output(['git',*a],cwd=R,encoding='utf-8').strip()
def put(f,v):
 assert not f.exists(),f
 f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
mode=sys.argv[1]
if mode=='test':
 for file in changed:
  path=R/file
  for target in re.findall(r'\]\(([^)]+)\)',path.read_text()):
   name,_,head=target.partition('#');dest=(path.parent/name).resolve();assert dest.is_file(),target
   if head:assert re.search(r'^#+ '+re.escape(head.replace('-',' '))+r'\s*$',dest.read_text(),re.M|re.I),target
 lifecycle=R/'plugins/verity-plane/common/skills/change/references/hosted-test-lifecycle.md'
 sys.path.insert(0,str(R));from se_harness.resources import section_view
 for selector in sorted(set(re.findall(r'`(docs/engineering/[^`]+#[^`]+)`',lifecycle.read_text()))):
  file,head=selector.split('#');raw=(p.RES/file).read_bytes();section_view(raw,resource=file,path=str(p.RES/file),release={'version':'0.22.1'},sha256=sha(raw),headings=[head])
 put(O/'content-review.json',{'files':changed,'outcome':'pass','scope':'One reporting handoff link only; no server, evaluator, schema, criterion, fixture answer or permission change.','design':'The read procedure directly links its next reporting action to the existing evidence guide. It adds no duplicated reporting rule, command, gate or template.','links':'Relative files/anchors and current lifecycle released selectors resolved. New subheadings remain inside their parent selection sections.','native_plan':'First run a bounded read/report diagnostic on the packaged candidate. Only if discovery and report review pass, rerun affected lifecycle qualification from a fresh project. Historical failures and original reports remain unchanged.'})
 scratch=Path('C:/Users/mathi/AppData/Local/Temp/hag32');scratch.mkdir(exist_ok=True);os.environ.update(TEMP=str(scratch),TMP=str(scratch));tempfile.tempdir=str(scratch)
 for label,args in [('focused',[H,'-X','utf8','-B','-m','unittest','discover','-s','tests/hosted_artifact_graph','-p','test_native*.py']),('source',[H,'-X','utf8','-B','scripts/run_tests.py']),('distribution',[H,'-X','utf8','-B','scripts/validate_release_distributions.py','--root','.']),('smoke',[H,'-X','utf8','-B','-m','se_harness','--help'])]:
  p.run(label,args,cwd=R);v=load(O/(label+'.json'));print(label,v['exit'],round(v['elapsed_seconds'],1),v['stderr'][-220:],flush=True)
elif mode=='check':
 assert sorted(git('diff','--name-only').splitlines())==sorted(changed)
 paths=changed+[(E/n).relative_to(R).as_posix() for n in ['review.md','checks.zip','checks-inventory.json']]
 args=['check',R,'--artifact','WO-HAG-011','--checkpoint','scope','--changes-complete']
 for path in paths:args+=['--changed-path',path]
 for name,args in [('scope',args+['--json']),('preflight',['preflight',R,'--work-order','WO-HAG-011','--phase','review','--json']),('validation',['validate',R,'--json'])]:p.gov(name,*args);print(name,'pass',flush=True)
elif mode=='commit':
 assert git('rev-parse','HEAD')=='5faa86d0616084bd69ae947e5f558b853d61c437'
 names=['focused','source','distribution','smoke','scope','preflight','validation'];assert all(load(O/(n+'.json'))['exit']==0 for n in names)
 E.mkdir(exist_ok=False)
 names+=['content-review']
 with zipfile.ZipFile(E/'checks.zip','x',zipfile.ZIP_DEFLATED) as z:
  for n in names:z.write(O/(n+'.json'),n+'.json')
 put(E/'checks-inventory.json',{'archive':'checks.zip','sha256':sha((E/'checks.zip').read_bytes()),'files':[{'path':n+'.json','sha256':sha((O/(n+'.json')).read_bytes())} for n in names]})
 put(E/'review.md', (O/'review.md').read_text())
 paths=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
 assert all(x in changed or x.startswith(E.relative_to(R).as_posix()+'/') for x in paths)
 scope=tomllib.loads((D/'work-orders/WO-HAG-011.md').read_text().split('+++')[1])['execution_scope']['paths'];assert all(any(x==s or s.endswith('/') and x.startswith(s) for s in scope) for x in paths)
 p.run('diff-check',['git','diff','--check'],cwd=R);p.run('stage',['git','add','--',*paths],cwd=R);p.run('staged-check',['git','diff','--cached','--check'],cwd=R)
 p.run('commit',['git','commit','-m','Link hosted read completion directly to evidence reporting','-m','Harness-Work-Order: WO-HAG-011'],cwd=R)
 assert not git('status','--porcelain');put(O/'candidate-32.json',{'commit':git('rev-parse','HEAD'),'base':'55caaada508495bea7d97effd27644d1ce8373da'});print(git('rev-parse','HEAD'))
elif mode=='build':
 source=(W/'hag_efficiency_package03.py').read_text().replace('hag-efficiency-proposal-20261008','hag-claude-report32-20261011')
 for a,b in [('candidate-03','candidate-32'),('build03','build32'),('package03','package32'),('client03','client32'),('native-efficiency03','native-report32'),("-03'","-32'")]:source=source.replace(a,b)
 exec(compile(source,'exact-build32','exec'))
else:raise ValueError(mode)
