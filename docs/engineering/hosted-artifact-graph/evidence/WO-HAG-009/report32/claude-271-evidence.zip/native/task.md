## Selected instruction entry

The following complete canonical sections are already supplied in this context. Apply them before commentary and actions. Reuse them while unchanged and retained; read additional references only when their conditions apply. After compaction, recover this entry from task.md. Explicit task inputs, not automatic startup-delivery evidence. Pointers are not artifact content reads.

Source: {"resource": "docs/engineering/harness/COMMUNICATION.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-claude-report32-20261011\\claude-271\\native\\inputs\\released-resources\\docs\\engineering\\harness\\COMMUNICATION.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "2aa70bc7959c3a1075adf9fd163225a6a8d92216cf8b054cd677fe94e8ea15cf"}

# Communication

## Purpose and claim

This policy controls eligible English prose written by agents for operators and
technical artifacts. It uses selected clarity principles based on ASD-STE100.
It is not ASD-STE100 compliance, certification, approval, or endorsement.

An agent MUST NOT download, search for, bundle, reproduce, parse, or attempt to
strictly implement ASD-STE100 or a controlled dictionary. The installed policy
is complete for its declared purpose.

## Eligible prose

Eligible prose is agent-authored English explanation that is not protected
content (see next section). For eligible prose, the agent SHOULD:

- use one stable term for one concept;
- define an uncommon project term before relying on it;
- identify the responsible actor when responsibility matters;
- state conditions, actions, and results directly;
- prefer active voice when it identifies responsibility;
- keep each sentence focused on one principal action;
- avoid ambiguous pronouns, decorative synonyms, hidden negation, vague
  references, and unnecessary introductions; and
- use a list or table when it clarifies parallel conditions, mappings, or
  ordered steps.

Sentence length is a review signal. It is not a conformance threshold and does
not justify removing necessary technical detail.

## Protected content

Exact protected content MUST remain byte-identical. It includes:

- code and inline code;
- commands, paths, identifiers, hashes, version strings, URLs, schemas, and
  field names;
- JSON, TOML, YAML, XML, and other machine-readable data;
- logs, diagnostics, evidence, evaluator output, and canonical restitution
  blocks;
- quotations; and
- operator-supplied text that is presented as supplied text.

Protected content MUST NOT be automatically paraphrased. It includes BCP 14 obligations, 
requirement statements, lifecycle and decision meanings, safety or legal qualifications, 
acceptance thresholds, formulas, and established terminology.

## Existing artifact pointers

These records are available for inspection. Their presence does not establish that they cover this request. Select and read the applicable records before making content claims.

[{"id": "CAP-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-claude-report32-20261011\\claude-271\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\capabilities\\CAP-P3-900.md", "sha256": "f00af6febc1d62752cab0364e3f4e80e227438f494d98d9f02a9a5c7fdc30bc0"}, {"id": "INT-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-claude-report32-20261011\\claude-271\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\intent\\INT-P3-900.md", "sha256": "20649db79738fdf649578286679d6fe05491e460c5a41e68ba0ed3161c47e7ed"}, {"id": "REL-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-claude-report32-20261011\\claude-271\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\release\\REL-P3-900.md", "sha256": "a7cc92f770027bae2ffbf987a1a83eb36bd5e012632e1db07cf5f377f6b12935"}, {"id": "REQ-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-claude-report32-20261011\\claude-271\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\requirements\\REQ-P3-900.md", "sha256": "99028b8605edfd6e85d3cbfb0ee5243f43df69059e314ed1f0b9ab0bde0bbba4"}, {"id": "SPEC-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-claude-report32-20261011\\claude-271\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\specifications\\SPEC-P3-900.md", "sha256": "0904f98bddc075f26c87e2e2ce603e3d74a497b8df85e1093bf3b0f5f35a45f9"}, {"id": "VER-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-claude-report32-20261011\\claude-271\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\verification\\VER-P3-900.md", "sha256": "9c975ff911c736f30dab7688df8f136e66eefd81eebc09362d0345cef813e8b4"}, {"id": "WO-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-claude-report32-20261011\\claude-271\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\work-orders\\WO-P3-900.md", "sha256": "98ac1fa85021ac8a6f4d7a74973e2148dac97aa6ca69064d847818efc3771332"}]
Before your first explanation, apply the supplied sections and read only the applicable plugin instructions and prerequisites still missing from context. Use the existing file tools below. This explicit test setup does not establish automatic startup instruction delivery.

Inspect the canonical source fixture through the selected private hosted service. Demonstrate all seven read-only MCP tools, including a meaningful Cypher read, and produce an evidence-backed report of what happened and what the public read interface supports. This is a focused discovery/reporting diagnostic under WO-HAG-009/011 and VER-HAG-007. It is not a full lifecycle qualification.

The exact selection, candidate, source manifest, client, plugin and released evaluator are in C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-claude-report32-20261011\claude-271\native\selection.json. The fresh project starts at version 0. You may import the supplied canonical fixture once to establish its immutable baseline. That is the only authorized mutation here. Choose requests from the selected instructions yourself. Do not create drafts, approve records, run lifecycle transitions, export, reset or publish anything. Git remains authoritative.

Use the imported baseline for the read tools. Inspect the actual returned content, completeness and selected view. Report observed successes, refusals, failures and limitations. Explain the public support for relationship reads and return-column aliases using the selected documentation; distinguish supported behavior from what you actually executed. No query or expected graph answer is supplied.

Use the candidate plugin's task routes. Your writable output directory is `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-claude-report32-20261011\claude-271\native\work`. Inputs under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-claude-report32-20261011\claude-271\native\inputs` are read-only. The exact permitted helper prefix is:

```text
"C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe" -I "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-claude-report32-20261011/claude-271/native/inputs/native_call.py"
```

Append one helper operation per shell call. The tool index is `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-claude-report32-20261011\claude-271\native\inputs\native-tools.md`. Native file tools remain available. No arbitrary commands, shell wrappers, pipelines or permission changes. Stop a denied action; do not switch routes to evade it.

Retain requests/results, `work/native-report.md` and `work/native-observations.json`. The report should allow an independent reviewer to distinguish complete observations from remaining gaps. This test grants no real verification, release, deployment or authority switch.


Start instruction discovery at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-claude-report32-20261011\claude-271\native\inputs\plugin\verity-plane\skills\setup\SKILL.md`. Follow its route for this selected target. Read current prerequisites before acting; reuse unchanged content already retained in context.
