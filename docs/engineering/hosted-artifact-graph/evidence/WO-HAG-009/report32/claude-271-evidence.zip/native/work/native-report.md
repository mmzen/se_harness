# Native MCP read-tool discovery report

Diagnostic scope: WO-HAG-009/011 and VER-HAG-007. This is not a full lifecycle
qualification. Git remains authoritative. All results are test-copy data under
`authority: "rehearsal-only; Git remains authoritative"`.

## Identities

| Identity | Value |
| --- | --- |
| Hosted baseline B | `se-harness-artifact-baseline/v1:sha256:523119fcafc5d456596381cb4ba5c92e5378566fbcd8686d27661402eac3af58` |
| Source fixture S | `5820415917e87b64d80bad2f7c39c6d18d692829` |
| Actual candidate C | `1e9a1a10a3f1fab5b71ea29476c6f0d12ff27556` |
| Test candidate P | Unknown; no lifecycle operation performed in this session |
| Project ID | `4e7140f8-dcc0-4db9-aeec-e61f845967a3` |
| Evaluator | 0.22.1 (archive `cb35c3c4...`, payload `0e7b7c2b...`) |
| Client | 0.22.2 (wheel `db603daf...`) |
| Response schema | `se-harness-graph-read/v2` |

## Setup and import

The service reported `ready: true`, `authority_mode: sandbox-projection`,
`test_copy: true` and matching component identities at project version 0.
All component fields matched the selected `configuration.json`.

The source manifest (7 artifacts from commit S) was imported with operation key
`import-baseline-01`. The evaluator reported `valid: true` with 0 errors and
1 advisory (`W-AUT-022`: coverage row `REQ-P3-900` names undefined rule
`P3-GREET-900`). Project version advanced from 0 to 1. Evidence:
`work/rec-import-01.json`.

## MCP tool results

All seven read-only MCP tools were exercised against baseline B. Each tool's
`test_copy` field was `true`.

| Tool | Target | complete | Unresolved refs | Outcome |
| --- | --- | --- | --- | --- |
| `revision` | WO-P3-900 | true | 0 | Returned StoredRevision with envelope, document and git provenance |
| `work-context` | WO-P3-900 | true | 0 | Returned 5 governing artifacts, 2 declared paths, evaluator check output |
| `check` | WO-P3-900 | true | 0 | Returned checkpoint-free check; compliance `not_assessable`, 0 blockers |
| `impact` | REQ-P3-900 | true | 0 | Returned 4 impacted artifacts and 6 declared relations |
| `lineage` | VER-P3-900 | true | 0 | Returned 1 connected artifact (WO-P3-900) through verification relation |
| `compare` | B vs B | true | 0 | Empty changes and relations (identical views) |
| `cypher` (attempt 2) | `MATCH (r:Revision)` | true | 0 | Returned 7 rows (all draft artifacts) with aliased columns |

### revision

Read the complete `StoredRevision` for `WO-P3-900` at revision
`sha256:8621bf65...`. The envelope contains `declared_relations` with three
relation kinds (`implements`, `specifications`, `verification`), Git provenance
(blob OID `52e49c2e...`, commit S), and the original path
`docs/engineering/lifecycle-pilot/work-orders/WO-P3-900.md`. The `document_base64`
field contained the complete TOML+Markdown document.

### work-context

Returned the work order binding for `WO-P3-900` with five governing artifacts
(`CAP-P3-900`, `INT-P3-900`, `REQ-P3-900`, `SPEC-P3-900`, `VER-P3-900`),
declared scope (`src/greeting.py`, `docs/engineering/lifecycle-pilot/`), empty
dependencies and relevant decisions. The evaluator output included instruction
discovery with procedure `PROC-FOCUS-SELECTED` and result digest
`1f21d2cade0e7c6e9643b51c5cf5c1f7835847029005e8bbb97c40f6d197a899`.

### check

Returned the checkpoint-free released check for `WO-P3-900`. Compliance status
was `not_assessable` (pre-action checkpoint). No scoped or repository blockers.
The evaluator output matched the `work-context` result exactly (same
`result_sha256`).

### impact

Root `REQ-P3-900` returned four impacted artifacts: `REL-P3-900`, `SPEC-P3-900`,
`VER-P3-900` and `WO-P3-900`. Six declared relations were returned:
`SPEC-P3-900 --specifies--> REQ-P3-900`, `VER-P3-900 --verifies--> REQ-P3-900`,
`WO-P3-900 --implements--> REQ-P3-900`, `WO-P3-900 --specifications--> SPEC-P3-900`,
`WO-P3-900 --verification--> VER-P3-900`, and `REL-P3-900 --gates--> WO-P3-900`.
The root artifact is excluded from the returned artifact list, consistent with
the documented contract.

### lineage

Root `VER-P3-900` returned one connected artifact (`WO-P3-900`) through a
`verification` relation. No VREC or evidence chain is linked at the imported
baseline, which is consistent with all artifacts being in draft status.

### compare

Compared baseline B against itself. The result contained empty `changes`,
`added_relations` and `removed_relations` arrays, which is the expected outcome
for identical views.

### cypher

**Attempt 1 (refused):** Used relationship traversal syntax
(`MATCH (r:Revision)-[:DECLARES]->(a:Artifact)`). The service refused with
`HAG_REMOTE_QUERY_SYNTAX` (HTTP 400). This establishes that relationship
traversal patterns are outside the admitted Cypher form.

**Attempt 2 (accepted):** Used the documented admitted form
(`MATCH (r:Revision) WHERE r.status = $status RETURN r.artifact_id AS id, r.status AS status LIMIT 10`).
The service returned 7 rows listing all artifacts with `status = "draft"`.
Column aliases (`AS id`, `AS status`) work correctly. Parameterized property
comparison via `$status` was accepted.

## Relationship reads: documented support vs observed behavior

The public read interface supports relationship data through three domain
operations: `impact`, `lineage`, and `compare`. These return declared relations
as structured edge objects with `source`, `kind` and `target` bindings. The
`revision` tool returns `declared_relations` within the envelope. The `cypher`
tool provides constrained graph exploration but does not support relationship
traversal patterns in the admitted query form.

**Documented support** (from `hosted-artifact-graph.md#physical-representation`
and `lifecycle-v2.md#bounded-cypher-reads`):
- Public edge labels: `HAS_REVISION`, `SELECTS`, `BASED_ON`, `PROPOSES`, `DECLARES`.
- `DECLARES` exposes `kind` and `target_artifact_id` properties.
- Cypher admits one `MATCH` or `OPTIONAL MATCH` path with labelled nodes,
  optional parameterized property comparisons, `RETURN`, and a numeric `LIMIT`.
- Unlabelled nodes, `WITH`, aggregation and arbitrary database syntax are not
  part of the admitted form.

**Observed behavior:**
- `impact` and `lineage` returned relation edges that correspond to `DECLARES`
  edges resolved through the selected view.
- `compare` returned empty relation differences for identical views.
- Cypher rejected the relationship traversal pattern `-[:DECLARES]->` and accepted
  a single-node `MATCH` with parameterized property filter.
- The domain reads (`impact`, `lineage`) are the supported route for relationship
  traversal at the read interface, not Cypher relationship patterns.

**Return-column aliases** in Cypher are supported. The response uses the aliased
column names in the `columns` array, and each row contains values in the same
order. This was observed with `AS id` and `AS status` aliases.

## Failures, recoveries and limitations

| Action | Outcome | Recovery |
| --- | --- | --- |
| Read `hosted-artifact-graph.md` from `source/` | File not found | Located in `reference/` via `find-file`; read with native Read |
| `instructions --section` with `docs/` or `reference/` prefix | ValueError (not in inventory) | Used native Read on absolute path |
| Cypher with `-[:DECLARES]->` traversal | Refused (HAG_REMOTE_QUERY_SYNTAX) | Rewrote query to admitted single-node form |

No permission denials from the host or client occurred. No uncertain effects
remain. All MCP tool calls completed without transport errors.

## Captured evidence

| Record | Purpose |
| --- | --- |
| `work/rec-status-01.json` | Service status and component verification |
| `work/rec-import-01.json` | Source import result, evaluator output, baseline identity |
| `work/rec-observations-01.json` | Captured call summary (31 native calls, 3 failures) |
| `work/native-observations.json` | Structured per-tool observations |
| `work/native-report.md` | This report |

## Gaps

- `compare` was tested only with identical views (same baseline on both sides).
  A meaningful comparison requires a second distinct view (e.g., a draft context
  with modified artifacts), which was not created in this read-only diagnostic.
- Cypher relationship traversal was not successfully exercised. The domain reads
  (`impact`, `lineage`) provide the equivalent relationship data.
- No context-based views were tested. All reads used the imported baseline view.
- Database read-only enforcement remains unverified (RISK-HAG-001).
- This diagnostic grants no verification, release, deployment or authority.
