+++
id = "VER-P3-901"
type = "verification"
title = "Retain an independent exact greeting assertion"
status = "approved"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-10T12:30:17Z"
decided_by = "test-owner"
reason = "Synthetic test-owner accepts the complete greeting test definition under task.md."
+++

# Exact greeting verification

## Independence

The expected value comes from REQ-P3-901 and SPEC-P3-901, fixed by the task owner. Candidate output does not define the expected value. The executor is test-executor; quality-owner assesses the test verification record.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-901 | inspection | Inspect the selected source and its SHA-256 | Source is the selected fixture at SHA-256 dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1 and defines greeting() |
| REQ-P3-901 | test | Local exact greeting assertion; docs/engineering/lifecycle-pilot/evidence/WO-P3-901/assertion.json | The call succeeds and returns exactly Hello rehearsal; retain actual output and exit result |

## Planned execution

On this Windows host, use the selected Python 3.14 helper with its documented assert-greeting operation. Retain the local record at `C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-lifecycle-native26-20261010/codex-211/native/work/assertion.json`. The approved helper prefix is supplied in selection.json; invoke it once with `assert-greeting --record` and that absolute destination. Inspect the full result before handoff. The service runs no source test.

## Evidence retention

Hand off the exact assertion result bytes as `docs/engineering/lifecycle-pilot/evidence/WO-P3-901/assertion.json`. Retain source inspection identity, actual commands, complete receipts and earlier/later immutable exports under this test's work directory. The released evaluator 0.22.1 assesses lifecycle gates and candidate bindings. Require a commit-bound VREC for the disposable Git candidate produced by the service.

## Failure and limits

Any mismatch, exception, unreadable evidence, changed fixture hash or refused gate blocks the dependent claim. This simple no-argument fixture has no meaningful additional input cases. Export and VREC checks establish test-record integrity, not correctness of the real implementation candidate or real release authority.

