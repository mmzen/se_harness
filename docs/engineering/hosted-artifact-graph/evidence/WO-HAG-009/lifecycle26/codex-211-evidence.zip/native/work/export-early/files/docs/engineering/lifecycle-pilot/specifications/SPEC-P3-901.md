+++
id = "SPEC-P3-901"
type = "specification"
title = "Local greeting return value"
status = "approved"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
contract = "The existing no-argument greeting() returns the exact string Hello rehearsal."

[relations]
specifies = ["REQ-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-10T12:30:17Z"
decided_by = "test-owner"
reason = "Synthetic test-owner accepts the complete greeting test definition under task.md."
+++

# Local greeting contract

## Behavior and example

Inspect `src/greeting.py` in the selected immutable fixture. A call to `greeting()` returns `Hello rehearsal` with no leading or trailing characters. For example, `greeting() == 'Hello rehearsal'` evaluates to true.

## Failure behavior

A different result or exception is a failed qualification check. Retain the actual diagnostic and stop dependent verification. The fixture has no input-dependent failure case; no new error interface is required.

## Design

The existing constant return is sufficient for this one fixed output. No source modification, new dependency, architecture or configurable behavior is needed.
