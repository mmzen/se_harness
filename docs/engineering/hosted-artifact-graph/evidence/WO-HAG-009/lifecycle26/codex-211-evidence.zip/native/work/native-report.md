The requested hosted test lifecycle completed. The exact local assertion passed, WO-P3-901 is implemented, VREC-P3-901 is verified, and RLS-P3-901 is released for test version 0.0.1. These are synthetic decisions in the disposable service. Independent Git reconstruction and released-evaluator replay remain for the reviewer.

The final validation inspected 18 artifacts: valid=true, zero errors, zero warnings, and one preserved advisory from imported history: `W-AUT-022: Coverage row REQ-P3-900 names undefined rule P3-GREET-900.` See [final validation](056-final-validate.json.stdout.txt). Context reporting and successful preparation were not treated as passed transition gates. The verification and release transitions each reported compliance `pass` with no scoped or repository blockers.

The selected service is `http://127.0.0.1:58435`, project `4b5add16-156c-4c27-abec-a006d61f68eb`, context `3b148f55-e951-42ed-8cf4-f7bb2fa2d6c0`. Final project/context versions are 28/26. The installed candidate client is 0.22.2, wheel SHA-256 `d6577c4a549b5f12847f04eb9dd349ac0f42d9531875d3b217984bad4ab2c75a`. The service used released evaluator 0.22.1, archive SHA-256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`, payload SHA-256 `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff`.

The source provenance commit is `5820415917e87b64d80bad2f7c39c6d18d692829`. The test VREC and RLS both bind `137b13490a1a86020e6739a133c4f79249859681`. The later governance head is `3d18b107abffabaf3383c668c8d74b4485569b34`. These test identities do not verify the real implementation qualification candidate `d31e337425696c944ee61eda9957b6ac4bd2c82b`.

The inspected [exported source](export-later/files/src/greeting.py) is unchanged:

```python
def greeting():
    return 'Hello rehearsal'
```

Its SHA-256 is `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`. The approved local assertion invoked the supplied client Python with isolated mode and bytecode writes disabled. [The exact record](assertion.json) contains the command, exit 0, empty stderr, and stdout `exact greeting passed\n`. Its SHA-256 is `cc676d3120e1f04bb86c54c76d66bc9ff82381e2b717231ec68b23fc2a8560f4`; the handoff and final export retain these same bytes. The assertion ran against the immutable local fixture. The service did not run a source test; its candidate manifest binds the identical source hash.

New INT, CAP, REQ, SPEC, VER and REL definitions were authored and content-reviewed separately from template admission, then approved as P3-901. WO-P3-901 uses narrow paths for those records, its source, evidence, and generated risk/decision/VREC/RLS records. The released generated-output policy covers each declared evaluator sidecar. The valid Git handoff evaluated all 12 changed paths. No source change was needed.

The test risk is RISK-P3-901. Its paired DEC-P3-901 is decided with option `mitigate`, actor `test-owner`, and mitigation WO-P3-901. The risk remains mitigating; risk acceptance was not inferred. Definitions/work/decision use test-owner, execution uses test-executor, VREC uses quality-owner, and RLS uses release-owner.

| Required case | Observed result | Retained evidence |
| --- | --- | --- |
| Stale preview after selected draft change | HTTP 409 `HAG_REMOTE_STALE_PREVIEW`; no receipt, changed files or affected revisions. Fresh preview at the unchanged 17/15 versions still saw draft definitions. | 020 through 023 command records; corresponding requests |
| Uncertain accepted reply | Apply returned transport exit 2. Lookup of original key `native-definition-apply` recovered the accepted effect. | [uncertain call](024-definition-apply.json), [recovery](025-recover-definition.json) |
| Identical retry | Returned byte-identical response and the same receipt; one project/context increment, 17/15 to 18/16. | [retry](026-identical-retry.json) |
| Changed content under accepted key | HTTP 409 `HAG_REMOTE_KEY_REUSE`; no duplicate or changed effect. | [refusal](027-changed-key.json) |
| Out-of-scope handoff | HTTP 422 `HAG_REMOTE_EVALUATOR_REFUSED`, predicate `QGP-G4I-PATHS`: `WEX201: changed path is outside execution scope: docs/outside-greeting-scope/assertion.json`. Valid preview used the same 22/20 versions; valid apply advanced once to 23/21. | [refusal](040-handoff-out-of-scope.json), [valid preview](041-handoff-preview.json), [apply](042-handoff-apply.json) |
| Completion and assurance | WO implemented; VREC verified; RLS released after their selected checks and supplied synthetic decisions. | 044, 046, 049, 051 and 054 command records |

The recovered and retried full response files have identical SHA-256 `310169857fa910fb91ac9ba5a53982bfa963933d98d9f3434bed0e1902f3cec6`. Their receipt is `sha256:a94c64c420c6e578059756edb29d58386a6cc4ddb7fa2542eb015878dec02ee1`; request digest is `sha256:be64b94498be7409a162a0bbd001408e74851b4472c7e453573b1ea8474716a0`. The identical retry reused the original request file. No retry loop was used.

All seven configured read-only hag MCP tools were exercised: revision, work-context, check, impact, lineage, compare, and cypher. Exact requests/responses are in [mcp](mcp/), with views and completeness summarized in [observations](native-observations.json). The initial template revision was incomplete because its relation targets were placeholders; the continuation requested a new complete view. The revised approved view resolved those references. The six other selected reads were complete with null continuation; the later verified VREC revision at context 24 was also complete with no unresolved references. A read result did not supply decision authority.

| Export | Baseline | Snapshot |
| --- | --- | --- |
| [Earlier manifest](export-early/manifest.json), 19 files | `se-harness-artifact-baseline/v1:sha256:380f3a35696d02ed1c27f856ba3ca17bd478a09bd42c48bc117216bb056577f8` | `sha256:2353e57747dfe0d1d942c0284a428cf44f0bb1fe75efcd7fb70e03cb226b3fc8` |
| [Later manifest](export-later/manifest.json), 28 files | `se-harness-artifact-baseline/v1:sha256:6b66e8a3ce0ab2c9a9521a3d6e1e47ed7490c55d94524d00539ec8afb3dc7a30` | `sha256:a99cf931d823fdad3975f2802bf708b553e9232207f6f8c44c0ebf141e7e6a5d` |

The exports use separate new destinations and include exact files, manifest and Git bundle. Two additional exports, export-vrec-ready and export-rls-ready, supported inspection before the decisions. The client reported successful downloads with `independent_replay: "not yet performed"`. Source and all seven imported -900 file hashes match the immutable inputs in both earlier/later manifests. The final candidate provenance retains the original test candidate and its evidence hashes. Export success is not an independent replay verdict.

The final [VREC](export-later/files/docs/engineering/lifecycle-pilot/verification-records/VREC-P3-901.md) and [RLS](export-later/files/docs/engineering/lifecycle-pilot/releases/RLS-P3-901.md) retain their original preparation fields and later synthetic decisions. Generated narrative still describes the original ready proposal; the explicit current status and lifecycle events show verified/released. Generated bytes were preserved. The RLS evaluator evidence verifies the full released payload. The proposed label `test-v0.0.1` is metadata only.

Additional execution issues are retained in the observations: an unavailable JavaScript `structuredClone` before a request write; a missing instruction heading recovered by locating its actual combined heading; and a chunk read with limit 10000 refused because the maximum is 4096, followed by a valid JSON-pointer schema read. A metadata lookup batch produced 30 empty collected outputs; those outputs supplied no evidence. Hashes were recovered from the immutable inventory metadata without treating inventory entries as content reads. No host permission denial was observed, and no permission route was changed. No additional human intervention occurred after the supplied task decisions.

The [read trace](native-file-read-trace.json) records exact selected input and inspected output paths, hashes and read triggers. The helper returned an empty file-read list, so this is an agent-maintained index, not a complete chronological count of every repeated read. The retained native tool results carry the exact section and JSON-pointer selections. The observations snapshot reported 258 tool items, but its native-call count is explicitly incomplete; wall time and context metrics are unavailable. Its calls-at-most-15 efficiency goal was missed. Exported copies of assertion.json in the command inventory represent one execution, not extra tests.

No real repository was activated or modified, and no push, tag, publication, installation or deployment was performed. Automatic startup instruction delivery is not established: task.md supplied the instruction entry explicitly. The next accountable action is the independent reviewer's reconstruction of the exports and verification of exact bytes and original candidate bindings with released 0.22.1. This report makes no independent qualification verdict about the real candidate.

