+++
id = "REL-P3-901"
type = "release_contract"
title = "Assess test version 0.0.1 with exact greeting evidence"
status = "approved"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
gates = ["WO-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-10T12:30:17Z"
decided_by = "test-owner"
reason = "Synthetic test-owner accepts the complete greeting test definition under task.md."
+++

# Test release 0.0.1

## Release scope and version

Include only WO-P3-901 in test version 0.0.1. The release record binds the exact disposable candidate from an explicitly verified VREC covering WO-P3-901 and VER-P3-901. The candidate is selected by capture, not invented in this draft.

## Required evidence

Require the exact local greeting assertion, source hash, passing released 0.22.1 gates, retained requests/receipts, and complete earlier and later exports. The operator must be able to inspect the source and test record. The independent reviewer assesses Git replay separately.

## Authority and compatibility

release-owner prepares and assesses the synthetic release record after its gates pass. This contract authorizes no tag creation, publication, deployment or real release. The existing fixture remains unchanged; no migration applies.

## Rollback and observation

If an assertion, binding, export hash or replay fails, stop the dependent claim and retain the failed evidence. The operator may discard the disposable test project after preserving evidence; do not alter the real repository. Inspect the retained artifacts once at handoff. No ongoing production obligation is introduced.
