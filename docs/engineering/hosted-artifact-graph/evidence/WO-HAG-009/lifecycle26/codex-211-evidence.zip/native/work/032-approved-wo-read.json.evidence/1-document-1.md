+++
id = "WO-P3-901"
type = "work_order"
title = "Prove the existing greeting and retain the test lifecycle"
status = "approved"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[assurance]
commit_bound_verification = "required"
rationale = "Test verification and release decisions depend on the new definitions, exact evidence and disposable candidate binding."
decided_by = "test-owner"

[execution_scope]
paths = ["src/greeting.py","docs/engineering/lifecycle-pilot/intent/INT-P3-901.md","docs/engineering/lifecycle-pilot/capabilities/CAP-P3-901.md","docs/engineering/lifecycle-pilot/requirements/REQ-P3-901.md","docs/engineering/lifecycle-pilot/specifications/SPEC-P3-901.md","docs/engineering/lifecycle-pilot/verification/VER-P3-901.md","docs/engineering/lifecycle-pilot/work-orders/WO-P3-901.md","docs/engineering/lifecycle-pilot/release/REL-P3-901.md","docs/engineering/lifecycle-pilot/risks/RISK-P3-901.md","docs/engineering/lifecycle-pilot/decisions/DEC-P3-901.md","docs/engineering/lifecycle-pilot/verification-records/VREC-P3-901.md","docs/engineering/lifecycle-pilot/releases/RLS-P3-901.md","docs/engineering/lifecycle-pilot/evidence/WO-P3-901/"]

[relations]
implements = ["REQ-P3-901"]
specifications = ["SPEC-P3-901"]
verification = ["VER-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-10T12:32:01Z"
decided_by = "test-owner"
reason = "Synthetic bounded greeting work and required commit-bound assurance approved after passing gates, as supplied in task.md."
scope_paths = ["src/greeting.py", "docs/engineering/lifecycle-pilot/intent/INT-P3-901.md", "docs/engineering/lifecycle-pilot/capabilities/CAP-P3-901.md", "docs/engineering/lifecycle-pilot/requirements/REQ-P3-901.md", "docs/engineering/lifecycle-pilot/specifications/SPEC-P3-901.md", "docs/engineering/lifecycle-pilot/verification/VER-P3-901.md", "docs/engineering/lifecycle-pilot/work-orders/WO-P3-901.md", "docs/engineering/lifecycle-pilot/release/REL-P3-901.md", "docs/engineering/lifecycle-pilot/risks/RISK-P3-901.md", "docs/engineering/lifecycle-pilot/decisions/DEC-P3-901.md", "docs/engineering/lifecycle-pilot/verification-records/VREC-P3-901.md", "docs/engineering/lifecycle-pilot/releases/RLS-P3-901.md", "docs/engineering/lifecycle-pilot/evidence/WO-P3-901/"]
+++

# Prove and retain the greeting

## Objective

Give the operator exact local proof of REQ-P3-901 and a complete exported engineering record for the test.

## In scope

Author the new P3-901 definitions, work, paired risk/decision, verification and release records. Inspect the immutable source, execute VER-P3-901, retain evidence and exercise the selected test lifecycle and its required refusals. Export earlier and later snapshots separately.

## Out of scope

Imported P3-900 records, source edits, real repository work, installation, credentials, account settings, push, tags, publication and deployment.

## Authorized decision envelope

test-owner supplies definition acceptance, required assurance, bounded work approval after gates and mitigation linked to this work. test-executor may execute the approved scope, retain evidence and record completion. quality-owner prepares and assesses the VREC; release-owner prepares and assesses the test RLS. All identities are synthetic. Refused or uncertain actions cannot supply authority.

## Constraints

Use the approved transport helper and installed candidate client. Released evaluator 0.22.1 governs. Keep all local output under work. Preserve exact request bytes and receipt keys. No source test runs on the service.

## Expected change surface

The inspected source `src/greeting.py` already returns the required literal; retain its identity without edits. The inspected P3-900 history provides context and remains immutable. The new P3-901 paths in execution_scope retain this run's definitions and lifecycle. The narrow evidence directory retains the exact assertion and generated work evidence. VREC and RLS paths are planned generated destinations; inspect the actual returned paths before proceeding. No consumer, packaging, CI or architecture change is needed for this existing constant fixture. The assertion helper is the supplied execution interface.

## Required verification

Execute VER-P3-901 locally and inspect the result. Require exact output and source identity. The service must pass its applicable start, completion, verification and release gates on the actual selected revisions.

## Evidence to record

Retain `docs/engineering/lifecycle-pilot/evidence/WO-P3-901/assertion.json`, exact requests/results, source identity, candidate bindings, refusal effects and immutable exports. Local transport records stay under the task's work directory.

## Stop and escalate conditions

Stop the affected action on permission denial, mismatched selection, changed source, failed assertion, stale preview, unknown effect or refused gate. Recover uncertain replies through the original key. Correct a deliberate test refusal only through a new valid request after inspecting its effects.

## Completion report format

Report observed behavior, checks, refused actions, uncertainties, exact evidence/export paths, source and test candidate identities, and the next accountable decision. Do not claim real verification or release authority.

