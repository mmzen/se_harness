+++
id = "CAP-P3-901"
type = "capability"
title = "Inspect the fixture greeting with retained proof"
status = "approved"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
ability = "The test operator can inspect the fixed greeting and its retained assertion in the disposable project."

[relations]
derives_from = ["INT-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-10T12:30:17Z"
decided_by = "test-owner"
reason = "Synthetic test-owner accepts the complete greeting test definition under task.md."
+++

# Inspect the greeting

The operator needs readable local source and exact assertion evidence, connected to the exported test record. This ability applies to the selected immutable fixture only. Requirements define the expected greeting; the verification contract defines the assertion. No external service execution is needed.
