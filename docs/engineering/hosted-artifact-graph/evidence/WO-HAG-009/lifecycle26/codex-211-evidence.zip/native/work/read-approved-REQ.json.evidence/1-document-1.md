+++
id = "REQ-P3-901"
type = "requirement"
title = "Return exactly Hello rehearsal"
status = "approved"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
statement = "Calling greeting() in the selected local fixture returns exactly Hello rehearsal."
verification_method = ["test", "inspection"]
priority = "must"
source = "Native hosted-workflow qualification task supplied by test-owner"

[relations]
derives_from = ["CAP-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-10T12:30:17Z"
decided_by = "test-owner"
reason = "Synthetic test-owner accepts the complete greeting test definition under task.md."
+++

# Exact greeting

The fixed output gives the operator a concrete result to inspect in the exported test record.

## Acceptance

When the operator calls `greeting()` with no arguments, the result equals the string `Hello rehearsal`, including case and its single space. A mismatch or exception fails the test and prevents a verification claim. No alternative greeting or source change is permitted in this task.
