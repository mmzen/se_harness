+++
id = "RISK-P3-901"
type = "risk"
title = "Greeting evidence may be mistaken for a source test on the service"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
description = "An operator could treat a passed hosted lifecycle gate as proof of greeting behavior even though the service never executes source tests."
action = "Under WO-P3-901 retain the exact local assertion, inspect source identity and bind the evidence to the disposable candidate before accepting verification."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-901"]
mitigated_by = ["WO-P3-901"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-10T12:34:19Z"
reason = "Synthetic test-owner chooses mitigation using WO-P3-901 to retain local assertion proof and candidate-bound verification; risk acceptance is not supplied."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-10T12:33:39Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-10T12:34:19Z"
decided_by = "test-owner"
reason = "Synthetic test-owner chooses mitigation using WO-P3-901 to retain local assertion proof and candidate-bound verification; risk acceptance is not supplied."
+++

# Risk: Greeting evidence may be mistaken for a source test on the service

## Description

An operator could treat a passed hosted lifecycle gate as proof of greeting behavior even though the service never executes source tests.

## Next action

Under WO-P3-901 retain the exact local assertion, inspect source identity and bind the evidence to the disposable candidate before accepting verification.
