# `harnessctl` command reference

<!-- Target expertise: 7/10. The score describes the knowledge expected from the reader, not the quality or complexity of the document. -->

> This is a non-authoritative reference to command syntax, actors and side
> effects. The selected released evaluator computes lifecycle states, allowed
> transitions, gates and next actions. Start with
> [ENGINEERING_HARNESS.md](harness-installation-and-upgrades.md#read-selected-instructions) (resource `ENGINEERING_HARNESS.md`, heading `read-by-task`), then use
> [CONTINUE.md](harness-installation-and-upgrades.md#read-selected-instructions) (resource `docs/engineering/harness/CONTINUE.md`, heading `continue-selected-work`),
> [decision rights](harness-installation-and-upgrades.md#read-selected-instructions) (resource `docs/engineering/harness/AUTHORITY.md`, heading `decision-rights`) and
> [results](harness-installation-and-upgrades.md#read-selected-instructions) (resource `docs/engineering/harness/RESULTS.md`, heading `report-a-lifecycle-result`) when directed.

## Invocation

In evaluator examples, `harnessctl` means the absolute Python executable of
the repository's selected released evaluator followed by `-I -m se_harness`.
Run it from outside the checkout. `REPO` is the absolute repository path;
replace placeholders before running a command. Source-development commands
are identified separately and do not govern repository lifecycle state.

For example, with `CHECKER` replaced by that absolute executable:

```text
"CHECKER" -I -m se_harness check "REPO" --artifact WO-ID --json
```

In PowerShell, prefix a quoted executable with `&`. Run
`harnessctl COMMAND --help` for the exact parser help in the selected environment.
The syntax inventory below shows parser defaults and optional inputs; always
supply an absolute `TARGET` for repository operations from the external directory.

## Command shape

These rules describe the local evaluator commands (`WO-ECP-022`).
The unpublished hosted `remote` client has the separate contract below:

- **The repository is the positional `TARGET`**, default `.`, on every
  command that reads or writes one. `select-work-order` reads an event file,
  `identity` reads a runtime environment and `qualify candidate-package`
  reads a wheel, so they take none. `skill-ownership` requires an explicit
  positional `TARGET` under SPEC-PLG-020; it has no implicit repository selection.
- **Naming.** `--artifact` selects an existing artifact; `--id` names the
  record a command creates; an option that names a relation of that record
  keeps the relation's name (`--work-order`, `--verification`,
  `--verification-record`, `--release-contract`). Both record commands name
  their preparation actor `--owner`. `preflight` keeps `--work-order`
  until it folds into `check`.
- **`--json` everywhere.** The workflow commands print the schema-2 result;
  `validate`, `validate-draft`, `inspect`, `resources`, `release-unit`, `identity`
  and `qualify` print their own objects; every other command prints one
  `se-harness-command-result-v1` object with the same facts as its human
  output.
- **Plan and write.** A command that changes existing governed state
  (`transition`, `decide`, `upgrade`, `skill-ownership`) plans by
  default and writes only with `--apply`. A command that adds content
  (`init`, `scaffold-domain`, `create-artifact`) writes by default and
  plans with `--dry-run`; `init` into a target with content appends the
  bounded fragments to existing files and refuses every other difference.
- **Exit codes.** `0`: completed. `1`: the command ran and its result is
  failed, blocked or not passing. `2`: the command could not run (a usage
  error, a refusal before any result). A failed result goes to standard
  output in both renderings; a code appears once per line.

## Command inventory

| Command | Principal actor | State effect | Intended use |
| --- | --- | --- | --- |
| `remote` | authorized sandbox operator or author; reader for reads | explicit remote reads or bounded sandbox draft writes; no local fallback | use the separately installed unpublished client; see [Hosted sandbox client](#hosted-sandbox-client-unpublished) |
| `init` | repository owner or authorized agent | writes the complete standard harness into an absent or empty target; into a target with content it preserves existing files, integrates the bounded fragments and writes `docs/engineering/ADOPTION_REPORT.md` | install the harness into any repository, new or existing |
| `validate` | human or agent | read-only | validate formal metadata, typed relations, lifecycle, coverage, evidence paths, and provenance |
| `validate-draft` | human or agent | read-only | inspect one supported draft, separating invalidity, unfinished authoring slots and background findings |
| `inspect` | human or agent | read-only | summarize existing validation, lifecycle queues, Explorer findings, and bounded next-step guidance without acting as a gate |
| `dashboard` | human or agent | writes derived output only | generate the read-only Harness Explorer; under `--json` an engine refusal exits 2 and a failed generation carries the engine's standard error in `error` |
| `resources` | human or agent | read-only | resolve instructions and templates from the selected external resource package; available since 0.21.0 and in the selected released 0.22.1 evaluator |
| `doctor` | human or agent | read-only | inspect installation integrity, required supplied files and evaluator identity |
| `preflight` | coding agent or reviewer | read-only | check one work order for start or review readiness and return its reading manifest |
| `evidence` | coding agent at a checkpoint | writes or rebinds one evidence packet header | write the work order's evidence packet with a machine header bound to the current formal snapshot, keeping the owner-authored body byte for byte |
| `pr-body` | coding agent opening a pull request | read-only | emit the LF-terminated pull-request body: the work-order line, the restitution line when a Git-derived handoff result is retained, and the evidence list; an unknown artifact is a failed result on standard output, exit 1, as for `check` and `evidence` |
| `check-pr` | managed GitHub CI | scope check; may rebind an in-progress handoff | check one or several approved work orders and their combined diff |
| `check` | human or agent selecting work or assessing a checkpoint | read-only, except the self-binding Git-derived handoff checkpoint, which rebinds the packet header and retains its completed result | without a checkpoint, return the selected artifact's complete execution context: state, governing chain, declared scope, reading manifest, next command and required decision, in one schema-2 result, selecting the single in_progress work order when none is named; with a checkpoint, evaluate one fixed checkpoint and emit canonical restitution |
| `transition` | authorized actor; a person or agent uses the same recorded WO approval for start and completion after local checks pass (see [one execution route](delegation-class.md)) | plan is read-only; `--apply` atomically mutates only explicitly selected artifacts | validate and record accountable lifecycle decisions without implicit related-record changes |
| `decide` | the human who holds `DR-DECISION-DISPOSE`, directly or under an explicitly named eligible owner label | plan is read-only; `--apply` writes the decision's `[disposition]` table and one lifecycle event, and moves every raised risk the decision concerns in the same act | answer, defer, or withdraw one open decision artifact so the artifacts it blocks can move again |
| `raise-risk` | anyone working: a reviewer, an implementer, or an agent mid-execution; no decision right is needed | writes one risk artifact in `raised`, and with `--with-decision` the open decision that blocks the threatened artifacts; dry-run is read-only | record one measured threat to governed work so that an owner answers it before the threatened stage moves |
| `risks` | human or agent | read-only | list the risks threatening one artifact and its governing chain, with score, state and pending decision |
| `select-work-order` | managed GitHub CI | read-only | select exactly one standalone work-order declaration from a bounded pull-request event through released package logic |
| `upgrade` | repository owner or explicitly authorized agent | plan is read-only; `--apply` mutates managed content transactionally | update an initialized/adopted repository after separately updating the package |
| `skill-ownership` | repository owner or authorized agent | preview is read-only; apply replaces disposable copies and saves the provider last | select plugin skills or restore repository skills; rerun after an interruption |
| `scaffold-domain` | coding agent | writes owner-controlled directories and a seed index; dry-run is read-only | create the canonical organization for one engineering domain |
| `create-artifact` | coding agent | writes one incomplete `draft`; dry-run is read-only | create a formal artifact from its canonical template and path mapping |
| `release-unit` | release owner or coding agent drafting a release contract | read-only | measure a release unit's work-order census from the commit trailers between the previous release tag and a candidate commit, and compare it with a contract (`E-CIP-001`) |
| `identity` | CI or advanced contributor | read-only identity report/check | prove released-evaluator, candidate-source, or candidate-package runtime origin and boundary |
| `qualify` | release CI, maintainer, or released evaluator | read-only except for one exclusive evidence output outside the inspected repository | run one of four fixed evaluator/target qualification roles and emit provenance-bound, non-authoritative evidence |
| `capture-verification` | coding agent after an authorized clean candidate | writes one `ready` VREC plus canonical evaluator evidence | bind selected work, verification contracts, evidence, evaluator identity, snapshot, and exact clean `HEAD` |
| `refresh-verification` | coding agent after an unchanged rebase | writes a new `ready` VREC | compare relevant Git entries and reuse evidence while preserving the original |
| `prepare-release` | coding agent after verification and release-preparation authority | writes one `ready` RLS plus canonical evaluator evidence | bind release policy, eligible VRECs, exact work coverage, released evaluator wheel identity, version, and the same candidate commit |

## Hosted sandbox client (unpublished)

`harnessctl remote` is available in candidate client 0.22.2, installed into a
separate test environment. The selected released evaluator 0.22.1 does not
provide this command. Keep the released evaluator selected for repository and server checks.

In these examples, `CLIENT_PYTHON` is the absolute Python path in the separate
candidate environment. Run from outside the checkout. `HAG_TEST_TOKEN` is the
name of a private environment variable; do not put its value in the command.

```text
"CLIENT_PYTHON" -I -m se_harness remote status --endpoint http://127.0.0.1:18080 --token-env HAG_TEST_TOKEN --json
"CLIENT_PYTHON" -I -m se_harness remote read --endpoint http://127.0.0.1:18080 --token-env HAG_TEST_TOKEN --project PROJECT_ID --baseline BASELINE_ID --request READ_REQUEST_JSON --json
```

The positional argument is an operation, not a repository path. Every operation
requires an explicit endpoint and credential-variable name. Operations other
than `status` also require `--project`. `baseline` selects `--baseline`;
`operation` selects the original operation `--key`. `read`, `check`, and `query`
use a versioned `--request` and an explicit baseline or context view.

The write operations are `import`, `draft-open`, `create-artifact`,
`revise-artifact`, and `freeze`. Each requires the complete versioned request
and `--client-wheel` identifying the actual separately installed candidate.
There is no automatic retry, rebase, local fallback, or implicit apply step.
After an uncertain write, inspect its original operation key before retrying.

This client prints the remote protocol result, not the local evaluator result
schema. Transport errors go to standard error; an unknown write outcome is not
a refusal or proof that nothing changed. See the [hosted sandbox guide](hosted-artifact-graph.md)
for the request contracts and qualification limits. These commands do not
approve work, accept verification, or release artifacts.

## Repository setup and inspection

```text
harnessctl init [TARGET] [--project-name NAME] [--integration git|ci|pr] [--dry-run] [--json]
harnessctl validate [TARGET] [--json] [--advisories]
harnessctl inspect [TARGET] [--json] [--vocabulary-threshold N]
harnessctl dashboard [TARGET] [--output PATH] [--json]
harnessctl doctor [TARGET] [--json]
```

`TARGET` defaults to the current directory. The successor candidate defaults to
the two selection files, with no copied instructions, templates or adoption report.
Repeat `--integration` for explicit Git evidence attributes, CI/output ignores,
or a PR template. Installation resolves every destination before writing and
refuses conflicts and linked or escaping paths. Published 0.20.0 retains its
repository-copy behavior; these candidate options do not adopt a release.

Validation reports deterministic errors and warnings but does not edit artifacts. Each finding names its assessment plane: `structure`, `governance`, configured `policy`, or non-blocking `maintenance`. Planes explain the finding source; they do not change severity, pass/fail behavior, or create a score.

The summary line carries a fourth number, `Advisories`. An advisory is a hint for the author of a draft requirement or intent (the `W-AUT-*` codes: statement shape, one obligation, length and budgets, the old free-text `verification_method`, the intent's outcome and success measures). It is not a warning: it is raised only while the artifact is `draft`, it is left out of the warning count and the plane counts, and it is listed only with `--advisories`. The JSON report always carries `advisories` and `advisory_count`. On a repository whose definitions are all approved, `Advisories: 0` is the normal reading. Since 0.18.0 the approval transition of a draft intent, capability, requirement or specification is refused while any advisory remains on it (`QGP-G1-AUTHORING`, `QGP-G2-AUTHORING`, `SPEC-TCM-007`); the refusal names each advisory and ends with `fix the draft and run the transition again`. `validate` itself keeps passing.

Inspection reuses the existing validator and Harness Explorer snapshot. It
reports `mode = repository_wide`, no selected artifact, formal validity, ready
decisions, draft definitions, active work, assurance preparation, and existing
repository findings. Human output groups repeated rule instances for
readability; `--json` retains every finding. Inspection output MUST NOT be used
as selected-iteration restitution.

The `assurance_pending` queue contains only an `implemented` work order whose explicit `[assurance]` classification is `required` and which has no direct `ready`, `verified`, or `released` VREC coverage. It suggests non-automatic preparation after one clean candidate commit; it does not select aggregate scope, create a record, or make the assurance decision. Completed legacy work without a classification and work explicitly classified `not_required` are not inferred into this queue.

The temporal reassessment observation `W-HEX-003` is deliberately narrow: it compares dates only for supported declared dependency relations whose source can still be meaningfully reassessed. It does not reopen completed work orders, reinterpret commit-bound verification or release records, or treat derived graph projections as declared dependencies.

For existing lifecycle queues and a closed set of actionable derived warning rules, inspection also reports deterministic suggested next steps. Each suggestion identifies its source, affected artifacts, action class, accountable role, and `automatic = false`. Suggestions contain no executable command and never assert eligibility or authority. Validator findings, informational observations, and unknown rules remain visible without guessed advice.

Inspection ends with a vocabulary section. It counts the words of every artifact's statement and body with code removed, drops common English and the harness terms the managed instructions define, and names the project terms at or above `--vocabulary-threshold` occurrences (default 50, between 30 and 100) that have no entry in `GLOSSARY.md` at the repository root, and the entries whose term appears in no artifact. The glossary is repository content. Published repository-copy installations seed it empty; minimal external-resource installation creates no glossary. Both routes preserve an existing glossary. The section is informational and never blocks.

A successfully produced inspection exits zero even when formal validation failed or attention exists, so use `validate` when gate exit behavior is required. Inspection is repository-local derived evidence: it does not approve, authorize, verify, supersede, release, remediate, or independently govern the repository.

Dashboard defaults to `target/harness-dashboard/`; its generated files are derived evidence, not formal authority. The small `index.html` bootstrap verifies `dashboard-manifest.json`, then loads a summary, compact topology, readiness data, individual artifact details, and explicitly expanded evidence from digest-named static resources. Serve the directory from one HTTP origin, for example with `python -m http.server 8000 --directory target/harness-dashboard`; direct `file://` opening is intentionally rejected because progressive resource loading and integrity checks require an origin. Generation remains local and needs no application server, but publishing or sharing the directory exposes every manifest-declared artifact and evidence body; the command does not scan for secrets or redact repository material. Doctor checks the standard installed contract against `.engineering-harness.lock` and the current distribution.

## Standalone draft validation

```text
harnessctl validate-draft [TARGET] --artifact ARTIFACT-ID [--json]
```

The caller supplies a complete projection. The command uses one parsed catalog
and the executing evaluator's canonical templates. It writes nothing. JSON is
`se-harness-draft-validation-v1`, with `selection` (id, type, status, relative
path), `admissible`, `errors`, `incomplete`, and `background`. Findings include
stable codes and structured field/relation/target details where relevant.
Text reports the same facts. Exit 0 means admissible; 1 means a produced refusal;
2 means usage or a failure before a result can be produced.

Supported draft types: intent, capability, requirement, specification,
architecture, adr, verification, work_order, release_contract and
operating_contract. Decision, risk, verification_record and release_record
continue through their existing commands.

A requirement with `CAP-xxx`, an omitted `derives_from`, or an empty array can
be admissible with an incomplete finding. A link to an existing release record,
an unknown non-template target, or `["CAP-xxx", "RLS-SEH-001"]` is refused.
Malformed TOML and duplicate IDs block a trustworthy catalog globally. Other
unselected findings remain background. A correct endpoint does not establish
readiness of its full governing chain.

Selection outside draft, lifecycle history and disposition are refused. This
snapshot query cannot prove that imported identity or provenance is unchanged.
The hosted caller must compare protected fields to its immutable base and enforce
rights and expected versions. Admission does not waive validation, approval,
verification or release gates, and includes no lifecycle next step.

<a id="released-resource-lookup-successor-candidate"></a>

## Released resource lookup

Released evaluators since 0.21.0 provide this command for repositories selecting
the `released-resources-v1` layout. This repository uses independently installed
0.22.1 after explicit adoption under WO-HUP-030. Publication alone does not
change a repository's selection.

```text
harnessctl resources [TARGET] [--resource RESOURCE-ID] [--content] [--json]
```

Without `--resource`, list resource IDs, local paths, byte digests and headings
from the exact selected release. Use a returned ID with `--resource` to select
one item. `--content` requires that one ID; it does not return every guide at
once. For `ENGINEERING_HARNESS.md`, it renders the project and selected version
in memory. No instruction copy or lifecycle state is written to the repository.

JSON output uses `se-harness-resources-v1`, with the selected `release` identity
and `resources` array. Content requests also return `content` and
`content_sha256`. Missing, altered or mismatched selected resources cause a
refusal; the command does not install resources or borrow another release.

## Work readiness

```text
harnessctl preflight [TARGET] --work-order WO-... [--phase start|review] [--json]
harnessctl select-work-order --event GITHUB_EVENT_PATH [--json]
```

`start` is the default phase. Preflight checks lifecycle eligibility, the governing chain, and the selected work order's explicit `[assurance]` declaration, then displays the classification, rationale, and deciding role with the reading manifest. A selected work order without a valid declaration fails even when completed legacy validation remains compatible. Passing proves structural readiness only; it does not prove comprehension, semantic scope fit, implementation correctness, the truth of the rationale or role claim, assurance, or release.

`select-work-order` reads one bounded event file. A body uses either
`Harness-Work-Order: WO-AAA-001` or
`Harness-Work-Orders: WO-AAA-001, WO-BBB-002`. Use `--field work-orders`
for one ID per output line. LF and CRLF are equivalent. Both declarations
together, duplicate IDs and malformed IDs are rejected.

```sh
harnessctl check-pr [TARGET] --event EVENT.json --from-git BASE [--json]
```

`check-pr` evaluates every selected approved work order and the complete diff
against their combined scope. Unrelated changes are not admitted by listing
another work order; that work order must actually cover the path. In-progress
work also needs passing local handoff checks. CI calls this command directly.


## Selected-scope workflow execution

The command shapes below are stable interfaces. The candidate standard
[`CONTINUE.md`](../../templates/repository/standard/docs/engineering/harness/CONTINUE.md#continue-selected-work)
routes to the selected procedure, and
[`WORKFLOW.json`](../../templates/repository/standard/docs/engineering/WORKFLOW.json)
is the machine-readable contract loaded by `harnessctl`. Use the workflow rule
selected for the artifact's exact type, state, and direct related records. Do
not derive a new transition or next action from this reference.

```text
harnessctl evidence [TARGET] --artifact WO-... --checkpoint start|pre-action|transition|handoff \
  [--rebound-at RFC3339] [--json]
harnessctl pr-body [TARGET] --artifact WO-... [--json]
harnessctl check [TARGET] [--artifact WO-...|VREC-...|RLS-...] [--json] [--include-background]  # without a checkpoint: the projection
harnessctl check [TARGET] --artifact WO-... --planned-path PATH [--planned-path PATH ...] [--json]
harnessctl check [TARGET] --artifact WO-...|VREC-...|RLS-... \
  --checkpoint start|pre-action|transition|handoff|scope [--target STATE] \  # with a checkpoint:
  [--procedure PROC-...] [--from-git BASE | --changed-path PATH ... \
  [--changes-complete] | --change-manifest PATH] [--pull-request-body PATH] [--json]
harnessctl transition [TARGET] --set ID=STATUS --decision ID=ACTOR \
  [--set ID=STATUS ...] [--decision ID=ACTOR ...] [--reason ID=TEXT ...] \
  [--apply] [--json]
```

`check` without `--checkpoint` is the one call an agent makes first (`WO-ECP-001`,
folded from `next` by `WO-ECP-019`). It returns the projection of the selected artifact — the single
`in_progress` work order when `--artifact` is absent, otherwise `WEX-ECP-001` names the candidate
count — with an additive `context` object: `reading_manifest` (the preflight manifest for the
phase the state implies, `start` for `approved` and `in_progress`, `review` afterwards),
`governing`, `declared_paths`, `state`, `next` (`argv`, `procedure_id`, `step_id`, the same step a
checkpoint `check` selects) and `decision_required`. It writes nothing and needs no prior command.
The human block renders the context as a `Context` section after `Command or response`, and
`result_sha256` binds it. The former `next` command was removed after 0.11.0 (`WO-ECP-020`); its
tombstone guard left with 0.15.0 (`WO-ECP-025`), so the parser now refuses the name as unknown.

`check` without `--checkpoint` projects only the selected artifact's governing chain and direct
lifecycle dependencies. It uses the ordered recommendation registry in
`WORKFLOW.json`. For example, `WFL-WO-READY-VREC` takes precedence over
`WFL-WO-PREPARE-VREC`, so existing ready assurance coverage cannot produce a
duplicate-capture recommendation. Unrelated repository findings remain a
background count; `--include-background` expands categories without making
them selected-scope work.

The optional `--planned-path` view assesses proposed files before approval.
It requires an explicit work order and no checkpoint. Repeat the option for
each repository-relative file in the plan; the file need not exist yet.
Existing calls without this option are unchanged.

The schema-2 result adds `scope.preparation`: `planned_paths`, `coverage`
(`covered`, `uncovered` or `invalid`), `explicit_matches` with the matching
`scope_entry`, `automatic_matches` with the existing admission rule,
`uncovered_paths`, `invalid_declarations` and
`impact_analysis: "not_assessed"`. These machine fields participate in the
result digest. The human report lists coverage and each path's reason.

The normal lifecycle projection, next action, exit meaning and gate fields
are preserved. **Exit zero does not mean the plan is covered.** Inspect
`scope.preparation.coverage` and resolve uncovered or invalid paths before
requesting approval. Coverage cannot prove that the agent found every
affected file. Planning writes nothing and does not populate actual changed
paths, assert completeness, evaluate gates or authorize work.

The selected WO file and existing directly linked VREC/RLS records and their
declared evaluator evidence use their existing exact-path admission rules.
The selected WO's own packet directory is reported separately under its
existing admission rule.
An unallocated future record has no assessable path; explain its expected
relationship rule and check the actual destination after preparation.
Other review/log evidence needs explicit scope unless an existing rule covers
it. A neighboring file is not admitted by a generated record's directory.

Do not combine planned paths with `--checkpoint`, `--target`, `--procedure`,
`--changed-path`, `--changes-complete`, `--change-manifest`, `--from-git`
or `--pull-request-body`. Invalid selection, malformed paths, case duplicates,
directory inputs and repository escapes are refused through normal diagnostics.
This option must be used with a released evaluator that provides it; candidate
source tests do not change the repository's selected evaluator.

With a checkpoint, `check` resolves the first matching rule, its typed `PROC-*` procedure, and its
`QG-*` gates; `--checkpoint scope` evaluates only the scope predicates of
`QG-G4-IMPLEMENTATION-EVIDENCE` for a work order in any lifecycle state and
writes nothing, which is what the managed pull-request gate runs (`WO-ECP-013`); [`harnessctl check` explained](harnessctl-check.md) walks
through the checkpoints, the rule table, the gates, and the refusal codes. `--checkpoint transition --target STATE` previews, read-only, the
exact predicates and graph-structural checks `transition --set ID=STATE` will
evaluate (`WO-ECP-009`): the transition binding index of `QUALITY_GATES.json`
keyed by artifact family and target state, evaluated by the same gate evaluator
with the same context, plus the `QGS-*` checks under the synthetic
`QG-STRUCTURAL` gate. A transition whose evaluation is not all `pass` renders
`Blocked by` with each refusing predicate's own identifier and writes nothing;
an applied transition that would be blocked fails closed with that identifier. `pre-action` requires `--procedure`, which must equal the selected
procedure or one complete declared alternative. `--changed-path` may repeat;
`--changes-complete` asserts that the supplied set is complete, including an
empty set. The assertion is evidence, not proof from a trusted Git baseline.
Without it, path-scope predicates are `not_assessable`.

`--from-git BASE` derives the change set from Git instead of from typed
paths: the union of `git diff --name-only BASE` against the working tree
(renames contribute both names) and the untracked files Git does not ignore,
each normalized as above; the set is complete by construction and the result
records `change_set_source = "git"`. It is mutually exclusive with the
changed-path options and the manifest (`WEX-ECP-002`); outside a Git
checkout, with a base Git cannot resolve, or on any Git failure it blocks
with `WEX-ECP-003` and evaluates no predicate as `pass`. The selected work
order's own artifact file, written by its lifecycle transitions and so always
in the diff, is admitted to its scope by construction (`ECP-CHG-007`).

`evidence` writes `DOMAIN/evidence/WO-ID/WO-ID-CHECKPOINT.md` (`WO-ECP-002`):
a fenced TOML header at byte offset 0 with exactly `artifact`, `checkpoint`,
`formal_snapshot_sha256` and `rebound_at`, followed by an owner-authored
body. On an existing packet only the header bytes change; the body is
retained byte for byte, and a file without a header at offset 0, with a
header naming another artifact or checkpoint, or with invalid TOML is refused
(`WEX-ECP-010`). It refuses when a `.gitattributes` rule would convert the
packet's line endings (`WEX-ECP-011`) and when the single `in_progress` work
order is not the one named (`WEX-ECP-012`). `QGP-G4I-EVIDENCE` reads that
header through a TOML parser; a packet without one is not assessable, and
the message names the `evidence` command that writes the header (the
one-release substring grace closed under `WO-AUT-006`). `check --checkpoint handoff
--from-git BASE` is self-binding (`ECP-SBH-001` to `-006`): it rebinds an
existing packet header to the current formal snapshot before evaluating —
body preserved, `evidence`'s `WEX-ECP-010`/`WEX-ECP-011` guards unchanged,
no packet created — and evaluates the change set with the retained result
path included, so one run is the declared, digest-stable result. A
completed run retains its schema-2 result as `handoff.json` in the same
directory, written by the harness; that directory is admitted to the work
order's scope by construction.

`pr-body` emits the pull-request body for an approved or later work order
(`WEX-ECP-014` otherwise): the standalone `Harness-Work-Order` line first, one
standalone `Harness-Restitution` line carrying the retained `handoff.json`'s
`result_sha256` when it exists, then the seeded `## Summary` and
`## Verification` headings with every evidence path under the packet
directory. LF line endings only; the body round-trips through
`select-work-order` unchanged, so paste its output rather than typing it.

`--change-manifest` is mutually exclusive with both changed-path options. It
must be an in-repository UTF-8 JSON object containing only `schema` with value
`se-harness-change-set-v1`, Boolean `complete`, and ordered array `paths`.
Paths use `/`, exact-file or component-boundary directory-prefix matching, and
reject absolute, traversal, backslash, wildcard, drive, URI, control-character,
reserved-device, duplicate, and case-ambiguous forms.

`check` always emits `se-harness-workflow-result-v2`. That structured result is
authoritative. The deterministic direct human renderer uses `Outcome`, `Done`,
`Not done`, conditional `Blocked by`, `Current lifecycle state`, `Decision
required`, `Next`, `Command or response`, and conditional `Alternatives` in
that order. Exact-format consumers must use this renderer directly rather than
ask a model to transcribe it. `check`, `transition`, `capture-verification`,
and `prepare-release` emit the same `se-harness-workflow-result-v2` result
through one selector (`WO-ECP-005`); the former `--result-schema` option is
gone and passing it is an argument error. Each rule in `WORKFLOW.json` carries
only the `done` and `current_lifecycle_state` prose of its restitution; the
next step and the command come from the bound procedure.

When `check` is blocked, `Next` and `Command or response` carry the corrective
form the contract declares for the first failing predicate: a command that
differs from the evaluated one (for example the handoff check with
`--changed-path` and `--changes-complete`), an escalation naming a decision
right, or a response describing the evidence to retain. The evaluated command
is never rendered as its own retry. Every schema-2 result carries
`result_sha256`. New results declare `digest_format = "machine-fields-v1"`
and hash stable machine fields rather than human wording. Retained results
without the marker keep their original human-block digest; a pull-request body may declare it on one standalone
`Harness-Restitution:` line for CI to recompute. At `handoff`, a work order
whose `ready` verification record binds a commit no longer reachable from
`HEAD` is blocked with `W-ADS-002`; `--pull-request-body` additionally reports
`W-ADS-001` when the work-order trailer ends with a carriage return.

An agent-facing handoff may adapt wording, ordering, headings, and relevant
explanation or omit empty fields. It remains conforming only when it preserves
actual artifact IDs, outcome, observed effects, incomplete work, material
non-effects, blockers, final lifecycle state, the accountable decision,
command argument boundaries or suggested-response meaning, and exactly one
recommended next action. Workflow-declared alternatives remain separate from
that recommendation. Agent prose never becomes lifecycle authority.

`transition` resolves IDs from formal metadata and plans by default. Each
selected ID needs one actor assertion. Rejection needs a non-empty reason; VREC
supersession uses the reason as the exact successor VREC ID. A packet is
assessed as one proposed final graph. `--apply` rechecks every input byte,
proves the locked released-evaluator authority before writing, stages
same-filesystem replacements outside artifact discovery, and rolls back earlier
replacements if a later write fails.

The command records actor text as an assertion, not proof of authority. The
effects and non-effects for each state are defined only by the matching
`WORKFLOW.json` rule. Related artifacts require separate explicit selection,
passing gates, and authority.

Direct human and JSON output are rendered from the same semantic workflow
result. Schema 2 always identifies exactly one typed next step and derives its
command argument array or response from the selected procedure. Adaptive agent
presentation consumes that result; it does not replace or recompute it.

## Decision disposition

```text
harnessctl decide [TARGET] --artifact DEC-... --option OPTION-ID --decision ACTOR [--authority-owner OWNER] --reason TEXT [--revisit TEXT] [--apply] [--json]
harnessctl decide [TARGET] --artifact DEC-... --defer --scope ARTIFACT-ID:FROM-TO ... --revisit TEXT --decision ACTOR [--authority-owner OWNER] --reason TEXT [--apply]
harnessctl decide [TARGET] --artifact DEC-... --withdraw --decision ACTOR [--authority-owner OWNER] --reason TEXT [--apply]
```

A decision artifact (`DEC-`) records one pending question, or one implementation deviation from one rule of one specification. While it is `open`, every artifact named in its `blocks` relation is refused its transitions by the `QGP-*-DECISION` predicate of the gate that transition would pass. The refusal names the decision, its question, its options, the deciding role, and the `decide` command that clears it.

`decide` is the only way a decision changes state; `transition` refuses it. Without `--apply` the command plans and reports; with `--apply` it writes the `[disposition]` table (the option, its label, the actual human, the time, and the verbatim reason) and one lifecycle event. `--option` must name one of the options the artifact declares. A deferral needs one `--scope` entry per transition it admits and a `--revisit` trigger; the scoped transitions pass, every other blocked transition still waits. Accepting a deviation needs `--revisit`, because acceptance is time-bounded. An ineligible owner is refused with `DR-DECISION-DISPOSE`.

`--decision ACTOR` records the actual human who made the decision. With
`--authority-owner OWNER`, the evaluator checks OWNER against the existing
holders for the blocked artifacts, or the departed specification for a
deviation. OWNER must match exactly and contain non-blank printable text of
at most 128 characters. It is retained separately as `authority_owner` in
the disposition. Without the option, ACTOR must directly match a holder.
Both preview and apply use the same checks. The CLI does not authenticate
these claims or grant consent; the caller must first establish the human's
authority and obtain the exact decision. Existing owner labels and historical
records are not changed.

The validator reports a malformed decision as `E-DCM-001` to `E-DCM-003`, prose in a legacy definition's `## Open decisions` section as `E-DCM-004`, a deviation whose `against` fragment is not a rule identifier of the named specification (`SPEC-xxx#PREFIX-AREA-NNN`) as `E-DCM-005`, and an accepted deviation past its revisit or accepted twice against the same rule as `W-DCM-001` and `W-DCM-002`. See [decision artifacts](decision-artifacts.md) for the model.

When the decision concerns a raised risk, `--apply` also moves that risk to the state the option names, in the same act: `accept` needs `--revisit`, `mitigate` needs `--mitigated-by WO-...`, and `avoid` records `--avoided-by` (an ADR or a decision; it defaults to the disposing decision). A deferral leaves the risk `raised`; a withdrawal withdraws it.

## Risk recording

```text
harnessctl raise-risk [TARGET] --domain SLUG --title TEXT --stage STAGE --category CATEGORY --cause TEXT --effect TEXT --likelihood N --impact N --threatens ID [--threatens ID ...] --raised-by ACTOR [--owner ROLE ...] [--id RISK-...] [--with-decision [--decision-id DEC-...] [--recommend accept|avoid|mitigate]] [--dry-run] [--json]
harnessctl risks [TARGET] --artifact ID [--json]
```

A risk artifact (`RISK-`) records one measured threat: one cause, one effect, the stage it threatens, `likelihood` and `impact` from 1 to 5, and their product as `score`. `raise-risk` computes the score, writes the file in `raised` and records the raise as a lifecycle event, in one act; a measurement outside the range or an identifier already declared anywhere is refused before anything is written, exit 2. `--domain` takes the domain slug or the identifier token of exactly one domain. With `--with-decision` the command also writes the open decision that blocks the threatened artifacts, with the options `accept`, `avoid` and `mitigate`. No gate reads risks: the stop is the paired decision's `QGP-*-DECISION` predicate, and the refusal names the decision, not the risk.

`risks` lists every risk threatening the named artifact or, for a work order, its governing chain; it writes nothing.

The validator reports a missing or invalid field as `E-RSK-001`, a wrong measurement or score as `E-RSK-002`, a raised risk that no pending decision names as `E-RSK-003`, a paired decision whose `blocks` differs from the risk's `threatens` as `E-RSK-004`, a disposition typed by hand as `E-RSK-005`, and an accepted risk past its revisit as `W-RSK-001`. See [risk artifacts](risk-artifacts.md) for the model.

## Safe repository upgrade

```text
harnessctl upgrade [TARGET] [--json]
harnessctl upgrade [TARGET] --apply [--json]
harnessctl upgrade [TARGET] --apply --work-order WO-... --evidence-output docs/engineering/DOMAIN/evidence/WO-...-evaluator-upgrade.json [--json]
```

The first form is a read-only plan. `--apply` is an explicit transactional repository mutation. Same-identity managed repair needs no new lifecycle packet. When the installed target evaluator differs from the standard lock, apply additionally requires a distinct approved or in-progress work order with an exact `[evaluator_upgrade]` packet and a work-order-keyed JSON evidence path. The packet binds the prior lock SHA-256 and exact immutable target archive/payload identity with `scope = "standard-root-only"`; a product release decision cannot substitute for it.

Apply requires the already-published target evaluator installed from exact wheel bytes outside the checkout, changes only eligible managed content, and stops without a partial managed update when identity, authority, customization, or conflict prevents a safe plan. Transition evidence, managed files, and the lock share the recoverable transaction, and successful replay must be a no-op. Every repository, including the `se_harness` implementation repository, follows this transaction and uses one exact released evaluator. GitHub discovers the managed workflow beside existing repository-owned workflows, while required-check and workflow-ordering policy remains external. See [installation and safe upgrades](harness-installation-and-upgrades.md).

## Retained skill ownership

```text
harnessctl skill-ownership TARGET --provider plugin --plugin-root DIRECTORY [--apply] [--json]
harnessctl skill-ownership TARGET --provider repository [--apply] [--json]
```

This candidate command is unavailable in released 0.17.0. It removes the two
named harness skill directories under .agents/skills and .claude/skills,
including edits and extra files. Other skill directories remain unchanged.
The replacement must contain a Verity Plane manifest and the six required files.
Preview is optional. Apply reads current inputs, deletes the old copies, and
saves the portable provider choice last. Rerun the command after an interruption.
Restoration copies the current repository templates over disposable old copies.
This file-only operation grants no lifecycle authority and does not install a
plugin or change host settings. See [the current design](plugin-simplification-2026-09-13.md).

## Predecessor-to-successor migration rehearsal

The former `rehearse-recovery` command is retired (`WO-ECP-030`, issue #376; it had no workflow caller and no retained report), as the former `rehearse-migration` command was (`WO-ECP-010`, issue #210); the root-evaluator handover is rehearsed by `python -m repository_tools.upgrade_rehearsal`, a repository-owned tool described in [rehearsing the root-evaluator handover](evaluator-migration-rehearsal.md), not by a `harnessctl` subcommand.


## Domain and artifact authoring

```text
harnessctl scaffold-domain [TARGET] --domain DOMAIN [--title TITLE] [--dry-run] [--json]
harnessctl create-artifact [TARGET] --domain DOMAIN --type TYPE [--id ID] [--dry-run] [--quiet] [--json]
```

Domain slugs, artifact identifiers, type prefixes, templates, and destinations are validated before mutation. `create-artifact` creates only an incomplete `draft`; it does not choose owners, relations, content, approval, or authority. After creation it prints the created type's checklist from `docs/engineering/ARTIFACT_AUTHORING.md`, resolved in the selected wheel for the external layout or in the repository for a supported older layout; `--quiet` suppresses it. Existing valid flat layouts remain discoverable and are not automatically migrated.

Without `--id`, `create-artifact` allocates the lowest free
`TYPE-DOMAIN-NNN` across every local branch and tag and the working tree,
untracked files included (`WO-ECP-002`): the refs are enumerated with
`git for-each-ref` and each ref's `docs/engineering` tree is listed, so two
agents on two branches cannot take the same number; remote-tracking refs are
not consulted. The domain token is read from the domain's existing
artifacts. The result names the refs on which the next-lower identifier was
found, so a gap is explained. Outside a Git checkout allocation is refused
(`WEX-ECP-013`) rather than guessed from the working tree. An explicit `--id`
is refused when any local ref already carries it.

Non-dry-run authoring uses the common pre-write mutation guard. The invoking environment must match the schema-3 released-evaluator identity locked by the target repository; candidate source and editable or contaminated installs fail without creating the requested path.

## Release unit derivation

```text
harnessctl release-unit [TARGET] --from TAG --to COMMIT [--exempt SHA ...] [--contract REL-ID] [--json | --toml]
```

Measures the work-order trailers between the previous release tag and a
candidate commit, including merged work. The JSON shape remains compatible.
Untraced commits, incomplete census information, and contract differences are
advisory and exit successfully; invalid Git refs or command inputs still fail.
`--exempt` remains readable for old invocations but is unnecessary. The owner
approves final release scope, and the final candidate still needs verification.

## Runtime identity

```text
harnessctl identity --role released-evaluator|candidate-source|candidate-package \
  --expected-version VERSION --expected-root PATH [options] [--json]
```

Key role-specific options are `--checkout-root`, `--candidate-commit`, `--evaluator-wheel-sha256`, `--entry-point`, `--require-isolated-python`, and `--require-entry-point`. The command verifies declared runtime origin; it does not select an evaluator or approve a candidate.

Runtime identity also observes the running interpreter's own entry-point path through the declared interpreter-safety rule and records three additional facts: whether the entry point is a symbolic link, which position class its resolved target occupies relative to the expected and checkout roots, and the target's SHA-256. The schema identifier stays `se-harness-runtime-identity-v3`, because consumers require a subset of the identity rather than an exact field set. The observation is recorded for every role, but only the two environment-bounded roles — `released-evaluator` and `candidate-package` — turn a refusal into the `RID024` diagnostic; `candidate-source` has no environment boundary, because its expected root is the checkout itself. `RID004` and `RID006` keep their existing meanings unchanged.

## Role-specific release qualification

```text
harnessctl qualify released-root [ROOT] [--output PATH] [--json]
harnessctl qualify complete-candidate [ROOT] --candidate-commit FULL_COMMIT [--output PATH] [--json]
harnessctl qualify candidate-package --candidate-wheel PATH --candidate-commit FULL_COMMIT --candidate-wheel-sha256 SHA256 --verifier-wheel-sha256 SHA256 [--checkout-root PATH] [--output PATH] [--json]
harnessctl qualify public-install [ROOT] --release-record RLS-... --public-wheel PATH --public-wheel-sha256 SHA256 --payload-sha256 SHA256 [--output PATH] [--json]
```

The four subcommands are separate closed parsers. They bind evaluator identity, target identity, fixed checks, and one independence class before reporting a result. They do not accept a general evaluator, validator, script, omission, or diagnostic-allowlist option. `--output` must name a new external file; the command never overwrites it or writes qualification evidence inside the inspected repository.

`--evaluator-python` is judged by the declared interpreter-safety rule before anything is spawned. Supply the environment's own lexical entry point — `bin/python` on POSIX, `Scripts/python.exe` on Windows — not the resolved system interpreter it points at. The environment root is derived from that lexical path, so an interpreter reached through a linked or junctioned parent directory is refused, as is one inside the inspected checkout or whose resolved target lands inside it. The terminal interpreter link itself is permitted, which is what makes an ordinary `python -m venv` environment usable on POSIX.

All operations emit `se-harness-release-qualification-v1`. The result identifies the operation, completion, outcome, evaluator, target, ordered checks, independence boundary, and its evidence-only authority. `complete-candidate` is always `candidate-controlled`, even when it passes. See [release qualification roles](release-qualification-roles.md) for the workflow map. `WO-REB-028` retired a fifth operation, `predecessor-view`, with the predecessor-bootstrap release path; its `PV001` and `PV002` codes stay reserved and no code path emits them.

The pre-namespace `accept-candidate` entry point, kept as a one-cycle alias of `qualify
candidate-package` under `REQ-REB-022`, was removed after 0.11.0 (`WO-ECP-019`); its tombstone guard left with
0.15.0 (`WO-ECP-025`), so the parser now refuses the name as unknown. Exact public 0.6.0 predates the `qualify` namespace;
its immutable command still emits `se-harness-functional-acceptance-v1` and is accepted only as
explicitly labeled bootstrap evidence in the candidate workflow's legacy branch, which runs only a
verifier without `qualify`. That historical output is not converted into or described as canonical
qualification evidence.

## Commit-bound verification preparation

```text
harnessctl capture-verification [TARGET] \
  --id VREC-... \
  --work-order WO-... \
  --verification VER-... \
  --evidence PATH \
  [--owner ROLE] [--domain DOMAIN] [--output PATH] [--json]
```

Refusals distinguish invalid state (`WEX301`), Git provenance (`WEX302`),
evidence (`WEX303`), and record inputs (`WEX304`). Repeat work orders, contracts,
and evidence paths for a final aggregate candidate. Work may be implemented,
verified, or released; all declared verification contracts must be selected.
Evidence may be a shared integration report plus earlier verification records.
The command writes a ready VREC and evaluator evidence. It does not verify it.

After WO-KIS-009, each selected WO's recorded execution approval and unchanged
scope authorize preparation for either a person or an agent. There is no
actor-specific single-WO limit. Use the installed evaluator's procedure on a
repository still governed by an earlier release until normal upgrade.
Use `--candidate-commit COMMIT --test-command <argv...>` to test the exact final
integration in a temporary checkout, including when the caller has local edits.

For a harmless rebase, use
`harnessctl refresh-verification REPO --from VREC-OLD-001 --id VREC-NEW-001`.
This compares relevant Git tree entries, governing inputs, and retained evidence.
It preserves the old ready record and writes a new ready successor. Changed
relevant files require fresh tests; verified records cannot be refreshed.

An accountable assurance owner reviews the retained evidence and separately decides whether to transition the VREC to `verified`. The record lives in later governance history and continues to bind the earlier candidate commit C.

If a later verified or released VREC fully covers a prepared ready record, the assurance owner may instead apply the declared `ready -> superseded` transition and name that successor with `--reason`. The command preserves `prepared_at` and `prepared_by`, adds only the supersession decision fields, typed successor relation, lifecycle event, status, and update date, and does not add `verified_at` or `verified_by`. Supersession means the proposal was retired, not verified. Historical superseded VRECs without preparation fields may retain the older valid `verified_at` capture shape; validation does not rewrite them or fabricate `verified_by`.

## Commit-bound release preparation

```text
harnessctl prepare-release [TARGET] \
  --id RLS-... \
  --release-contract REL-... \
  --verification-record VREC-... \
  --work-order WO-... \
  --version VERSION \
  --owner ROLE \
  [--tag TAG] [--domain DOMAIN] [--output PATH] [--json]
```

The corresponding release refusal codes are `WEX401` to `WEX404`. Select one
verified or released final-candidate VREC and repeat `--work-order` for the
release scope. The final record must cover exactly that work and all its
verification contracts. The RLS binds its exact candidate commit. Earlier
records may be cited as supporting evidence at different commits; passing
their individual checks cannot replace final integration verification.

Before writing, the command proves the locked released evaluator including its wheel filename and SHA-256. It writes canonical normalized evaluator evidence and binds the evidence path and digest in the `status = "ready"` RLS. The record contains `prepared_at` and `prepared_by`; it omits `released_at` and `authorized_by` until a separate release transition. For the external layout, explicitly select `--integration git` or establish an equivalent owner rule before evidence writes. The selected `.gitattributes` fragment applies exactly `docs/engineering/**/evidence/*.json text eol=lf`, preserving canonical evidence bytes across supported checkouts so the raw SHA-256 survives. Independent validation and publication replay reject missing, changed, noncanonical, candidate-role, host-path-leaking, or lock-mismatched evidence. A rejected contract can support only its exact rejected RLS as terminal history and remains invalid for preparation, binding, release, publication, or credential-bearing use. The command does not transition the record to `released`, commit, push, tag, create a GitHub Release, publish to PyPI, or deploy.

Only `ready` and `released` release records claim a version. Valid rejected records remain immutable audit history and do not prevent one correctly bound active successor for an unpublished version; a second active record still fails.

`WO-REB-028` retired the repository-specific schema-2 bootstrap path that once worked around released 0.5.0's inability to parse a rejected record: the predecessor preparation, assessment and publication-view adapters, their entry-point scripts, and the `qualify predecessor-view` operation are gone. Generic `harnessctl prepare-release` was never altered by that path and is unchanged by its removal. The retained 0.6.0 records keep their bytes and their hash-bound evidence digests; they are verifiable and no longer re-derivable. The real upgrade rehearsal, `python -m repository_tools.upgrade_rehearsal` (see [rehearsing the root-evaluator handover](evaluator-migration-rehearsal.md)), is the one mechanism for predecessor-to-successor assurance.

## Authority summary

| Result | Meaning |
| --- | --- |
| successful check | derived observation about the inspected repository or runtime |
| generated dashboard | derived navigation and anomaly evidence |
| generated `draft` | incomplete authoring starting point |
| generated `ready` VREC/RLS | structurally prepared proposal awaiting accountable review |
| human transition to `verified` | assurance decision about the exact candidate and evidence |
| human transition to `released` | release authorization for that same candidate |

For lifecycle timing, see [operational phasing](harness-operational-phasing.md). For complete examples, see [practical SE Harness examples](harness-lineage-example.md).


To capture while keeping local edits, add `--candidate-commit COMMIT` and put
`--test-command EXECUTABLE ARGUMENTS...` last. Capture tests that commit in a
temporary checkout and retains the command result in the record. A failed test
writes no record; uncommitted caller content is not used as tested evidence.

## Explicit resource migration (successor candidate)

```text
harnessctl upgrade TARGET --external-resources --prior-wheel PRIOR_WHEEL [--retire-file PATH] [--integration git|ci|pr] [--json]
```

Preview first. Add `--apply` and `--instruction-delivery-evidence RECEIPT` to the
same reviewed selection to retire its local entry. `--prior-wheel` must match
the old selection; it is read as data to recognize stock bytes. Repeat
`--retire-file` only for explicitly selected unchanged editable seeds. Customized
instruction seeds refuse migration. Historical and owner files stay intact.
See the [migration procedure and resource map](harness-installation-and-upgrades.md#migrate-a-repository-copy-installation).
On an external-resource installation, `upgrade --integration git` previews the
Git attributes needed before hash-bound evidence. Repeat with `--apply` to write.

## Editable files and lightweight identity (repository-copy layouts)

`harnessctl upgrade TARGET --replace-file PATH` previews replacement of one
editable supplied file. Add `--apply` to write it; repeat the option for more
files. Other guidance, templates, CI and owner settings are kept. The selected
checker version still has to match the installation record.

Ordinary writes use checker origin/version. `doctor`, explicit `identity`,
installation, upgrade and release preparation check the full installed payload.
The module route works without a console launcher. Runtime identity schema v4
reports Python version without hashing the executable. New evaluator evidence
schema v2 binds canonical validated values; legacy schema v1 remains readable.

## Hosted lifecycle rehearsal (candidate client)

These commands belong to the separately installed candidate client. The selected
released evaluator remains 0.22.1 and is the service's sole lifecycle evaluator.

```text
CLIENT_PYTHON -I -m se_harness remote rehearse --endpoint ENDPOINT --project PROJECT_ID --token-env TOKEN_VARIABLE --client-wheel CLIENT_WHEEL --test-copy --request REQUEST_JSON --json
CLIENT_PYTHON -I -m se_harness remote operation --endpoint ENDPOINT --project PROJECT_ID --token-env TOKEN_VARIABLE --key ORIGINAL_KEY --json
CLIENT_PYTHON -I -m se_harness remote export --endpoint ENDPOINT --project PROJECT_ID --token-env TOKEN_VARIABLE --client-wheel CLIENT_WHEEL --test-copy --request EXPORT_JSON --destination NEW_DIRECTORY --json
```

Use the [closed v2 contract](../../server/contracts/lifecycle-v2.md) for request
fields, modes and allowed effects. `inspect` reports evaluator results. `preview`
stages a disposable result without changing graph state. `apply` requires the
returned preview digest and unchanged inputs. Only `apply` creates an accepted
operation receipt. A retry with identical inputs returns that receipt; different
inputs under its key fail. No arbitrary command or `--test-command` is forwarded.

Export requires an immutable baseline and a new directory. It writes exact files,
a Git bundle and a manifest. Download success does not claim successful independent
replay. All these records are test data; Git remains authoritative for real work.

## Concise hosted authoring

The candidate client supports explicit typed inputs for existing operations.
This does not change service schemas, select lifecycle actions or grant authority.
Use the installed candidate Python with `-I -m se_harness remote OPERATION`.
Common selection is `--endpoint URL --project UUID --token-env VARIABLE`.
Credentials stay in that environment variable. The service remains a private
loopback sandbox; Git remains authoritative.

| Operation | Required typed fields |
| --- | --- |
| `remote import` | `--source-manifest FILE` |
| `remote draft-open` | `--baseline ID --work-order WO-ID` |
| `remote create-artifact` | `--context UUID --context-version N --domain NAME --artifact-type TYPE`; optional `--artifact ID` |
| `remote revise-artifact` | `--context UUID --context-version N --artifact ID --expected-revision REVISION --document-file FILE` |
| `remote read` (revision) | `--artifact ID --expected-revision REVISION` and exactly one of `--baseline ID` or `--context UUID --context-version N` |

Select `--typed`. Every mutation also requires `--operation-key KEY`,
`--expected-project-version N`, `--evaluator-file FILE`, and `--client-wheel FILE`.
The evaluator file contains exactly `version`, `archive_sha256`, `payload_sha256`
from the selected combination. The client verifies the executing package against
its wheel. The source manifest uses the existing canonical manifest schema.
Document files are exact UTF-8 bytes, at most 1 MiB. Linked paths are refused.
The client constructs the existing wire request; the agent selects its meaning,
versions and key. It never retries or changes these inputs automatically.

Raw `--request FILE` remains available for every existing operation, including
freeze and test-copy lifecycle operations. Do not combine raw and typed input.
Invalid typed fields fail before a network request. Stale versions and reused
keys with changed content retain the service's normal refusal behavior.

Add `--compact --record-directory NEW_DIRECTORY` for an evidence-backed view.
The parent directory must exist; the destination must not exist or traverse a
link. It retains exact request/response bytes, decoded documents and capture
metadata (exit, timings, uncertainty). The view shows small fields and documents,
with explicit pointers for omitted content. Required omitted findings still need
reading. It is a presentation, not an independent verdict.
For known workflow results with a selected instruction step, the view can leave
the full instruction-step catalogue and evaluator-only inputs in `full_response`
when their pointers are smaller. Their JSON pointers are listed in `omitted`.
The response path is given once in `full_response`. The selected step, its
prerequisites, executable procedure, findings and next action stay in view.
For draft-validation responses, `draft_review` identifies the evaluator's shape
and required-link checks and reports content review as `not_assessed`. An empty
`incomplete` list and `findings_complete: true` do not establish content readiness.
The agent reviews the saved content against the applicable authoring checklist.

For `create-artifact`, optional `--include-document` performs one read of the
exact created revision after an accepted creation. No other mutation occurs.
Its `document_read` field retains the independent response. A failed read does
not undo creation. After a capture or transport failure, inspect retained results
and look up the original operation key; a remote effect may have committed.
Do not choose a new key to conceal an unknown outcome. An explicit separate
revision read remains available for verification.

### Complete instruction sections

For a repository governed by a release that supports this option:

```text
harnessctl resources REPO --section docs/engineering/ARTIFACT_AUTHORING.md#design-simplicity --section docs/engineering/ARTIFACT_AUTHORING.md#intent --json
```

Use actual returned/selected headings. The example does not select a lifecycle
step. `--section RESOURCE#heading` can repeat up to 12 times. Each complete section
includes source path, selected release, digest and line range. Overlapping sections
are included once. Unknown or ambiguous headings and changed resources fail.
Do not mix `--section` with `--resource`/`--content`. Existing resource modes stay
available. This candidate option does not make an older released evaluator support it.
The native test adapter can use the same installed reader on byte-verified staged
released resources; that does not substitute candidate policy for the released evaluator.
