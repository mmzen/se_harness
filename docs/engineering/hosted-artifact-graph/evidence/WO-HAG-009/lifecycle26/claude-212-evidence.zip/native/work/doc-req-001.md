+++
id = "REQ-P3-001"
type = "requirement"
title = "Return the exact test greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
statement = "Calling greeting() returns Hello rehearsal."
verification_method = ["test"]
priority = "must"
source = "Synthetic test fixture requirement"

[relations]
derives_from = ["CAP-P3-001"]
+++

# Return the exact test greeting

Synthetic test input. This is not a real human decision.

## In plain words

The greeting function must return the exact string `Hello rehearsal`.

## Why

The test operator needs a fixed, predictable greeting to verify the lifecycle workflow. The exact value provides a deterministic acceptance criterion.

## Behavior

| Trigger | Response | On failure |
| --- | --- | --- |
| Call to greeting() | Returns the string `Hello rehearsal` | No alternative; the function must return the exact value |

## Acceptance

Calling `greeting()` returns exactly `Hello rehearsal`.

## Examples

### Normal

**Given** the fixture module is available

**When** greeting() is called

**Then** it returns the string `Hello rehearsal`
