+++
id = "INT-P3-001"
type = "intent"
title = "Verify the rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
outcome = "The test operator observes the exact greeting Hello rehearsal."

[relations]
+++

# Verify the rehearsal greeting

Synthetic test input. This is not a real human decision.

## In plain words

An operator needs to confirm that the local test fixture returns a fixed greeting for a disposable lifecycle rehearsal.

## Problem

The operator has no exported evidence that the fixture greeting matches the expected value. The operator needs a lifecycle record that proves the greeting function returns exactly `Hello rehearsal`.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| Greeting matches expected value | not measured | Exact match confirmed | Local test assertion output |

## Not this

- Real product release or deployment
- Changes to the greeting source code
- External service integration
