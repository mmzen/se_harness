+++
id = "REL-P3-001"
type = "release_contract"
title = "Test release record for version 0.0.1"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
candidate_commit = "5820415917e87b64d80bad2f7c39c6d18d692829"
previous_release_tag = "v0.0.0"

[relations]
gates = ["WO-P3-001"]
+++

# Test release record for version 0.0.1

Synthetic test input. This is not a real human decision.

## Release unit

Test version 0.0.1 binds WO-P3-001 and its verified test candidate. No tags, publication or deployment.

## Required evidence

One verified VREC covering WO-P3-001 with passing assertion evidence for REQ-P3-001.

## Compatibility and migration

Not applicable to test fixture.

## Rollback criteria and procedure

Discard the disposable test project if replay fails. Retain the verification record and exact evidence.
