+++
id = "WO-P3-001"
type = "work_order"
title = "Verify the test greeting fixture"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[assurance]
commit_bound_verification = "required"
rationale = "Synthetic fixture decision for test assurance. Future release decision depends on verified greeting correctness."
decided_by = "test-owner"

[execution_scope]
paths = [
  "src/greeting.py",
  "docs/engineering/lifecycle-pilot/",
]

[relations]
implements = ["REQ-P3-001"]
specifications = ["SPEC-P3-001"]
verification = ["VER-P3-001"]
+++

# Verify the test greeting fixture

Synthetic test input. This is not a real human decision.

## Objective

Confirm that the existing fixture greeting function returns exactly `Hello rehearsal` and retain test evidence for lifecycle completion.

## In scope

Only the synthetic source fixture inspection, pilot definitions and test evidence.

## Out of scope

Real engineering records, real human decisions, external actions, and source code modification.

## Authorized decision envelope

All supplied actors are synthetic test labels. The executor may run the local assertion and retain evidence within the declared paths.

## Expected change surface

| Path | Reason |
| --- | --- |
| `src/greeting.py` | Inspected source fixture (read only, no modification) |
| `docs/engineering/lifecycle-pilot/` | New test artifacts, evidence and lifecycle records |

## Required verification

Run VER-P3-001 on the exact clean fixture commit. Assert that `greeting()` returns `Hello rehearsal`.

## Evidence to record

Retain assertion output in `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json`.

## Stop and escalate conditions

Stop when the released evaluator refuses or when greeting does not match.

## Completion report format

State the completed behavior, actual assertion result, relevant limitations and next accountable decision.
