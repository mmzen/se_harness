+++
id = "VER-P3-001"
type = "verification"
title = "Assert the test greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"

[relations]
verifies = ["REQ-P3-001"]
+++

# Assert the test greeting

Synthetic test input. This is not a real human decision.

## Independence

Expected text is fixed by REQ-P3-001 and SPEC-P3-001, not by candidate output. The pass condition derives from the requirement's acceptance criterion.

## Requirement-to-evidence matrix

| Requirement | Method | Case | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-001 | test | Exact greeting assertion | greeting() returns exactly `Hello rehearsal` |

## Acceptance scenarios

Call `greeting()` from `src/greeting.py` and compare its return value to the string `Hello rehearsal`. The comparison must be exact, including case and whitespace.

## Evidence retention

Retain the actual assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json`.
