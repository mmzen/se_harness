+++
id = "SPEC-P3-001"
type = "specification"
title = "Fixed test greeting specification"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
contract = "Return the fixed greeting without external effects."

[relations]
specifies = ["REQ-P3-001"]
+++

# Fixed test greeting specification

Synthetic test input. This is not a real human decision.

## In plain words

The fixture function returns a fixed string and has no side effects.

## Scope

This specification governs the return value of `greeting()` in `src/greeting.py`. It leaves implementation language and module structure to the implementation.

## Rules

**P3-GREET-001.** The function `greeting()` MUST return the string `Hello rehearsal`.

**P3-GREET-002.** The function `greeting()` MUST NOT produce side effects.

## Failure behaviour

| Trigger | Response | Diagnostic |
| --- | --- | --- |
| greeting() returns a different value | Test assertion failure | Comparison shows expected vs actual |

## Examples

**Given** a clean source fixture, **when** `greeting()` is called, **then** it returns `Hello rehearsal` (P3-GREET-001) with no observable side effects (P3-GREET-002).

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-001 | P3-GREET-001, P3-GREET-002 |
