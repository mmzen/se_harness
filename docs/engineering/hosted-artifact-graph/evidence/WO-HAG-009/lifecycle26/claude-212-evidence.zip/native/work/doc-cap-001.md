+++
id = "CAP-P3-001"
type = "capability"
title = "Read the test greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
ability = "An operator can read the fixed greeting from the local test fixture."

[relations]
derives_from = ["INT-P3-001"]
+++

# Read the test greeting

Synthetic test input. This is not a real human decision.

## In plain words

The operator can call the greeting function and observe its return value.

## Actor and need

The test operator needs to read the exact greeting returned by the fixture function `greeting()` in `src/greeting.py`. The operator uses this value to confirm that the fixture meets the rehearsal requirement.

## Not decided here

- How the greeting is implemented internally
- Whether the greeting value should change in future
