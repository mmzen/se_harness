+++
id = "SPEC-P3-900"
type = "specification"
title = "Fixed rehearsal greeting"
status = "approved"
owners = ["test-owner"]
created = "2026-10-06"
updated = "2026-10-11"
contract = "Return the fixed greeting without external effects."

[relations]
specifies = ["REQ-P3-900"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-11T03:28:38Z"
decided_by = "test-owner"
reason = "Synthetic diagnostic fixture input under WO-HAG-009. This is not a human approval of real work."
+++

# Fixed rehearsal greeting

Synthetic rehearsal input. This is not a real human decision.

**P3-GREET-900.** The fixture function greeting() returns the string `Hello rehearsal`.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-900 | P3-GREET-900 |
