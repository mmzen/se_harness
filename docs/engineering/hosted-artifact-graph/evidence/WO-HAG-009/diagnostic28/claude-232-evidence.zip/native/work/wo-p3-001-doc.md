+++
id = "WO-P3-001"
type = "work_order"
title = "Verify the synthetic greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"

[assurance]
commit_bound_verification = "required"
rationale = "The greeting assertion verifies executable behavior that later decisions depend on."
decided_by = "test-owner"

[execution_scope]
paths = [
  "src/greeting.py",
  "docs/engineering/lifecycle-pilot/",
]

[relations]
implements = ["REQ-P3-900"]
specifications = ["SPEC-P3-900"]
verification = ["VER-P3-900"]
+++

# Verify the synthetic greeting

## Objective

Execute the greeting assertion defined in VER-P3-900 against the fixture commit and retain the evidence.

## In scope

The fixture source `src/greeting.py`, the governing definitions, and test evidence under `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/`.

## Out of scope

Real engineering records, real human decisions, external actions, code changes, new features, and release delivery.

## Authorized decision envelope

The executor may run the defined assertion, record the result, and report completion. The executor may not change source code, modify approved definitions, or authorize a release.

## Constraints

The source fixture is read-only. All actors are synthetic test labels.

## Expected change surface

| Path | Reason |
| --- | --- |
| `src/greeting.py` | Existing source read by the assertion; no modification planned |
| `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json` | Retained assertion result from VER-P3-900 execution |

## Required verification

Run VER-P3-900 on the exact clean fixture commit. The greeting assertion checks that `greeting()` returns exactly `Hello rehearsal`.

## Evidence to record

Retain the actual assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json`.

## Stop and escalate conditions

Stop when the released evaluator refuses or the assertion fails.

## Completion report format

State the completed assertion, its pass or fail result, the retained evidence path, and the next accountable decision.
