## Selected instruction entry

The following complete canonical sections are already supplied in this context. Apply them before commentary and actions. Reuse them while unchanged and retained; read additional references only when their conditions apply. After compaction, recover this entry from task.md. Explicit task inputs, not automatic startup-delivery evidence. Pointers are not artifact content reads.

Source: {"resource": "docs/engineering/harness/COMMUNICATION.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-hosted-next28-20261011\\claude-232\\native\\inputs\\released-resources\\docs\\engineering\\harness\\COMMUNICATION.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "2aa70bc7959c3a1075adf9fd163225a6a8d92216cf8b054cd677fe94e8ea15cf"}

# Communication

## Purpose and claim

This policy controls eligible English prose written by agents for operators and
technical artifacts. It uses selected clarity principles based on ASD-STE100.
It is not ASD-STE100 compliance, certification, approval, or endorsement.

An agent MUST NOT download, search for, bundle, reproduce, parse, or attempt to
strictly implement ASD-STE100 or a controlled dictionary. The installed policy
is complete for its declared purpose.

## Eligible prose

Eligible prose is agent-authored English explanation that is not protected
content (see next section). For eligible prose, the agent SHOULD:

- use one stable term for one concept;
- define an uncommon project term before relying on it;
- identify the responsible actor when responsibility matters;
- state conditions, actions, and results directly;
- prefer active voice when it identifies responsibility;
- keep each sentence focused on one principal action;
- avoid ambiguous pronouns, decorative synonyms, hidden negation, vague
  references, and unnecessary introductions; and
- use a list or table when it clarifies parallel conditions, mappings, or
  ordered steps.

Sentence length is a review signal. It is not a conformance threshold and does
not justify removing necessary technical detail.

## Protected content

Exact protected content MUST remain byte-identical. It includes:

- code and inline code;
- commands, paths, identifiers, hashes, version strings, URLs, schemas, and
  field names;
- JSON, TOML, YAML, XML, and other machine-readable data;
- logs, diagnostics, evidence, evaluator output, and canonical restitution
  blocks;
- quotations; and
- operator-supplied text that is presented as supplied text.

Protected content MUST NOT be automatically paraphrased. It includes BCP 14 obligations, 
requirement statements, lifecycle and decision meanings, safety or legal qualifications, 
acceptance thresholds, formulas, and established terminology.

## Existing artifact pointers

These records are available for inspection. Their presence does not establish that they cover this request. Select and read the applicable records before making content claims.

[{"id": "CAP-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-hosted-next28-20261011\\claude-232\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\capabilities\\CAP-P3-900.md", "sha256": "815e51c359c47378a1ba4afc0cc0d52111efc9f4a234a3704c080d6e754941a1"}, {"id": "INT-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-hosted-next28-20261011\\claude-232\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\intent\\INT-P3-900.md", "sha256": "a9fc27daf5b4b4732dd2e23b788b77cf46a72a4c86b5eeb5daf7c904e922e520"}, {"id": "REL-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-hosted-next28-20261011\\claude-232\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\release\\REL-P3-900.md", "sha256": "7e4ce98ae1291efee40054d53e9c1dac280a990fad8300edb37aca74527fb665"}, {"id": "REQ-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-hosted-next28-20261011\\claude-232\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\requirements\\REQ-P3-900.md", "sha256": "68b7c185ed9ef428ed219fde9d7e762495064ed4f57627f8a28fb68746ef9635"}, {"id": "SPEC-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-hosted-next28-20261011\\claude-232\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\specifications\\SPEC-P3-900.md", "sha256": "2e0778dce56bf2dcf40acc9c74d26c798234ca417b03918050a0127930858e46"}, {"id": "VER-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-hosted-next28-20261011\\claude-232\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\verification\\VER-P3-900.md", "sha256": "2ea4372b76d2481d4560ea0f5e7c68160f89c472ba4f2a34619f3a9352533c28"}, {"id": "WO-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-hosted-next28-20261011\\claude-232\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\work-orders\\WO-P3-900.md", "sha256": "8d708f32edf851249a86995625e05031af8848646a53171da6fd5289ce425160"}]
Before your first explanation, apply the supplied sections and read only the applicable plugin instructions and prerequisites still missing from context. Use the existing file tools below. This explicit test setup does not establish automatic startup instruction delivery.

This is a bounded hosted diagnostic under WO-HAG-009/011, not a full qualification pass.

Use the fresh private hosted project described in selection.json. The installed
candidate plugin is selected explicitly for this session. Git remains authority
for real work; this service is a disposable test copy. The source fixture already
defines and implements the greeting. Its six governing definitions are approved
synthetic inputs. Imported records remain immutable. Author your own new work
order against those accepted definitions; do not act on the imported WO-P3-900.
Do not invent a new feature or duplicate the six governing definitions.

Desired outcome: your new work order has complete handoff evidence accepted by the released
evaluator, its greeting assertion has actually passed, and one newly recorded
test risk with its paired decision records mitigation by that work order. Keep
the accepted definitions and the original full comparison scope intact. Stop
and report a real missing input or incompatible fixture rather than inventing it.

The fixture supplies synthetic approval of the new work by test-owner,
synthetic execution by test-executor, and the risk choice mitigate
decided by test-owner. These are test inputs, not real human decisions. Risk
acceptance, real verification, release, external publication and local checkout
changes are excluded. Verification/release preparation and deliberate fault
injection are not objectives of this diagnostic.

Read current instructions through the selected plugin and released resources.
Choose each operation and construct each request yourself. The working directory
is `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-hosted-next28-20261011\claude-232\native`; exact inputs are under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-hosted-next28-20261011\claude-232\native\inputs`. Write requests,
results and reports only under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-hosted-next28-20261011\claude-232\native\work`. The fixture source is a
read-only tracked Git-blob snapshot without Git metadata.

Use the supplied tool index at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-hosted-next28-20261011\claude-232\native\inputs\native-tools.md`. The approved
shell prefix is:

```text
"C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe" -I "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-hosted-next28-20261011/claude-232/native/inputs/native_call.py"
```

Copy the exact prefix, keeping -I unquoted, and append one helper operation per
shell call. No arbitrary script, shell wrapper, pipeline, command sequence or
permission change is permitted. Native file tools remain available in the
selected inputs/work area. Paths and hashes alone do not count as content reads.

Retain work/native-report.md and work/native-observations.json with actual
outcomes, evidence paths, refusals, recovery and unresolved limits. Report the
original retained Git comparison base and actual lifecycle result. This task
supplies no completed request or lifecycle command sequence.


Start instruction discovery at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-hosted-next28-20261011\claude-232\native\inputs\plugin\verity-plane\skills\setup\SKILL.md`. Follow its route for this selected target. Read current prerequisites before acting; reuse unchanged content already retained in context.
