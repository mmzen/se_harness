# Native MCP read-tool discovery report

Focused discovery/reporting diagnostic under WO-HAG-009/011 and VER-HAG-007.
This test grants no verification, release, deployment, or authority switch.

## Identities

| Component | Identity |
| --- | --- |
| Project | `6715f258-0876-45dd-9e93-e1c6237ee2fa` |
| Imported baseline B | `se-harness-artifact-baseline/v1:sha256:343cb57c34cd7ef05d92d1e7e63d5e5c76999d65f719d48e87bf1ba67f7532e1` |
| Source fixture commit S | `5820415917e87b64d80bad2f7c39c6d18d692829` |
| Evaluator | 0.22.1, archive `cb35c3c4...63053`, payload `0e7b7c2b...e7ff` |
| Client | 0.22.2, wheel `f8eac9a9...86a3` |
| Combination | `sha256:8ca03ee7...36e1` |
| Qualification candidate C | `4ce5bfb56d5fc594380deec56c20f1696961a621` |
| Authority mode | `sandbox-projection` |
| Test copy | `true` |
| Test Git candidate P | Not established by this diagnostic |

## Setup

The client wheel SHA-256 and all component identities match the combination report.
The service reported `ready: true`, `authority_mode: sandbox-projection`, `test_copy: true` at project version 0.
Status record: `work/001-status.json`.

## Import

The canonical source fixture was imported once to establish the immutable baseline.
This is the only mutation authorized for this task.

| Field | Value |
| --- | --- |
| Operation key | `import-baseline-001` |
| Outcome | accepted |
| Receipt ID | `e1c6403b-f99b-4cca-b919-9fe4143c3f5c` |
| Project version | 0 → 1 |
| Artifacts imported | 7 (CAP-P3-900, INT-P3-900, REL-P3-900, REQ-P3-900, SPEC-P3-900, VER-P3-900, WO-P3-900) |
| Evaluator valid | true; 0 errors, 0 warnings, 1 advisory (W-AUT-022) |
| Import record | `work/002-import.json` |

All seven artifacts have status `draft` and git provenance from commit S.

## Seven MCP read tools

Every MCP read used the imported baseline view.
All seven returned `schema: "se-harness-graph-read/v2"`, `test_copy: true`, `observed_project_version: 1`, and `complete: true` with no unresolved references.

### 1. revision

Read the stored revision for WO-P3-900.
The response contained the complete `StoredRevision`: revision ID, envelope with artifact ID, document SHA-256, original path, declared relations, git provenance (blob OID `52e49c2e...07ca`), and the base64-encoded document.
The envelope's `declared_relations` listed three outgoing relation kinds: `implements` → REQ-P3-900, `specifications` → SPEC-P3-900, `verification` → VER-P3-900.

### 2. work-context

Read the work context for WO-P3-900.
The response identified 5 governing artifacts (CAP-P3-900, INT-P3-900, REQ-P3-900, SPEC-P3-900, VER-P3-900), 2 declared scope paths (`docs/engineering/lifecycle-pilot/`, `src/greeting.py`), no dependencies, and no relevant decisions.
The embedded evaluator output reported `check` outcome `completed`, compliance status `not_assessable`, WO-P3-900 status `draft`, and zero scoped or repository blockers.

### 3. compare

Compared the imported baseline to itself (same baseline on both sides).
The result confirmed zero changes, zero added relations, and zero removed relations.
This demonstrates that the compare tool accepts two explicit view selectors and returns a differential.

### 4. impact

Queried impact of REQ-P3-900 (the requirement).
The response identified 4 impacted artifacts: REL-P3-900, SPEC-P3-900, VER-P3-900, WO-P3-900.
It returned 6 relations with the following kinds: `gates`, `implements`, `specifies`, `specifications`, `verification`, `verifies`.
The root (REQ-P3-900) was excluded from the returned artifact list, as documented.

### 5. lineage

Queried verification/evidence lineage for VER-P3-900.
The response identified 1 connected artifact (WO-P3-900) through the `verification` relation kind.
This confirms that lineage reports recorded verification links; additional VREC or evidence links would appear when present.

### 6. check

Ran the released checkpoint-free check for WO-P3-900.
The evaluator output matched the work-context result: `check` outcome `completed`, compliance `not_assessable`, zero blockers.
The response included full instruction discovery with procedure `PROC-FOCUS-SELECTED`.

### 7. cypher

Executed a relationship-traversal query using the documented admitted form:

```cypher
MATCH (src:Revision)-[d:DECLARES]->(tgt:Artifact)
WHERE src.artifact_id = $artifact
RETURN src.artifact_id AS source_id, d.kind AS relation_kind,
       d.target_artifact_id AS target_id
LIMIT 10
```

Parameters: `{"artifact": "WO-P3-900"}`.

The response returned 3 columns (`source_id`, `relation_kind`, `target_id`) and 3 rows:

| source_id | relation_kind | target_id |
| --- | --- | --- |
| WO-P3-900 | implements | REQ-P3-900 |
| WO-P3-900 | specifications | SPEC-P3-900 |
| WO-P3-900 | verification | VER-P3-900 |

This query demonstrated:
- Relationship traversal using `-[d:DECLARES]->` with a named edge variable.
- Parameterized property comparison (`$artifact`).
- Return-column aliases (`AS source_id`, `AS relation_kind`, `AS target_id`).
- Access to the public `DECLARES` relationship properties `kind` and `target_artifact_id`.

## Public read interface: relationship reads and return-column aliases

### Relationship reads

The public Cypher surface supports relationship traversal between labelled nodes.
The documented public labels are `Artifact`, `Revision`, `Baseline`, `DraftContext`, and `Project`.
The documented public relationship types are `HAS_REVISION`, `SELECTS`, `BASED_ON`, `PROPOSES`, and `DECLARES`.

The admitted query form requires:
- One `MATCH` or `OPTIONAL MATCH` path with labelled nodes.
- Distinct variable names for each node and relationship.
- Optional parameterized property comparisons.
- `RETURN` and a numeric `LIMIT`.

The query `-[d:DECLARES]->` was accepted, returning the `kind` and `target_artifact_id` properties from the DECLARES edge.
Anonymous relationship syntax such as `-[:TYPE]->` is refused per the contract, but the refusal of that form does not mean relationship traversal is unsupported.
Relationship traversal with a named variable is the supported form, as executed and confirmed by this diagnostic.

### Return-column aliases

Return-column aliases using `AS alias` are supported and optional.
The executed query used three aliases (`source_id`, `relation_kind`, `target_id`), and the response returned those exact strings as column names.
Without aliases, the response column names use the raw Cypher expression.

### Unsupported syntax

The following are not part of the documented admitted form: unlabelled nodes, `WITH`, aggregation, and arbitrary database syntax.
A rejected query constitutes the refusal of that query; it does not complete a read.

## Failures and limitations

| Category | Count | Detail |
| --- | --- | --- |
| Native call failures | 1 | `read-text` for `source/docs/notes/hosted-artifact-graph.md` failed with `FileNotFoundError`. The file exists under `reference/`, not `source/`. Recovered by `find-file` and native Read. |
| MCP tool failures | 0 | All seven MCP tools returned successfully. |
| Service refusals | 0 | No query or read was refused by the service. |

## Remaining gaps

- Only one Cypher query was executed. Additional queries targeting other labels (e.g., `Artifact`, `Baseline`) or relationship types (e.g., `HAS_REVISION`, `SELECTS`) were not tested.
- The compare tool was tested only with the same baseline on both sides; a comparison between a baseline and a draft context was not tested because no draft context was opened.
- Database-side read-only enforcement remains unverified (RISK-HAG-001).
- Refused query forms (anonymous edges, unlabelled nodes, `WITH`, aggregation) were not directly tested; the refusal behavior is documented but not observed.
- Automatic plugin loading and desktop host behavior are unobserved.

## Evidence

| File | Content |
| --- | --- |
| `work/001-status.json` | Service status response |
| `work/002-import.json` | Import command record, receipt, and evidence directory |
| `work/003-observations.json` | Accumulated observations snapshot (27 native calls, 1 failure, 2 command records) |
| `work/native-observations.json` | Structured observation summary for each MCP tool |
| `work/native-report.md` | This report |
