"""Summarize exact completed native exchanges for manual review; assign no verdict."""
import json
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-cypher-contract33-20261011';r=O/'claude-282';n=r/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
assert (n/'session.json').exists()
calls=[]
for line,raw in enumerate((n/'events.jsonl').read_text().splitlines(),1):
 try:e=json.loads(raw)
 except ValueError:continue
 for b in e.get('message',{}).get('content',[]) if isinstance(e.get('message'),dict) else []:
  if b.get('type')=='tool_use':calls.append({'event_line':line,'tool':b['name'],'input':b['input']})
results=[]
for f in sorted((n/'work').glob('*.stdout.txt')):
 try:v=load(f)
 except (ValueError,UnicodeError):continue
 if not isinstance(v,dict):continue
 if v.get('schema')=='se-harness-lifecycle-result/v2':
  results.append({'file':f.name,**{k:v.get(k) for k in ['outcome','operation_key','receipt_id','request_digest','error','versions','affected_artifacts','baseline_id','provenance']},'evaluator_commands':[{'command':c.get('command'),'arguments':c.get('arguments'),'exit':c.get('exit')} for c in (v.get('evaluator_output') or {}).get('commands',[])]})
parity=[load(f) for f in sorted((O/'native-parity-full33').glob('*.json'))]
facts={'trial':'claude-282','session':load(n/'session.json'),'lifecycle_results':results,
 'parity':[{'tool':x['tool'],'status':x['http_status'],'exact_match':x['exact_match'],'complete':(x.get('native_result') or {}).get('complete'),'continuation':(x.get('native_result') or {}).get('continuation'),'unresolved_references':(x.get('native_result') or {}).get('unresolved_references')} for x in parity]}
for name,value in [('review-facts.json',facts),('native-call-index.json',{'trial':'claude-282','calls':calls,'complete':True,'omissions':'Private reasoning and non-tool messages excluded.'})]:
 f=r/name;assert not f.exists();f.write_bytes((json.dumps(value,indent=2)+'\n').encode())
print(json.dumps({'calls':len(calls),'results':len(results),'parity':facts['parity']},indent=2))
