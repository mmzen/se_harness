"""Offline review only: exclude directories from JSON-file enumeration.

Candidate/native inputs stay byte-identical. This does not repair the tested
host's failures or change evaluator replay semantics.
"""
import json,hashlib,sys,types,subprocess
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'hag-cypher-contract33-20261011';root=O/'claude-282'
assert (root/'native/session.json').exists(), 'Do not assist a running session'
mode=sys.argv[1]
name='summarize_native.py' if mode=='observe' else 'assess_native.py'
path=p.R/'tests/hosted_artifact_graph'/name
original=path.read_bytes();source=original.decode()
old="    for path in sorted((root/'work').rglob('*.json')):\n" if mode=='observe' else "        for path in sorted((args.native_root/'work').rglob('*.json')):\n"
indent='        ' if mode=='observe' else '            '
new=old+indent+"if path.is_dir() and not path.is_symlink():\n"+indent+"    continue\n"
assert source.count(old)==1
changed=source.replace(old,new)
sha=lambda b:hashlib.sha256(b).hexdigest()
note={'mode':mode,'source_path':str(path),'original_sha256':sha(original),'review_copy_sha256':sha(changed.encode()),'exact_old':old,'exact_new':new,'reason':'Native exports used directory names ending .json. The original JSON enumerator attempts read_text on them and raises PermissionError. The review copy skips ordinary directories while preserving file and symlink handling. No native input, candidate source, service, artifact, evaluator or receipt is changed. This is observer recovery, not a corrected native pass.'}
f=root/('observer-recovery-'+mode+'.json');assert not f.exists();f.write_bytes((json.dumps(note,indent=2)+'\n').encode())
sys.path.insert(0,str(path.parent))
if mode=='observe':
 mod=types.ModuleType('summarize_native');mod.__file__=str(path);sys.modules['summarize_native']=mod
 exec(compile(changed,str(path)+' [offline directory guard]','exec'),mod.__dict__)
 sys.argv=[str(p.W/'hag_review33.py'),'claude-282','observe']
 exec(compile((p.W/'hag_review33.py').read_text(),'hag_review33.py','exec'),{'__file__':str(p.W/'hag_review33.py'),'__name__':'__main__'})
elif mode=='replay':
 sys.argv=[str(path),'--native-root',str(root/'native'),'--selection',str(root/'selection.json'),'--credentials',str(root/'credentials.json'),'--evaluator-python',str(p.P),'--output',str(root/'independent-replay')]
 exec(compile(changed,str(path)+' [offline directory guard]','exec'),{'__file__':str(path),'__name__':'__main__'})
else:raise ValueError(mode)
