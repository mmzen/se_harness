"""Bounded read-only progress metadata; no provider reasoning is printed."""
import datetime,json,sys
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'hag-cypher-contract33-20261011'
sys.path.insert(0,str(p.R/'tests/hosted_artifact_graph'))
from summarize_native import summarize
for host in ('claude',):
 n=O/(host+'-'+sys.argv[1]+'/native')
 if not (n/'invocation.json').exists():continue
 s=summarize(n);inv=json.loads((n/'invocation.json').read_text())
 age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(inv['started_at'])).total_seconds()
 files=sorted((n/'work').rglob('*'),key=lambda f:f.stat().st_mtime)
 recent=[f.relative_to(n/'work').as_posix() for f in files if f.is_file() and not f.name.endswith('.stdout.txt') and '.evidence' not in str(f)][-8:]
 accepted=[]
 for f in (n/'work').rglob('*.stdout.txt'):
  try:x=json.loads(f.read_text(encoding='utf-8-sig'))
  except (ValueError,OSError):continue
  if isinstance(x,dict) and x.get('outcome')=='accepted':accepted.append({'file':f.relative_to(n/'work').as_posix(),'operation_key':x.get('operation_key'),'artifacts':[a.get('artifact_id') for a in x.get('affected_artifacts',[])]})
 unique={x['operation_key']:x for x in accepted}
 results=[]
 for f in [f for f in files if f.is_file() and f.name.endswith('.stdout.txt')][-3:]:
  try:x=json.loads(f.read_text(encoding='utf-8-sig'))
  except (ValueError,OSError):continue
  if isinstance(x,dict):results.append({'file':f.name,'outcome':x.get('outcome'),'error':x.get('error'),'receipt_id':x.get('receipt_id')})
 print(json.dumps({'recent_results':results},ensure_ascii=True))
 print(json.dumps({'host':host,'elapsed_seconds':round(s.get('wall_seconds') or age),'ended':(n/'session.json').exists(),'calls_or_items':s.get('native_calls'),'reported_failures':len(s.get('native_failures',[])),'recent_files':recent,'accepted_lifecycle_count':len(unique),'last_accepted':list(unique.values())[-2:]},ensure_ascii=True))
