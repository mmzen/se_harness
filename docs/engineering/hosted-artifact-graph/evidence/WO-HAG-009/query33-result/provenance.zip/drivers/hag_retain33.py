"""Retain bounded visible evidence, including honest observer recovery."""
from pathlib import Path
import sys,json
W=Path(__file__).parent
source=(W/'hag_retain26.py').read_text()
source=source.replace('hag-efficiency-compact-pointers-20261010','hag-cypher-contract33-20261011')
source=source.replace("dest=h.D/'evidence/WO-HAG-011'", "dest=h.D/'evidence/WO-HAG-009/query33-result';dest.mkdir(exist_ok=True)")
names=['initial-status.json','independent-final-status.json','independent-final-status-command.json','input-integrity.json','instruction-read-trace.json','boundary-before-native.json','boundary-after-native.json','boundary-comparison.json','costs.json','command-cost-supplement.json','review-facts.json','native-call-index.json','observer-recovery-observe.json','observer-recovery-replay.json','claim-audit.json']
source=source.replace("'immutable-baseline-review.json'):","'immutable-baseline-review.json',"+','.join(repr(n) for n in names)+"):")
extra="""for directory in ('independent-replay','independent-replay-corrected-reader','replay33'):
 for p in (root/directory).glob('*.json'):files['replay/'+directory+'/'+p.name]=p.read_bytes()
for directory in h.O.glob('native-parity-*33'):
 for p in directory.glob('*'+trial+'*.json'):files['parity/'+directory.name+'/'+p.name]=p.read_bytes()
for name in (trial+'-independent-replay.json',trial+'-corrected-reader-replay.json',trial+'-reader-replay-short.json',trial+'-observer-recovery.json',trial+'-original-summary-failure.json',trial+'-stop.json'):
 p=h.O/name
 if p.exists():files['proctor/'+name]=p.read_bytes()
"""
source=source.replace("summary=h.O/(trial+'-summary.json')",extra+"summary=h.O/(trial+'-summary.json')")
exec(compile(source,'retain-query33','exec'),{'__file__':str(W/'hag_retain26.py'),'__name__':'__main__'})
index=W/'hag221proposal/docs/engineering/hosted-artifact-graph/evidence/WO-HAG-009/query33-result'/(sys.argv[1]+'-inventory.json')
index.write_bytes((json.dumps(json.loads(index.read_text()),indent=2)+'\n').encode())
