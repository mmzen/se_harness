"""Commit the bounded reader fix with its actual checks, preserving native C33."""
import json,subprocess,hashlib,zipfile
import hag_efficiency_plan as p
O=p.W/'hag-cypher-contract33-20261011';p.O=O
E=p.D/'evidence/WO-HAG-009/query33-result'
C='4ce5bfb56d5fc594380deec56c20f1696961a621'
code=['tests/hosted_artifact_graph/'+x for x in ['summarize_native.py','assess_native.py','test_native_support.py']]
paths=code+[(E/n).relative_to(p.R).as_posix() for n in ['reader-fix.md','reader-checks.zip','reader-inventory.json']]
load=lambda f:json.loads(f.read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=p.R,text=True).strip()
assert git('rev-parse','HEAD')==C
assert set(git('diff','--name-only').splitlines())==set(code)
args=['check',p.R,'--artifact','WO-HAG-009','--checkpoint','scope','--changes-complete']
for v in paths:args+=['--changed-path',v]
x=p.gov('reader-complete-scope33',*args,'--json');assert x['compliance']['status']=='pass'
good=['reader-focused33-host','reader-source33','reader-distribution33','reader-smoke33','reader-preflight33','reader-validation33','reader-complete-scope33','claude-282-reader-replay-short']
assert all(load(O/(n+'.json'))['exit']==0 for n in good)
names=good+['reader-focused33','reader-fix-scope33','reader-summary-recheck33','claude-282-original-summary-failure','claude-282-corrected-reader-replay']
E.mkdir(exist_ok=True)
with zipfile.ZipFile(E/'reader-checks.zip','x',zipfile.ZIP_DEFLATED) as z:
 for n in names:z.write(O/(n+'.json'),n+'.json')
index={'archive':'reader-checks.zip','sha256':sha((E/'reader-checks.zip').read_bytes()),'files':[{'path':n+'.json','sha256':sha((O/(n+'.json')).read_bytes())} for n in names]}
(E/'reader-inventory.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
review='''# Reader correction after the Claude run

The completed candidate-33 run exported snapshots into directories named
`export-earlier.json` and `export-later.json`. These are valid export directory
names. The observation and independent replay scanners selected them with
`rglob('*.json')` and attempted to read them as files. The observation command
failed; it did not prove that the exports were corrupt.

Both readers now skip ordinary directories while still traversing their contents.
Existing file checks and the replay reader's symlink refusal remain unchanged.
The regression test exercises the real observation entry with a JSON-named export
directory containing both a manifest and a failed command record. It requires
the failure record to remain visible. No service, client, instructions, schema,
permissions, dependencies, criterion or lifecycle policy changes.

Validation: 41 focused tests; full source suite 1,337 tests, 24 reported skips;
distribution and CLI smoke; released validation 1,991 artifacts, zero errors,
63 warnings; scope and review preflight passed. The actual completed transcript
produces the same summary as the explicit offline recovery. The corrected replay
reader independently checks all ten accepted operations and all four export
copies (two distinct baselines), including exact bytes and candidate objects.

Failures are preserved: the initial focused command could not use the sandbox
temporary directory, then passed with normal host access. A repeated replay with
an unnecessarily long observer directory hit Windows Git's filename limit, then
passed in a shorter new directory without host-setting changes. The original
summary failure and all native errors remain retained.

This correction was made after the native session and does not rewrite its
inputs or verdict. Candidate-33 native evidence is still bound to
`4ce5bfb56d5fc594380deec56c20f1696961a621`. There was no further native model run
for this mechanical reader correction. Full qualification remains incomplete
because of the independently assessed procedure and reporting findings.
'''
(E/'reader-fix.md').write_bytes(review.encode())
p.run('reader-diff-check33',['git','diff','--check'],cwd=p.R)
p.run('reader-stage33',['git','add','--',*paths],cwd=p.R)
p.run('reader-staged-check33',['git','diff','--cached','--check'],cwd=p.R)
p.run('reader-commit33',['git','commit','-m','Handle JSON-named export directories in qualification readers','-m','Harness-Work-Order: WO-HAG-009'],cwd=p.R)
head=git('rev-parse','HEAD');assert not git('status','--porcelain')
(O/'reader-fix-commit33.json').write_bytes((json.dumps({'head':head,'native_candidate':C,'code_paths':code},indent=2)+'\n').encode())
print(head)
