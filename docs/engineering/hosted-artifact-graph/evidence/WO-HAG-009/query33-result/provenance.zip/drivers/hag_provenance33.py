"""Retain exact build/setup drivers; exclude credential stores and raw provider events."""
import json,zipfile,hashlib,re
import hag_efficiency_plan as p
O=p.W/'hag-cypher-contract33-20261011';E=p.D/'evidence/WO-HAG-009/query33-result'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
drivers=['hag_correction33.py','hag_full33.py','hag_full27.py','hag_native27.py','hag_efficiency_package03.py','hag_package33_review.py','hag_parity33.py','hag_native_parity19.py','hag_review33.py','hag_full27_review.py','hag_trace33.py','hag_full27_trace.py','hag_diagnostic33_facts.py','hag_retain33.py','hag_full27_retain.py','hag_retain26.py','hag_provenance33.py']
drivers+=['hag_review33_recovery.py','hag_full33_facts.py','hag_watch33.py','hag_reader_commit33.py']
for name in drivers:files['drivers/'+name]=(p.W/name).read_bytes()
for name in ['candidate-33','package-guidance-comparison','service-reuse-comparison','server-wheel-members','client-build-33','package-33','client-env-33','client-install-33','build33-replay','retention33-scope','WO-HAG-009-context-resume33','WO-HAG-011-context-resume33','pr-before33','pr-before33-connected','latest-ci-failure33']:
 files['checks/'+name+'.json']=(O/(name+'.json')).read_bytes()
files['checks/reader-fix-commit33.json']=(O/'reader-fix-commit33.json').read_bytes()
for trial in (281,282):
 for f in O.glob('claude'+str(trial)+'-*.json'):
  if 'live-probe' not in f.name:files['setup/'+f.name]=f.read_bytes()
for name in ['combination','image-metadata','image-package','plugin-assembly','plugin-claude-inventory','plugin-codex-inventory','server-build','source-commit','source-status']:
 files['package/'+name+'.json']=(O/'package33'/(name+'.json')).read_bytes()
files['setup/diagnostic-task-comparison.json']=(O/'claude-281/task-comparison.json').read_bytes()
tokens=[x['token'].encode() for f in O.glob('*/credentials.json') for x in load(f)['principals']]
for name,raw in files.items():
 assert not any(t in raw for t in tokens),name
 assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
with zipfile.ZipFile(E/'provenance.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
index={'archive':'provenance.zip','sha256':sha((E/'provenance.zip').read_bytes()),'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())],'limits':'No raw provider auth, private reasoning, credentials, account stores or full environments. Exact known test tokens checked absent.'}
(E/'provenance-inventory.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());print(len(files),'files')
