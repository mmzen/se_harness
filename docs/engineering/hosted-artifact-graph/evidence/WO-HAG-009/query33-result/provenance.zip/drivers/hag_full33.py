"""Native diagnostic first; full qualification only after its independent pass."""
import json,sys,hashlib
from pathlib import Path
W=Path(__file__).parent
mode=sys.argv[1];host=sys.argv[2] if len(sys.argv)>2 else None;trial=sys.argv[3] if len(sys.argv)>3 else '281'
diagnostic=mode.startswith('diagnostic-');actual=mode.removeprefix('diagnostic-')
O=W/'hag-cypher-contract33-20261011';root=O/(host+'-'+trial) if host else O
if mode=='run' and trial=='282':
 verdict=json.loads((O/'claude-281/independent-assessment.json').read_text());assert verdict['result']=='pass'
source=(W/'hag_full27.py').read_text()
source=source.replace('hag-lifecycle-native27-20261010','hag-cypher-contract33-20261011').replace('hag-lifecycle-correction27-20261010','hag-cypher-contract33-20261011')
source=source.replace("trial='221'",'trial='+repr(trial)).replace("host+'-221-boundary-probe.json'","host+'-"+trial+"-boundary-probe.json'")
for a,b in [('candidate-27','candidate-33'),('package27','package33')]:source=source.replace(a,b)
source=source.replace("source=(W/'hag_native27.py').read_text()", "source=(W/'hag_native27.py').read_text().replace('hag-lifecycle-native27-20261010','hag-cypher-contract33-20261011').replace('hag-lifecycle-correction27-20261010','hag-cypher-contract33-20261011').replace('package27','package33').replace('client27','client33').replace('build27','build33').replace('native-lifecycle27','native-query33').replace('hag-full27-','hag-full33-')")
source=source.replace("host+'-version'","host+trial+'-version'").replace("host+'-live-probe'","host+trial+'-live-probe'").replace("host+'-auth'","host+trial+'-auth'").replace("host+'-auth-review.json'","host+trial+'-auth-review.json'")
source=source.replace("host+'-live-probe.json'","host+trial+'-live-probe.json'")
source=source.replace(".replace('hag-full27-','hag-full33-')", ".replace('hag-full27-','hag-full33-').replace('10.231.84.0/22','10.231.88.0/22')")
source=source.replace("'--timeout','1800'", "'--timeout','900'" if diagnostic else "'--timeout','3600'")
if diagnostic:source=source.replace(",'--drop-reply'",'')
sys.argv=[__file__,actual,host,trial]
exec(compile(source,'native31-preparation-and-run','exec'),{'__file__':str(W/'hag_full27.py'),'__name__':'__main__'})
if mode=='diagnostic-stage':
 native=root/'native';s=json.loads((root/'native-selection.json').read_text());sys.path.insert(0,str(W/'hag221proposal/tests/hosted_artifact_graph'))
 from qualify_agents import shell_prefix
 task=f'''Inspect the canonical source fixture through the selected private hosted service. Demonstrate all seven read-only MCP tools, including a meaningful Cypher read, and produce an evidence-backed report of what happened and what the public read interface supports. This is a focused discovery/reporting diagnostic under WO-HAG-009/011 and VER-HAG-007. It is not a full lifecycle qualification.

The exact selection, candidate, source manifest, client, plugin and released evaluator are in SELECTION_FILE. The fresh project starts at version 0. You may import the supplied canonical fixture once to establish its immutable baseline. That is the only authorized mutation here. Choose requests from the selected instructions yourself. Do not create drafts, approve records, run lifecycle transitions, export, reset or publish anything. Git remains authoritative.

Use the imported baseline for the read tools. Inspect the actual returned content, completeness and selected view. Report observed successes, refusals, failures and limitations. Explain the public support for relationship reads and return-column aliases using the selected documentation; distinguish supported behavior from what you actually executed. No query or expected graph answer is supplied.

Use the candidate plugin's task routes. Your writable output directory is `{native/'work'}`. Inputs under `{native/'inputs'}` are read-only. The exact permitted helper prefix is:

```text
{shell_prefix(s['approved_shell_argv_prefix'])}
```

Append one helper operation per shell call. The tool index is `{native/'inputs/native-tools.md'}`. Native file tools remain available. No arbitrary commands, shell wrappers, pipelines or permission changes. Stop a denied action; do not switch routes to evade it.

Retain requests/results, `work/native-report.md` and `work/native-observations.json`. The report should allow an independent reviewer to distinguish complete observations from remaining gaps. This test grants no real verification, release, deployment or authority switch.
'''
 (root/'native-task.md').write_bytes(task.encode())
 proof=json.loads((root/'stage-evidence.json').read_text());proof.update(case='Focused NQ-01/NQ-03/NQ-05 read and report diagnostic; no full lifecycle pass',task_sha256=hashlib.sha256(task.encode()).hexdigest(),limits='Fresh project and unchanged canonical fixture. Native chooses import and reads. No supplied query, completed request, artifact answer or procedure sequence. Only fixture import is an authorized write; all other actions are reads/reporting.')
 (root/'stage-evidence.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
 print('Focused diagnostic task staged')
