"""Gather facts for manual diagnostic review without assigning a verdict."""
import json,sys
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-cypher-contract33-20261011';r=O/'claude-281';n=r/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
session=load(n/'session.json');summary=load(O/'claude-281-summary.json');trace=load(r/'instruction-read-trace.json')
calls=[]
for line,raw in enumerate((n/'events.jsonl').read_text().splitlines(),1):
 try:e=json.loads(raw)
 except ValueError:continue
 for b in e.get('message',{}).get('content',[]) if isinstance(e.get('message'),dict) else []:
  if b.get('type')=='tool_use':calls.append({'event_line':line,'tool':b['name'],'input':b['input']})
parity=[load(f) for f in sorted((O/'native-parity-diagnostic33').glob('*.json'))]
facts={'session':{k:session.get(k) for k in ['exit','timed_out','elapsed_seconds']},'calls':summary['native_calls'],'peak_input_context':summary['peak_input_context'],'failures':summary['native_failures'],
 'reads':[{'line':x['event_line'],'path':x['path'],'sections':x['sections']} for x in trace['reads']],
 'parity':[{'tool':x['tool'],'status':x['http_status'],'exact_match':x['exact_match'],'complete':(x.get('native_result') or {}).get('complete'),'continuation':(x.get('native_result') or {}).get('continuation'),'unresolved_references':(x.get('native_result') or {}).get('unresolved_references')} for x in parity],
 'initial_version':load(r/'initial-status.json')['project_version'],'final_version':load(r/'independent-final-status.json')['project_version'],'boundary':load(r/'boundary-comparison.json')['equal'],'inputs':load(r/'input-integrity.json')['all_unchanged']}
for name,value in [('review-facts.json',facts),('native-call-index.json',{'trial':'claude-281','calls':calls,'complete':True,'omissions':'Private reasoning and non-tool messages excluded.'})]:
 f=r/name;assert not f.exists();f.write_bytes((json.dumps(value,indent=2)+'\n').encode())
print(json.dumps(facts,indent=2))
