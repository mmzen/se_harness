+++
id = "SPEC-P3-001"
type = "specification"
title = "Greeting function return value"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
contract = "Return the fixed greeting without external effects."

[relations]
specifies = ["REQ-P3-001"]
+++

# Greeting function return value

Synthetic rehearsal input. This is not a real human decision.

## In plain words

The greeting function returns a fixed string with no side effects.

## Scope

This specification governs the return value of greeting(). It does not govern the module structure or import mechanism.

## Rules

**P3-GREET-001.** The function greeting() returns the string `Hello rehearsal`.

## Failure behaviour

| Trigger | Response | Diagnostic |
| --- | --- | --- |
| greeting() is called | Returns Hello rehearsal | none |

## Examples

**Given** the greeting module is available, **when** greeting() is called, **then** the return value is exactly `Hello rehearsal` per P3-GREET-001.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-001 | P3-GREET-001 |
