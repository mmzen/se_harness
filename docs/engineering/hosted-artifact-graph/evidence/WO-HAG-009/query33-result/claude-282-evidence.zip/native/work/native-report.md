# Native Hosted-Workflow Qualification Report

**Work orders:** WO-HAG-009, VER-HAG-007
**Date:** 2026-10-11
**Agent:** Claude Opus 4.6 (claude-282/native)
**Project:** `3da44b4c-e05e-42b3-a11b-445ae95a41b3`
**Context:** `2aa3af11-961d-4e0b-a28a-3885f7ad9505` (final version 25)
**Project version:** 27
**Evaluator:** 0.22.1 (`archive_sha256: cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`)
**Client:** 0.22.2 (`wheel_sha256: f8eac9a9df5a2737690690b6b912aadaf5536e3c96629d27aafeeb5f5a2286a3`)
**Candidate commit:** `55e3e9998bf8eb02c0ee68097aef6138e1030adb`

## Greeting assertion

Source file: `inputs/source/src/greeting.py`
Source SHA-256: `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`
Expected: `Hello rehearsal`
Actual: `Hello rehearsal`
Result: **pass**
Assertion evidence: `work/assertion.json` (sha256: `1c68cb06d853b1be9ab84ef3831240bf85a93770c9d23cfd7d7bdfec118ac9ed`, 412 bytes)

## Lifecycle completion

All lifecycle stages completed successfully at version 0.0.1:

| Stage | Artifact | Final status | Key records |
|---|---|---|---|
| Definitions authored | INT-P3-001, CAP-P3-001, REQ-P3-001, SPEC-P3-001, VER-P3-001, REL-P3-001, WO-P3-001 | approved | 010–018 (import + draft/create/freeze) |
| Risk + decision | RISK-P3-001, DEC-P3-001 | mitigating / decided (terminal) | 027–031 |
| Handoff (scope assertion) | WO-P3-001 | handed-off → implemented | 033–034 (preview/apply) |
| Completion | WO-P3-001 | implemented | 040–041 (preview/apply) |
| Capture-verification | VREC-P3-001 | ready | 042–043 (preview/apply) |
| Verify | VREC-P3-001 | verified | 044–045 (preview/apply) |
| Prepare-release | RLS-P3-001 | ready | 046–047 (preview/apply) |
| Release | RLS-P3-001 | released | 048–049 (preview/apply) |

Final baseline: `se-harness-artifact-baseline/v1:sha256:a60a6880a33d6017876b92a8174ce8c2523ef57a1a146f94f1a1d3752aa828a0`

## Required demonstrations

### Out-of-scope handoff refusal

**Record:** 032
**Action:** Attempted handoff with path `tests/assertion.json` outside WO-P3-001 declared scope (`docs/engineering/lifecycle-pilot/`, `src/greeting.py`).
**Result:** `WEX201: changed path is outside execution scope`. The server refused the preview. No state mutation occurred.

### Stale preview after draft change

**Records:** 038 (INT-P3-002 creation to bump context version), 039 (stale apply attempt)
**Action:** Created new artifact INT-P3-002 to advance context version from 18 to 19. Then attempted to apply a handoff preview digest computed at context version 18.
**Result:** `HAG_REMOTE_STALE_PREVIEW`. The apply was refused because the preview digest did not match the current context version. No state mutation occurred.

### Uncertain-reply recovery

**Records:** 020–023 (completed pre-compaction)
**Action:** Submitted a lifecycle command that returned an uncertain outcome. Recovered by looking up the operation receipt, confirmed the operation had actually succeeded, then proceeded without duplicate effect.

### Identical retry without duplicate

**Records:** 020–023 (completed pre-compaction)
**Action:** Retried the same operation key. The server returned `HAG_REMOTE_KEY_REUSE`, confirming idempotency enforcement. No duplicate state mutation occurred.

### Changed request under accepted key

**Records:** 020–023 (completed pre-compaction)
**Action:** Submitted a different request body using an already-accepted operation key.
**Result:** `HAG_REMOTE_KEY_REUSE` — the server refused to accept a changed request under a previously used key.

## MCP tool usage (all 7 tools)

| Tool | Target | Context version | Record/result |
|---|---|---|---|
| `cypher` | Graph query on artifact states | 25 | Pre-compaction session |
| `revision` | REQ-P3-001 revision read | 25 | Pre-compaction session |
| `check` | RLS-P3-001 | 25 | This session — RLS-P3-001 released, PROC-EXTERNAL-ACTION |
| `work-context` | WO-P3-001 | 25 | This session — WO implemented, VREC verified, delivery selection pending |
| `lineage` | REQ-P3-001 | 25 | This session — root node, no upstream ancestors |
| `impact` | INT-P3-001 | 25 | This session — 10 downstream artifacts, full traceability chain |
| `compare` | Import baseline vs context v25 | 25 | This session — 4 artifact changes (INT-P3-002 added, RLS-P3-001 added, VREC-P3-001 added, WO-P3-001 revised), 14 added relations |

## Exports

| Snapshot | Baseline | Snapshot ID | Files | Record | Destination |
|---|---|---|---|---|---|
| Earlier (import) | `se-harness-artifact-baseline/v1:sha256:325fafc0ce2e2144d982cbcabf35283816fc725ddf5c4d0735c62dd205587140` | `sha256:f874cea6b1c586b97b08d527321c09e8cf01d3b74ff999e9072e1555b62181cb` | 21 | 053, 056 | `work/snapshots/earlier` |
| Later (released) | `se-harness-artifact-baseline/v1:sha256:a60a6880a33d6017876b92a8174ce8c2523ef57a1a146f94f1a1d3752aa828a0` | `sha256:13dd7112cecc638e7c93b7175255160a54b3f5ffd1fa2a13a7078962da3931b8` | 29 | 054, 057 | `work/snapshots/later` |

## Failures and blockers

### Observations command failure

The `observations --record work/records` command failed with `PermissionError` because the first export operation created directories named `work/export-earlier.json` and `work/export-later.json`. The summarize scanner treats these directory names as JSON files and cannot open them. The `mv` and `mkdir` shell commands were denied by the host permission system. Re-exported to `work/snapshots/earlier` and `work/snapshots/later` (records 056, 057) but the orphaned directories remain and block the observations command. Report and observations files were authored manually from collected evidence.

### Host permission denials

- `ls` command: denied by host permission system. Worked around using helper file tools.
- `mv` command: denied when attempting to rename export directories.
- `mkdir` outside `work/`: denied. Created `work/snapshots/` directory via Write tool instead.

### Protected-field revision refusal

Attempted to revise approved artifact REL-P3-001 to bump context version for the stale-preview demonstration. Server returned `HAG_REMOTE_PROTECTED_FIELD: Imported records are immutable; create a separate draft proposal.` Resolved by creating new artifact INT-P3-002 instead.

## Key identifiers

- **Project:** `3da44b4c-e05e-42b3-a11b-445ae95a41b3`
- **Context:** `2aa3af11-961d-4e0b-a28a-3885f7ad9505` (version 25)
- **Candidate commit:** `55e3e9998bf8eb02c0ee68097aef6138e1030adb`
- **Import baseline:** `se-harness-artifact-baseline/v1:sha256:325fafc0ce2e2144d982cbcabf35283816fc725ddf5c4d0735c62dd205587140`
- **Final baseline:** `se-harness-artifact-baseline/v1:sha256:a60a6880a33d6017876b92a8174ce8c2523ef57a1a146f94f1a1d3752aa828a0`
- **Source SHA-256:** `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`
- **Assertion SHA-256:** `1c68cb06d853b1be9ab84ef3831240bf85a93770c9d23cfd7d7bdfec118ac9ed`
