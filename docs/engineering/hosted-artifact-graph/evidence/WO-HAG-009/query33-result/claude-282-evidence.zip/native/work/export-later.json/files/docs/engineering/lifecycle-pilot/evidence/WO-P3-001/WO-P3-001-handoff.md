```toml
artifact = "WO-P3-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "7cfee262d50e14f596812c66072b0b93e8cd8b3033f85e6e73f6bf7c56000261"
rebound_at = "2026-10-11T08:50:30Z"
```

# WO-P3-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
