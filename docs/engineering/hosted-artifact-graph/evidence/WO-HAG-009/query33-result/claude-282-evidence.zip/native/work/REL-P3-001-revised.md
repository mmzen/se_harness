+++
id = "REL-P3-001"
type = "release_contract"
title = "Test release record for version 0.0.1"
status = "approved"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
version = "0.0.1"

[relations]
gates = ["WO-P3-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-11T08:31:42Z"
decided_by = "test-owner"
reason = "Synthetic test approval for lifecycle rehearsal."
+++

# Test release record for version 0.0.1

Synthetic rehearsal input. This is not a real human decision.

Test version 0.0.1 binds this work and its verified test candidate. No tags, publication or deployment. Discard the disposable test project if replay fails. Retain the verification record and exact evidence.

## Required evidence

One explicitly verified VREC covering WO-P3-001 and its verification contract VER-P3-001.

## Rollback criteria and procedure

Stop if the final candidate lacks complete verified coverage or release approval.
