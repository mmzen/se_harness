+++
id = "RISK-P3-001"
type = "risk"
title = "Disposable test evidence lacks independent replay"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
description = "The disposable test project has no Git metadata, so independent replay from the exported bundle depends on the bundle integrity."
action = "Retain the exported bundle and verify its hash after replay."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-001"]
mitigated_by = ["WO-P3-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-11T08:37:34Z"
reason = "Mitigate through verification of exported bundle integrity per WO-P3-001."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-11T08:35:27Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-11T08:37:34Z"
decided_by = "test-owner"
reason = "Mitigate through verification of exported bundle integrity per WO-P3-001."
+++

# Risk: Disposable test evidence lacks independent replay

## Description

The disposable test project has no Git metadata, so independent replay from the exported bundle depends on the bundle integrity.

## Next action

Retain the exported bundle and verify its hash after replay.
