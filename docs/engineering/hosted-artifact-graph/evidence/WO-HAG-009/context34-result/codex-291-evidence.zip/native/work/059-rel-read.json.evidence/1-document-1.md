+++
id = "REL-P3-901"
type = "release_contract"
title = "Assess the greeting test release 0.0.1"
status = "approved"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
candidate_commit = "3148e23665f19e4dbfc8b2d78ca4d5a1c45614e8"

[relations]
gates = ["WO-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-11T10:29:57Z"
decided_by = "test-owner"
reason = "Supplied synthetic acceptance of the complete release contract for version 0.0.1 at the exact verified candidate; no external action."
+++

# Assess the greeting test release 0.0.1

## Release unit

Version 0.0.1 covers only WO-P3-901 at test candidate `3148e23665f19e4dbfc8b2d78ca4d5a1c45614e8`, the unchanged candidate bound by verified VREC-P3-901. This is the first release assessment in this new test sequence; no previous release tag applies. The synthetic record tag is `test-0.0.1`; it is metadata only and does not authorize creating a Git tag.

## Required evidence

VREC-P3-901 must remain verified and cover WO-P3-901 with VER-P3-901 at the exact candidate. Its retained assertion must report exit 0 and `exact greeting passed`, with SHA-256 `e3757467fb4bf322eefcf1156b67a630b75305a2bffeaf33dceeb8112b3490b0`. Retain the released handoff and evaluator evidence. Release preparation and release transition gates must pass under evaluator 0.22.1. Preserve the original candidate and all evidence digests in the exported history.

## Compatibility and provenance

The greeting source remains unchanged. There is no migration or deployed component. The source fixture commit and candidate implementation commit are distinct from this disposable test candidate. Synthetic labels supply no real authority.

## Promotion policy and decisions

The selected route is private test record preparation and assessment only. test-owner supplies definition acceptance; release-owner prepares and decides the release record after the required evidence and gates pass. No publication, push, tag creation, installation or deployment is included. Export earlier and later immutable snapshots to separate new local destinations for independent reviewer reconstruction.

## Rollback criteria and procedure

If the candidate, coverage, assertion digest or required gate does not match, stop the affected release operation and retain its refusal. Preserve accepted history; report the needed correction through the released procedure instead of rebinding an accepted record. An export with an incomplete marker is unusable. There is no deployed state to roll back.

## Observation

At delivery inspect the final record and export manifest. Independent reviewer replay remains a separate result and must not be inferred from a successful export.
