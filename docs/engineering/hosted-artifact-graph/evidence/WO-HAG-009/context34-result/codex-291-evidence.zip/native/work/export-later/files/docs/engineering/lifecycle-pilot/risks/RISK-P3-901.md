+++
id = "RISK-P3-901"
type = "risk"
title = "Inspection may be mistaken for executed proof"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
description = "If the operator treats source inspection or a service gate as a source test, the exported test record can claim proof without an executed assertion."
action = "Retain the exact local assertion under WO-P3-901 and bind it to the verification candidate; inspect it before verification."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-901"]
mitigated_by = ["WO-P3-901"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-11T10:25:31Z"
reason = "Supplied synthetic mitigation choice: retain the executed assertion and commit-bound evidence through WO-P3-901."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-11T10:24:45Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-11T10:25:31Z"
decided_by = "test-owner"
reason = "Supplied synthetic mitigation choice: retain the executed assertion and commit-bound evidence through WO-P3-901."
+++

# Risk: Inspection may be mistaken for executed proof

## Description

If the operator treats source inspection or a service gate as a source test, the exported test record can claim proof without an executed assertion.

## Next action

Retain the exact local assertion under WO-P3-901 and bind it to the verification candidate; inspect it before verification.
