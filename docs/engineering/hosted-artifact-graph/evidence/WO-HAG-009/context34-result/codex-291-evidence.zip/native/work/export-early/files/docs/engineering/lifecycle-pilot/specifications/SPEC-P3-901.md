+++
id = "SPEC-P3-901"
type = "specification"
title = "Exact no-argument greeting result"
status = "approved"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
contract = "The selected greeting() call returns the exact string Hello rehearsal."

[relations]
specifies = ["REQ-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-11T10:22:17Z"
decided_by = "test-owner"
reason = "Supplied synthetic acceptance of the complete test definition after gates pass."
+++

# Exact no-argument greeting result

## Scope and behavior

This contract covers `greeting()` in `src/greeting.py`. Calling it without arguments returns the Python string `Hello rehearsal`. Equality includes case and the single interior space. The returned string has no leading or trailing whitespace.

## Example and failure assessment

Given the selected fixture, when the local assertion calls `greeting()`, the expected value is `Hello rehearsal`. An exception or unequal result fails the check; retain the failure and withhold test verification. Invalid function arguments are outside this no-argument contract.

## Design review

The existing constant return is the smallest implementation that meets the agreed requirement. No source change, configurable greeting, external dependency, architecture record or design decision is needed. The output is a return value, not a console-output requirement.
