+++
id = "SPEC-P3-001"
type = "specification"
title = "Greeting function contract"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
contract = "The greeting function returns the fixed string Hello rehearsal."

[relations]
specifies = ["REQ-P3-001"]
+++

# Greeting function contract

## Scope

This specification governs the return value of the `greeting()` function in `src/greeting.py`. Calling convention and module structure are outside its scope.

## Rules

**P3-GREET-001.** The function `greeting()` returns the string `Hello rehearsal`.

## Failure behavior

The function has no failure mode. It returns a constant string with no external dependencies.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-001 | P3-GREET-001 |
