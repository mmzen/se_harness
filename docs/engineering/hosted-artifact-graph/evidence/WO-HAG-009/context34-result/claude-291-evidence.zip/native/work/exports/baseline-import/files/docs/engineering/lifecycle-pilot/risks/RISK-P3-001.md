+++
id = "RISK-P3-001"
type = "risk"
title = "Test evidence may not export correctly"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
description = "The disposable test project evidence could fail to export as an immutable snapshot, preventing independent replay verification."
action = "Verify export integrity after completion."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-001"]
mitigated_by = ["WO-P3-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-11T10:25:11Z"
reason = "Export verification through WO-P3-001 mitigates this risk."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-11T10:24:04Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-11T10:25:11Z"
decided_by = "test-owner"
reason = "Export verification through WO-P3-001 mitigates this risk."
+++

# Risk: Test evidence may not export correctly

## Description

The disposable test project evidence could fail to export as an immutable snapshot, preventing independent replay verification.

## Next action

Verify export integrity after completion.
