```toml
artifact = "WO-P3-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "cb58ad16320c544c0a74c2247ec7870c58ded5557cd503d83fb12a8b20f1282a"
rebound_at = "2026-10-11T10:30:17Z"
```

# WO-P3-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
