"""Retain bounded build/setup provenance without raw provider authentication."""
import json,zipfile,hashlib,re
import hag_efficiency_plan as p
O=p.W/'hag-context-correction34-20261011';E=p.D/'evidence/WO-HAG-009/context34-result'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
files={}
drivers=['hag_correction34.py','hag_full34.py','hag_full27.py','hag_native27.py','hag_efficiency_package03.py','hag_package34_review.py','hag_parity34.py','hag_parity34_host.py','hag_native_parity19.py','hag_review34.py','hag_full27_review.py','hag_trace34.py','hag_full27_trace.py','hag_full34_facts.py','hag_retain34.py','hag_retain26.py','hag_provenance34.py','hag_watch34.py','hag_full34_probe.py','hag_assess34_codex.py','hag_assess34_claude.py']
for name in drivers:files['drivers/'+name]=(p.W/name).read_bytes()
for name in ['candidate-34','package-guidance-comparison','service-reuse-comparison','server-wheel-members','client-build-34','package-34','client-env-34','client-install-34','build34-replay','prior-ci-failure','codex-291-boundary-probe','recovery34b-WO-HAG-009','recovery34b-WO-HAG-011']:
 files['checks/'+name+'.json']=(O/(name+'.json')).read_bytes()
for host in ['claude','codex']:
 for f in O.glob(host+'291-*.json'):
  if 'live-probe' not in f.name:files['setup/'+f.name]=f.read_bytes()
for name in ['combination','image-metadata','image-package','plugin-assembly','plugin-claude-inventory','plugin-codex-inventory','server-build','source-commit','source-status']:
 files['package/'+name+'.json']=(O/'package34'/(name+'.json')).read_bytes()
files['checks/proctor-limitations.json']=(json.dumps({'observations':[
 'Initial correction wrapper attempted Markdown link extraction from Python and stopped before tests. Corrected to Markdown files; focused and full checks then passed. Exact correction/check evidence is in sibling context34/.',
 'Initial Codex parity observer selected the already-existing Claude output directory and stopped before an HTTP observation. It was corrected to a separate Codex directory. No native hint or graph mutation occurred.',
 'Claude final observer initially ran without permission for the loopback service. It failed; the repeated failed transport read is retained. Host permission then allowed status and independent replay. No service mutation was retried.',
 'One recovery instruction reader used an incorrect heading, then read the actual Review of implemented changes heading. One Git status check ran outside the checkout, then was rerun at the selected checkout. These were proctor read errors, not native test results.'
 ],'source':'Observed tool errors; raw session outputs remain in the conversation. This explanatory record does not reconstruct missing command captures.'},indent=2)+'\n').encode()
tokens=[x['token'].encode() for f in O.glob('*/credentials.json') for x in load(f)['principals']]
for name,raw in files.items():
 assert not any(t in raw for t in tokens),name
 assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
with zipfile.ZipFile(E/'provenance.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
index={'archive':'provenance.zip','sha256':sha((E/'provenance.zip').read_bytes()),'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())],'limits':'No raw provider auth, private reasoning, credentials, account stores or full environments. Exact known test tokens checked absent.'}
(E/'provenance-inventory.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());print(len(files),'files')
