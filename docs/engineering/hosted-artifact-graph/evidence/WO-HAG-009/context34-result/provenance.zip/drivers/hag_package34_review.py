"""Compare exact packaged instructions and unchanged service components."""
import json,zipfile,hashlib,subprocess
import hag_efficiency_plan as p
O=p.W/'hag-context-correction34-20261011';old=p.W/'hag-claude-correction30-20261011';p.O=O
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
 assert not f.exists(),f
 f.write_bytes((json.dumps(v,indent=2)+'\n').encode())
c=load(O/'candidate-34.json')['commit'];combo=load(O/'package34/combination.json')['payload'];prior=load(old/'package30/combination.json')['payload']
assert combo['source']['candidate_commit']==c
rows=[]
for host in ['claude','codex']:
 archive=O/'package34/plugin'/('verity-plane-'+host+'.zip')
 assert sha(archive.read_bytes())==combo['plugins'][host]['archive_sha256']
 with zipfile.ZipFile(archive) as z:
  for rel in ['evidence/references/hosted-evidence.md','change/references/hosted-test-lifecycle.md']:
   raw=subprocess.check_output(['git','show',c+':plugins/verity-plane/common/skills/'+rel],cwd=p.R)
   name=next(n for n in z.namelist() if n.endswith('/skills/'+rel));actual=z.read(name);assert raw==actual
   rows.append({'host':host,'archive_member':name,'sha256':sha(actual),'exact_candidate_bytes':True})
doc='server/contracts/lifecycle-v2.md'
raw=subprocess.check_output(['git','show',c+':'+doc],cwd=p.R)
assert (O/'package34/candidate-source'/doc).read_bytes()==raw
rows.append({'path':doc,'sha256':sha(raw),'exact_candidate_bytes':True})
put(O/'package-guidance-comparison.json',{'candidate':c,'files':rows})
script="import json,hashlib,zipfile;from pathlib import Path;w,=Path('/opt/service-wheel').glob('*.whl');z=zipfile.ZipFile(w);print(json.dumps({'archive_sha256':hashlib.sha256(w.read_bytes()).hexdigest(),'members':{n:hashlib.sha256(z.read(n)).hexdigest() for n in sorted(z.namelist())}}))"
current=p.run('server-wheel-members',['docker','run','--rm','--network','none','--read-only','--entrypoint','python','harness-hag:native-query34','-c',script])
previous=json.loads(load(old/'server-wheel-members.json')['stdout'])
changed=[n for n in sorted(set(current['members'])|set(previous['members'])) if current['members'].get(n)!=previous['members'].get(n)]
components={k:combo[k]==prior[k] for k in ['evaluator','runtime','database','schema_revision','protocols']}
locks={k:combo['server'][k]==prior['server'][k] for k in ['dependency_lock_sha256','system_packages_sha256']}
assert not changed and all(components.values()) and all(locks.values())
result=load(old/'service-reuse-comparison.json');result.update(current_candidate=c,previous_comparison_candidate=prior['source']['candidate_commit'],current_wheel_sha256=current['archive_sha256'],current_member_count=len(current['members']),changed_members=changed,same_components=components,same_dependency_locks=locks,comparison_chain='Previous exact member comparison at WO-HAG-009/functional30/provenance.zip establishes equality to VREC-HAG-005. Current comparison uses all wheel members, not archive identity. Client/plugin qualification remains separate.')
put(O/'service-reuse-comparison.json',result)
print(json.dumps({'candidate':c,'packaged_guides_exact':len(rows),'unchanged_service_members':len(current['members'])}))
