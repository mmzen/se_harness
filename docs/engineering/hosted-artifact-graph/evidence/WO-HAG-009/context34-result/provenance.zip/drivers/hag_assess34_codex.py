import json,hashlib,tomllib,re
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-context-correction34-20261011';r=O/'codex-291';w=r/'native/work'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
def response(name):return json.loads(load(w/(name+'.json'))['stdout'])
replay=load(r/'replay34/assessment.json');assert replay['state']=='accepted_calls_and_native_exports_replayed'
assert len(replay['cases'])==12 and all(x['outcome']=='passed' for x in replay['cases'])
exports=[x for x in replay['exports'] if x['case'].startswith('native-')];assert len(exports)==4
parity=[load(f) for f in (O/'native-parity-codex-full34').glob('*.json')]
assert len(parity)==8 and all(x['exact_match'] and x['http_status']==200 for x in parity)
assert {x['tool'] for x in parity}=={'revision','work-context','compare','impact','lineage','check','cypher'}
for x in parity:
 assert x['native_result']['complete'] and x['native_result']['continuation'] is None and not x['native_result']['unresolved_references']
a=response('024-def-recovery');b=response('025-def-identical-retry')
assert a==b and a['outcome']=='accepted'
assert (w/'024-def-recovery.json.stdout.txt').read_bytes()==(w/'025-def-identical-retry.json.stdout.txt').read_bytes()
assert a['versions']['project']=={'before':15,'after':16}
assert response('026-changed-key')['error']['code']=='HAG_REMOTE_KEY_REUSE'
assert response('021-stale')['error']['code']=='HAG_REMOTE_STALE_PROJECT'
o=response('040-outside');assert o['outcome']=='refused' and not o['files'] and not o['affected_artifacts']
assert 'WEX201' in json.dumps(o['evaluator_output']) and 'QGP-G4I-PATHS' in json.dumps(o['evaluator_output'])
handoff=load(w/'045-handoff-request.json');assert handoff['action']['from_git']==a['provenance']['input_git_head']
base=a['provenance']['input_git_head']
early=tomllib.loads((w/'export-early/files/docs/engineering/lifecycle-pilot/work-orders/WO-P3-901.md').read_text().split('+++')[1]);assert early['status']=='draft'
source=r/'native/inputs/source';preserved=[]
for name in ['export-early','export-ready','export-release-ready','export-later']:
 m=load(w/name/'manifest.json');files=m['snapshot']['files']
 for f in list(source.rglob('*-900.md'))+[source/'src/greeting.py']:
  assert files[f.relative_to(source).as_posix()]['sha256']==hashlib.sha256(f.read_bytes()).hexdigest()
 preserved.append({'export':name,'baseline':m['baseline']['baseline_id'],'head':m['snapshot']['head']})
P='3148e23665f19e4dbfc8b2d78ca4d5a1c45614e8'
for rel in ['verification-records/VREC-P3-901.md','releases/RLS-P3-901.md']:
 v=tomllib.loads((w/'export-later/files/docs/engineering/lifecycle-pilot'/rel).read_text().split('+++')[1]);assert v['commit']==P
assert load(r/'input-integrity.json')['all_unchanged'] and load(r/'boundary-comparison.json')['equal']
summary=load(O/'codex-291-summary.json');capture=load(w/'071-observations-capture.json')
assert capture['observed_tool_items']==232 and len(capture['command_records'])==64
assert len(capture['native_failures'])==7 and len(capture['failed_command_records'])==5 and len(capture['observed_content_reads'])==84
report=(w/'native-report.md').read_text()
missing=[]
for link in re.findall(r'\]\(([^)]+)\)',report):
 if '://' not in link and not (w/link.split('#')[0]).exists():missing.append(link)
assert not missing,missing
value={'trial':'codex-291','candidate':'01476073cb2fa0a86aaec11c70b0b2d605e8e878','result':'pass',
 'scope':'This Codex NQ-01 through NQ-05 native run only; no combined host qualification, real VREC decision or performance success.',
 'scenarios':{'NQ-01':'pass: selected instructions, entry conditions, current procedures and identity distinctions observed; actual section trace retained.',
 'NQ-02':'pass: all required stages, assertion and mitigation observed; 12 accepted calls independently replayed; complete original handoff base preserved.',
 'NQ-03':'pass: changed SPEC draft made its prior preview stale; the project-version guard refused it before digest evaluation. Correct scope refusal and all seven MCP tools confirmed.',
 'NQ-04':'pass: dropped reply, lookup, byte-identical retry and changed-key refusal confirmed separately.',
 'NQ-05':'pass: four exports independently reconstructed, originals and P bindings preserved; inspected report claims and links agree with captures and disclose limitations.'},
 'accepted_operations':12,'native_exports':4,'mcp_calls':8,'handoff_base':base,'test_candidate':P,
 'exports':preserved,'wall_seconds':summary['wall_seconds'],'observed_tool_items':summary['observed_tool_items'],
 'complete_native_count':None,'peak_context':None,'native_failed_items':len(summary['native_failures']),
 'limits':['Read-only observer first stopped on a non-unique output directory before any request; corrected to its own directory, preserving the failure. No native assistance or graph mutation.',
 'Native report accurately preserves recovered input/heading/shell/summary-read errors and its partial captured counts. Its bulk command-record view exceeded the read limit; selected rows remained available.',
 'Native report leaves interpreter-version querying and independent replay to the reviewer. Replay is now independently complete; original report remains unchanged.',
 'Codex and Claude overlapped in separate projects. This full workflow is not the single-artifact performance case. No speed comparison is made.',
 'Database ACL, public operation and desktop remain outside this qualification; raised risks retain their states.']}
f=r/'independent-assessment.json';assert not f.exists();f.write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({k:value[k] for k in ['result','accepted_operations','native_exports','mcp_calls','wall_seconds','observed_tool_items']}))
