"""Independent immediate HTTP replay of actual native MCP reads."""
from pathlib import Path
import sys
W=Path(__file__).parent;trial=sys.argv[1];label='diagnostic34' if trial=='281' else 'full34'
source=(W/'hag_native_parity19.py').read_text().replace('hag-agent-qualification-execution-20261007','hag-context-correction34-20261011')
source=source.replace("hosts={'codex':O/'codex/native03','claude':O/'claude/native02/work/sonnet01'}", "hosts={'claude-"+trial+"':O/'claude-"+trial+"/native'}")
source=source.replace('time.monotonic()+3800','time.monotonic()+'+('1100' if trial=='281' else '3800'))
sys.argv=[__file__,label]
exec(compile(source,'native31-parity','exec'),{'__file__':__file__,'__name__':'__main__'})
