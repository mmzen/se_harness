"""Continue the same native Claude observation without supplying workflow answers."""
import json,os,shutil,subprocess,sys
from pathlib import Path
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
o=h.O;prior=o/'claude/native02/work/opus02';native=o/'claude/native02/work/opus03'
g=o/'claude-guidance12';old=o/'claude-guidance11'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
mode=sys.argv[1]
if mode=='stage':
    assert load(prior/'session.json')['timed_out']
    assert load(old/'selection.json')['project_id']==load(prior/'selection.json')['project_id']
    g.mkdir();(native/'inputs').mkdir(parents=True);(native/'work').mkdir()
    for p in (prior/'inputs').iterdir():
        if p.is_dir():shutil.copytree(p,native/'inputs'/p.name)
        elif p.name!='inventory.json':shutil.copyfile(p,native/'inputs'/p.name)
    # Same-host records only. These are observed artifacts, not operator-created
    # answers. Keep raw command records and add byte-preserving stdout views.
    previous=native/'inputs/previous-work';shutil.copytree(prior/'work',previous)
    for p in previous.rglob('*.json'):
        v=load(p)
        if isinstance(v,dict) and isinstance(v.get('stdout'),str):
            with p.with_name(p.name+'.stdout.txt').open('x',encoding='utf-8',newline='') as stream:stream.write(v['stdout'])
    h.write(native/'inputs/previous-session.json',load(prior/'session.json'))
    shutil.copyfile(prior/'events.jsonl',native/'inputs/previous-events.jsonl')
    original_helper=o/'claude/native02/inputs/native_call.py'
    assert h.sha(original_helper.read_bytes())=='3438927b4e48bed88038f17e564ff6b00f6527d04f8a292338e149165eb2a7b8'
    assert (h.R/h.D/'evidence/WO-HAG-009/opus02-incomplete.zip').is_file()
    shutil.copyfile(h.R/'tests/hosted_artifact_graph/native_call.py',original_helper)
    h.write(g/'helper-change.json',{'prior_sha256':'3438927b4e48bed88038f17e564ff6b00f6527d04f8a292338e149165eb2a7b8','current_sha256':h.sha(original_helper.read_bytes()),'scope':'WO-HAG-009 test-driver output only. Same approved executable/script path and operations; original raw command record retained. No new shell or network capability.'})
    selection=json.loads(json.dumps(load(old/'native-selection.json')).replace(str(prior).replace('\\','\\\\'),str(native).replace('\\','\\\\')))
    selection['endpoint']=load(old/'selection.json')['endpoint']
    selection.update(native_task_file=str(native/'task.md'),output_directory=str(native/'work'))
    h.write(g/'native-selection.json',selection)
    h.write(g/'selection.json',load(old/'selection.json'))
    h.write(g/'credentials.json',load(old/'credentials.json'))
    task=(old/'native-task.md').read_text().replace(str(prior),str(native))
    task=task.replace('This is a fresh independent trial. Do not read previous sessions or their outputs.',
        'This continues your own timed-out Opus02 trial in the SAME private Claude project.\nYour own unchanged earlier requests, receipts and artifacts are read-only at `'+str(previous)+'`.\nYour previous event stream is at `'+str(native/'inputs/previous-events.jsonl')+'`.\nInspect actual state and uncertain writes before continuing; do not replay completed effects.\nNo other host or trial records may be read. Nothing in these pointers supplies a new lifecycle decision.')
    task=task.replace('prepared a new schema-2 service','prepared the same schema-2 service retained from your earlier observation')
    task+='\n## Continuation boundary\n\nThe earlier native session ended at its recorded time limit. Complete the original\nrequired outcomes that remain unperformed, using the same candidate guidance.\nDo not infer a pass from earlier prose. Preserve completed effects and errors.\nWrite new results only in the new output directory. Previous work is read-only.\nThe helper now retains its original command record and returns a `stdout_file`\npath containing the complete unmodified result, without escaped JSON strings.\nUse native Read to inspect that result. The earlier records have matching\n`.stdout.txt` copies for readability; their original bytes are preserved.\nNo workflow commands, completed requests, decisions or gate answers are supplied.\n'
    inventory=[{'path':str(p),'relative':p.relative_to(native/'inputs').as_posix(),'bytes':p.stat().st_size,'sha256':h.sha(p.read_bytes())} for p in sorted((native/'inputs').rglob('*')) if p.is_file()]
    h.write(native/'inputs/inventory.json',{'files':inventory,'note':'Exact continuation inputs; previous-work entries are this same native Claude trial only. An inventory hash is not proof of reading.'})
    h.write(g/'native-task.md',task)
    rules=load(old/'permissions.json')
    rules['permissions']['deny']=[x.replace(str(prior).replace('\\','/').replace('C:','c'),str(native).replace('\\','/').replace('C:','c')) for x in rules['permissions']['deny']]
    h.write(g/'permissions.json',rules)
    h.write(g/'continuation-binding.json',{'previous_session_sha256':h.sha((prior/'session.json').read_bytes()),'previous_events_sha256':h.sha((prior/'events.jsonl').read_bytes()),'inputs_sha256':h.sha((native/'inputs/inventory.json').read_bytes()),'project_id':selection['project_id'],'task_sha256':h.sha(task.encode()),'permissions_sha256':h.sha((g/'permissions.json').read_bytes()),'operator_mutations':[],'changes':'Only test-result readability and continued task location. No host permission expansion, completed workflow request or service state mutation.'})
elif mode in ('state-before','state-after'):
    files=[Path(r'C:\Users\mathi\.codex\config.toml'),Path(r'C:\Users\mathi\.claude\settings.json'),Path(r'C:\Users\mathi\.claude\plugins\installed_plugins.json')]
    h.write(o/('guidance12-'+mode+'.json'),{'repository_head':h.git('rev-parse','HEAD'),'repository_status':h.git('status','--porcelain'),'host_settings':[{'path':str(p),'exists':p.is_file(),'sha256':h.sha(p.read_bytes()) if p.is_file() else None} for p in files]})
elif mode=='run':
    s=load(g/'selection.json');c=load(g/'credentials.json');token=next(p['token'] for p in c['principals'] if p['id']=='operator')
    v=h.run('claude-guidance12-initial-status',[s['client_python'],'-I','-m','se_harness','remote','status','--endpoint',s['endpoint'],'--project',s['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--json'],env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token))
    assert v['project_version']==26 and v['ready']
    exe=r'C:\Users\mathi\.local\bin\claude.exe'
    h.run('claude-guidance12-version',[exe,'--version'])
    probe=h.run('claude-guidance12-auth-probe',[exe,'-p','--no-session-persistence','--tools','','--model','claude-opus-4-6','--output-format','json','Authorized model availability probe. Reply exactly AUTH_OK. Read or change no files and use no tools.'],timeout=180)
    assert probe.get('result','').strip()=='AUTH_OK' and not probe.get('is_error')
    args=[h.HOST,'-X','utf8','-B',h.R/'tests/hosted_artifact_graph/qualify_agents.py','--host','claude','--executable',exe,'--selection',g/'native-selection.json','--credentials',g/'credentials.json','--task',g/'native-task.md','--output',native,'--prepared-inputs','--timeout','4500','--permission-settings',g/'permissions.json','--model','claude-opus-4-6']
    raise SystemExit(subprocess.call(list(map(str,args)),cwd=h.W))
