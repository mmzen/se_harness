+++
id = "RISK-P3-001"
type = "risk"
title = "Synthetic test risk for greeting fixture"
status = "raised"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
description = "Test risk to validate risk-decision lifecycle workflow in this disposable project."
action = "Verify exact greeting text matches specification."
raised_by = "test-executor"
likelihood = 2
impact = 2
score = 4

[relations]
threatens = ["WO-P3-001"]

[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-07T08:44:29Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."
+++

# Risk: Synthetic test risk for greeting fixture

## Description

Test risk to validate risk-decision lifecycle workflow in this disposable project.

## Next action

Verify exact greeting text matches specification.
