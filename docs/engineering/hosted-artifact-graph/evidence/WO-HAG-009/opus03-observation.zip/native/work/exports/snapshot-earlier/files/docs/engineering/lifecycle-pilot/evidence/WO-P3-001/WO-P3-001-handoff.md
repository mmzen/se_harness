```toml
artifact = "WO-P3-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "bd829db4a3dcda881e2ca7ddca7a90dc18468e23056830fd48af127a0ae8c3cd"
rebound_at = "2026-10-07T09:00:30Z"
```

# WO-P3-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
