+++
id = "SPEC-P3-001"
type = "specification"
title = "Fixed rehearsal greeting specification"
status = "approved"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
contract = "Return the fixed greeting without external effects."

[relations]
specifies = ["REQ-P3-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-07T08:40:38Z"
decided_by = "test-owner"
reason = "Synthetic test: accept complete test definitions."
+++

# Fixed rehearsal greeting specification

Synthetic test input. This is not a real human decision.

**P3-GREET-001.** The fixture function greeting() returns the string `Hello rehearsal`.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-001 | P3-GREET-001 |
