+++
id = "RISK-P3-003"
type = "risk"
title = "Stale preview demonstration risk"
status = "raised"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
description = "Temporary risk to change project state for stale preview demo."
action = "Observe stale preview refusal then proceed."
raised_by = "test-executor"
category = "test"
likelihood = 1
impact = 1
score = 1

[relations]
threatens = ["WO-P3-001"]

[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-07T09:07:14Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."
+++

# Risk: Stale preview demonstration risk

## Description

Temporary risk to change project state for stale preview demo.

## Next action

Observe stale preview refusal then proceed.
