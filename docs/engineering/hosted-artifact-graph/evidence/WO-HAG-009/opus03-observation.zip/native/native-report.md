# Native Hosted-Workflow Qualification Report

Qualification: WO-HAG-009 / VER-HAG-007
Agent: Claude Opus 4.6 (claude-opus-4-6)
Date: 2026-10-07
Session: Opus03 continuation of Opus02 (timed out at receipt 050)

## Project identity

| Field | Value |
|---|---|
| project_id | `0981742c-0b57-469d-a527-6f227c67f385` |
| endpoint | `http://127.0.0.1:18332` |
| authority_mode | `sandbox-projection` |
| test_copy | `true` |
| context_id | `a27675eb-a7cc-4e03-9892-7f77eba4f83c` |
| final context_version | 26 |
| final project_version | 29 |
| source_commit | `5820415917e87b64d80bad2f7c39c6d18d692829` |

## Component identities

| Component | Version | SHA-256 |
|---|---|---|
| Client (candidate) | 0.22.2 | `84a24a0824fabc22f72142efc9cbc1f46651f75a5c814fb3de179259e2fa494b` |
| Evaluator (released) | 0.22.1 | archive: `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053` |
| Evaluator payload | 0.22.1 | `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff` |
| Greeting fixture | - | `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1` |

## Required outcome 1: Full lifecycle through work completion, verification, and release

**Status: Completed**

The full SE Harness lifecycle was exercised across two sessions (Opus02 receipts 001-050, Opus03 receipts 001-007):

1. **Definition authoring** (prev 001-018): Created and revised INT-P3-001, CAP-P3-001, REQ-P3-001, SPEC-P3-001, VER-P3-001, WO-P3-001, REL-P3-001. Drafted via `draft-open`, `create-artifact`, `revise-artifact`, then frozen.
2. **Definition acceptance** (prev 019-020): All 7 definitions transitioned draft -> approved via `transition` action. All QG-G1-DEFINITION, QG-G2-ARCHITECTURE, QG-G3-WORK-AUTHORIZATION, QG-G5-RELEASE-PREPARATION, and QG-STRUCTURAL gates passed.
3. **Work started** (prev 024-025): WO-P3-001 transitioned approved -> in_progress.
4. **Greeting assertion** (prev 026): `assert-greeting` helper confirmed `greeting()` returns exactly `Hello rehearsal` (exit_code 0, result: "exact greeting passed").
5. **Risk raised and decided** (prev 027-036): RISK-P3-001 raised and decided via DEC-P3-001 with mitigation=WO-P3-001.
6. **Implementation handoff** (prev 038-040): Valid handoff completed after out-of-scope refusal demo.
7. **Work completed** (prev 045-046): WO-P3-001 transitioned in_progress -> implemented.
8. **VREC captured** (prev 047-048): VREC-P3-001 created with assertion evidence.
9. **VREC verified** (opus03 002-003): VREC-P3-001 transitioned ready -> verified. QG-G4-ASSURANCE-DECISION passed. project_version 26->27, context_version 23->24.
10. **RLS prepared** (opus03 004-005): RLS-P3-001 prepared at commit `abff603a`. QG-G5-RELEASE-DECISION and QGS-VERIFIED-INCLUSION passed. project_version 27->28, context_version 24->25.
11. **RLS released** (opus03 006-007): RLS-P3-001 transitioned ready -> released. All gates passed. project_version 28->29, context_version 25->26.

### Key artifact revisions (final state)

| Artifact | Revision ID |
|---|---|
| INT-P3-001 | `sha256:4686dc3aa46bffd936fd2931d5846d724034cf7e411c7aebef825f49fdcd2a77` |
| CAP-P3-001 | `sha256:4392001d49889efd6b6b00b25cc5684e6f9f6045cb909478a87eb5cc1252f178` |
| REQ-P3-001 | `sha256:9529b19ebc60c8cb33b7b9560b373186e4c728e34a73e4fdcdee0084ec3389fa` |
| SPEC-P3-001 | `sha256:1ad911a3bdc4868df07ee2e60382a9e4d8b86aee90582108ae7082a59259e42a` |
| VER-P3-001 | `sha256:cf602a5ebdbef43d808bcadb0944cc9de07474bd0473f983441683026704db45` |
| REL-P3-001 | `sha256:8d42c88406b05f50c79b590375ea4a944fa7acbf5e06cdb6e09df8e598c9217a` |
| WO-P3-001 | `sha256:655ebcd7fa20f3a7adac72f64ef8106318c503009ac968e8ea1ab3b45400bad5` |
| DEC-P3-001 | `sha256:50c609d7ac714611d037afe60c210749f02163ffbda8a15ca14ea2f69dbf8cfb` |
| VREC-P3-001 | `sha256:80d234806e63e7310f99cdf19329d7c1409a129f58958bb2baa28c6839e50cd6` |
| RLS-P3-001 | `sha256:faeb423fb13515a1a971b38a5d34c9a1bb55b08b9d0419d0f780d25e0c641681` |

### Greeting assertion evidence

```json
{"result": "exact greeting passed", "expected": "Hello rehearsal", "exit_code": 0}
```

## Required outcome 2: Out-of-scope handoff refusal and stale preview

**Status: Completed (previous session)**

- **Out-of-scope refusal** (prev receipt 037): A handoff check with changed path `totally/outside/scope/rogue-file.txt` was refused by the evaluator. Gate `QGP-G4I-PATHS` failed with `WEX201: changed path is outside execution scope`. The evaluator returned `outcome: blocked` and the service returned HTTP 422 with `HAG_REMOTE_EVALUATOR_REFUSED`. WO-P3-001 remained `in_progress` unchanged.

- **Stale preview** (prev receipt 042): After a draft change, an apply request using a preview_digest from a prior state was refused with HTTP 409 `HAG_REMOTE_STALE_PREVIEW: Apply needs a preview bound to these exact inputs.` No state changed.

Both refusals correctly preserved existing state and the valid work was completed afterward.

## Required outcome 3: Uncertain-reply recovery, identical retry, changed key refusal

**Status: Completed (previous session)**

- **Uncertain-reply recovery** (prev receipt 021): After the definition transition apply (receipt 020 accepted the transition with operation_key `op-transition-defs-001`), the agent used `operation` lookup on the same key. The service returned the complete accepted result with the same receipt_id, baseline_id, and affected revisions, confirming the operation was already applied.

- **Identical retry** (prev receipt 022): The identical request with the same operation_key was retried. The service returned the same accepted result without creating a duplicate effect. The receipt_id, baseline_id, and all revision IDs matched exactly.

- **Changed key refusal** (prev receipt 023): A modified request body using the same operation_key `op-transition-defs-001` was submitted. The service refused with HTTP 409 `HAG_REMOTE_KEY_REUSE: Operation key has different content.`

## Required outcome 4: All 7 MCP tools on meaningful views

**Status: Completed (this session)**

All 7 read-only MCP tools were called at the final context (context_version 26) with meaningful selected views:

| # | Tool | Target | Key finding |
|---|---|---|---|
| 008 | check | RLS-P3-001 | Status: released, procedure PROC-EXTERNAL-ACTION, compliance not_assessable |
| 009 | work-context | WO-P3-001 | Status: implemented, 5 governing artifacts, 2 dependencies (RLS, VREC), scope: `src/greeting.py`, `docs/engineering/lifecycle-pilot/` |
| 010 | lineage | REQ-P3-001 | Root artifact with no upstream lineage (leaf requirement) |
| 011 | impact | INT-P3-001 | 12 downstream artifacts, 17 relations spanning full traceability chain |
| 012 | revision | RLS-P3-001 | Retrieved revision envelope and base64 document for revision `sha256:faeb423f...` |
| 013 | compare | Earlier vs later baseline | 2 added artifacts (RLS-P3-001, VREC-P3-001), 5 added relations, 0 removed |
| 014 | cypher | VREC-P3-001 query | Returned `[["VREC-P3-001", "verified"]]` |

All responses: `complete: true`, `continuation: null`, `test_copy: true`.

## Required outcome 5: Export two immutable snapshots

**Status: Completed (this session)**

| Export | Baseline ID | Snapshot ID | Files | Destination |
|---|---|---|---|---|
| Earlier | `se-harness-artifact-baseline/v1:sha256:82acd8d5c0d9eaeac75c382b28df8771ff8d81d9a048cfc05cccc5efba097a4d` | `sha256:8adf17fdb1c773ee0d9835ff71d54c3e4786db7e4a1b4d4a6ddc31742b01123d` | 26 | `work/exports/snapshot-earlier` |
| Later | `se-harness-artifact-baseline/v1:sha256:f5c25ec8ef4fa9c19d7158cdd3355efeb8f9dcfcaa6597c9c95fb06952746918` | `sha256:b23166b1490ea4dd8fc83e0dae01843b67cdf621926810093cc445625d96368b` | 30 | `work/exports/snapshot-later` |

Both exports contain `files/`, `history.bundle`, and `manifest.json`. The later snapshot includes 4 additional files (VREC-P3-001, RLS-P3-001, and their evaluator evidence).

## Failures and errors

- **Previous session timeout**: Opus02 timed out at receipt 050 after previewing the VREC transition but before applying it. Opus03 resumed successfully.
- **VREC decide refusal** (prev receipt 049): Attempt to use `decide` action for VREC-P3-001 `ready -> decided` was refused with "transition VREC-P3-001: ready -> decided is not allowed". Corrected by using `transition` action instead.
- **Export directory creation** (receipt 015): First export attempt failed because the parent directory didn't exist (`Create the export parent directory first`). Resolved by creating placeholder files via Write tool, then using new destination paths.

## Interventions

- Context compaction occurred twice (Opus02 -> Opus03, and within Opus03). After each compaction, task.md and selection.json were re-read to restore tool boundary and task context.
- The endpoint port changed between sessions (65055 in Opus02, 18332 in Opus03) as the service was restarted. The selection.json in Opus03 reflected the current endpoint.

## Receipt inventory

### Previous work (read-only, Opus02)
Receipts 001-050 under `inputs/previous-work/receipts/`

### This session (Opus03)
| Receipt | Operation | Key |
|---|---|---|
| 001 | status | - |
| 002 | VREC transition preview | op-vrec-transition-001 |
| 003 | VREC transition apply | op-vrec-transition-001 |
| 004 | RLS prepare preview | op-rls-prepare-001 |
| 005 | RLS prepare apply | op-rls-prepare-001 |
| 006 | RLS transition preview | op-rls-transition-001 |
| 007 | RLS transition apply | op-rls-transition-001 |
| 008-014 | MCP tool reads | - |
| 015 | Export earlier (failed, dir missing) | - |
| 016 | Export earlier (succeeded) | - |
| 017 | Export later (succeeded) | - |
