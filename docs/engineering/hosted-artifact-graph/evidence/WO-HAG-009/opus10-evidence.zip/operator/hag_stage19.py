import json,subprocess
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007';o=h.O
helper=o/'claude/native02/inputs/native_call.py'
assert helper.read_bytes()==(h.R/'tests/hosted_artifact_graph/native_call.py').read_bytes()
h.write(o/'improve19-helper-binding.json',{'path':str(helper),'sha256':h.sha(helper.read_bytes()),'source_candidate':json.loads((o/'improve19-candidate.json').read_text())['commit'],'scope':'Unchanged helper and fixed prefix; guidance/index correction only.'})
for args in [('hag_native_guidance19.py','state-before'),('hag_native_guidance19.py','setup','claude'),('hag_native_guidance19.py','stage','claude'),('hag_finish_native19.py',),('hag_focus19.py',),('hag_audit19.py','runtime')]:
 subprocess.run([str(h.HOST),'-X','utf8','-B',*args],cwd=h.W,check=True)
assert not h.git('status','--porcelain')
print('Fresh diagnostic staged. Native workflow has not run.')
