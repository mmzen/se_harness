"""Stage current-task inputs; do not perform the native agent's workflow."""
import json,sys,subprocess
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007';g=o/'claude-guidance19';n=o/'claude/native02/work/opus10';inputs=n/'inputs'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
sys.path.insert(0,str(h.R/'tests/hosted_artifact_graph'))
from native_schema import operation_view
selection=load(g/'native-selection.json')
for family in ('remote-v1','read-v1','lifecycle-v2'):
 source=inputs/'reference/server/contracts'/(family+'.json');raw=source.read_bytes();schema=json.loads(raw)
 branches=schema['$defs']['Command']['oneOf'] if family=='remote-v1' else schema['$defs']['Request']['oneOf'] if family=='read-v1' else schema['properties']['action']['oneOf']
 key='kind' if family=='lifecycle-v2' else 'operation'
 for branch in branches:
  operation=(branch['allOf'][1] if family=='read-v1' else branch)['properties'][key]['const'];view=operation_view(raw,family,operation)
  view['source_file']=str(source)
  h.write(inputs/'schemas'/family/(operation+'.json'),view)
for operation in ('read','operation','create-artifact','revise-artifact'):
 h.write(inputs/'client-help'/(operation+'.txt'),subprocess.check_output([selection['client_python'],'-I','-m','se_harness','remote',operation,'--help'],cwd=h.W))
helper=o/'claude/native02/inputs/native_call.py'
h.write(inputs/'native-tools.md',(h.R/'tests/hosted_artifact_graph/native-tools.md').read_bytes())
task=f'''# Focused hosted drafting diagnostic

You are Claude under the approved WO-HAG-009 qualification test. Work independently
in the fresh private hosted project in SELECTION_FILE. This run tests instruction
discovery during draft preparation only. Git remains authoritative for real work.

## Requested outcome

Prepare exactly one new intent draft for an operator who needs to establish that
the existing fixture's greeting() returns exactly `Hello rehearsal`. Inspect the
fixture and author the intent in the selected private service. Keep it as draft
and report its actual authoring findings. Use domain lifecycle-pilot and synthetic
owner test-owner. Imported -900 records are immutable history. Do not create other
artifacts, approve anything, start work, freeze a baseline or exercise lifecycle
decisions. Stop when this one draft is complete and its current findings retained,
or report the exact blocker. This is a focused diagnostic, not a full package.


## Entry and tools

Read SELECTION_FILE. Begin with the candidate plugin's normal verity-plane:setup
Skill for this explicit hosted selection, then follow its current-task routes.
The client is installed; do not install software or activate a checkout. The
selected released_resources directory contains the exact 0.22.1 procedures.

The selection's tool_index is the single command/file-discovery reference.
Read it before choosing tool syntax. It lists capabilities and exact schema
locations without request values or a workflow sequence. Read only applicable
procedure sections and the schema for the operation you select.

Use native Read/Write/Edit and only the approved_shell_argv_prefix for shell
calls, one helper call per invocation. No scripts, wrappers, pipes, loops, direct
client calls or other shell commands. Normal permissions and hooks apply. Stop
a denied action; do not change permissions or try alternate routes.

Keep every draft, request, result and transient progress note under `{n/'work'}`
using absolute paths. This output directory already exists. Inputs are read-only.
Keep current IDs, versions and exact result paths in the note; after compaction,
recover task, selection, note and original evidence before acting.

Never print credentials, inspect auth stores, change account/host settings or
read prior trials. Authentication is in the process environment. Helpers perform
no hidden workflow; construct your requests from current inputs and instructions.

Finish with native-report.md and native-observations.json at `{n}`. Report actual
reads and triggers, exact evidence/digest sources, draft IDs/paths, findings,
failures and limits. No complete NQ-01--05 claim: lifecycle, MCP parity, reply
recovery and export are outside this focused diagnostic.
'''
h.write(g/'native-task.md',task)
selection['diagnostic_scope']='Focused draft instruction discovery; no complete NQ-01--05 claim.'
selection['schema_views']='inputs/schemas/FAMILY/OPERATION.json'
selection['tool_index']=str(inputs/'native-tools.md')
h.write(g/'native-selection.json',selection)
inventory=[{'path':str(p),'relative':p.relative_to(inputs).as_posix(),'bytes':p.stat().st_size,'sha256':h.sha(p.read_bytes())} for p in sorted(inputs.rglob('*')) if p.is_file() and p.name!='inventory.json']
h.write(inputs/'inventory.json',{'files':inventory,'note':'Exact staged inputs; content reads must be observed independently.'})
binding=load(g/'correction-binding.json');binding.update(task_sha256=h.sha(task.encode()),helper_sha256=h.sha(helper.read_bytes()),inputs_inventory_sha256=h.sha((inputs/'inventory.json').read_bytes()),
 interventions='Before-run guidance/input correction and focused task boundary. No chosen draft IDs, completed artifact bodies, request values, workflow sequence or operator service mutations.',
 schema_views=[{'path':x['relative'],'bytes':x['bytes'],'sha256':x['sha256']} for x in inventory if x['relative'].startswith('schemas/')])
h.write(g/'correction-binding.json',binding)
stage=load(g/'stage-evidence.json');stage.update(task_sha256=binding['task_sha256'],inputs_inventory_sha256=binding['inputs_inventory_sha256'],correction=binding['interventions']);h.write(g/'stage-evidence.json',stage)
print(json.dumps({'task_bytes':len(task.encode()),'schema_views':len(binding['schema_views']),'inventory_bytes':(inputs/'inventory.json').stat().st_size}))
