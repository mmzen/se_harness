"""Extract independent observations; retain native assertions for human review."""
import base64,json
from pathlib import Path
import hag221_execute as h

o=h.W/'hag-agent-qualification-execution-20261007';r=o/'claude/native02/work/opus10';review=o/'review19'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert (r/'session.json').exists()
a=load(review/'opus10-assessment.json');first=a['first_draft_content_write_line']
events=[json.loads(x) for x in (r/'events.jsonl').read_text(encoding='utf-8').splitlines()]
calls={};searches=[];decodes=[]
for line,event in enumerate(events,1):
 m=event.get('message',{})
 for b in m.get('content',[]) if isinstance(m,dict) else []:
  if not isinstance(b,dict):continue
  if b.get('type')=='tool_use':calls[b['id']]={'line':line,'name':b['name'],'input':b['input']}
  if b.get('type')!='tool_result':continue
  c=calls.get(b['tool_use_id'],{});command=c.get('input',{}).get('command','')
  if c.get('name')!='Bash':continue
  raw=b.get('content');parsed=None
  if isinstance(raw,str):
   try:parsed=json.loads(raw)
   except ValueError:pass
  if ' find-file ' in command:
   searches.append({'call_line':c['line'],'result_line':line,'command':command,'error':bool(b.get('is_error')),'total_matches':parsed.get('total_matches') if isinstance(parsed,dict) else None})
  if '--decode-base64' in command:
   decodes.append({'call_line':c['line'],'result_line':line,'error':bool(b.get('is_error')),'before_authorship':bool(first and line<first),'result':parsed})
templates=[]
for p in (r/'work').glob('*.stdout.txt'):
 try:v=load(p)
 except (ValueError,UnicodeError):continue
 data=v.get('data') if isinstance(v,dict) else None
 if not isinstance(data,dict) or 'document_base64' not in data:continue
 body=base64.b64decode(data['document_base64'],validate=True)
 assert h.sha(body)==data['envelope']['document_sha256']
 templates.append({'file':p.relative_to(r).as_posix(),'revision_id':data['revision_id'],'sha256':h.sha(body),'bytes':len(body),'complete':v['complete'],'text':body.decode('utf-8')})
source=[x for x in a['read_trace'] if '/inputs/source/' in x['input']['file_path'].replace('\\','/')]
value={'source_candidate':a['source_candidate'],'readback':load(o/'opus10-draft-readback.json'),'source_reads':source,
 'source_read_before_authorship':bool(first and source and all(x['result_line']<first and x['returned_error'] is False for x in source)),
 'fixture_assertion_executed':any(' assert-greeting ' in x['input']['command'] for x in a['shell_calls']),
 'identity_command_calls':sum(x['input']['command'].rstrip().endswith(' identity') for x in a['shell_calls']),
 'searches':searches,'empty_searches':sum(x['total_matches']==0 for x in searches),'decodes':decodes,'read_documents':templates,
 'inventory_reads':[x for x in a['read_trace'] if Path(x['input']['file_path']).name=='inventory.json'],
 'schema_views_read':[x['input']['file_path'] for x in a['read_trace'] if '/inputs/schemas/' in x['input']['file_path'].replace('\\','/')],
 'native_report_present':(r/'native-report.md').exists(),'native_observations_present':(r/'native-observations.json').exists(),
 'limits':'These observations require content review of the actual final document and native reports. Draft admission is not a writing-quality verdict or full native qualification.'}
h.write(o/'opus10-review.json',value)
print(json.dumps({k:value[k] for k in ('source_read_before_authorship','identity_command_calls','empty_searches','fixture_assertion_executed','native_report_present')}))
