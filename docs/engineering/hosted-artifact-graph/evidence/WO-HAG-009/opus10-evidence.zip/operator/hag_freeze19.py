import json,os
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
assert h.git('rev-parse','HEAD')=='bf82c761f28fd9a786c1802b445d73eb52aa50e5'
paths=h.git('diff','--name-only').splitlines()+h.git('ls-files','--others','--exclude-standard').splitlines()
expected={'tests/hosted_artifact_graph/native-tools.md','plugins/verity-plane/common/skills/setup/SKILL.md','plugins/verity-plane/common/skills/change/SKILL.md',h.D+'evidence/WO-HAG-009/instruction-discovery-proposal19.md'}
assert set(paths)==expected
index=(h.R/'tests/hosted_artifact_graph/native-tools.md').read_text(encoding='utf-8')
for family,definition in [('remote-v1','Command'),('read-v1','Request')]:
 schema=json.loads((h.R/'server/contracts'/(family+'.json')).read_text())
 for branch in schema['$defs'][definition]['oneOf']:
  name=(branch['allOf'][1] if family=='read-v1' else branch)['properties']['operation']['const']
  assert '`'+name+'`' in index,name
h.run('next19-diff-check',['git','diff','--check'],cwd=h.R)
h.run('next19-plugin-checks',[h.HOST,'-X','utf8','-B','-m','unittest','discover','-s','tests/plugin_integration','-p','test_simple_plugin.py'],cwd=h.R,env=dict(os.environ,PYTHONUTF8='1'))
h.run('next19-stage',['git','add','--',*paths],cwd=h.R)
h.run('next19-commit',['git','commit','-m','Clarify native tool discovery and final draft review','-m','Harness-Work-Order: WO-HAG-009'],cwd=h.R)
h.write(h.O/'improve19-candidate.json',{'commit':h.git('rev-parse','HEAD'),'paths':paths,'tool_index_bytes':len(index.encode()),'request_names_match_original_schemas':True})
assert not h.git('status','--porcelain')
for old,new in [('hag_improve18_build.py','hag_improve19_build.py'),('hag_native_guidance18.py','hag_native_guidance19.py'),('hag_finish_native18.py','hag_finish_native19.py')]:
 text=(h.W/old).read_text(encoding='utf-8').replace('improve18','improve19').replace('guidance18','guidance19').replace('opus09','opus10').replace('native09','native10').replace('package18','package19').replace('build18','build19').replace('client18','client19').replace('18371','18381').replace('18372','18382').replace('10.231.64.0/23','10.231.66.0/23')
 h.write(h.W/new,text)
print(h.git('rev-parse','HEAD'))
