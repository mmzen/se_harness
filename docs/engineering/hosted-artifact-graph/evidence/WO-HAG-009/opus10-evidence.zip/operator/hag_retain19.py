"""Archive the focused test and its exact checked inputs; exclude credentials."""
import json,re,zipfile
from pathlib import Path
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007';out=o/'review19';r=o/'claude/native02/work/opus10';g=o/'claude-guidance19'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert (r/'session.json').exists()
tokens=[x['token'].encode() for p in o.glob('claude-guidance*/credentials.json') for x in load(p)['principals']]
files={}
for name in ('events.jsonl','stderr.txt','session.json','invocation.json','selection.json','task.md','reply-fault.json','native-report.md','native-observations.json','mcp.json','CLAUDE.md'):
 p=r/name
 if p.is_file():files['native/'+name]=p
for sub in ('work','inputs'):
 for p in (r/sub).rglob('*'):
  if p.is_file() and not p.name.endswith(('.whl','.pyc')):files['native/'+p.relative_to(r).as_posix()]=p
for name in ('selection.json','combination.json','stage-evidence.json','native-selection.json','native-task.md','permissions.json','correction-binding.json'):
 files['setup/'+name]=g/name
for pattern in ('next19-*.json','improve19-*.json','runtime-reuse-guidance19.json','build19-replay.json','guidance19-state-*.json','claude-guidance19-version.json','claude-guidance19-auth-probe.json','opus10-*.json'):
 for p in o.glob(pattern):files['checks/'+p.name]=p
for p in (o/'native-parity-guidance19').glob('*.json'):files['independent-mcp/'+p.name]=p
for name in ('hag_native_guidance19.py','hag_finish_native19.py','hag_focus19.py','hag_stage19.py','hag_next19.py','hag_freeze19.py','hag_improve19_build.py','hag_audit19.py','hag_native_parity19.py','hag_assess19.py','hag_retain19.py','hag_prepare19.py','hag_verify_draft19.py','hag_review19.py','hag_report19.py','hag_trace19.py','hag_native_progress19.py'):
 files['operator/'+name]=h.W/name
files['operator/native_call.py']=h.R/'tests/hosted_artifact_graph/native_call.py'
archive=out/'opus10-evidence.zip';inventory=[]
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):
  raw=p.read_bytes();assert not p.is_symlink(),p
  assert not any(t in raw for t in tokens),name
  assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
  assert not any(part in ('.git','credentials.json') for part in Path(name).parts)
  z.writestr(name,raw);inventory.append({'path':name,'bytes':len(raw),'sha256':h.sha(raw)})
h.write(out/'opus10-inventory.json',{'archive':archive.name,'bytes':archive.stat().st_size,'sha256':h.sha(archive.read_bytes()),'files':inventory,'redaction':'Exact native recorder redaction retained. Checked against known private project tokens and provider-token prefixes. Credentials, wheel binaries, Git directories and account stores excluded.'})
print(json.dumps({'files':len(inventory),'archive_bytes':archive.stat().st_size}))
