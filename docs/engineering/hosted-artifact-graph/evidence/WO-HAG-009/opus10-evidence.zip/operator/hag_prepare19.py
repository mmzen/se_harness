"""Prepare a fresh trial with the same task and a compact capability index."""
import json
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007'
candidate=json.loads((o/'improve19-candidate.json').read_text())['commit']
for name in ('hag_audit18.py','hag_native_progress18.py','hag_native_parity18.py','hag_assess18.py','hag_verify_draft18.py'):
 text=(h.W/name).read_text(encoding='utf-8').replace('guidance18','guidance19').replace('opus09','opus10').replace('review18','review19').replace('improve18','improve19').replace('a772ea264c7a68cc456a8af7df2ccf3ea3474947',candidate)
 h.write(h.W/name.replace('18','19'),text)
old=(h.W/'hag_focus18.py').read_text(encoding='utf-8')
old=old.replace('guidance18','guidance19').replace('opus09','opus10')
prefix=old[:old.index("task=f'''")]
tail=old[old.index("h.write(g/'native-task.md',task)"):]
tail=tail.replace("selection['schema_views']='inputs/schemas/FAMILY/OPERATION.json'", "selection['schema_views']='inputs/schemas/FAMILY/OPERATION.json'\nselection['tool_index']=str(inputs/'native-tools.md')")
outcome=(h.W/'hag_focus18.py').read_text().split('## Requested outcome\n\n',1)[1].split('## Entry and file discovery',1)[0]
task='''task=f\'''# Focused hosted drafting diagnostic

You are Claude under the approved WO-HAG-009 qualification test. Work independently
in the fresh private hosted project in SELECTION_FILE. This run tests instruction
discovery during draft preparation only. Git remains authoritative for real work.

## Requested outcome

OUTCOME
## Entry and tools

Read SELECTION_FILE. Begin with the candidate plugin's normal verity-plane:setup
Skill for this explicit hosted selection, then follow its current-task routes.
The client is installed; do not install software or activate a checkout. The
selected released_resources directory contains the exact 0.22.1 procedures.

The selection's tool_index is the single command/file-discovery reference.
Read it before choosing tool syntax. It lists capabilities and exact schema
locations without request values or a workflow sequence. Read only applicable
procedure sections and the schema for the operation you select.

Use native Read/Write/Edit and only the approved_shell_argv_prefix for shell
calls, one helper call per invocation. No scripts, wrappers, pipes, loops, direct
client calls or other shell commands. Normal permissions and hooks apply. Stop
a denied action; do not change permissions or try alternate routes.

Keep every draft, request, result and transient progress note under `{n/'work'}`
using absolute paths. This output directory already exists. Inputs are read-only.
Keep current IDs, versions and exact result paths in the note; after compaction,
recover task, selection, note and original evidence before acting.

Never print credentials, inspect auth stores, change account/host settings or
read prior trials. Authentication is in the process environment. Helpers perform
no hidden workflow; construct your requests from current inputs and instructions.

Finish with native-report.md and native-observations.json at `{n}`. Report actual
reads and triggers, exact evidence/digest sources, draft IDs/paths, findings,
failures and limits. No complete NQ-01--05 claim: lifecycle, MCP parity, reply
recovery and export are outside this focused diagnostic.
\'''
'''.replace('OUTCOME',outcome)
prefix+="h.write(inputs/'native-tools.md',(h.R/'tests/hosted_artifact_graph/native-tools.md').read_bytes())\n"
h.write(h.W/'hag_focus19.py',prefix+task+tail)
compile(prefix+task+tail,'hag_focus19.py','exec')
stage='''import json,subprocess
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007';o=h.O
helper=o/'claude/native02/inputs/native_call.py'
assert helper.read_bytes()==(h.R/'tests/hosted_artifact_graph/native_call.py').read_bytes()
h.write(o/'improve19-helper-binding.json',{'path':str(helper),'sha256':h.sha(helper.read_bytes()),'source_candidate':json.loads((o/'improve19-candidate.json').read_text())['commit'],'scope':'Unchanged helper and fixed prefix; guidance/index correction only.'})
for args in [('hag_native_guidance19.py','state-before'),('hag_native_guidance19.py','setup','claude'),('hag_native_guidance19.py','stage','claude'),('hag_finish_native19.py',),('hag_focus19.py',),('hag_audit19.py','runtime')]:
 subprocess.run([str(h.HOST),'-X','utf8','-B',*args],cwd=h.W,check=True)
assert not h.git('status','--porcelain')
print('Fresh diagnostic staged. Native workflow has not run.')
'''
h.write(h.W/'hag_stage19.py',stage)
print('Prepared Opus10 staging and independent observers.')
