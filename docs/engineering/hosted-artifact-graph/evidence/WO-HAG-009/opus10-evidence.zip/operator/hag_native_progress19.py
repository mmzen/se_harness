import json,collections,time
from pathlib import Path
r=Path(__file__).resolve().parent/'hag-agent-qualification-execution-20261007/claude/native02/work/opus10'
calls=collections.Counter();messages=[];errors=[];outside=[];commands=[];compactions=[];usage={};status=None
for l in (r/'events.jsonl').read_text(encoding='utf-8').splitlines():
 try:e=json.loads(l)
 except ValueError:continue
 if e.get('type')=='system' and 'compact' in e.get('subtype',''):compactions.append({k:e.get('compact_metadata',{}).get(k) for k in ('trigger','pre_tokens','post_tokens','duration_ms')})
 if e.get('type')=='system' and e.get('subtype')=='status':status=e.get('status')
 m=e.get('message',{})
 if isinstance(m,dict) and m.get('usage'):usage=m['usage']
 for b in m.get('content',[]) if isinstance(m,dict) else []:
  if not isinstance(b,dict):continue
  if b.get('type')=='tool_use':
   calls[b['name']]+=1
   if b['name']=='Bash':commands.append(b['input']['command'])
   if b['name'] in ('Write','Edit'):
    p=Path(b.get('input',{}).get('file_path',''))
    if not p.is_relative_to(r/'work') and p not in (r/'native-report.md',r/'native-observations.json'):outside.append(str(p))
  if e.get('type')=='assistant' and b.get('type')=='text':messages.append(b['text'][:1800])
  if b.get('type')=='tool_result' and b.get('is_error'):errors.append(str(b.get('content'))[:200])
results=[]
for p in sorted((r/'work').rglob('*.json'),key=lambda x:x.stat().st_mtime):
 try:
  v=json.loads(p.read_text(encoding='utf-8'));raw=v.get('stdout') if isinstance(v,dict) else None
  q=json.loads(raw) if raw else v
  if isinstance(q,dict) and 'outcome' in q:results.append({'file':p.relative_to(r/'work').as_posix(),'outcome':q['outcome'],'error':q.get('error'),'version':(q.get('versions') or {}).get('project')})
 except (ValueError,UnicodeError):continue
print(json.dumps({'recent_results':results[-3:],'complete':(r/'session.json').exists(),'calls':calls,'recent':messages[-1:],'error_count':len(errors),'last_error':errors[-1:] ,'outside':outside,'shell_calls':len(commands),'last_commands':commands[-3:],'age':round(time.time()-(r/'events.jsonl').stat().st_mtime),'compactions':compactions,'latest_usage':usage,'host_status':status}))
