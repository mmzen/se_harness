import json,os,sys
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
BASE='55caaada508495bea7d97effd27644d1ce8373da'
planned=['tests/hosted_artifact_graph/native-tools.md','plugins/verity-plane/common/skills/setup/SKILL.md','plugins/verity-plane/common/skills/change/SKILL.md',h.D+'evidence/WO-HAG-009/instruction-discovery-proposal19.md']
paths=set(h.git('diff','--name-only',BASE).splitlines())|set(h.git('ls-files','--others','--exclude-standard').splitlines())|set(planned);covered=set()
for ident in ('WO-HAG-009','WO-HAG-010'):
 scopes=h.record(h.D+'work-orders/'+ident+'.md')['execution_scope']['paths'];selected={p for p in paths if any(p==s or s.endswith('/') and p.startswith(s) for s in scopes)}
 args=['check','--artifact',ident,'--checkpoint','scope','--changes-complete']
 for p in sorted(selected):args+=['--changed-path',p]
 h.gov('next19-scope-'+ident,*args,new=True);covered|=selected
assert paths==covered
h.write(h.O/'next19-planned-paths.json',sorted(paths))
