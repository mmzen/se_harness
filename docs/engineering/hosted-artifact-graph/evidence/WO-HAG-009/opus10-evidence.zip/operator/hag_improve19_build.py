import json,os,sys
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007';mode=sys.argv[1]
candidate=json.loads((h.O/'improve19-candidate.json').read_text())['commit']
assert h.git('rev-parse','HEAD')==candidate and not h.git('status','--porcelain')
if mode=='build':
    h.run('improve19-client-build',[h.HOST,'-X','utf8','-B','-m','repository_tools.release_build','replay','--repository',h.R,'--commit',candidate,'--version','0.22.2','--output-directory',h.O/'build19','--result',h.O/'build19-replay.json'],cwd=h.R,timeout=1800)
    wheel=h.W/'hag-phase3-execution-20261006/package02/candidate-source/server/vendor/se_harness-0.22.1-py3-none-any.whl'
    assert h.sha(wheel.read_bytes())=='cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053'
    h.run('improve19-package',[h.HOST,'-X','utf8','-B',h.R/'server/scripts/qualify.py','prepare','--repository',h.R,'--output',h.O/'package19','--client-wheel',h.O/'build19/se_harness-0.22.2-py3-none-any.whl','--client-replay',h.O/'build19-replay.json','--evaluator-wheel',wheel,'--image','harness-hag:native-guidance19','--phase3'],timeout=1800)
    h.run('improve19-client-env',[h.HOST,'-m','venv',h.O/'client19'])
    h.run('improve19-client-install',[h.O/'client19/Scripts/python.exe','-I','-m','pip','install','--no-deps',h.O/'build19/se_harness-0.22.2-py3-none-any.whl'])
elif mode=='checks':
    env=dict(os.environ,PYTHONUTF8='1')
    h.run('improve19-source-suite',[h.HOST,'-X','utf8','-B','scripts/run_tests.py'],cwd=h.R,env=env,timeout=1800)
    h.run('improve19-distributions',[h.HOST,'-X','utf8','-B','scripts/validate_release_distributions.py','--root','.'],cwd=h.R,env=env)
    h.run('improve19-cli-smoke',[h.HOST,'-X','utf8','-B','-m','se_harness','--help'],cwd=h.R,env=env)
else:raise ValueError(mode)
