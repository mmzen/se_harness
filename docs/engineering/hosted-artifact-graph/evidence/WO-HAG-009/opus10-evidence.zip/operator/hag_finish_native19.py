"""Narrow only the session permissions and stage the exact approved criteria."""
import json,subprocess
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007';g=o/'claude-guidance19';native=o/'claude/native02/work/opus10'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
selection=load(g/'native-selection.json');helper=o/'claude/native02/inputs/native_call.py'
source=h.R/h.D/'verification/VER-HAG-007.md';text=source.read_text(encoding='utf-8')
criteria=text[text.index('## Acceptance scenarios'):text.index('## Supporting checks')]
h.write(native/'inputs/verification-criteria.md',criteria)
h.write(native/'inputs/helper-help.txt',subprocess.check_output([h.HOST,'-I',helper,'--help']))
selection['verification_criteria']=str(native/'inputs/verification-criteria.md')
selection['qualification_candidate']=load(o/'improve19-candidate.json')['commit']
selection['qualification_candidate_kind']='Actual source checkpoint for this trial, not a test Git candidate or a completed assurance decision.'
h.write(g/'native-selection.json',selection)
original=load(h.R/h.D/'evidence/WO-HAG-009/claude-permissions-proposed.json')
rules=load(o/'native-permission-quoted-rules.json')
rules['permissions']['allow']=[x for x in rules['permissions']['allow'] if x.startswith(('Bash(','mcp__'))]
path=lambda p:str(p).replace('\\','/').replace('C:','c')
rules['permissions']['allow']+=['Read(//'+path(native)+'/**)','Read(//'+path(helper)+')','Edit(//'+path(native/'work')+'/**)','Edit(//'+path(native/'native-report.md')+')','Edit(//'+path(native/'native-observations.json')+')']
rules['permissions']['deny']+=['Edit(//'+path(native/'inputs')+'/**)','Edit(//'+path(native/'CLAUDE.md')+')']
for previous in native.parent.iterdir():
    if previous.is_dir() and previous!=native:
        rules['permissions']['deny']+=['Read(//'+path(previous)+'/**)','Edit(//'+path(previous)+'/**)']
# dontAsk permits built-in read-only commands. Explicit denials narrow that
# surface; these rules make no claim of a complete shell security boundary.
commands=('ls','cat','echo','pwd','head','tail','grep','find','wc','which','diff','stat','du','cd','git')
for command in commands:
    for prefix in ('','/usr/bin/','/bin/'):
        rules['permissions']['deny'].append('Bash('+prefix+command+' *)')
h.write(g/'permissions.json',rules)
task=(g/'native-task.md').read_text(encoding='utf-8')
task+='''
## Current correction and reporting inputs

Use the candidate skills' hosted reading and context guidance before constructing
lifecycle requests. The exact approved acceptance cases, with their NQ identifiers,
are in the selected verification_criteria file. Read it to identify what evidence
each case needs; it supplies no completed requests or workflow answers.

The fixed helper now also has read-json. It reads one JSON pointer that YOU select
from a saved local result. --keys returns object keys or an array length without
field values. Inspect helper-help.txt or its subcommand help. In Windows Bash, pass --pointer as a shell-quoted JSON string (the subcommand help shows the syntax); a raw leading slash is converted to a filesystem path by that shell. This operation
executes no workflow and computes no lifecycle result. Its returned file hash and
pointer identify the inspected source. Retain complete command results as before.
Use bounded reads and exact fields instead of loading whole historical transcripts.

Keep a compact temporary progress note as described by the candidate guidance.
Use it only to locate original evidence and the evaluator's current procedure.
After compaction, recover task/selection and original results before resuming.
Record the actual instruction reads and their triggers; a hash is not a read.

The qualification_candidate selection field identifies this trial's actual source
checkpoint C. Fixture S and test Git candidate P are different identities; derive
P and hosted baseline B from actual records. Do not replace one with another.
For final reporting, follow the candidate evidence skill and cite exact result
fields. Independent replay is the reviewer's job, not a claim to infer from exports.

Only one fixed-helper call is allowed per Bash invocation. No pipes, echo, wrappers,
directory-listing commands, direct client calls or arbitrary Python. Use native
file tools for files. Extra denials narrow the old built-in read-only shell route.
Stop a denied action; do not switch executables or spellings to evade a denial.
No prior trial, transcript, completed artifact or operator assessment is an input.
'''
h.write(g/'native-task.md',task)
inventory=[{'path':str(p),'relative':p.relative_to(native/'inputs').as_posix(),'bytes':p.stat().st_size,'sha256':h.sha(p.read_bytes())} for p in sorted((native/'inputs').rglob('*')) if p.is_file() and p.name!='inventory.json']
h.write(native/'inputs/inventory.json',{'files':inventory,'note':'Exact staged inputs. Actual native reads and their triggers must be observed separately.'})
h.write(g/'correction-binding.json',{'source_candidate':selection['qualification_candidate'],'criteria_source':str(source),'criteria_source_sha256':h.sha(source.read_bytes()),'criteria_excerpt_sha256':h.sha(criteria.encode()),'task_sha256':h.sha(task.encode()),'effective_rules_sha256':h.sha((g/'permissions.json').read_bytes()),'helper_sha256':h.sha(helper.read_bytes()),'permission_change':'Only narrowing: current trial file area, prior trials read-denied, explicit denials for built-in read-only shell commands. Same fixed helper prefix and seven read-only MCP grants.','interventions':'Before-run packaged instruction and helper correction; exact criteria/identities/paths supplied. No workflow sequence, chosen artifacts, completed requests or operator lifecycle mutations.'})
print('Staged exact criteria, bounded reader help and narrowed session permissions.')
