# Native report — opus10 focused drafting diagnostic

## Task

Prepare exactly one new intent draft (INT-P3-001) in the hosted sandbox
to establish that the existing fixture's `greeting()` returns exactly
`Hello rehearsal`. Domain: lifecycle-pilot. Owner: test-owner.

## Fixture inspection

Source file: `src/greeting.py` (inventory relative: `source/src/greeting.py`)

```python
def greeting():
    return 'Hello rehearsal'
```

- Inventory SHA-256: `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`
- Matches `selection.json` field `greeting_sha256`
- Method: source inspection via native Read tool

## Instruction reads

1. **selection.json** — hosted sandbox selection, endpoint, project, tool index
2. **inputs/native-tools.md** — tool index: helper operations and schema locations
3. **inputs/combination.json** — qualified combination with component digests
4. **plugin/verity-plane/skills/setup/SKILL.md** — hosted sandbox selection procedure
5. **plugin/verity-plane/skills/change/SKILL.md** — hosted reading and drafting procedure
6. **released-resources/docs/engineering/harness/DRAFT_DEFINITIONS.md** — draft definitions procedure (Read this when, Before this action, Draft any missing definitions)
7. **released-resources/docs/engineering/ARTIFACT_AUTHORING.md** — design simplicity principle and intent checklist
8. **schemas/remote-v1/draft-open.json** — draft-open request schema
9. **schemas/remote-v1/create-artifact.json** — create-artifact request schema
10. **schemas/remote-v1/revise-artifact.json** — revise-artifact request schema
11. **schemas/read-v1/revision.json** — revision read request schema
12. **inputs/source-manifest.json** — source manifest for import
13. **schemas/remote-v1/import.json** — import request schema
14. **inputs/client-help/create-artifact.txt** — CLI help for remote commands
15. **inputs/inventory.json** — full input inventory

## Operations and evidence

### 1. Wheel identity verification
- Helper: `identity`
- Wheel SHA-256: `3cafe5e9226389f563bdf170e6c668217b912ff933462699e24be70e8d5a5685`
- Matches combination.json `client.wheel_sha256`

### 2. Service status
- Helper: `remote status`
- Record: `work/status-record.json`
- Ready: true
- Authority mode: sandbox-projection
- All component identities match combination report
- Project version: 0

### 3. Import (opus10-import-001)
- Request: `work/import-request.json`
- Record: `work/import-record.json`
- Outcome: accepted (HTTP 200)
- Baseline: `se-harness-artifact-baseline/v1:sha256:caeeb61861f4779a1ebbbde8124437eb65ec5ac37b6cab72b0a5adb1a140c664`
- Project version: 0 → 1
- 7 artifacts imported; evaluator valid (0 errors, 1 advisory W-AUT-022)
- Receipt: `13f2bc36-7a22-4de0-996e-9830663f9a6d`

### 4. Draft-open (opus10-draft-open-001)
- Request: `work/draft-open-request.json`
- Record: `work/draft-open-record.json`
- Outcome: accepted (HTTP 200)
- Context ID: `786d5290-331c-4dfb-9aba-d20bbe0a1656`, version 0
- Project version: 1 → 2
- Instruction discovery: status = available
- Receipt: `3c486806-a7a5-4b7a-8045-a63933571bdc`

### 5. Create-artifact (opus10-create-intent-001)
- Request: `work/create-intent-request.json`
- Record: `work/create-intent-record.json`
- Outcome: accepted (HTTP 200)
- Artifact: INT-P3-001 (intent, draft) at `docs/engineering/lifecycle-pilot/intent/INT-P3-001.md`
- Template revision: `sha256:6aae37dcbdfb0751c35941f02782db22bad72c31a3d0fd8e7cb8e8c59b9aa863`
- Admissible: true; 10 incomplete fields (template placeholders)
- Context version: 0 → 1, project version: 2 → 3
- Receipt: `05a2365b-c922-4ce0-9c13-3dfeebdd4f65`

### 6. Template read
- Read request: `work/read-intent-request.json`
- Record: `work/read-intent-record.json`
- Decoded template via `--decode-base64`; confirmed all canonical placeholders

### 7. Revise-artifact (opus10-revise-intent-001)
- Request: `work/revise-intent-request.json`
- Record: `work/revise-intent-record.json`
- Outcome: accepted (HTTP 200)
- Final revision: `sha256:b12401f014deae58ac2af0e0634b116e7c68d94fe30a8c1ffcda0dc680291151`
- Document SHA-256: `526749ab08ee31e1d14b8d8b8365f4d00470a0cd6955ce5f0eb841ec9cce8cdf`
- Admissible: true; 0 errors; 0 incomplete
- 1 background advisory (W-AUT-022 on SPEC-P3-900, pre-existing)
- Context version: 1 → 2, project version: 3 → 4
- Receipt: `fa159759-4395-4d6a-a044-75a3973db177`

### 8. Read-back verification
- Request: `work/read-intent-final-request.json`
- Record: `work/read-intent-final-record.json`
- Confirmed document_sha256 matches encoded document
- All placeholders replaced; content matches authored draft

## Draft review against intent checklist

| Checklist item | Status |
| --- | --- |
| Explain the present problem, who it affects, and the outcome wanted | Done: Problem section describes the need for traceability; outcome field states the observable result |
| What is the smallest useful outcome, and which needs and constraints are actually agreed? | Done: confirming greeting() returns exactly "Hello rehearsal" is the minimal agreed outcome |
| Say how the owner will know the change helped; an honest baseline may be not measured | Done: success measures table with "not measured" baseline, target condition, and observation method |
| State the important scope limits | Done: "Not this" section lists 3 explicit exclusions |

## Source claim verification

The intent claims greeting() returns "Hello rehearsal". Source inspection of
`src/greeting.py` confirms `return 'Hello rehearsal'` on line 2. The file's
inventory SHA-256 matches `selection.json`'s `greeting_sha256`.

## Failures and denied calls

None. All operations returned outcome: accepted.

## Limits

- This is a focused drafting diagnostic only.
- No lifecycle decisions exercised (no approve, freeze, start, complete, verify, release).
- No MCP parity testing, reply recovery testing, or export testing.
- No complete NQ-01 through NQ-05 claim.
- Imported -900 records are immutable history; not modified.
- The sandbox is test data under rehearsal-only authority; Git remains authoritative for real work.
