# Focused hosted drafting diagnostic

You are Claude under the approved WO-HAG-009 qualification test. Work independently
in the fresh private hosted project in C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus10\selection.json. This run tests instruction
discovery during draft preparation only. Git remains authoritative for real work.

## Requested outcome

Prepare exactly one new intent draft for an operator who needs to establish that
the existing fixture's greeting() returns exactly `Hello rehearsal`. Inspect the
fixture and author the intent in the selected private service. Keep it as draft
and report its actual authoring findings. Use domain lifecycle-pilot and synthetic
owner test-owner. Imported -900 records are immutable history. Do not create other
artifacts, approve anything, start work, freeze a baseline or exercise lifecycle
decisions. Stop when this one draft is complete and its current findings retained,
or report the exact blocker. This is a focused diagnostic, not a full package.


## Entry and tools

Read C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus10\selection.json. Begin with the candidate plugin's normal verity-plane:setup
Skill for this explicit hosted selection, then follow its current-task routes.
The client is installed; do not install software or activate a checkout. The
selected released_resources directory contains the exact 0.22.1 procedures.

The selection's tool_index is the single command/file-discovery reference.
Read it before choosing tool syntax. It lists capabilities and exact schema
locations without request values or a workflow sequence. Read only applicable
procedure sections and the schema for the operation you select.

Use native Read/Write/Edit and only the approved_shell_argv_prefix for shell
calls, one helper call per invocation. No scripts, wrappers, pipes, loops, direct
client calls or other shell commands. Normal permissions and hooks apply. Stop
a denied action; do not change permissions or try alternate routes.

Keep every draft, request, result and transient progress note under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus10\work`
using absolute paths. This output directory already exists. Inputs are read-only.
Keep current IDs, versions and exact result paths in the note; after compaction,
recover task, selection, note and original evidence before acting.

Never print credentials, inspect auth stores, change account/host settings or
read prior trials. Authentication is in the process environment. Helpers perform
no hidden workflow; construct your requests from current inputs and instructions.

Finish with native-report.md and native-observations.json at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus10`. Report actual
reads and triggers, exact evidence/digest sources, draft IDs/paths, findings,
failures and limits. No complete NQ-01--05 claim: lifecycle, MCP parity, reply
recovery and export are outside this focused diagnostic.
