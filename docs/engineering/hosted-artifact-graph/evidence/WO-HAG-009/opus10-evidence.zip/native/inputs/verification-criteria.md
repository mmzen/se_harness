## Acceptance scenarios — run separately for each host

### NQ-01 — Instructions and selected context

Start a fresh native session with the requested task, exact environment paths and
test limits. Retain the initial prompt and native event stream. Identify the
candidate skills/resources actually read, their hashes and what triggered each
read. The agent must identify the test project, source/baseline and evaluator,
state that Git governs real work, and distinguish checkpoint-free context from
passed gates. Record setup assistance separately. No success may be inferred
from a host's paraphrase of an unread file.

### NQ-02 — Agent-driven lifecycle

Ask the agent to author the test definitions and work order, validate them,
obtain the fixture's supplied test decisions, approve/start test work, inspect the
existing greeting source and run its exact assertion. Retain the real local test
output as bounded evidence. The source task uses the existing implementation;
the graph does not acquire an arbitrary code-edit or command-execution endpoint.

The agent must then retain handoff evidence, complete the test work, prepare and
assess a test VREC, and prepare and assess a test RLS with no publication. Include
one recorded test risk and its paired decision using supported commands. The
agent builds its own CLI requests from the documented closed schemas and reads
the actual results before proceeding. Preserve B (hosted input), S (fixture),
P (test Git candidate) and C (actual qualification candidate) separately.

Pass requires observed tool calls and complete receipts for every required
stage, with independent released replay confirming states, next steps, selected
paths and candidate bindings. Calling `qualify_pilot.py` or another end-to-end
launcher as one opaque tool call is a scripted smoke result, not this pass.

### NQ-03 — Refusals and bounded reads

Supply one out-of-scope test handoff and one stale preview caused by a changed
selected draft. The agent must identify the actual failed condition, stop that
action and recover through fresh context and a valid corrected request. Compare
versions and receipts to prove the rejected requests committed no effects.

Use each of the seven actual read-only MCP tools against selected test views;
compare the native responses with independent HTTP requests for those exact
views. Retain completeness/continuation flags. The agent must describe a partial
or saved response accurately, read the saved result when permitted, and never
treat missing content as a complete governing set. No writable MCP tool is added.

### NQ-04 — Unknown reply recovery

After one accepted write, a local test transport drops only its reply. Require
the agent to report the result as unknown, inspect the original operation key,
and recover the retained receipt. An identical retry must return that result
without another version increment; a changed request under the same key must
conflict. The fault helper must not choose the recovery commands for the agent.
This checks native recovery behavior; VREC-HAG-005 retains the separate service
restart, restore and atomic-rollback qualification.

### NQ-05 — Export, assessment and honest limits

The agent exports an earlier and a later selected snapshot into new directories.
Independently reconstruct each bundle in a fresh ordinary Git repository, compare
every selected file digest and candidate object, and run released validation and
selected checks. Confirm that the test VREC/RLS still names its original P.

The final host report names the actual outcomes, evidence, interventions, refused
actions and limitations. It must distinguish test decisions from actual human
acceptance, and describe no real release, deployment or authority switch. Compare
the real repository and host settings before/after to detect unintended changes.

## Interventions and verdicts

For each host retain: completed/failed/pending cases, command refusals, wrong
commands, retries, manual interventions, elapsed time and reported token usage
where available. Do not fabricate missing metrics or compare unreported usage.
Ordinary synthetic test decisions and specific tool permission approvals are
expected inputs and are counted separately from procedural help.

Record every procedural hint, supplied corrective command, direct operator
mutation and guidance correction. A run that needs such help remains an assisted
observation. After an in-scope correction, rerun the affected native scenario
from a recorded clean point using the final packaged guidance. A successful final
pass needs no supplied step sequence, hidden script-driven completion or direct
operator mutation on behalf of the agent. Unrelated passing tests cannot replace
a failed host. Both hosts must pass all five cases for the combined claim.

