# Disposable qualification task inputs

Read `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus10\task.md` and `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus10\selection.json` before acting,
including after compaction. They retain the task, selected inputs and tool boundary.
Use the selected candidate plugin skills and their required references for the workflow.
This file supplies no lifecycle procedure or new permission.

The existing approved shell prefix is this argument array:

```json
["C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe", "-I", "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-agent-qualification-execution-20261007/claude/native02/inputs/native_call.py"]
```

Use one helper command per Bash call. Do not add a pipeline, a second
command (including echo), a shell wrapper or arbitrary Python. The tool
result already reports the exit status. Use native Read/Write/Edit tools
for files, including retained results. These are the existing tool limits.
