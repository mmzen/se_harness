"""Read-only reproduction of JSON-pointer argument conversion; no native intervention."""
import json,os,subprocess,shlex
from pathlib import Path
W=Path(__file__).parent;O=W/'hag42';bash=Path('C:/Program Files/Git/bin/bash.exe')
assert bash.is_file()
probe=O/'argv-probe.py';probe.write_bytes(b'import json,sys;print(json.dumps(sys.argv[1:]))\n')
python='C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe'
command=' '.join(map(shlex.quote,[python,'-I',probe.as_posix(),'--pointer','/native_failures']))
rows=[]
for setting in (None,'1'):
 env=dict(os.environ)
 if setting is None:env.pop('MSYS_NO_PATHCONV',None)
 else:env['MSYS_NO_PATHCONV']=setting
 cp=subprocess.run([str(bash),'--noprofile','--norc','-c',command],cwd=O,env=env,capture_output=True,text=True,encoding='utf-8')
 rows.append({'argv':[str(bash),'--noprofile','--norc','-c',command],'cwd':str(O),'MSYS_NO_PATHCONV':setting,'exit':cp.returncode,'stdout':cp.stdout,'stderr':cp.stderr})
assert rows[0]['exit']==rows[1]['exit']==0
assert json.loads(rows[0]['stdout'])!=['--pointer','/native_failures']
assert json.loads(rows[1]['stdout'])==['--pointer','/native_failures']
f=O/'msys-pointer-reproduction.json';assert not f.exists();f.write_bytes((json.dumps({'observations':rows,'limits':'Separate process-only mechanical argument probe. No provider run, permission change, source edit or qualification pass. Original failures remain.'},indent=2)+'\n').encode())
print(json.dumps(rows))
