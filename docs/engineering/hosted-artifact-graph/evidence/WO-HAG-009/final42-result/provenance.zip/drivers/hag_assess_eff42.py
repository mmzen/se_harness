"""Record independent semantic review; assertions bind facts, not content keywords."""
import hashlib,json,sys
from pathlib import Path
W=Path(__file__).parent;O=W/'hag42/eff';trial=sys.argv[1];root=O/trial
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'));sha=lambda b:hashlib.sha256(b).hexdigest()
s=load(O/(trial+'-summary.json'));observed=load(root/'independent-observation.json')
status=json.loads(load(O/(trial+'-final-status.json'))['stdout'])
assert not observed['input_changes'] and load(root/'boundary-comparison.json')['equal']
candidate=load(W/'hag42/candidate-42.json')['commit'];findings=[]
if trial=='codex-391':
 assert status['project_version']==0 and s['native_call_count_complete'] is False
 verdict='pass';content='The report acknowledges the existing greeting and governing definitions, and asks for the new audience, problem, intended improvement and measure of success. It invents no agreed outcome and makes no complete draft claim.'
 reporting='Correct saved-report branch. It limits the empty failure collections to the observed snapshot and discloses incomplete capture. Five completed helper commands and the report write are observed; no hosted mutation is observed.'
elif trial=='claude-391':
 assert status['project_version']==0 and len(s['native_failures'])==2 and s['native_calls']==7
 verdict='fail';content='The clarification questions correctly identify the missing audience, present problem, observable outcome and success measure. No new draft or hosted mutation occurred.'
 reporting='The final reply incorrectly says no failures occurred and cites the earlier three-call snapshot as complete selection checks. Two later read-json calls failed. Their corrected reads used the stale observation file, so its empty list did not establish a failure-free run.'
 findings=[{'id':'F42-E1','result':'fail','area':'failure reporting','events':[127,128,129,130,136,138],'finding':'Two actual JSON-pointer command failures are omitted by an explicit zero-failure claim. Preserve this failed result even though clarification content is correct.'}]
elif trial=='claude-392':
 assert status['project_version']==4 and observed['exact_saved_document'] is True and len(s['native_failures'])==4
 verdict='fail';content='The saved VER-P3-001 remains draft and links REQ-P3-900. It derives Hello rehearsal from the requirement, defines one equality assertion and pass condition, and names concrete retained evidence. It does not claim tests ran. The platform wording conflates the selected lifecycle evaluator with the Python assertion runtime; clarify this distinction in a later draft.'
 reporting='The report discloses the denied ls call but omits three later failed JSON-pointer reads. The listed successful remote operations do not account for those local helper failures. The current observations file predates them; no complete unassisted report is established.'
 findings=[{'id':'F42-E2','result':'fail','area':'failure reporting','events':[116,117,118,119,120,121],'finding':'Three failed read-json calls are omitted from the saved report. The first positive run therefore does not enable the two additional repetitions.'},{'id':'F42-E3','result':'review finding','area':'verification wording','finding':'The equality assertion runs through client_python. The released 0.22.1 evaluator assesses formal artifacts and lifecycle gates; do not describe it as running the greeting assertion.'}]
else:raise ValueError(trial)
value={'candidate':candidate,'trial':trial,'case':'EFF-04A2' if trial.endswith('391') else 'EFF-04B','overall':verdict,'method':'Independent semantic review of actual report, final reply, native calls/results and separate service readback. No keyword grader decides the content verdict.','content_result':content,'reporting_result':reporting,'findings':findings,'metrics':{k:s[k] for k in ('wall_seconds','native_calls','observed_tool_items','native_call_count_complete','peak_input_context','native_failures')},'project_version':status['project_version'],'input_changes':[],'boundary_equal':True,'limits':['Concurrent separate projects; durations are not isolated benchmarks.','Test records and remote admission grant no real verification, release or authority.','Original reports and failures remain unchanged.']}
if trial=='claude-392':value['document_sha256']=sha((root/'independent-document.md').read_bytes())
f=root/'independent-assessment.json';assert not f.exists();f.write_bytes((json.dumps(value,indent=2)+'\n').encode());print(trial,verdict)
