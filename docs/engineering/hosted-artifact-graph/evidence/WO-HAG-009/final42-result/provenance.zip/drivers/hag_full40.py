"""Fresh full native qualification, reusing the exact C38 packages."""
import hashlib,json,subprocess,sys
from pathlib import Path
import hag_efficiency_plan as p
W=p.W;O=W/'hag-final40-20261012';P=W/'hag-authority38-20261012'
C='ee86a842550c19fb6a56913841757b42df9ecaec';REVIEW='dfeb5adf1f640dea48a53b7a446e49e93c31004a'
trial='361';mode=sys.argv[1];host=sys.argv[2]
root=O/(host+'-'+trial);native=root/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=p.R).decode().strip()==REVIEW
assert not subprocess.check_output(['git','status','--porcelain'],cwd=p.R).decode().strip()
assert not subprocess.check_output(['git','diff','--name-only',C,REVIEW,'--','se_harness','tests','plugins','server','templates','pyproject.toml','repository_tools','release'],cwd=p.R).decode().strip()
assert load(P/'candidate-38.json')['commit']==C
source=(W/'hag_full27.py').read_text()
source=source.replace('hag-lifecycle-native27-20261010','hag-final40-20261012').replace('hag-lifecycle-correction27-20261010','hag-authority38-20261012')
source=source.replace("trial='221'","trial='361'").replace("host+'-221-boundary-probe.json'","host+'-361-boundary-probe.json'")
for a,b in [('candidate-27','candidate-38'),('package27','package38')]:source=source.replace(a,b)
source=source.replace("==load(PREV/'candidate-38.json')['commit']","=='"+REVIEW+"'")
nested="(W/'hag_native27.py').read_text()"
replacement=nested+".replace('hag-lifecycle-native27-20261010','hag-final40-20261012').replace('hag-lifecycle-correction27-20261010','hag-authority38-20261012').replace('package27','package38').replace('client27','client38').replace('build27','build38').replace('native-lifecycle27','native-authority38').replace('hag-full27-','hag-final40-').replace('10.231.84.0/22','10.231.108.0/22')"
source=source.replace(nested,replacement)
source=source.replace('claude-opus-4-6','claude-opus-5-5').replace(r'C:\Users\mathi\.local\bin\claude.exe',str(W/'hag-opus55-availability-20261011/claude-2.1.280.exe'))
source=source.replace("'--timeout','1800'","'--timeout','3600'")
source=source.replace("host+'-version'","host+'-version2'").replace("host+'-live-probe'","host+'-live-probe2'").replace("host+'-auth'","host+'-auth2'").replace("host+'-auth-review.json'","host+'-auth-review2.json'").replace("host+'-live-probe.json'","host+'-live-probe2.json'")
exec(compile(source,'full40-native','exec'),{'__file__':str(W/'hag_full27.py'),'__name__':'__main__'})
if mode=='stage':
 selection=load(root/'native-selection.json');inv=load(native/'inputs/inventory.json')['files']
 assert all(sha(Path(x['path']).read_bytes())==x['sha256'] for x in inv)
 for f in ('native_call.py','summarize_native.py'):
  assert (native/'inputs'/f).read_bytes()==subprocess.check_output(['git','show',C+':tests/hosted_artifact_graph/'+f],cwd=p.R)
 assert selection['qualification_candidate']==C
 proof=load(root/'stage-evidence.json');proof.update(review_head=REVIEW,staged_input_count=len(inv),full_task_retained=True,model='claude-opus-5-5' if host=='claude' else 'CLI selected; record actual model',package_comparison_sha256=sha((P/'package-guidance-comparison.json').read_bytes()),service_comparison_sha256=sha((P/'service-reuse-comparison.json').read_bytes()))
 (root/'stage-evidence.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
 print(host,'exact package, helper and input identities confirmed')
