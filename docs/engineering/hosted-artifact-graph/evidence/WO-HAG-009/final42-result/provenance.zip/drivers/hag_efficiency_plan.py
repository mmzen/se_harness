from pathlib import Path
import json, subprocess, sys, time, hashlib

W=Path(__file__).parent
R=W/'hag221proposal'
P=Path(r'C:\Users\mathi\.codex\plugins\data\verity-plane-se-harness\evaluators\0.22.1\cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053\Scripts\python.exe')
RES=P.parent.parent/'share/se-harness/templates/repository/standard'
O=W/'hag-efficiency-proposal-20261008'
O.mkdir(exist_ok=True)
D=R/'docs/engineering/hosted-artifact-graph'

def run(label,args,allowed=(0,),cwd=W):
    dest=O/(label+'.json')
    if dest.exists(): raise RuntimeError('Log already exists: '+str(dest))
    start=time.monotonic()
    p=subprocess.run([str(x) for x in args],cwd=cwd,capture_output=True,encoding='utf-8',errors='replace')
    record=dict(argv=[str(x) for x in args],cwd=str(cwd),exit=p.returncode,elapsed_seconds=time.monotonic()-start,stdout=p.stdout,stderr=p.stderr)
    dest.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if p.returncode not in allowed: raise RuntimeError(f'{label}: exit {p.returncode}; see {dest}')
    try: return json.loads(p.stdout)
    except json.JSONDecodeError: return record

def gov(label,*args,allowed=(0,)):
    return run(label,[P,'-I','-m','se_harness',*args],allowed)

def section(path,heading):
    lines=path.read_text(encoding='utf-8').splitlines()
    start=next(i for i,s in enumerate(lines) if s.lstrip('# ').casefold()==heading.casefold() and s.startswith('#'))
    level=len(lines[start])-len(lines[start].lstrip('#'))
    end=next((i for i in range(start+1,len(lines)) if lines[i].startswith('#') and len(lines[i])-len(lines[i].lstrip('#'))<=level),len(lines))
    return '\n'.join(lines[start:end])

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='instructions':
        for name,head in [
            ('harness/ARTIFACTS.md','Artifact types'),
            ('harness/DEFINITION_LINKS.md','Links between definitions'),
            ('harness/DRAFT_DEFINITIONS.md','Draft any missing definitions'),
            ('harness/DRAFT_DEFINITIONS.md','Define how the result will be verified'),
            ('harness/DRAFT_WORK_ORDERS.md','Prepare work orders (WO) linking the definitions, scope, planned work, and verification requirements'),
            ('ARTIFACT_AUTHORING.md','Design simplicity'),
            ('ARTIFACT_AUTHORING.md','requirement'),
            ('ARTIFACT_AUTHORING.md','specification'),
            ('ARTIFACT_AUTHORING.md','verification'),
            ('ARTIFACT_AUTHORING.md','work_order')]:
            p=RES/'docs/engineering'/name
            print(str(p)+'\n'+section(p,head)+'\n')
    elif mode=='inspect':
        x=gov('inspect','inspect',R,'--json')
        print(json.dumps({k:v for k,v in x.items() if k in ('summary','errors','warnings','valid','schema','domains')},indent=2))
    elif mode=='create-preview':
        x=gov('preview-'+sys.argv[2],'create-artifact',R,'--domain','hosted-artifact-graph','--type',sys.argv[2],'--dry-run','--json')
        print(json.dumps(x,indent=2))
    elif mode=='create':
        x=gov('create-'+sys.argv[3],'create-artifact',R,'--domain','hosted-artifact-graph','--type',sys.argv[2],'--id',sys.argv[3],'--json')
        print(json.dumps(x,indent=2))
    elif mode=='validate':
        x=gov('validate-'+sys.argv[2],'validate',R,'--json',allowed=(0,1,2))
        print(json.dumps({k:v for k,v in x.items() if k not in ('findings','artifacts')},indent=2)[:5000])
        print(json.dumps([v for v in x.get('findings',[]) if v.get('severity')=='error'],indent=2))
    elif mode=='plan':
        import tomllib
        wo=D/'work-orders/WO-HAG-011.md'
        meta=tomllib.loads(wo.read_text(encoding='utf-8').split('+++')[1])
        planned=[p for p in meta['execution_scope']['paths'] if not p.endswith('/')]
        planned += [
            'tests/hosted_artifact_graph/native_call.py','tests/hosted_artifact_graph/native-tools.md',
            'tests/hosted_artifact_graph/qualify_agents.py','tests/hosted_artifact_graph/assess_native.py',
            'tests/hosted_artifact_graph/test_native_support.py',
            'plugins/verity-plane/common/skills/setup/SKILL.md',
            'plugins/verity-plane/common/skills/setup/references/hosted-context.md',
            'plugins/verity-plane/common/skills/change/SKILL.md',
            'plugins/verity-plane/common/skills/change/references/hosted-drafts.md',
            'plugins/verity-plane/common/skills/change/references/hosted-test-lifecycle.md',
            'plugins/verity-plane/common/skills/evidence/SKILL.md',
            'plugins/verity-plane/common/skills/evidence/references/hosted-evidence.md',
            'plugins/verity-plane/common/skills/harness-orient/references/hosted-reads.md',
            'docs/engineering/hosted-artifact-graph/evidence/WO-HAG-011/preparation-review.md',
            'docs/engineering/hosted-artifact-graph/evidence/WO-HAG-011/preparation-checks.json',
        ]
        args=['check',R,'--artifact','WO-HAG-011']
        for path in planned: args += ['--planned-path',path]
        x=gov('plan-'+sys.argv[2],*args,'--json',allowed=(0,1,2))
        prep=x.get('scope',{}).get('preparation',{})
        print(json.dumps({'scope_preparation':{k:v for k,v in prep.items() if k not in ('explicit_matches','planned_paths')},'planned_path_count':len(prep.get('planned_paths',[])), 'restitution':x.get('restitution')},indent=2))
    elif mode=='review':
        evidence=D/'evidence/WO-HAG-011'
        evidence.mkdir(exist_ok=True)
        def kept(name,keys):
            record=json.loads((O/(name+'.json')).read_text(encoding='utf-8'))
            value=json.loads(record.pop('stdout'))
            record['result_fields']={k:value[k] for k in keys if k in value}
            record['selection_notice']='Selected exact result fields; artifact inventories and unrelated warning bodies omitted. Counts retained.'
            return record
        artifacts={}
        for rel in ['requirements/REQ-HAG-014.md','specifications/SPEC-HAG-008.md','verification/VER-HAG-008.md','work-orders/WO-HAG-011.md']:
            raw=(D/rel).read_bytes()
            artifacts[rel]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'state':'draft','proposed_state':'approved'}
        checks={
            'selected_evaluator':'0.22.1','reviewed_artifacts':artifacts,
            'validation':kept('validate-02',['valid','artifact_count','error_count','warning_count','errors','advisory_count','advisories','plane_counts']),
            'planned_scope':kept('plan-01',['selection','scope','restitution']),
            'approval_readiness':kept('approval-readiness-01',['selection','compliance','findings','restitution']),
            'earlier_attempt':{'validation_advisories':6,'cause':'Coverage parser did not recognize rule identifiers in headings. Replaced headings with the canonical bold rule-label form; validate-02 has no advisories.'},
            'not_performed':['implementation','runtime tests','native reruns','approval or start transition','push or PR update'],
        }
        (evidence/'preparation-checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        review='''# Review: simpler and faster hosted authoring

## Decision requested

Approve implementation and review publication for **WO-HAG-011**, with required
commit-bound verification under **VER-HAG-008**, and approve **REQ-HAG-014** and
**SPEC-HAG-008**. All four records are currently draft. Accountable human: mmzen.

The existing WO-HAG-009 explicitly excludes new client behavior. The new package
adds that scope; it does not repeat or replace the existing work approvals.

## Useful outcome

An agent receives the applicable instructions, writes one document file and
submits it through the existing client. The client handles transport formatting
and retains full evidence while returning concise useful results. This addresses
the 11-minute, 56-call, 112,326-token one-intent diagnostic.

## Changes and verification

| Problem | Change | Evidence |
| --- | --- | --- |
| Instructions too long | Short skill entry points, selected route references and canonical section views | Source/section identity comparison and native read trace |
| Content repeated | One owner per rule; document files and compact result fields; full evidence stored once | Exact byte and result comparison |
| Too many calls and excessive duration | Typed existing operations, mechanical encoding/capture and useful returned fields | Same-task Claude runs and an affected Codex run, with actual calls and timings |

Experimental goals: under 3 minutes, at most 15 calls and under 40,000 peak input
tokens for the same fresh-project task. Record each goal separately from correctness.
Start with one Claude diagnostic; repeat twice only after a correct unassisted run,
then exercise Codex. Missed goals, provider limits and incorrect content stay visible.

No server, wire-schema, lifecycle-policy, template-meaning or authority change is
included. No new dependency, orchestration service or KIS gate. The full existing
VER-HAG-007 qualification remains pending and is not replaced by this diagnostic.

## What approval permits

Bounded local client/instruction implementation, ordinary checks, disposable
package builds, authorized native CLI tests and preparation of a verification
record bound to the exact candidate. Verification acceptance stays with mmzen.

The proposed publication grant covers ordinary pushes and updates to draft PR
#543 in mmzen/se_harness, from codex/hosted-agent-qualification to main, including
this package, its evidence, ready verification record and the later separately
supplied verification-decision commit. Keep the PR draft while existing full
qualification is incomplete. No merge, force-push, release, adoption or host update.

## Checks and pending input

- Released 0.22.1 validation: **1,991 artifacts, zero errors, zero authoring
  advisories**; 63 existing warnings outside this package remain.
- Planned scope: **35 paths covered**, no uncovered paths or invalid declarations.
  This checks the supplied plan; it is not proof that implementation cannot expose
  an additional dependency.
- Work-authorization graph, integrity and decision predicates pass.
- Approval is currently blocked by **QGS-ASSURANCE**: the human has not yet
  confirmed required commit-bound verification for this newly prepared work order.
  The requested package approval includes this classification; record it before
  the approval preview/apply. No decision field has been fabricated.
- Exact evaluator next step: **PROC-FOCUS-SELECTED / STEP-FOCUS-SELECTED**,
  supply the corrective input for QGS-ASSURANCE.
- No implementation, native run or lifecycle transition was performed for this
  package. Earlier qualification results and historical evidence remain unchanged.

## Review files

- [REQ-HAG-014](../../requirements/REQ-HAG-014.md)
- [SPEC-HAG-008](../../specifications/SPEC-HAG-008.md)
- [VER-HAG-008](../../verification/VER-HAG-008.md)
- [WO-HAG-011](../../work-orders/WO-HAG-011.md)
- [Checks and exact reviewed file digests](preparation-checks.json)

The package reuses INT-HAG-002 and CAP-HAG-002. It applies the existing KIS policy
to the entire agent task, including user effort and duration. New architecture,
risk-acceptance and decision records are unnecessary for this bounded adaptation.
Existing RISK-HAG-001/002 receive only affected-work links; their states and
history are preserved.
'''
        (evidence/'preparation-review.md').write_text(review,encoding='utf-8')
        print(json.dumps({'review':str(evidence/'preparation-review.md'),'reviewed_artifacts':artifacts},indent=2))
