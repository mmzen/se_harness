"""Retain completed C42 observations; never convert a failed or out-of-order run."""
import hashlib,json,re,sys,zipfile
from pathlib import Path
import hag_efficiency_plan as p
W=p.W;O=W/'hag42';mode=sys.argv[1]
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
groups=[('full','WO-HAG-009','final42-result',['claude-381','codex-381']),('eff','WO-HAG-011','focused42-result',['claude-391','codex-391','claude-392'])]
if mode=='scope':
 p.O=O
 for group,wo,name,trials in groups:
  names=['assessment.md','provenance.zip','provenance-inventory.json']+[t+s for t in trials for s in ('-evidence.zip','-visible.md','-inventory.json')]
  paths=[(p.D/'evidence'/wo/name/n).relative_to(p.R).as_posix() for n in names]
  v=p.gov(name+'-scope','check',p.R,'--artifact',wo,'--checkpoint','scope','--changes-complete',*[x for path in paths for x in ('--changed-path',path)],'--json')
  assert v['compliance']['status']=='pass';print(name,'scope pass',flush=True)
elif mode=='retain':
 for group,wo,name,trials in groups:
  assert json.loads(load(O/(name+'-scope.json'))['stdout'])['compliance']['status']=='pass'
  E=p.D/'evidence'/wo/name;E.mkdir(exist_ok=False)
  source=(W/'hag_retain36.py').read_text().replace('hag-procedure36-20261011','hag42/'+group).replace('WO-HAG-009/procedure36-result',wo+'/'+name)
  source=source.replace('replay36','replay42').replace('native-parity-*36','native-parity-*42')
  source=source.replace("names=['initial-status.json'", "names=['input-content-proof.json','persisted-instruction-recovery.json','initial-status.json'")
  source=source.replace('extra="""for directory', 'extra="""for f in (root/\'persisted-instructions\').glob(\'*.txt\'):\n files[\'assessment/persisted-instructions/\'+f.name]=f.read_bytes()\nfor directory')
  for trial in trials:
   sys.argv=[__file__,trial];exec(compile(source,'retain42','exec'),{'__file__':str(W/'hag_retain36.py'),'__name__':'__main__'})
  files={}
  for f in (O/group).glob('*.json'):
   if any(x in f.name for x in ('live-probe','version','auth')) and 'review' not in f.name:continue
   files['observations/'+f.name]=f.read_bytes()
  for n in ('candidate-42.json','package-guidance-comparison.json','service-reuse-comparison.json','client-equality.json','build42-replay.json','msys-pointer-reproduction.json','environment-review42.json','final-source42-short-temp.json'):
   files['candidate/'+n]=(O/n).read_bytes()
  for n in ('hag_runs42.py','hag_full40.py','hag_eff41.py','hag_native26.py','hag_native27.py','hag_full27.py','hag221_execute.py','hag_efficiency_plan.py','hag_full42_probe.py','hag_eff42_probe.py','hag_review42.py','hag_full27_review.py','hag_trace42.py','hag_full27_trace.py','hag_facts42.py','hag_observe42.py','hag_assess_eff42.py','hag_input42.py','hag_full42_parity.py','hag_native_parity19.py','hag_retain42.py','hag_retain36.py','hag_retain26.py','hag_msys42.py'):
   files['drivers/'+n]=(W/n).read_bytes()
  tokens=[x['token'].encode() for f in (O/group).glob('*/credentials.json') for x in load(f)['principals']]
  for n,raw in files.items():
   assert not any(t in raw for t in tokens),n
   assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),n
  with zipfile.ZipFile(E/'provenance.zip','x',zipfile.ZIP_DEFLATED) as z:
   for n,raw in sorted(files.items()):z.writestr(n,raw)
  index={'archive':'provenance.zip','sha256':sha((E/'provenance.zip').read_bytes()),'files':[{'path':n,'bytes':len(raw),'sha256':sha(raw)} for n,raw in sorted(files.items())],'omissions':'Raw provider events, reasoning, credential stores and test tokens omitted. Native failures and observer recoveries retained separately.'}
  (E/'provenance-inventory.json').write_bytes((json.dumps(index,indent=2)+'\n').encode())
  (E/'assessment.md').write_bytes((O/(name+'-assessment.md')).read_bytes())
else:raise ValueError(mode)
