from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_full27_trace.py').read_text().replace('hag-lifecycle-native27-20261010','hag42/full')
exec(compile(source,'functional30-read-trace','exec'),{'__file__':str(W/'hag_full27_trace.py'),'__name__':'__main__'})
