"""Final-candidate focused authoring qualification; unchanged accepted tasks."""
import hashlib,json,subprocess,sys
from pathlib import Path
import hag_efficiency_plan as p
W=p.W;O=W/'hag-eff41-20261012';O.mkdir(exist_ok=True);P=W/'hag-authority38-20261012'
C='ee86a842550c19fb6a56913841757b42df9ecaec';REVIEW='dfeb5adf1f640dea48a53b7a446e49e93c31004a'
mode,host,trial=sys.argv[1:4];root=O/(host+'-'+trial)
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
 assert not f.exists(),f
 f.write_bytes((json.dumps(v,indent=2)+'\n').encode())
def boundary():
 return {'settings':[{'path':str(f),'sha256':sha(f.read_bytes()) if f.exists() else None} for f in map(Path,('C:/Users/mathi/.codex/config.toml','C:/Users/mathi/.claude/settings.json','C:/Users/mathi/.claude/plugins/installed_plugins.json'))], 'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=p.R).decode().strip(),'tracked_diff':subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=p.R).decode()}
assert trial in ('371','372','373','374')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=p.R).decode().strip()==REVIEW
assert not subprocess.check_output(['git','status','--porcelain'],cwd=p.R).decode().strip()
assert not subprocess.check_output(['git','diff','--name-only',C,REVIEW,'--','se_harness','tests','plugins','server','templates','pyproject.toml','repository_tools','release'],cwd=p.R).decode().strip()
assert load(P/'candidate-38.json')['commit']==C
if mode=='auth':
 p.O=O;probe=O/(host+'-auth');probe.mkdir(exist_ok=False)
 exe=W/'hag-opus55-availability-20261011/claude-2.1.280.exe'
 p.run(host+'-version',[exe,'--version'])
 v=p.run(host+'-live-probe',[exe,'-p','--no-session-persistence','--tools','','--model','claude-opus-4-6','--output-format','json','Authorized provider availability probe. Reply exactly AUTH_OK. Use no tools, read no files, change nothing.'],cwd=probe)
 assert v.get('result','').strip()=='AUTH_OK' and not v.get('is_error')
 put(O/'claude-auth-review.json',{'host':'claude','model':'claude-opus-4-6','AUTH_OK_observed':True,'raw_events':'Private provider log excluded from published evidence.'})
 print('Claude Opus4.6 live probe passed');raise SystemExit(0)
if mode=='run':
 if host=='claude':assert load(O/'claude-auth-review.json')['AUTH_OK_observed']
 else:assert load(O/(host+'-'+trial+'-boundary-probe.json'))['exit']==0
 put(root/'boundary-before-native.json',boundary())
source=(W/'hag_native26.py').read_text()
source=source.replace('hag-efficiency-compact-pointers-20261010','hag-eff41-20261012').replace("P=h.O/'package26'","P=h.W/'hag-authority38-20261012/package38'")
source=source.replace("h.O/'client26/Scripts/python.exe'","h.W/'hag-authority38-20261012/client38/Scripts/python.exe'").replace("h.O/'build26/se_harness-0.22.2-py3-none-any.whl'","h.W/'hag-authority38-20261012/build38/se_harness-0.22.2-py3-none-any.whl'")
source=source.replace('hag-efficiency26-','hag-eff41-').replace('native-efficiency26','native-authority38').replace('10.231.84.0/22','10.231.112.0/22').replace("'201'","'371'")
source=source.replace(r'C:\Users\mathi\.local\bin\claude.exe',str(W/'hag-opus55-availability-20261011/claude-2.1.280.exe'))
try:exec(compile(source,'eff41-native','exec'),{'__file__':str(W/'hag_native26.py'),'__name__':'__main__'})
finally:
 if mode=='run':put(root/'boundary-after-native.json',boundary())
if mode=='stage':
 native=root/'native';inv=load(native/'inputs/inventory.json')['files']
 assert all(sha(Path(x['path']).read_bytes())==x['sha256'] for x in inv)
 for f in ('native_call.py','summarize_native.py'):
  assert (native/'inputs'/f).read_bytes()==subprocess.check_output(['git','show',C+':tests/hosted_artifact_graph/'+f],cwd=p.R)
 put(root/'package-reuse.json',{'candidate':C,'review_head':REVIEW,'package_root':str(P),'case':'EFF-04A2' if trial=='371' else 'EFF-04B','required_model':'claude-opus-4-6' if host=='claude' else 'Record CLI selected model','product_changes_since_candidate':[],'inputs_checked':len(inv)})
 print(host,trial,'exact package and unchanged task staged')
