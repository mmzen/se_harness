+++
id = "REQ-NATIVE-001"
type = "requirement"
title = "Return exactly Hello rehearsal"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
statement = "Calling greeting() in the selected immutable local fixture returns exactly Hello rehearsal."
verification_method = ["test"]
priority = "must"
source = "Native hosted-workflow qualification task"

[relations]
derives_from = ["CAP-NATIVE-001"]
+++

# Return exactly Hello rehearsal

## Why

The operator needs a fixed observable value to prove the selected fixture behavior and inspect its evidence.

## Acceptance

Calling greeting() with no arguments returns exactly `Hello rehearsal`. Any other result or execution failure fails the check. This obligation covers the supplied local fixture only.

