+++
id = "VER-NATIVE-001"
type = "verification"
title = "Prove the exact local greeting"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[relations]
verifies = ["REQ-NATIVE-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T05:08:50Z"
decided_by = "test-owner"
reason = "Supplied synthetic test-owner decision: accept complete native definitions and approve bounded work with commit-bound verification after gates pass."
+++

# Prove the exact local greeting

## Independence

The expected value is fixed by REQ-NATIVE-001 and SPEC-NATIVE-001, not derived from candidate output. test-executor retains the execution; quality-owner assesses the evidence and commit-bound verification record.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
| --- | --- | --- | --- |
| REQ-NATIVE-001 | test | assert-greeting; docs/engineering/lifecycle-pilot/evidence/WO-NATIVE-001/assertion.json | Exit 0 and exact stdout `exact greeting passed`, establishing equality with `Hello rehearsal`. |

## Planned execution

On this native Windows host, use the selected native_call.py approved helper with `assert-greeting --record work/assertion.json`. The helper uses selection.json client_python. It runs the selected fixture once after matching SHA-256 dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1. The source manifest identifies fixture commit 5820415917e87b64d80bad2f7c39c6d18d692829.

The service does not run source tests. Released SE Harness 0.22.1 evaluates lifecycle and evidence bindings. A mismatch or exception fails the assertion; retain the actual result without claiming success.

## Evidence retention

Retain the complete local command, working directory, exit, stdout, stderr and elapsed time in work/assertion.json, then hand off its exact bytes to docs/engineering/lifecycle-pilot/evidence/WO-NATIVE-001/assertion.json. Retain source identity and inspection in docs/engineering/lifecycle-pilot/evidence/WO-NATIVE-001/inspection.md. Capture commit-bound verification from the completed service projection and preserve its original candidate in both exports.

## Residual uncertainty

This equality assertion makes no separate type, platform portability or external-effects claim. The assertion record contains no Python version. The immutable fixture commit is distinct from the later disposable verification candidate.

