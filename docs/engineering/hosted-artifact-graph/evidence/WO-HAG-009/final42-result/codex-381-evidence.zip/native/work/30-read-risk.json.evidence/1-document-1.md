+++
id = "RISK-NATIVE-001"
type = "risk"
title = "Greeting proof could be bound to the wrong input"
status = "raised"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
description = "A passing local assertion could be mistaken for execution on the disposable verification candidate, obscuring the immutable fixture identity and invalidating the operator proof."
action = "Retain the fixture digest and full local assertion; compare the handed-off evidence and preserve the original test candidate in exports through WO-NATIVE-001."
raised_by = "test-executor"

[relations]
threatens = ["WO-NATIVE-001"]

[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-12T05:10:58Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."
+++

# Risk: Greeting proof could be bound to the wrong input

## Description

A passing local assertion could be mistaken for execution on the disposable verification candidate, obscuring the immutable fixture identity and invalidating the operator proof.

## Next action

Retain the fixture digest and full local assertion; compare the handed-off evidence and preserve the original test candidate in exports through WO-NATIVE-001.
