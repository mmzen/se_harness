+++
id = "WO-NATIVE-001"
type = "work_order"
title = "Retain proof of the native greeting rehearsal"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[assurance]
commit_bound_verification = "required"
rationale = "The test verification and release decisions depend on the new definitions, traceability and retained evidence."
decided_by = "test-owner"

[execution_scope]
paths = [
  "src/greeting.py",
  "docs/engineering/lifecycle-pilot/intent/INT-NATIVE-001.md",
  "docs/engineering/lifecycle-pilot/capabilities/CAP-NATIVE-001.md",
  "docs/engineering/lifecycle-pilot/requirements/REQ-NATIVE-001.md",
  "docs/engineering/lifecycle-pilot/specifications/SPEC-NATIVE-001.md",
  "docs/engineering/lifecycle-pilot/verification/VER-NATIVE-001.md",
  "docs/engineering/lifecycle-pilot/work-orders/WO-NATIVE-001.md",
  "docs/engineering/lifecycle-pilot/release/REL-NATIVE-001.md",
  "docs/engineering/lifecycle-pilot/evidence/WO-NATIVE-001/"
]

[relations]
implements = ["REQ-NATIVE-001"]
specifications = ["SPEC-NATIVE-001"]
verification = ["VER-NATIVE-001"]
+++

# Retain proof of the native greeting rehearsal

## Objective

Give the operator the inspected greeting, exact local equality assertion and complete exported engineering record for this test change.

## In scope

Author and approve the new NATIVE-001 definitions in this selected disposable test project. Inspect the immutable greeting, execute VER-NATIVE-001 locally, retain evidence, record one risk and its paired mitigation decision, complete the work and prepare commit-bound verification. Prepare a test release contract and record for version 0.0.1 after the exact verified candidate is known.

## Out of scope

Do not modify source or imported -900 records. Do not act on a real repository, install software, push, tag, publish or deploy.

## Authorized decision envelope

test-executor may execute the approved bounded test and retain observed outputs. The supplied test-owner decisions accept complete definitions and approve work after gates pass. The supplied risk choice is mitigate through this work. quality-owner prepares and decides the test VREC; release-owner prepares and decides the test RLS. These are synthetic test inputs only.

## Constraints

Use released evaluator 0.22.1 with the selected candidate transport. Retain exact requests and results. Keep the immutable fixture commit distinct from the disposable verification candidate. A release contract cannot be completed with a guessed candidate.

## Expected change surface

Inspected src/greeting.py contains the constant greeting; its bytes remain unchanged. The inspected INT, CAP, REQ, SPEC and VER NATIVE-001 drafts and this WO record supply the new test definitions and their approval writes. Their exact paths are listed above and remain part of the handoff comparison from the retained first lifecycle input head.

The planned REL-NATIVE-001 path contains the later test contract. The evidence/WO-NATIVE-001/ directory retains assertion.json, inspection.md and generated handoff evidence for this work only. No CI, packaging, caller or deployment change is needed for the selected fixed function and available assertion helper.

Future risk and paired decision IDs are unresolved until the service creates them; assess their returned paths under the conditional rule for risks recorded during execution. Future VREC/RLS IDs and evaluator evidence paths are unresolved until prepared; assess their direct relationship to this WO under existing generated-output rules. No parent directory is automatically admitted.

## Required verification

Execute the exact planned assertion and evidence inspection in VER-NATIVE-001. Keep the full assertion result even if it fails. Compare exported snapshots and original candidate bindings through the independent reviewer.

## Evidence to record

Retain local work/assertion.json and hand off identical bytes as docs/engineering/lifecycle-pilot/evidence/WO-NATIVE-001/assertion.json. Retain source identity and inspection in inspection.md beside it. Keep actual lifecycle receipts, refusals, retry comparisons and both export manifests under the native work directory.

## Stop and escalate conditions

Stop the affected action on source digest mismatch, permission denial, component mismatch, unresolved reply, failed assertion, out-of-scope change or failed gate. Resolve uncertainty with the original operation key. Do not widen approved scope or replace historical inputs to hide a refusal.

The executor records failed boundary checks separately from the greeting assertion result.

## Completion report format

Report the observed greeting check, source and candidate identities, retained evidence paths, actual refusals and recoveries, limitations and next accountable decision. Execution completion does not supply verification or release acceptance.
