+++
id = "INT-NATIVE-001"
type = "intent"
title = "Let the operator inspect a proved rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
outcome = "The operator can inspect the existing greeting and its complete exported test record."

[relations]
+++

# Let the operator inspect a proved rehearsal greeting

## Problem

The test owner needs an independently authored engineering record for the existing local fixture. Imported reference drafts do not record this native test. The operator needs to inspect the function, its exact greeting result and the exported history together.

## Success measures

At the end of this disposable rehearsal, the operator can inspect both immutable exports and trace the greeting result to its source and test evidence. The baseline for this native run is not measured. Acceptance checks are defined in VER-NATIVE-001.

## Scope limits

Only the selected private test copy and retained local evidence are in scope. Source files and imported history stay immutable. Real engineering decisions, publication, deployment, installation, tags and pushes are excluded. All actor labels are synthetic.
