+++
id = "RISK-NATIVE-001"
type = "risk"
title = "Greeting proof could be bound to the wrong input"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
description = "A passing local assertion could be mistaken for execution on the disposable verification candidate, obscuring the immutable fixture identity and invalidating the operator proof."
action = "Retain the fixture digest and full local assertion; compare the handed-off evidence and preserve the original test candidate in exports through WO-NATIVE-001."
raised_by = "test-executor"

[relations]
threatens = ["WO-NATIVE-001"]
mitigated_by = ["WO-NATIVE-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-12T05:11:43Z"
reason = "Supplied synthetic mitigation choice: retain fixture identity and exact assertion evidence through WO-NATIVE-001 before verification."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-12T05:10:58Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-12T05:11:43Z"
decided_by = "test-owner"
reason = "Supplied synthetic mitigation choice: retain fixture identity and exact assertion evidence through WO-NATIVE-001 before verification."
+++

# Risk: Greeting proof could be bound to the wrong input

## Description

A passing local assertion could be mistaken for execution on the disposable verification candidate, obscuring the immutable fixture identity and invalidating the operator proof.

## Next action

Retain the fixture digest and full local assertion; compare the handed-off evidence and preserve the original test candidate in exports through WO-NATIVE-001.
