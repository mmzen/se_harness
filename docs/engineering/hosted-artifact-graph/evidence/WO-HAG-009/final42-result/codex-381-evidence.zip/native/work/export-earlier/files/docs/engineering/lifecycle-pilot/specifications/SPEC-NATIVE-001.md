+++
id = "SPEC-NATIVE-001"
type = "specification"
title = "Exact fixture greeting"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
contract = "The selected fixture greeting() returns exactly Hello rehearsal."

[relations]
specifies = ["REQ-NATIVE-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T05:08:50Z"
decided_by = "test-owner"
reason = "Supplied synthetic test-owner decision: accept complete native definitions and approve bounded work with commit-bound verification after gates pass."
+++

# Exact fixture greeting

## Scope and behavior

This specification covers the no-argument greeting() in src/greeting.py. Its result equals `Hello rehearsal`, including the capital H and single space. For example, greeting() == "Hello rehearsal" evaluates true.

The existing constant return is the smallest sufficient implementation. No source modification, new interface or architecture is needed.

## Failure behavior

A different value or an execution exception is a failed verification outcome. The assertion result must be retained; the executor must not report success in that case.

