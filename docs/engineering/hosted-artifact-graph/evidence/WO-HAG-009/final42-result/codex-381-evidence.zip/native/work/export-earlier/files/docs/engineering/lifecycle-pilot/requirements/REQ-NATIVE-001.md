+++
id = "REQ-NATIVE-001"
type = "requirement"
title = "Return exactly Hello rehearsal"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
statement = "Calling greeting() in the selected immutable local fixture returns exactly Hello rehearsal."
verification_method = ["test"]
priority = "must"
source = "Native hosted-workflow qualification task"

[relations]
derives_from = ["CAP-NATIVE-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T05:08:50Z"
decided_by = "test-owner"
reason = "Supplied synthetic test-owner decision: accept complete native definitions and approve bounded work with commit-bound verification after gates pass."
+++

# Return exactly Hello rehearsal

## Why

The operator needs a fixed observable value to prove the selected fixture behavior and inspect its evidence.

## Acceptance

Calling greeting() with no arguments returns exactly `Hello rehearsal`. Any other result or execution failure fails the check. This obligation covers the supplied local fixture only.

