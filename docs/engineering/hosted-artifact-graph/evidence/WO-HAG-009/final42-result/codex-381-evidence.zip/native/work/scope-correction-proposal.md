# Scope correction proposal — not applied

The agent omitted the paired decision path while preparing WO-NATIVE-001. The first handoff scope check accepted the two supplied evidence paths. The complete Git-derived handoff then refused QGP-G4I-PATHS with:

> WEX201: changed path is outside execution scope: docs/engineering/lifecycle-pilot/decisions/DEC-NATIVE-001.md

The governed record remains in_progress at revision sha256:1422d84fd621ba332b2e1e2425f512b5e557edcfdffd3d152709e3454895c5b2. Its complete file SHA-256 is 7bf783d5e38920f8916479026d736142baa547a50feb607d9ecd1bcdfa9fb208, retained in export-later/files/docs/engineering/lifecycle-pilot/work-orders/WO-NATIVE-001.md.

The earlier approved file SHA-256 is d89b07719d0d32f7895dcd2b18c5a8e0c9de61aef848ec69918e3d1fc4a872f7, retained in export-earlier/files/docs/engineering/lifecycle-pilot/work-orders/WO-NATIVE-001.md.

Proposed correction for accountable review: explicitly cover docs/engineering/lifecycle-pilot/decisions/DEC-NATIVE-001.md and docs/engineering/lifecycle-pilot/risks/RISK-NATIVE-001.md in a supported revised work authorization, preserving the exact accepted version and original evidence. Both are predictable supporting paths for the requested paired risk decision. The present record instead described future IDs as unresolved and relied on conditional generated-output admission. That was insufficient for the decided DEC.

This proposal grants no authority. It must not replace the accepted file or broaden its recorded approval. The selected released AMEND_DEFINITIONS.md states: "This release has no supported command and relation for creating and activating this linked definition revision." Its preceding boundary requires review, a human decision and supported activation. The hosted closed schemas likewise provide no accepted-record scope amendment operation.

Affected operations: valid handoff, WO completion, commit-bound VREC preparation/acceptance, completed candidate-specific REL contract, and RLS preparation/decision. These remain unperformed. No candidate P exists. The first retained input head remains b79fce9ea54eefcab234323289126412d55f0af7; replacing it with a later head would conceal changed paths.

Current accountable escalation from the refusal: DR-REMEDIATION-SCOPE for QGP-G4I-PATHS on WO-NATIVE-001. Do not revise approved artifacts, delete the paired records, change the comparison base, or reinterpret the refusal as a pass. The local assertion remains valid evidence of the fixture equality only.

