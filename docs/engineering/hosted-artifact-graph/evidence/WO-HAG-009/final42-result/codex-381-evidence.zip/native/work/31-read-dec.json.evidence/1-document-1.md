+++
id = "DEC-NATIVE-001"
type = "decision"
title = "Answer to the threat Greeting proof could be bound to the wrong input"
status = "open"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
kind = "question"
question = "How is the threat 'Greeting proof could be bound to the wrong input' answered: accept, avoid or mitigate?"
raised_by = "test-executor"
recommendation = "mitigate"

[[options]]
id = "accept"
label = "Accept the threat; record a residual and a revisit trigger."

[[options]]
id = "avoid"
label = "Avoid the threat by a design change recorded in an ADR or a decision."

[[options]]
id = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."

[relations]
concerns = ["RISK-NATIVE-001", "WO-NATIVE-001"]
blocks = ["WO-NATIVE-001"]
+++

# Decision: Answer to the threat Greeting proof could be bound to the wrong input

## Question

How is the threat 'Greeting proof could be bound to the wrong input' answered: accept, avoid or mitigate? The description and the threatened artifacts are on RISK-NATIVE-001.

## Options

- `accept`: Accept the threat; record a residual and a revisit trigger.
- `avoid`: Avoid the threat by a design change recorded in an ADR or a decision.
- `mitigate`: Mitigate the threat through a work order; the risk closes under verified coverage.

## Recommendation

The raiser recommends `mitigate`.

## Disposition

Written by `harnessctl decide`; do not edit by hand. Disposing this decision
moves RISK-NATIVE-001 to the state the chosen option names, in the same act.
