# Native greeting inspection

Actor: test-executor. Synthetic private test only.

Inspected input: src/greeting.py from the immutable local fixture snapshot.
Source fixture S: 5820415917e87b64d80bad2f7c39c6d18d692829.
Source SHA-256: dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1.

The complete inspected source is:

```python
def greeting():
    return 'Hello rehearsal'
```

The local assertion for REQ-NATIVE-001 ran under the approved WO-NATIVE-001 on the native Windows host through the selected client Python. assertion.json retains its exact arguments, working directory, exit 0, stdout "exact greeting passed\n", empty stderr and elapsed time. Assertion record SHA-256: b8ecf7ac6345bc0c9a720a2190a2d7d3f9f4ff7ab45795c121165c8474b7118d.

The expected value comes from REQ-NATIVE-001 and SPEC-NATIVE-001. No source change was needed. The constant return is sufficient for the required equality; no new abstraction or dependency is warranted. This check makes no independent type or portability assertion. The source service did not execute the test.

The immutable fixture S is not the disposable verification candidate P. The later VREC will bind P and these exact evidence bytes. Actual qualification implementation candidate C is 1da445cb743295c441cf46f421653b092d042378. The local assertion does not verify C.

The threat of confusing input identities is RISK-NATIVE-001. DEC-NATIVE-001 records test-owner's supplied mitigation choice through WO-NATIVE-001. Keep the first lifecycle input head b79fce9ea54eefcab234323289126412d55f0af7 for the complete handoff comparison.

Boundary-check failures and recovery receipts remain separately in the native work directory. They do not alter the observed greeting assertion.

