+++
id = "CAP-NATIVE-001"
type = "capability"
title = "Inspect and prove the local greeting"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
ability = "The test operator can inspect the selected local greeting and trace its exact assertion to retained evidence."

[relations]
derives_from = ["INT-NATIVE-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T05:08:50Z"
decided_by = "test-owner"
reason = "Supplied synthetic test-owner decision: accept complete native definitions and approve bounded work with commit-bound verification after gates pass."
+++

# Inspect and prove the local greeting

The operator uses the immutable selected fixture in the private test environment. The required ability is to inspect the function and its retained equality assertion, with exported engineering history for independent review.

The requirement defines the exact expected greeting. The specification and verification contract define the check. No real product behavior or external action is requested.

