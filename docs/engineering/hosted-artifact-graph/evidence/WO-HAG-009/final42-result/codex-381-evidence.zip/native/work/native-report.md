The native qualification is **blocked and incomplete**. The local fixture's `greeting()` passed the exact equality assertion for `Hello rehearsal`. The full engineering lifecycle did not complete because I omitted the decision path from the approved scope of WO-NATIVE-001.

The intended handoff was refused with `HAG_REMOTE_EVALUATOR_REFUSED`. Its final released check reports:

> QGP-G4I-PATHS: WEX201: changed path is outside execution scope: docs/engineering/lifecycle-pilot/decisions/DEC-NATIVE-001.md

WO-NATIVE-001 remains `in_progress`. INT-NATIVE-001, CAP-NATIVE-001, REQ-NATIVE-001, SPEC-NATIVE-001 and VER-NATIVE-001 are approved. RISK-NATIVE-001 is `mitigating`; DEC-NATIVE-001 records the supplied `mitigate` choice through that work order. No valid handoff, work completion, VREC, test candidate P, REL-NATIVE-001, RLS or test release assessment occurred. The requested release contract for 0.0.1 is also unfinished.

| Case | Actual outcome and exact evidence | Limit |
| --- | --- | --- |
| Selected installation | [01-status.json](01-status.json): selected client 0.22.2 and evaluator 0.22.1 matched; ready=true | Readiness and context reporting do not pass lifecycle gates |
| Definitions and approval | [16-validate-result.json](16-validate-result.json), [22-recover-approval.json](22-recover-approval.json): new six-artifact package validated and approved | W-AUT-022 advisory concerns imported history; my scope review missed the decision path |
| Changed draft / stale preview | [19-stale-request.json](19-stale-request.json), [result](19-stale-result.json): HAG_REMOTE_STALE_PROJECT; [check](mcp-check-after-stale.json) retained draft state | This demonstrates stale selected inputs, not an isolated digest-mismatch error |
| Lost accepted reply | [21-approval-apply-request.json](21-approval-apply-request.json), [initial result](21-approval-apply-result.json): exit 2; [lookup](22-recover-approval.json) recovered acceptance | Initial transport uncertainty was resolved before retry |
| Identical retry | [23-identical-retry.json](23-identical-retry.json): exact original request resubmitted, parsed response matches lookup | Same receipt, versions and Git head; no duplicate effect observed |
| Changed request under accepted key | [24-changed-key-request.json](24-changed-key-request.json), [result](24-changed-key-result.json): HAG_REMOTE_KEY_REUSE | One assignment reason changed; no accepted mutation |
| Work start | [27-start-apply-result.json](27-start-apply-result.json): accepted as test-executor | Start is separate from completion |
| Greeting assertion | [assertion.json](assertion.json): exit 0, stdout `exact greeting passed\n`, empty stderr; [inspection](inspection.md) | Ran locally against fixture S; service ran no source tests |
| Risk and paired decision | [33-decide-apply-result.json](33-decide-apply-result.json), [DEC readback](34-readback-0.json), [risk readback](34-readback-1.json) | Mitigation selected by test-owner; risk not accepted or closed |
| Deliberate outside handoff | [36-outside-request.json](36-outside-request.json), [result](36-outside-result.json): WEX201 for `outside-native-scope/assertion.json` | No committed files/transitions; [comparison](mcp-compare-after-refusal.json) reports no changes |
| Intended handoff | [37-handoff-preview-request.json](37-handoff-preview-request.json), [result](37-handoff-preview-result.json): decision path outside scope | Supplied evidence paths passed, but full Git change set failed; temporary evidence preparation was discarded |
| Verification and release | [lineage](mcp-lineage-blocked-work.json), [later manifest](export-later/manifest.json) | No VREC, captured P, new release contract or RLS; not assessed |
| Earlier and later exports | [earlier result](38-export-earlier-result.json), [later result](39-export-later-result.json) | Downloads succeeded; independent Git reconstruction and evaluator replay were not performed |

The new definitions state the exact expected value, the failure condition and the local assertion method. VER-NATIVE-001 separates the greeting observation from commit-bound verification and external delivery. Template validation was followed by content review, but that review was insufficient: I relied on prose about future risk/decision artifacts and did not include their exact paths in the approved scope. The subsequent Git-based handoff exposed the omission. [scope-correction-proposal.md](scope-correction-proposal.md) preserves the proposed correction without changing the accepted record. Earlier future-tense language in [inspection.md](inspection.md) describes the intended VREC; it does not establish one.

The [selected change skill](../inputs/plugin/verity-plane/skills/change/SKILL.md) routes this action through its [hosted lifecycle procedure](../inputs/plugin/verity-plane/skills/change/references/hosted-test-lifecycle.md), which states: “A later missing path requires an authorized correction; do not expand approved scope by editing its record.” The selected [AMEND_DEFINITIONS.md](../inputs/released-resources/docs/engineering/harness/AMEND_DEFINITIONS.md) states: “This release has no supported command and relation for creating and activating this linked definition revision.” This applies because correcting WO-NATIVE-001 would change its accepted scope. I preserved the approved scope, original comparison base, risk and decision. I did not create a replacement to evade the failed gate.

The one current typed step from the failed evaluator result is `PROC-WO-IMPLEMENT / STEP-WO-IMPLEMENT-CHECK`: “Escalate QGP-G4I-PATHS under DR-REMEDIATION-SCOPE”. Its exact response is: “Escalate to the accountable owner under DR-REMEDIATION-SCOPE: WEX201: changed path is outside execution scope: docs/engineering/lifecycle-pilot/decisions/DEC-NATIVE-001.md”. The accountable synthetic owner is test-owner; test-executor remains the work executor. This report records that escalation. A supported authorized amendment route is missing; another approval prompt alone would not supply it.

| Read-only MCP tool | Saved complete selected response | Meaning |
| --- | --- | --- |
| work_context | [mcp-work-context.json](mcp-work-context.json), context 12 / project 14 | Draft work and governing chain |
| check | [mcp-check-after-stale.json](mcp-check-after-stale.json), context 13 / project 15 | Draft state after stale refusal |
| revision | [mcp-revision-approval.json](mcp-revision-approval.json), context 14 / project 16 | Approved WO bytes decoded and hash checked |
| impact | [mcp-impact.json](mcp-impact.json), context 17 / project 19 | REQ reverse reachability |
| cypher | [mcp-cypher.json](mcp-cypher.json), context 17 / project 19 | Selected WO status in_progress |
| compare | [mcp-compare-after-refusal.json](mcp-compare-after-refusal.json), context 17 / project 19 | Current context equals accepted mitigation baseline |
| lineage | [mcp-lineage-blocked-work.json](mcp-lineage-blocked-work.json), context 17 / project 19 | WO links to VER, no VREC |

Each successful selected response reports complete, null continuation and no unresolved items. Exact requests and raw responses are retained in these files. An additional [old-context comparison](mcp-compare-draft-change.json) returned HAG_REMOTE_STALE_CONTEXT inside a normal MCP response. That refusal does not establish a general unsupported-query claim. Completeness applies only to each selected view.

Project: `43c44f43-9152-47c9-b5ba-783402136dfd`. Context: `0b2fa8cd-0dac-406d-a841-6ca794a24a1d`. Latest observed versions: project 19, context 17. Evaluator 0.22.1 archive SHA-256 is `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`; payload SHA-256 is `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff`. Client 0.22.2 wheel SHA-256 is `b100618780631da7b4c15940df99ec06a283918a8c9d50d1d56633df428e24dc`.

Identity B is the imported hosted baseline `se-harness-artifact-baseline/v1:sha256:ff1217b7ed0b76963ec86750c62ea1ee33f57efab6375364318e9df27646fc15`. Fixture S is `5820415917e87b64d80bad2f7c39c6d18d692829`. Actual implementation candidate C is `1da445cb743295c441cf46f421653b092d042378`. Test verification candidate P was not captured. The local assertion verifies neither C nor a VREC binding.

The original accepted approval key is `native-approval-apply`, receipt `sha256:d88cb065b70cc47725914889643593e165ad08aafbb28d11607d17607e7ab114`. It advanced project 15→16 and context 13→14. Both handoff attempts retained its input Git head `b79fce9ea54eefcab234323289126412d55f0af7`; see [retained-handoff-base.json](retained-handoff-base.json).

Both export directories contain `files/`, `manifest.json` and `history.bundle`:

- [Earlier manifest](export-earlier/manifest.json): approval baseline `se-harness-artifact-baseline/v1:sha256:691ec394681f11b8b8d2a146cdddbc9ecd6a1406f2845180bddb0e0ab8945ba3`, head `0c04d86b277b152d086be91960ca82f88d5a2e32`, 18 files.
- [Later manifest](export-later/manifest.json): mitigation baseline `se-harness-artifact-baseline/v1:sha256:9f5735560032f13f29d6c7ac7f59b4a5dbd7270d14d1850c1cc715a83f41ab90`, head `e6395528b76c87a0a48c095d7152cd9a1dcd596a`, 20 files.

The inspected manifests add risk and decision and change the WO between snapshots. Greeting and imported history hashes remain equal. Both candidate arrays are empty. Local assertion and inspection evidence are retained beside this report, but are absent from exported snapshots because handoff was refused. Download success and manifest comparison do not establish independent Git replay or complete candidate-binding qualification.

[Captured observations](captured-observations.json) are an in-progress capture: 142 observed tool items, six native failed items, and five retained nonzero command records. The five records are the stale request, uncertain reply, changed-key request, deliberate outside handoff and unintended scope failure. These are different counts. The helper also rejected a read limit of 10034; a supported read recovered it. Three help-file searches returned no match before actual CLI help was read. The MCP stale-context refusal was returned within a normal tool result. No host permission denial was observed, but the capture is incomplete and gives no exhaustive failure count.

[File-read trace](file-read-trace.json) retains observed paths, hashes and triggers; [final reporting trace](final-report-read-trace.json) records recovery reads. Missing read capture remains unknown. Explicit setup and task instructions do not prove automatic startup delivery. [native-observations.json](native-observations.json) preserves machine-readable outcomes, exact identities, receipts, export hashes, limits and the evaluator's restitution. All decisions are synthetic test-copy inputs. No source modification, installation, real engineering decision, push, tag, publication or deployment occurred.

