# Test-copy exports

Each subdirectory is a new destination written by `remote export` (test copy only).

| Directory | Baseline | Stage |
| --- | --- | --- |
| `earlier-b8e7d78c/` | `se-harness-artifact-baseline/v1:sha256:b8e7d78cf353b21bf677c35312c0293354261981eb3f5c805f338f781abfaf52` | After VREC-P3-001 capture (ready; binds test candidate P `8945e125d58a64e6079d37f809c6ce008a116f65`) |
| `later-b973c2a7/` | `se-harness-artifact-baseline/v1:sha256:b973c2a710dbc411e432afe192e5dbacbce02e23d4fe57c093c18b08274f3230` | After RLS-P3-001 released (final test state) |

Git remains authoritative for real work. These are disposable test records.
