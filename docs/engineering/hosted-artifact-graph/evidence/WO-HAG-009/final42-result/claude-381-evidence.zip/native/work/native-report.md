# Native hosted-workflow qualification report (claude-381)

Test data only. All actors are synthetic labels. Git remains authoritative for
real work. No push, tag, publication, installation or deployment occurred.

## Outcome

The test operator can inspect the existing fixture function `greeting()` and
find an executed, retained assertion that it returns exactly `Hello rehearsal`.
The assertion is bound to test candidate P in a verified test VREC and a released
test RLS. Two immutable snapshots are exported for independent replay.

| Item | Final test state | Accepted receipt |
| --- | --- | --- |
| INT/CAP/REQ/SPEC/VER-P3-001 | approved | `sha256:8eb43579b3c7a6eb10248ac111269e87ed5d1e4f5aeb3b554d86a8e1256ae7dc` |
| RISK-P3-001 / DEC-P3-001 | raised (`c381-raise-risk-001`), then mitigating / decided `mitigate` | `sha256:861565ff…` / `sha256:2536584b0e13d29e2377cb82507159562c2a74df183c89d2610b9dada6afd4a8` |
| WO-P3-001 | approved, in_progress, implemented | `sha256:03254a30…`, `sha256:324f53e7…`, `sha256:cd50fc18df7787e331a6f367703fe3c4b27f9dd77a487a8591a1cbfd39338708` |
| Handoff (WO-P3-001) | accepted | `sha256:a2e63c6c3188b49a4c3b9184b7df6a1653062f63bd0a967aaa1077fed69c1b90` |
| VREC-P3-001 | ready, then verified (quality-owner) | `sha256:3aab7dc6…`, `sha256:f1c4c0a195bc0090f3ec3b991142b9ad966960bc0c33a5feb35fbd215cdc26f3` |
| REL-P3-001 | approved (release-owner) | `sha256:a1680866f1adcc839a64f0fc2d4f97a1cf643dc2f751a295347f7b4b184e0042` |
| RLS-P3-001 | ready, then released (release-owner), test version `0.0.1` | `sha256:c8293ae3…`, `sha256:04f4d63c6f4bb2aecd8f24051f7c9eb1775a1298c2df129435fbe62beeaee00e` |

Final view: context `3b562756-590f-4d5d-8f58-bfb0045bf0d1` version 28, project
version 30, baseline
`se-harness-artifact-baseline/v1:sha256:b973c2a710dbc411e432afe192e5dbacbce02e23d4fe57c093c18b08274f3230`.

The evaluator's current step after release is `STEP-EXTERNAL-ACTION`
(`DR-EXTERNAL-ACTION`). It needs authority for an exact external action. None
was supplied, so I stopped there. That is the next accountable decision.

## Identities

| Identity | Value | Source |
| --- | --- | --- |
| Selected context | hosted test project `ddab272a-f5bf-41b1-8e13-47a84e1d96fa`, endpoint `http://127.0.0.1:51064`, `test_copy: true`, `sandbox-projection` | `work/records/001-status.stdout.txt` |
| Released evaluator (sole governor) | 0.22.1, archive `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`, payload `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff` | status; every receipt |
| Candidate client | 0.22.2, wheel `b100618780631da7b4c15940df99ec06a283918a8c9d50d1d56633df428e24dc` | `identity`; status |
| Combination | `sha256:3db540a5cce2b530f286dca532f8a0c46903607f5bb2a7e3c9f3fdf074f63d09`; every component in status equals `inputs/combination.json` | status vs combination |
| Imported baseline | `se-harness-artifact-baseline/v1:sha256:5f976b84398a9902b1586e863077f5ac7fe060e3c644d8e702b3caa933b0b387` | `work/records/002-import` |
| Source fixture commit S | `5820415917e87b64d80bad2f7c39c6d18d692829` | source manifest |
| Test candidate P | `8945e125d58a64e6079d37f809c6ce008a116f65` (bound by VREC-P3-001 and RLS-P3-001) | `work/records/047-apply-capture.stdout.txt` |
| Implementation candidate C | `1da445cb743295c441cf46f421653b092d042378` (`qualification_candidate`); not tested by these test records | `identity`; selection.json |
| Handoff base | `560765c3fc8388b2376df55578d92ab3eb359304`, the `input_git_head` of the first accepted lifecycle mutation (`c381-approve-defs-001`) | `work/records/023-lookup-approve-defs.stdout.txt` |

Context reporting is not a gate result. Status and the combination match.
Validation (`work/records/020-inspect-validate`) reports `valid: true`, 14
artifacts, 0 errors and 0 warnings. Its one advisory, `W-AUT-022`, is on the
immutable imported `SPEC-P3-900`. Each gate pass cited below comes from a
separate evaluator result.

## Greeting source and assertion

- Source inspection: `inputs/source/src/greeting.py`, 45 bytes, SHA-256
  `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`, contains
  `return 'Hello rehearsal'`. Source inspection is not a test.
- Executed test: `assert-greeting`, recorded at
  `work/evidence/greeting-assertion.json` (SHA-256
  `64900203c513813ea0ed04dc76e90b2e4f529d19f66577ac2f79578007033f4a`). Exact
  result: `"exit": 0`, `"stdout": "exact greeting passed\n"`, `"stderr": ""`,
  `"elapsed_seconds": 0.077353`. The platform is the native Windows host with
  the selected client Python; the tool records no Python version. The hosted
  service ran no source tests.
- P contains `src/greeting.py` with the same SHA-256 `dcbd486a…`
  (`work/records/046-preview-capture.stdout.txt`, `/provenance/candidates`).
  `src/greeting.py` was not modified.

## Required cases

| Case | Outcome | Evidence | Remaining limit |
| --- | --- | --- | --- |
| Author, validate, full lifecycle | Passed through release assessment | records 005–019 (drafts), 020–057 (lifecycle) | Evaluator draft review is shape-only; my content review is in this report |
| Risk + paired decision | RISK-P3-001 raised with DEC-P3-001; decided `mitigate`, `mitigated_by WO-P3-001`, by `test-owner`; risk now `mitigating` | 026–031 | Risk acceptance was not supplied and was not used |
| Out-of-scope handoff refusal | Refused twice, no effect (details below) | 040, 041 | — |
| Stale preview after draft change | Refused `HAG_REMOTE_STALE_PROJECT` (409); WO stayed `draft`; fresh preview applied | 032–036 | — |
| Uncertain reply | Apply of `c381-approve-defs-001` returned transport `unknown` (exit 2) | 022 | — |
| Recovery by key lookup | `accepted`, receipt `sha256:8eb43579…`, project 16→17 | 023 | — |
| Identical retry | Same receipt and revisions; stdout SHA-256 `a65723469969fde44b6d9a3fde60221f8bc2aeaa91056462af1944e797caf505` identical to lookup; versions still 16→17 | 024 | — |
| Changed request, same key | Refused `HAG_REMOTE_KEY_REUSE` (409), no receipt | 025 | — |
| Seven MCP tools | All used; every response `complete: true`, `continuation: null` | `work/native-observations.json` `/mcp_reads` | See lineage note |
| Earlier/later exports | Written to new directories | `work/exports/` | Independent replay not performed by me |

### Out-of-scope handoff

1. `040`: the request added
   `docs/engineering/lifecycle-pilot/notes/greeting-source-identity.json`. The
   service refused it before evaluation with `HAG_REMOTE_PROTECTED_FIELD`
   (422): "Handoff inputs cannot replace formal or instruction files." I observed
   that this path was protected. I did not establish why it is classified that way.
2. `041`: the request added the root path `notes/greeting-source-identity.json`.
   The released evaluator refused it: `QGP-G4I-PATHS: WEX201: changed path is
   outside execution scope: notes/greeting-source-identity.json`, outcome
   `blocked`, `mutation.writes: []`. Its suggested response was an escalation
   under `DR-REMEDIATION-SCOPE`. I did not escalate; I moved the file into the
   WO's own evidence directory instead.
3. Neither refusal produced a receipt or versions. The valid handoff (`042`
   preview, `043` apply) then passed scope and the Git-derived handoff check
   from `560765c3…`. The change set was complete: 12 paths, all in scope.

### Stale preview

I previewed WO approval (`032`, digest `sha256:9f9eb3ee…`, versions 19/17).
Then I revised the selected WO draft (`033`, revision `7bbe38fd…`). Applying the
old preview (`034`) was refused with `HAG_REMOTE_STALE_PROJECT`. MCP `check` at
context 18 then showed `WO-P3-001` still `draft` at the new revision. A fresh
preview (`035`, digest `sha256:0039316f…`) was applied in `036`.

## Seven hosted reads (MCP)

| Tool | View | Selection | Result |
| --- | --- | --- | --- |
| `work-context` | context v14 | WO-P3-001 | 5 governing artifacts, 10 declared paths, complete |
| `lineage` | context v14 | REQ-P3-001; WO-P3-001 | REQ: 0 artifacts; WO: VER-P3-001 via `verification`. Complete. Per the read contract, lineage covers verification/evidence relations only; it does not list definition ancestry |
| `impact` | context v14 | REQ-P3-001 | 4 dependents (REL, SPEC, VER, WO), 6 relations, complete |
| `revision` | context v14 | INT-P3-001 `f244cd68…` | document SHA-256 `8ce738e5…` equals my local draft's bytes |
| `check` | context v16; v18 | DEC-P3-001; WO-P3-001 | DEC `open`, step `STEP-DEC-DISPOSE`; WO `draft` after stale refusal |
| `compare` | import baseline vs final baseline | — | 11 new `-P3-001` artifacts, 0 `-900` changes, 18 added relations, 0 removed |
| `cypher` | final baseline | `MATCH (r:Revision)-[d:DECLARES]->(a:Artifact) WHERE r.artifact_id = $artifact RETURN ... LIMIT 50`, `artifact=WO-P3-001` | 3 rows: implements REQ, specifications SPEC, verification VER; WO status `implemented` |

All read results carry `se-harness-graph-read/v2`, `test_copy: true` and the
0.22.1 evaluator identity. I read the physical-representation reference before
the Cypher query.

## Exports

| Destination | Baseline | Snapshot | Files | Git head |
| --- | --- | --- | --- | --- |
| `work/exports/earlier-b8e7d78c/` | `…b8e7d78cf353b21bf677c35312c0293354261981eb3f5c805f338f781abfaf52` (VREC ready) | `sha256:715f817f21f580b6a20f95a4ecea775c96d1c7f9753840e8714568b62c0e04c4` | 27 | `a434ac87a29ff13e82dcc4e34094c339b56522a9` |
| `work/exports/later-b973c2a7/` | `…b973c2a710dbc411e432afe192e5dbacbce02e23d4fe57c093c18b08274f3230` (RLS released) | `sha256:e1d29d51569719e5f6bd112899a3981f58ee64390c98138730d8d84b688df559` | 29 | `c306263989f20842a1ee332e9af8afcd5ce84615` |

Each Git head equals the `output_git_head` of the accepted capture or release
receipt. The client reports `independent_replay: "not yet performed"`. Download
success is not replay. The reviewer still has to clone the bundles, compare the
bytes and run released 0.22.1.

## Content review (my own, against the released type checklists)

- INT: problem, affected operator, outcome, one success measure (baseline `not
  measured`), and scope limits.
- CAP, REQ, SPEC: one observable obligation with a concrete acceptance. Rule
  `P3-GREET-001` sits under `## Rules` with a coverage row; my SPEC has no
  `W-AUT-022` advisory.
- VER: expected value derived from REQ/SPEC; matrix with method `test`; pass
  condition; platform and evaluator named; evidence path named.
- WO: exact scope paths, `[assurance] required` with rationale and
  `decided_by = "test-owner"`, both scope lists, decision envelope, stop
  conditions and completion format.
- REL: `gates = ["WO-P3-001"]`, version, rollback, evidence, and
  `candidate_commit` taken from the verified VREC only after verification.

## Failures, uncertainties and interventions

- `003` draft-open with my new WO ID was refused (`HAG_REMOTE_UNKNOWN_IDENTITY`):
  the anchor WO must exist in the baseline. I anchored the context on
  `WO-P3-900` (`004`). This selects the context only; `WO-P3-900` was not changed.
- `018` was refused with `E011`: REL `gates` accepts only work orders, although
  the template's slot reads `VER-xxx`. I corrected it under a new key (`019`).
- Helper usage errors: one `read-text` exceeded 64 KiB. Two `read-json` calls
  failed because Git Bash rewrote a bare `/pointer`. I used the documented
  `'"/pointer"'` form after that.
- `058` export was not sent because the parent directory was missing. I created
  `work/exports/` with a Write and retried in `059`.
- A raised risk file's preview and apply digests differ only by the write
  timestamp in `lifecycle_events`.
- Actor choices: I used `release-owner` for the REL definition approval, because
  REL `owners = ["release-owner"]`. The evaluator does not enforce owner
  matching here, so this was my choice. The completion step's argv suggested
  `delegated-executor`; I used the supplied `test-executor`.
- WO-P3-001 says the "handoff packet" states the source identity. The evaluator
  generates the packet itself, so the statement lives in the packet directory's
  `greeting-source-identity.json`, not in the packet body.
- No host permission denial occurred.

## Trace

The observation snapshot is `work/records/061-observations`: 178 native calls,
count complete, with `observed_content_reads`, `file_reads`, `native_failures`
and `command_records`. The pre-action reads, in order, were: task.md and
selection.json (CLAUDE.md); setup SKILL.md, then hosted-context; native-tools.md
(tool boundary); hosted-drafts and hosted-test-lifecycle (drafting and lifecycle
routes); the released sections for each action, read before that action;
hosted-reads before the MCP reads; hosted-artifact-graph#physical-representation
before Cypher; hosted-evidence before VREC and RLS. The report writes after the
snapshot are not counted in it.
