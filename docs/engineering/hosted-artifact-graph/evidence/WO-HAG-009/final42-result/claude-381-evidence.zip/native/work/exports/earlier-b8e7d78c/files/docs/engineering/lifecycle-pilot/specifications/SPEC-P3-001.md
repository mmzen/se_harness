+++
id = "SPEC-P3-001"
type = "specification"
title = "Fixed return value of the rehearsal greeting"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
# What an implementation must do to conform. The Explorer shows this summary under the title.
contract = "The fixture function greeting() returns the exact string Hello rehearsal."

[relations]
specifies = ["REQ-P3-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T05:09:47Z"
decided_by = "test-owner"
reason = "Synthetic test-owner input: accept complete test definitions."
+++

# Specification: Fixed return value of the rehearsal greeting

Synthetic test input supplied by the test owner. This is not a real human decision.

## In plain words

`greeting()` in `src/greeting.py` always returns the same fixed text,
`Hello rehearsal`.

## Scope

This specification governs the return value of `greeting()` in
`src/greeting.py`. It does not govern other fixture files.

## Terms

- **Exact greeting.** The 15-character string `Hello rehearsal`, with no
  leading or trailing whitespace.

## Rules

**P3-GREET-001.** The function `greeting()` MUST return a value equal to the
exact greeting `Hello rehearsal`.

## Failure behaviour

| Trigger | Response | Diagnostic |
| --- | --- | --- |
| `greeting()` returns a value that is not equal to `Hello rehearsal` | The implementation does not conform to P3-GREET-001; the exact-greeting assertion fails | `none` |

## Examples

**Given** the fixture source, **when** `greeting()` is called, **then** the
returned value equals `Hello rehearsal` (P3-GREET-001).

**Given** a source that returns `Hello rehearsal\n`, **when** `greeting()` is
called, **then** the value is not equal to the exact greeting and P3-GREET-001
is not met.

## Coverage

| Requirement | Rules |
| --- | --- |
| `REQ-P3-001` | P3-GREET-001 |

## Not decided here

- How the function computes the value; a literal return is sufficient.
