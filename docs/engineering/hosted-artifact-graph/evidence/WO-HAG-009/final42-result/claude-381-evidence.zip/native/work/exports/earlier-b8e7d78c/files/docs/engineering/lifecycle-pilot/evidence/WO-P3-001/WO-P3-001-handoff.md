```toml
artifact = "WO-P3-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "35a1672438f4ea41bf3bc26e38696b392ae2de968e05c221136ef41871ee9e17"
rebound_at = "2026-10-12T05:18:15Z"
```

# WO-P3-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
