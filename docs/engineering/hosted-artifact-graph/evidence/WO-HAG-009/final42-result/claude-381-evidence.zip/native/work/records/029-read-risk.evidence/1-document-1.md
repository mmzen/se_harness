+++
id = "RISK-P3-001"
type = "risk"
title = "Assertion evidence may not identify the tested source"
status = "raised"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
description = "The exact-greeting assertion runs on the native host against the local fixture copy, not inside the hosted test candidate. If the retained evidence does not identify the tested source digest and commit, a reviewer cannot tie the passing result to the src/greeting.py bytes in the verified test candidate."
action = "WO-P3-001 retains the complete assertion record and states the fixture source commit and SHA-256 in the handoff evidence; the VREC then binds that evidence to the test candidate."
raised_by = "test-owner"
likelihood = 2
impact = 3
score = 6

[relations]
threatens = ["WO-P3-001"]

[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-12T05:11:21Z"
decided_by = "test-owner"
reason = "Recorded by harnessctl raise-risk."
+++

# Risk: Assertion evidence may not identify the tested source

## Description

The exact-greeting assertion runs on the native host against the local fixture copy, not inside the hosted test candidate. If the retained evidence does not identify the tested source digest and commit, a reviewer cannot tie the passing result to the src/greeting.py bytes in the verified test candidate.

## Next action

WO-P3-001 retains the complete assertion record and states the fixture source commit and SHA-256 in the handoff evidence; the VREC then binds that evidence to the test candidate.
