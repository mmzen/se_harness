+++
id = "REL-P3-001"
type = "release_contract"
title = "Test release 0.0.1 of the exact rehearsal greeting"
status = "draft"
owners = ["release-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[relations]
gates = ["WO-P3-001"]
+++

# Release Contract: Test release 0.0.1 of the exact rehearsal greeting

Synthetic test input supplied by the test owner. This is not a real human decision.

## Release unit

Test version `0.0.1` contains only WO-P3-001 and its verification contract
VER-P3-001. The final test candidate commit is not yet known. It will be taken
from the verified test VREC before this contract is completed and decided.

## Required evidence

To be completed after verification.

## Rollback criteria and procedure

Stop if the final candidate lacks complete verified coverage or release approval.
