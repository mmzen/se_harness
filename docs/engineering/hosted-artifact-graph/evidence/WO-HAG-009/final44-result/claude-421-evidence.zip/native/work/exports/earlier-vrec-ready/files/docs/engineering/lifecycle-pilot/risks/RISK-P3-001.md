+++
id = "RISK-P3-001"
type = "risk"
title = "Greeting assertion may not apply to the verified test candidate"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
description = "Check C1 runs on src/greeting.py from source fixture commit 5820415917e87b64d80bad2f7c39c6d18d692829, but the VREC binds a separate test candidate commit. If src/greeting.py in that candidate differs, the retained C1 result does not prove REQ-P3-001 for the verified candidate."
action = "Before the test verification decision, compare the SHA-256 of src/greeting.py in the exported VREC candidate snapshot with dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1 (VER-P3-001 C2); keep src/greeting.py unchanged in WO-P3-001."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-001"]
mitigated_by = ["WO-P3-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-12T06:42:09Z"
reason = "Synthetic test-owner input: mitigate the test risk using WO-P3-001; VER-P3-001 C2 compares src/greeting.py in the VREC candidate with the tested digest before the verification decision."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-12T06:41:32Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-12T06:42:09Z"
decided_by = "test-owner"
reason = "Synthetic test-owner input: mitigate the test risk using WO-P3-001; VER-P3-001 C2 compares src/greeting.py in the VREC candidate with the tested digest before the verification decision."
+++

# Risk: Greeting assertion may not apply to the verified test candidate

## Description

Check C1 runs on src/greeting.py from source fixture commit 5820415917e87b64d80bad2f7c39c6d18d692829, but the VREC binds a separate test candidate commit. If src/greeting.py in that candidate differs, the retained C1 result does not prove REQ-P3-001 for the verified candidate.

## Next action

Before the test verification decision, compare the SHA-256 of src/greeting.py in the exported VREC candidate snapshot with dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1 (VER-P3-001 C2); keep src/greeting.py unchanged in WO-P3-001.
