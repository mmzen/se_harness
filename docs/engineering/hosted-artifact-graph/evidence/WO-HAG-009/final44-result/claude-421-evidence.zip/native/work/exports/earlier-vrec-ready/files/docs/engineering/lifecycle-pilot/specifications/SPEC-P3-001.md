+++
id = "SPEC-P3-001"
type = "specification"
title = "Fixed rehearsal greeting return value"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
# What an implementation must do to conform. The Explorer shows this summary under the title.
contract = "The fixture function greeting() in src/greeting.py takes no arguments and returns a value equal to the text Hello rehearsal."

[relations]
specifies = ["REQ-P3-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T06:38:25Z"
decided_by = "test-owner"
reason = "Synthetic test-owner input: accept complete test definitions."
+++

# Specification: Fixed rehearsal greeting return value

Synthetic rehearsal input supplied by the test owner. This is not a real human decision.

## In plain words

`greeting()` always gives back the same fixed text, `Hello rehearsal`.

## Scope

This specification governs the return value and side effects of the function
`greeting()` in `src/greeting.py`. The check method, platform and evidence
location belong to the verification contract that verifies `REQ-P3-001`.

## Terms

- **Fixture function.** The function `greeting()` in `src/greeting.py` of the selected rehearsal source.

## Rules

**REH-GREET-001.** A call to `greeting()` with no arguments MUST return a value equal to the exact text `Hello rehearsal` (capital `H`, lowercase `rehearsal`, one ASCII space, no leading or trailing whitespace).

## Failure behaviour

| Trigger | Response | Diagnostic |
| --- | --- | --- |
| `greeting()` returns any value other than `Hello rehearsal` | The implementation does not conform to REH-GREET-001; an equality check reports failure | none |
| `greeting()` raises an exception | The implementation does not conform to REH-GREET-001; the check reports failure | none |

## Examples

**Given** the selected fixture source, **when** a caller calls `greeting()`, **then** the result equals `Hello rehearsal` (REH-GREET-001).

**Given** a changed fixture that returns `Hello Rehearsal`, **when** a caller calls `greeting()`, **then** the result does not equal `Hello rehearsal` and REH-GREET-001 is not met.

## Coverage

| Requirement | Rules |
| --- | --- |
| `REQ-P3-001` | REH-GREET-001 |

## Not decided here

- The internal form of the implementation, such as a literal or a constant.
- Side effects and return type beyond equality; no agreed need requires them.
