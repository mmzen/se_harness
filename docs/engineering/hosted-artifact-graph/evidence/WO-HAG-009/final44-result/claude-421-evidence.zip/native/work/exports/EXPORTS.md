# Export destinations (native test, claude-421)

- `earlier-vrec-ready/`: baseline `se-harness-artifact-baseline/v1:sha256:77b710ba8509957d454339bcfca35dfde4920509457d19a967f2d52c1e37fe4b` (after VREC-P3-001 capture, before its verification decision).
- `later-rls/`: final baseline after the test release assessment (filled in when exported).
