# Native hosted-workflow qualification report (claude-421)

All records below are synthetic test data in the private hosted test copy. They grant no real approval, verification, release or external authority. Git remains authoritative for real work. No push, tag, publication, installation or deployment occurred.

## Outcome

The full test lifecycle completed. The fixture function `greeting()` was inspected and passed the executed local assertion (`exact greeting passed`). The test change has an exported earlier snapshot and an exported later snapshot.

| Item | Final state | Accepting operation key (receipt) |
| --- | --- | --- |
| INT/CAP/REQ/SPEC/VER-P3-001 | approved | `n421-approve-defs-apply-01` (`sha256:8cb6e445…b92c`) |
| WO-P3-001 | implemented | `n421-complete-apply-01` (`sha256:0a72ffcf…cfac`) |
| RISK-P3-001 / DEC-P3-001 | mitigating / decided (`mitigate`, mitigated_by WO-P3-001) | `n421-decide-apply-01` (`sha256:413fdfc8…e70d`) |
| VREC-P3-001 | verified (quality-owner) | `n421-verify-vrec-apply-01` (`sha256:ebd194b7…b749`) |
| REL-P3-001 | approved (test-owner) | `n421-approve-rel-apply-01` (`sha256:2b93dc18…4120`) |
| RLS-P3-001 | released, version `0.0.1` (release-owner) | `n421-release-decision-apply-01` (`sha256:c42bf11f…bdf1`) |

The evaluator's final next step is `PROC-EXTERNAL-ACTION` / `STEP-EXTERNAL-ACTION` (`DR-EXTERNAL-ACTION`). No external action is authorized, so that step is stopped and no action was taken.

## Selected context and evaluator

The `remote status` output is context reporting, not a gate result. Record: `work/01-status`.

- Endpoint `http://127.0.0.1:58942`; project `5164638c-3986-46e8-8919-30bfb3868bed`.
- Status: ready, `authority_mode` sandbox-projection, schema_revision 2, `test_copy` true, `database_read_only_enforcement` "deferred: RISK-HAG-001".
- Evaluator: released 0.22.1, archive `cb35c3c4…3053`, payload `0e7b7c2b…7e9ff`.
- Client: 0.22.2, wheel `25f1d5af…413b`. The `identity` helper output matched `combination.json`, and every status component matched the combination.
- Gate passes come only from the lifecycle results below, for example `QG-G3-WORK-AUTHORIZATION` passing in `work/31-approve-wo-preview` and `work/34-start-preview`.

The identities are kept distinct:

| Identity | Value |
| --- | --- |
| Source fixture S | `5820415917e87b64d80bad2f7c39c6d18d692829` |
| Input baseline B (import) | `…bac18b91…` |
| VREC capture input baseline | `…d362307b…` |
| Test Git candidate P | `09397830d7489422774bb7f155bbb77a3d30272b` |
| Implementation candidate C | `2f6ecb1433ef98cf643e0f604ed2c4258a2261e2` (`qualification_candidate` in selection and identity output) |

P binds only the test VREC and RLS. It is not C.

## Authored definitions and content review

Drafts are in `work/drafts/` and were submitted with `revise-artifact`. The checklists I applied, from `ARTIFACT_AUTHORING.md`, are the `intent`, `capability`, `requirement`, `specification`, `verification`, `work_order` and `release_contract` checklists.

- **Evaluator check:** every final draft was admissible with an empty `incomplete` list.
- **Content review (separate from the evaluator check):**
  - The requirement and specification fix the exact text and failure behavior.
  - Rule `REH-GREET-001` is the only rule.
  - I dropped a draft side-effect rule because it served no agreed need and the available tool could not check it.
  - The VER has two checks: C1, the executed assertion, and C2, a tested-source digest comparison by inspection.
  - The REL was completed only after the verified VREC named candidate P.

**Recorded limitation:** the C1 tool makes no type assertion and records no Python version. It does not execute the failure path, and it runs on one platform only (native Windows, `client44` Python).

## Local assertion (C1) and identity check (C2)

| Check | Observed result | Evidence |
| --- | --- | --- |
| Source inspection | `src/greeting.py` contains `return 'Hello rehearsal'` (45 bytes, SHA-256 `dcbd486a…cecab1` = selected `greeting_sha256`) | Native Read; `lookup-file source/src/greeting.py` |
| C1 executed test | exit 0, stdout `exact greeting passed\n`, stderr empty, 0.0698 s | `work/evidence/greeting-assertion.json` (693 bytes, SHA-256 `9d19640a…512a`) |
| C1 in the test repo | carried unchanged by handoff | `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/greeting-assertion.json` |
| C2 inspection | `src/greeting.py` in exported candidate P is 45 bytes, SHA-256 `dcbd486a…cecab1`; also listed in the capture provenance file map | `encode-file` on `work/exports/earlier-vrec-ready/files/src/greeting.py`; `work/47-capture-apply.stdout.txt` `/provenance/candidates` |

No hosted service endpoint ran source tests.

## Risk and paired decision

- `RISK-P3-001` was raised by `test-executor`, with owner `test-owner`. Its subject: C1 ran on S, but the VREC binds P.
- `DEC-P3-001` blocked `WO-P3-001`.
- The supplied decision was `mitigate`, decided by `test-owner`, with `mitigated_by` `WO-P3-001` (`work/40-decide-apply`). The risk moved to `mitigating`. No risk acceptance was used.
- Observation: the RISK file SHA-256 in the preview (`b0421c25…`) differs from the apply (`b78d4b1c…`). The DEC bytes were identical in both. I did not determine the cause.

## Required demonstrations

| Case | Outcome | Evidence |
| --- | --- | --- |
| Stale preview after a selected draft changed | After preview `sha256:8e1409…` (v14/15), VER-P3-001 was revised (v15/13). Apply with the old versions was refused: 409 `HAG_REMOTE_STALE_PROJECT`. The old digest at the current versions was also refused: 409 `HAG_REMOTE_STALE_PREVIEW`. No receipt, no files, no affected artifacts. A fresh preview showed all five definitions still `draft` | `work/21-*`, `work/22-*`, `work/23-*`, `work/24-*`, `work/25-*` (`/evaluator_output/commands/0/result/state`) |
| Out-of-scope handoff refusal | A preview including `…/evidence/WO-P3-900/greeting-assertion.json` was refused: `HAG_REMOTE_EVALUATOR_REFUSED`, blocked by `QGP-G4I-PATHS: WEX201: changed path is outside execution scope`. The evaluator asked for escalation under `DR-REMEDIATION-SCOPE`; I did not escalate and removed the unneeded file instead. The valid preview was then accepted at the unchanged v20/18 | `work/41-*`, `work/42-*` |
| Uncertain reply recovery | Apply `n421-approve-defs-apply-01` returned transport outcome `unknown` (exit 2). Key lookup: `accepted`, receipt `sha256:8cb6e445…`, project 15→16 | `work/26-approve-defs-apply`, `work/27-lookup-approve-defs` |
| Identical retry, no duplicate | The same request file and key returned the same receipt with versions still 15→16. Its stdout SHA-256 `39cbf462…` is identical to the lookup's | `work/28-approve-defs-apply-identical-retry` |
| Changed request under accepted key | One reason text changed, same key: 409 `HAG_REMOTE_KEY_REUSE`. Status afterwards showed project_version 16 | `work/29-*`, `work/30-status-after-key-reuse` |

Requests are retained in `work/requests/`. The handoff base `12e301fbb05b5d9dea08fc51d703b8db40707a7b` is the `input_git_head` of the first accepted lifecycle mutation (`work/27-lookup-approve-defs`). The Git-derived change set from that base was complete (11 paths), and every path was in scope (`work/42-handoff-preview.stdout.txt`).

## Read-only MCP tools (all seven)

Exact requests and selected response fields are in `work/mcp/mcp-reads.json`. All responses were `complete: true`, with continuation null and no unresolved references. Views are the final baseline `…109b9c43…`, plus `…77b710ba…` for compare.

| Tool | Root | Result |
| --- | --- | --- |
| work-context | WO-P3-001 | 5 governing artifacts, 9 paths, RLS/VREC as dependencies, DEC relevant |
| check | RLS-P3-001 | released at P |
| lineage | REQ-P3-001 | Empty artifacts and relations. Reported as observed; I make no claim about coverage from it |
| lineage | RLS-P3-001 | 4 artifacts, 6 relations |
| impact | REQ-P3-001 | 8 artifacts, 16 relations |
| compare | earlier vs later | REL and RLS added, VREC revised |
| revision | VREC-P3-001 | status verified |
| cypher | WO-P3-001 | DECLARES query, 3 rows |

Both Cypher prerequisites were read before the query: `hosted-artifact-graph.md#physical-representation` and the bounded-Cypher section of `lifecycle-v2.md`. The full MCP responses exist only in the session transcript; no separate host file was saved.

## Exports

| Export | Destination | Baseline | Snapshot | Files |
| --- | --- | --- | --- | --- |
| Earlier (VREC ready, before decision) | `work/exports/earlier-vrec-ready/` | `…77b710ba…` | `sha256:040a1203…` | 25 |
| Later (RLS released) | `work/exports/later-rls-released/` | `…109b9c43…` | `sha256:0a90d0ec…` | 28 |

Records: `work/49-export-earlier`, `work/60-export-later`. Both report `independent_replay: not yet performed`. I did not clone the bundles or run the released 0.22.1 evaluator over them; that remains for the independent reviewer. The exported VREC and RLS files bind candidate P (read natively).

## Failures, interventions and uncertainties

These are the native errors from the observations snapshot `work/61-observations`. It records 179 calls and 8 native tool-error results, and it is complete for calls up to that snapshot.

1. A `read-text` call with a guessed path `inputs/client-help/draft-open.txt` failed with FileNotFoundError. This was my error. I recovered with `find-file`.
2. `draft-open` for the planned new WO `WO-P3-901` was refused: 404 `HAG_REMOTE_UNKNOWN_IDENTITY`. A context must anchor to an existing baseline WO. I opened it on `WO-P3-900` instead; the anchor does not modify `WO-P3-900`, and all `-900` records stayed unchanged.
3. Expected refusals: stale project, stale preview, key reuse, and the out-of-scope handoff.
4. The uncertain transport reply was recovered as described above.
5. The first export failed with `not_sent`: "Create the export parent directory first". I created `work/exports/` by writing `EXPORTS.md` with the native Write tool, then retried with a new record.

Other notes:

- There were no host permission denials. No permissions were changed.
- The v2 `prepare-release` schema requires `tag`, but RELEASE.md says to add a tag only for an explicitly selected value. I recorded the label `test-v0.0.1`. No Git tag was created. This is a contract tension that the test owner should resolve.
- The REL template's `gates` placeholder includes `VER-xxx`, but only REL→WO is a declared relation. I used `WO-P3-001`. `previous_release_tag` was omitted because no previous release exists.
- The planned-path coverage view (`check --planned-path`) is not exposed by the v2 contract. Scope coverage was assessed through the handoff preview instead.
- Calls after the observations snapshot (these report and observation writes) are not in that snapshot.

## File-read trace

The trace is captured in `work/61-observations` (`/file_reads`, `/observed_content_reads`).

The reads were triggered in this order:

1. `task.md` and `selection.json`, required by CLAUDE.md.
2. The setup skill and its hosted-context reference, `native-tools.md`, `combination.json` and `evaluator.json`.
3. The change skill and hosted-drafts reference. These routed to the released `DRAFT_DEFINITIONS`, `DEFINE_CHANGE`, `ARTIFACTS`, `DEFINITION_LINKS`, `ARTIFACT_AUTHORING`, `DRAFT_WORK_ORDERS` and `WORK_AND_EVIDENCE` documents.
4. Before the VER: `native-execution-tools.md`.
5. Before each action, the selectors in the hosted-test-lifecycle reference: `AUTHORIZE_WORK`, `AUTHORITY`, `EXECUTE_WORK`, `RISKS_AND_DECISIONS`, `VERIFY_OUTCOME`, `RELEASE`, `DELIVER_RESULT` and `RESULTS`.
6. The hosted-evidence reference, then the hosted-reads reference and the Cypher references.
7. Reference contracts `lifecycle-v2.json`/`.md`, `export-v2.json` and the `draft-open` schema view; `server/README.md` and `harnessctl-reference.md`.
8. The seven `-900` source records, `src/greeting.py` and the source manifest.

No qualification walkthroughs, fixture-authoring functions, test drivers or earlier transcripts were read.
