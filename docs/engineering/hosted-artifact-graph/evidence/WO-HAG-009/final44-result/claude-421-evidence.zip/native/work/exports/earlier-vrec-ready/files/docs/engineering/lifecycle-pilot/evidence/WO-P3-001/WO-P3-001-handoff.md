```toml
artifact = "WO-P3-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "509c48d7a567fcfed192fdf001596b84564a6fcb7cc63f8f941f5fe6f28263bf"
rebound_at = "2026-10-12T06:43:36Z"
```

# WO-P3-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
