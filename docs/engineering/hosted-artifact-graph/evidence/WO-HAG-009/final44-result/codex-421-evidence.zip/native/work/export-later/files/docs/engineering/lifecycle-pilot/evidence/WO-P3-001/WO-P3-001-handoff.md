```toml
artifact = "WO-P3-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "50f4daec849f1e98aebc93fb95f2462bff69e07abef5050f4e8d6c08f10a875e"
rebound_at = "2026-10-12T06:45:07Z"
```

# WO-P3-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
