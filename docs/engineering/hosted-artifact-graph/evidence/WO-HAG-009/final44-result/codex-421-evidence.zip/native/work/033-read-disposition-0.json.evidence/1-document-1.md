+++
id = "DEC-P3-001"
type = "decision"
title = "Answer to the threat Unbound local evidence could be mistaken for candidate assurance"
status = "decided"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
kind = "question"
question = "How is the threat 'Unbound local evidence could be mistaken for candidate assurance' answered: accept, avoid or mitigate?"
raised_by = "test-executor"
recommendation = "mitigate"

[[options]]
id = "accept"
label = "Accept the threat; record a residual and a revisit trigger."

[[options]]
id = "avoid"
label = "Avoid the threat by a design change recorded in an ADR or a decision."

[[options]]
id = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."

[relations]
concerns = ["RISK-P3-001", "WO-P3-001"]
blocks = ["WO-P3-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-12T06:41:51Z"
reason = "Supplied synthetic choice: mitigate through the bounded greeting work and commit-bound evidence."

[[lifecycle_events]]
from = "open"
to = "decided"
decided_at = "2026-10-12T06:41:51Z"
decided_by = "test-owner"
reason = "Supplied synthetic choice: mitigate through the bounded greeting work and commit-bound evidence."
+++

# Decision: Answer to the threat Unbound local evidence could be mistaken for candidate assurance

## Question

How is the threat 'Unbound local evidence could be mistaken for candidate assurance' answered: accept, avoid or mitigate? The description and the threatened artifacts are on RISK-P3-001.

## Options

- `accept`: Accept the threat; record a residual and a revisit trigger.
- `avoid`: Avoid the threat by a design change recorded in an ADR or a decision.
- `mitigate`: Mitigate the threat through a work order; the risk closes under verified coverage.

## Recommendation

The raiser recommends `mitigate`.

## Disposition

Written by `harnessctl decide`; do not edit by hand. Disposing this decision
moves RISK-P3-001 to the state the chosen option names, in the same act.
