+++
id = "SPEC-P3-001"
type = "specification"
title = "Exact fixture greeting contract"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
contract = "The selected greeting() call returns exactly Hello rehearsal."

[relations]
specifies = ["REQ-P3-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T06:39:17Z"
decided_by = "test-owner"
reason = "Supplied synthetic acceptance of the complete greeting test definition; no real authority."
+++

# Exact fixture greeting contract

## Scope and rules

This contract covers the no-argument call to `greeting()` in `src/greeting.py`.

### GREET-EXACT-001

Calling `greeting()` returns exactly `Hello rehearsal`.

## Failure behavior and example

An exception or unequal return value fails conformance. There is no fallback or error recovery requirement. Given the selected fixture, calling `greeting()` produces `Hello rehearsal` under GREET-EXACT-001.

## Coverage

| Requirement | Rules |
| --- | --- |
| `REQ-P3-001` | GREET-EXACT-001 |

## Design review

The existing literal return is the smallest implementation of this fixed outcome. No source modification, abstraction, external dependency, or architecture decision is needed.
