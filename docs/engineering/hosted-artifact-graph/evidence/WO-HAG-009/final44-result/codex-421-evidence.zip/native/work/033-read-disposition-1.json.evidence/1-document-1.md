+++
id = "RISK-P3-001"
type = "risk"
title = "Unbound local evidence could be mistaken for candidate assurance"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
description = "The fixture assertion alone does not bind the disposable Git candidate. The operator could mistake source evidence or a service gate for verification of another candidate."
action = "Retain exact local assertion bytes and source identity under WO-P3-001, then capture and assess commit-bound verification before test release."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-001"]
mitigated_by = ["WO-P3-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-12T06:41:51Z"
reason = "Supplied synthetic choice: mitigate through the bounded greeting work and commit-bound evidence."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-12T06:40:38Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-12T06:41:51Z"
decided_by = "test-owner"
reason = "Supplied synthetic choice: mitigate through the bounded greeting work and commit-bound evidence."
+++

# Risk: Unbound local evidence could be mistaken for candidate assurance

## Description

The fixture assertion alone does not bind the disposable Git candidate. The operator could mistake source evidence or a service gate for verification of another candidate.

## Next action

Retain exact local assertion bytes and source identity under WO-P3-001, then capture and assess commit-bound verification before test release.
