+++
id = "RISK-P3-001"
type = "risk"
title = "Unbound local evidence could be mistaken for candidate assurance"
status = "raised"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
description = "The fixture assertion alone does not bind the disposable Git candidate. The operator could mistake source evidence or a service gate for verification of another candidate."
action = "Retain exact local assertion bytes and source identity under WO-P3-001, then capture and assess commit-bound verification before test release."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-001"]

[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-12T06:40:38Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."
+++

# Risk: Unbound local evidence could be mistaken for candidate assurance

## Description

The fixture assertion alone does not bind the disposable Git candidate. The operator could mistake source evidence or a service gate for verification of another candidate.

## Next action

Retain exact local assertion bytes and source identity under WO-P3-001, then capture and assess commit-bound verification before test release.
