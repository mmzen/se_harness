+++
id = "REL-P3-001"
type = "release_contract"
title = "Assess the exact greeting test release 0.0.1"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
candidate_commit = "fc8b1f48ed5258a65a5aad271f91429605496911"

[relations]
gates = ["WO-P3-001"]
+++

# Assess the exact greeting test release 0.0.1

## Release unit

This contract covers only synthetic version 0.0.1 in the selected private hosted test project. It includes WO-P3-001 and the unchanged greeting source represented by candidate_commit. There is no previous test release tag. The release record must bind final verified VREC-P3-001 at that exact candidate, with VER-P3-001 coverage of REQ-P3-001.

## Required evidence

Before preparation, inspect the final verified VREC-P3-001 and compare its commit with candidate_commit. Require the retained local assertion to exit 0 with exact stdout `exact greeting passed` followed by LF. Its exact bytes are at docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json, SHA-256 44a0f3c04e1cbaa27fc4468925a1b1af964a55c8975566669db4f87a5d6c6cc3. The completion assessment and complete Git-based handoff retain scope, identities, results and limits. Inspect the released evaluator sidecars and require passing release preparation and transition gates.

## Compatibility and migration

The source remains byte-identical to the selected fixture. No interface or data migration is included. The single local equality check claims no cross-platform or production assurance.

## Security and provenance

Preserve source fixture commit 5820415917e87b64d80bad2f7c39c6d18d692829 separately from this disposable candidate. Actual qualification implementation candidate 2f6ecb1433ef98cf643e0f604ed2c4258a2261e2 is not verified by these records. Use released evaluator 0.22.1 and preserve exact export bytes and Git history for independent review. The service does not execute source tests.

## Promotion policy and decision triggers

The selected route is test release preparation and assessment only. test-owner supplies definition approval; release-owner prepares the test RLS and supplies the synthetic release decision only after its gates and this evidence pass. A tag field is a test record label only. No push, real tag, publication, installation, deployment or external delivery is included.

## Rollback criteria and procedure

A candidate mismatch, changed evidence, missing verified coverage or failed gate stops preparation or release assessment. Preserve the refused result and exact prior records, withhold the test decision, and report the required correction. Any new scope or replacement candidate needs its own eligible procedure and decision. There is no deployed payload to roll back.

## Post-assessment observation

Read back the final record and export its immutable baseline to a new local destination. Preserve the earlier export separately. Report export success separately from independent Git reconstruction and released-evaluator replay, which the independent reviewer performs. No ongoing operational service obligation is created.
