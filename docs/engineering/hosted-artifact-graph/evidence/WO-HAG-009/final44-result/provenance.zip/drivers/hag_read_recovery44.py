import hashlib,json,re
from pathlib import Path
r=Path(__file__).parent/'h44/f/claude-421';n=r/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
 assert not f.exists(),f
 f.write_bytes((json.dumps(v,indent=2)+'\n').encode())
calls={};reads=[];events=[]
for line,raw in enumerate((n/'events.jsonl').read_text().splitlines(),1):
 try:e=json.loads(raw)
 except ValueError:continue
 events.append((line,e))
 for b in e.get('message',{}).get('content',[]) if isinstance(e.get('message'),dict) else []:
  if b.get('type')=='tool_use':calls[b['id']]=(line,b)
for line,e in events:
 for b in e.get('message',{}).get('content',[]) if isinstance(e.get('message'),dict) else []:
  if b.get('type')!='tool_result':continue
  call=calls.get(b.get('tool_use_id'))
  if not call or ' instructions ' not in str(call[1].get('input')):continue
  text=b.get('content');match=re.search(r'Full output saved to: ([^\n]+)',text) if isinstance(text,str) else None
  if not match:continue
  f=Path(match.group(1));raw=f.read_bytes();value=json.loads(raw)
  matching=[(i,c) for i,c in calls.values() if c.get('name')=='Read' and c['input'].get('file_path')==str(f)]
  exact=False;return_line=None
  for i,c in matching:
   for j,event in events:
    for out in event.get('message',{}).get('content',[]) if isinstance(event.get('message'),dict) else []:
     if out.get('type')=='tool_result' and out.get('tool_use_id')==c['id'] and not out.get('is_error'):
      try:exact=json.loads(re.sub(r'^\d+\t','',out['content'],flags=re.M))==value
      except (ValueError,TypeError):pass
      if exact:return_line=j
  assert exact,(call[0],str(f))
  target=r/'persisted-instructions'/f.name;target.parent.mkdir(exist_ok=True);target.write_bytes(raw)
  reads.append({'call_line':call[0],'result_line':line,'full_bytes':len(raw),'sha256':sha(raw),'retained_path':target.relative_to(r).as_posix(),'successful_read_return':return_line,'full_content_recovered':exact})
put(r/'persisted-instruction-recovery.json',{'reads':reads,'method':'Exact parsed returned host Read content compared to the complete host-saved instruction output; original saved bytes retained.'})

print(len(reads), "complete host-persisted instruction reads verified")
