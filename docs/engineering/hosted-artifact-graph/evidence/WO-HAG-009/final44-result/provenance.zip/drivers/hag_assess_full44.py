"""Mechanical C44 receipt/export checks; semantic assessment is recorded separately."""
import hashlib,json,sys,tomllib
from pathlib import Path
W=Path(__file__).parent;O=W/'h44/f';host=sys.argv[1];trial=host+'-421';r=O/trial;n=r/'native';w=n/'work'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
meta=lambda f:tomllib.loads(f.read_text().split('+++')[1])
replay=load(r/'replay44/assessment.json');summary=load(O/(trial+'-summary.json'))
assert len(replay['cases'])==12 and all(x['outcome']=='passed' for x in replay['cases'])
exports=[x for x in replay['exports'] if x['case'].startswith('native-')];assert len(exports)>=2
parity=[load(f) for f in (O/'native-parity-full44').glob('*'+trial+'*.json')]
tools={'revision','work-context','compare','impact','lineage','check','cypher'}
matched={x['tool'] for x in parity if x.get('exact_match') and x.get('http_status')==200}
assert tools.issubset({x['tool'] for x in parity})
if host=='claude':assert tools.issubset(matched)
manifests=[f for f in w.rglob('manifest.json') if (f.parent/'history.bundle').is_file() and (f.parent/'files').is_dir()]
originals=list((n/'inputs/source').rglob('*-900.md'))+[n/'inputs/source/src/greeting.py'];preserved=[];final=[]
for f in manifests:
 m=load(f);assert m['test_copy'] is True
 for source in originals:assert m['snapshot']['files'][source.relative_to(n/'inputs/source').as_posix()]['sha256']==sha(source.read_bytes())
 preserved.append({'export':f.parent.relative_to(w).as_posix(),'original_files':len(originals)})
 records=list((f.parent/'files').rglob('RLS-P3-*.md'))
 if any(meta(x)['status']=='released' for x in records):final.append(f.parent/'files/docs/engineering/lifecycle-pilot')
assert final
final=final[-1];vr=next(f for f in final.rglob('VREC-P3-*.md') if meta(f)['status']=='verified');rl=next(f for f in final.rglob('RLS-P3-*.md') if meta(f)['status']=='released')
vrec,rls=meta(vr),meta(rl);assert vrec['commit']==rls['commit']
actors=[]
for f in final.rglob('*.md'):
 try:m=meta(f)
 except (ValueError,IndexError):continue
 if m['id'].endswith('-900'):continue
 for e in m.get('lifecycle_events',[]):
  expected=None
  if e['to']=='approved':expected='test-owner'
  elif m['type']=='work_order' and e['to'] in ('in_progress','implemented'):expected='test-executor'
  elif m['type']=='verification_record' and e['to']=='verified':expected='quality-owner'
  elif m['type']=='release_record' and e['to']=='released':expected='release-owner'
  if expected:assert e['decided_by']==expected,(m['id'],e,expected)
  actors.append({'id':m['id'],'to':e['to'],'actor':e['decided_by']})
assert load(r/'input-integrity.json')['all_unchanged'] and load(r/'boundary-comparison.json')['equal']
assert load(n/'session.json')['exit']==0
value={'candidate':'2f6ecb1433ef98cf643e0f604ed2c4258a2261e2','trial':trial,'accepted_operations_replayed':12,'native_exports':len(exports),'mcp_observations':len(parity),'mcp_tools_exactly_matched':sorted(matched),'mcp_unmatched_observations':[{'tool':x['tool'],'status':x.get('http_status'),'native_call_id':x['native_call_id']} for x in parity if not x.get('exact_match')],'test_candidate':vrec['commit'],'actors':actors,'originals':preserved,'boundaries_unchanged':True,'metrics':{k:summary.get(k) for k in ('wall_seconds','native_calls','observed_tool_items','native_call_count_complete','peak_input_context')},'native_failed_items':len(summary['native_failures']),'content_review':'Separate manual assessment required; this script does not decide completeness.'}
f=r/'mechanical-assessment.json';assert not f.exists();f.write_bytes((json.dumps(value,indent=2)+'\n').encode())
print(json.dumps({k:value[k] for k in ('trial','accepted_operations_replayed','native_exports','mcp_tools_exactly_matched','mcp_unmatched_observations','test_candidate')}))
