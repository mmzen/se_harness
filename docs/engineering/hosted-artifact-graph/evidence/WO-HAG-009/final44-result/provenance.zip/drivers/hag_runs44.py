"""Fresh native trials on one exact candidate; unchanged accepted outcomes."""
import json,sys
from pathlib import Path
W=Path(__file__).parent;O=W/'h44';C=json.loads((O/'candidate-44.json').read_text())['commit']
group,mode,host=sys.argv[1:4]
if group=='full':
 source=(W/'hag_full40.py').read_text().replace('hag-final40-20261012','h44/f').replace('hag-authority38-20261012','h44').replace('361','421')
 for a,b in [('candidate-38','candidate-44'),('package38','package44'),('client38','client44'),('build38','build44'),('native-authority38','native-entry44'),('hag-final40-','hag-final44-'),('10.231.108.0/22','10.231.132.0/22')]:source=source.replace(a,b)
 sys.argv=[__file__,mode,host]
elif group=='eff':
 source=(W/'hag_eff41.py').read_text().replace('hag-eff41-20261012','h44/e').replace('hag-authority38-20261012','h44')
 for a,b in [('candidate-38','candidate-44'),('package38','package44'),('client38','client44'),('build38','build44'),('native-authority38','native-entry44'),('hag-eff41-','hag-eff44-'),('10.231.112.0/22','10.231.136.0/22'),('371','431'),('372','432'),('373','433'),('374','434')]:source=source.replace(a,b)
 source=source.replace('try:exec(','''source=source.replace("split('## Entry and tools'", "split('## Inputs and boundaries'")
try:exec(''')
 sys.argv=[__file__,mode,host,sys.argv[4]]
else:raise ValueError(group)
source=source.replace('ee86a842550c19fb6a56913841757b42df9ecaec',C).replace('dfeb5adf1f640dea48a53b7a446e49e93c31004a',C)
exec(compile(source,'native42-'+group,'exec'),{'__file__':str(W/'hag_full40.py' if group=='full' else W/'hag_eff41.py'),'__name__':'__main__'})
