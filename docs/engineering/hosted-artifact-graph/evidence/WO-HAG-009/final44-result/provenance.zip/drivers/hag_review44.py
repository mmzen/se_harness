"""Read-only final observations and independent partial replay for diagnostic28."""
import json,os,subprocess,sys,hashlib
from pathlib import Path
import hag_efficiency_plan as p
W,R=p.W,p.R;O=W/'h44/f';p.O=O
H=Path(r'C:\Users\mathi\AppData\Local\Python\pythoncore-3.14-64\python.exe')
trial=sys.argv[1];root=O/trial;native=root/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,x):
 assert not f.exists(),f
 f.write_bytes((json.dumps(x,indent=2)+'\n').encode())
mode=sys.argv[2]
if mode=='observe':
 source=(W/'hag_full27_review.py').read_text().replace('hag-lifecycle-native27-20261010','h44/f')
 sys.argv=[str(W/'hag_full27_review.py'),trial,'final']
 exec(compile(source,'diagnostic28-observer','exec'),{'__file__':str(W/'hag_full27_review.py'),'__name__':'__main__'})
 before=load(root/'boundary-before-native.json');after=load(root/'boundary-after-native.json')
 put(root/'boundary-comparison.json',{'equal':before==after,'before_sha256':sha((root/'boundary-before-native.json').read_bytes()),'after_sha256':sha((root/'boundary-after-native.json').read_bytes())})
 print('boundary_equal',before==after)
elif mode=='replay':
 result=p.run(trial+'-independent-replay',[H,'-X','utf8','-B',R/'tests/hosted_artifact_graph/assess_native.py','--native-root',native,'--selection',root/'selection.json','--credentials',root/'credentials.json','--evaluator-python',p.P,'--output',root/'replay44'],allowed=(0,1,2))
 print(json.dumps(result)[:1800])
elif mode=='stop':
 s=load(root/'selection.json')
 os.environ.update(HAG_SERVICE_IMAGE='harness-hag:native-entry44',HAG_HTTP_PORT=s['endpoint'].rsplit(':',1)[1],HAG_CONFIG_DIRECTORY=str(root/'configuration'),HAG_CREDENTIAL_FILE=str(root/'credentials.json'),HAG_SOURCE_VOLUME=s['source_volume'])
 result=p.run(trial+'-stop',['docker','compose','-p',s['compose_project'],'-f',W/'h44/package44/candidate-source/server/compose.yaml','-f',root/'network.json','stop','graph','service'])
 print(json.dumps({'trial':trial,'containers':'stopped','volumes':'preserved'}))
else:raise ValueError(mode)
