"""Retain C44 complete native qualification and focused cases."""
import hashlib,json,re,sys,zipfile
from pathlib import Path
import hag_efficiency_plan as p
W=p.W;O=W/'h44';mode=sys.argv[1]
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
groups=[('f','WO-HAG-009','final44-result',['claude-421','codex-421','codex-421-reads']),('e','WO-HAG-011','focused44-result',['claude-431','codex-431','claude-432','claude-433','claude-434','codex-432'])]
if mode=='scope':
 p.O=O
 for group,wo,name,trials in groups:
  names=['assessment.md','provenance.zip','provenance-inventory.json']+[t+s for t in trials for s in ('-evidence.zip','-visible.md','-inventory.json')]
  paths=[(p.D/'evidence'/wo/name/n).relative_to(p.R).as_posix() for n in names]
  v=p.gov(name+'-scope','check',p.R,'--artifact',wo,'--checkpoint','scope','--changes-complete',*[x for path in paths for x in ('--changed-path',path)],'--json')
  assert v['compliance']['status']=='pass';print(name,'scope pass',flush=True)
elif mode=='retain':
 for group,wo,name,trials in groups:
  assert (O/(name+'-assessment.md')).exists()
  for trial in trials:
   r=O/group/trial
   assert (r/'native/session.json').exists() and load(r/'boundary-comparison.json')['equal']
   assert (r/'independent-assessment.json').exists()
 for group,wo,name,trials in groups:
  assert json.loads(load(O/(name+'-scope.json'))['stdout'])['compliance']['status']=='pass'
  E=p.D/'evidence'/wo/name
  if E.exists():assert not list(E.iterdir()),E
  else:E.mkdir()
  source=(W/'hag_retain26.py').read_text().replace('hag-efficiency-compact-pointers-20261010','h44/'+group)
  source=source.replace("dest=h.D/'evidence/WO-HAG-011'", "dest=h.D/'evidence/"+wo+'/'+name+"'")
  names=['status-after-native.json','input-fidelity.json','mechanical-assessment.json','independent-final-reply.md','persisted-instruction-recovery.json','initial-status.json','independent-final-status.json','independent-final-status-command.json','independent-status-recovery.json','input-integrity.json','instruction-read-trace.json','boundary-before-native.json','boundary-after-native.json','boundary-comparison.json','costs.json','command-cost-supplement.json','review-facts.json','native-call-index.json','observer-recovery-observe.json','observer-recovery-replay.json','claim-audit.json','output-boundary-audit.json','refusal-receipt-observations.json','refused-request-receipts.json']
  source=source.replace("'immutable-baseline-review.json'):","'immutable-baseline-review.json',"+','.join(repr(n) for n in names)+"):")
  extra="""for observed in list(root.glob('original-*-request.json'))+list(root.glob('original-*-read.json'))+list((root/'persisted-instructions').glob('*'))+[root/'independent-originals.json']:
 if observed.exists():files['assessment/'+observed.name]=observed.read_bytes()
for observed in (root/'replay44').glob('*.json'):files['replay/'+observed.name]=observed.read_bytes()
for directory in h.O.glob('native-parity-*44'):
 for observed in directory.glob('*'+trial+'*.json'):files['parity/'+directory.name+'/'+observed.name]=observed.read_bytes()
for suffix in ('-independent-replay.json','-stop.json'):
 observed=h.O/(trial+suffix)
 if observed.exists():files['proctor/'+observed.name]=observed.read_bytes()
"""
  source=source.replace("summary=h.O/(trial+'-summary.json')",extra+"summary=h.O/(trial+'-summary.json')")
  compile(source,'retain44','exec')
  for trial in trials:
   sys.argv=[__file__,trial];exec(compile(source,'retain44','exec'),{'__file__':str(W/'hag_retain26.py'),'__name__':'__main__'})
  files={}
  for f in (O/group).glob('*.json'):
   if any(x in f.name for x in ('live-probe','version','auth')) and 'review' not in f.name:continue
   files['observations/'+f.name]=f.read_bytes()
  for f in O.glob('*.json'):
   if any(x in f.name for x in ('candidate-44','comparison','client-equality','build44-replay','ci44','integration-archive','resume-421','retained-archive-check','parity44-recovery')):files['candidate/'+f.name]=f.read_bytes()
  files['drivers/full44-parity-original.py']=(O/'full44-parity-original.py').read_bytes()
  for name0 in ('hag_runs44.py','hag_full40.py','hag_eff41.py','hag_native26.py','hag_native27.py','hag_full27.py','hag221_execute.py','hag_efficiency_plan.py','hag_full44_probe.py','hag_eff44_probe.py','hag_review44.py','hag_full27_review.py','hag_trace44.py','hag_full27_trace.py','hag_facts44.py','hag_observe44.py','hag_input44.py','hag_full44_parity.py','hag_native_parity19.py','hag_retain44.py','hag_retain36.py','hag_retain26.py','hag_assess_full44.py','hag_read_recovery44.py','hag_originals44.py','hag_reads44.py','hag_finish44.py'):
   files['drivers/'+name0]=(W/name0).read_bytes()
  tokens=[x['token'].encode() for f in (O/group).glob('*/credentials.json') for x in load(f)['principals']]
  for n,raw in files.items():
   assert not any(t in raw for t in tokens),n
   assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),n
  with zipfile.ZipFile(E/'provenance.zip','x',zipfile.ZIP_DEFLATED) as z:
   for n,raw in sorted(files.items()):z.writestr(n,raw)
  (E/'provenance-inventory.json').write_bytes((json.dumps({'archive':'provenance.zip','sha256':sha((E/'provenance.zip').read_bytes()),'files':[{'path':n,'bytes':len(raw),'sha256':sha(raw)} for n,raw in sorted(files.items())],'omissions':'No raw provider events, private reasoning, credential stores or test tokens. Native failures and observer results retained.'},indent=2)+'\n').encode())
  (E/'assessment.md').write_bytes((O/(name+'-assessment.md')).read_bytes())
else:raise ValueError(mode)
