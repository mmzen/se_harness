"""Retain independent C44 read-recovery assessment and the reviewed full verdict."""
import hashlib,json,sys
from pathlib import Path
W=Path(__file__).parent;O=W/'h44/f';R=W/'hag221proposal'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
 assert not f.exists(),f
 f.write_bytes((v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
r=O/'codex-421-reads';n=r/'native'
before=load(r/'boundary-before-native.json');after=load(r/'boundary-after-native.json')
assert before==after
assert load(r/'initial-status.json')==load(r/'status-after-native.json')
session=load(n/'session.json');assert session['exit']==0 and not session['timed_out']
inventory=load(n/'inputs/inventory.json');checks=[]
for x in inventory['files']:
 f=Path(x['path']);checks.append({'path':x['relative'],'expected':x['sha256'],'actual':sha(f.read_bytes())})
assert all(x['expected']==x['actual'] for x in checks)
parity=[load(f) for f in (O/'native-parity-reads44').glob('*codex-421-reads*.json')]
assert len(parity)==2 and {x['tool'] for x in parity}=={'work-context','cypher'}
assert all(x['exact_match'] and x['http_status']==200 and x['native_result']['complete'] and x['native_result']['continuation'] is None for x in parity)
sys.path.insert(0,str(R/'tests/hosted_artifact_graph'))
from summarize_native import summarize
summary=summarize(n);put(O/'codex-421-reads-summary.json',summary)
assert summary['calls_by_tool'].get('work-context',0)<=1  # capture names can be provider-qualified
put(r/'boundary-comparison.json',{'equal':True,'before_sha256':sha((r/'boundary-before-native.json').read_bytes()),'after_sha256':sha((r/'boundary-after-native.json').read_bytes()),'service_status_equal':True})
put(r/'input-integrity.json',{'all_unchanged':True,'files':checks})
put(r/'independent-assessment.json',{
 'trial':'codex-421-reads','candidate':'2f6ecb1433ef98cf643e0f604ed2c4258a2261e2','overall':'pass',
 'scope':'NQ-03 two-tool read-only supplement; not a new full lifecycle run.',
 'tools':['work-context','cypher'],'exact_mcp_http_matches':2,'project_version_before_and_after':29,
 'service_status_equal':True,'repository_and_settings_unchanged':True,'inputs_unchanged':True,
 'content_review':'Manually inspected native report and exact requests/responses. Complete envelopes are accurately separated from checkpoint-free not_assessable lifecycle context. Report leaves HTTP parity to this independent review and discloses the recovered reader-size failures.',
 'failed_native_items':len(summary['native_failures']),
 'interventions':{'corrective_prompts':0,'operator_workflow_mutations':0,'scripted_completion':False},
 'limits':['Two early comparisons were missing because the proctor observer watched the wrong trial directories. This separate fresh native session recovers only those tool comparisons at the unchanged final baseline. Original stale HTTP 409 comparisons remain failures of observation timing.','No automatic startup, desktop, real assurance, release or authority-switch claim.','Only visible native tool/result evidence is assessed; incomplete capture is not an exhaustive call count.']})
r=O/'codex-421';v=load(r/'mechanical-assessment.json')
v.update({'content_review':{'outcome':'pass','method':'Manual review of new intent, verification and release contract; native report, actual refusal/recovery records, trace and independent receipt/export replay.',
 'observations':['The new intent names the operator outcome and an observable package-availability measure. Historical records and fixture source remain byte-identical.','The verification contract derives Hello rehearsal from accepted test definitions and specifies the exact local helper, source digest, Windows context, 0.22.1 governor and evidence destination. It claims no separate type assertion.','Twelve accepted operations replay and four exact native exports reconstruct with the original candidate binding. Synthetic actor roles match the supplied test decisions.','Stale preview, out-of-scope handoff, lost reply, identical retry and changed-key conflict are retained and correctly explained.','Nine visible failed native items remain recorded; capture limits and recovered local command errors are disclosed.','All seven MCP tool comparisons pass when the original five successful tool comparisons are combined with the separately assessed two-tool immutable-view recovery.']},
 'overall':'pass','cases':{f'NQ-0{i}':'pass' for i in range(1,6)},
 'interventions':{'corrective_prompts':0,'operator_workflow_mutations':0,'scripted_completion':False},
 'read_recovery':'../codex-421-reads/independent-assessment.json',
 'observations_preserved':['The original proctor observer watched earlier trial directories. Four delayed Codex comparisons returned stale HTTP 409; they remain retained and do not count as matches. Later original checks supply check parity; the separate read session supplies work-context and cypher.','Native report preserves null archive/payload fields in the VREC origin-version inspection, distinct from the fully pinned RLS payload inspection. Exact sidecars and successful independent released replay are retained.'],
 'limits':['Observed Windows CLI/component combination only; no desktop or automatic startup/compaction qualification.','Synthetic records do not verify the real candidate or authorize delivery.','Concurrent disposable sessions do not establish isolated performance.','Passing full lifecycle qualification does not repair the two failed Claude focused repetitions.']})
put(r/'independent-assessment.json',v)
print(json.dumps({'codex_full':'pass with separately disclosed two-tool read recovery','read_recovery':'pass','read_seconds':summary['wall_seconds'],'read_observed_items':summary['observed_tool_items'],'read_failed_items':len(summary['native_failures'])}))
