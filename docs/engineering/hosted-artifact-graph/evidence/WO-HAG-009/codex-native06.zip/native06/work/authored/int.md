+++
id = "INT-N06-001"
type = "intent"
title = "Make the greeting inspection independently reviewable"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
outcome = "An operator can inspect greeting() and prove its exact return value with an exported engineering record."
[relations]

+++

# Make the greeting inspection independently reviewable

Synthetic test record. Supplied actor labels have no real engineering authority.

## Problem
The operator has a fixed local fixture but needs a retained, inspectable test record for this independent trial.

## Success measures
At handoff, the operator can locate one exact assertion result and two immutable exports with their candidate identities. Baseline: not measured in this trial. Review occurs once at trial handoff.

## Scope limits
Inspect the existing fixture and retain evidence. No source change, real approval, installation, Git push, tag, publication or deployment.

