# Local greeting inspection

The native executor inspected the supplied immutable inputs/source/src/greeting.py. It defines greeting() and directly returns the literal 'Hello rehearsal'. No source edit was needed or made.

Source commit S: 5820415917e87b64d80bad2f7c39c6d18d692829. Source SHA-256: dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1, matching selection.json.

The fixed native helper executed the exact local equality assertion. The complete sibling assertion.json records the actual Python executable, argument array, working directory, exit 0, stdout "exact greeting passed\n", and empty stderr. The expected literal was specified in REQ-N06-001 before execution. The service did not execute the test.

The candidate client belongs to implementation C 0dbb8ea19f28994da7abc7ecbab08c8db430dc0c from combination.json. This local fixture test does not verify that implementation. The service will bind the retained evidence to its disposable candidate P; the later VREC must preserve that original P.

Review: the source already meets the requirement, so inspection and one exact assertion are sufficient. There are no source, packaging, CI, or runtime changes. Synthetic risk RISK-N06-001 and decision DEC-N06-001 retain the supplied mitigate choice through WO-N06-001. Exports and independent replay remain separately assessable outcomes.
