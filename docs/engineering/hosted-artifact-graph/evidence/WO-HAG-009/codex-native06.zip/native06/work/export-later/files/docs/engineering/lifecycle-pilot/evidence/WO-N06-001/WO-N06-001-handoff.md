```toml
artifact = "WO-N06-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "d776c651688431a63666ebe449792d507d6c6f9a60f33d0c25d89cd77a79fba9"
rebound_at = "2026-10-07T05:52:29Z"
```

# WO-N06-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
