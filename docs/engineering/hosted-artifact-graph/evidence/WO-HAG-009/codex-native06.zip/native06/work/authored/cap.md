+++
id = "CAP-N06-001"
type = "capability"
title = "Inspect and prove the local greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
ability = "An operator can inspect the immutable greeting fixture and follow an exact local assertion into exported test records."
[relations]
derives_from = ["INT-N06-001"]
+++

# Inspect and prove the local greeting

Synthetic test record. Supplied actor labels have no real engineering authority.

## Capability
Given the supplied local Git-blob snapshot, the operator can inspect src/greeting.py, run the bounded local assertion, and inspect its evidence and candidate binding in the exported test record.

## Limits
The hosted service records test evidence; it does not execute source tests.

