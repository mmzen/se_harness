+++
id = "REL-N06-001"
type = "release_contract"
title = "Bind test release 0.0.1 to verified greeting evidence"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"

[relations]
gates = ["WO-N06-001"]
+++

# Bind test release 0.0.1 to verified greeting evidence

Synthetic test record. Supplied actor labels have no real engineering authority.

## Release scope
Test version 0.0.1 covers only WO-N06-001. The release record must bind the exact candidate from its accepted test verification record and retained local assertion evidence.

## Gates and evidence
Require completed bounded work, passed verification, exact evidence digests and the supplied release-owner decision after released 0.22.1 gates pass. Retain the exported files, manifest and self-contained Git bundle.

## Rollback conditions
If replay or exact-byte comparison fails, withhold use of the test release and preserve the failed evidence for review. This disposable test permits no production release.

## Authority limits
A recorded tag name is test metadata only. No tag creation, push, publication, installation or deployment is authorized.

