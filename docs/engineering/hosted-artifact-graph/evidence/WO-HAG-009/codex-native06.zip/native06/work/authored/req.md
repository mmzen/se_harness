+++
id = "REQ-N06-001"
type = "requirement"
title = "Prove the exact Hello rehearsal return"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
statement = "Calling the supplied fixture greeting() returns exactly the string Hello rehearsal."
verification_method = ["test", "inspection"]
priority = "must"
source = "Native independent trial outcome supplied by the test owner"
measure = "Exact string equality, with the source digest and local assertion output retained."
[relations]
derives_from = ["CAP-N06-001"]
+++

# Prove the exact Hello rehearsal return

Synthetic test record. Supplied actor labels have no real engineering authority.

## Acceptance
Calling greeting() with no arguments returns exactly `Hello rehearsal`, including case and the single space, without a trailing newline. Retain the original source digest and actual assertion output. A mismatch, exception or missing result fails the claim; do not edit the immutable source to obtain a pass.

