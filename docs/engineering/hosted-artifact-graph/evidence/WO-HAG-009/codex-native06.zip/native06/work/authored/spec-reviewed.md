+++
id = "SPEC-N06-001"
type = "specification"
title = "Inspect the fixed greeting without modifying it"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
contract = "Observe the existing zero-argument greeting and preserve exact local evidence."
[relations]
specifies = ["REQ-N06-001"]
+++

# Inspect the fixed greeting without modifying it

Synthetic test record. Supplied actor labels have no real engineering authority.

## Scope
The input is the supplied src/greeting.py Git-blob snapshot. Inspection plus one exact equality assertion is sufficient; no new source implementation is needed.

## N06-GREET-001
The zero-argument greeting() function MUST return the Python string `Hello rehearsal` exactly. The assertion expected value comes from REQ-N06-001.

## N06-EVIDENCE-002
The executor MUST retain the source SHA-256, runtime, command, exit status and assertion output. If the assertion fails or the digest differs from selection.json, stop the affected verification. The service MUST NOT be used to execute source tests.

## Coverage
REQ-N06-001 is covered by the exact-return and evidence-retention rules above.

## Example
A no-argument call returning `Hello rehearsal` passes; a result with a newline fails exact equality.

