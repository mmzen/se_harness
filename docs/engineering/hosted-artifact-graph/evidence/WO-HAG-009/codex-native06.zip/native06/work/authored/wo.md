+++
id = "WO-N06-001"
type = "work_order"
title = "Inspect greeting and retain the complete test record"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
[assurance]
commit_bound_verification = "required"
rationale = "The synthetic verification and release decisions depend on exact definitions and retained assertion evidence at one test candidate."
decided_by = "test-owner"

[execution_scope]
paths = ["src/greeting.py", "docs/engineering/lifecycle-pilot/intent/INT-N06-001.md", "docs/engineering/lifecycle-pilot/capabilities/CAP-N06-001.md", "docs/engineering/lifecycle-pilot/requirements/REQ-N06-001.md", "docs/engineering/lifecycle-pilot/specifications/SPEC-N06-001.md", "docs/engineering/lifecycle-pilot/verification/VER-N06-001.md", "docs/engineering/lifecycle-pilot/work-orders/WO-N06-001.md", "docs/engineering/lifecycle-pilot/release/REL-N06-001.md", "docs/engineering/lifecycle-pilot/risks/RISK-N06-001.md", "docs/engineering/lifecycle-pilot/decisions/DEC-N06-001.md", "docs/engineering/lifecycle-pilot/evidence/WO-N06-001/"]
[relations]
implements = ["REQ-N06-001"]
specifications = ["SPEC-N06-001"]
verification = ["VER-N06-001"]
+++

# Inspect greeting and retain the complete test record

Synthetic test record. Supplied actor labels have no real engineering authority.

## Objective
Enable an operator to inspect greeting() and prove its exact return with a complete exported engineering test record.

## In scope
Inspect src/greeting.py, execute the local assertion, retain exact evidence, and exercise the synthetic lifecycle for these new records.

## Out of scope
Source edits, imported -900 record changes, real engineering decisions, installation, publication, deployment, push and tags.

## Constraints
Use the supplied candidate client and released 0.22.1 governor. Keep immutable source commit S and disposable test candidate P distinct. All actor labels are synthetic.

## Expected change surface
Inspected src/greeting.py already returns the expected literal and needs no edit. The seven new N06 definitions and work/release contract record the outcome. The named risk and decision record evidence-misbinding mitigation. The narrow evidence directory retains assertion.json and inspection.md. Evaluator-prepared VREC/RLS and declared sidecars use automatic selected-work admission; actual destinations require inspection after preparation. No packaging, CI, caller, or runtime change is needed for this fixed fixture.

## Authorized decision envelope
Use only the supplied test-owner decisions after required gates pass. test-executor may inspect and retain evidence within this scope. quality-owner assesses the test VREC; release-owner assesses the test RLS. No source change or real external action is permitted.

## Required verification
Perform VER-N06-001 and preserve failed and successful observations. Record a mitigation decision linking this work.

## Evidence to record
Exact local assertion, source digest, command/runtime/exit/output, scope handoff, evaluator receipts, revision/version guards and immutable exports.

## Stop and escalate conditions
Stop the affected action on permission denial, unavailable protocol/runtime, source mismatch, unpassed gate or scope expansion. Do not change permissions or switch routes to bypass a denial.

## Completion report format
Report actual behavior, checks and refusals, unchanged source, test candidate bindings, record IDs, exports, limitations and the next accountable step.

