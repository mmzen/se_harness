param([string]$Path,[string]$Trigger)
$resolved = (Resolve-Path -LiteralPath $Path).Path
[ordered]@{path=$resolved;sha256=(Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash.ToLower();trigger=$Trigger} | ConvertTo-Json -Compress | Add-Content -LiteralPath 'work/file-read-trace.jsonl' -Encoding utf8
Get-Content -LiteralPath $resolved
