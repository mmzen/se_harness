+++
id = "VER-N06-001"
type = "verification"
title = "Retain an independent local greeting assertion"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"

[relations]
verifies = ["REQ-N06-001"]
+++

# Retain an independent local greeting assertion

Synthetic test record. Supplied actor labels have no real engineering authority.

## Independence
The expected literal `Hello rehearsal` is fixed by REQ-N06-001 and SPEC-N06-001 before execution, never copied from candidate output.

## Requirement-to-evidence matrix
| Requirement | Method | Case | Pass condition |
| --- | --- | --- | --- |
| REQ-N06-001 | inspection, test | Inspect immutable src/greeting.py and run native_call.py assert-greeting | Source hash dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1; exact equality; exit 0 |

## Execution and pass criteria
On the supplied Windows host, use C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe -I with the selected inputs/native_call.py assert-greeting --record work/assertion.json. Retain its actual runtime and output. Released evaluator 0.22.1 assesses lifecycle and bindings only. The endpoint runs no source test.

## Evidence retention
Retain exact assertion JSON at docs/engineering/lifecycle-pilot/evidence/WO-N06-001/assertion.json and an inspection report in that directory. Bind the records to the service's actual disposable candidate P while preserving original source commit S. Do not claim P verifies a changed implementation C.

## Failure assessment
A source mismatch, missing observation, changed evidence, out-of-scope handoff or stale request prevents the affected claim. Retain each refusal separately and inspect unchanged versions before valid continuation.

