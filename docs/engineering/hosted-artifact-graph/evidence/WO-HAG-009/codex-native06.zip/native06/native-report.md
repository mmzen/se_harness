The local assertion passed: the existing `greeting()` returns exactly `Hello rehearsal`. The disposable hosted workflow completed with `WO-N06-001=implemented`, `VREC-N06-001=verified`, and `RLS-N06-001=released` for test version `0.0.1`. Earlier and later immutable exports are retained with matching file and bundle hashes. This is an observed test result, not a real engineering release or an independent qualification verdict.

The source was inspected without edits:

```python
def greeting():
    return 'Hello rehearsal'
```

The exact assertion command, executable, argument boundaries, working directory, exit status and output are in [assertion.json](work/assertion.json). It exited `0`, printed `exact greeting passed\n`, and had empty stderr. Its SHA-256 is `477ef69c21d32d2ad90e8adf7f7cfc6a33cfbbffc9149f7cc115ab71cf563acc`. The source SHA-256 remains `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`. The service retained this local evidence; it did not run the source test.

The selected context was project `6779305f-8c5d-47f1-bd53-7b42189697c0` at `http://127.0.0.1:51760`, with `test_copy=true`, schema revision `2`, and authority mode `sandbox-projection`. [Status](work/001-status.json), [wheel identity](work/identity-check.json), and the supplied combination identify candidate client `0.22.2`, candidate Codex plugin `0.2.7`, and released governor `0.22.1`. The governor archive SHA-256 is `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`; its payload SHA-256 is `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff`. Only the credential environment-variable name was used. No secret values or stores were read.

The supplied candidate setup/change/evidence/orient guidance and relevant closed contracts were read explicitly. The hosted selection route left the real host plugin and checkout selection unchanged. There was no installation, activation, delegation, permission change, ownership override, source edit, push, Git tag, publication or deployment. Automatic instruction injection was not tested.

The new engineering package contains `INT-N06-001`, `CAP-N06-001`, `REQ-N06-001`, `SPEC-N06-001`, `VER-N06-001`, `WO-N06-001`, and `REL-N06-001`. The work order requires commit-bound assurance and declares 11 narrow paths: the seven new artifact paths, its risk and decision paths, its evidence directory, and `src/greeting.py`. The synthetic test-owner inputs supplied definition/work approval and the mitigation decision. Execution used `test-executor`; VREC preparation and acceptance used `quality-owner`; RLS preparation and authorization used `release-owner`.

| Observed case | Result and retained evidence |
| --- | --- |
| Authoring and validation | Created and revised the new package with actual returned revisions, then validated it. [Commands 005–024](work/commands-index.json) retain every request and full result. |
| Stale selection and preview | After the selected SPEC draft changed, the original apply returned HTTP 409 `HAG_REMOTE_STALE_PROJECT`. A request with current versions and the old preview digest returned HTTP 409 `HAG_REMOTE_STALE_PREVIEW`. Both had no affected files or artifacts. [022](work/022-stale-apply-result.json), [023](work/023-stale-digest-result.json), [current read](work/mcp-03-cypher.json) and [fresh preview](work/024-defs-fresh-preview-result.json) establish unchanged project 17/context 15 before valid apply. |
| Lost lifecycle reply | [025](work/025-defs-apply-result.json) retained exit 2, empty stdout and transport outcome `unknown`. The original key `native06-defs-apply` was looked up in [026](work/026-defs-recovery-result.json), which proved acceptance. |
| Identical retry | [027](work/027-defs-identical-retry-result.json) reused the exact original request file and expected versions. Lookup and retry stdout were byte-identical. Receipt `sha256:faf30ccd532691cc20e57e6e6eb3faabfec1db036a32c4cb3c44788c7be81fc0`, baseline and versions remained the same: project 17→18, context 15→16. [Comparison](work/retry-byte-comparison.json). |
| Changed content under accepted key | A changed reason under the accepted key returned HTTP 409 `HAG_REMOTE_KEY_REUSE`, with no effects. [028 request](work/028-key-conflict-request.json), [result](work/028-key-conflict-result.json). |
| Work approval and execution | Approval, start preflight, start, handoff and completion passed their applicable checks. [032](work/032-wo-approve-result.json), [035](work/035-start-result.json), [044](work/044-handoff-result.json), [046](work/046-complete-result.json). |
| Risk and paired decision | `RISK-N06-001` records the risk of binding greeting evidence to the wrong candidate. `DEC-N06-001` records `mitigate`, decided by `test-owner`, with `WO-N06-001`. The resulting risk state is `mitigating`, not `mitigated` or accepted. [040](work/040-mitigate-result.json). |
| Out-of-scope handoff | The probe path `docs/unscoped/native06-probe.json` failed HTTP 422 `HAG_REMOTE_EVALUATOR_REFUSED`, predicate `QGP-G4I-PATHS`, diagnostic `WEX201`. WO stayed `in_progress`; no writes occurred. [041](work/041-out-of-scope-result.json) and [readback](work/mcp-after-scope-refusal.json) show unchanged project 23/context 4. The probe was abandoned; valid evidence was subsequently handed off within approved paths. |
| Verification | Capture retained the original candidate and exact evidence, then the supplied quality-owner acceptance passed and was applied. [048](work/048-capture-result.json), [051](work/051-verify-result.json). |
| Test release | RLS preparation passed, its ready record was reviewed, and the supplied release-owner transition passed release and structural gates. [053](work/053-release-prepare-result.json), [055](work/055-release-preview-result.json), [056](work/056-release-apply-result.json). |
| Final validation | [058](work/058-final-validate-result.json) reports 18 artifacts, zero errors, zero warnings, and one unchanged historical advisory: `W-AUT-022` in imported `SPEC-P3-900`. |

The scope refusal was a released evaluator refusal. No host permission denial occurred. Preview results describe projected effects; they are not accepted writes. Similarly, checkpoint-free MCP `check` results report context with `not_assessable` and no gates. The transition/preflight/capture results above provide the actual passed checks. No passing check was treated as synthetic approval by itself.

All seven read-only hag MCP tools were exercised: `revision` on the new INT revision, `work-context` on the authored WO, `cypher` on the changed SPEC state, `check` on selected lifecycle records, `impact` on the new requirement, `lineage` from the work to verification, and `compare` from the imported baseline to the earlier approved-definition baseline. [mcp-index.json](work/mcp-index.json) identifies the exact views, budgets and saved request/response files. All seven and six additional reads returned `complete=true`, `continuation=null`, and no unresolved references. Saved results were read. These claims apply to their selected queries and views, not an unrequested complete graph.

Keep the four identities distinct:

| Identity | Exact binding |
| --- | --- |
| Source fixture S | `5820415917e87b64d80bad2f7c39c6d18d692829` |
| Capture input baseline B | `se-harness-artifact-baseline/v1:sha256:da36ada985b5aa780b79eebf98b150fdf9e219b2a016674d4f793804a8e96e39` |
| Disposable test candidate P | `b1ae7c695684b82c00d1102d1443a7800a66e431` |
| Actual implementation candidate C | `0dbb8ea19f28994da7abc7ecbab08c8db430dc0c` |

The exported VREC and RLS retain P. The later governance HEAD is `afc21626fd1ebb07d64093abcb76f575e491648a`; it does not replace P. This fixture test does not verify C.

| Immutable export | Files | Snapshot ID | Git HEAD |
| --- | ---: | --- | --- |
| [Earlier](work/export-earlier/manifest.json) | 19 | `sha256:a7a5c1283f13dfe05658b36d3ec35d79d31f1a7628d387f62c50b055ad8c7b59` | `ba43395d2ad6e64b9e175d0bababa4f203a2f79b` |
| [Later](work/export-later/manifest.json) | 29 | `sha256:77560c55d9fcc2e72023209501cd86296a062ee7df7f9cb0e7ace331aee57c92` | `afc21626fd1ebb07d64093abcb76f575e491648a` |

Each destination contains exact bytes under `files/`, `manifest.json`, and `history.bundle`. The earlier bundle SHA-256 is `bd0ab6424b57dbbeab8cdc9c80ce39a321aea3c98c496c379e63b67ee6eae8cb`; the later bundle SHA-256 is `770d266018197e945f5bb1a40c6f72d11062533b75774dce542c592bc4a7a9f0`. Separate `work/export-review` and `work/export-release-review` snapshots retain the reviewed ready VREC and ready RLS. [Byte audit](work/byte-audit.json) confirms all four exports' file counts, byte lengths and hashes, bundle hashes, and absence of `.incomplete`. All seven imported `-900` records and the greeting source match their original bytes. No export was overwritten.

Independent Git reconstruction and replay with released `0.22.1` were not performed by this native agent. The bundles and original candidate bindings are ready for that separate reviewer check. The VREC sidecar records `origin-version` with null archive/payload fields; these bytes were preserved. Full evaluator identity is separately retained in receipts and export provenance. The RLS sidecar records `full-payload`. Database read-only privilege enforcement remains declared deferred under `RISK-HAG-001`; no independent privilege audit is claimed.

Minor execution issues remain visible. The first draft-open selected the new WO before it existed and returned HTTP 404 `HAG_REMOTE_UNKNOWN_IDENTITY`; opening the immutable seed selection allowed authoring the new package without changing history. An initial final readback omitted the export's `files/` directory and failed path resolution; corrected paths were then read. A PowerShell display projection printed null fields from ordered dictionaries; the saved byte audit was intact and its parsed values were checked. The release wire schema requires `tag`, so `test-v0.0.1` was selected as disposable record metadata only.

The [file-read trace](work/file-read-trace.jsonl) retains exact paths, SHA-256 values and triggers. It includes retrospective entries and hash-only reads; it is not an operating-system access audit. The candidate continuing-authority adapter reference was read during final review; released `AUTHORITY.md` was read before lifecycle decisions. This record does not prove that every candidate prerequisite was read at its earliest required point. [Observations](native-observations.json) retain these limitations and interventions rather than assigning an unconditional qualification pass.

The final selected context is `7d11ae9f-3c3a-4cb3-aeff-32270f7db89d` version `10`, project version `29`. [Final check](work/mcp-rls-final-check.json) reports `RLS-N06-001=released`, with the one next typed step `PROC-EXTERNAL-ACTION / STEP-EXTERNAL-ACTION`: use matching authority for an exact external action, or obtain the missing grant. This trial selects no external action, so none was performed. The requested test record is complete; the independent reviewer owns the remaining replay and qualification assessment.

[commands-index.json](work/commands-index.json) maps all 58 numbered calls plus the local assertion to exact argument arrays, request hashes, full results, operation keys, versions, revisions and receipts. [evidence-inventory.json](work/evidence-inventory.json) indexes the retained work files by SHA-256.

