# Native hosted-workflow qualification: blocked

The existing local fixture passed the exact assertion `greeting() == 'Hello rehearsal'`. The requested complete exported engineering record was **not completed**. Hosted access failed before any lifecycle operation, and no qualification pass is claimed.

## Selected context and identity

Selection: `selection.json`, host `codex`, endpoint `http://127.0.0.1:59907`, project `0c07f0af-551e-4962-9743-acf6f1656e42`. Credential variable NAME: `HAG_NATIVE_TEST_TOKEN`. No credential values, stores or files were inspected.

The installed candidate client reports **0.22.2** (`client-version-corrected.result.txt`). The non-secret configuration selects plugin **0.2.7**, schema **2**, `test_copy: true`, and `sandbox-projection`. Its specified released governor is **0.22.1**, `/opt/evaluator/bin/python`, archive SHA-256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`, payload SHA-256 `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff`. These are configured identities, not a runtime identity verification or passed gate. The combination report is explicitly qualification pending.

The selected manifest identifies source commit `5820415917e87b64d80bad2f7c39c6d18d692829`. The candidate combination identifies candidate source commit `345557d20e83f1c6ed72e11460ee4ba451cf3d91`. Neither is substituted for a newly verified test candidate P or actual implementation candidate C; neither P nor C was created.

## Observed blockers

1. `Get-FileHash` on the exact selected candidate wheel returned **Access ... is denied**. See `wheel-hash-denial.txt`. Wheel verification stopped without retry, escalation, alternative path or permission change. The expected wheel hash is `dde016db02340ca01a9542ec052cce471b27308df8a85878bf36b1ce97d89353`; it was not independently confirmed.
2. The single candidate CLI status call returned **HTTP 403**, `HAG_REMOTE_FORBIDDEN`, `Principal cannot access the selected project.`, exit **1**. See `status.command.json`, `status.result.txt`, and `status.exit.json`. The response has `ready: false` and null project/view/version/evaluator/receipt values. This is an access refusal, not a lifecycle gate result or lost accepted reply. No hosted request was made afterward and no MCP route was used to circumvent it.
3. Independent read-only `git rev-parse HEAD` on the selected source fixture returned **dubious ownership**, exit **128**. See `fixture-head.*`. No safe.directory exception, account change, alternate Git route or retry was attempted. The manifest commit is therefore a supplied binding, not locally verified HEAD.

These observed filesystem, service-access and Git trust failures are distinct from an automatic approval-review rejection; no escalation or approval-review request was made. The record does not diagnose the credential or account configuration.

## Completed independent observation

Inspected the permitted immutable fixture `src/greeting.py`. Exact bytes:

```python
def greeting():
    return 'Hello rehearsal'
```

SHA-256: `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`.

Ran the local `assert-greeting.py` through the selected Python with `-I -B`. Runtime: Python **3.14.6** on Windows. Assertion exit **0**; exact retained output in `assertion.result.txt` includes:

```text
actual='Hello rehearsal'
PASS: greeting() == 'Hello rehearsal'
```

This proves the observed local function result only. No service endpoint ran source tests. No source file was changed; no commit-bound verification or release assessment was completed.

## Required cases left unperformed

| Case | Actual outcome |
| --- | --- |
| New definitions, bounded WO, VER, release contract 0.0.1 | Not authored remotely; setup/access blocked |
| Definition acceptance, work approval/start/completion | Not attempted; no current view or versions |
| One risk and paired mitigation decision | Not created; no approved test work available |
| Out-of-scope handoff refusal with unchanged effects | Not exercised; access denial does not substitute for this case |
| Stale preview after draft revision | Not exercised |
| Uncertain reply lookup, identical retry, changed accepted-key refusal | Not exercised; no mutation or accepted operation key exists |
| Seven MCP tools: check, compare, cypher, impact, lineage, revision, work-context | Not invoked after project access refusal; no meaningful selected service view available |
| MCP completeness, saved results, continuations | Unassessed; no MCP responses or saved-result paths exist |
| Test VREC acceptance and RLS authorization | Not attempted |
| Earlier and later immutable exports | Neither created; export destinations absent |
| Independent replay using released 0.22.1 | Not performed; no bundles or original test candidate bindings available |

No remote mutation requests were submitted. There are no returned baseline/context IDs, revisions, previews, accepted operation keys, receipts or export paths to report. No before/after service-state comparison was available, so unchanged server state is not independently attested. The agent itself submitted only one read-only status request.

## Evidence and interventions

`file-read-trace.jsonl` records exact successful input paths, SHA-256 values and read triggers. The first selection/setup/manifest/combination reads were registered retrospectively immediately after creating the trace. Candidate setup, change, evidence and harness-orient guidance was read explicitly; automatic injection is not claimed. Actual CLI help is retained in `remote-help.*`. The permitted README was read for the Phase 3 route; none of its referenced walkthroughs, test drivers, fixture authoring code or earlier host transcripts were opened or executed.

`record.ps1` records one CLI call at a time; `assert-greeting.py` performs only the local assertion. `local-invocation-failures.txt` and `client-version.result.txt` retain two local invocation mistakes and their corrections. No end-to-end launcher, delegation, installation, activation, host plugin change, Git mutation, push, tag, publication or deployment occurred. Imported `-900` records were not amended or given decisions.

Next accountable action: the test operator must resolve the supplied environment's project-access and file/Git access blockers under its own authority before a fresh authorized continuation can complete the outstanding qualification. No permission changes are requested or performed by this run.
