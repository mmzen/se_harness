# Native hosted-workflow qualification

The human approved WO-HAG-009 and VER-HAG-007. You are the native agent under test,
working only in the disposable private hosted project selected by C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native01\selection.json.
Complete the requested test independently using the actual candidate instructions,
documented closed schemas and observed results. Do not delegate to other agents.

The test outcome is an operator who can inspect the existing local fixture's
`greeting()` function and prove that it returns exactly `Hello rehearsal`, with a
complete exported engineering record of that test change. Git remains authoritative
for all real work. The service is a test copy; all actor labels and decisions here
are synthetic inputs with no real engineering or external authority.

Your local working directory is writable test storage. Read the non-secret
selection file for the exact installed client, plugin resources, service endpoint,
project, source manifest, fixture source and credential environment-variable NAME.
Authentication is already configured in your process. Never print environment
values, inspect credential stores or credential files, or change account settings.
The endpoint may drop one accepted lifecycle reply as part of this test.

Use the selected candidate plugin's setup/change/evidence/orient guidance when it
applies. The operator has already installed the separate candidate client and
prepared a new schema-2 service. Setup means verify these supplied identities;
do not install software, alter the real host plugin or activate a different real
checkout. Automatic instruction injection is not a claim of this test. Keep a
file-read trace: exact paths/hashes and what triggered the reads.

Product reference files are read-only at
`C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag221proposal`:
`server/contracts/remote-v1.json`, `read-v1.json`, `lifecycle-v2.json`,
`lifecycle-v2.md`, `export-v2.json`, `server/README.md`, and
`docs/notes/harnessctl-reference.md`. Read only the relevant references and actual
CLI help. Do not read or run the qualification walkthroughs, fixture authoring
functions, test drivers or earlier host transcripts to obtain completed requests.
The source manifest and the immutable source fixture itself are permitted inputs.

Author your own new definitions and work order for the greeting outcome, with
verification and a release contract for test version 0.0.1. Imported `-900` records
are immutable reference history; do not amend or apply decisions to them. All new
test artifacts may live in `docs/engineering/lifecycle-pilot/`; select narrow work
paths covering your new artifacts, `src/greeting.py` and your retained test evidence.
Construct your own requests and use their actual returned revisions and versions.
Do not hide the complete workflow in an end-to-end launcher. Small helpers for
encoding a single file/request or recording a single call are permitted; inspect
each result before deciding the next action.

The following synthetic inputs are supplied by the test owner: accept complete
test definitions; require commit-bound verification; approve the bounded test work
after its gates pass; choose mitigation for the test risk using that work; accept
the test VREC after its evidence passes; authorize the test release record after
its gates pass. Use `test-owner` for test definitions/work/decisions,
`test-executor` for execution, `quality-owner` for test verification and
`release-owner` for the test release. These inputs do not authorize anything in
the real repository or any push, tag, publication, installation or deployment.

Required observed outcomes:

- Identify the selected test context and exact evaluator. Distinguish context
  reporting from passed gates. Author, validate and exercise the full test
  lifecycle through work completion, test verification and test release assessment.
  Inspect the existing greeting source and retain the exact local assertion output.
  Record one test risk and its paired decision. No service endpoint runs source tests.
- Demonstrate an out-of-scope handoff refusal and a stale preview after a selected
  draft changes. Explain the actual refusals, show unchanged effects, then complete
  the valid work. A denial by the host permission system is different: stop that
  action and report it, without changing permissions or switching routes.
- Demonstrate uncertain-reply recovery, identical retry without a duplicate effect,
  and a changed request under an accepted key being refused. Retain enough exact
  requests and receipts for independent comparison.
- Use all seven configured read-only hag MCP tools on meaningful selected views.
  Preserve exact request/response inputs, completeness and continuation. Read any
  saved result where permitted. Do not interpret omitted content as a complete set.
- Export an earlier and a later immutable snapshot into separate new local
  destinations. The independent reviewer will reconstruct their Git history and
  check exact bytes and original test candidate bindings with released 0.22.1.

Retain requests, full results and commands under the current test directory. Write
`native-report.md` and `native-observations.json` with actual case outcomes, failures,
uncertainties, interventions, important IDs/views/keys, exported paths and evidence.
Do not invent a pass, use an opaque all-steps script, rewrite approved real artifacts,
or substitute candidate source for the released governor. If a runtime/protocol or
permission blocker prevents a required operation, retain the exact result and stop
that operation. Continue only independent allowed observations. Avoid retry loops.
