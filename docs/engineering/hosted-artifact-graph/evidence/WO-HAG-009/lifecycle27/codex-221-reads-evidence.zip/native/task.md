## Selected instruction entry

The following complete canonical sections are already supplied in this context. Apply them before commentary and actions. Reuse them while unchanged and retained; read additional references only when their conditions apply. After compaction, recover this entry from task.md. Explicit task inputs, not automatic startup-delivery evidence. Pointers are not artifact content reads.

Source: {"resource": "docs/engineering/harness/COMMUNICATION.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221-reads\\native\\inputs\\released-resources\\docs\\engineering\\harness\\COMMUNICATION.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "2aa70bc7959c3a1075adf9fd163225a6a8d92216cf8b054cd677fe94e8ea15cf"}

# Communication

## Purpose and claim

This policy controls eligible English prose written by agents for operators and
technical artifacts. It uses selected clarity principles based on ASD-STE100.
It is not ASD-STE100 compliance, certification, approval, or endorsement.

An agent MUST NOT download, search for, bundle, reproduce, parse, or attempt to
strictly implement ASD-STE100 or a controlled dictionary. The installed policy
is complete for its declared purpose.

## Eligible prose

Eligible prose is agent-authored English explanation that is not protected
content (see next section). For eligible prose, the agent SHOULD:

- use one stable term for one concept;
- define an uncommon project term before relying on it;
- identify the responsible actor when responsibility matters;
- state conditions, actions, and results directly;
- prefer active voice when it identifies responsibility;
- keep each sentence focused on one principal action;
- avoid ambiguous pronouns, decorative synonyms, hidden negation, vague
  references, and unnecessary introductions; and
- use a list or table when it clarifies parallel conditions, mappings, or
  ordered steps.

Sentence length is a review signal. It is not a conformance threshold and does
not justify removing necessary technical detail.

## Protected content

Exact protected content MUST remain byte-identical. It includes:

- code and inline code;
- commands, paths, identifiers, hashes, version strings, URLs, schemas, and
  field names;
- JSON, TOML, YAML, XML, and other machine-readable data;
- logs, diagnostics, evidence, evaluator output, and canonical restitution
  blocks;
- quotations; and
- operator-supplied text that is presented as supplied text.

Protected content MUST NOT be automatically paraphrased. It includes BCP 14 obligations, 
requirement statements, lifecycle and decision meanings, safety or legal qualifications, 
acceptance thresholds, formulas, and established terminology.

## Existing artifact pointers

These records are available for inspection. Their presence does not establish that they cover this request. Select and read the applicable records before making content claims.

[{"id": "CAP-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221-reads\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\capabilities\\CAP-P3-900.md", "sha256": "f00af6febc1d62752cab0364e3f4e80e227438f494d98d9f02a9a5c7fdc30bc0"}, {"id": "INT-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221-reads\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\intent\\INT-P3-900.md", "sha256": "20649db79738fdf649578286679d6fe05491e460c5a41e68ba0ed3161c47e7ed"}, {"id": "REL-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221-reads\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\release\\REL-P3-900.md", "sha256": "a7cc92f770027bae2ffbf987a1a83eb36bd5e012632e1db07cf5f377f6b12935"}, {"id": "REQ-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221-reads\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\requirements\\REQ-P3-900.md", "sha256": "99028b8605edfd6e85d3cbfb0ee5243f43df69059e314ed1f0b9ab0bde0bbba4"}, {"id": "SPEC-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221-reads\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\specifications\\SPEC-P3-900.md", "sha256": "0904f98bddc075f26c87e2e2ce603e3d74a497b8df85e1093bf3b0f5f35a45f9"}, {"id": "VER-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221-reads\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\verification\\VER-P3-900.md", "sha256": "9c975ff911c736f30dab7688df8f136e66eefd81eebc09362d0345cef813e8b4"}, {"id": "WO-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221-reads\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\work-orders\\WO-P3-900.md", "sha256": "98ac1fa85021ac8a6f4d7a74973e2148dac97aa6ca69064d847818efc3771332"}]
Before your first explanation, apply the supplied sections and read only the applicable plugin instructions and prerequisites still missing from context. Use the existing file tools below. This explicit test setup does not establish automatic startup instruction delivery.

# Repeat the bounded-read case

Run only the read portion of VER-HAG-007 NQ-03 through real Codex CLI. The prior lifecycle trial is complete. Its late independent HTTP comparison occurred after graph changes and cannot qualify MCP parity. This separate read session must keep the final test state fixed.

Read C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-lifecycle-native27-20261010\codex-221-reads\native\selection.json and the selected coordinates in `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-lifecycle-native27-20261010\codex-221-reads\native\inputs\read-selection.json`. Use the selected plugin's applicable instructions and the tool index at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-lifecycle-native27-20261010\codex-221-reads\native\inputs\native-tools.md`. Choose your own meaningful requests for all seven configured read-only MCP tools. Cover the selected requirement, completed work and its context, revision, impact, lineage, baseline comparison and constrained Cypher. Respect tool schemas, budgets and completeness/continuation markers. Include a bounded incomplete read when supported and report its limits. Independent assessment will repeat your exact observed requests through HTTP and compare complete responses.

Use only read operations. Do not modify service state, create artifacts, import, open contexts, run lifecycle operations, export, change permissions or edit source inputs. Write local reports only below `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-lifecycle-native27-20261010\codex-221-reads\native\work`. Preserve failed requests. Do not infer an accepted verification for the real implementation or claim prior qualification gaps have disappeared.

Write `work/native-report.md` with observed tools, selected views, results, incomplete responses and honest limits. Write `work/native-observations.json` with corresponding evidence references. Original lifecycle evidence remains in the previous run; do not reconstruct it. The proctor will collect native events and compare exact MCP/HTTP results without helping select requests.

Existing approved helper prefix:

```text
"C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe" -I "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-lifecycle-native27-20261010/codex-221-reads/native/inputs/native_call.py"
```

Use one helper invocation per shell call. Native file tools remain available. This supplies no read request or operation sequence. A path or hash alone is not a content read. Reuse unchanged instructions already retained in context. Time limit: 600 seconds.


Start instruction discovery at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-lifecycle-native27-20261010\codex-221-reads\native\inputs\plugin\verity-plane\skills\setup\SKILL.md`. Follow its route for this selected target. Read current prerequisites before acting; reuse unchanged content already retained in context.


## Codex file discovery

If native Read is unavailable, use this existing approved helper prefix:

```json
["C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe", "-I", "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-lifecycle-native27-20261010/codex-221-reads/native/inputs/native_call.py"]
```
Append `read-json ABSOLUTE_FILE` to read selection.json, or `read-text ABSOLUTE_FILE` for an inventoried input or work text file. Use native patch/file tools for writing. This host adaptation replaces only the unavailable native Read route; keep one helper call per invocation, normal permissions, the same selected task and all other restrictions. It supplies no workflow operation, request values, draft or decision.
