# Native bounded-read report

The read portion exercised all seven configured MCP tools against the selected fixed test state. There were 11 retained MCP requests: eight complete responses, one explicitly incomplete response, and two validation errors. Independent HTTP parity remains pending.

## Selected state and identities

- Project: `43ecba70-0bf1-4f46-90d3-b0d755b77baa`.
- Context: `ae7c1109-0733-40d9-86dc-533e1ef73dff`, version `32`.
- Final hosted baseline B: `se-harness-artifact-baseline/v1:sha256:afed508aa719a96e95b0fe79e98acc483a9884ed27aad9cc066e9180f0bc644b`.
- Earlier comparison baseline: `se-harness-artifact-baseline/v1:sha256:50a21468c21927b5b433799a8f8a0a550e6fe3f92ab595dcb2dc2bbde529f94c`.
- Source fixture S: `5820415917e87b64d80bad2f7c39c6d18d692829`, as supplied in selection and returned comparison/Cypher provenance.
- Actual implementation candidate C: `1b4ca16833b3908882e4a961c150156aca417f3c`, as selected and reported in service components. This read session does not verify C.
- Test Git candidate P: unknown from these reads. No substitution of S for P.

[Initial status](status-before.json.stdout.txt) and [final status](status-after.json.stdout.txt) both report ready, project version `34`, schema revision `2`, `sandbox-projection`, and `test_copy: true`. Every successful MCP result also reports project version `34`. No service mutation was requested.

The observed components and protocols match the selected combination. Evaluator `0.22.1` retains archive SHA-256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053` and payload SHA-256 `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff`. The identity helper reports candidate client wheel SHA-256 `7e01ee96e393071933c61985af80bac3f8e72f679149fcb87b7983d3e5938591`, matching selected client `0.22.2`. Status corroborates that identity; no installation was performed.

## Observed reads

Each linked evidence file retains the exact request object and the returned MCP content, including the unchanged result text. Evidence numbers describe record order; independent calls within a batch may overlap. Standard budgets were 500 rows, 2,097,152 bytes and depth 8.

| Tool and evidence | Selection | Observed result |
| --- | --- | --- |
| [work_context](mcp-02-work_context.json) | WO-P3-902, context version 32 | Complete; five governing bindings, 14 declared paths, two dependencies, no relevant decisions. |
| [impact](mcp-04-impact.json) | REQ-P3-901, context version 32 | Complete; ten affected artifact bindings and 20 relations. |
| [lineage](mcp-05-lineage.json) | REQ-P3-901, context version 32 | Complete empty connected verification/evidence relation result. This does not mean no verification records exist. |
| [compare](mcp-06-compare.json) | Earlier baseline to final baseline | Complete; seven changed bindings, 18 added relations, four removed relations. Six artifacts were added and WO-P3-901 changed revision. |
| [check](mcp-07-check.json) | WO-P3-902, final baseline | Complete checkpoint-free read; embedded evaluator operation completed, compliance remains `not_assessable`. |
| [revision](mcp-08-revision.json) | REQ-P3-901, final baseline | Complete selected revision `sha256:060e032c3c9725169db4ca02d895e5a701179e1a9e5313485eed17012b394a08`. |
| [lineage](mcp-09-lineage.json) | VREC-P3-902, final baseline | Complete; five connected bindings and seven relations, including RLS-P3-902, WO-P3-902 and VER-P3-901. These are recorded links, not new assurance. |
| [bounded impact](mcp-10-impact.json) | REQ-P3-901, same context; two-row budget | Incomplete; two artifact bindings, zero returned relations, `row_limit`. |
| [cypher](mcp-11-cypher.json) | WO-P3-902, final baseline | Complete; one row with ID, `implemented` status and the selected revision. Parameterized labelled Revision query, numeric LIMIT 10. |

All eight complete MCP responses have `continuation: null` and empty `unresolved_references`. The responses use `se-harness-graph-read/v2` and the rehearsal-only authority label.

The selected requirement was also decoded through the typed candidate client. Its [1,217-byte document](requirement-decoded.json.evidence/1-document-1.md) has SHA-256 `851c045bf3b9b1a9a402a813de88c8db6e82611efed30d99bb9997a415b94164`, matching its envelope. Its acceptance text states:

> Given the selected immutable src/greeting.py, invoking greeting() with no arguments must return exactly `Hello rehearsal`.

This session did not execute that test. The auxiliary [client read](requirement-decoded.json.stdout.txt) verifies decoded document integrity; it is not independent transport parity evidence.

## Incomplete response and failures

The bounded impact response has `complete: false`, despite empty unresolved references. Its exact continuation is:

```json
{
  "reason": "row_limit",
  "strategy": "repeat_at_same_view_with_narrower_selection",
  "instructions": "Repeat at this exact view with a narrower artifact selection or a larger budget within the fixed limits. This partial response is not a governing context."
}
```

It omits eight artifact bindings and all 20 relations present in the earlier full-budget read at the identical view. It cannot support a complete impact or governing-context claim. The prior full-budget response supplies the complete answer; no cursor or changed view was used.

[First failed check](mcp-01-check.json) selected REQ-P3-901 at the final baseline. [Second failed check](mcp-03-check.json) selected the same ID at the context. Both returned:

```text
Input validation error: Unevaluated properties are not allowed ('artifact_id', 'operation', 'view' were unexpected)
```

The displayed tool signature did not expose the artifact-ID pattern. Reading the selected check schema established that only WO, VREC, RLS and DEC IDs are admitted. The successful WO-P3-902 check preserves the original failures; the requirement itself was covered by revision and impact reads.

A batched local prerequisite read failed because `inputs/source/docs/notes/hosted-artifact-graph.md` did not exist (native event chunk `99d462`). Inventory discovery located `inputs/reference/docs/notes/hosted-artifact-graph.md`; the subsequent complete read included that file, the Cypher contract and the check schema (chunk `49185e`). Cypher was issued only after its prerequisites were read.

## Embedded evaluator result and limits

The check and work-context results retain the same evaluator result digest `0dd9654311eb301123aba86a8b837baaa75bbfeb64a22456ff93ba41eade854a`. The unchanged embedded restitution reports:

> WO-P3-902 is implemented; VREC-P3-902 is verified.

That is a test-copy state. The read made no writes or lifecycle transition, and its compliance status is `not_assessable`. The evaluator's current step is `PROC-DELIVERY-SELECT / STEP-DELIVERY-SELECT`: the repository-owner or release-owner holds `DR-DELIVERY-SELECT` to choose which separately authorized delivery path to select for WO-P3-902. This bounded read task does not take that step.

The [observation snapshot](observation-snapshot.json) is explicitly in progress and reports incomplete native-call counting. Its `native_failures` field contains one captured item; `failed_command_records` is empty. These fields do not erase the two MCP validation errors or establish an exhaustive failure count. Later report writes and readback are outside that snapshot.

[Machine-readable observations](native-observations.json) map every MCP request to its evidence. The proctor must repeat the exact requests and compare complete responses. This agent performed no independent HTTP parity assessment. The earlier late comparison remains insufficient. Original lifecycle evidence stays in the prior run and was not reconstructed. Explicit instruction reads do not establish automatic startup delivery. Database-side read-only enforcement remains deferred under RISK-HAG-001. No real implementation verification, release, Git action or qualification-gap closure is claimed.

