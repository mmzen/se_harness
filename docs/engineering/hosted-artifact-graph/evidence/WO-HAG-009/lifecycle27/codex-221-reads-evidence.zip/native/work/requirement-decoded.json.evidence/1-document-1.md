+++
id = "REQ-P3-901"
type = "requirement"
title = "Return the exact greeting from the local fixture"
status = "approved"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
statement = "Calling greeting() in the selected local fixture returns exactly the string Hello rehearsal."
verification_method = ["test"]
priority = "must"
source = "task.md supplied test outcome; CAP-P3-901"
[relations]
derives_from = ["CAP-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-10T13:34:07Z"
decided_by = "test-owner"
reason = "Supplied synthetic decision: accept complete definitions for the bounded greeting test."
+++

# Return the exact greeting from the local fixture

## Why
The operator needs a fixed, inspectable result for this native lifecycle test.

## Acceptance
Given the selected immutable src/greeting.py, invoking greeting() with no arguments must return exactly `Hello rehearsal`. Whitespace differences, another value or an exception fail the assertion. VER-P3-901 will define the executed test and retained evidence. The task supplies the expected value; candidate output does not define it.

No input-dependent error interface or product behavior is added.
