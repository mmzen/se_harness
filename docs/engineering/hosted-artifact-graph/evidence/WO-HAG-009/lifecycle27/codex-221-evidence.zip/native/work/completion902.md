# Greeting test evidence for WO-P3-902

The immutable src/greeting.py already returns exactly `Hello rehearsal`. The new local assertion run under WO-P3-902 completed with exit 0, stdout `exact greeting passed\n`, and empty stderr. Its exact command, working directory and output are retained in the companion assertion.json at VER-P3-901\'s original evidence path. Source SHA-256: dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1. Source fixture S: 5820415917e87b64d80bad2f7c39c6d18d692829.

The source satisfies the accepted requirement and specification without any source change, abstraction or dependency. The exact local assertion tests the specified return value. The service evaluates engineering records and does not execute source tests.

The first handoff refusal deliberately used outside/assertion.json. A second handoff exposed a planning error: decided DEC-P3-901 was outside WO-P3-901\'s approved execution scope. Both refusals committed no handoff effects. WO-P3-901 remains in_progress; it was not rewritten. WO-P3-902 explicitly covers the complete observed path set, including that decision and its paired risk. DEC-P3-901 remains decided with option mitigate through WO-P3-901, and RISK-P3-901 remains mitigating. This work makes no claim to have closed the earlier risk or completed the earlier work.

The trusted comparison base remains b49faf261d0d4864118b23d11086bbb93c9194ce from the first accepted lifecycle mutation. This new work uses that same base and includes all recorded changes.

The earlier snapshot was exported before work completion. The final snapshot will include commit-bound verification and test release assessment if their gates pass. Test candidate P comes from capture-verification; actual implementation candidate C is 1b4ca16833b3908882e4a961c150156aca417f3c and is not verified by this greeting test. Independent replay remains a reviewer check. All actor labels and decisions are synthetic; Git remains authoritative for real work.
