+++
id = "RLS-P3-902"
type = "release_record"
title = "Release candidate 0.0.1"
status = "ready"
owners = ["release-owner"]
created = "2026-10-10"
updated = "2026-10-10"
version = "0.0.1"
commit = "4e714835fc74f166e8463ce0df6988522cdc2772"
git_object_format = "sha1"
prepared_at = "2026-10-10T13:49:34Z"
prepared_by = "release-owner"
evaluator_evidence_path = "docs/engineering/lifecycle-pilot/evidence/RLS-P3-902-evaluator.json"
evaluator_evidence_sha256 = "1521d0f7b70cf50ac623f3fb80a2d95bdc28293681b809002573d3115629707c"
tag = "rehearsal-0.0.1"

[relations]
satisfies = ["REL-P3-902"]
includes_verification = ["VREC-P3-902"]
releases_work = ["WO-P3-902"]
+++

# Release Record Candidate

This ready record proposes release `0.0.1` for `WO-P3-902` from candidate commit `4e714835fc74f166e8463ce0df6988522cdc2772`. An accountable release owner must review and transition it to `released`; this command did not approve, commit, tag, release, or publish anything.

The release candidate commit may precede the governance commit retaining this record. Any release tag must be created and checked by the authorized release process.
