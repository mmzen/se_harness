The greeting test completed in the selected disposable hosted project. The local assertion proved that `greeting()` returns exactly `Hello rehearsal`: exit `0`, stdout `exact greeting passed\n`, and empty stderr. [Exact assertion](assertion902.json) and [exported source](export-late/files/src/greeting.py) retain the evidence. Source SHA-256 is `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`; no source modification was needed.

The completed record is **WO-P3-902 implemented**, **VREC-P3-902 verified**, and **RLS-P3-902 released** for test version **0.0.1**. This required a scope correction. The original WO-P3-901 remains in_progress; RISK-P3-901 remains mitigating. The released work set contains only WO-P3-902. All actor labels and decisions are synthetic. Git remains authoritative for real work.

| Required case | Observed result and exact evidence | Limit |
| --- | --- | --- |
| Context and governor | Project `43ecba70-0bf1-4f46-90d3-b0d755b77baa`, context `ae7c1109-0733-40d9-86dc-533e1ef73dff`; final project/context versions 34/32. [Status](status.json) and [final manifest](export-late/manifest.json) identify the selected test copy. | Context reporting is not a passed gate. The read-only check and work-context reported not_assessable. |
| Definitions and bounded work | New INT/CAP/REQ/SPEC/VER/REL/WO-P3-901 were authored from the requested outcome. [Validation](validate-902.json.stdout.txt) returned valid=true, zero errors; WO/REL-P3-902 added the corrective scope. [Implementation receipt](implement902.json.stdout.txt) records the passed completion transition. | Imported -900 records stayed unchanged. Their W-AUT-022 maintenance advisory remains. |
| Stale preview | After REL-P3-901 changed, [old apply request](requests/stale-defs.json) was [refused](stale-defs.json.stdout.txt) with HAG_REMOTE_STALE_PROJECT, HTTP 409, no affected artifacts/files. A fresh preview then preceded acceptance. | This was a project-version rejection, not a digest-only rejection. |
| Lost reply and recovery | [Original call](defs-apply.json) returned transport outcome unknown. Lookup of key `native-defs-apply` [recovered acceptance](defs-recovery.json.stdout.txt). | Unknown transport was not treated as refusal. |
| Identical retry | [Retry](defs-identical-retry.json.stdout.txt) used the original [request](requests/defs-apply.json); its full parsed JSON equals the recovery result. Both retain project 17→18 and context 15→16. | No second effect is reported by the retained receipt. |
| Changed accepted key | A changed reason under the same key was [refused](defs-key-conflict.json.stdout.txt), HAG_REMOTE_KEY_REUSE, HTTP 409, empty effects. | No new key was used to evade the conflict. |
| Deliberate outside handoff | [Preview](handoff-outside.json.stdout.txt) refused `outside/assertion.json` under QGP-G4I-PATHS / WEX201, with unchanged work state and empty committed effects. | This was evaluator refusal, not host permission denial. |
| Unexpected scope failure | The next [handoff preview](handoff-preview.json.stdout.txt) also refused: DEC-P3-901 was outside WO-P3-901's approved scope. | My initial scope omitted the paired decision path. Its generated disposition was not sufficient to admit it to this handoff. |
| Corrective completion | New WO/REL-P3-902 explicitly admitted the exact complete path set. Approval/start gates passed, the assertion ran again, and [accepted handoff](handoff902.json.stdout.txt) passed all 15 Git-derived changed paths. | The comparison base remained `b49faf261d0d4864118b23d11086bbb93c9194ce`. Approved WO-P3-901 and decided DEC-P3-901 were not rewritten. |
| Risk and decision | [RISK-P3-901](export-late/files/docs/engineering/lifecycle-pilot/risks/RISK-P3-901.md) and [DEC-P3-901](export-late/files/docs/engineering/lifecycle-pilot/decisions/DEC-P3-901.md) record test-owner's mitigate choice through WO-P3-901. | The risk was not accepted or closed. The corrective release does not claim completion of that earlier work. |
| Verification and release | [VREC](export-late/files/docs/engineering/lifecycle-pilot/verification-records/VREC-P3-902.md) is verified by quality-owner; [RLS](export-late/files/docs/engineering/lifecycle-pilot/releases/RLS-P3-902.md) is released by release-owner. [Verification](verify902.json.stdout.txt) and [release](release902.json.stdout.txt) transitions passed. | The service did not run source tests. `rehearsal-0.0.1` is record metadata; no Git tag or external delivery occurred. |

The recovered receipt is `sha256:6e6c047b9328790f4c93a179fbce513e5a8f33c58fb19c7ccd34654fa814dd76`, with request digest `sha256:3907de90a6a8761cd382740d905a4f0e68efe541e3cba8ae92ecbf7b926a59ff`. Exact request files, command arguments, stdout, stderr, typed client evidence and full receipts remain under this work directory.

All seven configured read-only MCP tools were used on meaningful views: [check](mcp-check.json), [work_context](mcp-work-context.json), [revision](mcp-revision.json), [impact](mcp-impact.json), [lineage](mcp-lineage.json), [compare](mcp-compare.json), and [cypher](mcp-cypher.json). Each retained response reports complete=true, continuation=null and no unresolved references for its selected view and budget. The revision document was decoded and read. Compare shows seven new bindings and eight new relations against the import baseline. Cypher returned REQ-P3-901 in approved state. These results do not describe later views.

The identities remain distinct:

| Identity | Exact value |
| --- | --- |
| Imported hosted baseline B | `se-harness-artifact-baseline/v1:sha256:6b6d50dc4da569b2fcb5958fa763e44353f0a7bd9da47b09aaf5a0b82b4c21ca` |
| Verification input baseline B | `se-harness-artifact-baseline/v1:sha256:878d644a30294f2d97eb4081f95e2f8da630dc9648b8e2902b70b156283b2af1` |
| Source fixture S | `5820415917e87b64d80bad2f7c39c6d18d692829` |
| Disposable test candidate P, bound by VREC and RLS | `4e714835fc74f166e8463ce0df6988522cdc2772` |
| Actual implementation candidate C, from supplied combination | `1b4ca16833b3908882e4a961c150156aca417f3c` |
| Later exported governance head | `9a406d9638934789fade80dc8fd005935c589462` |

The governor was released **0.22.1**, archive SHA-256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`, payload SHA-256 `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff`. The separate client was 0.22.2 and selected Codex plugin 0.2.7. This test verifies P; it does not verify C. The VREC evaluator sidecar records origin-version inspection with null archive/payload fields. Receipts and snapshots pin the exact evaluator; the RLS sidecar records full-payload inspection.

| Export | Baseline | Snapshot | Files |
| --- | --- | --- | --- |
| [Earlier manifest](export-early/manifest.json) | `se-harness-artifact-baseline/v1:sha256:50a21468c21927b5b433799a8f8a0a550e6fe3f92ab595dcb2dc2bbde529f94c` | `sha256:eba290089f8896b3f30d823b97d85c18da115c4f4b66fa9b702137e8edca50be` | 19 |
| [Later manifest](export-late/manifest.json) | `se-harness-artifact-baseline/v1:sha256:afed508aa719a96e95b0fe79e98acc483a9884ed27aad9cc066e9180f0bc644b` | `sha256:5b06f1abe6366f6d56ffca0362d7311ed7ee4b4d8c6197d7e70a982df433b176` | 31 |

Both new destinations retain `files/`, `manifest.json`, and `history.bundle`. Bundle SHA-256 values are `749884dc26d9bd808a56f86489eb63e78642d013428b58134e063d70bb77dd92` (earlier) and `f1906ad072fae29c5a4f76d49dfda2c19968219b6bcb0254ea5c13a2c451c405` (later). Export calls completed successfully. The inspected final source, assertion, VREC and RLS hashes match the manifest. Intermediate exports in `export-verification/` and `export-release-ready/` supported evidence review.

**Independent replay was not performed.** The reviewer must reconstruct the exported Git histories, compare exact bytes, and check the original test candidate bindings with released 0.22.1. Export success does not establish that result.

[Native observations](native-observations.json) contains case IDs, keys, exact views, receipts, request hashes, read paths/hashes and reasons for reads. [Captured observations](observed-capture.json) is a partial snapshot: 214 observed tool items, 80 successful visible-read metadata entries, five nonzero command records and six native failed-item pointers. These are not exhaustive execution or failure counts; exported assertion copies also appear as command records. Later readbacks and report writes are outside that capture. Missing read evidence remains unknown. The explicitly supplied task and recovery reads do not establish automatic startup instruction delivery.

Additional local errors were an instructions request without an exact heading and an unavailable JavaScript `structuredClone` call. They changed no hosted state; exact section/file reads and a JSON copy resolved them. Generated VREC/RLS prose retains preparation wording, while frontmatter and lifecycle events establish verified/released states.

The evaluator's next step is PROC-EXTERNAL-ACTION / STEP-EXTERNAL-ACTION, requiring authority for an exact external action. The task selects no such action, so none was performed. The remaining qualification action is the independent review of the retained exports.

