+++
id = "SPEC-P3-901"
type = "specification"
title = "Exact local greeting contract"
status = "approved"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
contract = "The existing no-argument greeting() returns exactly Hello rehearsal."
[relations]
specifies = ["REQ-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-10T13:34:07Z"
decided_by = "test-owner"
reason = "Supplied synthetic decision: accept complete definitions for the bounded greeting test."
+++

# Exact local greeting contract

## Scope and behavior
This contract covers only the existing Python function in src/greeting.py. Calling `greeting()` returns the string `Hello rehearsal`, with no leading or trailing whitespace. For example, `greeting() == 'Hello rehearsal'` is true.

A changed value or an exception fails the planned exact assertion. The function takes no input, so no additional input-validation or recovery behavior is required.

The existing constant return is sufficient for this outcome. No abstraction, dependency, source edit or architecture change is needed. Verification and retention mechanics belong to VER-P3-901.
