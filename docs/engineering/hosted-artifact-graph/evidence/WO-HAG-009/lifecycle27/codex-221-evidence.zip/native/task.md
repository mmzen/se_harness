## Selected instruction entry

The following complete canonical sections are already supplied in this context. Apply them before commentary and actions. Reuse them while unchanged and retained; read additional references only when their conditions apply. After compaction, recover this entry from task.md. Explicit task inputs, not automatic startup-delivery evidence. Pointers are not artifact content reads.

Source: {"resource": "docs/engineering/harness/COMMUNICATION.md", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221\\native\\inputs\\released-resources\\docs\\engineering\\harness\\COMMUNICATION.md", "release": {"archive_sha256": "cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053", "payload_sha256": "0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff", "version": "0.22.1"}, "sha256": "2aa70bc7959c3a1075adf9fd163225a6a8d92216cf8b054cd677fe94e8ea15cf"}

# Communication

## Purpose and claim

This policy controls eligible English prose written by agents for operators and
technical artifacts. It uses selected clarity principles based on ASD-STE100.
It is not ASD-STE100 compliance, certification, approval, or endorsement.

An agent MUST NOT download, search for, bundle, reproduce, parse, or attempt to
strictly implement ASD-STE100 or a controlled dictionary. The installed policy
is complete for its declared purpose.

## Eligible prose

Eligible prose is agent-authored English explanation that is not protected
content (see next section). For eligible prose, the agent SHOULD:

- use one stable term for one concept;
- define an uncommon project term before relying on it;
- identify the responsible actor when responsibility matters;
- state conditions, actions, and results directly;
- prefer active voice when it identifies responsibility;
- keep each sentence focused on one principal action;
- avoid ambiguous pronouns, decorative synonyms, hidden negation, vague
  references, and unnecessary introductions; and
- use a list or table when it clarifies parallel conditions, mappings, or
  ordered steps.

Sentence length is a review signal. It is not a conformance threshold and does
not justify removing necessary technical detail.

## Protected content

Exact protected content MUST remain byte-identical. It includes:

- code and inline code;
- commands, paths, identifiers, hashes, version strings, URLs, schemas, and
  field names;
- JSON, TOML, YAML, XML, and other machine-readable data;
- logs, diagnostics, evidence, evaluator output, and canonical restitution
  blocks;
- quotations; and
- operator-supplied text that is presented as supplied text.

Protected content MUST NOT be automatically paraphrased. It includes BCP 14 obligations, 
requirement statements, lifecycle and decision meanings, safety or legal qualifications, 
acceptance thresholds, formulas, and established terminology.

## Existing artifact pointers

These records are available for inspection. Their presence does not establish that they cover this request. Select and read the applicable records before making content claims.

[{"id": "CAP-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\capabilities\\CAP-P3-900.md", "sha256": "f00af6febc1d62752cab0364e3f4e80e227438f494d98d9f02a9a5c7fdc30bc0"}, {"id": "INT-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\intent\\INT-P3-900.md", "sha256": "20649db79738fdf649578286679d6fe05491e460c5a41e68ba0ed3161c47e7ed"}, {"id": "REL-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\release\\REL-P3-900.md", "sha256": "a7cc92f770027bae2ffbf987a1a83eb36bd5e012632e1db07cf5f377f6b12935"}, {"id": "REQ-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\requirements\\REQ-P3-900.md", "sha256": "99028b8605edfd6e85d3cbfb0ee5243f43df69059e314ed1f0b9ab0bde0bbba4"}, {"id": "SPEC-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\specifications\\SPEC-P3-900.md", "sha256": "0904f98bddc075f26c87e2e2ce603e3d74a497b8df85e1093bf3b0f5f35a45f9"}, {"id": "VER-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\verification\\VER-P3-900.md", "sha256": "9c975ff911c736f30dab7688df8f136e66eefd81eebc09362d0345cef813e8b4"}, {"id": "WO-P3-900", "path": "C:\\Users\\mathi\\Documents\\Codex\\2026-09-20\\verity-plane-plugin-verity-plane-se\\work\\hag-lifecycle-native27-20261010\\codex-221\\native\\inputs\\source\\docs\\engineering\\lifecycle-pilot\\work-orders\\WO-P3-900.md", "sha256": "98ac1fa85021ac8a6f4d7a74973e2148dac97aa6ca69064d847818efc3771332"}]
Before your first explanation, apply the supplied sections and read only the applicable plugin instructions and prerequisites still missing from context. Use the existing file tools below. This explicit test setup does not establish automatic startup instruction delivery.

# Native hosted-workflow qualification

The human approved WO-HAG-009 and VER-HAG-007. You are the native agent under test,
working only in the disposable private hosted project selected by C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-lifecycle-native27-20261010\codex-221\native\selection.json.
Complete the requested test independently using the actual candidate instructions,
documented closed schemas and observed results. Do not delegate to other agents.

The test outcome is an operator who can inspect the existing local fixture's
`greeting()` function and prove that it returns exactly `Hello rehearsal`, with a
complete exported engineering record of that test change. Git remains authoritative
for all real work. The service is a test copy; all actor labels and decisions here
are synthetic inputs with no real engineering or external authority.

Your working directory is `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-lifecycle-native27-20261010\codex-221\native`. Read the selected inputs under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-lifecycle-native27-20261010\codex-221\native\inputs`. Write requests, drafts, results, exports and reports only under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-lifecycle-native27-20261010\codex-221\native\work`. The source is an exact tracked Git-blob snapshot without Git metadata. No source modification or ownership override is permitted. Read the non-secret
selection file for the exact installed client, plugin resources, service endpoint,
project, source manifest, fixture source and credential environment-variable NAME.
Authentication is already configured in your process. Never print environment
values, inspect credential stores or credential files, or change account settings.
The endpoint may drop one accepted lifecycle reply as part of this test.

Use the selected candidate plugin's setup/change/evidence/orient guidance when it
applies. The operator has already installed the separate candidate client and
prepared a new schema-2 service. Setup means verify these supplied identities;
do not install software, alter the real host plugin or activate a different real
checkout. Automatic instruction injection is not a claim of this test. Keep a
file-read trace: exact paths/hashes and what triggered the reads.

Product reference files are read-only at
`C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-lifecycle-native27-20261010\codex-221\native\inputs\reference`:
`server/contracts/remote-v1.json`, `read-v1.json`, `lifecycle-v2.json`,
`lifecycle-v2.md`, `export-v2.json`, `server/README.md`, and
`docs/notes/harnessctl-reference.md`. Read only the relevant references and actual
CLI help. Do not read or run the qualification walkthroughs, fixture authoring
functions, test drivers or earlier host transcripts to obtain completed requests.
The source manifest and the immutable source fixture itself are permitted inputs.

Author your own new definitions and work order for the greeting outcome, with
verification and a release contract for test version 0.0.1. Imported `-900` records
are immutable reference history; do not amend or apply decisions to them. All new
test artifacts may live in `docs/engineering/lifecycle-pilot/`; select narrow work
paths covering your new artifacts, `src/greeting.py` and your retained test evidence.
Construct your own requests and use their actual returned revisions and versions.
Do not hide the complete workflow in an end-to-end launcher. Small helpers for
encoding a single file/request or recording a single call are permitted; inspect
each result before deciding the next action.

The following synthetic inputs are supplied by the test owner: accept complete
test definitions; require commit-bound verification; approve the bounded test work
after its gates pass; choose mitigation for the test risk using that work; accept
the test VREC after its evidence passes; authorize the test release record after
its gates pass. Use `test-owner` for test definitions/work/decisions,
`test-executor` for execution, `quality-owner` for test verification and
`release-owner` for the test release. These inputs do not authorize anything in
the real repository or any push, tag, publication, installation or deployment.

Required observed outcomes:

- Identify the selected test context and exact evaluator. Distinguish context
  reporting from passed gates. Author, validate and exercise the full test
  lifecycle through work completion, test verification and test release assessment.
  Inspect the existing greeting source and retain the exact local assertion output.
  Record one test risk and its paired decision. No service endpoint runs source tests.
- Demonstrate an out-of-scope handoff refusal and a stale preview after a selected
  draft changes. Explain the actual refusals, show unchanged effects, then complete
  the valid work. A denial by the host permission system is different: stop that
  action and report it, without changing permissions or switching routes.
- Demonstrate uncertain-reply recovery, identical retry without a duplicate effect,
  and a changed request under an accepted key being refused. Retain enough exact
  requests and receipts for independent comparison.
- Use all seven configured read-only hag MCP tools on meaningful selected views.
  Preserve exact request/response inputs, completeness and continuation. Read any
  saved result where permitted. Do not interpret omitted content as a complete set.
- Export an earlier and a later immutable snapshot into separate new local
  destinations. The independent reviewer will reconstruct their Git history and
  check exact bytes and original test candidate bindings with released 0.22.1.

Retain requests, full results and commands under the current test directory. Write
`work/native-report.md` and `work/native-observations.json` with actual case outcomes, failures,
uncertainties, interventions, important IDs/views/keys, exported paths and evidence.
Do not invent a pass, use an opaque all-steps script, rewrite approved real artifacts,
or substitute candidate source for the released governor. If a runtime/protocol or
permission blocker prevents a required operation, retain the exact result and stop
that operation. Continue only independent allowed observations. Avoid retry loops.

## Tool and source locations

Read the selected tool index at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-lifecycle-native27-20261010\codex-221\native\inputs\native-tools.md` and use the selected plugin skills and their applicable references. The exact approved helper prefix is:

```text
"C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe" -I "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-lifecycle-native27-20261010/codex-221/native/inputs/native_call.py"
```
Copy the exact prefix, keeping -I unquoted; append one selected operation.

Use one helper invocation per shell call. Do not add shell wrappers, arbitrary scripts, pipelines or multiple commands. Native file tools remain available. This boundary supplies no operation sequence or artifact content. Original sources and released resources remain at their selection-file paths. A path or hash alone is not a read.

The synthetic risk choice is `mitigate`, linked to the work you author, decided by `test-owner`. Risk acceptance is not supplied. The test VREC preparation/decision identity is `quality-owner`; the test RLS preparation/decision identity is `release-owner`. These fixture inputs grant no real human authority.


Start instruction discovery at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-lifecycle-native27-20261010\codex-221\native\inputs\plugin\verity-plane\skills\setup\SKILL.md`. Follow its route for this selected target. Read current prerequisites before acting; reuse unchanged content already retained in context.


## Codex file discovery

If native Read is unavailable, use this existing approved helper prefix:

```json
["C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe", "-I", "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-lifecycle-native27-20261010/codex-221/native/inputs/native_call.py"]
```
Append `read-json ABSOLUTE_FILE` to read selection.json, or `read-text ABSOLUTE_FILE` for an inventoried input or work text file. Use native patch/file tools for writing. This host adaptation replaces only the unavailable native Read route; keep one helper call per invocation, normal permissions, the same selected task and all other restrictions. It supplies no workflow operation, request values, draft or decision.
