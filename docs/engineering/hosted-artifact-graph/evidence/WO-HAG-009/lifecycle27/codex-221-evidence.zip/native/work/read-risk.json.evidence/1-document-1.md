+++
id = "RISK-P3-901"
type = "risk"
title = "Mistake source inspection for executed greeting evidence"
status = "raised"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
description = "An operator could mistake the visible constant or a successful lifecycle check for an executed source test, leaving the greeting outcome unproved."
action = "Retain the exact local assertion output and source identity through WO-P3-901 before completing the test work."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-901"]

[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-10T13:37:49Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."
+++

# Risk: Mistake source inspection for executed greeting evidence

## Description

An operator could mistake the visible constant or a successful lifecycle check for an executed source test, leaving the greeting outcome unproved.

## Next action

Retain the exact local assertion output and source identity through WO-P3-901 before completing the test work.
