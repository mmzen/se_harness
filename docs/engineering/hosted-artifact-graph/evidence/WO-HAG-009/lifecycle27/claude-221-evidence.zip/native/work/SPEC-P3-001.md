+++
id = "SPEC-P3-001"
type = "specification"
title = "Rehearsal greeting fixture contract"
status = "draft"
owners = ["test-owner"]
created = "2026-10-10"
updated = "2026-10-10"
contract = "The fixture function greeting() returns the string Hello rehearsal."

[relations]
specifies = ["REQ-P3-001"]
+++

# Rehearsal greeting fixture contract

## In plain words

The greeting function is a fixed fixture that always returns one exact string.

## Scope

This specification governs the return value of `greeting()` in `src/greeting.py`.
It does not govern the function's interface, performance, or deployment.

## Rules

**P3-GREET-001.** The function `greeting()` MUST return the string `Hello rehearsal`.

## Examples

**Given** the fixture source is unchanged, **when** `greeting()` is called,
**then** it returns `Hello rehearsal` (P3-GREET-001).

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-001 | P3-GREET-001 |
