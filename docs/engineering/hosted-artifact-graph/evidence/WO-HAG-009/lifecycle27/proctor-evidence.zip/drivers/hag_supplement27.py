"""Retain terminal and cost observations without replacing original summaries."""
import collections,hashlib,json,sys
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-lifecycle-native27-20261010';trial=sys.argv[1];root=O/trial;native=root/'native'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
def put(p,v):
    assert not p.exists(),p
    p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
assert (native/'session.json').exists()
records={}
for p in (native/'work').rglob('*'):
    if not p.is_file() or p.stat().st_size>4194304:continue
    try:v=load(p)
    except (ValueError,UnicodeError):continue
    if isinstance(v,dict) and {'argv','cwd','stdout','stderr','exit'}<=v.keys():
        key=hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        records.setdefault(key,{'path':p.relative_to(native).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'exit':v['exit'],'elapsed_seconds':v.get('elapsed_seconds')})
value={'trial':trial,'scope':'Supplemental scan accepts any filename extension; original costs.json scans .json only and is preserved.',
       'records':list(records.values()),'recorded_command_seconds':sum(v['elapsed_seconds'] or 0 for v in records.values()),
       'limits':'Command time is measured subprocess duration only. It does not assign the remaining wall time to model reasoning. Failed calls are retained.'}
put(root/'command-cost-supplement.json',value)
if trial=='claude-221':
    a=load(root/'independent-replay/assessment.json');failure=load(root/'independent-replay/failure.json');cmd=load(O/'claude-221-independent-replay.json')
    assert cmd['exit']==1 and len(a['cases'])==5 and all(x['outcome']=='passed' for x in a['cases'])
    put(root/'replay-terminal-assessment.json',{'state':'incomplete','accepted_operations_replayed':5,'native_exports':0,'command_exit':cmd['exit'],
        'failure':failure['message'],'prior_assessment_state':a['state'],
        'limits':'The five assessor-created input snapshots support operation replay only. They are not native exports and do not satisfy NQ-05. Original running assessment and terminal failure remain unchanged.'})
print(json.dumps({'trial':trial,'command_records':len(records),'seconds':value['recorded_command_seconds']}))
