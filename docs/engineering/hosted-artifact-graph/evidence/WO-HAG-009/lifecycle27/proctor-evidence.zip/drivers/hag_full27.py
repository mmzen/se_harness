"""Run authorized NQ tasks; no supplied artifact content or lifecycle sequence."""
import json,os,subprocess,sys,hashlib
from pathlib import Path
import hag_efficiency_plan as p
W=p.W; R=p.R; O=W/'hag-lifecycle-native27-20261010'; O.mkdir(exist_ok=True)
PREV=W/'hag-lifecycle-correction27-20261010'; PERM=W/'hag-efficiency-compact-pointers-20261010'; OLD=W/'hag-agent-qualification-execution-20261007'
H=Path(r'C:\Users\mathi\AppData\Local\Python\pythoncore-3.14-64\python.exe')
mode=sys.argv[1];host=sys.argv[2] if len(sys.argv)>2 else None;trial='221'
root=O/(host+'-'+trial) if host else O;native=root/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
def put(f,v):
    assert not f.exists(),f
    f.write_bytes((v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
def sha(b):return hashlib.sha256(b).hexdigest()
p.O=O
def boundary():
    settings=[]
    for name in ('C:/Users/mathi/.codex/config.toml','C:/Users/mathi/.claude/settings.json','C:/Users/mathi/.claude/plugins/installed_plugins.json'):
        f=Path(name);settings.append({'path':name,'sha256':sha(f.read_bytes()) if f.exists() else None})
    return {'settings':settings,'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),
        'tracked_diff':subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R).decode()}
if mode=='auth':
    exe=Path(r'C:\Users\mathi\.local\bin\claude.exe') if host=='claude' else Path(r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\9691020b546a15b2\codex.exe')
    p.run(host+'-version',[exe,'--version'])
    probe=O/(host+'-auth');probe.mkdir(exist_ok=False)
    prompt='Authorized provider availability probe. Reply exactly AUTH_OK. Use no tools, read no files, change nothing.'
    args=[exe,'-p','--no-session-persistence','--tools','','--model','claude-opus-4-6','--output-format','json',prompt] if host=='claude' else [exe,'--no-daemon','exec','--ephemeral','--skip-git-repo-check','--json','-C',probe,'--sandbox','read-only','-c','plugins."verity-plane@se-harness".enabled=false',prompt]
    v=p.run(host+'-live-probe',args,cwd=probe)
    raw=load(O/(host+'-live-probe.json'))
    if host=='claude':assert v.get('result','').strip()=='AUTH_OK' and not v.get('is_error')
    else:assert any(json.loads(s).get('item',{}).get('text')=='AUTH_OK' for s in raw['stdout'].splitlines() if s.startswith('{'))
    put(O/(host+'-auth-review.json'),{'host':host,'exit':raw['exit'],'AUTH_OK_observed':True,'raw_events':'Private provider log excluded from published evidence.'})
    print(host,'live authentication passed')
elif mode in ('setup','stage'):
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==load(PREV/'candidate-27.json')['commit']
    changed=subprocess.check_output(['git','diff','--name-only',load(PREV/'candidate-27.json')['commit'],'HEAD','--','se_harness','tests','plugins','server','templates','pyproject.toml','repository_tools'],cwd=R).decode()
    assert not changed,changed
    source=(W/'hag_native27.py').read_text()
    oldargv=sys.argv;sys.argv=[str(W/'hag_native26.py'),mode,host,trial]
    try:exec(compile(source,'retained-preparation26','exec'),{'__file__':str(W/'hag_native26.py'),'__name__':'__main__'})
    finally:sys.argv=oldargv
    if mode=='stage':
        inputs=native/'inputs';selection=load(root/'native-selection.json');helper=inputs/'native_call.py'
        task=(OLD/'native-task.md').read_text().replace(str(R),str(inputs/'reference'))
        task=task.replace('Your local working directory is writable test storage.',f'Your working directory is `{native}`. Read the selected inputs under `{inputs}`. Write requests, drafts, results, exports and reports only under `{native / "work"}`. The source is an exact tracked Git-blob snapshot without Git metadata. No source modification or ownership override is permitted.')
        task=task.replace('`native-report.md` and `native-observations.json`','`work/native-report.md` and `work/native-observations.json`')
        task+='\n## Tool and source locations\n\nRead the selected tool index at `'+str(inputs/'native-tools.md')+'` and use the selected plugin skills and their applicable references. The exact approved helper prefix is:\n\n```json\n'+json.dumps(selection['approved_shell_argv_prefix'])+'\n```\n\nUse one helper invocation per shell call. Do not add shell wrappers, arbitrary scripts, pipelines or multiple commands. Native file tools remain available. This boundary supplies no operation sequence or artifact content. Original sources and released resources remain at their selection-file paths. A path or hash alone is not a read.\n'
        task+='\nThe synthetic risk choice is `mitigate`, linked to the work you author, decided by `test-owner`. Risk acceptance is not supplied. The test VREC preparation/decision identity is `quality-owner`; the test RLS preparation/decision identity is `release-owner`. These fixture inputs grant no real human authority.\n'
        argv=selection['approved_shell_argv_prefix']
        sys.path.insert(0,str(R/'tests/hosted_artifact_graph'))
        from qualify_agents import shell_prefix
        task=task.replace('```json\n'+json.dumps(argv)+'\n```','```text\n'+shell_prefix(argv)+'\n```\nCopy the exact prefix, keeping -I unquoted; append one selected operation.')
        put(root/'native-task.md',task)
        rules=load(PERM/'claude-202/permissions.json')
        raw=json.dumps(rules).replace(str(PERM/'claude-202/native').replace('\\','/'),native.as_posix()).replace(str(PERM/'claude-202/native').replace('\\','/').replace('C:','//c'),native.as_posix().replace('C:','//c'))
        # Path rules also contain Windows-backslash spellings in serialized JSON.
        raw=raw.replace(json.dumps(str(PERM/'claude-202/native'))[1:-1],json.dumps(str(native))[1:-1])
        rules=json.loads(raw)
        assert 'claude-202' not in json.dumps(rules)
        put(root/'permissions.json',rules)
        put(root/'stage-evidence.json',{'candidate':load(PREV/'candidate-27.json')['commit'],'review_head':load(PREV/'candidate-27.json')['commit'],'reused_package':str(PREV/'package27'),'runtime_guidance_changes_since_candidate':[],'task_sha256':sha(task.encode()),'inputs_inventory_sha256':sha((inputs/'inventory.json').read_bytes()),'permissions_sha256':sha((root/'permissions.json').read_bytes()),'case':'VER-HAG-007 NQ-01 through NQ-05','limits':'Fresh project, unchanged original lifecycle outcome and synthetic decisions, exact candidate package. No complete-input focused-draft route, supplied artifact, completed request or workflow sequence.'})
        put(inputs/'client-help.txt',subprocess.check_output([selection['client_python'],'-I','-m','se_harness','remote','--help'],cwd=W).decode())
        # Help is an additional staged input; update the not-yet-used inventory.
        inv=load(inputs/'inventory.json');f=inputs/'client-help.txt';inv['files'].append({'path':str(f),'relative':'client-help.txt','bytes':f.stat().st_size,'sha256':sha(f.read_bytes())})
        (inputs/'inventory.json').write_bytes((json.dumps(inv,indent=2)+'\n').encode())
        proof=load(root/'stage-evidence.json');proof['inputs_inventory_sha256']=sha((inputs/'inventory.json').read_bytes());(root/'stage-evidence.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
        print(host,'staged fresh full lifecycle task')
elif mode=='run':
    assert load(O/(host+'-auth-review.json'))['AUTH_OK_observed']
    s=load(root/'selection.json'); creds=load(root/'credentials.json');token=next(x['token'] for x in creds['principals'] if x['id']=='operator')
    result=subprocess.run([s['client_python'],'-I','-m','se_harness','remote','status','--endpoint',s['endpoint'],'--project',s['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--json'],env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token),capture_output=True,cwd=W,check=True)
    status=json.loads(result.stdout);assert status['ready'] and status['project_version']==0
    put(root/'initial-status.json',status)
    exe=r'C:\Users\mathi\.local\bin\claude.exe' if host=='claude' else r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\9691020b546a15b2\codex.exe'
    args=[H,'-X','utf8','-B',R/'tests/hosted_artifact_graph/qualify_agents.py','--host',host,'--executable',exe,'--selection',root/'native-selection.json','--credentials',root/'credentials.json','--task',root/'native-task.md','--output',native,'--prepared-inputs','--drop-reply','--timeout','1800','--instruction-section','docs/engineering/harness/COMMUNICATION.md#communication']
    if host=='claude':args+=['--permission-settings',root/'permissions.json','--model','claude-opus-4-6']
    else:
        assert load(O/(host+'-221-boundary-probe.json'))['exit']==0
        args+=['--codex-loopback-network']
    put(root/'boundary-before-native.json',boundary())
    code=subprocess.call(list(map(str,args)),cwd=W)
    put(root/'boundary-after-native.json',boundary())
    raise SystemExit(code)
else:raise ValueError(mode)
