from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_efficiency_close08.py').read_text()
source=source.replace('hag-efficiency-entry-20261009','hag-lifecycle-native27-20261010').replace('hag-efficiency08-','hag-full27-')
source=source.replace("assert trial in ('claude-21','claude-22','claude-23','claude-24')", "assert trial in ('claude-221','claude-222','codex-221')")
exec(compile(source,'close-full27','exec'),{'__file__':__file__,'__name__':'__main__'})
