import json,os,socket,subprocess,sys,time,urllib.request
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-lifecycle-native27-20261010'
if sys.argv[1]=='inside':
    root=Path(sys.argv[2]);endpoint=sys.argv[3];sentinel=Path(sys.argv[4]);result={}
    for name,action in [
        ('workspace_write',lambda:(root/'owned-write.txt').write_bytes(b'probe\n')),
        ('outside_write',lambda:sentinel.open('r+')),
        ('selected_service',lambda:urllib.request.urlopen(endpoint+'/health',timeout=5)),
        ('external_proxy',lambda:urllib.request.urlopen('https://example.com/',timeout=5)),
        ('external_direct',lambda:socket.create_connection(('1.1.1.1',443),timeout=5))]:
        try:
            x=action();result[name]={'succeeded':True,'status':getattr(x,'status',None)}
            if hasattr(x,'close'):x.close()
        except Exception as exc:result[name]={'succeeded':False,'error':type(exc).__name__,'detail':str(exc)}
    print(json.dumps(result))
else:
    trial=sys.argv[1];selection=json.loads((O/trial/'selection.json').read_bytes())
    root=O/trial/'boundary-probe';root.mkdir(exist_ok=False)
    sentinel=O/trial/'outside-sentinel.txt';sentinel.write_bytes(b'unchanged\n')
    sys.path.insert(0,str(W/'hag221proposal/tests/hosted_artifact_graph'))
    from qualify_agents import codex_loopback_options
    exe=r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\9691020b546a15b2\codex.exe'
    argv=[exe,*codex_loopback_options('codex',selection['endpoint']),'sandbox','--include-managed-config','--permission-profile','hag-loopback','--cd',str(root),'--',sys.executable,'-I','-B',str(Path(__file__).resolve()),'inside',str(root),selection['endpoint'],str(sentinel)]
    start=time.monotonic();r=subprocess.run(argv,cwd=root,capture_output=True,text=True,encoding='utf-8',timeout=45)
    record={'argv':argv,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'elapsed_seconds':round(time.monotonic()-start,3)}
    dest=O/(trial+'-boundary-probe.json');assert not dest.exists();dest.write_bytes((json.dumps(record,indent=2)+'\n').encode())
    assert r.returncode==0,r.stderr
    facts=json.loads(r.stdout)
    assert facts['workspace_write']['succeeded'] and not facts['outside_write']['succeeded']
    assert facts['selected_service']['status']==200
    assert not facts['external_proxy']['succeeded'] and '403' in facts['external_proxy']['detail']
    assert not facts['external_direct']['succeeded'] and '10013' in facts['external_direct']['detail']
    assert sentinel.read_bytes()==b'unchanged\n'
    print(json.dumps({'trial':trial,'boundary_verdict':'pass','results':facts}))
