"""Summarize independently checked round-27 observations at the agreed evidence path."""
import hashlib,json,sys,zipfile
from pathlib import Path
import hag_efficiency_plan as p
W,R,D=p.W,p.R,p.D;O=W/'hag-lifecycle-native27-20261010';E=D/'evidence/WO-HAG-009/lifecycle27'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
    assert not f.exists(),f
    f.parent.mkdir(parents=True,exist_ok=True)
    f.write_bytes(v if isinstance(v,bytes) else (v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
readroot=O/'codex-221-reads'
parity=[load(f) for f in sorted((O/'native-parity-reads27').glob('*.json'))]
success=[x for x in parity if x['http_status']==200]
assert len(success)==9 and all(x['exact_match'] for x in success)
assert {x['tool'] for x in success}=={'check','work-context','revision','impact','lineage','compare','cypher'}
assert len(parity)==11 and all(x['http_status']==400 and x['native_result'] is None and not x['exact_match'] for x in parity if x not in success)
assert load(readroot/'initial-status-retry1.json')==load(readroot/'status-after-native-retry1.json')
assert load(readroot/'boundary-before-native-retry1.json')==load(readroot/'boundary-after-native-retry1.json')
for trial in ('codex-221','claude-221'):
    root=O/trial
    assert load(root/'boundary-before-native.json')==load(root/'boundary-after-native.json')
    assert load(root/'input-integrity.json')['all_unchanged']
assert load(readroot/'input-integrity.json')['all_unchanged']
put(readroot/'independent-assessment.json',{'case':'VER-HAG-007 NQ-03 read portion','result':'valid_read_responses_match',
    'native_seconds':load(readroot/'native/session.json')['elapsed_seconds'],'valid_calls':9,'tools':sorted({x['tool'] for x in success}),
    'exact_match_valid_calls':True,'incomplete_responses':sum(x['native_result'].get('complete') is False for x in success),
    'invalid_calls':2,'invalid_response_limit':'MCP rejected the requests before the domain read and returned plain validation text; HTTP returned HAG_REMOTE_MALFORMED. Native parser returned null. Exact error-envelope parity is not claimed; original records and visible errors are retained.',
    'project_version_before_after':34,'context_version':32,'monitored_boundaries_equal':True,
    'prior_mismatches':'Nine delayed comparisons from codex-221 remain mismatches. This independent native read-only repetition does not rewrite those observations.'})
files={}
for name in ('hag_full27.py','hag_full27_probe.py','hag_full27_review.py','hag_full27_trace.py','hag_full27_cost.py','hag_supplement27.py','hag_full27_parity.py','hag_native_parity19.py','hag_reads27.py','hag_full27_close.py','hag_efficiency_close08.py','hag_full27_retain.py','hag_retain26.py','hag_assess27.py'):
    files['drivers/'+name]=(W/name).read_bytes()
for name in ('codex-auth-review.json','claude-auth-review.json','codex-version.json','claude-version.json','codex-221-boundary-probe.json','codex-221-reads-boundary-probe.json','final-evidence-context-WO-HAG-009.json','pr-before-evidence.json'):
    files['checks/'+name]=(O/name).read_bytes()
files['components/comparison.json']=(W/'hag-lifecycle-correction27-20261010/component-comparison.json').read_bytes()
files['components/candidate.json']=(W/'hag-lifecycle-correction27-20261010/candidate-27.json').read_bytes()
tokens=[x['token'].encode() for f in O.glob('*/credentials.json') for x in load(f)['principals']]
assert all(not any(t in raw for t in tokens) for raw in files.values())
archive=E/'proctor-evidence.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(files.items()):z.writestr(name,raw)
put(E/'proctor-inventory.json',{'archive':archive.name,'sha256':sha(archive.read_bytes()),'files':[{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(files.items())],
    'limits':'Selected proctor drivers and noncredential observations only. Authentication probes are summarized; provider logs and secrets are excluded.'})
print(json.dumps({'stable_read_parity':'9 valid calls, seven tools, exact match','invalid_requests_retained':2,'monitored_boundaries_equal':True}))
