import json,sys,re,hashlib,collections,datetime
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-lifecycle-native27-20261010';trial=sys.argv[1];root=O/trial;native=root/'native'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert (native/'session.json').exists()
calls={};categories=collections.Counter();characters=0;commands=[];events=[]
def categorize(command):
    m=re.search(r'native_call\.py[\"\']?\s+([a-z-]+)(?:\s+([a-z-]+))?',command)
    return (m[1]+(' '+m[2] if m[1]=='remote' and m[2] else '')) if m else 'other shell'
for number,line in enumerate((native/'events.jsonl').read_text().splitlines(),1):
    try:e=json.loads(line)
    except ValueError:continue
    item=e.get('item',{})
    if e.get('type')=='item.completed' and item.get('type')=='command_execution':
        category=categorize(item.get('command',''));categories[category]+=1
        text=item.get('aggregated_output','');characters+=len(text);commands.append({'line':number,'category':category,'characters':len(text)})
    m=e.get('message',{})
    for b in m.get('content',[]) if isinstance(m,dict) else []:
        if b.get('type')=='tool_use':
            calls[b['id']]=b['name']
            category=categorize(b['input'].get('command','')) if b['name']=='Bash' else b['name']
            categories[category]+=1
        if b.get('type')=='tool_result':
            text=b.get('content','');characters+=len(text if isinstance(text,str) else json.dumps(text))
records={}
for p in (native/'work').rglob('*.json'):
    if p.stat().st_size>4194304:continue
    try:v=load(p)
    except (ValueError,UnicodeError):continue
    if isinstance(v,dict) and {'argv','cwd','stdout','stderr','exit'}<=v.keys():
        key=hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        records.setdefault(key,{'first_path':p.relative_to(native).as_posix(),'elapsed_seconds':v.get('elapsed_seconds'),'exit':v['exit']})
value={'trial':trial,'session':load(native/'session.json'),'task_bytes':(native/'task.md').stat().st_size,
    'observed_call_categories':dict(categories),'visible_tool_result_characters':characters,
    'unique_command_records':list(records.values()),'recorded_command_seconds':sum(x['elapsed_seconds'] or 0 for x in records.values()),
    'limits':'Full five-scenario lifecycle trial, not the focused one-artifact EFF benchmark. Codex items are a lower bound. Records duplicated by exports are deduplicated by exact canonical record content. Byte/character counts are not tokens; command durations may overlap, and unexplained wall time is not assigned to model reasoning. No private reasoning is reproduced.'}
path=root/'costs.json';assert not path.exists();path.write_bytes((json.dumps(value,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in value.items() if k not in ('session','unique_command_records','limits')},indent=2))
