from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_retain26.py').read_text()
source=source.replace('hag-efficiency-compact-pointers-20261010','hag-lifecycle-native27-20261010')
source=source.replace("dest=h.D/'evidence/WO-HAG-011'", "dest=h.D/'evidence/WO-HAG-009/lifecycle27';dest.mkdir(exist_ok=True)")
source=source.replace("'immutable-baseline-review.json'):", "'immutable-baseline-review.json','initial-status.json','independent-final-status.json','independent-final-status-command.json','input-integrity.json','instruction-read-trace.json','boundary-before-native.json','boundary-after-native.json','costs.json','command-cost-supplement.json','replay-terminal-assessment.json','initial-status-retry1.json','boundary-before-native-retry1.json','boundary-after-native-retry1.json','status-after-native-retry1.json','prelaunch-failure.json'):")
source=source.replace("summary=h.O/(trial+'-summary.json')", "for p in root.glob('independent-replay/*.json'):\n files['replay/'+p.name]=p.read_bytes()\nfor directory in h.O.glob('native-parity-*27'):\n for p in directory.glob('*'+trial+'*.json'):\n  if ('reads' in p.stem)==('reads' in trial):files['parity/'+directory.name+'/'+p.name]=p.read_bytes()\nfor name in (trial+'-independent-replay.json',trial+'-boundary-probe.json',trial+'-final-status.json',trial+'-containers.json',trial+'-stop.json'):\n p=h.O/name\n if p.exists():files['proctor/'+name]=p.read_bytes()\nsummary=h.O/(trial+'-summary.json')")
exec(compile(source,'retain-full27','exec'),{'__file__':str(W/'hag_retain26.py'),'__name__':'__main__'})
