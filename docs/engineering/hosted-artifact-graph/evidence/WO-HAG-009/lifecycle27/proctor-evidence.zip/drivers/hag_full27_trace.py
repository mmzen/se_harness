"""Retain observed content reads without private reasoning or duplicated content."""
import json,sys,hashlib
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-lifecycle-native27-20261010';trial=sys.argv[1]
root=O/trial;native=root/'native';rows=[];calls={}
def record(line,tool,result):
    if not isinstance(result,dict):return
    for k in ('files','resources'):
        for item in result.get(k,[]):record(line,tool,item)
    if 'path' not in result:return
    p=Path(result['path'])
    try:rel=p.relative_to(native).as_posix()
    except ValueError:return
    if not rel.startswith('inputs/'):return
    rows.append({'event_line':line,'tool':tool,'path':rel,
        'retained_file_sha256':hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None,
        'sections':[{k:v for k,v in s.items() if k not in ('content','text')} for s in result.get('sections',[])],
        'returned_metadata':{k:v for k,v in result.items() if k not in ('content','text','lines','source','files','resources') and not isinstance(v,(dict,list))}})
for number,line in enumerate((native/'events.jsonl').read_text(encoding='utf-8').splitlines(),1):
    try:event=json.loads(line)
    except ValueError:continue
    item=event.get('item',{})
    if event.get('type')=='item.completed' and item.get('type')=='command_execution':
        if ' read-text ' in item.get('command','') or ' instructions ' in item.get('command',''):
            try:record(number,'Codex helper',json.loads(item.get('aggregated_output','')))
            except ValueError:pass
    msg=event.get('message',{})
    for b in msg.get('content',[]) if isinstance(msg,dict) else []:
        if b.get('type')=='tool_use':calls[b['id']]=b
        if b.get('type')!='tool_result' or b.get('is_error'):continue
        call=calls.get(b.get('tool_use_id'),{})
        if call.get('name')=='Read':
            args=call['input'];record(number,'Claude Read',{'path':args['file_path'],'requested_offset':args.get('offset'),'requested_limit':args.get('limit')})
        if call.get('name')=='Bash' and (' read-text ' in call['input'].get('command','') or ' instructions ' in call['input'].get('command','')):
            content=b.get('content',[])
            texts=[content] if isinstance(content,str) else [x.get('text','') for x in content if x.get('type')=='text']
            for text in texts:
                try:record(number,'Claude helper',json.loads(text))
                except ValueError:pass
value={'trial':trial,'snapshot':'complete' if (native/'session.json').exists() else 'running','reads':rows,'limits':'Successful observed content reads only. Retained file hashes do not prove a partial read was complete. Event lines link to the visible transcript; trigger/ordering assessment remains separate.'}
if value['snapshot']=='complete':
    p=root/'instruction-read-trace.json';assert not p.exists();p.write_bytes((json.dumps(value,indent=2)+'\n').encode())
print(json.dumps({'trial':trial,'snapshot':value['snapshot'],'instruction_reads':[{'line':x['event_line'],'path':x['path'],'sections':[s.get('heading') for s in x['sections']]} for x in rows if x['path'].startswith(('inputs/plugin/','inputs/released-resources/'))]},indent=2))
