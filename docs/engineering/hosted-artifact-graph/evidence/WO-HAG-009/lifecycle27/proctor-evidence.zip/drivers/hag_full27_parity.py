from pathlib import Path
import sys
source=(Path(__file__).parent/'hag_native_parity19.py').read_text()
source=source.replace("'hag-agent-qualification-execution-20261007'","'hag-lifecycle-native27-20261010'")
source=source.replace("hosts={'codex':O/'codex/native03','claude':O/'claude/native02/work/sonnet01'}", "hosts={h+'-221':O/(h+'-221')/'native' for h in ('codex','claude')}")
sys.argv=[__file__,'full27']
exec(compile(source,'native-independent-parity26','exec'),{'__file__':__file__,'__name__':'__main__'})
