"""Repeat only native read qualification against the completed, frozen test view."""
import hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
import hag_efficiency_plan as p
W=p.W;R=p.R;O=W/'hag-lifecycle-native27-20261010';old=O/'codex-221'
root=O/'codex-221-reads';native=root/'native';H=Path(r'C:\Users\mathi\AppData\Local\Python\pythoncore-3.14-64\python.exe')
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
    assert not f.exists(),f
    f.write_bytes((v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
def boundary():
    settings=[]
    for name in ('C:/Users/mathi/.codex/config.toml','C:/Users/mathi/.claude/settings.json','C:/Users/mathi/.claude/plugins/installed_plugins.json'):
        f=Path(name);settings.append({'path':name,'sha256':sha(f.read_bytes()) if f.exists() else None})
    return {'settings':settings,'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),
        'tracked_diff':subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R).decode()}
mode=sys.argv[1]
if mode=='stage':
    root.mkdir(exist_ok=False);native.mkdir()
    shutil.copytree(old/'native/inputs',native/'inputs')
    def remap(value):
        if isinstance(value,str):return value.replace(str(old/'native'),str(native)).replace((old/'native').as_posix(),native.as_posix())
        if isinstance(value,dict):return {k:remap(v) for k,v in value.items()}
        if isinstance(value,list):return [remap(v) for v in value]
        return value
    selection=remap(load(old/'native-selection.json'))
    selection['endpoint']=load(old/'selection.json')['endpoint']
    receipt=load(old/'native/work/release902.json.stdout.txt')
    early=load(old/'native/work/export-early/manifest.json')
    selected={'source':'Completed Codex native trial; supplied coordinates only, no read requests or conclusions.',
        'project_id':selection['project_id'],'project_version':receipt['versions']['project']['after'],
        'final_context':receipt['view'],'final_baseline_id':receipt['baseline_id'],
        'earlier_baseline_id':early['baseline']['baseline_id'],
        'selected_artifacts':['REQ-P3-901','WO-P3-902','VREC-P3-902','RLS-P3-902']}
    put(native/'inputs/read-selection.json',selected)
    inventory=remap(load(native/'inputs/inventory.json'))
    f=native/'inputs/read-selection.json'
    inventory['files'].append({'path':str(f),'relative':f.relative_to(native/'inputs').as_posix(),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())})
    (native/'inputs/inventory.json').write_bytes((json.dumps(inventory,indent=2)+'\n').encode())
    put(root/'selection.json',selection);put(root/'native-selection.json',selection)
    sys.path.insert(0,str(R/'tests/hosted_artifact_graph'))
    from qualify_agents import shell_prefix
    task=f'''# Repeat the bounded-read case

Run only the read portion of VER-HAG-007 NQ-03 through real Codex CLI. The prior lifecycle trial is complete. Its late independent HTTP comparison occurred after graph changes and cannot qualify MCP parity. This separate read session must keep the final test state fixed.

Read SELECTION_FILE and the selected coordinates in `{native/'inputs/read-selection.json'}`. Use the selected plugin's applicable instructions and the tool index at `{native/'inputs/native-tools.md'}`. Choose your own meaningful requests for all seven configured read-only MCP tools. Cover the selected requirement, completed work and its context, revision, impact, lineage, baseline comparison and constrained Cypher. Respect tool schemas, budgets and completeness/continuation markers. Include a bounded incomplete read when supported and report its limits. Independent assessment will repeat your exact observed requests through HTTP and compare complete responses.

Use only read operations. Do not modify service state, create artifacts, import, open contexts, run lifecycle operations, export, change permissions or edit source inputs. Write local reports only below `{native/'work'}`. Preserve failed requests. Do not infer an accepted verification for the real implementation or claim prior qualification gaps have disappeared.

Write `work/native-report.md` with observed tools, selected views, results, incomplete responses and honest limits. Write `work/native-observations.json` with corresponding evidence references. Original lifecycle evidence remains in the previous run; do not reconstruct it. The proctor will collect native events and compare exact MCP/HTTP results without helping select requests.

Existing approved helper prefix:

```text
{shell_prefix(selection['approved_shell_argv_prefix'])}
```

Use one helper invocation per shell call. Native file tools remain available. This supplies no read request or operation sequence. A path or hash alone is not a content read. Reuse unchanged instructions already retained in context. Time limit: 600 seconds.
'''
    put(root/'native-task.md',task)
    put(root/'stage-evidence.json',{'case':'VER-HAG-007 NQ-03 read-only repeat','candidate':selection['qualification_candidate'],
        'prior_trial':'codex-221','same_project':True,'selected':selected,'task_sha256':sha(task.encode()),
        'inputs_inventory_sha256':sha((native/'inputs/inventory.json').read_bytes()),
        'reason':'Earlier independent reads were delayed until the context changed. Preserve every mismatch and assess only this new stable-view repetition.'})
    print(json.dumps({'staged':str(root),'selected':selected}))
elif mode=='run':
    assert load(O/'codex-221-reads-boundary-probe.json')['exit']==0
    s=load(root/'selection.json');token=next(x['token'] for x in load(old/'credentials.json')['principals'] if x['id']=='operator')
    def status():
        result=subprocess.run([s['client_python'],'-I','-m','se_harness','remote','status','--endpoint',s['endpoint'],'--project',s['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--json'],env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token),capture_output=True,cwd=W,check=True)
        return json.loads(result.stdout)
    before=status();assert before['project_version']==34
    retry=len(sys.argv)>2 and sys.argv[2]=='retry1'
    suffix='-retry1' if retry else ''
    if retry:
        assert set(x.name for x in native.iterdir())=={'inputs'}
        (native/'work').mkdir()
        put(root/'prelaunch-failure.json',{'argv':['hag_reads27.py','run'],'exit':1,'stage':'prepare_output before native host launch','error':'ValueError: Prepared output must contain only inputs and empty work','correction':'Create the required empty work directory; keep the same input bytes, project, timeout, permissions and probe. First before/after observations remain retained.'})
    put(root/('initial-status'+suffix+'.json'),before);put(root/('boundary-before-native'+suffix+'.json'),boundary())
    args=[H,'-X','utf8','-B',R/'tests/hosted_artifact_graph/qualify_agents.py','--host','codex','--executable',r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\9691020b546a15b2\codex.exe','--selection',root/'native-selection.json','--credentials',old/'credentials.json','--task',root/'native-task.md','--output',native,'--prepared-inputs','--timeout','600','--instruction-section','docs/engineering/harness/COMMUNICATION.md#communication','--codex-loopback-network']
    code=subprocess.call(list(map(str,args)),cwd=W)
    after=status();put(root/('boundary-after-native'+suffix+'.json'),boundary());put(root/('status-after-native'+suffix+'.json'),after)
    assert before==after,('Read-only state changed',before,after)
    raise SystemExit(code)
elif mode=='parity':
    source=(W/'hag_native_parity19.py').read_text()
    source=source.replace("'hag-agent-qualification-execution-20261007'","'hag-lifecycle-native27-20261010'")
    source=source.replace("hosts={'codex':O/'codex/native03','claude':O/'claude/native02/work/sonnet01'}","hosts={'codex-221-reads':O/'codex-221-reads/native'}")
    source=source.replace("storage='codex-final' if host=='codex-reads' else host","storage='codex-221'")
    sys.argv=[__file__,'reads27']
    exec(compile(source,'independent-stable-read-parity','exec'),{'__file__':__file__,'__name__':'__main__'})
else:raise ValueError(mode)
