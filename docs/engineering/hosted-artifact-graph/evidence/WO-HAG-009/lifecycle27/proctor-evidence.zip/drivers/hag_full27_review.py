"""Independent observation summaries. No service mutation or native assistance."""
import json,sys,hashlib,urllib.request,collections,os,subprocess
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-lifecycle-native27-20261010'
sys.path.insert(0,str(W/'hag221proposal/tests/hosted_artifact_graph'))
from summarize_native import summarize
trial=sys.argv[1];root=O/trial;native=root/'native'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(path,v):
    assert not path.exists(),path
    path.write_bytes((json.dumps(v,indent=2)+'\n').encode())
s=summarize(native)
if len(sys.argv)>2 and sys.argv[2]=='final':
    assert (native/'session.json').exists()
    summary_path=O/(trial+'-summary.json')
    if summary_path.exists():assert load(summary_path)==s
    else:put(summary_path,s)
    selection=load(root/'selection.json');token=next(x['token'] for x in load(root/'credentials.json')['principals'] if x['id']=='operator')
    argv=[selection['client_python'],'-I','-m','se_harness','remote','status','--endpoint',selection['endpoint'],'--project',selection['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--json']
    result=subprocess.run(argv,cwd=W,env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token),capture_output=True,check=True)
    status=json.loads(result.stdout)
    put(root/'independent-final-status-command.json',{'argv':argv,'cwd':str(W),'exit':result.returncode,'stdout':result.stdout.decode(),'stderr':result.stderr.decode(),'prior_observer_error':'An initial direct status request used an incorrect URL and returned 404; no mutation was attempted.' if trial=='claude-221' else None})
    put(root/'independent-final-status.json',status)
    inventory=load(native/'inputs/inventory.json')['files']
    mismatches=[x['relative'] for x in inventory if sha((native/'inputs'/x['relative']).read_bytes())!=x['sha256']]
    put(root/'input-integrity.json',{'checked_files':len(inventory),'mismatches':mismatches,'all_unchanged':not mismatches})
    print(json.dumps({'trial':trial,'final_project_version':status.get('project_version'),'input_integrity_mismatches':mismatches}))
print(json.dumps({'trial':trial,'finished':(native/'session.json').exists(),'wall_seconds':s.get('wall_seconds'),'calls':s.get('native_calls'),'peak_input_context':s.get('peak_input_context'),'failures':[{'line':v.get('line'),'source':v.get('source'),'diagnostic':v.get('diagnostic','')[:220]} for v in s.get('native_failures',[])]},indent=2))
