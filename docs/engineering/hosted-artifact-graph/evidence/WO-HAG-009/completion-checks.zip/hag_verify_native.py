import hashlib,json,subprocess,sys,tomllib,zipfile,concurrent.futures
import hag_efficiency_plan as p
R,D,W=p.R,p.D,p.W;O=W/'hag-native-verification';p.O=O
E=D/'evidence/WO-HAG-009';E10=D/'evidence/WO-HAG-010'
BASE='55caaada508495bea7d97effd27644d1ce8373da';OLD='4f4165727547929b1481d34f359c59bb13ce6a49'
ID='VREC-HAG-006'
def load(f):return json.loads(f.read_bytes())
def put(f,x):f.write_bytes(((x if isinstance(x,str) else json.dumps(x,ensure_ascii=False,indent=2))+'\n').encode())
def git(*args):return subprocess.check_output(['git',*args],cwd=R).decode().strip()
def brief(x):return {k:x.get(k) for k in ['operation','state','restitution']}
def retain():
 files=list(O.glob('*.json'))+list(O.glob('*.md'))+[W/'hag_verify_native.py',W/'hag_verify_native_begin.py',W/'hag_native_candidate_checks.py']
 files=[f for f in files if f.name!='capture-help.json']
 with zipfile.ZipFile(E/'completion-checks.zip','w',zipfile.ZIP_DEFLATED) as z:
  for f in sorted(files):z.writestr(f.name,f.read_bytes())
 b=(E/'completion-checks.zip').read_bytes()
 put(E/'completion-checks-inventory.json',{'archive':'completion-checks.zip','sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'files':[{'path':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(files)]})

mode=sys.argv[1]
if mode=='prepare':
 assert git('rev-parse','HEAD')==OLD and not git('status','--porcelain')
 for a in ['WO-HAG-009','WO-HAG-010']:assert json.loads(load(O/(a+'-preparation-scope.json'))['stdout'])['compliance']['status']=='pass'
 f=D/'README.md';s=f.read_text(encoding='utf-8');assert s.count('## Latest functional qualification')==1
 s=s.replace('## Latest functional qualification','''## Current native qualification

Both Windows CLI hosts pass all five VER-HAG-007 native lifecycle cases for
candidate `2f6ecb1433ef98cf643e0f604ed2c4258a2261e2`. The
[consolidated evidence](evidence/WO-HAG-009/consolidation.md) retains exact
component identities, twelve replayed operations per host, six reconstructed
exports and seven MCP/HTTP tool comparisons per host. Codex includes the disclosed
two-tool read-only supplement. WO-HAG-009 and WO-HAG-010 handoff checks pass;
their completion and verification preparation follow the released evaluator.
Human verification of this native qualification remains pending.

[WO-HAG-011's focused assessment](evidence/WO-HAG-011/focused44-result/assessment.md)
still has two failed Claude positive repetitions and unmet efficiency targets.
Those are separate VER-HAG-008 results. PR #543 remains draft. Git remains
authoritative; no production, desktop, public delivery or risk acceptance is claimed.

## Historical qualification observations

The sections below preserve earlier candidates' observations and outstanding
work at the time of each report. They do not replace the current result above.

### Earlier preview-digest diagnostic''')
 put(f,s.rstrip())
 f=R/'docs/notes/hosted-artifact-graph.md';s=f.read_text();old='PR #542 integrated that result. The separate native Codex/Claude qualification is\n[in progress under WO-HAG-009](../engineering/hosted-artifact-graph/evidence/WO-HAG-009/report.md).';assert old in s
 s=s.replace(old,'PR #542 integrated that result. Both native Codex/Claude CLI runs pass all five\nVER-HAG-007 cases; [the consolidated evidence](../engineering/hosted-artifact-graph/evidence/WO-HAG-009/consolidation.md)\nrecords their exact inputs and limits. Human verification remains pending.\nThe separate WO-HAG-011 focused drafting failures remain unresolved.')
 put(f,s.rstrip())
 put(E/'verification-assessment.md','''# Native hosted lifecycle qualification — verification assessment

## Result and scope

WO-HAG-009 and WO-HAG-010 deliver native Windows Codex CLI/Claude Code
qualification and the corrected hosted setup route. Both hosts pass NQ-01
through NQ-05 under VER-HAG-007. The actual candidate will be the clean commit
named by VREC-HAG-006, containing completed work orders and this retained
evidence. No real human verification is inferred from these observations.

## Requirement assessment

| Governing requirement | Observed result | Evidence |
| --- | --- | --- |
| REQ-HAG-011: lifecycle rehearsal with Git authority preserved | PASS for NQ-01/02/03/05 on both hosts. Agents followed the hosted route, authored definitions, completed synthetic work and prepared/assessed test VREC/RLS records. Original imported records and real host/repository boundaries are preserved. | final44-result native archives: instruction-read-trace, independent-assessment, boundary comparisons, requests, responses and replay |
| REQ-HAG-012: complete atomic effects and safe retry | PASS for NQ-03/04 on both hosts. Out-of-scope and stale operations are refused. A lost reply is recovered by its operation key; identical retry returns the original receipt and changed input under that key is refused. Twelve accepted operations per host independently replay. | Native archives: exact operation inputs/outputs, receipt lookup and replay/assessment.json |
| REQ-HAG-013: provenance and reproducible export | PASS for NQ-02/05 on both hosts. Two Claude and four Codex exports reconstruct exact files and retained Git history; synthetic VREC/RLS candidate bindings remain unchanged. | Native archives: exports, replay commands/results, original-file comparisons and component tuples |
| WO-HAG-010: hosted selection before local activation | PASS in the final native runs. The original two-file correction, preserved local route, rebuilt packages, activation tests and earlier failed trials remain retained. | WO-HAG-010/execution-support.zip and the final native instruction-read traces |

## Exact source and checks

Native qualification ran candidate `2f6ecb1433ef98cf643e0f604ed2c4258a2261e2`,
using released governor 0.22.1, candidate client 0.22.2 and plugins 0.2.7. Exact
wheel, image, dependency and fixture identities are in
[consolidation.json](consolidation.json). That index verifies 1,374 members in
eight retained archives and records byte-equivalence limits for earlier service
qualification. It does not claim equal archive/image identities where they differ.

The final verification candidate adds documentation status, retained check
results and work-order completion to the published consolidation. No native
service, client, instruction package or test-driver source changes. The new
documentation only links observed results and distinguishes historical reports.
Earlier artifacts and evidence are preserved byte-for-byte.

Supporting source checks pass 1,339 tests with 24 skips, distribution validation
and CLI smoke. Exact commands/runtime and the original long-path failures plus
successful process-local retry remain in the IPK local-check archive. The later
CI capacity correction and Windows/Linux package qualification were verified
separately by mmzen in VREC-IPK-002. No new-code or new-run claim is made for
this completion/evidence commit. Refreshed released scope, handoff, validation
and completion results are in completion-checks.zip.

## Limits and separate work

Codex's seven-tool MCP parity includes five tools from the original run and two
from a separate read-only session at the same fixed final baseline. The observer
initially watched old directories. Four delayed comparisons returned stale HTTP
409 and remain unmatched; the supplement supplies the missing parity evidence
without graph mutation or lifecycle assistance. All native command failures and
recovered errors remain visible. No corrective prompts, operator workflow
mutations or hidden scripted completion supplied the required lifecycle result.

WO-HAG-011 retains two focused Claude drafting failures under VER-HAG-008:
omitted known evaluator version and contradictory readiness/type-check claims.
Its efficiency targets are unmet. This record assesses only WO-HAG-009/010 and
VER-HAG-007; it neither verifies WO-HAG-011 nor waives a criterion. PR #543 stays
draft while that separate work remains unfinished.

Desktop, automatic startup/compaction/resume, public installation, production
operation, authentication/database ACL implementation and real Git authority
cutover are excluded. RISK-HAG-001 and RISK-HAG-002 remain raised. Acceptance
of this result does not accept those risks or authorize merge/release/deployment.
Synthetic actor decisions and test VREC/RLS records do not verify this candidate.
''')
 retain()
 for a in ['WO-HAG-009','WO-HAG-010']:
  rel=f'docs/engineering/hosted-artifact-graph/evidence/{a}/verification-change-set.json'
  paths=set(git('diff','--name-only',BASE).splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines())|{rel}
  meta=tomllib.loads((D/f'work-orders/{a}.md').read_text().split('+++')[1]);scope=meta['execution_scope']['paths']
  selected=[q for q in sorted(paths) if any(q==s or (s.endswith('/') and q.startswith(s)) for s in scope)]
  put(R/rel,{'schema':'se-harness-change-set-v1','complete':True,'paths':selected})
 print('Prepared current documentation and candidate assessment; historical evidence unchanged.')
elif mode=='handoff':
 def run(a):
  x=p.gov(a+'-final-review','preflight',R,'--work-order',a,'--phase','review','--json');assert x['ready']
  x=p.gov(a+'-final-handoff','check',R,'--artifact',a,'--checkpoint','handoff','--change-manifest',f'docs/engineering/hosted-artifact-graph/evidence/{a}/verification-change-set.json','--json',allowed=(0,1,2));return a,brief(x)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for a,x in pool.map(run,['WO-HAG-009','WO-HAG-010']):print(a,json.dumps(x),flush=True)
elif mode=='complete':
 for a in ['WO-HAG-009','WO-HAG-010']:
  label=a+'-final-handoff-rebound.json' if a=='WO-HAG-009' else a+'-final-handoff.json'
  prior=json.loads(load(O/label)['stdout']);assert prior['compliance']['status']=='pass'
  args=['transition',R,'--set',a+'=implemented','--decision',a+'=Codex']
  x=p.gov(a+'-complete-preview',*args,'--json',allowed=(0,1,2));print(a+' preview',json.dumps(brief(x)),flush=True)
  assert x['compliance']['status']=='pass' and x['operation']['outcome']=='completed'
  x=p.gov(a+'-complete-apply',*args,'--apply','--json');print(a+' apply',json.dumps(brief(x)),flush=True)
elif mode=='validate':
 x=p.gov('candidate-validation','validate',R,'--json',allowed=(0,1,2));print(json.dumps({k:v for k,v in x.items() if k in ['valid','artifact_count','error_count','warning_count','errors','advisory_count']}));assert x['valid']
 for a in ['WO-HAG-009','WO-HAG-010']:
  x=p.gov(a+'-completed-context','check',R,'--artifact',a,'--json');print(a,json.dumps(brief(x)),flush=True)
 retain()
elif mode=='commit':
 assert git('rev-parse','HEAD')==OLD
 for a in ['WO-HAG-009','WO-HAG-010']:assert tomllib.loads((D/f'work-orders/{a}.md').read_text().split('+++')[1])['status']=='implemented'
 files=sorted(set(git('diff','--name-only').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines()))
 assert len(files)==10,files
 allowed=['docs/engineering/hosted-artifact-graph/README.md','docs/notes/hosted-artifact-graph.md','docs/engineering/hosted-artifact-graph/work-orders/WO-HAG-009.md','docs/engineering/hosted-artifact-graph/work-orders/WO-HAG-010.md']
 assert all(f in allowed or f.startswith(('docs/engineering/hosted-artifact-graph/evidence/WO-HAG-009/','docs/engineering/hosted-artifact-graph/evidence/WO-HAG-010/')) for f in files)
 p.run('candidate-stage',['git','add','--',*files],cwd=R);p.run('candidate-diff-check',['git','diff','--cached','--check'],cwd=R)
 p.run('candidate-commit',['git','commit','-m','Complete native hosted qualification and prepare assurance evidence','-m','Harness-Work-Orders: WO-HAG-009, WO-HAG-010'],cwd=R)
 candidate=git('rev-parse','HEAD');assert not git('status','--porcelain')
 put(O/'candidate.json',{'candidate':candidate,'previous_head':OLD,'changed_files':files,'native_test_candidate':'2f6ecb1433ef98cf643e0f604ed2c4258a2261e2'})
 print('candidate',candidate)
elif mode=='capture':
 candidate=load(O/'candidate.json')['candidate'];assert git('rev-parse','HEAD')==candidate and not git('status','--porcelain')
 assert ID not in git('log','--all','--pretty=format:','--name-only','--','docs/engineering/hosted-artifact-graph/verification-records')
 for f in (D/'verification-records').glob('*.md'):
  m=tomllib.loads(f.read_text().split('+++')[1]);assert not any(a in str(m.get('relations',{})) for a in ['WO-HAG-009','WO-HAG-010']),f
 files=[E/'verification-assessment.md',E/'completion-checks.zip',E/'completion-checks-inventory.json',E/'verification-change-set.json',E10/'verification-change-set.json',E/'consolidation.md',E/'consolidation.json',E/'handoff-checks.zip',E/'handoff-checks-inventory.json',E/'WO-HAG-009-handoff.md',E10/'WO-HAG-010-handoff.md',E10/'consolidation.md',E10/'implementation-review.md',E10/'execution-support.zip',E10/'execution-support.json']
 files+=sorted((E/'final44-result').glob('*'))
 I=R/'docs/engineering/integration-package/evidence/WO-IPK-002'
 files += [I/f for f in ['local-checks.zip','local-checks-inventory.json','ci-evidence.zip','ci-evidence-inventory.json','candidate-relationship.json','verification-assessment.md']]
 args=['capture-verification',R,'--id',ID,'--work-order','WO-HAG-009','--work-order','WO-HAG-010','--verification','VER-HAG-007','--owner','Codex','--domain','hosted-artifact-graph']
 for f in files:assert f.is_file();args+=['--evidence',f.relative_to(R).as_posix()]
 put(O/'capture-inputs.json',{'candidate':candidate,'record':ID,'files':[{'path':f.relative_to(R).as_posix(),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files]})
 args+=['--candidate-commit',candidate,'--json','--test-command',r'C:\Users\mathi\AppData\Local\Python\pythoncore-3.14-64\python.exe','-X','utf8','-B',str(W/'hag_native_candidate_checks.py')]
 x=p.gov('capture',*args,allowed=(0,1,2));print(json.dumps(brief(x)))
