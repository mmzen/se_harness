import hag_efficiency_plan as p,json,concurrent.futures,subprocess
p.O=p.W/'hag-native-verification'
print(p.section(p.RES/'docs/engineering/harness/VERIFY_OUTCOME.md','Establish the verification scope'))
print(p.section(p.RES/'docs/engineering/harness/VERIFY_OUTCOME.md','Obtain the human\'s verification decision'))
print('EXISTING RECORDS', subprocess.check_output(['git','log','--all','--pretty=format:','--name-only','--','docs/engineering/hosted-artifact-graph/verification-records'],cwd=p.R,text=True)[:6000])
def run(a):
 x=p.gov(a+'-context','check',p.R,'--artifact',a,'--json');print(a,json.dumps(x['restitution']),flush=True)
 x=p.gov(a+'-handoff','check',p.R,'--artifact',a,'--checkpoint','handoff','--change-manifest',f'docs/engineering/hosted-artifact-graph/evidence/{a}/handoff-change-set.json','--json',allowed=(0,1,2));print(a,json.dumps({'operation':x['operation'],'restitution':x['restitution']}),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,['WO-HAG-009','WO-HAG-010']))
