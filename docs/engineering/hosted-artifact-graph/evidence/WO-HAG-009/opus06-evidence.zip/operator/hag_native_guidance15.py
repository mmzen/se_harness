"""Fresh isolated native trials of the corrected packaged guidance."""
import ipaddress,json,os,secrets,shutil,subprocess,sys,uuid,zipfile
from pathlib import Path
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
P=h.O/'package15'; E=h.R/h.D/'evidence/WO-HAG-009'
canon=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
mode=sys.argv[1];host=sys.argv[2] if len(sys.argv)>2 else None
root=h.O/(host+'-guidance15') if host else None
native=(root/'native07' if host=='codex' else h.O/'claude/native02/work/opus06') if host else None
def copy(source,target):
    assert not target.exists(),target
    h.write(target,source.read_bytes())
if mode in ('state-before','state-after'):
    files=[Path(r'C:\Users\mathi\.codex\config.toml'),Path(r'C:\Users\mathi\.claude\settings.json'),Path(r'C:\Users\mathi\.claude\plugins\installed_plugins.json')]
    h.write(h.O/('guidance15-'+mode+'.json'),{'repository_head':h.git('rev-parse','HEAD'),
        'repository_status':h.git('status','--porcelain'),
        'host_settings':[{'path':str(p),'exists':p.is_file(),'sha256':h.sha(p.read_bytes()) if p.is_file() else None} for p in files],
        'limits':'Hashes of selected non-credential settings only; no account stores or full environment retained.'})
elif mode=='probe-codex':
    probe=h.O/'guidance15-codex-auth-probe';probe.mkdir(exist_ok=False)
    h.run('guidance15-codex-auth-probe',[r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe',
        '--no-daemon','exec','--ephemeral','--skip-git-repo-check','--json','-C',probe,'--sandbox','read-only',
        '-c','plugins."verity-plane@se-harness".enabled=false',
        'Authorized provider availability probe. Reply exactly AUTH_OK. Use no tools, read no files, change nothing.'],timeout=180)
    record=json.loads((h.O/'guidance15-codex-auth-probe.json').read_text())
    assert any(json.loads(line).get('item',{}).get('text')=='AUTH_OK' for line in record['stdout'].splitlines() if line.startswith('{'))
elif mode=='setup':
    assert host in ('codex','claude');root.mkdir(exist_ok=False)
    config=json.loads((P/'configuration/config.json').read_text());config['project_id']=str(uuid.uuid4())
    for key in ('source_directory','source_inventory','source_manifest'):
        config[key]=json.loads((h.O/'codex/configuration/config.json').read_text())[key]
    compose=P/'candidate-source/server/compose.yaml'
    config['components']['deployment_sha256']=h.sha(canon({'configuration':{k:v for k,v in config.items() if k!='components'},'compose_sha256':h.sha(compose.read_bytes())}))
    h.write(root/'configuration/config.json',config)
    payload=config['components'];h.write(root/'combination.json',{'payload':payload,'combination_id':'sha256:'+h.sha(b'se-harness-hosted-combination/v1\n'+canon(payload))})
    credentials=json.loads((P/'credentials.json').read_text())
    for p in credentials['principals']:p['token']=secrets.token_urlsafe(32);p['projects']=[config['project_id']]
    h.write(root/'credentials.json',credentials)
    project='hag-native-'+host+'-guidance15';volume=project+'-source';port=18341 if host=='codex' else 18342
    ids=subprocess.check_output(['docker','network','ls','-q']).decode().split()
    networks=h.run(host+'-guidance15-networks',['docker','network','inspect',*ids])
    used=[ipaddress.ip_network(c['Subnet']) for n in networks for c in (n.get('IPAM',{}).get('Config') or []) if 'Subnet' in c]
    available=[str(s) for s in ipaddress.ip_network('10.231.62.0/23').subnets(new_prefix=28) if not any(s.overlaps(v) for v in used)]
    assert len(available)>=2
    h.write(root/'network.json',{'networks':{k:{'ipam':{'config':[{'subnet':s}]}} for k,s in zip(('private','client'),available)}})
    h.run(host+'-guidance15-volume-absent',['docker','volume','inspect',volume],allow=(1,))
    h.run(host+'-guidance15-volume-create',['docker','volume','create',volume])
    h.run(host+'-guidance15-source-stage',['docker','run','--rm','--network','none','--mount',f'type=bind,source={h.O/"source-staged"},target=/input,readonly',
        '--mount',f'type=volume,source={volume},target=/source','--entrypoint','python','harness-hag:native-guidance15','-c','import shutil;shutil.copytree("/input","/source",dirs_exist_ok=True)'])
    env=dict(os.environ,HAG_SERVICE_IMAGE='harness-hag:native-guidance15',HAG_HTTP_PORT=str(port),HAG_CONFIG_DIRECTORY=str(root/'configuration'),HAG_CREDENTIAL_FILE=str(root/'credentials.json'),HAG_SOURCE_VOLUME=volume)
    dc=['docker','compose','-p',project,'-f',compose,'-f',root/'network.json']
    h.run(host+'-guidance15-up',[*dc,'up','-d','graph','service'],env=env)
    h.run(host+'-guidance15-init',[*dc,'run','--rm','service','init'],env=env)
    selection=json.loads((h.O/host/'selection.json').read_text())
    selection.update(project_id=config['project_id'],endpoint='http://127.0.0.1:'+str(port),
        configuration=str(root/'configuration/config.json'),combination=str(root/'combination.json'),compose_project=project,source_volume=volume,
        client_python=str(h.O/'client15/Scripts/python.exe'),client_wheel=str(h.O/'build15/se_harness-0.22.2-py3-none-any.whl'))
    selection.pop('credentials',None);h.write(root/'selection.json',selection)
elif mode=='stage':
    assert not native.exists();(native/'inputs').mkdir(parents=True);(native/'work').mkdir()
    inputs=native/'inputs'
    selection=json.loads((root/'selection.json').read_text())
    archive=P/'plugin'/('verity-plane-'+host+'.zip')
    combo=json.loads((root/'combination.json').read_text())
    assert h.sha(archive.read_bytes())==combo['payload']['plugins'][host]['archive_sha256']
    with zipfile.ZipFile(archive) as z:
        for info in z.infolist():
            p=Path(info.filename);assert not p.is_absolute() and '..' not in p.parts
        z.extractall(inputs/'plugin')
    copy(Path(selection['client_wheel']),inputs/Path(selection['client_wheel']).name)
    copy(root/'combination.json',inputs/'combination.json');copy(Path(selection['configuration']),inputs/'configuration.json')
    copy(Path(selection['source_manifest']),inputs/'source-manifest.json')
    fixture=Path(selection['source_directory'])
    for name in subprocess.check_output(['git','ls-files','-z'],cwd=fixture).decode().strip('\0').split('\0'):copy(fixture/name,inputs/'source'/name)
    refs=['server/contracts/remote-v1.json','server/contracts/read-v1.json','server/contracts/lifecycle-v2.json','server/contracts/lifecycle-v2.md','server/contracts/export-v2.json','server/README.md','docs/notes/harnessctl-reference.md','docs/notes/hosted-artifact-graph.md']
    candidate=combo['payload']['source']['candidate_commit']
    for name in refs:h.write(inputs/'reference'/name,h.blob(candidate,name))
    resources=h.NEW.parent.parent/'share/se-harness/templates/repository/standard'
    copy(resources/'ENGINEERING_HARNESS.md.tpl',inputs/'released-resources/ENGINEERING_HARNESS.md')
    copy(resources/'docs/engineering/ARTIFACT_AUTHORING.md',inputs/'released-resources/docs/engineering/ARTIFACT_AUTHORING.md')
    shutil.copytree(resources/'docs/engineering/harness',inputs/'released-resources/docs/engineering/harness')
    helper=h.O/'claude/native02/inputs/native_call.py' if host=='claude' else inputs/'native_call.py'
    if host=='codex':copy(h.R/'tests/hosted_artifact_graph/native_call.py',helper)
    assert helper.read_bytes()==(h.R/'tests/hosted_artifact_graph/native_call.py').read_bytes()
    assert h.sha((E/'claude-permissions-proposed.json').read_bytes())=='48af73d913845721f895c8266af843c5265ffdbbd960b7ea24346d749874457d'
    helptext=subprocess.check_output([selection['client_python'],'-I','-m','se_harness','remote','--help'],cwd=h.W)
    h.write(inputs/'client-help.txt',helptext)
    selection.update(client_wheel=str(inputs/Path(selection['client_wheel']).name),plugin=str(inputs/'plugin/verity-plane'),configuration=str(inputs/'configuration.json'),source_manifest=str(inputs/'source-manifest.json'),source_directory=str(inputs/'source'),source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=fixture).decode().strip(),source_kind='Exact tracked Git-blob snapshot without Git metadata.',combination=str(inputs/'combination.json'),reference_root=str(inputs/'reference'),released_resources=str(inputs/'released-resources'),native_helper=str(helper),greeting_sha256=h.sha((inputs/'source/src/greeting.py').read_bytes()),inputs_inventory=str(inputs/'inventory.json'))
    inventory=[{'path':str(p),'relative':p.relative_to(inputs).as_posix(),'bytes':p.stat().st_size,'sha256':h.sha(p.read_bytes())} for p in sorted(inputs.rglob('*')) if p.is_file()]
    h.write(inputs/'inventory.json',{'files':inventory,'note':'Exact supplied inputs; actual read triggers are recorded separately by the native agent.'})
    selection.update(helper_python=h.HOST.as_posix(), approved_shell_argv_prefix=[h.HOST.as_posix(), '-I', helper.as_posix()], native_task_file=str(native/'task.md'), output_directory=str(native/'work'))
    h.write(root/'native-selection.json',selection)
    task=(h.O/'native-task.md').read_text().replace(str(h.R),str(inputs/'reference'))
    task=task.replace('`docs/notes/harnessctl-reference.md`.','`docs/notes/harnessctl-reference.md`, and `docs/notes/hosted-artifact-graph.md`.')
    task=task.replace('Read only the relevant references and actual\nCLI help.','Read only the relevant references and the captured actual CLI help at\n`'+str(inputs/'client-help.txt')+'`.')
    task=task.replace('Your local working directory is writable test storage.',
        'This is a fresh independent trial. Do not read previous sessions or their outputs.\nRead the selected inputs at `'+str(inputs)+'`. Write only under `work/` in\nyour working directory, plus the two final report files at its root. The source\nis an exact Git-blob snapshot without Git metadata. No source edit or ownership\noverride is allowed.')
    if host=='claude':task+='\nThe normal Skill tool is available. Begin with the selected candidate plugin\'s\n`verity-plane:setup` skill for the explicit hosted selection; follow its routes to\nother skills and released resources as they apply. The client is already installed.\nDo not activate another checkout or install anything.\n'
    task+='\n## Supplied test identities\n\nThe risk option is exactly `mitigate`, with the work order you author. Risk\nacceptance is not supplied. Its decision actor is `test-owner`. The test VREC\npreparation owner and verification actor are `quality-owner`. The test RLS\npreparation owner and release actor are `release-owner`. Work execution uses\n`test-executor`. These are synthetic inputs, not real human authority.\n'
    task+='\n## Session tool boundary\n\nThe human approved the scoped test reads/writes, seven read-only MCP tools and\nthe fixed one-call helper. Existing deny rules and normal review remain. Stop\na newly denied action. Do not alter permissions. Use native file tools and this\nfixed shell prefix; read its help. Its `identity`, `encode-file`, `assert-greeting`\nand `remote` subcommands perform one operation that you choose. It supplies no\nworkflow sequence or decisions. Codex may use its ordinary workspace tools.\n\n```text\n'+h.HOST.as_posix()+' -I '+helper.as_posix()+'\n```\n'
    task+='\nReleased instruction resources are at `'+str(inputs/'released-resources')+'`.\n'
    assert host=='claude'
    task=task.replace('Write only under `work/` in\nyour working directory, plus the two final report files at its root.',
        'Your working directory is `'+str(native)+'`.\nThe sole output directory for drafts, requests, receipts, exports and read traces is\n`'+str(native/'work')+'`. The two final report files may be written at the working-directory root.\nDo not create other sibling output directories at that root. Use absolute paths for every write.')
    task=task.replace('Small helpers for\nencoding bytes or sending one operation at a time are permitted; inspect\neach result before deciding the next action.',
        'Use the supplied one-call helper for encoding or sending one operation.\nUse native Write/Edit tools to construct request files. Inspect each result\nbefore deciding the next action. Do not wrap calls in Python -c, scripts or shell loops.')
    task+='\nThe fixed helper prefix is the only shell command route for this Claude trial.\nDo not change HAG_NATIVE_WORK_DIRECTORY or HAG_NATIVE_SELECTION. Requests and\n--record/--destination outputs must use absolute paths under the output directory\nstated above. Normal permission review still applies. These are tool and path\nboundaries, not a supplied workflow.\n'
    task+='\nThe staged input inventory is at `'+str(inputs/'inventory.json')+'`. It identifies\nexact staged hashes. Record only the paths and triggers that you actually read;\nwhen using an inventory hash, label that source. A hash alone is not a read.\n'
    rules=json.loads((h.O/'native-permission-quoted-rules.json').read_text())
    original=json.loads((E/'claude-permissions-proposed.json').read_text())
    assert rules['permissions']['allow'][:len(original['permissions']['allow'])]==original['permissions']['allow']
    assert rules['permissions']['deny']==original['permissions']['deny']
    extra='Edit(//'+str(inputs).replace('\\','/').replace('C:','c')+'/**)'
    rules['permissions']['deny'].append(extra)
    rules['permissions']['deny'].append('Edit(//'+str(native/'CLAUDE.md').replace('\\','/').replace('C:','c')+')')
    h.write(root/'permissions.json',rules)
    task+='\nThe selected `approved_shell_argv_prefix` is the exact permitted command prefix.\nRead it from the selection file; do not guess or rediscover its executable path.\nAfter context compaction, reread `native_task_file` and the current selection before\nresuming. These persistent files preserve the tool boundary and task inputs.\n'
    h.write(root/'native-task.md',task)
    h.write(root/'stage-evidence.json',{'source_candidate':candidate,'project':selection['project_id'],'inputs_inventory_sha256':h.sha((inputs/'inventory.json').read_bytes()),'task_sha256':h.sha(task.encode()),'helper_sha256':h.sha(helper.read_bytes()),'approved_rules_sha256':h.sha((E/'claude-permissions-proposed.json').read_bytes()),'effective_rules_sha256':h.sha((root/'permissions.json').read_bytes()),'correction':'WO-HAG-010 packaged startup/setup routing correction. Existing deny rules and helper unchanged. Three finite quoting equivalents match the exact approved helper executable and script. Native dontAsk mode retains permission review. No completed requests or workflow sequence supplied.'})
elif mode=='run':
    selection=json.loads((root/'selection.json').read_text());creds=json.loads((root/'credentials.json').read_text())
    token=next(p['token'] for p in creds['principals'] if p['id']=='operator')
    status=h.run(host+'-guidance15-initial-status',[selection['client_python'],'-I','-m','se_harness','remote','status','--endpoint',selection['endpoint'],'--project',selection['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--json'],env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token))
    assert status['ready'] and status['project_version']==0
    exe=r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe' if host=='codex' else r'C:\Users\mathi\.local\bin\claude.exe'
    h.run(host+'-guidance15-version',[exe,'--version'])
    if host=='claude':
        probe=h.run('claude-guidance15-auth-probe',[exe,'-p','--no-session-persistence','--tools','','--model','claude-opus-4-6','--output-format','json','Authorized model availability probe. Reply exactly AUTH_OK. Read or change no files and use no tools.'],timeout=180)
        assert probe.get('result','').strip()=='AUTH_OK' and not probe.get('is_error')
    args=[h.HOST,'-X','utf8','-B',h.R/'tests/hosted_artifact_graph/qualify_agents.py','--host',host,'--executable',exe,'--selection',root/'native-selection.json','--credentials',root/'credentials.json','--task',root/'native-task.md','--output',native,'--prepared-inputs','--drop-reply','--timeout','3600']
    if host=='claude':args+=['--permission-settings',root/'permissions.json','--model','claude-opus-4-6']
    raise SystemExit(subprocess.call(list(map(str,args)),cwd=h.W))
