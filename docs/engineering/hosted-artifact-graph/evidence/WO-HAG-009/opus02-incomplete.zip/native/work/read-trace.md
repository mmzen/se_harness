# File Read Trace

Records paths, hashes and triggers for files actually read during this test.

## Task & Selection Files
| Path | SHA-256 (from inventory) | Trigger |
|------|--------------------------|---------|
| inputs/task.md (via CLAUDE.md) | n/a (working-dir root) | Initial task load |
| inputs/selection.json | n/a (working-dir root) | Initial context identification |
| inputs/inventory.json | n/a | Staged input verification |
| inputs/client-help.txt | 0763a15c2193fb65bf0cb619d96bc123aaf8fc703b9af199f993cd986aed92d2 | CLI help reference |
| inputs/combination.json | 8bf745288f03d14e8481d448caeedd3a93239827f226935fa5cdebf7ab9965c6 | Combination verification |
| inputs/configuration.json | 953cb26674a01ea73fe0b68799b402f9093b920f1ac7298a33fd42e8467a60ef | Service configuration |
| inputs/source-manifest.json | 137d1a6c7bf5375b2dfe686c495e55b576fe2d9a572aa210d191f17d7f0bd71b | Artifact listing |

## Source Fixture
| Path | SHA-256 (from inventory) | Trigger |
|------|--------------------------|---------|
| inputs/source/src/greeting.py | dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1 | Fixture inspection |
