The requested functional outcomes were observed in the private test copy. `greeting()` passed the local exact-equality assertion. `WO-P3-901` is `implemented`, `VREC-P3-901` is `verified`, and `RLS-P3-901` is `released` for test version `0.0.1`. Earlier and later immutable exports are retained. This is not an overall qualification approval: procedural deviations are reported below, and independent replay remains pending.

All decisions use the task's supplied synthetic actors. Git remains authoritative for real work. No real repository change, tag, push, installation, publication or deployment was performed. The generated record's `v0.0.1` field is metadata.

The machine-readable record is [native-observations.json](native-observations.json). Original command captures retain argv, stdout, stderr, exit and duration; companion `.stdout.txt` and `.evidence` files retain full results. Compact displays are not the full evidence.

| Identity | Observed value |
| --- | --- |
| Selected project | `466232f4-45a0-4320-8f5b-bbb9ce35f68e` |
| Endpoint | `http://127.0.0.1:50353` |
| Context | `a365311b-543b-4c9e-bfb0-985446e4166a`, final version 27; project version 29 |
| Client | `0.22.2`, wheel SHA-256 `ada921b057612647d82ad803aab6f94349228f11a33e46357fb81316e8d57150` |
| Released evaluator | `0.22.1`, archive SHA-256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053` |
| Evaluator payload | `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff` |
| Imported baseline B0 | `se-harness-artifact-baseline/v1:sha256:e73720d24d4dab099707a0760918abe3d980c727b800c36adfb9a4dc817af884` |
| Verification input baseline B | `se-harness-artifact-baseline/v1:sha256:56c5460b7a08687ff8207e9ef1a94cfc5232a9cc0d4f0dc5947f3e1191e3115e` |
| Source fixture S | `5820415917e87b64d80bad2f7c39c6d18d692829` |
| Disposable test candidate P | `50b73b015badd5dc3d07e677258338a5fd63e2a4` |
| Actual implementation candidate C | `ee86a842550c19fb6a56913841757b42df9ecaec` |
| Retained handoff base | `ccfdb51c53412bac1f0dedfc5d0f5a116fa0d78e` |

Selection comes from `../selection.json` and `status-initial.json`. The final export manifest and verified VREC retain B, S and P. C comes from `selection.json#/qualification_candidate`; the test VREC does not verify C. The retained handoff base comes from the first accepted lifecycle mutation, `defs-lookup.json.stdout.txt#/provenance/input_git_head`, and is also saved in `retained-base.json`.

| Assessed case | Outcome | Exact retained evidence | Remaining limit |
| --- | --- | --- | --- |
| selection | observed: Selected private project ready with evaluator 0.22.1 and client 0.22.2. | `status-initial.json`; `selection.json#/qualification_candidate` | Explicit test setup; no automatic startup-delivery claim. |
| drafts | observed: New bounded definitions, verification and work order authored; release contract completed after candidate known. Validation admitted drafts. | `validate.json`; `revise-int-stale-test.json`; `revise-rel.json`; `INT-P3-901.md through WO-P3-901.md`; `REL-P3-901.md` | Template admission is distinct from agent content review; historical W-AUT-022 advisory retained. |
| stale-preview | expected_refusal: Draft changed after preview; old apply refused HAG_REMOTE_STALE_PROJECT with empty effects. Fresh preview used project15/context13. | `defs-preview-old.json`; `revise-int-stale-test.json`; `defs-stale-request.json`; `defs-stale.json.stdout.txt`; `defs-preview.json` | The project guard refused first; isolated preview-digest mismatch behavior was not separately tested. |
| definitions-approval | accepted_recovered: Five new definitions approved by supplied test-owner decision at project15→16/context13→14. | `defs-apply-request.json`; `defs-apply.json`; `defs-lookup.json.stdout.txt` | Initial reply was unknown, not a pass or refusal. |
| uncertain-reply | recovered: Original native-defs-apply key lookup recovered accepted receipt. | `defs-apply.json#/stderr`; `defs-lookup.json#/argv`; `defs-lookup.json.stdout.txt` | Lookup alone is separate from retry. |
| identical-retry | observed_no_duplicate: Same request file resubmitted; recovered and retried result objects deeply equal, same receipt and versions. | `defs-identical-retry.json#/argv`; `defs-identical-retry.json.stdout.txt`; `receipt-and-export-comparison.json` | No replacement key or refreshed versions used. |
| changed-key-content | expected_refusal: Changed reason under native-defs-apply refused HAG_REMOTE_KEY_REUSE; no receipt or effects. | `defs-changed-key-request.json`; `defs-changed-key.json.stdout.txt` | This is a service conflict, not a host permission denial. |
| work-approval | accepted: WO-P3-901 approved by test-owner after passing selected transition gates. | `wo-preview.json`; `wo-approve.json` | Approval and start were separate operations. |
| work-start | accepted: WO-P3-901 became in_progress under test-executor. | `start-preflight.json`; `start-preview.json`; `start-apply.json` | No source change was needed. |
| local-assertion | passed: Local equality assertion exited0, stdout exact greeting passed\n, stderr empty. | `assertion.json`; `assertion.json.stdout.txt`; `export-later/files/src/greeting.py` | No separate type assertion or runtime-version measurement; no endpoint executed source tests. |
| risk | accepted: RISK-P3-901 and paired DEC-P3-901 recorded for candidate identity confusion. | `risk-apply.json`; `read-risk.json`; `read-dec.json` | Synthetic test data. |
| mitigation-decision | accepted: test-owner selected mitigate, linked WO-P3-901; DEC decided, RISK mitigating. | `decide-apply.json`; `mcp-revision.json`; `read-mitigating-risk.json` | Risk acceptance was not selected; no closed-risk claim. |
| outside-handoff | expected_refusal: QGP-G4I-PATHS/WEX201 refused docs/outside-greeting-scope.json; no writes, versions null, WO remained in_progress. | `handoff-outside-request.json`; `handoff-outside.json.stdout.txt` | No scope broadening; deliberate negative-test path was omitted from valid handoff. |
| valid-handoff | accepted: Valid scoped evidence retained against first accepted lifecycle input Git head. | `retained-base.json`; `handoff-preview.json`; `handoff-apply.json` | Retained base was not replaced by later start head. |
| work-completion | accepted: WO-P3-901 implemented by test-executor. | `complete-preview.json`; `complete-apply.json` | Does not itself verify or release. |
| verification-preparation | accepted: VREC-P3-901 ready, prepared by quality-owner; exact candidate captured. | `vrec-preview.json`; `vrec-apply.json`; `read-vrec-ready.json`; `export-assessment/` | Preparation is not verification acceptance. |
| verification-decision | accepted: VREC-P3-901 verified by quality-owner after assessment. | `verify-preview.json`; `verify-apply.json`; `read-vrec-verified.json` | Binds disposable test candidate P, not actual implementation C. |
| release-contract | accepted: REL-P3-901 approved by test-owner; candidate exactly matches verified VREC. | `REL-P3-901.md`; `rel-preview.json`; `rel-apply.json`; `read-rel-approved.json` | No guessed binding or accepted-record amendment. |
| release-preparation | accepted: RLS-P3-901 ready, prepared by release-owner for version0.0.1, WO901 and VREC901. | `rls-preview.json`; `rls-apply.json`; `export-release-review/` | Returned next-step context is not_assessable with no gates; command success is not a release decision. |
| release-decision | accepted: RLS-P3-901 released by release-owner after QG-G5-RELEASE-DECISION and structural gates passed. | `release-preview.json`; `release-apply.json`; `mcp-final-check.json` | No real tag, publication or deployment. |
| mcp-seven | observed_complete: All seven tools returned complete=true, continuation=null, no unresolved references on selected views. | `mcp-work-context.json`; `mcp-check.json`; `mcp-revision.json`; `mcp-final-compare.json`; `mcp-final-impact.json`; `mcp-final-lineage.json`; `mcp-final-cypher.json` | Checkpoint-free context/check is not approval and can report not_assessable. |
| immutable-exports | downloaded: Earlier18-file and later29-file snapshots saved separately; manifests read; source/imported hashes match. | `export-early.json`; `export-early/manifest.json`; `export-later.json`; `export-later/manifest.json` | Independent Git reconstruction/released-evaluator replay not performed. |
| qualification-discipline | deviations_retained: Reader errors recovered; task recovery used Get-Content outside the approved helper-only shell route. | `observations-index.json#/native_failures`; `file-read-trace.json` | Functional outcome does not establish an error-free instruction-following qualification. |

The new intent, capability, requirement, specification, verification and work order were reviewed against their selected type checklists. The outcome is an operator who can inspect the existing fixture and locate proof of exact equality. The approved scope covers the exact new records, source path and retained evidence directory. No fixture implementation change was needed. The release contract was deferred until the final verified candidate was known, then reviewed and approved with that exact binding.

The local assertion used the selected client Python on Windows with `-I -B` and compared the return value to `'Hello rehearsal'`. Its exact stdout is `"exact greeting passed\n"`, exit is `0`, and stderr is empty. The source is 45 bytes with SHA-256 `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`. The retained assertion capture is 740 bytes with SHA-256 `e0dc5ff07136cbbac9fd9086b85116da0b32153a086128a9aca3be710bd8957f`. The final exported source and assertion have these same hashes. This establishes the tested equality; it does not claim a separate type assertion, a measured Python version, or source-test execution by the service.

The original approval submission returned transport outcome `unknown` with exit 2. Lookup of `native-defs-apply` recovered receipt `sha256:61f1c1e321c1395b750f91f405096bf35878214e6cf2698d5f439c52eebb6ed3`. The identical resubmission used the same original request file and returned that same receipt, request digest and project/context versions. The complete parsed lookup and retry results compare equal after object-key sorting. Both describe project 15→16 and context 13→14; no second increment appears. Changing the reason while retaining the accepted key produced `HAG_REMOTE_KEY_REUSE`. [receipt-and-export-comparison.json](receipt-and-export-comparison.json) retains the comparison method and result.

The stale test reused an old preview after the selected INT draft changed. The first failing guard was `HAG_REMOTE_STALE_PROJECT`; this does not establish an isolated preview-digest-only refusal. The refusal returned no receipt, files or affected revisions. The fresh preview and accepted operation continued from project 15/context 13. The out-of-scope handoff failed `QGP-G4I-PATHS` with `WEX201` for `docs/outside-greeting-scope.json`. It returned no writes and kept the work order `in_progress`. The valid handoff used only approved paths and retained the original comparison base.

The seven configured MCP tools were exercised on explicit views. Every response below reports `complete=true`, `continuation=null`, and no unresolved references. Exact requests and complete response text are retained in the linked files. An additional context recovery read is in `mcp-context-recovered.json`.

| MCP tool | Evidence | Selected view | Complete / continuation / unresolved |
| --- | --- | --- | --- |
| work-context | [mcp-work-context.json](mcp-work-context.json) | context 14 | true / null / [] |
| check | [mcp-check.json](mcp-check.json) | context 17 | true / null / [] |
| revision | [mcp-revision.json](mcp-revision.json) | context 18 | true / null / [] |
| compare | [mcp-final-compare.json](mcp-final-compare.json) | earlier → later | true / null / [] |
| impact | [mcp-final-impact.json](mcp-final-impact.json) | later baseline | true / null / [] |
| lineage | [mcp-final-lineage.json](mcp-final-lineage.json) | later baseline | true / null / [] |
| cypher | [mcp-final-cypher.json](mcp-final-cypher.json) | later baseline | true / null / [] |
| check | [mcp-final-check.json](mcp-final-check.json) | later baseline | true / null / [] |

Comparison reports five added bindings and one changed binding between the exports; no imported `-900` binding changed. Impact from `REQ-P3-901` returns eight dependent artifacts. Lineage from `VREC-P3-901` returns its recorded verification/release relationships. Cypher returns `["RLS-P3-901", "released"]`. These reads report selected graph content, not new assurance. The checkpoint-free checks report lifecycle context with `not_assessable` and empty gates. Passed approval, verification and release gates are supported by their separate transition results.

| Export | Baseline | Snapshot | Files |
| --- | --- | --- | --- |
| [Earlier manifest](export-early/manifest.json) | `se-harness-artifact-baseline/v1:sha256:c70a6cd0348018dd8c13f7195528936dee496642a574cd78a099a433d64b8666` | `sha256:41976290d3b5aa67988f4200e772cb8c3391d76747ae0d81e958cac39b5c7bd6` | 18 |
| [Later manifest](export-later/manifest.json) | `se-harness-artifact-baseline/v1:sha256:1a60e3d47c3ce264a94d9f36b925c27214eaed3af55f0503886341241c18c96a` | `sha256:63c29b698b56df0d5f04151d204f7dc03ebab6f676b79a4bc3b50f1863669e48` | 29 |

The earlier Git bundle is 11,212 bytes, SHA-256 `0b9d5fd57bf589cfc91d4cdde5385228bb4d4eda9459ee2cb9efe8a7deee5bb5`, with head `4cc921dbab51608a4fd5e81537a2b345016109ed`. The later bundle is 26,796 bytes, SHA-256 `788b9f6398bac3d4a9b856488161d4dddd2fac4ab58c217f66c70eb76e08cf7d`, with head `d25596f196a8bedf6f4bfb107a78e697bee7059e`. These are manifest and successful client export observations, not independent reconstruction. The client reported `independent_replay: "not yet performed"`. Both new export destinations and their original bytes remain intact.

The later manifest retains P's original file hashes and binding to VREC-P3-901. The source and all seven imported record hashes match between early and later manifests. Two additional immutable exports, `export-assessment/` and `export-release-review/`, supported inspection before verification and release decisions. The RLS evaluator sidecar records full-payload inspection, the exact released evaluator tuple, isolated Python and empty diagnostics. The VREC sidecar has narrower identity fields; the complete evaluator tuple is retained in operation and snapshot provenance. Neither sidecar is a source-test result.

The run had errors and procedural deviations. The captured command failures are the uncertain approval reply, stale apply, changed-key request and out-of-scope handoff. Three observed reader errors concerned an oversized text-read limit, an incorrect RELEASE resource path, and a guessed drafting heading. Corrected bounded reads and the candidate's canonical selectors recovered them. Guessing those selectors did not follow the instruction to discover unknown headings first. After compaction, task recovery used `Get-Content` instead of the approved helper-only shell route; that was a procedural deviation, even though it was a read of the required task file. A later oversized observation-array extraction was truncated and failed JSON parsing in orchestration; the original capture remains intact and narrow fields were used instead. No permission denial was observed, and no permission setting or alternate execution route was used to bypass a denial.

[observations-index.json](observations-index.json) is an in-progress capture taken before final audit reads and report writes. It lists 201 observed tool items: 138 command-execution, 54 file-change and 9 MCP items. Its command-record array has 65 entries, including 4 failed command records. It lists 7 native failed items and 77 successful visible read entries. These measures overlap and are not an exhaustive final call/failure count. `native_call_count_complete` is false; wall time, total native calls and peak context are unknown.

[file-read-trace.json](file-read-trace.json) copies exact observed paths, hashes, sections and source line references, with task-to-read triggers. This trace is partial: JSON-pointer reads, typed document reads, task delivery/recovery and later audit reads are not exhaustively captured by its source. Section reads do not establish whole-file reads. No later read is presented as proof that an earlier prerequisite was read. Explicit test instructions do not establish automatic startup instruction delivery. Database-enforced read-only security and real engineering authority remain unverified.

The final evaluator's current step is `PROC-EXTERNAL-ACTION / STEP-EXTERNAL-ACTION` for `RLS-P3-901`, under `DR-EXTERNAL-ACTION`. Its operative response is: `Reuse the matching complete-release or external-action authorization for RLS-P3-901; request only an uncovered action and target.` This test selects stop at that boundary because no external action is authorized. The reviewer can now perform the separately requested independent reconstruction and released-0.22.1 replay of the retained exports.

