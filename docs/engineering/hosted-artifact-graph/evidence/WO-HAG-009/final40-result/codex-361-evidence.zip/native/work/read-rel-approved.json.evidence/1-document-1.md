+++
id = "REL-P3-901"
type = "release_contract"
title = "Private greeting test release 0.0.1"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
candidate_commit = "50b73b015badd5dc3d07e677258338a5fd63e2a4"

[relations]
gates = ["WO-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T04:22:34Z"
decided_by = "test-owner"
reason = "Synthetic test-owner accepts the complete release contract for version 0.0.1 bound to verified VREC-P3-901 candidate and WO-P3-901 only."
+++

# Private greeting test release 0.0.1

## Release unit
This first synthetic release is version 0.0.1 and covers only WO-P3-901. The exact disposable test candidate is `50b73b015badd5dc3d07e677258338a5fd63e2a4`, taken from verified VREC-P3-901. There is no previous release tag for this new test unit.

## Required evidence
VREC-P3-901 must remain verified and bind this same candidate, WO-P3-901 and VER-P3-901. Its assertion.json must retain the passing exact equality assertion; completion.md identifies the fixture source digest. Released evaluator 0.22.1 must pass release preparation and decision gates. Preserve the RLS evaluator sidecar, source bytes, candidate binding and exported Git history for independent review.

## Compatibility and migration
The fixture source is unchanged. This test record introduces no runtime migration or compatibility promise.

## Security and provenance
This is the selected loopback private sandbox. Source fixture S and disposable candidate P remain distinct from actual implementation candidate C. Imported -900 records remain unchanged. Synthetic actors have no real engineering authority.

## Promotion policy
Prepare and assess one test release record only. The supplied release-owner decision may authorize its synthetic released state after gates pass. A version tag string in the record is metadata only. No tag creation, push, publication, installation or deployment is authorized.

## Rollback criteria and procedure
On failed equality evidence, missing or changed bytes, candidate mismatch, failed gates or incomplete export, stop release assessment. Preserve all records and report the failed criterion. Do not overwrite accepted records or substitute a later commit; any correction needs separately authorized work. No deployed runtime exists to roll back.

## Observation
The operator inspects the later immutable export and its manifest once at handoff. Independent Git reconstruction and released-evaluator replay are recorded separately from download success.
