+++
id = "RISK-P3-901"
type = "risk"
title = "Greeting evidence may be attributed to a different candidate"
status = "raised"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
description = "Confusing fixture commit, disposable test candidate and implementation candidate could make the operator treat the local assertion as proof for untested bytes."
action = "Retain the fixture digest and exact assertion, then bind the evidence to the test candidate through WO-P3-901 and its verification record."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-901"]

[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-12T04:14:34Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."
+++

# Risk: Greeting evidence may be attributed to a different candidate

## Description

Confusing fixture commit, disposable test candidate and implementation candidate could make the operator treat the local assertion as proof for untested bytes.

## Next action

Retain the fixture digest and exact assertion, then bind the evidence to the test candidate through WO-P3-901 and its verification record.
