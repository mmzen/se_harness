+++
id = "SPEC-P3-901"
type = "specification"
title = "Selected fixture greeting interface"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
contract = "The no-argument greeting() in src/greeting.py returns exactly Hello rehearsal."

[relations]
specifies = ["REQ-P3-901"]
+++

# Selected fixture greeting interface

## Behavior
For REQ-P3-901, calling `greeting()` from `src/greeting.py` with no arguments returns exactly `Hello rehearsal`, including capitalization and the single space. A return value containing a trailing newline fails the equality criterion.

## Example and failure
`greeting() == 'Hello rehearsal'` evaluates true. An exception or unequal value fails verification and stops this rehearsal. No recovery interface is required.

## Design
The inspected fixture already implements the required behavior with one constant return. Retaining that implementation is the smallest solution; no abstraction, dependency, packaging or CI change is needed.
