+++
id = "RISK-P3-901"
type = "risk"
title = "Greeting evidence may be attributed to a different candidate"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
description = "Confusing fixture commit, disposable test candidate and implementation candidate could make the operator treat the local assertion as proof for untested bytes."
action = "Retain the fixture digest and exact assertion, then bind the evidence to the test candidate through WO-P3-901 and its verification record."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-901"]
mitigated_by = ["WO-P3-901"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-12T04:15:16Z"
reason = "Synthetic owner selects mitigation through the bounded greeting work and its retained source and candidate evidence."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-12T04:14:34Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-12T04:15:16Z"
decided_by = "test-owner"
reason = "Synthetic owner selects mitigation through the bounded greeting work and its retained source and candidate evidence."
+++

# Risk: Greeting evidence may be attributed to a different candidate

## Description

Confusing fixture commit, disposable test candidate and implementation candidate could make the operator treat the local assertion as proof for untested bytes.

## Next action

Retain the fixture digest and exact assertion, then bind the evidence to the test candidate through WO-P3-901 and its verification record.
