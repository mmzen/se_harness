Export destinations for the claude-361 native test. Each subdirectory is a separate new export destination written by the candidate client.
earlier-wo-approved: baseline se-harness-artifact-baseline/v1:sha256:717e127d2bfc5ae63589707bba8696491bb36c81eefbcc86f9fe5451ae9f673e
later-released: baseline se-harness-artifact-baseline/v1:sha256:918a7e1457fc6b507725c06e888f26a09f608758573ae88ea2d177ffc16baa8d
