```toml
artifact = "WO-P3-361"
checkpoint = "handoff"
formal_snapshot_sha256 = "a59e92fe4917013f13413daaf9a5ea8327a1871e85ed36d0a906114850608933"
rebound_at = "2026-10-12T04:20:16Z"
```

# WO-P3-361 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
