+++
id = "REL-P3-361"
type = "release_contract"
title = "Test release 0.0.1 of the rehearsal greeting record"
status = "draft"
owners = ["release-owner"]
created = "2026-10-12"
updated = "2026-10-12"
# Choose the final candidate and the work to release.
# `harnessctl release-unit . --from <tag> --to <commit>` gives advisory history.
candidate_commit = "88a856f170b2c472782e9d8da26450c1316cc23e"
previous_release_tag = "none"

[relations]
gates = ["WO-P3-361"]
+++

# Release Contract: Test release 0.0.1 of the rehearsal greeting record

Synthetic rehearsal input. This is not a real human decision.

## Release unit

Test version `0.0.1` contains only WO-P3-361 and its verification contract
VER-P3-361. The final candidate is test candidate commit
`88a856f170b2c472782e9d8da26450c1316cc23e`, bound by the verified test
VREC-P3-361. There is no earlier test release, so no previous release tag
exists.

## Required evidence

- VREC-P3-361 in `verified`, covering WO-P3-361 and VER-P3-361 at the
  candidate commit.
- The retained assertion record
  `docs/engineering/lifecycle-pilot/evidence/WO-P3-361/greeting-assertion.json`
  with exit 0 and stdout `exact greeting passed`.
- Released evaluator 0.22.1 evidence for the test RLS.

## Compatibility and migration

None. `greeting()` behavior is unchanged.

## Security and provenance

The service is a private loopback test copy. All actors are synthetic labels.
Git remains authoritative for real work.

## Promotion policy

Test release record only. No push, tag creation, publication, installation
or deployment. The RLS `tag` field records a label only.

## Human approval triggers

The synthetic `release-owner` decides the test RLS after its gates pass.

## Rollback criteria and procedure

Stop if the final candidate lacks complete verified coverage or release
approval. If replay of an export fails, discard the disposable test project;
nothing outside it is affected.

## Post-release observation window

None; no deployment occurs.
