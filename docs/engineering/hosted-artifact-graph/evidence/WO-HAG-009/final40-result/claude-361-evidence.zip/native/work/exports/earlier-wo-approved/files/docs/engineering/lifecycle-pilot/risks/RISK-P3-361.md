+++
id = "RISK-P3-361"
type = "risk"
title = "Assertion evidence may not match the verified test candidate"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
description = "The greeting assertion runs on the native host against the source fixture, while the test VREC binds a separate hosted test candidate commit. If the asserted src/greeting.py differs from the candidate's file, the verification and release records would rely on evidence for different bytes."
action = "Retain the exact assertion record, which checks the fixture SHA-256 before running, through the WO-P3-361 handoff, and compare that digest with src/greeting.py in the exported candidate snapshot before the VREC decision."
raised_by = "test-owner"
likelihood = 2
impact = 3
score = 6

[relations]
threatens = ["WO-P3-361"]
mitigated_by = ["WO-P3-361"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-12T04:17:05Z"
reason = "Synthetic test-owner input: choose mitigation for the test risk using WO-P3-361, which retains the digest-checked assertion record through handoff."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-12T04:16:10Z"
decided_by = "test-owner"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-12T04:17:05Z"
decided_by = "test-owner"
reason = "Synthetic test-owner input: choose mitigation for the test risk using WO-P3-361, which retains the digest-checked assertion record through handoff."
+++

# Risk: Assertion evidence may not match the verified test candidate

## Description

The greeting assertion runs on the native host against the source fixture, while the test VREC binds a separate hosted test candidate commit. If the asserted src/greeting.py differs from the candidate's file, the verification and release records would rely on evidence for different bytes.

## Next action

Retain the exact assertion record, which checks the fixture SHA-256 before running, through the WO-P3-361 handoff, and compare that digest with src/greeting.py in the exported candidate snapshot before the VREC decision.
