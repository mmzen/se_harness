# Native hosted-workflow qualification report (claude-361)

Test data only. The service is a private loopback test copy. All actors are
synthetic labels with no real authority. Git remains authoritative for real work.
No push, tag, publication, installation or deployment occurred.

## Selected context and evaluator

| Item | Value | Evidence |
| --- | --- | --- |
| Project | `3b3133cb-1a64-4b5b-925c-88322c914dc1` | `inputs/selection.json` |
| Endpoint | `http://127.0.0.1:50322` | `records/01-status` |
| Released evaluator | 0.22.1, archive `cb35c3c4…3053`, payload `0e7b7c2b…e79ff` | `inputs/evaluator.json`, every result `/evaluator` |
| Candidate client | 0.22.2, wheel `ada921b0…57150` | `identity` output; matches `inputs/combination.json` |
| Status | `ready: true`, `authority_mode: sandbox-projection`, `test_copy: true`, schema revision 2, all component identities equal to the combination | `records/01-status.stdout.txt` |

Context reporting is separate from gate results. Status and `check` without a
checkpoint report context only; gate results came from transition, handoff,
decide, capture and release previews/applies (`compliance.status`).

## Identities

| Name | Identity |
| --- | --- |
| Source fixture commit S | `5820415917e87b64d80bad2f7c39c6d18d692829` |
| Imported baseline B0 | `se-harness-artifact-baseline/v1:sha256:8214e0c5363809defb32a43665ef7f55bc444b2d2b8638209b077a32ab1d447d` |
| Draft context | `d6a04a4a-61bc-477a-8205-c8c542a35a19` (anchored on imported `WO-P3-900`; see failures) |
| Retained handoff base | `2e61d59c463ae632a54eb1bf74c920bd2e47fd19` (`input_git_head` of the first accepted lifecycle mutation, key `c361-L06-approve-defs-apply`) |
| Test Git candidate P (VREC/RLS) | `88a856f170b2c472782e9d8da26450c1316cc23e` |
| Actual implementation candidate C | Unknown; not established by this test. Test records bind P only. |
| Earlier baseline (WO approved) | `se-harness-artifact-baseline/v1:sha256:717e127d2bfc5ae63589707bba8696491bb36c81eefbcc86f9fe5451ae9f673e` |
| Final baseline (RLS released) | `se-harness-artifact-baseline/v1:sha256:918a7e1457fc6b507725c06e888f26a09f608758573ae88ea2d177ffc16baa8d` |

## Authored artifacts and final states

New records in `docs/engineering/lifecycle-pilot/`: INT, CAP, REQ, SPEC, VER,
WO, REL, RISK, DEC, VREC and RLS, all `*-P3-361`. Drafts are in `work/drafts/`.

| Artifact | Final state (Cypher read on final baseline) |
| --- | --- |
| INT/CAP/REQ/SPEC/VER-P3-361 | approved (`test-owner`) |
| WO-P3-361 | implemented (approved `test-owner`; start/complete `test-executor`) |
| RISK-P3-361 / DEC-P3-361 | mitigating / decided (`mitigate`, `mitigated_by` WO-P3-361, `test-owner`) |
| VREC-P3-361 | verified (`quality-owner` prepared and decided) |
| REL-P3-361 | approved (`test-owner`; see uncertainties) |
| RLS-P3-361 | released, version 0.0.1 (`release-owner` prepared and decided) |
| All imported `-900` records | draft, unchanged |

Content readiness: every new definition, the WO and the REL returned draft
admission with empty `incomplete` and passed `QGP-*-AUTHORING` gates. My separate
content review (against the released type checklists) found the drafts
complete for the supplied outcome. Template admission is not that review.

## Greeting proof

- Source inspection: `inputs/source/src/greeting.py` (sha256 `dcbd486a…cab1`)
  is `def greeting(): return 'Hello rehearsal'`.
- Executed test: `assert-greeting`, record `work/evidence/greeting-assertion.json`
  (sha256 `25060178789d3b6a982950887576a1f538b382c584f867a4dbfa3e00379229fb`):
  exit 0, stdout `exact greeting passed\n`, stderr empty, elapsed 0.122003 s.
- The same bytes were handed off to
  `docs/engineering/lifecycle-pilot/evidence/WO-P3-361/greeting-assertion.json`
  and bound by VREC-P3-361. Candidate P's `src/greeting.py` digest equals
  `dcbd486a…cab1` (`records/48-L25-capture-apply.stdout.txt` `/provenance/candidates`).
- No service endpoint ran source tests.

## Cases

| Case | Outcome | Evidence | Limit |
| --- | --- | --- | --- |
| Out-of-scope handoff | Refused by the released evaluator: `HAG_REMOTE_EVALUATOR_REFUSED`, blocked by `QGP-G4I-PATHS: WEX201: changed path is outside execution scope: notes/greeting-assertion.json`. No receipt; versions unchanged (next preview used 22/20). | `requests/L19-…`, `records/42-L19-handoff-out-of-scope` | Preview mode only |
| Valid handoff | Accepted, receipt `sha256:ff8d76d8…1d1b`; handoff check `pass`; 11 changed paths from base `2e61d59c…`, all in scope | `records/43-…`, `records/44-L21-handoff-apply` | — |
| Stale preview | Preview `sha256:18986e09…` at 16/14; then VER-P3-361 revised (ctx 15, project 17); applying old preview refused `HAG_REMOTE_STALE_PROJECT` (409), no effects. Validate inspection afterwards showed all five definitions still `draft`. Fresh preview `sha256:52c44ba0…` then applied. | `records/21-…`, `22-…`, `23-…`, `24-…`, `25-…` | — |
| Uncertain reply | Apply `c361-L06-approve-defs-apply` returned transport `outcome: unknown` (exit 2). Lookup of the original key: `accepted`, receipt `sha256:220d4268…d352`, versions 17→18. | `records/26-…`, `records/27-L06-operation-lookup` | — |
| Identical retry | Same request file, same key: `accepted`, same receipt and revision IDs, versions 17→18; stdout sha256 `78e60978…` equals the lookup's. No duplicate effect. | `records/28-L06-identical-retry` | — |
| Changed request, accepted key | One `reason` changed under the same key: refused `HAG_REMOTE_KEY_REUSE` (409), no effects. | `requests/L07-…`, `records/29-…` | — |
| Risk and decision | RISK-P3-361 + DEC-P3-361 raised (score 6), decided `mitigate` by `test-owner` | `records/31-…`, `35-…` | Risk remains `mitigating` |
| Host permission denial | None occurred | observations index | — |

## Lifecycle receipts (accepted applies)

| Key | Action | Receipt |
| --- | --- | --- |
| c361-L06-approve-defs-apply | approve 5 definitions | sha256:220d4268… |
| c361-L09-raise-risk-apply | raise risk + decision | sha256:f8aea8c7… |
| c361-L12-decide-apply | decide mitigate | sha256:dfd3c120… |
| c361-L15-approve-wo-apply | approve WO | sha256:900fd43a… |
| c361-L18-start-apply | start WO | sha256:8bdb0688… |
| c361-L21-handoff-apply | handoff | sha256:ff8d76d8… |
| c361-L23-complete-apply | WO implemented | sha256:cd07562b… |
| c361-L25-capture-apply | VREC ready | sha256:583d9f47… |
| c361-L27-vrec-verify-apply | VREC verified | sha256:75c6f1f0… |
| c361-L29-approve-rel-apply | REL approved | sha256:07d58dca… |
| c361-L31-prepare-release-apply | RLS ready | sha256:99a4b254… |
| c361-L33-rls-release-apply | RLS released | sha256:57c81aa8… |

After RLS release the evaluator's next step is `DR-EXTERNAL-ACTION`; no external
action is authorized, so the lifecycle stops there.

## MCP reads (all seven tools, final baseline unless noted)

| Tool | Request | complete / continuation |
| --- | --- | --- |
| work-context | WO-P3-361 | true / null; 5 governing, 10 declared paths, deps RLS+VREC, decision DEC |
| check | RLS-P3-361 | true / null; released, candidate P |
| lineage | REQ-P3-361 | true / null; empty artifacts and relations (root declares no verification links) |
| lineage | RLS-P3-361 | true / null; REL, VER, VREC, WO; 6 relations |
| impact | REQ-P3-361 | true / null; 8 artifacts, 15 relations |
| compare | earlier `717e127d` vs final `918a7e14` | true / null; 4 changes (REL, WO revised; VREC, RLS added) |
| revision | RLS-P3-361 `sha256:5bd41125…` | true / null; envelope + document |
| cypher | `MATCH (b:Baseline)-[s:SELECTS]->(r:Revision) RETURN r.artifact_id AS id, r.status AS status LIMIT 50`, `{}` | true / null; 18 rows |

Exact MCP requests and responses are retained in the session transcript only;
they were not copied to separate files.

## Exports

| Destination | Baseline | Snapshot | Files | Git head |
| --- | --- | --- | --- | --- |
| `work/exports/earlier-wo-approved` | `…717e127d…` | `sha256:86df9b5f…3c90` | 21 | `66d6ea2b5c4ab81537306d1e5e6e9214d2a50c36` |
| `work/exports/later-released` | `…918a7e14…` | `sha256:c0612396…ecff` | 28 | `5061433591d6ccfc0aa71d9a3734e70a1a726d22`; test candidate `88a856f1…` |

Later Git bundle: 27496 bytes, sha256 `4c578822…bb87`. Both results report
`independent_replay: not yet performed`. Download success is not replay.

## Failures and interventions (9 captured native errors)

1. `instructions` call with `docs/notes/harnessctl-reference.md` refused (not an
   inventory name); read it natively from `inputs/reference/` instead.
2. `draft-open` with new `WO-P3-361` refused `HAG_REMOTE_UNKNOWN_IDENTITY`
   (WO must exist in baseline). Reopened anchored on imported `WO-P3-900`; that
   record was never revised or transitioned.
3. REL revision refused `HAG_REMOTE_INVALID_DRAFT` / E011: `gates` accepts only
   work orders although the template lists `VER-xxx`. Resubmitted with a new key.
4. `read-json` pointer quoting error; corrected to the documented `'"/…"'` form.
5. Stale apply refusal (intended case).
6. Uncertain reply (endpoint-injected; recovered by lookup).
7. Key-reuse refusal (intended case).
8. Out-of-scope handoff refusal (intended case).
9. First export `not_sent`: parent directory missing. Created it by writing
   `work/exports/README.txt`, then retried.

## Uncertainties and gaps

- The v2 `check` action has no `--planned-path` option, so the planned-path
  coverage view was not run before WO approval.
- REL approval actor: I used `test-owner` (supplied "accept complete test
  definitions"); the REL's `owners` is `release-owner`. The evaluator accepted it.
- REL `previous_release_tag = "none"`: no earlier test release exists; accepted
  by draft admission, but its meaning was my choice.
- The intended outcome and scope were taken from the task as the synthetic
  requester confirmation; no separate exchange occurred.
- The assertion record includes host paths; it makes no Python version claim.
- RISK-P3-361 stays `mitigating`; no transition to `mitigated` was attempted.
- Observation snapshot `records/62-observations` was taken before these report
  writes; later writes are not counted there.
