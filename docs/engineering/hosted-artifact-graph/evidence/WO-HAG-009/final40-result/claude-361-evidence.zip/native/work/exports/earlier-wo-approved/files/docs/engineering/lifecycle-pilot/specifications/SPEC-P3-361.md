+++
id = "SPEC-P3-361"
type = "specification"
title = "Rehearsal greeting function contract"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
# What an implementation must do to conform. The Explorer shows this summary under the title.
contract = "The fixture function greeting() takes no arguments and returns the string Hello rehearsal."

[relations]
specifies = ["REQ-P3-361"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T04:14:48Z"
decided_by = "test-owner"
reason = "Synthetic test-owner input: accept complete test definitions."
+++

# Specification: Rehearsal greeting function contract

Synthetic rehearsal input. This is not a real human decision.

## In plain words

The file `src/greeting.py` has one function, `greeting()`, that gives back
`Hello rehearsal` every time it is called.

## Scope

This specification governs the `greeting()` function in `src/greeting.py`.
It leaves the check method and evidence to VER-P3-361.

## Terms

- **Fixture.** The selected immutable source snapshot that contains `src/greeting.py`.

## Rules

**GRT-CALL-001.** The implementation MUST define `greeting()` in
`src/greeting.py`, callable with no arguments, and return the string
`Hello rehearsal` exactly: no leading or trailing whitespace, no other
characters and the same letter case.

## Failure behaviour

| Trigger | Response | Diagnostic |
| --- | --- | --- |
| `greeting()` returns a value other than `Hello rehearsal` | The implementation does not conform to GRT-CALL-001 | `none` |

## Examples

**Given** the fixture `src/greeting.py`, **when** `greeting()` is called with
no arguments, **then** the result equals `Hello rehearsal` (GRT-CALL-001).

## Coverage

| Requirement | Rules |
| --- | --- |
| `REQ-P3-361` | GRT-CALL-001 |

## Not decided here

- The implementation language features beyond the function signature.
