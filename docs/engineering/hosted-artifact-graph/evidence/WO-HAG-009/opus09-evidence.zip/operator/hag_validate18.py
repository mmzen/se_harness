import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
h.run('next18-read-schema-validator',['docker','run','--rm','--network','none',
 '--mount',f'type=bind,source={h.R},target=/repo,readonly',
 '--mount',f'type=bind,source={h.W/"hag_validate_views18.py"},target=/test.py,readonly',
 '--mount',f'type=bind,source={h.O/"claude/native02/work/opus07/work"},target=/observed,readonly',
 '--entrypoint','python','harness-hag:native-guidance17','/test.py'])
h.gov('next18-validation','validate',new=True)
