"""Observe native MCP calls and independently repeat only their exact HTTP reads."""
import json,time,urllib.request,urllib.error,datetime,sys
from pathlib import Path
O=Path(__file__).resolve().parent/'hag-agent-qualification-execution-20261007'
hosts={'codex':O/'codex/native03','claude':O/'claude/native02/work/sonnet01'}
if len(sys.argv)>1 and sys.argv[1]=='codex-final':
    hosts={'codex-final':O/'codex-final/native04'}
if len(sys.argv)>1 and sys.argv[1]=='claude-final':
    hosts={'claude-final':O/'claude/native02/work/opus01'}
if len(sys.argv)>1 and sys.argv[1]=='codex-reads':
    hosts={'codex-reads':O/'codex-final/reads01'}
if len(sys.argv)>1 and sys.argv[1]=='guidance04':
    hosts={'codex-guidance04':O/'codex-guidance04/native06','claude-guidance04':O/'claude/native02/work/sonnet04'}
if len(sys.argv)>1 and sys.argv[1]=='guidance05':
    hosts={'claude-guidance05':O/'claude/native02/work/sonnet05'}
if len(sys.argv)>1 and sys.argv[1]=='guidance18':
    hosts={'claude-guidance18':O/'claude/native02/work/opus09'}
out=O/('native-parity-'+sys.argv[1] if len(sys.argv)>1 else 'native-parity');out.mkdir(exist_ok=False)
seen=set();calls={};total=0

def parsed(content):
    if isinstance(content,dict):return content
    if isinstance(content,str):
        try:return json.loads(content)
        except ValueError:return None
    if isinstance(content,list):
        for block in content:
            if isinstance(block,dict) and block.get('type')=='text':
                value=parsed(block.get('text'))
                if isinstance(value,dict):return value
    return None

def assess(host,key,tool,request,native):
    global total
    if (host,key) in seen:return
    seen.add((host,key));total+=1
    storage='codex-final' if host=='codex-reads' else host
    selection=json.loads((O/storage/'selection.json').read_text())
    credentials=json.loads((O/storage/'credentials.json').read_text())
    token=next(p['token'] for p in credentials['principals'] if p['id']=='operator')
    assert request['project_id']==selection['project_id']
    assert request['operation']==tool
    url=selection['endpoint']+'/v1/projects/'+selection['project_id']+'/reads/'+tool
    args=urllib.request.Request(url,json.dumps(request).encode(),{'Content-Type':'application/json','Authorization':'Bearer '+token},method='POST')
    try:
        try:response=urllib.request.urlopen(args,timeout=180)
        except urllib.error.HTTPError as exc:response=exc
        with response:
            status=response.status;http=json.loads(response.read())
        result={'host':host,'native_call_id':key,'tool':tool,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'method':'POST','url':url,'request':request,'native_result':native,'http_status':status,'http_result':http,
            'exact_match':native==http}
    except Exception as exc:
        result={'host':host,'native_call_id':key,'tool':tool,'request':request,'native_result':native,'error_type':type(exc).__name__,'exact_match':False}
    raw=json.dumps(result,indent=2,ensure_ascii=False)+'\n'
    assert token not in raw
    (out/f'{total:03d}-{host}-{tool}.json').write_text(raw,encoding='utf-8')
    print(json.dumps({'host':host,'tool':tool,'exact_match':result['exact_match'],'http_status':result.get('http_status')}),flush=True)

deadline=time.monotonic()+3800
while time.monotonic()<deadline:
    for host,root in hosts.items():
        if not (root/'events.jsonl').exists():continue
        for line in (root/'events.jsonl').read_text(encoding='utf-8').splitlines():
            try:event=json.loads(line)
            except ValueError:continue
            item=event.get('item',{})
            if event.get('type')=='item.completed' and item.get('type')=='mcp_tool_call' and item.get('server')=='hag':
                native=parsed((item.get('result') or {}).get('content'))
                assess(host,item['id'],item['tool'],item['arguments'],native)
            message=event.get('message',{})
            for block in message.get('content',[]) if isinstance(message,dict) else []:
                if not isinstance(block,dict):continue
                if block.get('type')=='tool_use' and block.get('name','').startswith('mcp__hag__'):
                    calls[host,block['id']]=(block['name'].removeprefix('mcp__hag__'),block['input'])
                if block.get('type')=='tool_result' and (host,block.get('tool_use_id')) in calls:
                    tool,request=calls[host,block['tool_use_id']]
                    assess(host,block['tool_use_id'],tool,request,parsed(block.get('content')))
    if all((p/'session.json').exists() for p in hosts.values()):break
    time.sleep(.5)
print(json.dumps({'observed_calls':total,'complete':all((p/'session.json').exists() for p in hosts.values())}),flush=True)
