import json,subprocess,sys
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007';o=h.O
helper=o/'claude/native02/inputs/native_call.py'
old=helper.read_bytes();h.write(o/'improve18-helper-before.py',old)
new=(h.R/'tests/hosted_artifact_graph/native_call.py').read_bytes()
h.write(helper,new)
h.write(o/'improve18-helper-binding.json',{'path':str(helper),'before_sha256':h.sha(old),'after_sha256':h.sha(new),'source_candidate':json.loads((o/'improve18-candidate.json').read_text())['commit'],'scope':'Same finite allowed helper prefix; adds bounded filename discovery and exact selected-field base64 decoding; no workflow choice. Prior helper retained; no prior native process is running.'})
for name in ('hag_audit16.py','hag_native_progress16.py','hag_native_parity16.py'):
 text=(h.W/name).read_text(encoding='utf-8').replace('guidance16','guidance18').replace('opus07','opus09').replace('8126918e7406b9630474f9c933bf66cb9eed6a29',h.git('rev-parse','HEAD'))
 h.write(h.W/name.replace('16','18'),text)
for args in [('hag_native_guidance18.py','state-before'),('hag_native_guidance18.py','setup','claude'),('hag_native_guidance18.py','stage','claude'),('hag_finish_native18.py',),('hag_focus18.py',),('hag_audit18.py','runtime')]:
 subprocess.run([str(h.HOST),'-X','utf8','-B',*args],cwd=h.W,check=True)
h.run('next18-packaged-schema-views',['docker','run','--rm','--network','none','--mount',f'type=bind,source={h.R},target=/repo,readonly','--mount',f'type=bind,source={h.W/"hag_validate_views18.py"},target=/test.py,readonly','--mount',f'type=bind,source={o/"claude/native02/work/opus07/work"},target=/observed,readonly','--entrypoint','python','harness-hag:native-guidance18','/test.py'])
assert not h.git('status','--porcelain')
print('Fresh diagnostic staged; no native workflow operations have run.')
