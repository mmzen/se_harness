import json,os
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
assert h.git('rev-parse','HEAD')=='29734167310f5164281718dd4565ef27a45dd240'
paths=h.git('diff','--name-only').splitlines()+h.git('ls-files','--others','--exclude-standard').splitlines()
scopes=h.record(h.D+'work-orders/WO-HAG-009.md')['execution_scope']['paths']
assert all(any(p==s or s.endswith('/') and p.startswith(s) for s in scopes) for p in paths)
h.run('next18-diff-check',['git','diff','--check'],cwd=h.R)
h.run('next18-plugin-checks',[h.HOST,'-X','utf8','-B','-m','unittest','discover','-s','tests/plugin_integration','-p','test_simple_plugin.py'],cwd=h.R,env=dict(os.environ,PYTHONUTF8='1'))
h.run('next18-stage',['git','add','--',*paths],cwd=h.R)
h.run('next18-commit',['git','commit','-m','Make hosted template reads and bounded file discovery explicit','-m','Harness-Work-Order: WO-HAG-009'],cwd=h.R)
h.write(h.O/'improve18-candidate.json',{'commit':h.git('rev-parse','HEAD'),'paths':paths})
assert not h.git('status','--porcelain')
for old,new in [('hag_improve17_build.py','hag_improve18_build.py'),('hag_native_guidance17.py','hag_native_guidance18.py'),('hag_finish_native17.py','hag_finish_native18.py')]:
 text=(h.W/old).read_text(encoding='utf-8').replace('improve17','improve18').replace('guidance17','guidance18').replace('opus08','opus09').replace('native08','native09').replace('package17','package18').replace('build17','build18').replace('client17','client18').replace('18361','18371').replace('18362','18372').replace('10.231.62.0/23','10.231.64.0/23')
 h.write(h.W/new,text)
print(h.git('rev-parse','HEAD'))
