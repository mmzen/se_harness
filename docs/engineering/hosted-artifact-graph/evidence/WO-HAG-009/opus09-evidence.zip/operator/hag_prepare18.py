import json
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007'
# Derive only temporary orchestration; preserve the previous trial source.
text=(h.W/'hag_focus17.py').read_text(encoding='utf-8').replace('guidance17','guidance18').replace('opus08','opus09')
text=text.replace("('remote-v1','lifecycle-v2')","('remote-v1','read-v1','lifecycle-v2')")
text=text.replace("branches=schema['$defs']['Command']['oneOf'] if family=='remote-v1' else schema['properties']['action']['oneOf']", "branches=schema['$defs']['Command']['oneOf'] if family=='remote-v1' else schema['$defs']['Request']['oneOf'] if family=='read-v1' else schema['properties']['action']['oneOf']")
text=text.replace("key='operation' if family=='remote-v1' else 'kind'", "key='kind' if family=='lifecycle-v2' else 'operation'")
text=text.replace("operation=branch['properties'][key]['const'];view=operation_view(raw,family,operation)","operation=(branch['allOf'][1] if family=='read-v1' else branch)['properties'][key]['const'];view=operation_view(raw,family,operation)")
text=text.replace("helper=o/'claude/native02/inputs/native_call.py'", "for operation in ('read','operation','create-artifact','revise-artifact'):\n h.write(inputs/'client-help'/(operation+'.txt'),subprocess.check_output([selection['client_python'],'-I','-m','se_harness','remote',operation,'--help'],cwd=h.W))\nhelper=o/'claude/native02/inputs/native_call.py'")
start=text.index('Prepare new draft definitions for an operator');end=text.index('\n## Entry and file discovery',start)
text=text[:start]+'''Prepare exactly one new intent draft for an operator who needs to establish that
the existing fixture's greeting() returns exactly `Hello rehearsal`. Inspect the
fixture and author the intent in the selected private service. Keep it as draft
and report its actual authoring findings. Use domain lifecycle-pilot and synthetic
owner test-owner. Imported -900 records are immutable history. Do not create other
artifacts, approve anything, start work, freeze a baseline or exercise lifecycle
decisions. Stop when this one draft is complete and its current findings retained,
or report the exact blocker. This is a focused diagnostic, not a full package.
''' + text[end:]
text=text.replace('The fixed helper\'s lookup-file resolves one relative input name with its current',"When a filename is known but its path is not, use the fixed helper's find-file\nBASENAME (optionally --under PREFIX/). It returns bounded candidates without\nchoosing one. Its lookup-file resolves one exact relative input name with its current")
text=text.replace('schemas/remote-v1/OPERATION.json. Lifecycle views are available separately but', 'schemas/remote-v1/OPERATION.json. Read-operation views are\nschemas/read-v1/OPERATION.json. Actual captured CLI help is\nclient-help/CLI_OPERATION.txt (read, operation, create-artifact, revise-artifact).\nLifecycle views are available separately but')
text=text.replace('Its help describes lookup-file, read-json,','Its help describes find-file, lookup-file, read-json,')
text=text.replace('Never treat command exit alone as a passed check or template creation as approval.','The field reader can decode an explicitly selected base64 string with\n--decode-base64; it returns exact UTF-8 and its byte digest without writing files.\nNever treat command exit alone as a passed check or template creation as approval.')
h.write(h.W/'hag_focus18.py',text)
stage=(h.W/'hag_stage17.py').read_text(encoding='utf-8').replace('improve17','improve18').replace('guidance17','guidance18').replace('hag_finish_native17','hag_finish_native18').replace('hag_focus17','hag_focus18').replace('hag_audit17','hag_audit18').replace("replace('16','17')","replace('16','18')").replace("replace('opus07','opus08')","replace('opus07','opus09')").replace('next17','next18').replace('hag_validate_views17','hag_validate_views18')
stage=stage.replace('adds read-only exact input lookup and exact bounded output rendering','adds bounded filename discovery and exact selected-field base64 decoding; no workflow choice')
h.write(h.W/'hag_stage18.py',stage)
test=(h.W/'hag_validate_views17.py').read_text(encoding='utf-8')
test=test.replace("('remote-v1','lifecycle-v2')","('remote-v1','read-v1','lifecycle-v2')")
test=test.replace("branches=source['$defs']['Command']['oneOf'] if family=='remote-v1' else source['properties']['action']['oneOf']", "branches=source['$defs']['Command']['oneOf'] if family=='remote-v1' else source['$defs']['Request']['oneOf'] if family=='read-v1' else source['properties']['action']['oneOf']")
test=test.replace("key='operation' if family=='remote-v1' else 'kind'", "key='kind' if family=='lifecycle-v2' else 'operation'")
test=test.replace("branch['properties'][key]['const']", "(branch['allOf'][1] if family=='read-v1' else branch)['properties'][key]['const']")
where=test.index("print(json.dumps(")
test=test[:where]+'''raw=Path('/repo/server/contracts/read-v1.json').read_bytes();source=json.loads(raw)
view=operation_view(raw,'read-v1','revision')['schema']
request={'schema':'se-harness-graph-read/v1','operation':'revision','project_id':'00000000-0000-4000-8000-000000000001','view':{'kind':'context','context_id':'00000000-0000-4000-8000-000000000002','context_version':1},'budget':{'rows':1,'bytes':100000,'depth':0},'artifact_id':'INT-P3-001','revision_id':'sha256:'+'1'*64}
original=Draft202012Validator(source);selected=Draft202012Validator(view)
assert original.is_valid(request)==selected.is_valid(request)==True;checks+=1
for field in request:
 missing=copy.deepcopy(request);missing.pop(field)
 assert original.is_valid(missing)==selected.is_valid(missing)==False,field
 checks+=1
for extra in ('operation_key','key','unexpected'):
 changed={**request,extra:'forbidden'}
 assert original.is_valid(changed)==selected.is_valid(changed)==False
 checks+=1
''' + test[where:]
test=test.replace('exact observed v1 requests and every required-field deletion/extra-field refusal','exact observed v1 requests and a revision-read request with required-field deletion/extra-field refusal')
h.write(h.W/'hag_validate_views18.py',test)
print('Prepared the focused single-intent diagnostic and read-schema checks.')
