"""Retain observed focused discovery, without claiming lifecycle qualification."""
import collections,json,os,sys
from pathlib import Path
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007';o=h.O;r=o/'claude/native02/work/opus09';g=o/'claude-guidance18';review=o/'review18';review.mkdir(exist_ok=True)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert (r/'session.json').exists()
assert load(o/'guidance18-state-before.json')==load(o/'guidance18-state-after.json')
events=[json.loads(x) for x in (r/'events.jsonl').read_text(encoding='utf-8').splitlines()]
calls={};results={};reads=[];writes=[];shell=[];peaks=[];sizes=[];errors=[]
inventory={str(Path(x['path'])).lower():x for x in load(r/'inputs/inventory.json')['files']}
for line,event in enumerate(events,1):
 m=event.get('message',{});blocks=m.get('content',[]) if isinstance(m,dict) else []
 if isinstance(m,dict) and m.get('usage'):
  u=m['usage'];peaks.append({'line':line,'tokens':sum(u.get(k,0) for k in ('input_tokens','cache_creation_input_tokens','cache_read_input_tokens'))})
 for b in blocks:
  if not isinstance(b,dict):continue
  if b.get('type')=='tool_use':
   call={'line':line,'name':b['name'],'input':b['input'],'id':b['id']};calls[b['id']]=call
   if b['name']=='Read':reads.append(call)
   if b['name']=='Write':writes.append(call)
   if b['name']=='Bash':shell.append(call)
  if b.get('type')=='tool_result':
   results[b['tool_use_id']]={'line':line,'error':bool(b.get('is_error')),'content':b.get('content')}
   sizes.append(len(json.dumps(b.get('content'),ensure_ascii=False).encode()))
   if b.get('is_error'):errors.append({'line':line,'call':calls.get(b['tool_use_id']), 'content':b.get('content')})
trace=[]
for call in reads:
 path=Path(call['input']['file_path']);inv=inventory.get(str(path).lower());result=results.get(call['id'])
 if inv:assert h.sha(path.read_bytes())==inv['sha256'],path
 trace.append({**call,'result_line':result['line'] if result else None,'returned_error':result['error'] if result else None,'staged_sha256':inv['sha256'] if inv else None,'extent':'Only the requested offset/limit; no full-file inference.'})
drafts=[w for w in writes if w['input'].get('content','').startswith('+++')]
first=min((w['line'] for w in drafts),default=None)
first_template=min((c['line'] for c in shell if 'create-artifact' in c['input']['command'] and '--help' not in c['input']['command']),default=None)
prerequisites={}
for name in ('DRAFT_DEFINITIONS.md','ARTIFACT_AUTHORING.md','ARTIFACTS.md','DEFINITION_LINKS.md'):
 hits=[x for x in trace if Path(x['input']['file_path']).name==name and x['returned_error'] is False]
 prerequisites[name]={'reads':hits,'before_first_content_write':bool(hits and min(x['result_line'] for x in hits)<first) if first else None,'before_first_template_creation':bool(hits and first_template and min(x['result_line'] for x in hits)<first_template)}
selection=load(g/'selection.json');creds=load(g/'credentials.json');token=next(p['token'] for p in creds['principals'] if p['id']=='operator')
env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token)
base=[selection['client_python'],'-I','-m','se_harness','remote'];opts=['--endpoint',selection['endpoint'],'--project',selection['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--json']
status=h.run('opus09-final-status',[*base,'status',*opts],env=env)
receipts=[]
for p in sorted((r/'work').rglob('*.json')):
 try:
  record=load(p);value=json.loads(record['stdout']) if isinstance(record,dict) and 'stdout' in record else None
 except ValueError:continue
 if not isinstance(value,dict) or value.get('outcome')!='accepted':continue
 key=value['operation_key'];result=h.run('opus09-receipt-'+key,[*base,'operation','--key',key,*opts],env=env)
 assert result==value,(p,key)
 receipts.append({'file':p.relative_to(r).as_posix(),'sha256':h.sha(p.read_bytes()),'key':key,'view':value.get('view'),'versions':value.get('versions'),'affected_artifacts':value.get('affected_artifacts'),'exact_lookup_match':True})
value={'trial':'opus09','kind':'Focused draft discovery diagnostic, not full NQ qualification','session':load(r/'session.json'),'source_candidate':load(g/'native-selection.json')['qualification_candidate'],'components':load(g/'combination.json'),'prerequisite_reads':prerequisites,'first_draft_content_write_line':first,'draft_content_writes':drafts,'read_trace':trace,'errors':errors,'shell_calls':shell,'receipt_lookups':receipts,'status_after':status,'peak_observed_input_context_tokens':max((x['tokens'] for x in peaks),default=0),'peak_before_first_draft_write':max((x['tokens'] for x in peaks if first and x['line']<=first),default=None),'tool_result_text_bytes':sum(sizes),'largest_tool_result_bytes':max(sizes,default=0),'tool_calls':dict(collections.Counter(x['name'] for x in calls.values())),'host_state_unchanged':True,'limits':['Observed reads require review of the requested extents against the selected type checklists.','Exact receipt lookup confirms draft effects; it is not independent released lifecycle replay.','NQ-02 lifecycle completion, NQ-03 seven-tool/refusal coverage, NQ-04 reply recovery and NQ-05 exports are unperformed in this diagnostic.','No real assurance, completion, merge, release, deployment or risk acceptance.','The narrower task prevents a controlled efficiency comparison with earlier full-lifecycle prompts.']}
h.write(review/'opus09-assessment.json',value)
print(json.dumps({k:value[k] for k in ('source_candidate','first_draft_content_write_line','peak_observed_input_context_tokens','peak_before_first_draft_write','tool_calls','host_state_unchanged')}))
print(json.dumps({'prerequisites':{k:v['before_first_content_write'] for k,v in prerequisites.items()},'accepted_receipts':len(receipts),'errors':len(errors)}))
