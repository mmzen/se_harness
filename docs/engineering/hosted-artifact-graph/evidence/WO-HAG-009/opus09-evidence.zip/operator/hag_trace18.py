"""Compact observer of actual call order; no instructions are sent to the test."""
import json
from pathlib import Path
root=Path(__file__).resolve().parent/'hag-agent-qualification-execution-20261007/claude/native02/work/opus09'
calls={};summaries=[]
for n,line in enumerate((root/'events.jsonl').read_text(encoding='utf-8').splitlines(),1):
 try:event=json.loads(line)
 except ValueError:continue
 message=event.get('message',{})
 for block in message.get('content',[]) if isinstance(message,dict) else []:
  if not isinstance(block,dict):continue
  if block.get('type')=='tool_use':
   data=block['input'];name=block['name'];value={'line':n,'tool':name}
   if name in ('Read','Write','Edit'):
    value.update(path=data['file_path'].replace(str(root),'TRIAL'),offset=data.get('offset'),limit=data.get('limit'))
   elif name=='Bash':
    command=data['command'];pos=command.find('native_call.py')
    value['command']=command[pos+len('native_call.py'):].lstrip('" ') if pos>=0 else 'outside approved helper prefix'
    value['command']=value['command'].replace(str(root).replace('\\','/'),'TRIAL')
   else:value['input']=data
   calls[block['id']]=value;summaries.append(value)
  if block.get('type')=='tool_result' and block.get('tool_use_id') in calls:
   value=calls[block['tool_use_id']];value['result_line']=n;value['error']=bool(block.get('is_error'))
   if value['error']:
    content=str(block.get('content'));value['error_excerpt']=content[:120]+' ... '+content[-350:]
print(json.dumps(summaries[-22:],ensure_ascii=False,indent=2))
