import copy,json,sys
from pathlib import Path
from jsonschema import Draft202012Validator
sys.path.insert(0,'/repo/tests/hosted_artifact_graph')
from native_schema import operation_view
checks=0
for family in ('remote-v1','read-v1','lifecycle-v2'):
 raw=(Path('/repo/server/contracts')/(family+'.json')).read_bytes();source=json.loads(raw)
 branches=source['$defs']['Command']['oneOf'] if family=='remote-v1' else source['$defs']['Request']['oneOf'] if family=='read-v1' else source['properties']['action']['oneOf']
 key='kind' if family=='lifecycle-v2' else 'operation'
 for branch in branches:
  view=operation_view(raw,family,(branch['allOf'][1] if family=='read-v1' else branch)['properties'][key]['const'])['schema']
  Draft202012Validator.check_schema(view);checks+=1
  assert not Draft202012Validator(view).is_valid({});checks+=1
source=json.loads(Path('/repo/server/contracts/remote-v1.json').read_bytes())
original=Draft202012Validator(source)
for path in Path('/observed').glob('*.json'):
 request=json.loads(path.read_bytes())
 if not isinstance(request,dict) or request.get('schema')!='se-harness-remote-command/v1':continue
 view=operation_view(Path('/repo/server/contracts/remote-v1.json').read_bytes(),'remote-v1',request['operation'])['schema']
 selected=Draft202012Validator(view)
 assert original.is_valid(request)==selected.is_valid(request)==True,path
 checks+=1
 for field in view['required']:
  missing=copy.deepcopy(request);missing.pop(field)
  assert original.is_valid(missing)==selected.is_valid(missing)==False,(path,field)
  checks+=1
 extra={**request,'unexpected':True}
 assert original.is_valid(extra)==selected.is_valid(extra)==False
 checks+=1
raw=Path('/repo/server/contracts/read-v1.json').read_bytes();source=json.loads(raw)
view=operation_view(raw,'read-v1','revision')['schema']
request={'schema':'se-harness-graph-read/v1','operation':'revision','project_id':'00000000-0000-4000-8000-000000000001','view':{'kind':'context','context_id':'00000000-0000-4000-8000-000000000002','context_version':1},'budget':{'rows':1,'bytes':100000,'depth':0},'artifact_id':'INT-P3-001','revision_id':'sha256:'+'1'*64}
original=Draft202012Validator(source);selected=Draft202012Validator(view)
assert original.is_valid(request)==selected.is_valid(request)==True;checks+=1
for field in request:
 missing=copy.deepcopy(request);missing.pop(field)
 assert original.is_valid(missing)==selected.is_valid(missing)==False,field
 checks+=1
for extra in ('operation_key','key','unexpected'):
 changed={**request,extra:'forbidden'}
 assert original.is_valid(changed)==selected.is_valid(changed)==False
 checks+=1
print(json.dumps({'checks':checks,'pass':True,'method':'JSON Schema validator: all staged operation shapes; exact observed v1 requests and a revision-read request with required-field deletion/extra-field refusal. No hosted scenario claimed.'}))
