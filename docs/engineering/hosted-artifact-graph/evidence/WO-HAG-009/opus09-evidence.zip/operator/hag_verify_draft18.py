"""Independent readback of the final submitted draft; never advance its state."""
import base64,json,os,tomllib
from pathlib import Path
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007';o=h.O;r=o/'claude/native02/work/opus09';g=o/'claude-guidance18'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert (r/'session.json').exists()
selection=load(g/'selection.json');token=next(p['token'] for p in load(g/'credentials.json')['principals'] if p['id']=='operator')
env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token)
records=[]
for p in (r/'work').rglob('*.json'):
 try:
  value=load(p);result=json.loads(value['stdout']) if isinstance(value,dict) and 'stdout' in value else None
 except ValueError:continue
 if not isinstance(result,dict) or result.get('outcome')!='accepted':continue
 argv=value['argv'];operation=argv[argv.index('remote')+1]
 if operation=='revise-artifact':records.append((result,p,value))
if not records:
 h.write(o/'opus09-draft-readback.json',{'completed_revision_observed':False,'reason':'No accepted revise-artifact receipt in the retained native command records.'})
 print('No completed revision exists; diagnostic remains incomplete.');raise SystemExit
result,p,record=max(records,key=lambda x:x[0]['versions']['project']['after'])
request=load(Path(record['argv'][record['argv'].index('--request')+1]))
assert request['operation']=='revise-artifact'
selected=next(a for a in result['affected_artifacts'] if a['artifact_id']==request['artifact_id'])
read={'schema':'se-harness-graph-read/v1','operation':'revision','project_id':selection['project_id'],'view':result['view'],'artifact_id':selected['artifact_id'],'revision_id':selected['revision_id'],'budget':{'rows':5,'bytes':200000,'depth':0}}
h.write(o/'opus09-independent-read-request.json',read)
actual=h.run('opus09-independent-final-revision',[selection['client_python'],'-I','-m','se_harness','remote','read','--endpoint',selection['endpoint'],'--project',selection['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--request',o/'opus09-independent-read-request.json','--json'],env=env)
assert actual['complete'] is True and actual['continuation'] is None and actual['view']==result['view']
data=actual['data'];body=base64.b64decode(data['document_base64'],validate=True)
assert body==base64.b64decode(request['document_base64'],validate=True)
assert data['revision_id']==selected['revision_id'] and data['envelope']['document_sha256']==h.sha(body)
metadata=tomllib.loads(body.decode('utf-8').split('+++',2)[1])
assert metadata['id']==selected['artifact_id'] and metadata['type']=='intent' and metadata['status']=='draft'
assert 'lifecycle_events' not in metadata
assessment={'completed_revision_observed':True,'artifact_id':selected['artifact_id'],'revision_id':selected['revision_id'],'view':result['view'],'document_sha256':h.sha(body),'document_bytes':len(body),'native_submitted_bytes_equal_independent_service_bytes':True,'status':metadata['status'],'type':metadata['type'],'evaluator_output':result['evaluator_output'],'native_record':p.relative_to(r).as_posix(),'limits':'Readback confirms exact submitted draft and evaluator findings. It approves no artifact or work and does not qualify the full lifecycle.'}
h.write(o/'opus09-draft-readback.json',assessment)
print(json.dumps({k:assessment[k] for k in ('artifact_id','status','document_bytes','native_submitted_bytes_equal_independent_service_bytes')}))
