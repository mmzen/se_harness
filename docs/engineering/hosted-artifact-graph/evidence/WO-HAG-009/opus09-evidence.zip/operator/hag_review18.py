"""Review the diagnostic's observed ordering and exact draft readback."""
import base64,json
from pathlib import Path
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007';r=o/'claude/native02/work/opus09';review=o/'review18'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert (r/'session.json').exists()
a=load(review/'opus09-assessment.json');calls=a['shell_calls'];reads=a['read_trace']
first=a['first_draft_content_write_line']
decodes=[c for c in calls if '--decode-base64' in c['input']['command']]
template=load(r/'work/read-intent-result.json.stdout.txt')
decoded=base64.b64decode(template['data']['document_base64'],validate=True)
assert template['complete'] is True and template['continuation'] is None
assert h.sha(decoded)==template['data']['envelope']['document_sha256']
assert len(decodes)==1 and decodes[0]['line']<first
names=[Path(x['input']['file_path']).name for x in reads]
source_reads=[x for x in reads if '/inputs/source/' in x['input']['file_path'].replace('\\','/')]
schema_reads=[x for x in reads if '/inputs/schemas/' in x['input']['file_path'].replace('\\','/')]
native=load(r/'native-observations.json')
digests=[{'path':x['file'],'reported':x['sha256'],'actual':h.sha((r/'inputs'/x['file']).read_bytes())} for x in native['instructions_read']]
for item in digests:item['matches']=item['reported']==item['actual']
assert source_reads and all(x['result_line']<first and x['returned_error'] is False for x in source_reads)
value={'source_candidate':a['source_candidate'],'template_decode_before_draft_authorship':True,'template_revision':template['data']['revision_id'],'template_sha256':h.sha(decoded),'template_read_complete':True,'readback':load(o/'opus09-draft-readback.json'),'inventory_file_read_observed':'inventory.json' in names,'source_file_reads':source_reads,'fixture_assertion_executed':any(' assert-greeting ' in x['input']['command'] for x in calls),'reported_instruction_digest_comparison':digests,'schema_views_read':[x['input']['file_path'].split('schemas',1)[1] for x in schema_reads],'find_file_calls':sum(' find-file ' in x['input']['command'] for x in calls),'create_artifact_calls':sum(' remote create-artifact ' in x['input']['command'] for x in calls),'native_final_report_present':(r/'native-report.md').exists(),'judgement_findings':['The source was inspected at trace lines 109-110; no assertion was executed. The native report should identify inspection as the method.','The submitted success-measure target is Confirmed by verification; this conflicts with the generated intent template distinction between operational measures and acceptance checks.','The draft claim that no formal record exists is unsupported by a content read of imported records.','The native reports omit six observed command errors or denials; reported instruction digests require the independent comparison below.'],'conclusion':'The exact template-read correction and source inspection worked. Content review and evidence reporting remain incomplete; draft admission does not establish a clean diagnostic pass or full native qualification.'}
h.write(o/'opus09-review.json',value)
print(json.dumps({k:value[k] for k in ('template_decode_before_draft_authorship','inventory_file_read_observed','source_file_reads','find_file_calls','create_artifact_calls','native_final_report_present')}))
print(json.dumps({'instruction_digest_matches':digests}))
