"""Archive the focused test and its exact checked inputs; exclude credentials."""
import json,re,zipfile
from pathlib import Path
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007';out=o/'review18';r=o/'claude/native02/work/opus09';g=o/'claude-guidance18'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert (r/'session.json').exists()
tokens=[x['token'].encode() for p in o.glob('claude-guidance*/credentials.json') for x in load(p)['principals']]
files={}
for name in ('events.jsonl','stderr.txt','session.json','invocation.json','selection.json','task.md','reply-fault.json','native-report.md','native-observations.json','mcp.json','CLAUDE.md'):
 p=r/name
 if p.is_file():files['native/'+name]=p
for sub in ('work','inputs'):
 for p in (r/sub).rglob('*'):
  if p.is_file() and not p.name.endswith(('.whl','.pyc')):files['native/'+p.relative_to(r).as_posix()]=p
for name in ('selection.json','combination.json','stage-evidence.json','native-selection.json','native-task.md','permissions.json','correction-binding.json'):
 files['setup/'+name]=g/name
for pattern in ('next18-*.json','improve18-*.json','runtime-reuse-guidance18.json','build18-replay.json','guidance18-state-*.json','claude-guidance18-version.json','claude-guidance18-auth-probe.json','opus09-*.json'):
 for p in o.glob(pattern):files['checks/'+p.name]=p
for p in (o/'native-parity-guidance18').glob('*.json'):files['independent-mcp/'+p.name]=p
for name in ('hag_native_guidance18.py','hag_finish_native18.py','hag_focus18.py','hag_stage18.py','hag_next18.py','hag_freeze18.py','hag_improve18_build.py','hag_validate_views18.py','hag_audit18.py','hag_native_parity18.py','hag_assess18.py','hag_retain18.py','hag_prepare18.py','hag_verify_draft18.py','hag_validate18.py','hag_review18.py','hag_trace18.py'):
 files['operator/'+name]=h.W/name
files['operator/native_call.py']=h.R/'tests/hosted_artifact_graph/native_call.py'
files['operator/prior-native_call.py']=o/'improve18-helper-before.py'
archive=out/'opus09-evidence.zip';inventory=[]
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):
  raw=p.read_bytes();assert not p.is_symlink(),p
  assert not any(t in raw for t in tokens),name
  assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
  assert not any(part in ('.git','credentials.json') for part in Path(name).parts)
  z.writestr(name,raw);inventory.append({'path':name,'bytes':len(raw),'sha256':h.sha(raw)})
h.write(out/'opus09-inventory.json',{'archive':archive.name,'bytes':archive.stat().st_size,'sha256':h.sha(archive.read_bytes()),'files':inventory,'redaction':'Exact native recorder redaction retained. Checked against known private project tokens and provider-token prefixes. Credentials, wheel binaries, Git directories and account stores excluded.'})
print(json.dumps({'files':len(inventory),'archive_bytes':archive.stat().st_size}))
