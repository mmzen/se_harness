# Native drafting diagnostic report

## Scope

Focused hosted drafting diagnostic under WO-HAG-009. One new intent draft
(INT-P3-001) was prepared in a private sandbox-projection test copy to
establish that the existing fixture's `greeting()` returns exactly
`Hello rehearsal`. This is not a complete NQ-01--05 qualification claim.

## Instruction paths and read triggers

| Instruction | Path | Read trigger |
| --- | --- | --- |
| CLAUDE.md (project) | `CLAUDE.md` | Session start |
| task.md | `task.md` | Session start |
| selection.json | `selection.json` | Session start |
| Setup skill (hosted sandbox route) | `inputs/plugin/verity-plane/skills/setup/SKILL.md` | verity-plane:setup invocation |
| Change skill | `inputs/plugin/verity-plane/skills/change/SKILL.md` | Draft preparation |
| Harness-orient skill (Read one hosted revision) | `inputs/plugin/verity-plane/skills/harness-orient/SKILL.md` | Reading created template |
| DRAFT_DEFINITIONS.md | `inputs/released-resources/docs/engineering/harness/DRAFT_DEFINITIONS.md` | Prerequisite before drafting |
| ARTIFACT_AUTHORING.md (design-simplicity + intent checklist) | `inputs/released-resources/docs/engineering/ARTIFACT_AUTHORING.md` | Prerequisite before drafting |
| ARTIFACTS.md (artifact-types, artifact-locations) | `inputs/released-resources/docs/engineering/harness/ARTIFACTS.md` | Prerequisite before drafting |
| draft-open schema view | `inputs/schemas/remote-v1/draft-open.json` | Before constructing draft-open request |
| create-artifact schema view | `inputs/schemas/remote-v1/create-artifact.json` | Before constructing create-artifact request |
| revise-artifact schema view | `inputs/schemas/remote-v1/revise-artifact.json` | Before constructing revise-artifact request |
| revision read schema view | `inputs/schemas/read-v1/revision.json` | Before reading artifact content |
| create-artifact CLI help | `inputs/client-help/create-artifact.txt` | Before constructing remote commands |

## Digest sources

| Source | SHA-256 |
| --- | --- |
| Fixture `src/greeting.py` | `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1` |
| Client wheel `se_harness-0.22.2` | `419fc2a2f72144c2e396736487a1f456316d074dd23735bb98ff59addbb41444` |
| Evaluator archive 0.22.1 | `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053` |
| Evaluator payload 0.22.1 | `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff` |
| Combination report | `sha256:d25ad894929eaaf3c5ddbed6c105a6c05e37cddad37d6b63a99c46a0325c482d` |
| Completed document INT-P3-001 | `57b267bea065645a6c260f5164c9b11e6be825c9701a700790b406b23030172b` |

## Operations performed

1. **Status check** — Verified sandbox readiness, authority mode
   `sandbox-projection`, `test_copy: true`, and all component identities
   against the combination report.

2. **Import** (operation key: `import-source-001`) — Imported the 7-artifact
   source manifest (INT/CAP/REQ/SPEC/VER/REL/WO-P3-900). Evaluator validated
   with 0 errors, 1 advisory (W-AUT-022). Baseline ID:
   `se-harness-artifact-baseline/v1:sha256:c10f54861349fa3c16182a03765f619a3b08b2a7dad0e894bec0ec5ebe602dc9`.
   Project version: 0 → 1.

3. **Draft-open** (operation key: `draft-open-001`) — Opened draft context
   for WO-P3-900. Context ID: `dbee6059-5a66-4b27-9689-f00b7e99ae86`,
   version 0. Project version: 1 → 2. Instruction discovery status: available.

4. **Create-artifact** (operation key: `create-intent-001`) — Created intent
   template INT-P3-001 in domain `lifecycle-pilot`. Admissible with 10
   incomplete placeholder findings. Context version: 0 → 1. Project version: 2 → 3.

5. **Read revision** — Retrieved the created template via hosted read. Decoded
   base64 document. Decoded SHA-256 matched envelope's `document_sha256`.

6. **Revise-artifact** (operation key: `revise-intent-001`) — Submitted the
   completed intent document. Evaluator result: admissible, 0 errors,
   0 incomplete, 1 background advisory (W-AUT-022 on SPEC-P3-900, unrelated).
   Context version: 1 → 2. Project version: 3 → 4.

7. **Read revision (verification)** — Read back the revised document. Document
   SHA-256 confirmed: `57b267bea065645a6c260f5164c9b11e6be825c9701a700790b406b23030172b`.
   Complete: true. Unresolved references: none.

## Draft IDs and paths

| Artifact | Revision ID | Path |
| --- | --- | --- |
| INT-P3-001 | `sha256:57b80c72c57b78ec1eeea887a4f41a187b27230c1b4e709a7d07ee654b489fad` | `docs/engineering/lifecycle-pilot/intent/INT-P3-001.md` |

## Observed findings

- **Admissible**: The completed INT-P3-001 draft passed draft validation with
  zero errors and zero incomplete items.
- **Background advisory**: W-AUT-022 on SPEC-P3-900 ("Coverage row REQ-P3-900
  names undefined rule P3-GREET-900") — present in imported data, unrelated to
  the new intent draft.
- **Fixture verification**: `greeting()` in `src/greeting.py` returns exactly
  `'Hello rehearsal'`. File SHA-256 matches `greeting_sha256` in selection.json.
- **No lifecycle decisions exercised**: The draft remains in `draft` status.
  No approval, freeze, baseline, work start, or lifecycle transition was attempted.
- **Test copy**: All operations confirmed `test_copy: true` and `authority:
  rehearsal-only; Git remains authoritative`.

## Limits

- This diagnostic covers only focused draft instruction discovery and one intent
  draft preparation. It does not claim NQ-01--05 qualification.
- Lifecycle rehearsal, MCP parity, reply recovery, and export cases are outside
  this scope.
- Database read-only enforcement remains deferred (RISK-HAG-001).
- The draft is not approved, and the sandbox projection is not repository authority.
