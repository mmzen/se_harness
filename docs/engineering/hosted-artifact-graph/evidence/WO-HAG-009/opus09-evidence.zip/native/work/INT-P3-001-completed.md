+++
id = "INT-P3-001"
type = "intent"
title = "Establish that greeting returns exact expected value"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
outcome = "An operator can confirm that greeting() returns exactly 'Hello rehearsal'."

[relations]
+++

# Intent: Establish that greeting returns exact expected value

## In plain words

The greeting fixture in this project must return the exact string
`Hello rehearsal`. This intent records that expectation so it can be
traced through requirements, verification and delivery.

## Problem

There is no formal record establishing that `greeting()` in
`src/greeting.py` must return exactly `Hello rehearsal`. Without a
stated intent, an operator cannot trace the expectation to a verified
requirement or reject an unintended change to this value.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| greeting() returns exactly `Hello rehearsal` | not measured | Confirmed by verification | After each delivery, by invoking the greeting fixture |

## Not this

- Changing the return value of greeting()
- Adding parameters or variants to the greeting function
- Modifying source files outside `src/greeting.py`
