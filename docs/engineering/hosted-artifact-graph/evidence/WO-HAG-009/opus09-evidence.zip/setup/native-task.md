# Focused hosted drafting diagnostic

You are Claude under the approved WO-HAG-009 qualification test. Work independently
in the fresh private hosted project in SELECTION_FILE. This run tests instruction
discovery during draft preparation only. Git remains authoritative for real work.

## Requested outcome

Prepare exactly one new intent draft for an operator who needs to establish that
the existing fixture's greeting() returns exactly `Hello rehearsal`. Inspect the
fixture and author the intent in the selected private service. Keep it as draft
and report its actual authoring findings. Use domain lifecycle-pilot and synthetic
owner test-owner. Imported -900 records are immutable history. Do not create other
artifacts, approve anything, start work, freeze a baseline or exercise lifecycle
decisions. Stop when this one draft is complete and its current findings retained,
or report the exact blocker. This is a focused diagnostic, not a full package.

## Entry and file discovery

Read SELECTION_FILE. Begin with the candidate plugin's normal verity-plane:setup
Skill for this explicit hosted selection, then follow its current-task routes.
The client is already installed. Do not install software or activate a checkout.
The selected released_resources directory supplies the exact 0.22.1 procedures.

When a filename is known but its path is not, use the fixed helper's find-file
BASENAME (optionally --under PREFIX/). It returns bounded candidates without
choosing one. Its lookup-file resolves one exact relative input name with its current
path and hash. It does not read that file into context. Use native Read on the
returned file and its needed sections. Do not front-load the full input inventory.
Names are relative to inputs: plugin/verity-plane/skills/..., released-resources/...
and source/... . Original contracts are reference/server/contracts/*.json.

Once YOU choose a remote operation, its exact schema view is
schemas/remote-v1/OPERATION.json. Read-operation views are
schemas/read-v1/OPERATION.json. Actual captured CLI help is
client-help/CLI_OPERATION.txt (read, operation, create-artifact, revise-artifact).
Lifecycle views are available separately but
are not needed for this drafting task. Each view names its original source/hash
and pointer, retains required fields/referenced definitions, and supplies no
request values. Complete schemas and the inventory remain available if needed.

## Tools and evidence

Use native Read/Write/Edit and only the exact approved_shell_argv_prefix from the
selection for shell calls. One helper call per invocation; no scripts, wrappers,
loops, pipes or other shell commands. Its help describes find-file, lookup-file, read-json,
encode-file and one chosen remote call. Normal permission checks and hooks apply.
Stop a denied action; do not change permissions or try alternate routes.

Keep every request, complete result and draft under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus09\work` using absolute
paths. Inputs are read-only. The helper's result_fields are exact bounded JSON
values, with omitted_pointers listed; they are not a gate verdict. Read necessary
omitted fields from stdout_file with read-json. On Windows Bash, --pointer takes
a shell-quoted JSON string, e.g. '"/versions"', to preserve the leading slash.
The field reader can decode an explicitly selected base64 string with
--decode-base64; it returns exact UTF-8 and its byte digest without writing files.
Never treat command exit alone as a passed check or template creation as approval.

Never print credential values, inspect auth stores, change account/host settings,
or read prior trials. Authentication is already in the process environment.
The loopback service and token variable name come from the selection. Helpers
perform no hidden workflow; construct your own requests from current inputs.

Keep a small transient progress note in work/ with current IDs, versions and exact
request/result paths. After compaction recover task/selection, note and original
evidence before acting. No conversation note supplies authority.

Finish with native-report.md and native-observations.json at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus09`. Name actual
instruction paths, read triggers and digest sources, draft IDs/paths, observed
findings and limits. Do not claim full NQ-01--05 qualification: later lifecycle,
MCP parity, reply recovery and export cases are outside this focused diagnostic.
