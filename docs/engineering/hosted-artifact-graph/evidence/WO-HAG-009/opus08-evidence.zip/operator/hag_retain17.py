"""Archive the focused test and its exact checked inputs; exclude credentials."""
import json,re,zipfile
from pathlib import Path
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007';out=o/'review17';r=o/'claude/native02/work/opus08';g=o/'claude-guidance17'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert (r/'session.json').exists()
tokens=[x['token'].encode() for p in o.glob('claude-guidance*/credentials.json') for x in load(p)['principals']]
files={}
for name in ('events.jsonl','stderr.txt','session.json','invocation.json','selection.json','task.md','reply-fault.json','native-report.md','native-observations.json','mcp.json','CLAUDE.md'):
 p=r/name
 if p.is_file():files['native/'+name]=p
for sub in ('work','inputs'):
 for p in (r/sub).rglob('*'):
  if p.is_file() and not p.name.endswith(('.whl','.pyc')):files['native/'+p.relative_to(r).as_posix()]=p
for name in ('selection.json','combination.json','stage-evidence.json','native-selection.json','native-task.md','permissions.json','correction-binding.json'):
 files['setup/'+name]=g/name
for pattern in ('next17-*.json','improve17-*.json','runtime-reuse-guidance17.json','build17-replay.json','guidance17-state-*.json','claude-guidance17-version.json','claude-guidance17-auth-probe.json','opus08-*.json'):
 for p in o.glob(pattern):files['checks/'+p.name]=p
for p in (o/'native-parity-guidance17').glob('*.json'):files['independent-mcp/'+p.name]=p
for name in ('hag_native_guidance17.py','hag_finish_native17.py','hag_focus17.py','hag_stage17.py','hag_next17.py','hag_freeze17.py','hag_improve17_build.py','hag_validate_views17.py','hag_audit17.py','hag_native_parity17.py','hag_assess17.py','hag_retain17.py'):
 files['operator/'+name]=h.W/name
files['operator/native_call.py']=h.R/'tests/hosted_artifact_graph/native_call.py'
files['operator/prior-native_call.py']=o/'improve17-helper-before.py'
archive=out/'opus08-evidence.zip';inventory=[]
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):
  raw=p.read_bytes();assert not p.is_symlink(),p
  assert not any(t in raw for t in tokens),name
  assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
  assert not any(part in ('.git','credentials.json') for part in Path(name).parts)
  z.writestr(name,raw);inventory.append({'path':name,'bytes':len(raw),'sha256':h.sha(raw)})
h.write(out/'opus08-inventory.json',{'archive':archive.name,'bytes':archive.stat().st_size,'sha256':h.sha(archive.read_bytes()),'files':inventory,'redaction':'Exact native recorder redaction retained. Checked against known private project tokens and provider-token prefixes. Credentials, wheel binaries, Git directories and account stores excluded.'})
print(json.dumps({'files':len(inventory),'archive_bytes':archive.stat().st_size}))
