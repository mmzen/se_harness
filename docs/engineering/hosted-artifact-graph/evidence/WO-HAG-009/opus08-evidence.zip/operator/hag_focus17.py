"""Stage current-task inputs; do not perform the native agent's workflow."""
import json,sys,subprocess
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007';g=o/'claude-guidance17';n=o/'claude/native02/work/opus08';inputs=n/'inputs'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
sys.path.insert(0,str(h.R/'tests/hosted_artifact_graph'))
from native_schema import operation_view
selection=load(g/'native-selection.json')
for family in ('remote-v1','lifecycle-v2'):
 source=inputs/'reference/server/contracts'/(family+'.json');raw=source.read_bytes();schema=json.loads(raw)
 branches=schema['$defs']['Command']['oneOf'] if family=='remote-v1' else schema['properties']['action']['oneOf']
 key='operation' if family=='remote-v1' else 'kind'
 for branch in branches:
  operation=branch['properties'][key]['const'];view=operation_view(raw,family,operation)
  view['source_file']=str(source)
  h.write(inputs/'schemas'/family/(operation+'.json'),view)
helper=o/'claude/native02/inputs/native_call.py'
task=f'''# Focused hosted drafting diagnostic

You are Claude under the approved WO-HAG-009 qualification test. Work independently
in the fresh private hosted project in SELECTION_FILE. This run tests instruction
discovery during draft preparation only. Git remains authoritative for real work.

## Requested outcome

Prepare new draft definitions for an operator who needs to establish that the
existing fixture's greeting() returns exactly `Hello rehearsal`. Inspect the
fixture and choose the definitions needed for that outcome. Keep them as drafts
in the selected private service; report unresolved authoring findings honestly.
Use domain lifecycle-pilot and synthetic owner test-owner. Imported -900 records
are immutable history. Do not approve definitions, create work/release/verification
records, start implementation, freeze a baseline or exercise lifecycle decisions.
Stop after the definition drafts and their current findings are retained.

## Entry and file discovery

Read SELECTION_FILE. Begin with the candidate plugin's normal verity-plane:setup
Skill for this explicit hosted selection, then follow its current-task routes.
The client is already installed. Do not install software or activate a checkout.
The selected released_resources directory supplies the exact 0.22.1 procedures.

The fixed helper's lookup-file resolves one relative input name with its current
path and hash. It does not read that file into context. Use native Read on the
returned file and its needed sections. Do not front-load the full input inventory.
Names are relative to inputs: plugin/verity-plane/skills/..., released-resources/...
and source/... . Original contracts are reference/server/contracts/*.json.

Once YOU choose a remote operation, its exact schema view is
schemas/remote-v1/OPERATION.json. Lifecycle views are available separately but
are not needed for this drafting task. Each view names its original source/hash
and pointer, retains required fields/referenced definitions, and supplies no
request values. Complete schemas and the inventory remain available if needed.

## Tools and evidence

Use native Read/Write/Edit and only the exact approved_shell_argv_prefix from the
selection for shell calls. One helper call per invocation; no scripts, wrappers,
loops, pipes or other shell commands. Its help describes lookup-file, read-json,
encode-file and one chosen remote call. Normal permission checks and hooks apply.
Stop a denied action; do not change permissions or try alternate routes.

Keep every request, complete result and draft under `{n/'work'}` using absolute
paths. Inputs are read-only. The helper's result_fields are exact bounded JSON
values, with omitted_pointers listed; they are not a gate verdict. Read necessary
omitted fields from stdout_file with read-json. On Windows Bash, --pointer takes
a shell-quoted JSON string, e.g. '"/versions"', to preserve the leading slash.
Never treat command exit alone as a passed check or template creation as approval.

Never print credential values, inspect auth stores, change account/host settings,
or read prior trials. Authentication is already in the process environment.
The loopback service and token variable name come from the selection. Helpers
perform no hidden workflow; construct your own requests from current inputs.

Keep a small transient progress note in work/ with current IDs, versions and exact
request/result paths. After compaction recover task/selection, note and original
evidence before acting. No conversation note supplies authority.

Finish with native-report.md and native-observations.json at `{n}`. Name actual
instruction paths, read triggers and digest sources, draft IDs/paths, observed
findings and limits. Do not claim full NQ-01--05 qualification: later lifecycle,
MCP parity, reply recovery and export cases are outside this focused diagnostic.
'''
h.write(g/'native-task.md',task)
selection['diagnostic_scope']='Focused draft instruction discovery; no complete NQ-01--05 claim.'
selection['schema_views']='inputs/schemas/FAMILY/OPERATION.json'
h.write(g/'native-selection.json',selection)
inventory=[{'path':str(p),'relative':p.relative_to(inputs).as_posix(),'bytes':p.stat().st_size,'sha256':h.sha(p.read_bytes())} for p in sorted(inputs.rglob('*')) if p.is_file() and p.name!='inventory.json']
h.write(inputs/'inventory.json',{'files':inventory,'note':'Exact staged inputs; content reads must be observed independently.'})
binding=load(g/'correction-binding.json');binding.update(task_sha256=h.sha(task.encode()),helper_sha256=h.sha(helper.read_bytes()),inputs_inventory_sha256=h.sha((inputs/'inventory.json').read_bytes()),
 interventions='Before-run guidance/input correction and focused task boundary. No chosen draft IDs, completed artifact bodies, request values, workflow sequence or operator service mutations.',
 schema_views=[{'path':x['relative'],'bytes':x['bytes'],'sha256':x['sha256']} for x in inventory if x['relative'].startswith('schemas/')])
h.write(g/'correction-binding.json',binding)
stage=load(g/'stage-evidence.json');stage.update(task_sha256=binding['task_sha256'],inputs_inventory_sha256=binding['inputs_inventory_sha256'],correction=binding['interventions']);h.write(g/'stage-evidence.json',stage)
print(json.dumps({'task_bytes':len(task.encode()),'schema_views':len(binding['schema_views']),'inventory_bytes':(inputs/'inventory.json').stat().st_size}))
