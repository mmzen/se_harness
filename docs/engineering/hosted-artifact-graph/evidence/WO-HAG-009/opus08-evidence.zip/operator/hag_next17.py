import json,sys,os
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
BASE='55caaada508495bea7d97effd27644d1ce8373da'
planned=['tests/hosted_artifact_graph/native_call.py','tests/hosted_artifact_graph/test_native_support.py','tests/hosted_artifact_graph/native_schema.py','tests/hosted_artifact_graph/test_native_schema.py','plugins/verity-plane/common/skills/setup/SKILL.md','plugins/verity-plane/common/skills/change/SKILL.md',h.D+'evidence/WO-HAG-009/instruction-discovery-proposal17.md']
mode=sys.argv[1]
if mode=='scope':
 paths=set(h.git('diff','--name-only',BASE).splitlines())|set(h.git('ls-files','--others','--exclude-standard').splitlines())|set(planned);covered=set()
 for ident in ('WO-HAG-009','WO-HAG-010'):
  scopes=h.record(h.D+'work-orders/'+ident+'.md')['execution_scope']['paths'];selected={p for p in paths if any(p==s or (s.endswith('/') and p.startswith(s)) for s in scopes)}
  argv=['check','--artifact',ident,'--checkpoint','scope','--changes-complete']
  for p in sorted(selected):argv+=['--changed-path',p]
  h.gov('next17-scope-'+ident,*argv,new=True);covered|=selected
 assert covered==paths,paths-covered
 h.write(h.O/'next17-planned-paths.json',sorted(paths))
elif mode=='test':
 env=dict(os.environ,PYTHONUTF8='1')
 for label,pattern in [('support','test_native_support.py'),('schema','test_native_schema.py')]:
  h.run('next17-'+label,[h.HOST,'-X','utf8','-B','-m','unittest','discover','-s','tests/hosted_artifact_graph','-p',pattern],cwd=h.R,env=env)
else:raise ValueError(mode)
