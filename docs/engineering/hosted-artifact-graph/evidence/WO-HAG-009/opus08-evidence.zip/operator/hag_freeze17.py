import json,os
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
assert h.git('rev-parse','HEAD')=='b6e129f2ae8b89d538d30168344416d63f6e8d9e'
paths=h.git('diff','--name-only').splitlines()+h.git('ls-files','--others','--exclude-standard').splitlines()
scopes=h.record(h.D+'work-orders/WO-HAG-009.md')['execution_scope']['paths']
assert all(any(p==s or s.endswith('/') and p.startswith(s) for s in scopes) for p in paths)
h.run('next17-diff-check',['git','diff','--check'],cwd=h.R)
h.run('next17-plugin-checks',[h.HOST,'-X','utf8','-B','-m','unittest','discover','-s','tests/plugin_integration','-p','test_simple_plugin.py'],cwd=h.R,env=dict(os.environ,PYTHONUTF8='1'))
h.run('next17-stage',['git','add','--',*paths],cwd=h.R)
h.run('next17-commit',['git','commit','-m','Narrow hosted draft instruction entry and native input views','-m','Harness-Work-Order: WO-HAG-009'],cwd=h.R)
h.write(h.O/'improve17-candidate.json',{'commit':h.git('rev-parse','HEAD'),'paths':paths})
assert not h.git('status','--porcelain')
for old,new in [('hag_improve15_build.py','hag_improve17_build.py'),('hag_native_guidance16.py','hag_native_guidance17.py'),('hag_finish_native16.py','hag_finish_native17.py')]:
 text=(h.W/old).read_text(encoding='utf-8')
 if 'build' in old:text=text.replace('15','17')
 else:
  text=text.replace('guidance16','guidance17').replace('opus07','opus08').replace('native07','native08').replace('package15','package17').replace('build15','build17').replace('client15','client17').replace('guidance15','guidance17').replace('18351','18361').replace('18352','18362').replace('improve16','improve17')
  if 'guidance' in old:
   text=text.replace("'--timeout','3600'","'--timeout','1200'")
 h.write(h.W/new,text)
print(h.git('rev-parse','HEAD'))
