import copy,json,sys
from pathlib import Path
from jsonschema import Draft202012Validator
sys.path.insert(0,'/repo/tests/hosted_artifact_graph')
from native_schema import operation_view
checks=0
for family in ('remote-v1','lifecycle-v2'):
 raw=(Path('/repo/server/contracts')/(family+'.json')).read_bytes();source=json.loads(raw)
 branches=source['$defs']['Command']['oneOf'] if family=='remote-v1' else source['properties']['action']['oneOf']
 key='operation' if family=='remote-v1' else 'kind'
 for branch in branches:
  view=operation_view(raw,family,branch['properties'][key]['const'])['schema']
  Draft202012Validator.check_schema(view);checks+=1
  assert not Draft202012Validator(view).is_valid({});checks+=1
source=json.loads(Path('/repo/server/contracts/remote-v1.json').read_bytes())
original=Draft202012Validator(source)
for path in Path('/observed').glob('*.json'):
 request=json.loads(path.read_bytes())
 if not isinstance(request,dict) or request.get('schema')!='se-harness-remote-command/v1':continue
 view=operation_view(Path('/repo/server/contracts/remote-v1.json').read_bytes(),'remote-v1',request['operation'])['schema']
 selected=Draft202012Validator(view)
 assert original.is_valid(request)==selected.is_valid(request)==True,path
 checks+=1
 for field in view['required']:
  missing=copy.deepcopy(request);missing.pop(field)
  assert original.is_valid(missing)==selected.is_valid(missing)==False,(path,field)
  checks+=1
 extra={**request,'unexpected':True}
 assert original.is_valid(extra)==selected.is_valid(extra)==False
 checks+=1
print(json.dumps({'checks':checks,'pass':True,'method':'JSON Schema validator: all staged operation shapes; exact observed v1 requests and every required-field deletion/extra-field refusal. No hosted scenario claimed.'}))
