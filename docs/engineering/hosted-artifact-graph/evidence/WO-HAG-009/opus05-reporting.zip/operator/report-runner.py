"""Retain a stopped observation and rerun only native evidence reporting."""
import json, os, re, shutil, subprocess, sys, zipfile
from pathlib import Path
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
o=h.O; root=o/'claude/native02/work'; r=root/'opus04'; native=root/'opus05'
g=o/'claude-guidance14'; e=h.R/h.D/'evidence/WO-HAG-009'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
mode=sys.argv[1]
if mode=='retain':
    assert load(o/'guidance13-state-before.json')==load(o/'guidance13-state-after.json')
    base='55caaada508495bea7d97effd27644d1ce8373da'
    paths=set(h.git('diff','--name-only',base).splitlines())|set(h.git('ls-files','--others','--exclude-standard').splitlines())
    paths.update(h.D+'evidence/WO-HAG-009/'+s for s in ('opus04-assessment.json','opus04-inventory.json','opus04-stopped.zip','report.md'))
    covered=set()
    for ident in ('WO-HAG-009','WO-HAG-010'):
        scopes=h.record(h.D+'work-orders/'+ident+'.md')['execution_scope']['paths']
        selected={p for p in paths if any(p==s or (s.endswith('/') and p.startswith(s)) for s in scopes)}
        a=['check','--artifact',ident,'--checkpoint','scope','--changes-complete']
        for p in sorted(selected):a+=['--changed-path',p]
        h.gov('native14-retention-scope2-'+ident,*a,new=True);covered|=selected
    assert covered==paths,paths-covered
    commands=[]
    for line in (r/'events.jsonl').read_text(encoding='utf-8').splitlines():
        try:event=json.loads(line)
        except ValueError:continue
        for b in event.get('message',{}).get('content',[]) if isinstance(event.get('message'),dict) else []:
            if isinstance(b,dict) and b.get('type')=='tool_use' and b.get('name')=='Bash' and b['input']['command'].startswith('ls '):
                commands.append({'tool_use_id':b['id'],'command':b['input']['command']})
    assert len(commands)==8
    assessment={'trial':'opus04','status':'stopped_incomplete','session':load(r/'session.json'),
      'selected_draft_case':load(o/'opus04-selected-draft-audit.json'),
      'route_violations':commands,'intervention':'Parent stopped only this trial Claude process (PID 33712) after observing the last three non-helper Bash listings during the reporting audit. Full transcript inspection finds eight listing attempts, including earlier calls missed by the live observer. No outside write observed; the actual repository and selected host settings match before/after.',
      'scope':'Listings read only the trial evidence area. They violate the explicit fixed-helper-only command route; no destructive or external effect is alleged.',
      'diagnosis':'dontAsk retains built-in read-only Bash permissions. It is not a strict allowlist. Reporting needs no shell or hosted mutation; a session-local Bash denial and factual file inventory can support a separate reporting-only rerun without widening authority.',
      'source':'https://code.claude.com/docs/en/permissions',
      'verdict':'The exact selected-draft refusal/recovery has observed and independently replayed evidence. This stopped run produced no final native report and does not establish a complete Claude qualification.'}
    h.write(e/'opus04-assessment.json',assessment)
    files={}
    for p in r.iterdir():
        if p.is_file():files['native/'+p.name]=p
    for p in (r/'work').rglob('*'):
        if p.is_file():files['native/'+p.relative_to(r).as_posix()]=p
    files['native/inputs/inventory.json']=r/'inputs/inventory.json'
    for name in ('selection.json','native-selection.json','native-task.md','permissions.json','case-binding.json'):
        files['setup/'+name]=o/'claude-guidance13'/name
    for pattern in ('claude-guidance13-*.json','guidance13-state-*.json','opus04-*.json','native14-retention-scope*.json'):
        for p in o.glob(pattern):files['checks/'+p.name]=p
    replay=Path(r'C:\Users\mathi\AppData\Local\Temp\hag-o04-replay-20261007')
    for p in replay.glob('*.json'):files['independent-replay/'+p.name]=p
    for p in (o/'native-parity-guidance13').glob('*.json'):files['mcp-parity/'+p.name]=p
    files['operator/setup.py']=h.W/'hag_native_case13.py';files['operator/case-audit.py']=h.W/'hag_audit_opus04_case.py'
    secrets=[v['token'].encode() for v in load(o/'claude-guidance13/credentials.json')['principals']]
    archive=e/'opus04-stopped.zip';inventory=[]
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for name,p in sorted(files.items()):
            raw=p.read_bytes();assert not any(s in raw for s in secrets),name;assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
            z.writestr(name,raw);inventory.append({'path':name,'bytes':len(raw),'sha256':h.sha(raw)})
    h.write(e/'opus04-inventory.json',{'archive':archive.name,'bytes':archive.stat().st_size,'sha256':h.sha(archive.read_bytes()),'files':inventory,'excluded':'Credentials, copied packages, environments and reconstructed Git repositories.'})
    p=e/'report.md';p.write_bytes(p.read_bytes()+b'\n## Opus04 selected-draft test and stopped report\n\n'+
      ('Claude changed the exact selected draft, received HAG_REMOTE_STALE_CONTEXT with no committed effect, then refreshed and applied a valid correction. Project versions were 32, 33, 33 after refusal, and 34 after recovery. Independent replay passed the one accepted action; its whole-run wrapper still exits 1 because this focused test contains no new exports. Opus03 supplies the earlier two exports.\n\nThe parent stopped this run after observing three non-helper directory-listing commands in its own test evidence area. Full transcript review found eight listing attempts, including earlier calls missed by the live observer. The real checkout and selected host settings stayed unchanged. No final report was produced, so the combined qualification remains incomplete. See [assessment](opus04-assessment.json) and [inventory](opus04-inventory.json).\n').encode())
    print(json.dumps({'retained':len(inventory),'archive_bytes':archive.stat().st_size}))
elif mode=='stage':
    g.mkdir();(native/'inputs').mkdir(parents=True);(native/'work').mkdir()
    previous=[root/name for name in ('opus02','opus03','opus04')]
    for p in (r/'inputs').iterdir():
        if p.is_dir():shutil.copytree(p,native/'inputs'/p.name)
        elif p.name!='inventory.json':shutil.copyfile(p,native/'inputs'/p.name)
    selection=json.loads(json.dumps(load(o/'claude-guidance13/native-selection.json')).replace(str(r).replace('\\','\\\\'),str(native).replace('\\','\\\\')))
    selection.pop('approved_shell_argv_prefix',None)
    selection.update(native_task_file=str(native/'task.md'),output_directory=str(native/'work'))
    h.write(g/'native-selection.json',selection);h.write(g/'credentials.json',load(o/'claude-guidance13/credentials.json'))
    inventory=[];indices=[]
    for trial in previous:
        files=[p for p in trial.iterdir() if p.is_file()]+[p for p in (trial/'work').rglob('*') if p.is_file()]
        for p in sorted(files):inventory.append({'path':str(p),'bytes':p.stat().st_size,'sha256':h.sha(p.read_bytes())})
        chunks=native/'inputs/event-lines'/trial.name;chunks.mkdir(parents=True)
        for number,raw in enumerate((trial/'events.jsonl').read_bytes().splitlines(keepends=True),1):
            try:ev=json.loads(raw)
            except ValueError:continue
            m=ev.get('message',{});blocks=m.get('content',[]) if isinstance(m,dict) else []
            uses=[b for b in blocks if isinstance(b,dict) and b.get('type')=='tool_use']
            compact=ev.get('type')=='system' and 'compact' in ev.get('subtype','')
            if uses or compact:
                p=chunks/f'{number:05d}.jsonl';p.write_bytes(raw)
                indices.append({'trial':trial.name,'source_line':number,'source':str(trial/'events.jsonl'),'exact_event_file':str(p),'sha256':h.sha(raw),'tool_calls':uses,'compact_metadata':ev.get('compact_metadata') if compact else None})
    h.write(native/'inputs/evidence-files.json',{'purpose':'File navigation only. Original bytes are unchanged; hashes do not establish a read or pass.','files':inventory})
    h.write(native/'inputs/event-index.json',{'purpose':'Unmodified tool inputs and compaction metadata, linked to the exact source JSONL line. This index supplies no verdict or workflow instructions.','events':indices})
    h.write(native/'inputs/inventory.json',{'files':[{'path':str(p),'relative':p.relative_to(native/'inputs').as_posix(),'bytes':p.stat().st_size,'sha256':h.sha(p.read_bytes())} for p in sorted((native/'inputs').rglob('*')) if p.is_file()]})
    rules=load(o/'claude-guidance13/permissions.json')
    rules['permissions']['allow']=[x for x in rules['permissions']['allow'] if not x.startswith(('Bash(','mcp__'))]
    rules['permissions']['deny']+=['Bash','ToolSearch','mcp__hag__*']
    for p in [*previous,native/'inputs',native/'CLAUDE.md']:
        rules['permissions']['deny'].append('Edit(//'+str(p).replace('\\','/').replace('C:','c')+('/**)' if p.suffix!='.md' else ')'))
    h.write(g/'permissions.json',rules)
    task=f'''# Native qualification: evidence reporting only

You are the Claude Code agent under test for WO-HAG-009 / VER-HAG-007.
Rerun only NQ-05's final-report requirement by auditing your own three native
observations at {', '.join(str(p) for p in previous)}.
Do not execute any lifecycle operation, repeat completed work, export again,
or perform an independent replay. This is a reporting-only session. Bash and
MCP calls are disabled for this session; use native Read/Write/Edit tools.
The normal candidate plugin and its hooks remain loaded. Read the candidate
setup guidance as applicable to the explicit test selection at SELECTION_FILE;
do not activate a checkout or change host settings. Existing captured results
are the evidence; do not claim fresh service observations in this report.

Produce native-report.md and native-observations.json in {native}.
Other notes may be written only under {native/'work'}. Prior observations,
staged inputs and the actual repository are read-only. Do not delegate.

The report must name actual outcomes, evidence, interventions, failed/denied
actions and limits for NQ-01 through NQ-05. Audit earlier narrative claims
against original requests and results; preserve earlier files unchanged.
Distinguish proposed requests, previews, accepted operations, refused operations
and independent checks you did not perform. Keep actual qualification C,
hosted baselines B, fixture S and synthetic Git candidate P separate.
Supplied actors and test VREC/RLS are synthetic; Git remains authoritative
for real work. No human verification, real release or deployment occurred.
Do not call the combined qualification complete or verified yourself; the
independent reviewer assesses the retained evidence. Clearly identify any
required evidence that you cannot establish from the records you read.

Use {native/'inputs/evidence-files.json'} to find exact paths and byte hashes.
Use {native/'inputs/event-index.json'} to locate actual prior tool inputs,
reads and compaction events. These are navigation metadata, not conclusions.
The index links exact unchanged source-event lines. Read the underlying
evidence for your claims and cite exact paths, not just the index or an old
summary. Original native events.jsonl and all work files remain available.
For Opus02's large JSON receipts, Opus03 inputs/previous-work contains copies
with complete unescaped stdout companions. A file inventory hash alone is
not proof that the tested agent read that file. A post-run hash of a mutable
file does not necessarily identify its bytes at the time of a prior read.
Record actual instruction-read paths, triggers, hash sources and any gaps.

Avoid loading whole large event streams at once; use the navigation metadata
and exact event/receipt paths. The records retain every attempted operation,
including errors. The Opus04 session was stopped by the parent after its
reporting audit used three non-helper shell listings, contrary to its task.
Those read only its test evidence area; no outside write was observed.
This session removes shell access and supplies only a file inventory. That
is an operator intervention to report, not permission to erase the failure.
No outcomes, corrected commands or prewritten assessment are supplied here.
After compaction reread task.md and selection.json and continue only reporting.
'''
    h.write(g/'native-task.md',task)
    h.write(g/'report-binding.json',{'case':'NQ-05 final reporting only','previous_trials':[str(p) for p in previous],'package_source':'0dbb8ea19f28994da7abc7ecbab08c8db430dc0c','task_sha256':h.sha(task.encode()),'permission_change':'Only narrowing: no Bash, MCP or ToolSearch. Native file read/write remains within the existing approved trial area; previous evidence is read-only.','navigation':'Complete file inventory and original tool inputs with exact event-line links; no verdict, command sequence or mutation request supplied.'})
    print(json.dumps({'staged':str(native),'metadata_files':len(inventory),'events':len(indices)}))
elif mode in ('state-before','state-after'):
    files=[Path(r'C:\Users\mathi\.codex\config.toml'),Path(r'C:\Users\mathi\.claude\settings.json'),Path(r'C:\Users\mathi\.claude\plugins\installed_plugins.json')]
    h.write(o/('guidance14-'+mode+'.json'),{'repository_head':h.git('rev-parse','HEAD'),'repository_status':h.git('status','--porcelain'),'host_settings':[{'path':str(p),'exists':p.is_file(),'sha256':h.sha(p.read_bytes()) if p.is_file() else None} for p in files]})
elif mode=='run':
    exe=r'C:\Users\mathi\.local\bin\claude.exe'
    h.run('claude-guidance14-version',[exe,'--version'])
    probe=h.run('claude-guidance14-auth-probe',[exe,'-p','--no-session-persistence','--tools','','--model','claude-opus-4-6','--output-format','json','Authorized model availability probe. Reply exactly AUTH_OK. Read or change no files and use no tools.'],timeout=180)
    assert probe.get('result','').strip()=='AUTH_OK' and not probe.get('is_error')
    args=[h.HOST,'-X','utf8','-B',h.R/'tests/hosted_artifact_graph/qualify_agents.py','--host','claude','--executable',exe,'--selection',g/'native-selection.json','--credentials',g/'credentials.json','--task',g/'native-task.md','--output',native,'--prepared-inputs','--timeout','1800','--permission-settings',g/'permissions.json','--model','claude-opus-4-6']
    raise SystemExit(subprocess.call(list(map(str,args)),cwd=h.W))
