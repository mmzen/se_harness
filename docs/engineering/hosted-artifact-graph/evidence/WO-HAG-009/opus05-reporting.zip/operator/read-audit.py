"""Index actual native file/Skill reads without treating a hash as a read."""
import json
from pathlib import Path
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007'; roots=o/'claude/native02/work'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
norm=lambda p:str(p).replace('\\','/').lower()
out=[]; summaries=[]
for name in ('opus02','opus03','opus04'):
    r=roots/name;s=load(r/'selection.json');inventory={norm(x['path']):x for x in load(r/'inputs/inventory.json')['files']}
    events=[json.loads(x) for x in (r/'events.jsonl').read_text(encoding='utf-8').splitlines()]
    results={};messages={};calls=[]
    for number,event in enumerate(events,1):
        m=event.get('message',{});blocks=m.get('content',[]) if isinstance(m,dict) else []
        prose='\n'.join(x['text'] for x in blocks if isinstance(x,dict) and x.get('type')=='text')
        for b in blocks:
            if not isinstance(b,dict):continue
            if b.get('type')=='tool_result':results[b['tool_use_id']]={'source_line':number,'error':b.get('is_error',False),'content':b.get('content')}
            if b.get('type')=='tool_use':calls.append((number,b,prose))
    reads=[]
    for line,b,prose in calls:
        if b['name'] not in ('Read','Skill'):continue
        p=Path(b['input']['file_path']) if b['name']=='Read' else Path(s['plugin'])/'skills'/b['input']['skill'].split(':')[-1]/'SKILL.md'
        inv=inventory.get(norm(p));result=results.get(b['id'])
        static=bool(inv);current=h.sha(p.read_bytes()) if p.is_file() else None
        if static:assert inv['sha256']==current,p
        entry={'trial':name,'tool':b['name'],'tool_use_id':b['id'],'source_line':line,'path':str(p),'input':b['input'],'result_line':result['source_line'] if result else None,'returned_error':result['error'] if result else None,'sha256':inv['sha256'] if inv else current,'hash_source':'pre-run immutable staged inventory; matches current bytes' if inv else 'post-run file only; not proof of historical bytes','trigger_evidence':prose or 'No same-event prose; use original task, tool input and preceding transcript context.','read_extent':'Skill tool content' if b['name']=='Skill' else {'offset':b['input'].get('offset'),'limit':b['input'].get('limit')},'caveat':'A successful partial read identifies its requested extent; no claim that the complete file was read.'}
        reads.append(entry)
    instructions=[x for x in reads if '/skills/' in norm(x['path']) or '/released-resources/' in norm(x['path'])]
    summaries.append({'trial':name,'read_calls':len(reads),'instruction_calls':len(instructions),'skills':sorted({x['input']['skill'] for x in reads if x['tool']=='Skill'}),'immutable_hash_matches':sum('pre-run' in x['hash_source'] for x in reads),'errors':sum(x['returned_error'] is True for x in reads),'instruction_files':sorted({x['path'] for x in instructions})})
    out.extend(reads)
h.write(o/'claude-independent-read-trace.json',{'method':'Actual Read and Skill calls, original event lines and tool result matching. Staged hashes checked independently; mutable file hashes explicitly limited. No native trace completeness or earliest-prerequisite claim inferred.','trials':summaries,'reads':out})
print(json.dumps(summaries,indent=2))
