# Disposable qualification task inputs

Read `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus05\task.md` and `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus05\selection.json` before acting,
including after compaction. They retain the task, selected inputs and tool boundary.
Use the selected candidate plugin skills and their required references for the workflow.
This file supplies no lifecycle procedure or new permission.
