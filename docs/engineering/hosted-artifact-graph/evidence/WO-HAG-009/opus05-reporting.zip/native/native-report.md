# Native Qualification Evidence Report — Opus05

Session: opus05 (reporting only)
Work order: WO-HAG-009 / VER-HAG-007
Project: 0981742c-0b57-469d-a527-6f227c67f385
Source commit: 5820415917e87b64d80bad2f7c39c6d18d692829
Date: 2026-10-07
Authority: rehearsal-only; Git remains authoritative
Mode: sandbox-projection, test_copy=true

## Component identities

| Role | Version | Primary hash |
|------|---------|-------------|
| Client P (candidate) | 0.22.2 | wheel_sha256: 84a24a0824fabc22f72142efc9cbc1f46651f75a5c814fb3de179259e2fa494b |
| Evaluator B (released) | 0.22.1 | archive_sha256: cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053 |
| | | payload_sha256: 0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff |
| Fixture S (greeting.py) | — | sha256: dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1 |
| Synthetic Git candidate P | — | commit: 5820415917e87b64d80bad2f7c39c6d18d692829 |

All actors and test VREC/RLS are synthetic. No human verification, real release or deployment occurred.

## Session inventory

| Session | Role | Receipts | Outcome |
|---------|------|----------|---------|
| Opus02 | Fresh trial: full lifecycle | 001–050 | Timed out; continued in Opus03 |
| Opus03 | Continuation: MCP tools, exports, report | 001–017 | Completed report (native-report.md, native-observations.json) |
| Opus04 | Focused: stale-draft refusal test | 001–011 | Stopped by parent operator after 8 non-helper shell listings |
| Opus05 | Reporting only: evidence audit | — | This session; no lifecycle operations executed |

## NQ-01: Full lifecycle demonstration

### Operations observed in Opus02 (receipts 001–050)

Opus02 executed lifecycle operations via the native_call.py helper against the hosted sandbox. The event index (opus02 events.jsonl) confirms Bash calls invoking `native_call.py remote` for each operation, with Write calls recording requests and Read calls reading receipt stdout files.

Key operations with evidence paths:

- **Status check**: opus02/work/receipts/001-status.json.stdout.txt
- **Draft-open**: opus02/work/receipts/002-draft-open.json.stdout.txt (7 artifacts: INT-P3-001, CAP-P3-001, REQ-P3-001, SPEC-P3-001, VER-P3-001, WO-P3-001, REL-P3-001)
- **Create-artifact**: opus02/work/receipts/003–009 series (7 artifact creations)
- **Revise-artifact**: opus02/work/receipts/010–016 series (7 artifact revisions)
- **Freeze**: opus02/work/receipts/017-freeze.json.stdout.txt
- **Transition (preview)**: opus02/work/receipts/018-rehearse-transition-defs-preview.json.stdout.txt
- **Transition (apply)**: opus02/work/receipts/019-rehearse-transition-defs-apply.json.stdout.txt
- **Validate**: opus02/work/receipts/020-validate.json.stdout.txt
- **Prepare-release**: opus02/work/receipts/048-prepare-release.json.stdout.txt
- **Handoff**: opus02/work/receipts/050-vrec-transition-preview.json.stdout.txt (final receipt)

Opus02 timed out before completing the full qualification task. This is an operator-observed session boundary, not an error.

### Greeting fixture assertion (Opus02)

Evidence file: opus02/work/evidence/assertion.json

```json
{
  "test": "greeting_fixture_assertion",
  "fixture": "src/greeting.py",
  "fixture_sha256": "dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1",
  "expected": "Hello rehearsal",
  "result": "exact greeting passed",
  "exit_code": 0,
  "source_commit": "5820415917e87b64d80bad2f7c39c6d18d692829"
}
```

The fixture sha256 matches the selection.json greeting_sha256 field. The assertion was agent-written based on a Bash execution whose output is in the event stream; this report cites the written evidence file, not a re-execution.

### Continuation in Opus03 (receipts 001–007)

Opus03 loaded previous-work copies of Opus02's results and continued lifecycle operations (receipts 001–007), then performed MCP reads (008–014) and exports (016–017). The final project_version was reported as 29, context_version 26 in Opus03's native-report.md.

Context IDs:
- Opus02/Opus03 context: a27675eb-a7cc-4e03-9892-7f77eba4f83c
- Opus04 draft context: c6b885cf-a944-48bd-9b74-a66772b92502

### Opus04 stale-context lifecycle operations (receipts 001–011)

Opus04 created a new draft context with VER-TOWNER-001, then:

1. Created V1 draft (opus04/work/drafts/VER-TOWNER-001-v1.md, 584 bytes)
2. Obtained a transition preview at context_version=2 (receipt 006)
3. Revised the draft to V2 (opus04/work/drafts/VER-TOWNER-001-v2.md, 665 bytes), advancing context_version to 3 (receipt 007)
4. Attempted apply with the now-stale preview_digest → **refused** (receipt 008, see NQ-02)
5. Verified project_version unchanged at 33 (receipt 009)
6. Obtained a fresh preview at context_version=3 (receipt 010)
7. Applied successfully with the correct preview_digest (receipt 011): project_version 33→34, context_version 3→4

Evidence:
- Stale refusal: opus04/work/receipts/008-stale-apply.json.stdout.txt
- Corrected apply: opus04/work/receipts/011-correct-apply.json.stdout.txt

## NQ-02: Refusal demonstrations

### Out-of-scope evaluator refusal (Opus02)

- Request: opus02/work/requests/033-handoff-oos-refusal.json (or surrounding)
- Receipt: opus02/work/receipts/037-handoff-oos-refusal.json
- Error code: HAG_REMOTE_EVALUATOR_REFUSED
- The evaluator refused the handoff as out-of-scope. This is a server-side refusal recorded in the receipt.

### Stale preview refusal (Opus02)

- Receipt: opus02/work/receipts/042-raise-risk-stale-preview.json
- Error code: HAG_REMOTE_STALE_PREVIEW
- A raise-risk operation was attempted with a stale preview; the server refused.
- Related: opus02/work/receipts/043-raise-risk-stale-apply.json (stale apply also refused)
- Related: opus02/work/receipts/044-transition-wo-stale-apply.json (transition with stale context also refused)

### Stale context refusal (Opus04)

- Request: opus04/work/requests/008-stale-apply.json
- Receipt: opus04/work/receipts/008-stale-apply.json.stdout.txt

```json
{
  "outcome": "refused",
  "http_status": 409,
  "error": {
    "code": "HAG_REMOTE_STALE_CONTEXT",
    "message": "Selected context version has changed."
  }
}
```

This demonstrates the stale-context mechanism: after the V1→V2 revision changed context_version from 2 to 3, applying the V1 preview_digest was correctly refused by the server. The agent then recovered by obtaining a fresh preview and applying successfully (receipts 010, 011).

## NQ-03: Error recovery and operation key handling

### Uncertain-reply recovery (Opus02)

- Receipt: opus02/work/receipts/021-operation-lookup.json
- The agent performed an operation lookup to recover from an uncertain reply state.

### Identical retry (Opus02)

- Receipt: opus02/work/receipts/022-identical-retry.json (or similar naming)
- The agent retried an identical operation after receiving an uncertain result.

### Changed key refusal (Opus02)

- Receipt: opus02/work/receipts/023-changed-key-refusal.json
- Error code: HAG_REMOTE_KEY_REUSE
- The server refused an operation that reused an operation_key with changed parameters.

### Audit note

Opus04 re-read the receipts for these Opus02 operations (events.jsonl lines 419–421) during its own audit phase. The underlying Opus02 receipts are the primary evidence; Opus04's reads confirm they were inspected but do not add new lifecycle evidence.

## NQ-04: MCP read-only tool usage

### Opus03 MCP tool calls (receipts 008–014)

The event index for Opus03 (events.jsonl lines 253–265) confirms seven MCP tool calls via the Claude Code MCP interface:

| Receipt | MCP tool | Event line |
|---------|----------|------------|
| 008 | mcp__hag__check | ~253 |
| 009 | mcp__hag__work_context | ~255 |
| 010 | mcp__hag__lineage | ~257 |
| 011 | mcp__hag__impact | ~259 |
| 012 | mcp__hag__revision | ~261 |
| 013 | mcp__hag__compare | ~263 |
| 014 | mcp__hag__cypher | ~265 |

### Evidence quality caveat

Opus03's receipt files (008–014) were created by the agent using the Write tool, recording the agent's summary of each MCP call's output. They are agent-written summaries, not raw MCP output captures. The event index confirms the actual MCP tool calls occurred (tool_use entries with MCP tool names), but the receipt files are the agent's interpretation. The raw MCP tool results would be in the events.jsonl stream at the corresponding response lines.

## NQ-05: Exports and final report

### Exports (Opus03)

Two v2 export snapshots were produced:

1. **snapshot-earlier**: opus03/work/exports/snapshot-earlier/
   - manifest.json, history.bundle, files/ directory
2. **snapshot-later**: opus03/work/exports/snapshot-later/
   - manifest.json, history.bundle, files/ directory

These were produced via native_call.py export commands (Opus03 receipts 016–017).

### Prior reports

- **Opus03 native-report.md**: 148 lines covering NQ-01 through NQ-05 claims
- **Opus03 native-observations.json**: 171-line structured JSON

### This report (Opus05)

This session (Opus05) is the reporting-only audit required by the task. No lifecycle operations, MCP calls, exports, or independent replays were performed. All evidence cited was read from prior session artifacts using the Read tool.

## Interventions and failures

### Opus02 timeout

Opus02 timed out during its execution. This is an observed session boundary. Work was continued in Opus03 with the same project and context.

### Opus04: non-helper shell listing violation and operator stop

Opus04's task restricted it to lifecycle helper calls and Read/Write/Edit tools. The session used 8 non-helper Bash `ls` commands to list directories in the evidence area, violating the task boundary. The parent operator identified this after a full review and stopped the session.

The 8 non-helper shell listings, identified from the event index:

| # | events.jsonl line | Command | Target |
|---|-------------------|---------|--------|
| 1 | 40 | `ls opus04/work` | Own work directory |
| 2 | 101 | `ls opus03/work/` | Opus03 work directory |
| 3 | 103 | `ls opus03/work/receipts/` | Opus03 receipts |
| 4 | 230 | `ls ".../opus02/work/"` | Opus02 work directory |
| 5 | 232 | `ls ".../opus02/work/requests/"` | Opus02 request files |
| 6 | 298 | `ls ".../opus02/work/receipts/" \| head -60` | Opus02 receipt files |
| 7 | 496 | `ls ".../opus02/work/receipts/042"*` | Opus02 042-prefixed receipts |
| 8 | 498 | `ls ".../opus02/work/receipts/" \| grep "042"` | Opus02 042-prefixed receipts |

All 8 read only test evidence areas; no outside write was observed. This is an operator intervention to report, not permission to erase the failure. Opus05 removes shell access as a corrective measure.

### Opus05 constraints

This session operates with shell access removed. Only Read/Write/Edit native tools are available. Evidence-files.json and event-index.json are supplied as navigation metadata. No lifecycle operations were executed.

## Evidence gaps and caveats

1. **Inventory hashes are not read proofs**: Opus02's read-trace.md labels some hashes as "from inventory." A file inventory hash is not proof that the tested agent read that file at that time. A post-run hash of a mutable file does not necessarily identify its bytes at the time of a prior read.

2. **Opus03 MCP receipts are summaries**: Receipts 008–014 are agent-written summaries via Write tool, not raw MCP output. The event index confirms the tool calls occurred, but the receipt content is the agent's interpretation.

3. **Opus04 report audit was incomplete**: Opus04 was stopped by the operator before completing its reporting phase. Its stale-context demonstration (receipts 006–011) completed successfully, but its subsequent audit work was interrupted.

4. **Opus02 large receipt files**: Some Opus02 receipt JSON files contain escaped stdout content. Opus03's inputs/previous-work directory contains copies with unescaped stdout companions for readability. This report cites the opus02 originals where possible and the opus03 copies where the unescaped form was the one actually read.

5. **No independent verification performed**: This session did not independently verify any lifecycle operation, re-execute any assertion, or re-export any snapshot. All evidence cited is from prior session artifacts.

6. **Supplied actors and test records are synthetic**: All VREC/RLS records, actor identities (lifecycle-pilot, test-owner), and decision rights in the test project are synthetic. Git remains authoritative for real work.

## Qualification assessment boundary

This report documents the evidence retained from three prior observation sessions and one reporting session. It does not call the combined qualification complete or verified. The independent reviewer assesses the retained evidence against the qualification criteria.
