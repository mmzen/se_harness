"""Cross-check the supplied fixture decisions and observed receipts, not model claims."""
import hashlib,json,datetime,tomllib
from pathlib import Path
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
root=h.O/'codex-final/native04'
replay=Path(r'C:\Users\mathi\AppData\Local\Temp\hag-n04-replay-20261007')
assessment=json.loads((replay/'assessment.json').read_text())
assert assessment['state']=='accepted_calls_and_native_exports_replayed'
assert len(assessment['cases'])==11
load=lambda name:json.loads((root/name).read_text(encoding='utf-8-sig'))
result=lambda name:json.loads(load('work/'+name)['stdout'])
decisions=[]
for case in assessment['cases']:
    request=json.loads(Path(case['request_file']).read_text())
    action=request['action'];kind=action['kind']
    if kind=='transition':
        for assignment in action['assignments']:
            expected={'approved':'test-owner','in_progress':'test-executor','implemented':'test-executor',
                      'verified':'quality-owner','released':'release-owner'}[assignment['state']]
            assert assignment['actor']==expected,(case['case'],assignment)
            decisions.append({'artifact':assignment['artifact'],'state':assignment['state'],'actor':expected})
    if kind=='decide':
        assert action['decision']=='test-owner' and action['option']=='mitigate'
        assert action['mitigated_by']==['WO-N04-001']
        decisions.append({'artifact':action['artifact'],'option':action['option'],'actor':action['decision']})
    if kind in ('capture-verification','prepare-release'):
        assert action['owner']==('quality-owner' if kind=='capture-verification' else 'release-owner')
fault=load('reply-fault.json')[0]['result']
lookup=result('030-definitions-operation-result.json')
retry=result('031-identical-retry-result.json')
assert fault==lookup==retry
conflict=result('032-changed-accepted-key-result.json')
assert 'KEY_REUSE' in json.dumps(conflict)
status=result('033-after-retry-status.json')
assert status['project_version']==retry['versions']['project']['after']==20
stale=result('010-stale-int-result.json')
assert 'STALE_PROJECT' in json.dumps(stale)
refusal=result('045-handoff-outside-result.json')
assert 'WEX201' in json.dumps(refusal)
assert 'docs/outside-native04.json' in json.dumps(refusal)
assertion=load('work/003-greeting-assertion.json')
assert assertion['exit']==0 and assertion['stdout']=='exact greeting passed\n' and not assertion['stderr']
assert "['greeting']()=='Hello rehearsal'" in assertion['argv'][-2]
trace=[];missing=[];later_edits=[]
for line in (root/'work/read-trace.jsonl').read_text(encoding='utf-8-sig').splitlines():
    entry=json.loads(line)
    if not isinstance(entry,dict) or not entry.get('sha256'):
        missing.append(entry);continue
    matches=h.sha(Path(entry['path']).read_bytes())==entry['sha256']
    if Path(entry['path']).is_relative_to(root/'inputs'):
        assert matches,entry['path']
    if not matches:
        later_edits.append(entry['path']);continue
    trace.append(entry)
parity=[json.loads(p.read_text()) for p in (h.O/'native-parity-codex-reads').glob('*.json')]
assert {p['tool'] for p in parity}=={'revision','work-context','compare','impact','lineage','check','cypher'}
assert all(p['exact_match'] and p['http_status']==200 for p in parity)
for p in parity:
    r=p['native_result']
    assert r['complete'] and not r['continuation'] and not r['unresolved_references']
host_config=Path(r'C:\Users\mathi\.codex\config.toml')
config=tomllib.loads(host_config.read_text(encoding='utf-8'))
host={'configured_model':config.get('model'),'configured_reasoning':config.get('model_reasoning_effort'),
      'config_sha256':h.sha(host_config.read_bytes()),
      'config_modified_at_utc':datetime.datetime.fromtimestamp(host_config.stat().st_mtime,datetime.timezone.utc).isoformat(),
      'limitation':'Codex JSON events do not report a model identifier. This is the configured value observed after the run, not a provider-returned identity. No configuration or credential content is retained.'}
h.write(h.O/'codex-independent-assessment.json',{'outcome':'observed_cases_pass_after_read_input_correction',
    'lifecycle_replay':{'accepted_calls':11,'native_exports':2,'source':str(replay/'assessment.json')},
    'synthetic_decisions':decisions,'reply_recovery':{'original_receipt_equals_lookup_and_retry':True,'project_version_after_retry':20,'changed_payload_refused':True},
    'required_refusals':{'stale_project':True,'outside_path':True},'live_assertion':assertion,
    'read_trace':{'matching_file_hashes':len(trace),'failed_reads_with_no_hash':len(missing),'outputs_edited_after_read':later_edits},
    'mcp':{'successful_exact_http_matches':sorted(p['tool'] for p in parity),'input_correction':'Existing docs/notes/hosted-artifact-graph.md staged before a separate native read case; no query or request supplied.'},
    'host':host,'limitations':['Native04 alone has the retained failed Cypher read. reads01 supplies the final bounded-read case.',
    'One earlier replay failed because its temporary clone path was too long on Windows. It is retained; the shorter-path replay passed.',
    'Actual WO-HAG-009 remains in_progress. This is evidence, not human verification, merge or release.']})
print(json.dumps({'accepted_calls':11,'exports':2,'matching_trace_hashes':len(trace),'mcp_tools':7,'configured_model':host['configured_model']}))
