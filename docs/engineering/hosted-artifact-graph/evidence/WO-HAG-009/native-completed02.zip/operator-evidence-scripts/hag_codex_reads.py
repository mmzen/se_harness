"""Fresh read-only native case with the omitted existing protocol guide staged."""
import json,shutil,subprocess,sys
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
previous=h.O/'codex-final/native04'
root=h.O/'codex-final/reads01'
if sys.argv[1]=='stage':
    root.mkdir(exist_ok=False);(root/'work').mkdir()
    shutil.copytree(previous/'inputs',root/'inputs')
    guide='docs/notes/hosted-artifact-graph.md'
    path=root/'inputs/reference'/guide
    shutil.copyfile(h.R/guide,path)
    selection=json.loads((previous/'selection.json').read_text())
    outer=json.loads((h.O/'codex-final/selection.json').read_text())
    selection['endpoint']=outer['endpoint']
    for key,value in list(selection.items()):
        if isinstance(value,str) and str(previous/'inputs') in value:
            selection[key]=value.replace(str(previous/'inputs'),str(root/'inputs'))
    views={}
    for name in ('earlier','later'):
        manifest=json.loads((previous/'work'/('export-'+name)/'manifest.json').read_text())
        views[name]={'kind':'baseline','baseline_id':manifest['baseline']['baseline_id']}
    selection['selected_views']=views
    selection['selected_work_order']='WO-N04-001'
    h.write(h.O/'codex-final/reads01-selection.json',selection)
    task='''# Inspect the selected hosted test records\n\nYou are the independent native agent for the read-only portion of VER-HAG-007\nNQ-03. Use the exact test project and two immutable views in SELECTION_FILE.\nGit remains authoritative; these records and supplied actor labels are test data.\nMake no service mutation and do not alter imported or real repository files.\n\nUse the candidate plugin's setup and harness-orient guidance under inputs/plugin.\nThe operator has already installed the separate candidate client and selected\nthe service. Do not install, activate, or change the real host plugin.\nRead the applicable protocol information under inputs/reference, including\ndocs/notes/hosted-artifact-graph.md and the read-v1.json schema. These are existing\nproduct instructions. Automatic delivery is outside this case.\n\nUse each of the seven actual hag MCP tools on meaningful selected views:\nrevision, work-context, compare, impact, lineage, check and cypher. Choose the\nrequests and query from the product instructions and observed records yourself.\nRetain exact requests/results and completeness/continuation flags. Read saved\nresults if needed and permitted. An attempted or refused read is not a successful\nread. Checkpoint-free context does not establish passed gates or authority.\n\nThe independent reviewer will repeat your exact read requests through HTTP.\nKeep the two baseline selections unchanged. Do not inspect previous sessions,\nqualification walkthroughs, or completed request examples. Authentication is\nalready configured by environment variable; never print its value or inspect\ncredential files. Keep normal native sandbox/review; stop a permission denial.\n\nWrite only under work/ and the two root files native-report.md and\nnative-observations.json. Record actual read triggers and file hashes, all tool\nresults and any unresolved gap. Report no lifecycle, assurance, release or\nwhole-work qualification completion from these reads.\n'''
    h.write(h.O/'codex-final/reads01-task.md',task)
    h.write(h.R/h.D/'evidence/WO-HAG-009/codex-reads01-inputs.json',{
        'kind':'Correction of omitted existing test input for an independent read-only case',
        'source':'docs/notes/hosted-artifact-graph.md','sha256':h.sha(path.read_bytes()),
        'replaced_instructions':False,'product_guidance_changed':False,
        'task_sha256':h.sha(task.encode()),'selected_views':views,
        'limits':'This case covers the seven bounded reads only. Earlier refused Cypher calls remain failures; lifecycle/refusal/retry/export evidence is assessed separately.'})
elif sys.argv[1]=='run':
    args=[h.HOST,'-X','utf8','-B',h.R/'tests/hosted_artifact_graph/qualify_agents.py',
        '--host','codex','--executable',r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe',
        '--selection',h.O/'codex-final/reads01-selection.json','--credentials',h.O/'codex-final/credentials.json',
        '--task',h.O/'codex-final/reads01-task.md','--output',root,'--prepared-inputs','--timeout','900']
    raise SystemExit(subprocess.call(list(map(str,args)),cwd=h.W))
