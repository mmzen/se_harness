All seven actual hag MCP tools returned successful, fully inspected reads on the selected immutable test views. Every response reports `complete: true`, `continuation: null`, and `unresolved_references: []`. There were no refused reads, permission denials, or unread saved responses.

This is a bounded VER-HAG-007 NQ-03 read observation. Git remains authoritative. Supplied actor labels and recorded lifecycle states are test data. These reads establish no lifecycle, assurance, release, or whole-work qualification completion.

Project: `4a495f62-50ba-4f69-b120-393685b1d232` at `http://127.0.0.1:18312`.

| Selection | Immutable baseline |
| --- | --- |
| Earlier | `se-harness-artifact-baseline/v1:sha256:9f4c37933a05ca7c96cb60596c5cc53262feb2fa6c22dd7436506a9b86b3a7f9` |
| Later | `se-harness-artifact-baseline/v1:sha256:80cdffcf457c9631a6442df36b471782cde393ba824814aa9d0d74f6b7e64020` |

The candidate setup and harness-orient guidance was read explicitly under `inputs/plugin`. The existing separate client was reused. The live status matched the selected combination, including evaluator 0.22.1, client 0.22.2, component identities, protocols, schema revision 2, `sandbox-projection`, and `test_copy: true`. The candidate wheel SHA-256 matched. The real host plugin was not installed, activated, or changed.

| Actual tool | Selection and observation | Evidence prefix |
| --- | --- | --- |
| compare | Earlier → later: added RLS-N04-001, changed VREC-N04-001; five added and two removed revision-bound relations | `work/01-compare` |
| work-context | Later WO-N04-001: five governing artifacts, eleven declared paths, two dependencies, one relevant decision | `work/02-work-context` |
| revision | Earlier VREC-N04-001: complete stored bytes; document SHA-256 and canonical revision ID recomputed successfully | `work/03-revision` |
| impact | Later SPEC-N04-001: six dependent artifacts excluding the root, eleven relations | `work/04-impact` |
| lineage | Later RLS-N04-001: four connected artifacts excluding the root, six relations | `work/05-lineage` |
| check | Later VREC-N04-001: unchanged checkpoint-free evaluator result | `work/06-check` |
| cypher | Parameterized public Revision query returned the later VREC binding and its recorded test status `verified` | `work/07-cypher` |

Requests use `se-harness-graph-read/v1`; this configured test project returns `se-harness-graph-read/v2` with the required test-copy label. Each request uses a budget of 500 rows, 2,097,152 bytes and depth eight. Tool choices and the Cypher query were derived from the product protocol and these observed records. No previous sessions, qualification walkthrough files, or completed request examples were inspected.

Both embedded evaluator results report `compliance.status: not_assessable`, `gates: []`, `change_set_complete: false`, and `mutation.writes: []`. Their `PROC-DELIVERY-SELECT` / `STEP-DELIVERY-SELECT` context is retained as observed test data; no delivery path was selected or executed. Their recorded statuses and retrospective restitution wording confer no new decision or authority.

The returned instruction-discovery status was `available`. Explicit reads of the supplied entry, COMMUNICATION, RESULTS, and DELIVER_RESULT resources matched their advertised hashes. Actual read triggers, exact hashes, complete MCP objects, response text, requests, evaluator identities, revision identities, and completeness fields are retained in [native-observations.json](native-observations.json). No evaluator-only policy files were read. No accountable decision was obtained or applied.

Each evidence prefix has `.json` (complete MCP call record), `.request.json` (replay body), and `.response.json` (exact returned text). The decoded earlier VREC is retained as `work/03-revision.document.md`. `work/status-before.json` and `work/status-after.json` preserve the status calls. Project version remained 30 and both status results were equal. All consumed input hashes, including `selection.json`, remained unchanged. Writes were confined to `work/` and the two authorized root report files; no service mutation or source/repository edit was performed.

Independent HTTP replay remains for the reviewer. Database-side read-only enforcement remains deferred under RISK-HAG-001. Automatic instruction delivery and all lifecycle, assurance, release and broader qualification decisions remain outside this observation.
