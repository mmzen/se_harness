import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent.parent
def read(path):
    return json.loads((root / path).read_text(encoding='utf-8'))
def digest(path):
    return hashlib.sha256((root / path).read_bytes()).hexdigest()

selection = read('selection.json')
combination = read('inputs/combination.json')
configuration = read('inputs/configuration.json')
status_record = read('work/status-before.json')
status = json.loads(status_record['stdout'])
checks = {
    'status_exit_zero': status_record['exit'] == 0,
    'ready': status['ready'] is True,
    'project_matches': status['project_id'] == selection['project_id'],
    'authority_mode': status['authority_mode'] == 'sandbox-projection',
    'test_copy': status['test_copy'] is True,
    'schema_revision': status['schema_revision'] == combination['payload']['schema_revision'] == 2,
    'components': status['components'] == combination['payload'] == configuration['components'],
    'protocols': status['protocols'] == combination['payload']['protocols'],
    'evaluator': status['evaluator'] == combination['payload']['evaluator'],
    'client': status['client'] == combination['payload']['client'],
    'wheel_sha256': digest('inputs/se_harness-0.22.2-py3-none-any.whl') == combination['payload']['client']['wheel_sha256'],
}
files = [
    ('selection.json', 'User explicitly selected project, views and work order.'),
    ('inputs/plugin/skills/setup/SKILL.md', 'User explicitly requested candidate setup guidance; hosted selection prerequisites.'),
    ('inputs/plugin/skills/harness-orient/SKILL.md', 'User explicitly requested candidate harness-orient guidance; seven hosted read tools and completeness handling.'),
    ('inputs/reference/docs/notes/hosted-artifact-graph.md', 'User explicitly requested product protocol; read semantics and public Cypher surface. Historical report links were not followed.'),
    ('inputs/reference/server/contracts/read-v1.json', 'User explicitly requested read schema; all definitions inspected as compact JSON after initial output truncation.'),
    ('inputs/combination.json', 'Setup hosted selection requires comparing exact component tuple.'),
    ('inputs/configuration.json', 'Selected service configuration; confirm test_copy and component tuple.'),
    ('inputs/native_call.py', 'Selected helper inspected before executing status; no mutation operation used.'),
    ('inputs/reference/server/README.md', 'Protocol guide operating-procedure link; keyword scan and lines 165-246 read for protocol limits and v2 test-copy semantics; no walkthrough files opened.'),
    ('inputs/reference/server/contracts/lifecycle-v2.md', 'Product protocol reference for graph-read/v2 test-copy labels and unchanged revision hashing; first 95 lines read.'),
    ('inputs/se_harness-0.22.2-py3-none-any.whl', 'Setup requires SHA-256 comparison; hash only, no installation.'),
]
result = {'checks': checks, 'selected_views': selection['selected_views'], 'input_reads': [
    {'path': path, 'sha256': digest(path), 'trigger': trigger} for path, trigger in files
]}
(root/'work/selection-verification.json').write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
print(json.dumps(result, indent=2))
assert all(checks.values()), 'Hosted selection mismatch; stop remote actions'
