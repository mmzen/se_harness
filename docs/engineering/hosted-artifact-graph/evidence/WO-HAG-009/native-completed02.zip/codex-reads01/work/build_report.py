import base64
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent.parent
work = root / 'work'
def read(path):
    return json.loads((root/path).read_text(encoding='utf-8'))
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def file_info(path):
    raw = (root/path).read_bytes()
    return {'path': path, 'bytes': len(raw), 'sha256': sha(raw)}
def write_json(path, value):
    (root/path).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

selection = read('selection.json')
verification = read('work/selection-verification.json')
before = read('work/status-before.json')
after = read('work/status-after.json')
status_before = json.loads(before['stdout'])
status_after = json.loads(after['stdout'])
assert before['exit'] == after['exit'] == 0
assert status_before == status_after
for entry in verification['input_reads']:
    assert file_info(entry['path'])['sha256'] == entry['sha256'], entry['path']

ids = ['01-compare', '02-work-context', '03-revision', '04-impact', '05-lineage', '06-check', '07-cypher']
records = []
responses = {}
for id_ in ids:
    record = read('work/'+id_+'.json')
    result = record['result']
    assert result.get('isError') is False
    assert len(result['content']) == 1 and result['content'][0]['type'] == 'text'
    raw_text = result['content'][0]['text']
    response = json.loads(raw_text)
    responses[record['request']['operation']] = response
    request = record['request']
    assert response['operation'] == request['operation']
    assert response['project_id'] == selection['project_id'] == request['project_id']
    assert response['view'] == request['view']
    assert response['schema'] == 'se-harness-graph-read/v2'
    assert response['test_copy'] is True
    assert response['authority'] == 'rehearsal-only; Git remains authoritative'
    assert response['evaluator'] == status_before['evaluator']
    assert response['observed_project_version'] == 30
    assert response['complete'] is True
    assert response['continuation'] is None and response['unresolved_references'] == []
    request_path = 'work/'+id_+'.request.json'
    response_path = 'work/'+id_+'.response.json'
    write_json(request_path, request)
    (root/response_path).write_bytes(raw_text.encode('utf-8'))
    record.update({
        'request_file': file_info(request_path),
        'response_file': file_info(response_path),
        'mcp_record_file': file_info('work/'+id_+'.json'),
        'http_replay': {'method': 'POST', 'endpoint': selection['endpoint'], 'project_id': selection['project_id'], 'operation': request['operation'], 'body_file': request_path, 'route': 'Use the service HTTP route for this operation; no route inferred from the tool name.', 'authentication': 'Use configured environment credential; value not retained.'},
        'assessment': {'successful_read': True, 'response_fully_read': True, 'saved_file_notice': False, 'complete': response['complete'], 'continuation': response['continuation'], 'unresolved_references': response['unresolved_references'], 'schema': response['schema'], 'observed_project_version': response['observed_project_version'], 'evaluator': response['evaluator'], 'provenance': response['provenance'], 'test_copy': response['test_copy']}
    })
    if response['evaluator_output'] is not None:
        eo = response['evaluator_output']
        record['assessment']['checkpoint_free_compliance'] = eo['compliance']
        record['assessment']['instruction_discovery_status'] = eo['instruction_discovery']['status']
        assert eo['instruction_discovery']['status'] == 'available'
        assert eo['compliance']['status'] == 'not_assessable' and eo['compliance']['gates'] == []
        assert eo['mutation']['writes'] == []
    records.append(record)

revision = responses['revision']['data']
document = base64.b64decode(revision['document_base64'], validate=True)
assert base64.b64encode(document).decode() == revision['document_base64']
assert sha(document) == revision['envelope']['document_sha256']
canonical = json.dumps(revision['envelope'], sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
computed_revision = 'sha256:'+sha(b'se-harness-artifact-revision/v1\n'+canonical)
assert computed_revision == revision['revision_id']
document_path = 'work/03-revision.document.md'
(root/document_path).write_bytes(document)
changes = responses['compare']['data']['changes']
vrec_change = next(x for x in changes if x['artifact_id'] == 'VREC-N04-001')
assert vrec_change['before'] == revision['revision_id']
assert responses['check']['data']['artifact']['revision_id'] == vrec_change['after']
assert responses['cypher']['data']['rows'] == [['VREC-N04-001', vrec_change['after'], 'verified']]
assert len(responses['cypher']['data']['columns']) == 3

discovery = responses['work-context']['evaluator_output']['instruction_discovery']['agent_instructions']
resources = [discovery['entry'], *discovery['shared_prerequisites'], discovery['current_step']['location']]
resource_reads = []
for resource in resources:
    path = 'inputs/released-resources/'+resource['file']
    info = file_info(path)
    assert info['sha256'] == resource['sha256'], path
    info.update({'heading': resource['heading'], 'advertised_sha256': resource['sha256'], 'hash_matches': True,
                 'trigger': 'Actual work-context and check instruction_discovery; explicit file read for reporting boundaries and current step. Full supplied file read; no procedure action executed.'})
    resource_reads.append(info)

notes = {
    'comparison': {'changes': changes, 'added_relations': len(responses['compare']['data']['added_relations']), 'removed_relations': len(responses['compare']['data']['removed_relations'])},
    'work_context': {'governing_artifacts': responses['work-context']['data']['governing_artifacts'], 'declared_scope': responses['work-context']['data']['declared_scope'], 'dependencies': responses['work-context']['data']['dependencies'], 'relevant_decisions': responses['work-context']['data']['relevant_decisions']},
    'revision_integrity': {'document': file_info(document_path), 'document_sha256_matches': True, 'computed_revision_id': computed_revision, 'revision_id_matches': True},
    'impact': {'root': 'SPEC-N04-001', 'artifact_count_excluding_root': len(responses['impact']['data']['artifacts']), 'relation_count': len(responses['impact']['data']['relations'])},
    'lineage': {'root': 'RLS-N04-001', 'artifact_count_excluding_root': len(responses['lineage']['data']['artifacts']), 'relation_count': len(responses['lineage']['data']['relations'])},
    'cypher': responses['cypher']['data'],
    'checkpoint_free_context': 'Both embedded evaluator results report compliance.status=not_assessable, gates=[], change_set_complete=false, and mutation.writes=[]. Recorded test states and restitution wording are retained unchanged and do not describe decisions made by this agent.',
    'returned_step': {'procedure_id': 'PROC-DELIVERY-SELECT', 'step_id': 'STEP-DELIVERY-SELECT', 'role': 'repository-owner or release-owner', 'decision_right': 'DR-DELIVERY-SELECT', 'executed': False, 'reason': 'Read-only task; automatic delivery and lifecycle decisions are outside this case.'},
}
observations = {
    'scope': 'VER-HAG-007 NQ-03 independent Codex native read-only observations; no whole-work qualification verdict',
    'host': 'codex', 'session_id': '01a11450-c2de-7282-b326-3ef3a81f0e46',
    'selection': selection,
    'setup_verification': verification,
    'instruction_delivery': {'mode': 'explicit local candidate resource reads', 'automatic_delivery_assessed': False, 'real_host_plugin_changed': False, 'checkout_activated': False, 'separate_client_reused': True, 'resource_reads': resource_reads, 'authority_prerequisite': 'AUTHORITY.md condition (obtaining or applying an accountable decision) did not apply; no such decision requested or performed.', 'formal_reading_manifest': 'Returned IDs and paths retained. No lifecycle action or whole governing-context review attempted; formal document read limited to the selected earlier VREC through the revision tool.'},
    'native_reads': records,
    'findings': notes,
    'status_reads': {'before': before, 'after': after, 'before_file': file_info('work/status-before.json'), 'after_file': file_info('work/status-after.json'), 'equal': True, 'observed_project_version_before': 30, 'observed_project_version_after': 30},
    'unchanged_input_checks': {'all_consumed_input_hashes_match': True, 'selection_file_sha256': file_info('selection.json')['sha256'], 'selected_views_unchanged': selection['selected_views'] == verification['selected_views'], 'service_mutation_tools_called': 0, 'source_or_real_repository_write_operations': 0},
    'unresolved_gaps': [
        'Independent HTTP replay has not been performed by this agent; exact request bodies and response text are retained for the reviewer.',
        'Checkpoint gates and real human authority were not assessed; not_assessable remains not_assessable.',
        'Database-enforced read-only access remains deferred under RISK-HAG-001 as reported by status.',
        'Automatic instruction delivery, lifecycle, assurance, release, and whole-work qualification are outside this read-only observation.'
    ],
    'read_failures_or_denials': [],
    'retention': 'Each work/NN-name.json preserves the complete returned MCP object and its content text; response.json contains that exact UTF-8 text without reformatting. Request files contain exact argument values. Embedded evaluator output is unchanged. No saved-file notice or unread MCP content occurred.',
}
write_json('native-observations.json', observations)

report = '''All seven actual hag MCP tools returned successful, fully inspected reads on the selected immutable test views. Every response reports `complete: true`, `continuation: null`, and `unresolved_references: []`. There were no refused reads, permission denials, or unread saved responses.

This is a bounded VER-HAG-007 NQ-03 read observation. Git remains authoritative. Supplied actor labels and recorded lifecycle states are test data. These reads establish no lifecycle, assurance, release, or whole-work qualification completion.

Project: `4a495f62-50ba-4f69-b120-393685b1d232` at `http://127.0.0.1:18312`.

| Selection | Immutable baseline |
| --- | --- |
| Earlier | `se-harness-artifact-baseline/v1:sha256:9f4c37933a05ca7c96cb60596c5cc53262feb2fa6c22dd7436506a9b86b3a7f9` |
| Later | `se-harness-artifact-baseline/v1:sha256:80cdffcf457c9631a6442df36b471782cde393ba824814aa9d0d74f6b7e64020` |

The candidate setup and harness-orient guidance was read explicitly under `inputs/plugin`. The existing separate client was reused. The live status matched the selected combination, including evaluator 0.22.1, client 0.22.2, component identities, protocols, schema revision 2, `sandbox-projection`, and `test_copy: true`. The candidate wheel SHA-256 matched. The real host plugin was not installed, activated, or changed.

| Actual tool | Selection and observation | Evidence prefix |
| --- | --- | --- |
| compare | Earlier → later: added RLS-N04-001, changed VREC-N04-001; five added and two removed revision-bound relations | `work/01-compare` |
| work-context | Later WO-N04-001: five governing artifacts, eleven declared paths, two dependencies, one relevant decision | `work/02-work-context` |
| revision | Earlier VREC-N04-001: complete stored bytes; document SHA-256 and canonical revision ID recomputed successfully | `work/03-revision` |
| impact | Later SPEC-N04-001: six dependent artifacts excluding the root, eleven relations | `work/04-impact` |
| lineage | Later RLS-N04-001: four connected artifacts excluding the root, six relations | `work/05-lineage` |
| check | Later VREC-N04-001: unchanged checkpoint-free evaluator result | `work/06-check` |
| cypher | Parameterized public Revision query returned the later VREC binding and its recorded test status `verified` | `work/07-cypher` |

Requests use `se-harness-graph-read/v1`; this configured test project returns `se-harness-graph-read/v2` with the required test-copy label. Each request uses a budget of 500 rows, 2,097,152 bytes and depth eight. Tool choices and the Cypher query were derived from the product protocol and these observed records. No previous sessions, qualification walkthrough files, or completed request examples were inspected.

Both embedded evaluator results report `compliance.status: not_assessable`, `gates: []`, `change_set_complete: false`, and `mutation.writes: []`. Their `PROC-DELIVERY-SELECT` / `STEP-DELIVERY-SELECT` context is retained as observed test data; no delivery path was selected or executed. Their recorded statuses and retrospective restitution wording confer no new decision or authority.

The returned instruction-discovery status was `available`. Explicit reads of the supplied entry, COMMUNICATION, RESULTS, and DELIVER_RESULT resources matched their advertised hashes. Actual read triggers, exact hashes, complete MCP objects, response text, requests, evaluator identities, revision identities, and completeness fields are retained in [native-observations.json](native-observations.json). No evaluator-only policy files were read. No accountable decision was obtained or applied.

Each evidence prefix has `.json` (complete MCP call record), `.request.json` (replay body), and `.response.json` (exact returned text). The decoded earlier VREC is retained as `work/03-revision.document.md`. `work/status-before.json` and `work/status-after.json` preserve the status calls. Project version remained 30 and both status results were equal. All consumed input hashes, including `selection.json`, remained unchanged. Writes were confined to `work/` and the two authorized root report files; no service mutation or source/repository edit was performed.

Independent HTTP replay remains for the reviewer. Database-side read-only enforcement remains deferred under RISK-HAG-001. Automatic instruction delivery and all lifecycle, assurance, release and broader qualification decisions remain outside this observation.
'''
(root/'native-report.md').write_text(report, encoding='utf-8')
files = [p for p in work.rglob('*') if p.is_file() and p.name != 'output-hashes.json']
files += [root/'native-report.md', root/'native-observations.json']
write_json('work/output-hashes.json', [file_info(p.relative_to(root).as_posix()) for p in sorted(files)])
print(json.dumps({'successful_native_reads': len(records), 'completeness': [r['assessment']['complete'] for r in records], 'status_equal': True, 'input_hashes_unchanged': True, 'revision_hash_verified': True, 'resource_hashes_verified': True, 'outputs': ['native-report.md', 'native-observations.json', 'work/output-hashes.json']}, indent=2))
