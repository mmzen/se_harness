The greeting proof and synthetic engineering lifecycle are complete. Overall native qualification is **incomplete**: all seven configured MCP tools were called, but the Cypher query was refused. Six distinct MCP tools returned complete selected views. Independent Git reconstruction and released-evaluator replay remain for the reviewer.

The local assertion exited 0 with exact stdout `exact greeting passed\n` and empty stderr. It tested `greeting() == 'Hello rehearsal'` without normalization. The immutable source was inspected and remained unchanged. The service did not run source tests. See [assertion receipt](work/003-greeting-assertion.json) and [source inspection](work/source-inspection.json).

| Selected identity | Observed value |
| --- | --- |
| Project | `4a495f62-50ba-4f69-b120-393685b1d232` |
| Endpoint | `http://127.0.0.1:64194` |
| Candidate client / plugin | `0.22.2` / `0.2.7` |
| Released evaluator | `0.22.1` |
| Evaluator archive SHA-256 | `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053` |
| Evaluator payload SHA-256 | `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff` |
| Client wheel SHA-256 | `dde016db02340ca01a9542ec052cce471b27308df8a85878bf36b1ce97d89353` |
| Immutable source S | `5820415917e87b64d80bad2f7c39c6d18d692829` |
| Actual implementation candidate C | `345557d20e83f1c6ed72e11460ee4ba451cf3d91` |
| Disposable test candidate P | `67d4d1d330842b499d29dc87d2a413a6b75680fd` |
| Context | `86e65672-a90b-4406-bfa2-025ccf7e0ae5`, final version 28 |
| Final project version | 30 |

S is the supplied tracked-file snapshot, C identifies the hosted implementation under qualification, and P is the disposable engineering candidate bound by the VREC and RLS. These identities are not interchangeable. [Identity comparison](work/identity-comparison.json) records matching supplied/service components, schema revision 2 and test-copy readiness. Readiness and ordinary context checks returned `not_assessable` with no gates; they were not treated as gate passes.

I used the selected candidate's setup, change, evidence and orientation instructions through explicit file reads, together with the released procedures selected by actual evaluator results. Setup verified supplied identities without installation or activation of a real checkout. No claim of automatic instruction injection is made. [Read trace](work/read-trace.jsonl) records exact paths, SHA-256 hashes, byte counts and read triggers, including labelled retrospective audit reads. Only relevant supplied product references, CLI help, plugin/released instructions, source inputs and this run's outputs were used.

| New artifact | Final state and identity |
| --- | --- |
| INT/CAP/REQ/SPEC/VER/REL-N04-001 | Approved by synthetic `test-owner` |
| WO-N04-001 | Implemented; started and completed by `test-executor`; commit-bound assurance required |
| RISK-N04-001 | Mitigating: evidence could be attributed to the wrong candidate |
| DEC-N04-001 | Decided by `test-owner`: mitigate using WO-N04-001 |
| VREC-N04-001 | Verified; owner, preparation and acceptance identity `quality-owner` |
| RLS-N04-001 | Released for test version `0.0.1`; owner, preparation and release identity `release-owner` |

The authored work paths name the new formal records, exact risk/decision paths, `src/greeting.py`, and the retained WO evidence directory. Related generated records use the evaluator's admission rules. No source edit was necessary. The seven imported `-900` records remained draft and byte-identical to the supplied fixture.

The final validation is valid with zero errors and zero warnings. Its one maintenance advisory, W-AUT-022 on SPEC-P3-900, was already present in immutable history. An advisory on my initial SPEC draft was corrected before definition approval. See [final validation](work/067-final-validation-result.json). Start preflight, bounded handoff, completion, VREC acceptance and release transition returned passing checks. The final release transition passed QG-G5-RELEASE-DECISION and QG-STRUCTURAL. The final RLS context check again reports context rather than another gate pass.

| Required challenge | Actual observation and effects |
| --- | --- |
| Stale preview | After INT-N04-001 changed, applying its old preview returned HTTP 409 `HAG_REMOTE_STALE_PROJECT`. No transition was accepted. Project 5/context 3 and the revised draft were confirmed by lineage. This proves the stale project guard; it is not a separately observed digest-only refusal. |
| Out-of-scope handoff | `docs/outside-native04.json` returned HTTP 422 `HAG_REMOTE_EVALUATOR_REFUSED`, WEX201 / QGP-G4I-PATHS. Comparison showed no added, removed or changed artifacts at project 24/context 22. The subsequent in-scope handoff passed and was accepted. |
| Lost accepted reply | Definitions apply exited 2 with transport outcome `unknown`. Looking up the original key recovered the accepted receipt. |
| Identical retry | The original request file, including its original expected versions, was retried once. Receipt, request digest, versions, affected revisions and baseline were identical; there was one accepted effect. |
| Changed accepted key | Changing a reason under the accepted key returned HTTP 409 `HAG_REMOTE_KEY_REUSE`. Status remained project 20. |
| Host permission refusal | None occurred. Service/evaluator refusals above are not host permission denials. |

For independent comparison, the lost-reply key is `native04-definitions-apply`; its accepted request digest is `sha256:b0c118ec54c8aad3f313ced336b2b94d4a953958999ebbdf596a0b0b03c20e45` and receipt is `sha256:03f00de51ea2355e6906e32073b2921d7b017a15fe9c4bed171e6b901272e23e`. It advanced project 19→20 and context 17→18. Exact evidence is in numbered files 029–033 and [recovery comparison](work/071-recovery-comparison.json). Stale evidence is in 008–010a; scope refusal and unchanged-effect evidence is in 045–046; valid handoff is in 047–048.

| MCP tool | Meaningful selected read | Result |
| --- | --- | --- |
| revision | INT template; generated risk/decision; ready RLS | Complete |
| lineage | Revised INT after stale refusal, context 3 | Complete |
| work_context | New WO and governing chain, context 16 | Complete |
| check | Open mitigation decision, context 21 | Complete; context is not approval |
| compare | Accepted baseline against context 22 after scope refusal | Complete; no changes |
| impact | REQ-N04-001 downstream coverage, context 25 | Complete |
| cypher | Intended VREC read at earlier immutable baseline | Refused; no completeness claim |

Every successful MCP response explicitly returned `complete=true`, `continuation=null` and no unresolved references for that selected view. Raw saved responses were read. This does not imply that every artifact in the project was requested. The Cypher call returned HTTP 400 `HAG_REMOTE_QUERY_SYNTAX: Unknown public label or relationship.` My query used `ArtifactRevision` without first establishing that it was supported public vocabulary. This is an agent-authored query failure, not proof of a service defect. I stopped that operation without guessing another query or changing routes, as instructed. The MCP wrapper's `isError=false` did not make the embedded refusal a success. Exact request/response and view/completeness details are in [call index](work/070-call-index.json) and numbered MCP files, especially [055 request](work/055-mcp-cypher-request.json) and [055 result](work/055-mcp-cypher-result.json).

| Immutable export | Earlier | Later |
| --- | --- | --- |
| Destination | [work/export-earlier](work/export-earlier/manifest.json) | [work/export-later](work/export-later/manifest.json) |
| Files | 27 | 29 |
| State | WO implemented, VREC ready | WO implemented, VREC verified, RLS released |
| Git head | `e72b521dee48f79c9485c5daa880a293cb2494fd` | `27011b10acd6edaa985cd542a4cfd74223092555` |
| Snapshot | `sha256:02a360ef2ee0bc09b887e2c3266add0d684a4059167e2506ab304633e30dd608` | `sha256:8c2e3d360993781afee6a91a7f454fbd11665e938a56da998ee9e906c210d741` |
| Bundle bytes | 22865 | 25641 |
| Bundle SHA-256 | `a175cb4a6f832381a03fad65f885906dd86333624ae8dc48306f463f1effe157` | `e8bb006d7ae044bae0f074149ce61b967b485173d68e1b833ff200c9f9477d27` |

Both destinations were new and separate. All exported file sizes/hashes and bundle hashes matched their manifests; neither has an incomplete marker. Both retain identical original candidate-binding metadata and the exact local assertion receipt. Source SHA-256 remains `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`. See [earlier integrity check](work/056-earlier-export-check.json) and [later integrity check](work/069-later-export-check.json).

The VREC sidecar records origin/version evidence and has null archive/payload hashes. I did not treat those nulls as a full identity check; the complete evaluator tuple is retained in service results, candidate metadata and the lock. The RLS sidecar records full-payload identity. The exported bundles preserve the original P separately from later governance heads. The independent reviewer must still reconstruct Git history and replay the records using released 0.22.1; this report does not claim that replay passed.

All exact remote requests and full client stdout/stderr/argv/cwd receipts are retained under `work/`. The call index maps receipts to operations, keys, versions and views. Encoded document bytes remain in revision/handoff request files; final authored drafts are under `work/drafts/`. The retained single-call recorder performs one chosen call and result read, with no workflow sequencing or decisions. Offline scripts only check exported bytes or index saved results.

Minor local issues are recorded in [native-observations.json](native-observations.json): missing resource/path guesses, an oversized audit display, and a dictionary summary that initially displayed nulls. The trace preserves three null entries from nonexistent-path attempts; [failed-read details](work/read-attempt-failures.json) identify their exact paths and trace lines. They are not successful file reads. None changed service state; the saved integrity result was reread and confirmed. No additional human intervention, delegation, permission change, credential-value access, source modification or real Git/external action occurred.

The released record's next typed step is PROC-EXTERNAL-ACTION. No such action was selected: the user's authority is restricted to this synthetic assessment. The `native04-test-0.0.1` tag field is test metadata only. No tag, push, publication, installation or deployment occurred. A failed export or independent replay requires withholding use of the exported test release, preserving the failed evidence and obtaining an explicit selection before any fresh test run.
