async (stem, command, request) => {
await tools.apply_patch("*** Begin Patch\n*** Add File: work/"+stem+"-request.json\n+"+JSON.stringify(request,null,2).replaceAll("\n","\n+")+"\n*** End Patch");
const raw=await tools.exec_command({cmd:load("prefix")+" remote "+command+" --request work/"+stem+"-request.json --record work/"+stem+"-result.json | Out-Null",max_output_tokens:1500});
if(raw.output)text(raw);
const read=await tools.exec_command({cmd:". ./work/read.ps1 work/"+stem+"-result.json 'Inspect exact result before next operation' | ConvertFrom-Json | ForEach-Object { $_.stdout }",max_output_tokens:55000});
let result;try{result=JSON.parse(read.output);}catch{text(read);return null;}
store(stem,result);
const clean=JSON.parse(JSON.stringify(result)); if(clean.provenance?.candidates) for(const candidate of clean.provenance.candidates){if(candidate.files){candidate.file_count=Object.keys(candidate.files).length;delete candidate.files;}}
if(clean.evaluator_output?.commands) for(const cmd of clean.evaluator_output.commands) {if(cmd.result){cmd.result.instruction_step=cmd.result.instruction_discovery?.agent_instructions?.current_step; delete cmd.result.instruction_discovery;delete cmd.result.procedure; if(cmd.result.compliance?.gates) for(const g of cmd.result.compliance.gates){g.predicates=g.predicates?.map(p=>p.status==="pass"?{id:p.id,status:p.status}:p);}}}
text({...clean,evaluator_output:clean.evaluator_output?.commands?{commands:clean.evaluator_output.commands.map(c=>({command:c.command,arguments:c.arguments,exit:c.exit,result:c.result?{schema:c.result.schema,operation:c.result.operation,compliance:c.result.compliance,state:c.result.state,findings:c.result.findings,mutation:c.result.mutation,restitution:c.result.restitution,instruction_step:c.result.instruction_step,...(!c.result.state?c.result:{})}:c.result}))}:clean.evaluator_output});
return result;
}
