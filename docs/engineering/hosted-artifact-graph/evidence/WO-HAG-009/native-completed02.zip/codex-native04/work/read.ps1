param([Parameter(Mandatory=$true)][string]$Path,[Parameter(Mandatory=$true)][string]$Trigger)
$resolved = (Resolve-Path -LiteralPath $Path).Path
$bytes = [IO.File]::ReadAllBytes($resolved)
$entry = [ordered]@{path=$resolved;sha256=(Get-FileHash -LiteralPath $resolved -Algorithm SHA256).Hash.ToLower();bytes=$bytes.Length;trigger=$Trigger}
$entry | ConvertTo-Json -Compress | Add-Content -LiteralPath "$PSScriptRoot/read-trace.jsonl" -Encoding utf8
[IO.File]::ReadAllText($resolved)
