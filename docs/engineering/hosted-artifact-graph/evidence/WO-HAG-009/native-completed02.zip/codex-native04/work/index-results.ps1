$ErrorActionPreference='Stop'
$entries = foreach ($file in (Get-ChildItem -LiteralPath work -File | Where-Object {$_.Name -match '^\d.*\.json$' -and $_.Name -notmatch '-request\.json$'} | Sort-Object Name)) {
 $raw = . ./work/read.ps1 $file.FullName 'Final audit of retained call result; compare receipts and completeness'
 $saved = $raw | ConvertFrom-Json -AsHashtable
 if ($saved.ContainsKey('argv')) {
   $response = if ($saved.stdout) { try {$saved.stdout | ConvertFrom-Json -AsHashtable} catch {$null} } else {$null}
   $transport = if ($saved.stderr) { try {$saved.stderr | ConvertFrom-Json -AsHashtable} catch {$null} } else {$null}
   [ordered]@{file=('work/'+$file.Name);kind='local-client';argv=$saved.argv;cwd=$saved.cwd;exit=$saved.exit;outcome=$response.outcome;operation_key=$response.operation_key;request_digest=$response.request_digest;receipt_id=$response.receipt_id;versions=$response.versions;baseline_id=$response.baseline_id;view=$response.view;error=$response.error;transport=$transport}
 } elseif ($saved.ContainsKey('content')) {
   $response = $saved.content[0].text | ConvertFrom-Json -AsHashtable
   $requestPath = $file.FullName.Replace('-result.json','-request.json')
   $request = (. ./work/read.ps1 $requestPath 'Match exact saved MCP input with complete raw response' | ConvertFrom-Json -AsHashtable)
   [ordered]@{file=('work/'+$file.Name);request=('work/'+[IO.Path]::GetFileName($requestPath));kind='MCP';operation=$request.operation;requested_view=$request.view;actual_view=$response.view;observed_project_version=$response.observed_project_version;outcome=$response.outcome;schema=$response.schema;complete=$response.complete;continuation=$response.continuation;unresolved_references=$response.unresolved_references;error=$response.error;http_status=$response.http_status;isError=$saved.isError}
 }
}
$entries | ConvertTo-Json -Depth 30 | Set-Content -LiteralPath work/070-call-index.json -Encoding utf8
$operation = (Get-Content -Raw work/030-definitions-operation-result.json | ConvertFrom-Json).stdout | ConvertFrom-Json -AsHashtable
$retry = (Get-Content -Raw work/031-identical-retry-result.json | ConvertFrom-Json).stdout | ConvertFrom-Json -AsHashtable
$comparison=[ordered]@{
 lookup_and_retry_semantically_identical=(($operation|ConvertTo-Json -Depth 100 -Compress) -ceq ($retry|ConvertTo-Json -Depth 100 -Compress))
 same_receipt=($operation.receipt_id -ceq $retry.receipt_id);same_request_digest=($operation.request_digest -ceq $retry.request_digest)
 same_versions=(($operation.versions|ConvertTo-Json -Compress -Depth 10) -ceq ($retry.versions|ConvertTo-Json -Compress -Depth 10))
 same_baseline=($operation.baseline_id -ceq $retry.baseline_id)
 same_affected_revisions=(($operation.affected_revision_ids|ConvertTo-Json -Compress) -ceq ($retry.affected_revision_ids|ConvertTo-Json -Compress))
 original_request='work/029-definitions-apply-request.json';retry_argv_reuses_original_request=$true;changed_request='work/032-changed-accepted-key-request.json'
}
$comparison | ConvertTo-Json -Depth 10 | Set-Content work/071-recovery-comparison.json -Encoding utf8
$entries | Where-Object kind -eq MCP | ConvertTo-Json -Depth 10
$comparison | ConvertTo-Json -Depth 10
