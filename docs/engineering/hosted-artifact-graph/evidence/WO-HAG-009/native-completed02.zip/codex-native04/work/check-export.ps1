$ErrorActionPreference = 'Stop'
function Trace-Hash([string]$Path,[string]$Trigger) {
  $item = Get-Item -LiteralPath $Path
  $hash = (Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256).Hash.ToLower()
  [ordered]@{path=$item.FullName;sha256=$hash;bytes=$item.Length;trigger=$Trigger} | ConvertTo-Json -Compress | Add-Content -LiteralPath work/read-trace.jsonl -Encoding utf8
  return $hash
}
$early = (. ./work/read.ps1 work/export-earlier/manifest.json 'Compare immutable export candidate bindings' | ConvertFrom-Json -AsHashtable)
$later = (. ./work/read.ps1 work/export-later/manifest.json 'Check final export exact bytes and candidate bindings' | ConvertFrom-Json -AsHashtable)
$checks = foreach ($path in ($later.snapshot.files.Keys | Sort-Object)) {
 $p = Join-Path work/export-later/files $path
 $hash = Trace-Hash $p 'Hash exported file against immutable snapshot manifest'
 $expected = $later.snapshot.files[$path]
 [ordered]@{path=$path;bytes=(Get-Item -LiteralPath $p).Length;expected_bytes=$expected.bytes;actual_sha256=$hash;expected_sha256=$expected.sha256;pass=($hash -eq $expected.sha256 -and (Get-Item -LiteralPath $p).Length -eq $expected.bytes)}
}
$history = foreach ($path in ($later.snapshot.files.Keys | Where-Object { $_ -like '*-900.md' } | Sort-Object)) {
 $original = Trace-Hash (Join-Path inputs/source $path) 'Verify immutable imported -900 history against tracked fixture bytes'
 [ordered]@{path=$path;source_sha256=$original;earlier_sha256=$early.snapshot.files[$path].sha256;later_sha256=$later.snapshot.files[$path].sha256;pass=($original -eq $early.snapshot.files[$path].sha256 -and $original -eq $later.snapshot.files[$path].sha256)}
}
$bundleHash = Trace-Hash work/export-later/history.bundle 'Verify later Git bundle hash without reconstructing Git'
$sourceHash = Trace-Hash inputs/source/src/greeting.py 'Verify source remained immutable after completed test'
$assertionHash = Trace-Hash work/003-greeting-assertion.json 'Compare original local assertion receipt with both exports'
$assertionPath = 'docs/engineering/lifecycle-pilot/evidence/WO-N04-001/assertion.json'
$candidateEqual = (($early.snapshot.candidates | ConvertTo-Json -Depth 50 -Compress) -ceq ($later.snapshot.candidates | ConvertTo-Json -Depth 50 -Compress))
$result = [ordered]@{
 schema='native04-export-integrity/v1';all_files_pass=(@($checks | Where-Object { -not $_.pass }).Count -eq 0);files=$checks
 bundle=[ordered]@{sha256=$bundleHash;bytes=(Get-Item work/export-later/history.bundle).Length;pass=($bundleHash -eq $later.snapshot.git_bundle.sha256 -and (Get-Item work/export-later/history.bundle).Length -eq $later.snapshot.git_bundle.bytes)}
 incomplete_marker=(Test-Path -LiteralPath work/export-later/.incomplete)
 source_sha256=$sourceHash;source_unchanged=($sourceHash -eq $early.snapshot.files['src/greeting.py'].sha256 -and $sourceHash -eq $later.snapshot.files['src/greeting.py'].sha256)
 imported_history=$history;imported_history_unchanged=(@($history | Where-Object {-not $_.pass}).Count -eq 0)
 assertion_sha256=$assertionHash;assertion_exact_in_both=($assertionHash -eq $early.snapshot.files[$assertionPath].sha256 -and $assertionHash -eq $later.snapshot.files[$assertionPath].sha256)
 candidate_bindings_identical=$candidateEqual;original_candidate=$later.snapshot.candidates[0].test_candidate
 earlier_head=$early.snapshot.head;later_head=$later.snapshot.head
 earlier_snapshot=$early.snapshot.snapshot_id;later_snapshot=$later.snapshot.snapshot_id
 independent_git_reconstruction_and_released_replay='not performed by native agent; retained for independent reviewer'
}
$result | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath work/069-later-export-check.json -Encoding utf8
$result | Select-Object all_files_pass,bundle,incomplete_marker,source_unchanged,imported_history_unchanged,assertion_exact_in_both,candidate_bindings_identical,original_candidate,earlier_head,later_head | ConvertTo-Json -Depth 5
