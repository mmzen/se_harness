+++
id = "SPEC-P3-001"
type = "specification"
title = "Greeting output contract"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
contract = "The greeting function returns the fixed string Hello rehearsal without side effects."

[relations]
specifies = ["REQ-P3-001"]
+++

# Greeting output contract

Synthetic qualification test. This is not a real human decision.

This specification governs the return value of the greeting function in the qualification fixture.

## Rule

**P3-GREET-001.** The function `greeting()` in `src/greeting.py` MUST return the string `Hello rehearsal`.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-001 | P3-GREET-001 |
