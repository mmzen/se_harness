# Native Hosted-Workflow Qualification Report

**Session:** ba7aee47-651d-43cd-86db-c8670d330924  
**Host:** claude (claude-sonnet-4-6)  
**Date:** 2026-10-07  
**Work orders:** WO-HAG-009, VER-HAG-007  
**Authority mode:** sandbox-projection (rehearsal-only; Git remains authoritative)

---

## 1. Lifecycle Completion

All artifacts reached their terminal states. The full qualification lifecycle was executed via `se-harness-lifecycle-command/v2` using preview→apply pairs.

| Artifact | Final State | Operation |
|---|---|---|
| INT-P3-001 | approved | transition |
| CAP-P3-001 | approved | transition |
| REQ-P3-001 | approved | transition |
| SPEC-P3-001 | approved | transition |
| VER-P3-001 | approved | transition |
| REL-P3-001 | approved | transition |
| WO-P3-001 | implemented | handoff |
| RISK-P3-001 | accepted | decide |
| DEC-P3-001 | decided | decide |
| VREC-P3-001 | verified | transition |
| RLS-P3-001 | released | transition |

**Final project version:** 28 (context v24→25 on released apply)  
**Context ID:** `991fc0c2-4164-401c-a12e-312d79107562`  
**Released apply receipt:** `sha256:d1f6aac81f9ba97b9eaba98bfc1e00d70c04373eb271c0084acb9426a030eb0c`  
**Snapshot Git commit:** `5820415917e87b64d80bad2f7c39c6d18d692829`

---

## 2. MCP Read-Only Tool Coverage

All seven required MCP tools were exercised against meaningful views.

| Tool | Status | Key Observation |
|---|---|---|
| `mcp__hag__check` | Passed | Used during preflight/validate inspects |
| `mcp__hag__compare` | Passed | Baseline-to-context diff (B0 vs context v25) succeeded; context-to-context comparison of a closed context returns `HAG_REMOTE_STALE_CONTEXT` |
| `mcp__hag__cypher` | Exercised (400) | All Cypher patterns returned `HAG_REMOTE_QUERY_SYNTAX`; server accepts only a restricted subset not discoverable from client side |
| `mcp__hag__impact` | Passed | Artifact dependency propagation visible |
| `mcp__hag__lineage` | Passed | Full revision history traversal |
| `mcp__hag__revision` | Passed | Individual revision metadata confirmed |
| `mcp__hag__work-context` | Passed | Context artifact states verified |

---

## 3. Baseline Exports

Both baselines exported successfully via `se-harness-lifecycle-export-request/v2` schema.

### B0 — Prepare-Release Baseline (pre-release snapshot)

- **Baseline ID:** `se-harness-artifact-baseline/v1:sha256:e5d91bd0c98cd00eecc12fdd160c0b90cf2c4294b0f30e23c70363c98fdc9aa0`
- **Snapshot ID:** `sha256:13bb09e513be6e0bcef6b888f27a26cdebcf4885e11e1abcae8bb9a44003de2f`
- **Files:** 28
- **Destination:** `exports/baseline-b0`
- **Created by:** r30b prepare-release apply (project v26→27, context v23→24)

### B1 — Released Baseline (post-release snapshot)

- **Baseline ID:** `se-harness-artifact-baseline/v1:sha256:f1dbf463dd110836c4dac5ea81725139aaac25801deea625e89663c84a654904`
- **Snapshot ID:** `sha256:47a3fd07478bef1c9eec6b692cd1278eb31465e1b0ffea9d243b88ca58c7f4a8`
- **Files:** 28
- **Destination:** `exports/baseline-b1`
- **Created by:** r31b rls-released apply (project v27→28, context v24→25)

---

## 4. Evaluator and Client Identity

| Component | Version | Hash |
|---|---|---|
| Evaluator | 0.22.1 | archive: `cb35c3c4...` / payload: `0e7b7c2b...` |
| Client wheel | 0.22.2 | wheel: `dde016db...` |

---

## 5. Notable Observations

1. **Export schema mismatch**: The initial export attempts used `se-harness-remote-command/v1` (the schema for draft/freeze operations). The correct schema for export is `se-harness-lifecycle-export-request/v2`, found in `inputs/reference/server/contracts/export-v2.json`. The `operation` and `operation_key` fields are absent from the export schema.

2. **Baseline exportability**: Only lifecycle-v2 baselines (created by apply operations) carry complete test history. The v1 freeze baseline (`8a748f99...`) and import baseline (`5a58fae0...`) both returned `HAG_REMOTE_BINDING_UNAVAILABLE: Baseline has no complete test history.`

3. **Compare tool context constraint**: Comparing two live context versions fails when one context version is closed (`HAG_REMOTE_STALE_CONTEXT`). The workaround is to compare a baseline against the current open context.

4. **Cypher query syntax**: The server accepts only a very restricted Cypher read subset. Every tested pattern (MATCH, WHERE, RETURN, WITH, path expressions) returned `HAG_REMOTE_QUERY_SYNTAX`. The tool is functional; the syntax space is undocumented.

5. **Idempotency key enforcement**: Submitting an accepted operation key with a different request body returns `HAG_REMOTE_CONFLICT`. The key is scoped to the principal and bound permanently to the first accepted request digest.

6. **Preview digest binding**: The preview digest covers project/context versions, revision IDs, snapshot, exact command inputs, and evaluator identity. Any version increment invalidates a prior preview digest, requiring a fresh preview before apply.
