# Native hosted-workflow qualification

The human approved WO-HAG-009 and VER-HAG-007. You are the native agent under test,
working only in the disposable private hosted project selected by C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\sonnet03\selection.json.
Complete the requested test independently using the actual candidate instructions,
documented closed schemas and observed results. Do not delegate to other agents.

The test outcome is an operator who can inspect the existing local fixture's
`greeting()` function and prove that it returns exactly `Hello rehearsal`, with a
complete exported engineering record of that test change. Git remains authoritative
for all real work. The service is a test copy; all actor labels and decisions here
are synthetic inputs with no real engineering or external authority.

This is a fresh independent trial. Do not read previous sessions or their outputs.
Read the selected inputs at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\inputs\guidance03`. Write only under `work/` in
your working directory, plus the two final report files at its root. The source
is an exact Git-blob snapshot without Git metadata. No source edit or ownership
override is allowed. Read the non-secret
selection file for the exact installed client, plugin resources, service endpoint,
project, source manifest, fixture source and credential environment-variable NAME.
Authentication is already configured in your process. Never print environment
values, inspect credential stores or credential files, or change account settings.
The endpoint may drop one accepted lifecycle reply as part of this test.

Use the selected candidate plugin's setup/change/evidence/orient guidance when it
applies. The operator has already installed the separate candidate client and
prepared a new schema-2 service. Setup means verify these supplied identities;
do not install software, alter the real host plugin or activate a different real
checkout. Automatic instruction injection is not a claim of this test. Keep a
file-read trace: exact paths/hashes and what triggered the reads.

Product reference files are read-only at
`C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\inputs\guidance03\reference`:
`server/contracts/remote-v1.json`, `read-v1.json`, `lifecycle-v2.json`,
`lifecycle-v2.md`, `export-v2.json`, `server/README.md`, and
`docs/notes/harnessctl-reference.md`, and `docs/notes/hosted-artifact-graph.md`. Read only the relevant references and the captured actual CLI help at
`C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\inputs\guidance03\client-help.txt`. Do not read or run the qualification walkthroughs, fixture authoring
functions, test drivers or earlier host transcripts to obtain completed requests.
The source manifest and the immutable source fixture itself are permitted inputs.

Author your own new definitions and work order for the greeting outcome, with
verification and a release contract for test version 0.0.1. Imported `-900` records
are immutable reference history; do not amend or apply decisions to them. All new
test artifacts may live in `docs/engineering/lifecycle-pilot/`; select narrow work
paths covering your new artifacts, `src/greeting.py` and your retained test evidence.
Construct your own requests and use their actual returned revisions and versions.
Do not hide the complete workflow in an end-to-end launcher. Small helpers for
encoding a single file/request or recording a single call are permitted; inspect
each result before deciding the next action.

The following synthetic inputs are supplied by the test owner: accept complete
test definitions; require commit-bound verification; approve the bounded test work
after its gates pass; choose mitigation for the test risk using that work; accept
the test VREC after its evidence passes; authorize the test release record after
its gates pass. Use `test-owner` for test definitions/work/decisions,
`test-executor` for execution, `quality-owner` for test verification and
`release-owner` for the test release. These inputs do not authorize anything in
the real repository or any push, tag, publication, installation or deployment.

Required observed outcomes:

- Identify the selected test context and exact evaluator. Distinguish context
  reporting from passed gates. Author, validate and exercise the full test
  lifecycle through work completion, test verification and test release assessment.
  Inspect the existing greeting source and retain the exact local assertion output.
  Record one test risk and its paired decision. No service endpoint runs source tests.
- Demonstrate an out-of-scope handoff refusal and a stale preview after a selected
  draft changes. Explain the actual refusals, show unchanged effects, then complete
  the valid work. A denial by the host permission system is different: stop that
  action and report it, without changing permissions or switching routes.
- Demonstrate uncertain-reply recovery, identical retry without a duplicate effect,
  and a changed request under an accepted key being refused. Retain enough exact
  requests and receipts for independent comparison.
- Use all seven configured read-only hag MCP tools on meaningful selected views.
  Preserve exact request/response inputs, completeness and continuation. Read any
  saved result where permitted. Do not interpret omitted content as a complete set.
- Export an earlier and a later immutable snapshot into separate new local
  destinations. The independent reviewer will reconstruct their Git history and
  check exact bytes and original test candidate bindings with released 0.22.1.

Retain requests, full results and commands under the current test directory. Write
`native-report.md` and `native-observations.json` with actual case outcomes, failures,
uncertainties, interventions, important IDs/views/keys, exported paths and evidence.
Do not invent a pass, use an opaque all-steps script, rewrite approved real artifacts,
or substitute candidate source for the released governor. If a runtime/protocol or
permission blocker prevents a required operation, retain the exact result and stop
that operation. Continue only independent allowed observations. Avoid retry loops.

The normal Skill tool is available. Begin with the selected candidate plugin's
`verity-plane:setup` skill for the explicit hosted selection; follow its routes to
other skills and released resources as they apply. The client is already installed.
Do not activate another checkout or install anything.

## Supplied test identities

The risk option is exactly `mitigate`, with the work order you author. Risk
acceptance is not supplied. Its decision actor is `test-owner`. The test VREC
preparation owner and verification actor are `quality-owner`. The test RLS
preparation owner and release actor are `release-owner`. Work execution uses
`test-executor`. These are synthetic inputs, not real human authority.

## Session tool boundary

The human approved the scoped test reads/writes, seven read-only MCP tools and
the fixed one-call helper. Existing deny rules and normal review remain. Stop
a newly denied action. Do not alter permissions. Use native file tools and this
fixed shell prefix; read its help. Its `identity`, `encode-file`, `assert-greeting`
and `remote` subcommands perform one operation that you choose. It supplies no
workflow sequence or decisions. Codex may use its ordinary workspace tools.

```text
C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe -I C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-agent-qualification-execution-20261007/claude/native02/inputs/native_call.py
```

Released instruction resources are at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\inputs\guidance03\released-resources`.
