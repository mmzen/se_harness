+++
id = "REL-P3-901"
type = "release_contract"
title = "Test release record for version 0.0.1"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
candidate_commit = "5820415917e87b64d80bad2f7c39c6d18d692829"
previous_release_tag = "none"

[relations]
gates = ["WO-P3-901"]
+++

# Test release record for version 0.0.1

Synthetic rehearsal input. This is not a real human decision.

Test version 0.0.1 binds this work and its verified test candidate at commit 5820415917e87b64d80bad2f7c39c6d18d692829. No tags, publication or deployment. Discard the disposable test project if replay fails. Retain the verification record and exact evidence.
