+++
id = "REQ-P3-901"
type = "requirement"
title = "greeting() returns exactly Hello rehearsal"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
statement = "Calling greeting() returns the string Hello rehearsal."
measure = "Exact string equality: result == 'Hello rehearsal'"
source = "Phase 3 qualification fixture"
verification_method = ["test"]
priority = "must"

[relations]
derives_from = ["CAP-P3-901"]
+++

# greeting() returns exactly Hello rehearsal

Synthetic rehearsal input. This is not a real human decision.

## Trigger

Always: every call to greeting() on the fixture module.

## Fallback

If the call fails or returns a different value, the assertion fails and the qualification halts.

## Acceptance

The caller can check: `assert greeting() == 'Hello rehearsal'`.
