+++
id = "SPEC-P3-901"
type = "specification"
title = "greeting() fixture specification"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
contract = "Return the fixed string Hello rehearsal without external effects."

[relations]
specifies = ["REQ-P3-901"]
+++

# greeting() fixture specification

Synthetic rehearsal input. This is not a real human decision.

This specification governs the src/greeting.py fixture function. It leaves runtime environment, import machinery and all other functions to other artifacts.

## Scope

The module src/greeting.py exposes one function: greeting().

## Definitions

greeting: the callable defined in src/greeting.py that returns a fixed string.

## Rules

**P3-GREET-901.** The implementation MUST return the string `Hello rehearsal` on every call.

**P3-GREET-901-NEG.** The implementation MUST NOT return any other string or raise an exception.

## State

State: no module-level mutable state. Event: call greeting(). Response: the string `Hello rehearsal`.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-901 | P3-GREET-901 |
