+++
id = "WO-P3-901"
type = "work_order"
title = "Assert and record the exact greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"

[assurance]
commit_bound_verification = "required"
rationale = "Synthetic fixture decision for Phase 3 test assurance."
decided_by = "test-owner"

[execution_scope]
paths = ["src/greeting.py", "docs/engineering/lifecycle-pilot/"]

[relations]
implements = ["REQ-P3-901"]
specifications = ["SPEC-P3-901"]
verification = ["VER-P3-901"]
+++

# Assert and record the exact greeting

Synthetic rehearsal input. This is not a real human decision.

## Objective

Assert greeting() returns exactly Hello rehearsal and retain the assertion evidence.

## In scope

Only the synthetic fixture src/greeting.py, pilot definitions and test evidence under docs/engineering/lifecycle-pilot/.

## Out of scope

Real engineering records, real human decisions and external actions.

## Authorized decision envelope

All supplied actors are synthetic test labels.

## Required verification

Run VER-P3-901 on the exact clean fixture commit.

## Stop conditions

Stop when the released evaluator refuses.

## Completion

Retain actual assertion outputs, candidate identity and exported snapshots.
