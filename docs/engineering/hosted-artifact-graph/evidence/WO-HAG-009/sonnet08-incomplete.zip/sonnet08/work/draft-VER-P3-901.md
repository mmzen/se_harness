+++
id = "VER-P3-901"
type = "verification"
title = "Assert greeting() returns Hello rehearsal"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"

[relations]
verifies = ["REQ-P3-901"]
+++

# Assert greeting() returns Hello rehearsal

Synthetic rehearsal input. This is not a real human decision.

## Independence

Expected text is fixed by REQ-P3-901, not candidate output. The assertion is a direct Python import check with no external oracle.

## Requirement-to-evidence matrix

| Requirement | Method | Case | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-901 | test | exact greeting assertion | Equals Hello rehearsal |

Retain the actual assertion result in docs/engineering/lifecycle-pilot/evidence/WO-P3-901/assertion.json.
