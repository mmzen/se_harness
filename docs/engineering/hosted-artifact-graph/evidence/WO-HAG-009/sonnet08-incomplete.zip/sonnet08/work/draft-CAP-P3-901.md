+++
id = "CAP-P3-901"
type = "capability"
title = "Assert the exact greeting string"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
ability = "Assert that greeting() returns exactly Hello rehearsal."

[relations]
derives_from = ["INT-P3-901"]
+++

# Assert the exact greeting string

Synthetic rehearsal input. This is not a real human decision.

The operator can assert the greeting fixture returns the exact expected string using a direct Python import assertion.
