"""Publish only bounded diagnostic evidence to the existing unfinished-work PR."""
import base64,hashlib,json,subprocess,sys,tomllib,zipfile
import hag_efficiency_plan as p
W,R,D=p.W,p.R,p.D;O=W/'hag-hosted-next28-20261011';p.O=O
E=D/'evidence/WO-HAG-009/diagnostic28'
C='dfcf1e976123836f00354a228c8e72a833f2e3cf';PRE='dd1c4730e7b4973fae87bc0a6b1c9a871f1219c7'
BASE='55caaada508495bea7d97effd27644d1ce8373da';BRANCH='codex/hosted-agent-qualification'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=R,encoding='utf-8').strip()
def put(f,x):
 assert not f.exists(),f
 f.write_bytes((x if isinstance(x,str) else json.dumps(x,indent=2)+'\n').encode())
def unpack(f):
 x=load(f);return json.loads(x['stdout']) if 'stdout' in x else x
def url(head):return f'https://github.com/mmzen/se_harness/blob/{head}/{(E/"assessment.md").relative_to(R).as_posix()}'
mode=sys.argv[1]
if mode=='checks':
 changed=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
 assert all(x==(D/'README.md').relative_to(R).as_posix() or x.startswith(E.relative_to(R).as_posix()+'/') for x in changed),changed
 # Include the two forthcoming review-check retention files in declared scope.
 changed+= [(E/n).relative_to(R).as_posix() for n in ['report-checks.zip','report-checks-inventory.json']]
 args=['check',R,'--artifact','WO-HAG-009','--checkpoint','scope','--changes-complete']
 for x in changed:args+=['--changed-path',x]
 x=p.gov('report28-scope',*args,'--json');assert x['compliance']['status']=='pass'
 x=p.gov('report28-preflight','preflight',R,'--work-order','WO-HAG-009','--phase','review','--json');assert x['ready']
 x=p.gov('report28-validation','validate',R,'--json');assert x['error_count']==0
 print(json.dumps({'scope':'pass','preflight':'ready','validation':{k:x[k] for k in ['artifact_count','error_count','warning_count']}}))
elif mode=='commit':
 assert git('rev-parse','HEAD')==C and git('branch','--show-current')==BRANCH
 names=['report28-scope','report28-preflight','report28-validation']
 assert all(load(O/(n+'.json'))['exit']==0 for n in names)
 with zipfile.ZipFile(E/'report-checks.zip','x',zipfile.ZIP_DEFLATED) as z:
  for n in names:z.write(O/(n+'.json'),n+'.json')
 put(E/'report-checks-inventory.json',{'archive':'report-checks.zip','sha256':sha((E/'report-checks.zip').read_bytes()),'files':[{'path':n+'.json','sha256':sha((O/(n+'.json')).read_bytes())} for n in names]})
 for index in E.glob('*-inventory.json'):
  i=load(index)
  with zipfile.ZipFile(E/i['archive']) as z:
   assert sha((E/i['archive']).read_bytes())==i['sha256']
   assert all(sha(z.read(f['path']))==f['sha256'] for f in i['files'])
 changes=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
 scope=tomllib.loads((D/'work-orders/WO-HAG-009.md').read_text().split('+++')[1])['execution_scope']['paths']
 assert all(any(x==s or s.endswith('/') and x.startswith(s) for s in scope) for x in changes)
 assert all(x==(D/'README.md').relative_to(R).as_posix() or x.startswith(E.relative_to(R).as_posix()+'/') for x in changes)
 p.run('report28-diff-check',['git','diff','--check'],cwd=R)
 p.run('report28-stage',['git','add','--',*changes],cwd=R)
 p.run('report28-staged-check',['git','diff','--cached','--check'],cwd=R)
 p.run('report28-commit',['git','commit','-m','Retain focused Claude hosted lifecycle diagnostic and limitations','-m','Harness-Work-Order: WO-HAG-009'],cwd=R)
 head=git('rev-parse','HEAD');assert not git('status','--porcelain')
 assert not git('diff','--name-only',C,head,'--','se_harness','tests','plugins','server','templates','repository_tools','pyproject.toml')
 put(O/'evidence-commit28.json',{'head':head,'candidate':C,'base':BASE,'report':url(head)})
 print(json.dumps(load(O/'evidence-commit28.json')))
elif mode=='publish':
 head=load(O/'evidence-commit28.json')['head'];assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
 before=unpack(O/'pr-before-28.json');assert before['headRefOid']==PRE and before['isDraft'] and before['baseRefName']=='main'
 body=before['body'].replace('\r\n','\n');assert 'Harness-Work-Orders: WO-HAG-009, WO-HAG-010, WO-HAG-011' in body
 note=(O/'pr-note28.md').read_text().replace('REPORT_URL',url(head)).replace('REVIEW_HEAD',head)
 body=body.replace('## Latest result\n',note+'\n## Previous full qualification result\n',1)
 assert note in body
 put(O/'pr-body28.md',body)
 put(O/'pr-event28.json',{'pull_request':{'body':body,'head':{'sha':head,'ref':BRANCH},'base':{'sha':BASE,'ref':'main'}}})
 p.gov('check-pr28','check-pr',R,'--event',O/'pr-event28.json','--from-git',BASE,'--json',allowed=(0,1,2))
 check=load(O/'check-pr28.json');assert check['exit']==2 and not check['stdout'] and len(check['stderr'].splitlines())==1 and 'WO-HAG-009: QGP-G4I-EVIDENCE:' in check['stderr'],check
 rules=p.run('main-controls28',['gh','api','repos/mmzen/se_harness/rulesets/20693381'])
 assert rules['enforcement']=='active' and any(x['type']=='pull_request' for x in rules['rules'])
 assert any(x['type']=='required_status_checks' and any(y['context']=='validate' for y in x['parameters']['required_status_checks']) for x in rules['rules'])
 assert p.run('source-controls28',['gh','api','repos/mmzen/se_harness/rules/branches/codex%2Fhosted-agent-qualification'])==[]
 args=['gh','pr','view','543','--repo','mmzen/se_harness','--json','url,state,isDraft,headRefName,headRefOid,baseRefName,body,statusCheckRollup']
 now=p.run('write-guard28',args)
 assert now['state']=='OPEN' and now['isDraft'] and now['baseRefName']=='main' and now['headRefName']==BRANCH and now['headRefOid']==PRE and now['body']==before['body']
 p.run('push28',['git','push','origin',f'{head}:refs/heads/{BRANCH}'],cwd=R)
 p.run('pr-edit28',['gh','pr','edit','543','--repo','mmzen/se_harness','--body-file',O/'pr-body28.md'])
 now=p.run('published-readback28',args)
 assert now['headRefOid']==head and now['isDraft'] and now['baseRefName']=='main' and now['body'].replace('\r\n','\n')==body
 path=(E/'assessment.md').relative_to(R).as_posix()
 remote=p.run('report-readback28',['gh','api',f'repos/mmzen/se_harness/contents/{path}?ref={head}'])
 assert base64.b64decode(remote['content'])==(E/'assessment.md').read_bytes()
 print(json.dumps({'pr':now['url'],'head':head,'report':url(head),'draft':True}))
else:raise ValueError(mode)
