"""Retain bounded visible evidence after the diagnostic finishes."""
from pathlib import Path
import sys
W=Path(__file__).parent
source=(W/'hag_retain36.py').read_text().replace('hag-procedure36-20261011','hag-digest39-20261012').replace('WO-HAG-009/procedure36-result','WO-HAG-009/digest39-result')
source=source.replace("names=['initial-status.json'","names=['approval-reading-order.json','digest-guard-review.json','initial-status.json'")
source=source.replace('replay36','replay39').replace('native-parity-*36','native-parity-*39')
sys.argv=[__file__,'claude-351']
exec(compile(source,'digest39-retention','exec'),{'__file__':str(W/'hag_retain36.py'),'__name__':'__main__'})
