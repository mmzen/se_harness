"""Reuse exact C38 packages for a narrower, unassisted native guard diagnostic."""
import hashlib,json,subprocess,sys
from pathlib import Path
import hag_efficiency_plan as p
W=p.W;O=W/'hag-digest39-20261012';P=W/'hag-authority38-20261012'
C='ee86a842550c19fb6a56913841757b42df9ecaec';REVIEW='fabfdebae48e10b3fadbb2833e9a8bb30115e15b'
trial='351';root=O/('claude-'+trial);native=root/'native';mode=sys.argv[1]
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
    assert not f.exists(),f
    f.write_bytes((v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=p.R).decode().strip()==REVIEW
assert not subprocess.check_output(['git','status','--porcelain'],cwd=p.R).decode().strip()
assert not subprocess.check_output(['git','diff','--name-only',C,REVIEW,'--','se_harness','tests','plugins','server','templates','pyproject.toml','repository_tools','release'],cwd=p.R).decode().strip()
assert load(P/'candidate-38.json')['commit']==C
if mode=='proof':
    old=P/'claude-341';previous=old/'native';selection=load(root/'native-selection.json')
    inv=load(native/'inputs/inventory.json')['files']
    assert all(sha(Path(x['path']).read_bytes())==x['sha256'] for x in inv)
    def normalized(raw,n):return raw.replace(str(n),'<NATIVE>').replace(n.as_posix(),'<NATIVE>').replace(n.as_posix().replace('C:','//c'),'<NATIVE>')
    assert normalized(json.dumps(load(root/'permissions.json')),native)==normalized(json.dumps(load(old/'permissions.json')),previous)
    for f in ('native_call.py','summarize_native.py'):
        assert (native/'inputs'/f).read_bytes()==subprocess.check_output(['git','show',C+':tests/hosted_artifact_graph/'+f],cwd=p.R)
    assert selection['qualification_candidate']==C
    assert load(P/'package-guidance-comparison.json')['candidate']==C
    put(O/'diagnostic-scope.json',{
      'candidate':C,'review_head':REVIEW,'trial':'claude-351','previous_trial':'claude-341',
      'model':'claude-opus-5-5','cli':'2.1.280','task':'Focused preview-digest refusal and recovery; no work start or handoff',
      'task_sha256':sha((root/'native-task.md').read_bytes()),'same_permissions_except_paths':True,
      'packages_reused_from':str(P),'package_comparison_sha256':sha((P/'package-guidance-comparison.json').read_bytes()),
      'service_comparison_sha256':sha((P/'service-reuse-comparison.json').read_bytes()),'staged_input_count':len(inv),
      'product_changes_since_candidate':[],
      'limits':'Different narrower task; no full NQ pass or comparison of completion time. Native agent chooses content and requests. No corrective operation sequence or completed artifact supplied.'})
    print('Exact candidate package reuse and unchanged permission boundary confirmed')
    raise SystemExit(0)
source=(W/'hag_full27.py').read_text()
source=source.replace('hag-lifecycle-native27-20261010','hag-digest39-20261012').replace('hag-lifecycle-correction27-20261010','hag-authority38-20261012')
source=source.replace("trial='221'","trial='351'")
for a,b in [('candidate-27','candidate-38'),('package27','package38')]:source=source.replace(a,b)
source=source.replace("==load(PREV/'candidate-38.json')['commit']","=='"+REVIEW+"'")
nested="(W/'hag_native27.py').read_text()"
replacement=nested+".replace('hag-lifecycle-native27-20261010','hag-digest39-20261012').replace('hag-lifecycle-correction27-20261010','hag-authority38-20261012').replace('package27','package38').replace('client27','client38').replace('build27','build38').replace('native-lifecycle27','native-authority38').replace('hag-full27-','hag-digest39-').replace('10.231.84.0/22','10.231.104.0/22')"
source=source.replace(nested,replacement)
source=source.replace('claude-opus-4-6','claude-opus-5-5').replace(r'C:\Users\mathi\.local\bin\claude.exe',str(W/'hag-opus55-availability-20261011/claude-2.1.280.exe'))
source=source.replace(",'--drop-reply'",'').replace("'--timeout','1800'","'--timeout','1200'")
sys.argv=[__file__,mode,'claude']
exec(compile(source,'digest39-native','exec'),{'__file__':str(W/'hag_full27.py'),'__name__':'__main__'})
if mode=='stage':
    from qualify_agents import shell_prefix
    selection=load(root/'native-selection.json')
    task=(W/'hag_digest39_task.txt').read_text().replace('NATIVE_ROOT',str(native)).replace('APPROVED_HELPER_PREFIX',shell_prefix(selection['approved_shell_argv_prefix']))
    (root/'native-task.md').write_bytes(task.encode())
    proof=load(root/'stage-evidence.json');proof.update(case='Focused preview-digest subset of NQ-03; not full lifecycle qualification',task_sha256=sha(task.encode()),review_head=REVIEW,limits='Fresh private project; exact existing candidate and permissions. Narrower task, no comparable timing or full qualification claim. Agent chooses artifact content and operations; no supplied request or mutation sequence.')
    (root/'stage-evidence.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
    print('Focused preview-digest task staged')
