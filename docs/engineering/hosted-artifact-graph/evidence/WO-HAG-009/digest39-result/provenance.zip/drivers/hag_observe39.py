"""Read-only observers for the focused digest diagnostic."""
from pathlib import Path
import sys
W=Path(__file__).parent;mode=sys.argv[1]
if mode in ('watch','trace','parity'):
    name={'watch':'hag_watch36.py','trace':'hag_trace36.py','parity':'hag_parity36.py'}[mode]
    sys.argv=[__file__,'claude-351' if mode=='trace' else '351']
elif mode in ('observe','replay','stop'):
    name='hag_review36.py';sys.argv=[__file__,'claude-351',mode]
elif mode=='facts':name='hag_full36_facts.py'
elif mode in ('audit','refusals'):name='hag_assess36.py'
else:raise ValueError(mode)
source=(W/name).read_text().replace('hag-procedure36-20261011','hag-digest39-20261012').replace('claude-311','claude-351')
for a,b in [('diagnostic36','diagnostic39'),('replay36','replay39'),('native-procedure36','native-authority38')]:source=source.replace(a,b)
source=source.replace("O/'package36/candidate-source/server/compose.yaml'","W/'hag-authority38-20261012/package38/candidate-source/server/compose.yaml'")
exec(compile(source,'digest39-'+mode,'exec'),{'__file__':str(W/name),'__name__':'__main__'})
