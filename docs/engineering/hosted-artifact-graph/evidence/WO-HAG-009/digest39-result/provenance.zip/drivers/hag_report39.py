"""Independent assessment of the focused native digest-guard observation."""
import hashlib,json
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'hag-digest39-20261012';r=O/'claude-351';w=r/'native/work';E=p.D/'evidence/WO-HAG-009/digest39-result'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
    assert not f.exists(),f
    f.parent.mkdir(parents=True,exist_ok=True)
    f.write_bytes((v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
facts=load(r/'review-facts.json');metrics=load(O/'claude-351-summary.json');replay=load(r/'replay39/assessment.json')
audit=load(r/'output-boundary-audit.json');order=load(r/'approval-reading-order.json');scope=load(O/'diagnostic-scope.json')
assert not facts['session']['timed_out'] and metrics['native_calls']==62 and metrics['peak_input_context']==177692
assert len(metrics['native_failures'])==5
assert len([x for x in facts['lifecycle_results'] if x['outcome']=='accepted'])==1
assert len(replay['cases'])==1 and replay['cases'][0]['outcome']=='passed'
assert replay['cases'][0]['file_effects']==['docs/engineering/lifecycle-pilot/intent/INT-P3-001.md']
assert order['read_before_first_approval_request'] and order['first_approval_request_event']==210
assert audit['monitored_repository_and_host_settings_equal'] and audit['staged_input_integrity']['all_unchanged'] and not audit['writes_outside_work']
assert (w/'native-report.md').exists() and (w/'native-observations.json').exists()
first=load(w/'07-preview1.stdout.txt');first_request=load(w/'req-07-preview1.json')
revision=load(w/'08-revise-r2.stdout.txt')['result'];stale_request=load(w/'req-09-apply-stale.json');stale=load(w/'09-apply-stale.stdout.txt')
fresh=load(w/'12-preview2.stdout.txt');fresh_request=load(w/'req-12-preview2.json');apply_request=load(w/'req-13-apply2.json');applied=load(w/'13-apply2.stdout.txt')
assert revision['versions']['project']=={'before':4,'after':5}
assert revision['versions']['context']['before']==2 and revision['versions']['context']['after']==3
assert stale_request['expected_project_version']==5 and stale_request['expected_context_version']==3
assert stale_request['preview_digest']==first['preview_digest'] and stale_request['action']==first_request['action']
assert stale['error']['code']=='HAG_REMOTE_STALE_PREVIEW' and stale['outcome']=='refused' and stale['http_status']==409
assert not stale['receipt_id'] and not stale['affected_artifacts'] and not stale['files']
assert load(w/'10-status-after-refusal.stdout.txt')['project_version']==5
assert apply_request['action']==fresh_request['action'] and apply_request['preview_digest']==fresh['preview_digest']!=first['preview_digest']
assert applied['outcome']=='accepted' and applied['versions']['project']=={'before':5,'after':6}
assert applied['versions']['context']['before']==3 and applied['versions']['context']['after']==4
assert load(r/'independent-final-status.json')['project_version']==6
parity=[load(f) for f in sorted((O/'native-parity-diagnostic39').glob('*.json'))]
assert len(parity)==3 and all(x['exact_match'] and x['http_status']==200 and x['native_result']['complete'] for x in parity)
assert [x['native_result']['observed_project_version'] for x in parity]==[4,5,6]
after_refusal=parity[1]['native_result'];after_apply=parity[2]['native_result']
assert after_refusal['data']['rows'][0]==['INT-P3-001',revision['affected_revision_ids'][0],'intent','draft',3]
assert after_apply['data']['rows'][0]==['INT-P3-001',applied['affected_revision_ids'][0],'intent','approved',4]
receipts=load(r/'refused-request-receipts.json');assert len(receipts)==1 and receipts[0]['status']==404 and receipts[0]['operation_key']==stale_request['operation_key']
source=r/'native/inputs/source';projection=r/'replay39/000-transition/repository'
imports=list(source.glob('docs/engineering/lifecycle-pilot/**/*900.md'))
assert len(imports)==7 and all((projection/f.relative_to(source)).read_bytes()==f.read_bytes() for f in imports)
guard={'outcome':'passed for focused native preview-digest refusal and recovery',
 'first_preview_digest':first['preview_digest'],'amended_revision':revision['affected_revision_ids'][0],
 'stale_apply_uses_current_versions':{'project':5,'context':3},'stale_apply_keeps_original_action':True,
 'refusal':stale['error'],'refused_operation_lookup_status':404,'unchanged_after_refusal':{'project':5,'context':3,'state':'draft','revision':revision['affected_revision_ids'][0]},
 'fresh_preview_digest':fresh['preview_digest'],'accepted_receipt':applied['receipt_id'],'accepted_versions':applied['versions'],
 'released_replay':'one accepted approval passed; only INT-P3-001 file changed',
 'imported_records_preserved':7,
 'limit':'The digest binds revisions, versions and other inputs together. This proves the digest guard was reached after a content change, with current request versions. It does not isolate individual components inside the digest or complete full native qualification.'}
put(r/'digest-guard-review.json',guard)
claims={
 'content':'The agent authored one intent from the explicit greeting outcome and existing fixture. It acknowledges INT-P3-900, states a not-measured baseline and makes no assertion-run claim. The amendment adds the task-matching source/text-change exclusion. Imported records are draft and remain exact.',
 'reading':'Delegation section returned successfully at event47 before first approval request at event210. This verifies the targeted read and its ordering, not universal comprehension or full instruction compliance.',
 'report':'Native report correctly distinguishes digest guard from version guard and discloses that the digest internally binds both versions and content. Its Cypher transcriptions are not used as independent proof; exact native/HTTP results are retained.',
 'identity':'Exact qualification candidate C is ee86a842550c19fb6a56913841757b42df9ecaec. Native report names it correctly but later calls implementation candidate C not applicable because no new source implementation occurred. This is inconsistent terminology; no candidate P capture occurred.',
 'errors':'Four avoidable helper failures: one unsupported instruction selector and three JSON-pointer quoting errors. One intended stale-preview refusal. First preview also contained a redundant reason prefix; the stale apply preserved that action and the fresh preview/apply corrected it.',
 'no_new_requirement':'No further one-component-at-a-time digest isolation is claimed or added as an approval requirement. Existing full NQ-01..05, Opus4.6 authoring cases and paired-host obligations remain unchanged.',
 'interventions':'No supplied corrective commands, artifact text, operation sequence or operator graph writes during the native run. Independent HTTP reads only. This task explicitly names the digest-guard outcome and is narrower than earlier greeting-workflow diagnostics.'}
put(r/'claim-audit.json',claims)
put(r/'independent-assessment.json',{'candidate':scope['candidate'],'trial':'claude-351','outcome':guard['outcome'],'guard':guard,'claims':claims,'metrics':{k:metrics[k] for k in ['wall_seconds','native_calls','peak_input_context','model_turns']},'failed_tool_items':5,'parity':facts['parity'],'reading_order':order,'boundaries':{'all_120_inputs_unchanged':True,'writes_inside_work':11,'command_captures':11,'monitored_repository_and_settings_unchanged':True},'full_qualification':'pending','actual_assurance_decision':False})
put(E/'assessment.md',f'''# Native preview-digest refusal and recovery

**The focused diagnostic passed.** Claude sent an old approval-preview digest
with the current project and context versions. The service returned
`HAG_REMOTE_STALE_PREVIEW`, committed no effect, then accepted one approval
after a fresh preview. Independent released-evaluator replay passed.

Candidate: `{scope['candidate']}`. Trial: `claude-351`.
Model: Opus 5.5. Pinned CLI: 2.1.280. Service evaluator: released 0.22.1.
Client: 0.22.2. Session-local plugin guidance: 0.2.7.

## What this run covers

This is a narrower NQ-03 diagnostic on the same exact candidate and packages as
[Claude341](../authority38-result/assessment.md). It asks for the previously
missing digest-guard observation and recovery. It does not repeat the greeting
workflow or change a qualification criterion. No product source or instruction
file changed, and no package was rebuilt.

A fresh private project started empty. Claude chose to author one new intent,
INT-P3-001, with content based on the supplied greeting outcome. It selected its
own commands, amendment and query. The amendment added the task's exclusion of
source and greeting-text changes. No completed artifact or command sequence was
supplied. Decisions used only the synthetic test-owner identity.

## Evidence of the guard and recovery

| Observation | Independent result |
| --- | --- |
| Initial approval preview | Project 4 / context 2, selected original draft; digest D1 returned |
| Draft amendment | New revision; project 5 / context 3 |
| Stale apply | Same action and D1, but current expected versions 5 / 3 |
| Actual refusal | HTTP 409, `HAG_REMOTE_STALE_PREVIEW`; no receipt, files or affected revisions |
| State after refusal | Project 5 / context 3; amended revision still draft; rejected operation lookup returns 404 |
| Recovery | Fresh preview D2; one accepted apply advances project 5→6, context 3→4, intent draft→approved |
| Independent replay | Released 0.22.1 replay passed; only INT-P3-001 changed |
| Imported history | All seven -900 records match the source bytes in the independent projection |
| Cypher | Three complete native responses exactly match separate HTTP reads at project versions 4, 5 and 6 |
| Approval reading | Delegation section successfully read at event 47; first approval request at event 210 |
| Boundaries | All 120 inputs unchanged; 11 observed Write/Edit requests inside work/; repository and monitored host settings unchanged |

The prior run reached the earlier version guard. This run reaches the digest
guard. The digest itself binds revisions, versions and other inputs together;
this observation does not isolate each internal component. That is an explicit
limit, not a newly added qualification requirement. The native report states it
correctly. Its transcribed Cypher files are supplemented by exact captured
native responses and independent HTTP replies.

## Costs and remaining imperfections

Native duration was **7m39s (458.664 seconds)**, with **62 tool calls** and
**177,692 peak input-context tokens**. This includes import, one draft, amendment,
preview/refusal/recovery and reporting. It includes no greeting assertion or new
source implementation. Independent replay, setup and assessment are separate.
The narrower task is not comparable to the previous full greeting diagnostic;
these numbers do not establish a performance improvement.

Five failed tool items are retained: one unsupported instruction selector,
three JSON-pointer quoting errors and the intended stale-preview refusal.
The first preview also contained a doubled artifact prefix in its reason.
Claude preserved that action for the stale test, then corrected the reason in
the fresh preview/apply. There were no observed permission denials or operator
corrections during the run.

The report identifies the qualification candidate correctly but elsewhere calls
implementation candidate C inapplicable because it made no source implementation.
The actual C is the exact candidate above; no test candidate P was captured.
This wording issue remains disclosed. Source inspection supports the new intent
content, but the native agent's own review is not independent assurance.

## Checks, state and next work

The candidate's previous 1,339-test source suite (24 reported skips), focused
checks, distribution/smoke checks and exact package build remain applicable:
no product bytes changed. Package and helper identity, permissions and staged
input hashes were checked before this run. Live authentication passed. Evidence
scope, preflight and released validation are retained with this report.

At the preceding PR head `fabfdeba`, technical checks passed and three conditional
release rehearsals were skipped. The harness CI failure is the existing
WO-HAG-009 `QGP-G4I-EVIDENCE` blocker for unfinished qualification. New-head CI
is reported separately. PR #543 remains draft, targeting main, with the original
complete comparison base.

The specific missing digest-guard diagnostic is now closed. Continue the remaining
native qualification under VER-HAG-007/008; full NQ-01 through NQ-05 for both hosts
and required Opus 4.6 authoring cases remain pending. No criterion was relaxed.
Broad performance work remains deferred.

Actual WO-HAG-009/011 remain `in_progress` at
`PROC-WO-IMPLEMENT / STEP-WO-IMPLEMENT-CHECK`. The test intent's approval does
not advance real work or provide human verification. No actual VREC, merge,
release, deployment, host update or risk acceptance occurs. Git remains
authoritative. Only the exact disposable test containers were stopped; volumes
are preserved.

## Retained evidence

- [Visible transcript](claude-351-visible.md).
- [Native inventory](claude-351-inventory.json) and [archive](claude-351-evidence.zip):
  exact requests, results, draft revisions, native report, guard review, read
  ordering, independent replay, refusal lookup, parity and boundaries.
- [Provenance inventory](provenance-inventory.json) and [archive](provenance.zip):
  task, preparation/observer sources, fresh identities and exact package reuse.
- [Report checks](report-checks.zip) and [inventory](report-checks-inventory.json).

Private reasoning, provider/account logs, credentials and executables are omitted.
Earlier evidence and its verdicts remain unchanged.
''')
f=p.D/'README.md';s=f.read_text();a=s.index('## Latest functional qualification');b=s.index('## Previous paired functional qualification',a)
s=s[:a]+'''## Latest functional qualification

The [focused preview-digest diagnostic](evidence/WO-HAG-009/digest39-result/assessment.md)
uses the unchanged candidate `ee86a842550c19fb6a56913841757b42df9ecaec` with Opus 5.5.
Claude reached the stale-preview digest guard with current versions, confirmed
no effect and recovered to one accepted approval. Independent replay and all
three Cypher/HTTP comparisons passed. The specific missing diagnostic is closed.
Full paired-host qualification and required Opus 4.6 cases remain pending.
PR #543 stays draft.

This narrower task took 7:39, 62 calls and 177,692 peak input-context tokens.
It is not a comparable performance sample. The [prior authority-reading run](evidence/WO-HAG-009/authority38-result/assessment.md),
[scope/planning run](evidence/WO-HAG-009/scope37-result/assessment.md),
[earlier Opus 5.5 comparison](evidence/WO-HAG-009/opus55-comparison/assessment.md)
and [Opus 4.6 entry-condition assessment](evidence/WO-HAG-009/procedure36-result/assessment.md)
retain their original results. Criteria are unchanged; broad performance work
remains deferred.

'''+s[b:];f.write_bytes(s.encode())
put(O/'pr-note39.md','''Harness-Work-Orders: WO-HAG-009, WO-HAG-010, WO-HAG-011

## Current result

[Focused preview-digest diagnostic](REPORT_URL), candidate ee86a842550c19fb6a56913841757b42df9ecaec; review head REVIEW_HEAD.

The missing digest-guard observation is now established on the unchanged candidate. In a fresh private project, Opus 5.5 sent the old preview digest with current project/context versions. The service returned HAG_REMOTE_STALE_PREVIEW with no effect. Claude obtained a fresh preview and one accepted approval; independent released-evaluator replay passed. All three native Cypher responses matched HTTP. Required delegation reading preceded approval.

This narrower diagnostic took 7:39, 62 calls and 177,692 peak input-context tokens. Four helper failures and the intended refusal are retained. No product code, instructions, package, permissions or criteria changed. No performance improvement is claimed. Prior results remain intact.

Full NQ-01..05 for both hosts and required Opus 4.6 authoring cases remain pending. Continue those existing qualification obligations next. No actual VREC or human verification is requested here.

## Delivery boundary

PR #543 stays draft, codex/hosted-agent-qualification to main, with the original complete comparison base. WO-HAG-009/010/011 remain in_progress. The existing WO-HAG-009 QGP-G4I-EVIDENCE blocker for unfinished qualification is disclosed; current CI must be checked separately. Exact candidate source/package checks are reused, with no product edits. Evidence scope/preflight/validation are retained.

Git remains authoritative. No actual verification, merge, release, deployment, host update or risk acceptance is granted. Authentication/database ACL implementation and broad performance changes remain deferred. Released next step: STEP-WO-IMPLEMENT-CHECK. This is an authorized unfinished-work review update.
''')
print('Focused guard evidence independently assessed; report written')
