"""Retain bounded setup and package-reuse evidence without credentials."""
import hashlib,json,re,zipfile
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'hag-digest39-20261012';P=p.W/'hag-authority38-20261012';E=p.D/'evidence/WO-HAG-009/digest39-result'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
assert (O/'claude-351/native/session.json').exists()
files={}
drivers=['hag_digest39.py','hag_digest39_task.txt','hag_observe39.py','hag_report39.py','hag_retain39.py','hag_provenance39.py','hag_publish39.py','hag_publish28.py','hag_full27.py','hag_native27.py','hag_efficiency_plan.py','hag221_execute.py','hag_parity36.py','hag_native_parity19.py','hag_review36.py','hag_full27_review.py','hag_trace36.py','hag_full27_trace.py','hag_full36_facts.py','hag_retain36.py','hag_retain26.py','hag_watch36.py','hag_assess36.py','hag_ordering38.py']
for name in drivers:files['drivers/'+name]=(p.W/name).read_bytes()
for name in ('diagnostic-scope','context-WO-HAG-009','context-WO-HAG-011','claude-auth-review','claude-version','ci-previous39'):
    files['current/'+name+'.json']=(O/(name+'.json')).read_bytes()
for f in O.glob('claude351-*.json'):files['setup/'+f.name]=f.read_bytes()
for name in ('candidate-38','package-guidance-comparison','service-reuse-comparison','server-wheel-members','build38-replay'):
    files['reused-candidate/'+name+'.json']=(P/(name+'.json')).read_bytes()
files['reuse.json']=(json.dumps({'candidate':'ee86a842550c19fb6a56913841757b42df9ecaec','prior_report':'https://github.com/mmzen/se_harness/blob/fabfdebae48e10b3fadbb2833e9a8bb30115e15b/docs/engineering/hosted-artifact-graph/evidence/WO-HAG-009/authority38-result/assessment.md','prior_provenance_sha256':sha((p.D/'evidence/WO-HAG-009/authority38-result/provenance.zip').read_bytes()),'meaning':'No product edits or package rebuild in this diagnostic. Same exact C38 candidate, archives, service image, dependencies and helper bytes. Only task, private project and retained evidence differ.'},indent=2)+'\n').encode()
tokens=[x['token'].encode() for f in O.glob('*/credentials.json') for x in load(f)['principals']]
for name,raw in files.items():
    assert not any(t in raw for t in tokens),name
    assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
with zipfile.ZipFile(E/'provenance.zip','x',zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(files.items()):z.writestr(name,raw)
index={'archive':'provenance.zip','sha256':sha((E/'provenance.zip').read_bytes()),'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())],'limits':'Exact bounded setup and observer sources plus prior package identities. No raw provider log, private reasoning, credentials, account stores, environment or executable. Test tokens checked absent.'}
f=E/'provenance-inventory.json';assert not f.exists();f.write_bytes((json.dumps(index,indent=2)+'\n').encode());print(len(files),'files')
