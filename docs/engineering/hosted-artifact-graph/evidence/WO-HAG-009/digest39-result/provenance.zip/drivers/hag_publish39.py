"""Publish diagnostic evidence only under the existing unfinished-review grant."""
from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_publish28.py').read_text()
source=source.replace('hag-hosted-next28-20261011','hag-digest39-20261012').replace('WO-HAG-009/diagnostic28','WO-HAG-009/digest39-result')
source=source.replace("C='dfcf1e976123836f00354a228c8e72a833f2e3cf';PRE='dd1c4730e7b4973fae87bc0a6b1c9a871f1219c7'", "C='fabfdebae48e10b3fadbb2833e9a8bb30115e15b';PRE='fabfdebae48e10b3fadbb2833e9a8bb30115e15b'")
source=source.replace("'candidate':C","'candidate':'ee86a842550c19fb6a56913841757b42df9ecaec'")
for stem in ('report','evidence-commit','pr-note','pr-body','pr-event','check-pr','main-controls','source-controls','write-guard','push','pr-edit','published-readback','report-readback'):
    source=source.replace(stem+'28',stem+'39')
source=source.replace('pr-before-28.json','pr-before-39.json')
source=source.replace("body=body.replace('## Latest result\\n',note+'\\n## Previous full qualification result\\n',1)",'body=note')
source=source.replace('Retain focused Claude hosted lifecycle diagnostic and limitations','Retain focused preview-digest diagnostic and qualification limits')
exec(compile(source,'digest39-publish','exec'),{'__file__':str(W/'hag_publish28.py'),'__name__':'__main__'})
