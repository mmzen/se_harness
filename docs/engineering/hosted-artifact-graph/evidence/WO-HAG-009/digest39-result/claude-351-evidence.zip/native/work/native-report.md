# NQ-03 focused diagnostic: preview-digest guard

**Outcome:** The service refused an approval apply that carried a preview digest
from before a draft amendment. The refusal committed no effects. A fresh preview
of the amended draft was then applied once. Test data only: Git remains
authoritative. `test-owner` is a synthetic fixture identity, not a human decision.
This focused observation is not a pass for NQ-01 through NQ-05 and is not a
comparable performance sample.

## Identities

| Item | Value | Evidence |
| --- | --- | --- |
| Project | `798f89d1-3b13-4183-a0ac-21f9a3fcfa36`, authority mode `sandbox-projection`, `test_copy: true` | `work/01-status.stdout.txt` |
| Source fixture S | `5820415917e87b64d80bad2f7c39c6d18d692829` (provenance repository `https://example.invalid/private-rehearsal.git`) | `work/07-preview1.stdout.txt` `/provenance` |
| Evaluator | 0.22.1, archive `cb35c3c4…3053`, payload `0e7b7c2b…7e7ff` | status and every result |
| Client | 0.22.2, wheel `ada921b0…57150` (matches `inputs/combination.json`) | `work/01-status.stdout.txt` |
| Qualification candidate | `ee86a842550c19fb6a56913841757b42df9ecaec` (`/components/source/candidate_commit`) | `work/01-status.stdout.txt` |
| Imported baseline | `se-harness-artifact-baseline/v1:sha256:02def27c…c79f` | `work/02-import` |
| Draft context | `77a0cc42-ab9e-454a-8fe4-e3c9755ee6eb` (base: imported baseline; selected WO-P3-900 as context only) | `work/03-draft-open` |
| Test Git candidate P / implementation candidate C | Not applicable; no capture or implementation was performed | — |

Status matched the combination report for readiness, schema revision, protocols
and all component identities before any mutation.

## Selected draft

- **Type and ID:** intent `INT-P3-001`, domain `lifecycle-pilot`, allocated by
  `create-artifact`.
- **Why intent:** The supplied outcome is an operator result. An intent needs no
  declared upstream link. A requirement would need an active capability. The only
  capability, CAP-P3-900, is imported, draft and immutable here. That is
  reasoning from `DEFINITION_LINKS.md`, not an observed refusal.
- **Content readiness:** complete against `ARTIFACT_AUTHORING.md#intent`, by
  source inspection of the agent-authored text:
  - Problem: from INT-P3-900.
  - Outcome and owner: from the task.
  - Success measure: honest baseline `not measured`.
  - Scope limits: listed.
- **Draft validation:** `incomplete: []` with `content_review: not_assessed`. That
  is the template-shape check only.
- **Amendment (r1 → r2):** added the scope limit "No change to the greeting text
  or to `src/greeting.py`." Both files are retained: `work/INT-P3-001.r1.md` and
  `work/INT-P3-001.r2.md`.

## Case rows

| # | Action (key) | Outcome | Evidence | Remaining limit |
| --- | --- | --- | --- | --- |
| 1 | import (`nq03-import-01`) | accepted, pv 0→1, 7 imported revisions | `work/02-import` | Advisory W-AUT-022 on SPEC-P3-900 (imported, unrelated) |
| 2 | draft-open (`nq03-open-01`) | accepted, pv 1→2, ctx v0 | `work/03-draft-open` | Embedded WO-P3-900 check is context only: compliance `not_assessable`, no gates |
| 3 | create-artifact (`nq03-create-int-01`) | accepted, pv 2→3, ctx v1, INT-P3-001 rev `sha256:4ffddec8…3c9df` (template) | `work/04-create-intent`, document `…evidence/2-document-1.md` | Template placeholders reported as incomplete |
| 4 | revise r1 (`nq03-revise-int-01`) | accepted, pv 3→4, ctx v2, rev `sha256:0b108d92…918d1` | `work/05-revise-r1` | — |
| 5 | Cypher read, ctx v2 (MCP) | complete; INT-P3-001 rev `0b108d92…` status `draft` | `work/06-cypher-ctx2.json` (transcribed) | Transcription by agent, not a client capture |
| 6 | Preview 1 approval (`nq03-approve-preview-01`) | `previewed`; D1 = `sha256:0ea93303c0602ea11113e30a953a1a41890b8c9144cc0e2067e86b1208f31570`; QG-G1-DEFINITION and QG-STRUCTURAL `pass`; one proposed file `docs/engineering/lifecycle-pilot/intent/INT-P3-001.md` | `work/07-preview1.stdout.txt` `/preview_digest`, `/evaluator_output/commands/0/result/compliance`, `/files` | The reason was double-prefixed (`INT-P3-001=INT-P3-001=…`) because the service adds the prefix |
| 7 | revise r2 (`nq03-revise-int-02`) | accepted, pv 4→5, ctx v3, rev `sha256:899b1e06…73024` | `work/08-revise-r2` | — |
| 8 | Apply with D1 at **current** versions pv 5 / ctx 3, action byte-identical to preview 1 (`nq03-approve-apply-stale-01`) | **refused** by the service: HTTP 409 `HAG_REMOTE_STALE_PREVIEW`, "Apply needs a preview bound to these exact inputs."; no receipt, no affected revisions, no files | `work/09-apply-stale.stdout.txt`, request `work/req-09-apply-stale.json` | See uncertainty 1 |
| 9 | No-effect check: status | `project_version` still 5 | `work/10-status-after-refusal.stdout.txt` `/project_version` | — |
| 10 | No-effect check: Cypher ctx v3 (MCP) | complete; INT-P3-001 still rev `899b1e06…`, status `draft`, ctx v3 | `work/11-cypher-ctx3-after-refusal.json` (transcribed) | — |
| 11 | Preview 2 approval with corrected reason (`nq03-approve-preview-02`) | `previewed`; D2 = `sha256:7eceedf73dd59b5d390eb4694579e891d3a3fc270bc8c958d55a2fc3df9a38ab`; compliance `pass`; one proposed file | `work/12-preview2.stdout.txt` | Only the overall compliance status was read, not each gate |
| 12 | Apply with D2 (`nq03-approve-apply-02`) | **accepted**: receipt `sha256:807a5e25…43821`, pv 5→6, ctx 3→4, INT-P3-001 draft → approved, rev `sha256:547b2ed3…e63cc`, baseline `se-harness-artifact-baseline/v1:sha256:e913ae5d…e08e`, input Git head `1dc1b148…`, output Git head `ceab4b16…` | `work/13-apply2.stdout.txt` `/outcome`, `/versions`, `/affected_artifacts`, `/evaluator_output/commands/1/result/state` | — |
| 13 | Cypher ctx v4 (MCP) | complete; INT-P3-001 rev `547b2ed3…`, status `approved` | `work/14-cypher-ctx4-after-approval.json` (transcribed) | — |

## The failed condition

The stale apply carried the current expected project and context versions (5 and
3). The version guard therefore had no mismatch to report. The service returned
the preview-specific code `HAG_REMOTE_STALE_PREVIEW` and did not return a version
conflict. Between preview 1 and the apply, the selected INT-P3-001 revision
changed from `0b108d92…` to `899b1e06…` because of the r2 amendment. Preview 1
had planned an approval of r1 content, which is no longer the selected draft.

## Uncertainties

1. The v2 contract (`reference/server/contracts/lifecycle-v2.md`) says the digest
   binds project/context versions **and** selected revision IDs. The r2 revision
   also advanced both versions. The refusal message does not name which bound
   input differed. This run therefore shows that the digest guard (not the version
   guard) refused a preview made before a content change. It does not separate the
   content component from the version component inside the digest. Isolating that
   would need a control in which the versions advance without a content change.
   This diagnostic did not run such a control.
2. The Cypher results come from the native MCP tool and were transcribed into
   `work/*.json` by the agent. They are not client captures.
3. The capture is a snapshot taken before this report was written
   (`work/15-observations`, `snapshot: in_progress`).

## Context compared with passed gates

- **Context only:** draft-open's embedded WO-P3-900 check (compliance
  `not_assessable`, no gates), the Cypher reads and status.
- **Passed gates:** the INT-P3-001 transition gates in preview 1
  (QG-G1-DEFINITION with four predicates, and QG-STRUCTURAL edge draft→approved),
  and overall `pass` in preview 2. The service reran the released checks at the
  accepted apply.
- **Not decided:** no gate approves anything by itself. The approval is the
  supplied synthetic fixture decision by `test-owner`, applied by the agent.

## Evaluator next step (unchanged)

`PROC-DEFINITION-COMPLETE` / `STEP-DEFINITION-COMPLETE`. Response: "Decide the
selected definition INT-P3-001 only." `decision_required`: `DR-DEFINITION-DECIDE`,
role `definition-owner`, with outcomes `implemented`, `reject` and `stop`. That
step was not taken.

## Material non-effects

- No work was started or completed.
- The greeting assertion was not run, and no test was executed.
- No VREC or RLS was prepared.
- No risk was recorded.
- Nothing was exported, published or installed.
- The source was not changed, and no Git action was taken in a real repository.
- No decision was applied to any imported -900 record.
- The context was not frozen.

## Failed calls and recoveries (from `work/15-observations` `/native_failures`)

1. The `instructions` helper refused `reference/...` selectors because it covers
   inventory names for released resources only. Recovery: the two reference files
   were read with native Read.
2. Three `read-json` calls failed with "JSON pointer must be empty or start with
   /". Git Bash converted the bare `/…` pointer into a path. Recovery: the
   documented quoting `'"/field"'` was used.
3. One service refusal (case 8), which was intended.

No host permission denials were observed.

## Instruction reads (actual)

- **Task and selection:**
  - `task.md`, which supplied `COMMUNICATION.md` in full.
  - `selection.json`
  - `inputs/native-tools.md`
  - `inputs/combination.json`
- **Plugin skill and route files:**
  - `setup/SKILL.md`
  - `setup/references/hosted-context.md`
  - `change/references/hosted-drafts.md`
  - `harness-orient/references/hosted-reads.md`
  - `change/references/hosted-test-lifecycle.md`
  - `evidence/references/hosted-evidence.md`
- **Released 0.22.1 sections:**
  - `DRAFT_DEFINITIONS.md`: `#read-this-when`, `#before-this-action`,
    `#draft-any-missing-definitions`
  - `ARTIFACT_AUTHORING.md`: `#design-simplicity`, `#intent`, `#requirement`
  - `AUTHORIZE_WORK.md`: `#assess-the-proposed-artifact-package` and
    `#apply-the-selected-transitions`, with entry conditions
  - `AUTHORITY.md`: `#decision-rights`, `#delegation-and-separation`
  - `ARTIFACTS.md`: `#artifact-types`, `#artifact-locations`
  - `DEFINITION_LINKS.md#links-between-definitions`
  - `DEFINE_CHANGE.md#identify-the-existing-artifacts-that-apply-to-the-change`,
    with entry conditions
  - `RESULTS.md#report-a-lifecycle-result`, with entry conditions
- **Product references:**
  - `reference/docs/notes/hosted-artifact-graph.md` (complete)
  - `reference/server/contracts/lifecycle-v2.md` (complete)
  - `reference/server/contracts/lifecycle-v2.json` (complete)
- **Fixture records:** the seven -900 records and `source/src/greeting.py`.
  Reading the source was inspection only; nothing was executed.
- **Not read:**
  - `RECORD_STATE.md#complete-a-selected-definition`, which the evaluator returned
    as the next step.
  - `WORK_AND_EVIDENCE.md#assurance-classification`, because no work was approved.
