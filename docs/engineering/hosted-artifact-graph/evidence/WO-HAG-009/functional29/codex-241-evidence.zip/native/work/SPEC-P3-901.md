+++
id = "SPEC-P3-901"
type = "specification"
title = "Exact greeting function result"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
contract = "The selected greeting() function returns the exact Python string Hello rehearsal when called without arguments."

[relations]
specifies = ["REQ-P3-901"]
+++

# Exact greeting function result

## Rules

Calling `greeting()` from `src/greeting.py` without arguments returns `'Hello rehearsal'`. The returned value is a Python string with no extra newline or surrounding space.

## Failure behavior and example

An exception or any other result fails REQ-P3-901; the test must retain that failure without substituting a successful output. For example, `assert greeting() == 'Hello rehearsal'` must succeed. The test also inspects the function's literal return statement.

## Design

The existing fixed return statement is the smallest implementation that satisfies this request. No source change, new component or architecture decision is needed. The verification contract governs retained proof; this specification makes no deployment or service-execution claim.

