+++
id = "DEC-P3-901"
type = "decision"
title = "Answer to the threat Governance output mistaken for a local greeting test"
status = "decided"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
kind = "question"
question = "How is the threat 'Governance output mistaken for a local greeting test' answered: accept, avoid or mitigate?"
raised_by = "test-executor"
recommendation = "mitigate"

[[options]]
id = "accept"
label = "Accept the threat; record a residual and a revisit trigger."

[[options]]
id = "avoid"
label = "Avoid the threat by a design change recorded in an ADR or a decision."

[[options]]
id = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."

[relations]
concerns = ["RISK-P3-901", "WO-P3-901"]
blocks = ["WO-P3-901"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-11T04:46:11Z"
reason = "Synthetic supplied choice: mitigate through WO-P3-901 by retaining the exact local assertion and source inspection before verification."

[[lifecycle_events]]
from = "open"
to = "decided"
decided_at = "2026-10-11T04:46:11Z"
decided_by = "test-owner"
reason = "Synthetic supplied choice: mitigate through WO-P3-901 by retaining the exact local assertion and source inspection before verification."
+++

# Decision: Answer to the threat Governance output mistaken for a local greeting test

## Question

How is the threat 'Governance output mistaken for a local greeting test' answered: accept, avoid or mitigate? The description and the threatened artifacts are on RISK-P3-901.

## Options

- `accept`: Accept the threat; record a residual and a revisit trigger.
- `avoid`: Avoid the threat by a design change recorded in an ADR or a decision.
- `mitigate`: Mitigate the threat through a work order; the risk closes under verified coverage.

## Recommendation

The raiser recommends `mitigate`.

## Disposition

Written by `harnessctl decide`; do not edit by hand. Disposing this decision
moves RISK-P3-901 to the state the chosen option names, in the same act.
