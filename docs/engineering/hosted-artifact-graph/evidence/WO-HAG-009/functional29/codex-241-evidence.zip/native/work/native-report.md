# Native hosted-workflow report

The requested native test operations completed in the disposable hosted project. The local assertion proved that the unchanged fixture's `greeting()` returns exactly `Hello rehearsal`. The new work is `implemented`, its verification record is `verified`, and the test release record is `released` for version `0.0.1`. The earlier and later immutable exports are retained for independent review.

This report records observed native results. Independent Git reconstruction and released-evaluator replay have **not** been performed here. All actor labels and decisions are synthetic. Git remains authoritative for real engineering work.

## Selected context and binding

- Project: `2f1626a9-f3d8-41f3-9e8c-56b850b2c50f`; endpoint: `http://127.0.0.1:51640`.
- Context: `313f396f-7bdf-4efb-abf2-cab311743d03`; final project/context versions: `28/26`.
- Client: `0.22.2`; candidate plugin: `codex 0.2.7`. [Status](status.json.stdout.txt) records the supplied component/combination identity checks and ready schema-2 test context.
- Released governor: `0.22.1`; archive SHA-256 `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`; payload SHA-256 `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff`.
- Implementation candidate C: `dfcf1e976123836f00354a228c8e72a833f2e3cf`.
- Fixture source S: `5820415917e87b64d80bad2f7c39c6d18d692829`.
- Verified test candidate P: `6b81bc9f508e35c7f59f81cf8ce4ad43a9dde306`.
- Verification input baseline B: `se-harness-artifact-baseline/v1:sha256:9c9ff52132c0df9660ff30b8f3d963316e7af587d0b4e4535084a2cd5e89748c`.

The VREC binds P. It does not verify C or the later export head. The later manifest retains P, B, S, the candidate file hashes and evaluator identity. Setup verified the supplied hosted selection; it did not install software or activate a checkout.

## Source proof and lifecycle

The inspected source is 45 bytes, SHA-256 `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`:

```python
def greeting():
    return 'Hello rehearsal'
```

The [local command record](assertion.json) retains the exact argv, source path, exit code `0`, empty stderr and elapsed time. Its [stdout](assertion.json.stdout.txt) is exactly `exact greeting passed\n`. The assertion expression compares the function result to `'Hello rehearsal'`; stdout does not print the returned value. No service endpoint executed the source test. Exact record and stdout bytes were handed off and read back from the later export.

| Artifact | Observed state and decision |
|---|---|
| INT/CAP/REQ/SPEC/VER/REL-P3-901 | New complete definitions accepted with supplied `test-owner` input |
| WO-P3-901 | Approved by `test-owner`, started and completed by `test-executor`; `implemented` |
| RISK-P3-901 / DEC-P3-901 | Paired risk/decision; supplied `mitigate` choice recorded by `test-owner`; risk `mitigating`, decision `decided`, mitigation linked to WO-P3-901 |
| VREC-P3-901 | Prepared and accepted by `quality-owner`; `verified` at original P |
| RLS-P3-901 | Prepared and authorized by `release-owner`; `released`, version `0.0.1` |

I reviewed the complete new drafts against the applicable authoring checklists and inspected prepared evidence records before applying supplied decisions. Automated validation is separate from that content review. Final [validation](final-validate-result.json.stdout.txt) reports 18 artifacts, zero errors and zero warnings. It retains one historical advisory, `W-AUT-022` on `SPEC-P3-900` rule `P3-GREET-900`. The seven imported `-900` records were not amended. Their hashes match across the two export manifests.

The [handoff](handoff-result.json.stdout.txt), [completion](complete-result.json.stdout.txt), [verification](verify-result.json.stdout.txt), and [release](release-result.json.stdout.txt) contain full evaluator commands and results. The release transition passed `QG-G5-RELEASE-DECISION` and `QG-STRUCTURAL`. A read-only context report is not a gate pass: the final check reports `not_assessable` with no gates.

## Required refusal and recovery observations

| Case | Actual observation and effect evidence |
|---|---|
| Stale preview after draft change | INT-P3-901 changed after the old preview at versions 16/14. Applying that digest at current versions 17/15 returned HTTP 409 `HAG_REMOTE_STALE_PREVIEW`: “Apply needs a preview bound to these exact inputs.” Zero files/revisions were affected. A fresh preview then supported approval. See [old preview](definitions-preview-old-result.json.stdout.txt), [draft change](revise-int-stale-case.json), [refusal](stale-preview-result.json.stdout.txt), and [fresh preview](definitions-preview-result.json.stdout.txt). |
| Uncertain accepted reply | `codex241-definitions-apply` returned transport exit 2 after the service accepted it. [Operation lookup](definitions-recovery.json.stdout.txt) established acceptance before retry. |
| Identical retry | The exact [original request](definitions-apply-request.json) was retried. [Retry result](definitions-identical-retry.json.stdout.txt) retained the same receipt, request digest, baseline and versions: project 17→18, context 15→16. No second effect occurred. |
| Changed accepted key | Changing the reason under that same key returned HTTP 409 `HAG_REMOTE_KEY_REUSE`: “Operation key has different content.” Zero files/revisions were affected. See [request](accepted-key-conflict-request.json) and [refusal](accepted-key-conflict-result.json.stdout.txt). |
| Out-of-scope handoff | The preview containing `docs/unrelated-proof.txt` returned HTTP 422 `HAG_REMOTE_EVALUATOR_REFUSED`, predicate `QGP-G4I-PATHS`: `WEX201: changed path is outside execution scope: docs/unrelated-proof.txt`. Zero files/revisions were affected; WO remained `in_progress`, versions 22/20. That request stopped. The separately scoped [valid preview](handoff-preview-result.json.stdout.txt) used the same guards and the accepted handoff advanced to 23/21. No scope expansion occurred. |

Recovery/retry receipt: `sha256:1ee80e15bfef1880a099b599b9ee552144a53baf238946efd6b25ee1e5ccdfab`.
Request digest: `sha256:cbc32a345c3f87d3d271d2e97baceaa274bfbd8f80f894719dbc9abbdf33ebcb`.
Exact requests, command records, stdout/stderr and affected revisions remain in `work/`; [structured observations](native-observations.json) index the keys, receipts and versions.

There were no host permission denials or unresolved runtime blockers. A local help-file lookup found no match; actual CLI help resolved the reference. During context recovery, two read-only helper syntax attempts failed (`read-file --path`, then `read-text --path`); documented positional `read-text` succeeded. No permission or route change occurred.

## Seven read-only MCP tools

Each linked file preserves its exact request and full raw response. Every selected result reports `complete: true`, `continuation: null`, and no unresolved references. Completeness applies to the selected operation/view.

| Tool | Meaningful selected view |
|---|---|
| [work-context](mcp-work-context.json) | WO-P3-901 at context version 14 |
| [check](mcp-check.json) | DEC-P3-901 at context version 19 |
| [revision](mcp-revision.json) | Exact verified VREC-P3-901 revision at context version 24; decoded document SHA-256 matched its envelope |
| [compare](mcp-compare.json) | Earlier versus later baseline; changed WO plus added DEC/RISK/VREC/RLS |
| [impact](mcp-impact.json) | REQ-P3-901 dependents in the later baseline |
| [lineage](mcp-lineage.json) | RLS-P3-901 ancestry under the operation's defined relation scope |
| [cypher](mcp-cypher.json) | Later-baseline query returned RLS-P3-901 with status `released` |

Initial template views with unresolved placeholders were incomplete and were not treated as complete governing records. Later authored revisions and decision/evidence records were inspected.

## Immutable exports and remaining review

| Export | Snapshot / Git head / contents |
|---|---|
| [Earlier manifest](export-earlier/manifest.json) | `sha256:7006d6fad5d8b3ddbc2956a2fc747d8ce7d6b5616170b20f70516cb1024f6643`; head `846ed5ac6694fb0d87d48acf10cfb2edef8c0ee3`; 19 files and [history.bundle](export-earlier/history.bundle) |
| [Later manifest](export-later/manifest.json) | `sha256:0f1c84077f24883407bb312565881b4295d6a06fa90ee1738bf74cc914b962ff`; head `83040ffaa665515045397d7e4a1258f5e9cbfe1a`; 30 files and [history.bundle](export-later/history.bundle) |

Earlier bundle SHA-256: `2b75048a55922b96fcd171586057ab141b5728ff3126058618ceb34046d2d208`.
Later bundle SHA-256: `ab6967d8915b85aca17f9dc8dae23b39a3b3f0ed7b32ef392a4957ed81928fde`.
The complete final artifact bytes are under `export-later/files/`. Intermediate `export-verification/` and `export-release-review/` retain the prepared records inspected before decisions.

The client reported successful export validation. Manifest comparisons and selected byte readbacks agree. The independent reviewer must still reconstruct both bundles and check exact bytes and original candidate bindings with released 0.22.1. The VREC sidecar records origin-version 0.22.1 with null payload/archive fields; the selected service and candidate manifest pin the hashes, and the RLS sidecar records full-payload identity.

[File-read trace](file-read-trace.json) retains observed exact paths/hashes, section boundaries and read triggers. [Captured observations](observed-trace-final.json) are an `in_progress` snapshot through the reporting cutoff: 198 observed tool items, incomplete call capture, and no complete wall-time, native-call or billed-token total. Some read-json metadata is supplemented in the file-read trace. The capture is not proof of full-file reading. No automatic startup instruction delivery is claimed.

The [final RLS check](mcp-final-check.json) reports `completed`, `RLS-P3-901 is released.`, no blocked items, and the next typed step `PROC-EXTERNAL-ACTION / STEP-EXTERNAL-ACTION`. Its decision right is `DR-EXTERNAL-ACTION`, owned by the accountable external-action owner. Exact response: “Reuse the matching complete-release or external-action authorization for RLS-P3-901; request only an uncovered action and target.”

No external action is part of this task. The `v0.0.1` field is release-record data; no Git tag, push, publication or deployment occurred. No source modification, real artifact approval, installation, activation or ownership override occurred.

