+++
id = "RISK-P3-901"
type = "risk"
title = "Governance output mistaken for a local greeting test"
status = "raised"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
description = "The operator could accept a service gate as proof of greeting() without a retained local assertion, leaving REQ-P3-901 unproved."
action = "Retain the exact local assertion and source inspection through WO-P3-901 before accepting its verification."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-901"]

[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-11T04:45:18Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."
+++

# Risk: Governance output mistaken for a local greeting test

## Description

The operator could accept a service gate as proof of greeting() without a retained local assertion, leaving REQ-P3-901 unproved.

## Next action

Retain the exact local assertion and source inspection through WO-P3-901 before accepting its verification.
