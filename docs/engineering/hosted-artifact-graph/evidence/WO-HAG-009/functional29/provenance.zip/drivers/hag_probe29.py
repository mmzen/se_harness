from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_full27_probe.py').read_text().replace('hag-lifecycle-native27-20261010','hag-functional29-20261011')
exec(compile(source,'functional29-boundary','exec'),{'__file__':__file__,'__name__':'__main__'})
