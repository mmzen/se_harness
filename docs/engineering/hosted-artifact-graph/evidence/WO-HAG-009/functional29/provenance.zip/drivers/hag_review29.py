"""Observe, replay and stop a completed functional qualification project."""
import sys
from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_review28.py').read_text().replace('hag-hosted-next28-20261011','hag-functional29-20261011')
source=source.replace("O/'package28/candidate-source/server/compose.yaml'", "W/'hag-hosted-next28-20261011/package28/candidate-source/server/compose.yaml'")
source=source.replace(",'--limit','99'",'')
exec(compile(source,'functional29-review','exec'),{'__file__':str(W/'hag_review28.py'),'__name__':'__main__'})
