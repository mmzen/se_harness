"""Observe exact MCP/HTTP comparisons while native calls occur."""
from pathlib import Path
import sys
W=Path(__file__).parent
source=(W/'hag_native_parity19.py').read_text()
source=source.replace('hag-agent-qualification-execution-20261007','hag-functional29-20261011')
source=source.replace("hosts={'codex':O/'codex/native03','claude':O/'claude/native02/work/sonnet01'}", "hosts={h+'-241':O/(h+'-241')/'native' for h in ('codex','claude')}")
source=source.replace('time.monotonic()+3800','time.monotonic()+3900')
sys.argv=[__file__,'full29']
exec(compile(source,'functional29-parity','exec'),{'__file__':__file__,'__name__':'__main__'})
