"""Retain completed functional runs without credentials or private reasoning."""
from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_full27_retain.py').read_text()
source=source.replace('hag-lifecycle-native27-20261010','hag-functional29-20261011')
source=source.replace('WO-HAG-009/lifecycle27','WO-HAG-009/functional29')
source=source.replace('native-parity-*27','native-parity-*29')
source=source.replace("'costs.json'", "'boundary-comparison.json','proctor-interruption.json','costs.json'")
exec(compile(source,'retain-functional29','exec'),{'__file__':str(W/'hag_full27_retain.py'),'__name__':'__main__'})
