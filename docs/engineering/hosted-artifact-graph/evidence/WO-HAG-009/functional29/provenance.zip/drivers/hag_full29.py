"""Full functional qualification of unchanged candidate28; performance work deferred."""
from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_full27.py').read_text()
source=source.replace('hag-lifecycle-native27-20261010','hag-functional29-20261011')
source=source.replace('hag-lifecycle-correction27-20261010','hag-hosted-next28-20261011')
source=source.replace("trial='221'","trial='241'").replace("host+'-221-boundary-probe.json'","host+'-241-boundary-probe.json'")
source=source.replace('candidate-27.json','candidate-28.json').replace('package27','package28')
source=source.replace("assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()==load(PREV/'candidate-28.json')['commit']", "assert subprocess.run(['git','merge-base','--is-ancestor',load(PREV/'candidate-28.json')['commit'],'HEAD'],cwd=R).returncode==0\n    assert not subprocess.check_output(['git','status','--porcelain'],cwd=R).strip()")
source=source.replace("source=(W/'hag_native27.py').read_text()", "source=(W/'hag_native27.py').read_text().replace('hag-lifecycle-native27-20261010','hag-functional29-20261011').replace('hag-lifecycle-correction27-20261010','hag-hosted-next28-20261011').replace('package27','package28').replace('client27','client28').replace('build27','build28').replace('native-lifecycle27','native-lifecycle28').replace('hag-full27-','hag-full29-')")
source=source.replace("'review_head':load(PREV/'candidate-28.json')['commit']", "'review_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()")
source=source.replace("'--timeout','1800'", "'--timeout','3600'")
exec(compile(source,'functional29-driver','exec'),{'__file__':str(W/'hag_full27.py'),'__name__':'__main__'})
