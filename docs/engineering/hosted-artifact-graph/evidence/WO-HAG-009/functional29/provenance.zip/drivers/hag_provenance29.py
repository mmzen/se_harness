"""Retain bounded functional qualification provenance once both native runs end."""
import json,hashlib,zipfile,re
from pathlib import Path
import hag_efficiency_plan as p
W=p.W; O=W/'hag-functional29-20261011'; E=p.D/'evidence/WO-HAG-009/functional29'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
assert all((O/h/'native/session.json').exists() for h in ('codex-241','claude-241'))
E.mkdir(exist_ok=True)
files={}
for name in ('hag_full29.py','hag_full27.py','hag_native27.py','hag_probe29.py','hag_full27_probe.py','hag_review29.py','hag_review28.py','hag_full27_review.py','hag_trace29.py','hag_full27_trace.py','hag_parity29.py','hag_native_parity19.py','hag_retain29.py','hag_full27_retain.py','hag_retain26.py','hag_assess_codex29.py','hag_assess_claude29.py','hag_provenance29.py'):
    files['drivers/'+name]=(W/name).read_bytes()
for name in ('codex-auth-review.json','claude-auth-review.json','codex-version.json','claude-version.json','codex-241-boundary-probe.json','service-reuse-comparison.json','server-wheel-members.json','pr-before-functional29.json','WO-HAG-009-context-resume1.json','WO-HAG-010-context-resume1.json','WO-HAG-011-context-resume1.json'):
    files['checks/'+name]=(O/name).read_bytes()
for host in ('codex','claude'):
    for suffix in ('volume-absent','volume-create','source-stage','init','networks','up'):
        name=host+'241-'+suffix+'.json'; files['setup/'+name]=(O/name).read_bytes()
for name in ('candidate-28.json','component-comparison.json','guidance-reference-check.json','package-28.json'):
    files['components/'+name]=(W/'hag-hosted-next28-20261011'/name).read_bytes()
files['components/combination.json']=(W/'hag-hosted-next28-20261011/package28/combination.json').read_bytes()
tokens=[x['token'].encode() for f in O.glob('*/credentials.json') for x in load(f)['principals']]
for name,raw in files.items():
    assert not any(t in raw for t in tokens),name
    assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
archive=E/'provenance.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for name,raw in sorted(files.items()):z.writestr(name,raw)
index={'archive':archive.name,'sha256':sha(archive.read_bytes()),'files':[{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(files.items())],
 'limits':'Selected exact proctor drivers and noncredential observations only. Authentication results summarized; raw provider probes, private reasoning, tokens, credential stores and full environments excluded. Candidate source/package checks retained by reference to diagnostic28 and lifecycle-correction28.'}
dest=E/'provenance-inventory.json';assert not dest.exists();dest.write_bytes((json.dumps(index,indent=2)+'\n').encode())
print(json.dumps({'files':len(files),'archive_bytes':archive.stat().st_size}))
