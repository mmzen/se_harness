"""Retain the independent assessment of the completed Codex functional run."""
import json, hashlib
from pathlib import Path
W=Path(__file__).parent; O=W/'hag-functional29-20261011'; root=O/'codex-241'; work=root/'native/work'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
result=lambda n:load(work/(n+'.json.stdout.txt'))
session=load(root/'native/session.json'); replay=load(root/'independent-replay/assessment.json')
assert session['exit']==0 and not session['timed_out']
assert replay['state']=='accepted_calls_and_native_exports_replayed' and len(replay['cases'])==11
assert sum(x['case'].startswith('native-export-') for x in replay['exports'])==4
parity=[load(f) for f in (O/'native-parity-full29').glob('*codex-241*.json')]
assert len(parity)==8 and all(x['http_status']==200 and x['exact_match'] for x in parity)
assert {x['tool'] for x in parity}=={'check','work-context','revision','impact','lineage','compare','cypher'}
assert load(root/'boundary-comparison.json')['equal']
assert load(root/'input-integrity.json')['all_unchanged']
recovered=result('definitions-recovery');retry=result('definitions-identical-retry')
assert recovered==retry
assert recovered['versions']['project']=={'before':17,'after':18}
assert result('wo-approve-result')['versions']['project']=={'before':18,'after':19}
for name,code in [('stale-preview-result','HAG_REMOTE_STALE_PREVIEW'),('accepted-key-conflict-result','HAG_REMOTE_KEY_REUSE'),('out-of-scope-result','HAG_REMOTE_EVALUATOR_REFUSED')]:
    value=result(name)
    assert value['outcome']=='refused' and value['error']['code']==code
    assert not value['affected_revision_ids'] and not value['affected_artifacts'] and not value.get('files')
assert result('handoff-result')['versions']['project']=={'before':22,'after':23}
assert 'QGP-G4I-PATHS' in json.dumps(result('out-of-scope-result'))
assert 'docs/unrelated-proof.txt' in json.dumps(result('out-of-scope-result'))
assert (work/'assertion.json.stdout.txt').read_bytes()==b'exact greeting passed\n'
assert load(work/'assertion.json')['exit']==0
trace=load(root/'instruction-read-trace.json')
assert trace['snapshot']=='complete'
read_order={}
for row in trace['reads']:
    for section in row['sections']:
        read_order.setdefault(section.get('heading'),row['event_line'])
required=['draft-any-missing-definitions','define-how-the-result-will-be-verified','apply-the-selected-transitions','start-the-selected-work','record-risks-risk-affecting-the-change','resolve-approval-blockers','record-implementation-completion','prepare-the-verification-record','record-the-verification-decision','prepare-a-release-record','record-the-release-decision-when-required']
assert all(x in read_order for x in required)
report=work/'native-report.md'
assessment={
 'trial':'codex-241','candidate':'dfcf1e976123836f00354a228c8e72a833f2e3cf',
 'contract':'VER-HAG-007','functional_result':'pass',
 'cases':{
  'NQ-01':{'result':'pass','evidence':'instruction-read-trace.json; native/work/file-read-trace.json; visible transcript','review':'The native session read the selected setup, hosted routes, authoring checklists and released lifecycle sections before their actions. Explicit packaged-resource reads are claimed, not automatic startup delivery. Final report distinguishes context from passed gates and keeps real Git authority unchanged.'},
  'NQ-02':{'result':'pass','accepted_lifecycle_operations':11,'review':'Seven new definitions/work records were authored from the stated greeting task. Actual local assertion passed. Risk/decision, handoff, completion, VREC and RLS followed. Independent released 0.22.1 replay matched all command semantics and exact affected path sets. No corrective instruction or operator mutation was supplied during the native session.'},
  'NQ-03':{'result':'pass','mcp_tools':sorted({x['tool'] for x in parity}),'exact_http_matches':8,'review':'Stale-preview and out-of-scope requests were refused with no reported effects; subsequent accepted requests used unchanged guards. QGP-G4I-PATHS and the exact outside path were identified. All seven actual MCP tools matched immediate independent HTTP reads. The report identifies incomplete template views and retained full results.'},
  'NQ-04':{'result':'pass','reply_dropped':session['reply_dropped'],'identical_receipts':True,'project_version_once':[17,18],'review':'Operation lookup recovered the dropped reply before identical retry. Retry returned the same complete receipt and versions. Changed content under the key was refused. The following accepted operation began at version 18, proving no extra accepted increment.'},
  'NQ-05':{'result':'pass','native_exports_reconstructed':4,'review':'Independent reconstruction checked exact selected Git bytes and candidate objects, released validation and original P bindings. Final host report preserves expected refusals, incidental read syntax errors, synthetic decisions and remaining review limits. Staged inputs and monitored repository/host boundaries are unchanged.'}},
 'native_elapsed_seconds':session['elapsed_seconds'],'native_exit':session['exit'],
 'model_reported':None,'model_limit':'No model identity extracted from the retained native event schema; do not infer one.',
 'instruction_section_first_read_lines':{x:read_order[x] for x in required},
 'report_sha256':hashlib.sha256(report.read_bytes()).hexdigest(),
 'interventions':'Session setup, approved loopback boundary probe, supplied synthetic decisions and automatic dropped-reply helper only. No procedural hint or direct operator mutation during the run.',
 'limits':['This is an independent test assessment, not human verification acceptance.','Claude must separately pass every case for combined qualification.','Performance improvement is deferred; elapsed time is reported, not a lifecycle gate.','No production authorization, automatic startup/compaction delivery, desktop qualification, real release or deployment is claimed.']}
dest=root/'independent-assessment.json';assert not dest.exists();dest.write_bytes((json.dumps(assessment,indent=2)+'\n').encode())
print(json.dumps({'functional_result':assessment['functional_result'],'cases':list(assessment['cases']),'seconds':session['elapsed_seconds']}))
