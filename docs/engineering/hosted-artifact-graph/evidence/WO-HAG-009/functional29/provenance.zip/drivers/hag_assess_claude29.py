"""Retain the failed/incomplete Claude qualification without repairing its evidence."""
import json,tomllib
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-functional29-20261011';root=O/'claude-241';work=root/'native/work'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
result=lambda n:load(work/(n+'.json.stdout.txt'))
def put(f,x):
    assert not f.exists(),f
    f.write_bytes((json.dumps(x,indent=2)+'\n').encode())
session=load(root/'native/session.json');failure=load(root/'independent-replay/failure.json')
assert session['exit']!=0 and not session['timed_out']
assert len(failure['cases'])==8 and all(x['outcome']=='passed' for x in failure['cases'])
assert failure['message']=="('Missing accepted lifecycle or two native exports', 8, 1)"
assert sum(x['case'].startswith('native-export-') for x in failure['exports'])==1
assert load(root/'boundary-comparison.json')['equal'] and load(root/'input-integrity.json')['all_unchanged']
recovered=result('receipt-lookup-transition');retry=result('receipt-transition-retry')
assert recovered==retry and recovered['versions']['project']=={'before':16,'after':17}
assert result('receipt-start-apply')['versions']['project']=={'before':17,'after':18}
assert result('receipt-transition-changed')['error']['code']=='HAG_REMOTE_KEY_REUSE'
release=result('receipt-prepare-release-preview')
assert release['outcome']=='refused' and 'WEX404' in json.dumps(release)
rel=work/'export-early/files/docs/engineering/lifecycle-pilot/release/REL-P3-001.md'
candidate=tomllib.loads(rel.read_text().split('+++')[1])['candidate_commit']
assert candidate=='5820415917e87b64d80bad2f7c39c6d18d692829'
assert result('receipt-revise-rel-001-rev6')['result']['error']['code']=='HAG_REMOTE_PROTECTED_FIELD'
assert not list((O/'native-parity-full29').glob('*claude-241*.json'))
assessment={
 'trial':'claude-241','candidate':'dfcf1e976123836f00354a228c8e72a833f2e3cf',
 'contract':'VER-HAG-007','functional_result':'not_qualified',
 'termination':'Proctor stopped only the owned native child after repeated refused contract-edit attempts. This was not the 3600-second timeout. The agent had begun a separate REL-P3-002 draft but its content admission was refused. A later autonomous recovery was not tested.',
 'cases':{
  'NQ-01':{'result':'incomplete','evidence':'instruction-read-trace.json and native visible transcript','review':'Selected hosted routes and some authoring/lifecycle sections were read. The trace does not establish reads of every returned prerequisite; authority, blocker disposition and completion sections are absent. No complete final report was produced. Do not infer those reads from links or hashes.'},
  'NQ-02':{'result':'failed','accepted_lifecycle_operations_replayed':8,'review':'New definitions and work were authored. Approval, start, risk/decision, handoff, completion, VREC capture and verification matched independent released replay. Release preparation failed WEX404: the authored REL pins source S rather than the later verified candidate P. No RLS was prepared or assessed.'},
  'NQ-03':{'result':'incomplete','actual_mcp_tools_observed':0,'review':'No out-of-scope handoff case or stale-preview-after-draft-change case was demonstrated. A risk apply without a matching preview was refused, but it is not the required stale-preview scenario. No seven-tool MCP/HTTP comparison occurred.'},
  'NQ-04':{'result':'pass','reply_dropped':session['reply_dropped'],'identical_receipts':True,'project_version_once':[16,17],'review':'The original accepted operation was looked up after the dropped reply. Identical retry returned the same receipt and versions. Changed content under the key conflicted. The next accepted operation began at 17.'},
  'NQ-05':{'result':'incomplete','native_exports_reconstructed':1,'review':'The earlier native export reconstructed and validated. There is no later native export or final report. Independent replay retained the original accepted candidates; that does not substitute for the missing native export. Monitored host/repository boundaries and staged input hashes are unchanged.'}},
 'native_elapsed_seconds':session['elapsed_seconds'],'native_exit':session['exit'],
 'native_calls':load(O/'claude-241-summary.json')['native_calls'],
 'peak_input_context':load(O/'claude-241-summary.json')['peak_input_context'],
 'model_reported':'claude-opus-4-6','fixture_source_S':candidate,
 'interventions':'Setup, supplied synthetic decisions, automatic dropped-reply helper and final proctor stop. No corrective command or direct operator mutation was supplied during the native run.',
 'failure_classes':['Evaluator WEX404 candidate mismatch','Client not_sent input/capture refusals','Service HAG_REMOTE_PROTECTED_FIELD after an actual accepted-record revision attempt','Draft admission refusal for the separate replacement contract','Two denied native shell-listing commands; no permission widening','Unperformed cases after proctor stop'],
 'limits':['No full Claude qualification or human verification acceptance.','The observed mismatch is authored test content; no service implementation defect is established by it.','A correct Codex run cannot replace missing Claude cases.','Performance goals remain separate; no efficiency improvement claim.']}
put(root/'independent-assessment.json',assessment)
put(root/'replay-terminal-assessment.json',{'terminal_state':'failed_missing_second_native_export','accepted_operations_replayed':8,'native_exports_reconstructed':1,'failure_file':'independent-replay/failure.json','checkpoint_file':'independent-replay/assessment.json','note':'assessment.json is the last running checkpoint. failure.json is the terminal result; neither original file was edited.'})
print(json.dumps({'result':assessment['functional_result'],'seconds':session['elapsed_seconds'],'replayed':8,'native_exports':1}))
