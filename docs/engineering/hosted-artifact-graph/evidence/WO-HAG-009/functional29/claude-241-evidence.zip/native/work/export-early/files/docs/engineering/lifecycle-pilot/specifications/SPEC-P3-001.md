+++
id = "SPEC-P3-001"
type = "specification"
title = "Fixed rehearsal greeting output"
status = "approved"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
contract = "The greeting() function returns the string Hello rehearsal without side effects."

[relations]
specifies = ["REQ-P3-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-11T04:45:36Z"
decided_by = "test-owner"
reason = "Synthetic test definition approved for lifecycle rehearsal."
+++

# Fixed rehearsal greeting output

## In plain words

The greeting function returns a fixed string and does nothing else.

## Scope

This specification governs the return value of greeting() in src/greeting.py. It does not govern other modules or external interfaces.

## Rules

**P3-GREET-001.** The function greeting() returns the Python string `Hello rehearsal`.

## Examples

**Given** the module src/greeting.py is importable, **when** greeting() is called, **then** it returns exactly `Hello rehearsal` per P3-GREET-001.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-001 | P3-GREET-001 |
