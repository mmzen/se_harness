+++
id = "VER-P3-001"
type = "verification"
title = "Assert the exact greeting output"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"

[relations]
verifies = ["REQ-P3-001"]
+++

# Assert the exact greeting output

## Independence

The expected value `Hello rehearsal` is fixed by REQ-P3-001 and SPEC-P3-001, not derived from candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
|---|---|---|---|
| REQ-P3-001 | test | Exact greeting assertion using assert-greeting | greeting() equals `Hello rehearsal` |

## Acceptance scenarios

Execute the fixture assertion command and retain the result file. The assertion compares greeting() output to the expected string.

## Evidence retention

Retain the assertion result at docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json.

## Residual uncertainty

The test executes on the local fixture only. It does not cover deployed environments.
