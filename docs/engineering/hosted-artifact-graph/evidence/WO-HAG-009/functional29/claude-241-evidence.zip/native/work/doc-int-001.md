+++
id = "INT-P3-001"
type = "intent"
title = "Verify the rehearsal greeting output"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
outcome = "The test operator observes that greeting() returns exactly Hello rehearsal."

[relations]
+++

# Verify the rehearsal greeting output

## In plain words

The test operator needs to confirm that the local fixture returns the correct greeting for a disposable lifecycle rehearsal.

## Problem

The operator has no verified evidence that the greeting fixture returns the expected string. Without an executed assertion and retained evidence, the lifecycle rehearsal cannot proceed through verification and release.

## Success measures

| Measure | Today | When reached | Observed |
| --- | --- | --- | --- |
| greeting() returns Hello rehearsal | not measured | Assertion passes | Local test execution output retained in evidence |

## Not this

- Real product releases or deployments
- Changes to the greeting source code
- External publication or installation
- Real human engineering decisions
- Production operating obligations
