+++
id = "REL-P3-001"
type = "release_contract"
title = "Test release record for version 0.0.1"
status = "approved"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
candidate_commit = "59a30811eba95515c3dc57fe4b815a9be9a6ab1e"
previous_release_tag = "v0.0.0"

[relations]
gates = ["WO-P3-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-11T04:45:36Z"
decided_by = "test-owner"
reason = "Synthetic test definition approved for lifecycle rehearsal."
+++

# Test release record for version 0.0.1

## Release unit

Test version 0.0.1 binds the verified greeting fixture at the test copy candidate commit. No tags, publication or deployment.

## Required evidence

A passing VREC covering WO-P3-001 and VER-P3-001 at the candidate commit.

## Rollback criteria and procedure

Discard the disposable test project if replay fails. Retain the verification record and exact evidence.
