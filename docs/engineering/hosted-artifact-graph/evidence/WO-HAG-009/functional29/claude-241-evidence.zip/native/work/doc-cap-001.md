+++
id = "CAP-P3-001"
type = "capability"
title = "Read the verified rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
ability = "The test operator can read and verify the exact rehearsal greeting from the local fixture."

[relations]
derives_from = ["INT-P3-001"]
+++

# Read the verified rehearsal greeting

## In plain words

The test operator can call the fixture's greeting function and confirm it returns the expected string.

## Actor and need

The test operator needs to execute the greeting assertion and retain its output as evidence for the lifecycle rehearsal.

## Not decided here

- How the greeting is implemented
- What happens after the test release record
- External deployment or publication
