+++
id = "REQ-P3-001"
type = "requirement"
title = "Return the exact rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
statement = "Calling greeting() returns exactly Hello rehearsal."
verification_method = ["test"]
priority = "must"
source = "INT-P3-001"

[relations]
derives_from = ["CAP-P3-001"]
+++

# Return the exact rehearsal greeting

## In plain words

The greeting function must return the fixed string `Hello rehearsal` when called.

## Why

The lifecycle rehearsal requires a deterministic fixture output to verify against.

## Behavior

| Trigger | Response | On failure |
| --- | --- | --- |
| Call greeting() | Returns the string `Hello rehearsal` | Not applicable; the function has no failure mode |

## Examples

### Normal

**Given** the fixture module is imported

**When** greeting() is called

**Then** it returns exactly `Hello rehearsal`
