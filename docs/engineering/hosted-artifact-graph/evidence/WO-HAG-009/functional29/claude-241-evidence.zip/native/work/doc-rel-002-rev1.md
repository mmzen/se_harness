+++
id = "REL-P3-002"
type = "release_contract"
title = "Test release for version 0.0.1 at test candidate"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
candidate_commit = "59a30811eba95515c3dc57fe4b815a9be9a6ab1e"
previous_release_tag = "v0.0.0"

[relations]
gates = ["WO-P3-001"]
+++

# Test release for version 0.0.1 at test candidate

## Release unit

Test version 0.0.1 binds the verified greeting fixture at test copy candidate 59a30811eba95515c3dc57fe4b815a9be9a6ab1e. No tags, publication or deployment.

## Required evidence

A passing VREC covering WO-P3-001 and VER-P3-001 at the candidate commit.

## Compatibility and migration

No compatibility or migration concerns for this disposable test release.

## Security and provenance

Test copy only. No real security or provenance assessment required.

## Promotion policy

No external delivery. The test release completes the lifecycle rehearsal.

## Human approval triggers

Synthetic test-owner approval for the exact release record.

## Rollback criteria and procedure

Discard the disposable test project if replay fails. Retain the verification record and exact evidence.

## Post-release observation window

Not applicable to disposable test release.
