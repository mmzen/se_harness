+++
id = "WO-P3-001"
type = "work_order"
title = "Verify and release the rehearsal greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"

[assurance]
commit_bound_verification = "required"
rationale = "Future release decision depends on verified greeting output."
decided_by = "test-owner"

[execution_scope]
paths = ["src/greeting.py", "docs/engineering/lifecycle-pilot/"]

[relations]
implements = ["REQ-P3-001"]
specifications = ["SPEC-P3-001"]
verification = ["VER-P3-001"]
+++

# Verify and release the rehearsal greeting

## Objective

Confirm that greeting() returns exactly `Hello rehearsal` and retain the evidence for the test release.

## In scope

The fixture source at src/greeting.py, pilot definitions under docs/engineering/lifecycle-pilot/, and test evidence.

## Out of scope

Real engineering records, real human decisions, external deployment, and changes to source code.

## Authorized decision envelope

The test-executor may run the greeting assertion and retain evidence. All actors are synthetic test labels.

## Expected change surface

- src/greeting.py: inspected, not modified
- docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json: new assertion result

## Required verification

Run VER-P3-001 on the exact fixture commit.

## Evidence to record

Retain the assertion output at docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json.

## Stop and escalate conditions

Stop when the released evaluator refuses an operation.

## Completion report format

State the greeting assertion result, actual checks performed, and the next accountable decision.
