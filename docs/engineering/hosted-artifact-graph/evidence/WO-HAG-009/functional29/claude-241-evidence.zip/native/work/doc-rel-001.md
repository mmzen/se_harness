+++
id = "REL-P3-001"
type = "release_contract"
title = "Test release record for version 0.0.1"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
candidate_commit = "5820415917e87b64d80bad2f7c39c6d18d692829"
previous_release_tag = "v0.0.0"

[relations]
gates = ["WO-P3-001"]
+++

# Test release record for version 0.0.1

## Release unit

Test version 0.0.1 binds the verified greeting fixture at the source commit. No tags, publication or deployment.

## Required evidence

A passing VREC covering WO-P3-001 and VER-P3-001 at the candidate commit.

## Rollback criteria and procedure

Discard the disposable test project if replay fails. Retain the verification record and exact evidence.
