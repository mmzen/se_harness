+++
id = "VER-P3-001"
type = "verification"
title = "Assert the greeting independently"
status = "approved"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"

[relations]
verifies = ["REQ-P3-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-11T06:03:07Z"
decided_by = "test-owner"
reason = "Synthetic test definition approved for lifecycle rehearsal."
+++

# Verification Contract: Assert the greeting independently

## Independence

Expected text is fixed by REQ-P3-001 and SPEC-P3-001, not candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-001 | test | exact greeting assertion | Equals Hello rehearsal |

## Acceptance scenarios

Execute `assert-greeting` against the local fixture. The assertion compares the return value of `greeting()` to the string `Hello rehearsal`.

## Evidence retention

Retain the actual assertion result in `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json`. The assertion record includes the command argv, exit code and exact stdout.
