+++
id = "RISK-P3-001"
type = "risk"
title = "Disposable test evidence may not survive project teardown"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
description = "Test evidence exists only in the disposable hosted project. If the project is discarded before export, all evidence is lost."
action = "Export immutable snapshots before discarding the test project."
raised_by = "test-executor"
likelihood = 2
impact = 3
score = 6

[relations]
threatens = ["WO-P3-001"]
mitigated_by = ["WO-P3-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-11T06:07:43Z"
reason = "Mitigate by exporting snapshots before project teardown."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-11T06:06:29Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-11T06:07:43Z"
decided_by = "test-owner"
reason = "Mitigate by exporting snapshots before project teardown."
+++

# Risk: Disposable test evidence may not survive project teardown

## Description

Test evidence exists only in the disposable hosted project. If the project is discarded before export, all evidence is lost.

## Next action

Export immutable snapshots before discarding the test project.
