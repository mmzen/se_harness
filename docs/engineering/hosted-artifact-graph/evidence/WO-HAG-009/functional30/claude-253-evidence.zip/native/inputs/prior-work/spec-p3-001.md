+++
id = "SPEC-P3-001"
type = "specification"
title = "Fixed rehearsal greeting specification"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
contract = "Return the fixed greeting without external effects."

[relations]
specifies = ["REQ-P3-001"]
+++

# Specification: Fixed rehearsal greeting specification

## In plain words

The greeting function returns a fixed string with no side effects.

## Scope

This specification governs the output of `greeting()`. It does not govern how the function is deployed or called.

## Rules

**P3-GREET-001.** The function `greeting()` returns the string `Hello rehearsal`.

## Examples

**Given** the fixture source is unchanged, **when** `greeting()` is called, **then** it returns `Hello rehearsal` per P3-GREET-001.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-001 | P3-GREET-001 |
