+++
id = "REL-P3-001"
type = "release_contract"
title = "Test release record for version 0.0.1"
status = "approved"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"

[relations]
gates = ["WO-P3-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-11T06:03:07Z"
decided_by = "test-owner"
reason = "Synthetic test release contract approved for lifecycle rehearsal."
+++

# Release Contract: Test release record for version 0.0.1

## Release unit

Test version 0.0.1 binds this work and its verified test candidate. No tags, publication, or deployment.

## Required evidence

A verified VREC covering WO-P3-001 and VER-P3-001 with exact greeting assertion evidence.

## Rollback criteria and procedure

Discard the disposable test project if replay fails. Retain the verification record and exact evidence.
