```toml
artifact = "WO-P3-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "bca7041c819f096ec3c38bad0f91d737888c2f16ca4544bf4f5331c2ec225367"
rebound_at = "2026-10-11T06:20:47Z"
```

# WO-P3-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
