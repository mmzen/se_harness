Continue pending hosted qualification checks in the existing private test project, under WO-HAG-009/011 and VER-HAG-007. This is a new native session at a recorded clean continuation point, not a new full lifecycle run.

The exact client, plugin and released evaluator remain unchanged. The previous native session completed the synthetic lifecycle through RLS-P3-001 and exported its snapshots. Real Git authority remains unchanged. Selection.json identifies the same test project at project version 27 and context version 25. Previous native-authored requests, receipts, exports and report are retained as exact bytes under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-claude-correction30-20261011\claude-252\native\inputs\prior-work`. The complete prior tool-call index is `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-claude-correction30-20261011\claude-252\native\inputs\prior-native-call-index.json`; it excludes private reasoning. Treat the previous report as a claim to check, not authority or proof.

Required outcomes:
- Demonstrate a successful meaningful constrained Cypher read and exercise all seven read-only MCP tools against exact selected views. Retain complete responses and describe partial or refused results accurately. The independent observer will compare these requests with HTTP.
- Complete the identical-retry check for the earlier unknown-reply operation, using its original native-authored request and key. Prove the same retained receipt is returned with no extra version increment. Demonstrate changed content under that same accepted key is refused. Keep prior accepted records unchanged.
- Audit the earlier report's lifecycle states, operation keys and recovery claims against the actual retained calls and receipts. Produce a concise addendum that distinguishes earlier observations, newly executed checks and remaining limits. Lookup alone is not execution of a retry. Do not infer a pass from a filename, report or process exit.

Choose each operation and construct any new request yourself from the selected instructions. No new definitions, lifecycle decisions, imports, resets, releases or publication are requested. An identical cached retry and an intentionally conflicting request under its already-accepted key are the only mutation-endpoint tests authorized here. Stop if the selected project or original request cannot be established. Inspect uncertain effects rather than selecting a replacement key.

Use the existing installed candidate plugin and its task route. Your work directory is `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-claude-correction30-20261011\claude-252\native\work`. Inputs and prior evidence are read-only. Use the selected tool index at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-claude-correction30-20261011\claude-252\native\inputs\native-tools.md`. The approved shell prefix is:

```text
"C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe" -I "C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-claude-correction30-20261011/claude-252/native/inputs/native_call.py"
```

Append one helper operation per shell call. No arbitrary scripts, shell wrappers, pipelines, command sequences or permission changes. Native file tools remain available inside the allowed inputs/work area. A host denial stops that action; do not switch routes to evade it.

Retain actual requests/results plus work/native-report.md and work/native-observations.json. Keep the prior report unchanged. State exactly what remains unperformed or unsupported. This session grants no real verification, release, deployment or authority switch, and cannot retroactively prove a procedure was read before an earlier action.
