"""Retained observation, independent replay and owned test-container shutdown."""
from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_review28.py').read_text().replace('hag-hosted-next28-20261011','hag-claude-correction30-20261011').replace('package28','package30').replace('native-lifecycle28','native-lifecycle30')
source=source.replace(",'--limit','99'",'')
exec(compile(source,'functional30-review','exec'),{'__file__':str(W/'hag_review28.py'),'__name__':'__main__'})
