"""Bounded instruction correction; existing WO-HAG-011 authority."""
import hashlib,json,os,re,subprocess,sys,tempfile,tomllib,zipfile
from pathlib import Path
import hag_efficiency_plan as p
W,R,D=p.W,p.R,p.D;O=W/'hag-claude-correction30-20261011';O.mkdir(exist_ok=True);p.O=O
H=Path('C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe')
E=D/'evidence/WO-HAG-011/release-guidance30'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
 assert not f.exists(),f
 f.parent.mkdir(parents=True,exist_ok=True)
 f.write_bytes(v if isinstance(v,bytes) else (v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
def git(*a):return subprocess.check_output(['git',*a],cwd=R,encoding='utf-8').strip()
mode=sys.argv[1]
if mode in ('test','test-workspace','test-host'):
 sys.path.insert(0,str(R));from se_harness.resources import section_view
 guide=R/'plugins/verity-plane/common/skills/change/references/hosted-test-lifecycle.md'
 selectors=sorted(set(re.findall(r'`(docs/engineering/[^`]+#[^`]+)`',guide.read_text())))
 for s in selectors:
  f,head=s.split('#');raw=(p.RES/f).read_bytes();section_view(raw,resource=f,path=str(p.RES/f),release={'version':'0.22.1'},sha256=sha(raw),headings=[head])
 engine=p.P.parent.parent/'Lib/site-packages/se_harness/provenance.py'
 lines=engine.read_text().splitlines();i=next(i for i,x in enumerate(lines) if 'contract_metadata.get("candidate_commit", commit)' in x)
 if mode=='test':put(O/'guidance-review.json',{'outcome':'pass','selectors':selectors,'release_pin_source':str(engine),'source_sha256':sha(engine.read_bytes()),'exact_source_lines':lines[i-3:i+3],'review':'Optional candidate pin inherits the final VREC candidate when absent; explicit mismatch remains refused. No accepted record or evaluator policy changed.'})
 scratch=Path('C:/Users/mathi/AppData/Local/Temp/hag30') if mode=='test-host' else W.parent/'t30';scratch.mkdir(exist_ok=True);os.environ.update(TEMP=str(scratch),TMP=str(scratch));tempfile.tempdir=str(scratch)
 for label,args in [('focused-host' if mode=='test-host' else 'focused-workspace',[H,'-X','utf8','-B','-m','unittest','discover','-s','tests/hosted_artifact_graph','-p','test_native*.py']),('source-host' if mode=='test-host' else 'source',[H,'-X','utf8','-B','scripts/run_tests.py']),('distribution',[H,'-X','utf8','-B','scripts/validate_release_distributions.py','--root','.']),('smoke',[H,'-X','utf8','-B','-m','se_harness','--help'])]:
  p.run(label,args,cwd=R);x=load(O/(label+'.json'));print(label,x['exit'],round(x['elapsed_seconds'],1),x['stderr'][-250:],flush=True)
elif mode=='check':
 paths=git('diff','--name-only').splitlines()+[(E/n).relative_to(R).as_posix() for n in ['review.md','checks.zip','checks-inventory.json']]
 scope=tomllib.loads((D/'work-orders/WO-HAG-011.md').read_text().split('+++')[1])['execution_scope']['paths']
 assert all(any(x==s or s.endswith('/') and x.startswith(s) for s in scope) for x in paths)
 args=['check',R,'--artifact','WO-HAG-011','--checkpoint','scope','--changes-complete']
 for x in paths:args+=['--changed-path',x]
 for label,args in [('scope',args+['--json']),('preflight',['preflight',R,'--work-order','WO-HAG-011','--phase','review','--json']),('validation',['validate',R,'--json'])]:
  p.gov(label,*args);print(label,'pass',flush=True)
elif mode=='commit':
 assert git('rev-parse','HEAD')=='2cccf95c214e4126246eb2844fc320a13651fedf'
 names=['focused-host','source-host','distribution','smoke','scope','preflight','validation']
 assert all(load(O/(n+'.json'))['exit']==0 for n in names)
 names+=['focused','focused-workspace','source']
 E.mkdir(exist_ok=False)
 with zipfile.ZipFile(E/'checks.zip','x',zipfile.ZIP_DEFLATED) as z:
  for n in names+['guidance-review','final-content-review']:z.write(O/(n+'.json'),n+'.json')
 put(E/'checks-inventory.json',{'archive':'checks.zip','sha256':sha((E/'checks.zip').read_bytes()),'files':[{'path':n+'.json','sha256':sha((O/(n+'.json')).read_bytes())} for n in names+['guidance-review','final-content-review']]})
 put(E/'review.md','''# Claude release-binding correction

The functional29 Claude run approved a release contract pinned to the imported
fixture commit. Its verified disposable candidate was different. Released 0.22.1
refused release preparation with WEX404. Claude then attempted to revise the
protected contract. The original failures and incomplete result remain at
`../../WO-HAG-009/functional29/assessment.md`.

## Correction

- At contract drafting, distinguish the fixture from the future verified candidate.
  Defer its completion and approval until the final verified candidate is known;
  preserve any actual supplied constraint. Do not use an absent optional field
  to avoid the canonical template's candidate-content requirement.
- At release preparation, compare the selected contract with the final VREC.
- Stop protected-record revisions instead of trying changed content or history.
  A new draft does not replace the accepted record or supply amendment authority.
- Add the exact decision-disposition procedure and make authority prerequisites explicit.

Three plugin Markdown references change. The selected released source confirms
the optional-pin behavior; its exact source fragment and hash are retained.
No runtime, evaluator rule, schema, permissions or accepted criteria change.
This is a functional correction. Performance optimization remains deferred.

## Validation and qualification

Released section selectors resolve. Focused native support tests, the full source
suite, distribution checks, CLI smoke, scope, review preflight and released
validation pass. Exact commands and outputs are in checks.zip.
The initial focused invocation failed because the host sandbox's temporary
directory denied file access. Its output is retained; the rerun used writable
task storage. No product behavior or test criterion changed for this rerun.
The sandboxed full suite also failed on denied atomic hardlinks and loopback
sockets. It is retained alongside the ordinary host rerun in a short disposable
temporary directory. The rerun keeps every test; no assertion was weakened.

Next: package this exact clean candidate and rerun Claude's affected NQ cases
from a fresh private project, without supplied requests or operator mutations.
Retain the prior Codex pass; it does not by itself qualify the changed guidance.
No new native pass, work completion or human verification is claimed here.
''')
 paths=git('diff','--name-only').splitlines()+git('ls-files','--others','--exclude-standard').splitlines()
 scope=tomllib.loads((D/'work-orders/WO-HAG-011.md').read_text().split('+++')[1])['execution_scope']['paths'];assert all(any(x==s or s.endswith('/') and x.startswith(s) for s in scope) for x in paths)
 p.run('diff-check',['git','diff','--check'],cwd=R);p.run('stage',['git','add','--',*paths],cwd=R);p.run('staged-check',['git','diff','--cached','--check'],cwd=R)
 p.run('commit',['git','commit','-m','Clarify hosted release binding and protected-record recovery','-m','Harness-Work-Order: WO-HAG-011'],cwd=R)
 assert not git('status','--porcelain');put(O/'candidate-30.json',{'commit':git('rev-parse','HEAD'),'base':'55caaada508495bea7d97effd27644d1ce8373da'});print(git('rev-parse','HEAD'))
elif mode=='build':
 source=(W/'hag_efficiency_package03.py').read_text().replace('hag-efficiency-proposal-20261008','hag-claude-correction30-20261011')
 for a,b in [('candidate-03','candidate-30'),('build03','build30'),('package03','package30'),('client03','client30'),('native-efficiency03','native-lifecycle30'),("-03'","-30'")]:source=source.replace(a,b)
 exec(compile(source,'exact-build30','exec'))
else:raise ValueError(mode)
