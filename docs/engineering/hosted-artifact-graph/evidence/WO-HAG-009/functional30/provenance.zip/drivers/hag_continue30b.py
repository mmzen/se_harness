"""Separate historical evidence inventory from the released-instruction lookup."""
from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_continue30.py').read_text().replace("root=O/'claude-252'","root=O/'claude-253'").replace('claude252-live-probe','claude253-live-probe')
old="(native/'inputs/inventory.json').write_bytes((json.dumps({'files':inventory},indent=2)+'\\n').encode())"
new="""put(root/'complete-inputs-inventory.json',{'files':inventory})
 keep={'prior-work/lifecycle-transition-defs-apply.json','prior-work/native-report.md','prior-work/native-observations.json','prior-native-call-index.json','prior-session.json'}
 lookup=[x for x in inventory if not x['relative'].startswith('prior-work/') or x['relative'] in keep]
 assert len(json.dumps(lookup).encode())<65536
 (native/'inputs/inventory.json').write_bytes((json.dumps({'files':lookup},indent=2)+'\\n').encode())"""
assert old in source
source=source.replace(old,new)
source=source.replace('Use the selected tool index at', 'Prior evidence remains readable through native Read; the helper lookup index covers packaged instructions and the named prior report, call index and original request. Use the selected tool index at')
exec(compile(source,'focused-continuation-staging-correction','exec'),{'__file__':__file__,'__name__':'__main__'})
