"""Read-only progress metadata, no private provider reasoning."""
from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_watch29.py').read_text().replace('hag-functional29-20261011','hag-claude-correction30-20261011').replace("('claude','codex')","('claude',)").replace('-241/native','-251/native')
exec(compile(source,'functional30-watch','exec'),{'__file__':__file__,'__name__':'__main__'})
