"""Fresh native continuation of pending checks, reusing exact prior native evidence."""
import json,os,shutil,subprocess,sys,hashlib
from pathlib import Path
import hag_efficiency_plan as p
W,R=p.W,p.R;O=W/'hag-claude-correction30-20261011';p.O=O;old=O/'claude-251';root=O/'claude-252';native=root/'native'
H=Path('C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe');EXE=Path('C:/Users/mathi/.local/bin/claude.exe')
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def put(f,v):
 assert not f.exists(),f
 f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(v if isinstance(v,bytes) else (v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
def status(label):
 s=load(root/'selection.json');t=next(x['token'] for x in load(root/'credentials.json')['principals'] if x['id']=='operator')
 a=[s['client_python'],'-I','-m','se_harness','remote','status','--endpoint',s['endpoint'],'--project',s['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--json']
 v=subprocess.run(a,cwd=W,env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=t),capture_output=True,encoding='utf-8',check=True)
 put(root/(label+'-command.json'),{'argv':a,'cwd':str(W),'exit':v.returncode,'stdout':v.stdout,'stderr':v.stderr});x=json.loads(v.stdout);put(root/(label+'.json'),x);return x
def boundary():
 paths=['C:/Users/mathi/.codex/config.toml','C:/Users/mathi/.claude/settings.json','C:/Users/mathi/.claude/plugins/installed_plugins.json']
 return {'settings':[{'path':f,'sha256':sha(Path(f).read_bytes()) if Path(f).exists() else None} for f in paths],'repository_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'tracked_diff':subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=R).decode().strip()}
mode=sys.argv[1]
if mode=='stage':
 assert load(old/'native/session.json')['exit']==0 and not root.exists()
 root.mkdir();shutil.copyfile(old/'credentials.json',root/'credentials.json');put(root/'selection.json',(old/'selection.json').read_bytes());put(root/'combination.json',(old/'combination.json').read_bytes())
 shutil.copytree(old/'native/inputs',native/'inputs');(native/'work').mkdir()
 prior=native/'inputs/prior-work';shutil.copytree(old/'native/work',prior)
 put(native/'inputs/prior-native-call-index.json',(old/'native-call-index.json').read_bytes())
 put(native/'inputs/prior-session.json',(old/'native/session.json').read_bytes())
 s=load(old/'native-selection.json');raw=json.dumps(s).replace(json.dumps(str(old/'native'))[1:-1],json.dumps(str(native))[1:-1]).replace((old/'native').as_posix(),native.as_posix());s=json.loads(raw)
 s['continuation']={'previous_trial':'claude-251','project_version':27,'context_id':'1262e8c0-289f-41b6-917c-9b0574a05890','context_version':25,'prior_work':str(prior),'prior_call_index':str(native/'inputs/prior-native-call-index.json'),'scope':'Finish pending reads, retry evidence and report assessment. Existing test records stay unchanged.'};put(root/'native-selection.json',s)
 raw=(old/'permissions.json').read_text()
 for a,b in [((old/'native').as_posix(),native.as_posix()),((old/'native').as_posix().replace('C:','//c'),native.as_posix().replace('C:','//c')),(json.dumps(str(old/'native'))[1:-1],json.dumps(str(native))[1:-1])]:raw=raw.replace(a,b)
 assert 'claude-251' not in raw;put(root/'permissions.json',json.loads(raw))
 sys.path.insert(0,str(R/'tests/hosted_artifact_graph'));from qualify_agents import shell_prefix
 task=f'''Continue pending hosted qualification checks in the existing private test project, under WO-HAG-009/011 and VER-HAG-007. This is a new native session at a recorded clean continuation point, not a new full lifecycle run.

The exact client, plugin and released evaluator remain unchanged. The previous native session completed the synthetic lifecycle through RLS-P3-001 and exported its snapshots. Real Git authority remains unchanged. Selection.json identifies the same test project at project version 27 and context version 25. Previous native-authored requests, receipts, exports and report are retained as exact bytes under `{prior}`. The complete prior tool-call index is `{native/'inputs/prior-native-call-index.json'}`; it excludes private reasoning. Treat the previous report as a claim to check, not authority or proof.

Required outcomes:
- Demonstrate a successful meaningful constrained Cypher read and exercise all seven read-only MCP tools against exact selected views. Retain complete responses and describe partial or refused results accurately. The independent observer will compare these requests with HTTP.
- Complete the identical-retry check for the earlier unknown-reply operation, using its original native-authored request and key. Prove the same retained receipt is returned with no extra version increment. Demonstrate changed content under that same accepted key is refused. Keep prior accepted records unchanged.
- Audit the earlier report's lifecycle states, operation keys and recovery claims against the actual retained calls and receipts. Produce a concise addendum that distinguishes earlier observations, newly executed checks and remaining limits. Lookup alone is not execution of a retry. Do not infer a pass from a filename, report or process exit.

Choose each operation and construct any new request yourself from the selected instructions. No new definitions, lifecycle decisions, imports, resets, releases or publication are requested. An identical cached retry and an intentionally conflicting request under its already-accepted key are the only mutation-endpoint tests authorized here. Stop if the selected project or original request cannot be established. Inspect uncertain effects rather than selecting a replacement key.

Use the existing installed candidate plugin and its task route. Your work directory is `{native/'work'}`. Inputs and prior evidence are read-only. Use the selected tool index at `{native/'inputs/native-tools.md'}`. The approved shell prefix is:

```text
{shell_prefix(s['approved_shell_argv_prefix'])}
```

Append one helper operation per shell call. No arbitrary scripts, shell wrappers, pipelines, command sequences or permission changes. Native file tools remain available inside the allowed inputs/work area. A host denial stops that action; do not switch routes to evade it.

Retain actual requests/results plus work/native-report.md and work/native-observations.json. Keep the prior report unchanged. State exactly what remains unperformed or unsupported. This session grants no real verification, release, deployment or authority switch, and cannot retroactively prove a procedure was read before an earlier action.
'''
 put(root/'native-task.md',task)
 inventory=[{'path':str(f),'relative':f.relative_to(native/'inputs').as_posix(),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f in sorted((native/'inputs').rglob('*')) if f.is_file() and f.name!='inventory.json']
 (native/'inputs/inventory.json').write_bytes((json.dumps({'files':inventory},indent=2)+'\n').encode())
 put(root/'stage-evidence.json',{'candidate':s['qualification_candidate'],'case':'Focused continuation of NQ-03 reads, NQ-04 retry, NQ-05 reporting; not a fresh full lifecycle pass','project_version':27,'context_version':25,'prior_trial':'claude-251','prior_data':'Exact existing native-authored work and complete tool-call metadata; no completed new request or query supplied.','task_sha256':sha(task.encode()),'inputs_inventory_sha256':sha((native/'inputs/inventory.json').read_bytes()),'permissions_sha256':sha((root/'permissions.json').read_bytes()),'assistance':'Initial task identifies the pending outcomes and asks for an evidence-backed audit; no query syntax, corrective command or step sequence supplied.'})
 print('Focused continuation staged; original project and native evidence preserved')
elif mode=='auth':
 probe=root/'auth-probe';probe.mkdir(exist_ok=False)
 v=p.run('claude252-live-probe',[EXE,'-p','--no-session-persistence','--tools','','--model','claude-opus-4-6','--output-format','json','Authorized availability probe. Reply exactly AUTH_OK. Use no tools, read no files, change nothing.'],cwd=probe)
 assert v.get('result','').strip()=='AUTH_OK' and not v.get('is_error');put(root/'auth-review.json',{'AUTH_OK_observed':True,'raw_provider_response':'Retained privately; excluded from publication.'});print('Live authentication passed')
elif mode=='run':
 assert load(root/'auth-review.json')['AUTH_OK_observed'];x=status('initial-status');assert x['ready'] and x['project_version']==27
 put(root/'boundary-before-native.json',boundary())
 args=[H,'-X','utf8','-B',R/'tests/hosted_artifact_graph/qualify_agents.py','--host','claude','--executable',EXE,'--selection',root/'native-selection.json','--credentials',root/'credentials.json','--task',root/'native-task.md','--output',native,'--prepared-inputs','--timeout','1200','--instruction-section','docs/engineering/harness/COMMUNICATION.md#communication','--permission-settings',root/'permissions.json','--model','claude-opus-4-6']
 code=subprocess.call(list(map(str,args)),cwd=W);put(root/'boundary-after-native.json',boundary());raise SystemExit(code)
else:raise ValueError(mode)
