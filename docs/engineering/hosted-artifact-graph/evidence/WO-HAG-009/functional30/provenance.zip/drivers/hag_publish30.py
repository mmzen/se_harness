"""Publish the bounded correction and actual qualification evidence to draft PR 543."""
from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_publish28.py').read_text()
source=source.replace('hag-hosted-next28-20261011','hag-claude-correction30-20261011').replace('WO-HAG-009/diagnostic28','WO-HAG-009/functional30')
source=source.replace("C='dfcf1e976123836f00354a228c8e72a833f2e3cf';PRE='dd1c4730e7b4973fae87bc0a6b1c9a871f1219c7'", "C='912c2f4ba9f537fc0e2f9f64facb925de86fb2b6';PRE='2cccf95c214e4126246eb2844fc320a13651fedf'")
for stem in ('report','evidence-commit','pr-note','pr-body','pr-event','check-pr','main-controls','source-controls','write-guard','push','pr-edit','published-readback','report-readback'):
 source=source.replace(stem+'28',stem+'30')
source=source.replace('pr-before-28.json','pr-before-30.json')
source=source.replace("body=body.replace('## Latest result\\n',note+'\\n## Previous full qualification result\\n',1)",'body=note')
source=source.replace('Retain focused Claude hosted lifecycle diagnostic and limitations','Retain Claude release correction and remaining qualification gaps')
# Visible native exchanges are protected evidence. Retain whitespace diagnostics;
# do not normalize their bytes or invent a repository formatting requirement.
source=source.replace("p.run('report30-staged-check',['git','diff','--cached','--check'],cwd=R)", "p.run('report30-staged-check',['git','diff','--cached','--check'],cwd=R,allowed=(0,2))")
exec(compile(source,'publish-functional30','exec'),{'__file__':str(W/'hag_publish28.py'),'__name__':'__main__'})
