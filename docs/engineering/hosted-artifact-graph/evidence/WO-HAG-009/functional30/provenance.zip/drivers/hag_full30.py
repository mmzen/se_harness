"""Fresh autonomous Claude functional qualification of corrected guidance."""
from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_full29.py').read_text()
source=source.replace('hag-functional29-20261011','hag-claude-correction30-20261011').replace('hag-hosted-next28-20261011','hag-claude-correction30-20261011')
source=source.replace("trial='241'","trial='251'").replace('-241-boundary','-251-boundary')
for a,b in [('candidate-28','candidate-30'),('package28','package30'),('client28','client30'),('build28','build30'),('native-lifecycle28','native-lifecycle30'),('hag-full29-','hag-full30-')]:source=source.replace(a,b)
exec(compile(source,'functional30-driver','exec'),{'__file__':str(W/'hag_full29.py'),'__name__':'__main__'})
