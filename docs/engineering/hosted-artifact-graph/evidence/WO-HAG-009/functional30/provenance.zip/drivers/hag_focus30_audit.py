"""Observed continuation facts; no native report is accepted as its own proof."""
from pathlib import Path
import json,hashlib
W=Path(__file__).parent;O=W/'hag-claude-correction30-20261011';root=O/'claude-253';native=root/'native';old=O/'claude-251/native/work'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
assert (native/'session.json').exists()
original=(old/'lifecycle-transition-defs-apply.json').read_bytes();key=json.loads(original)['operation_key']
receipt=json.loads(load(old/'lc-transition-defs-lookup.json')['stdout'])
calls=[]
for line,s in enumerate((native/'events.jsonl').read_text().splitlines(),1):
 try:e=json.loads(s)
 except ValueError:continue
 for b in e.get('message',{}).get('content',[]) if isinstance(e.get('message'),dict) else []:
  if b.get('type')=='tool_use':calls.append({'event_line':line,'tool':b['name'],'input':b['input']})
attempts=[]
for f in (native/'work').rglob('*.json'):
 try:x=load(f)
 except ValueError:continue
 a=x.get('argv',[])
 if 'rehearse' not in a or '--request' not in a:continue
 req=Path(a[a.index('--request')+1]);b=req.read_bytes();request=json.loads(b)
 try:response=json.loads(x.get('stdout',''))
 except ValueError:response={}
 attempts.append({'record':f.relative_to(native).as_posix(),'request':str(req),'request_sha256':sha(b),'original_exact_bytes':b==original,'same_key':request.get('operation_key')==key,'exit':x.get('exit'),'outcome':response.get('outcome'),'error':response.get('error'),'receipt_exact_match':response==receipt,'receipt_id':response.get('receipt_id'),'request_digest':response.get('request_digest'),'versions':response.get('versions')})
parity=[load(f) for f in sorted((O/'native-parity-continueb30').glob('*.json'))]
full=load(root/'complete-inputs-inventory.json')['files'];mismatches=[x['relative'] for x in full if sha((native/'inputs'/x['relative']).read_bytes())!=x['sha256']]
integrity={'checked_files':len(full),'all_unchanged':not mismatches,'mismatches':mismatches}
facts={'trial':'claude-253','kind':'Focused continuation, not a new full lifecycle qualification','native_session':load(native/'session.json'),'original_operation_key':key,'original_request_sha256':sha(original),'retry_attempts':attempts,'initial_project_version':load(root/'initial-status.json')['project_version'],'final_project_version':load(root/'independent-final-status.json')['project_version'],'successful_matching_tools':sorted({x['tool'] for x in parity if x.get('http_status')==200 and x['exact_match']}),'parity_count':len(parity),'parity_results':[{'tool':x['tool'],'http_status':x.get('http_status'),'exact_match':x['exact_match'],'native_result_present':x.get('native_result') is not None} for x in parity],'complete_prior_input_integrity':integrity,'boundary':load(root/'boundary-comparison.json'),'report_exists':(native/'work/native-report.md').exists(),'mutation_calls':[x for x in calls if x['tool']=='Bash' and any(' remote '+verb in x['input'].get('command','') for verb in ['rehearse','import','draft-open','create-artifact','revise-artifact','freeze','export'])]}
for name,v in [('complete-inputs-integrity.json',integrity),('native-call-index.json',{'calls':calls,'omissions':'Private reasoning and non-tool messages excluded.'}),('independent-observation.json',facts)]:
 p=root/name;assert not p.exists();p.write_bytes((json.dumps(v,indent=2)+'\n').encode())
print(json.dumps({k:v for k,v in facts.items() if k not in ['native_session','mutation_calls','parity_results']},indent=2))
