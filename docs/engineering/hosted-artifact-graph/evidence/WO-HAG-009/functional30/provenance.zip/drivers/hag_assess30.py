"""Independent assessment of the full Claude run; preserve unresolved cases."""
import json,hashlib,tomllib
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-claude-correction30-20261011';r=O/'claude-251';w=r/'native/work'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
session=load(r/'native/session.json');replay=load(r/'independent-replay/assessment.json')
assert session['exit']==0 and not session['timed_out']
assert replay['state']=='accepted_calls_and_native_exports_replayed' and len(replay['cases'])==10
assert load(r/'boundary-comparison.json')['equal'] and load(r/'input-integrity.json')['all_unchanged']
parity=[load(f) for f in sorted((O/'native-parity-full30').glob('*.json'))]
assert all(x['exact_match'] for x in parity)
assert len([x for x in parity if x['http_status']==200])==6
assert len([x for x in parity if x['tool']=='cypher' and x['http_status']==400])==8
calls=[]
for line,raw in enumerate((r/'native/events.jsonl').read_text().splitlines(),1):
 try:e=json.loads(raw)
 except ValueError:continue
 for b in e.get('message',{}).get('content',[]) if isinstance(e.get('message'),dict) else []:
  if b.get('type')=='tool_use':calls.append({'event_line':line,'tool':b['name'],'input':b['input']})
applies=[x for x in calls if x['tool']=='Bash' and 'remote rehearse --request' in x['input'].get('command','') and 'lifecycle-transition-defs-apply.json' in x['input']['command']]
assert len(applies)==1
meta=lambda name:tomllib.loads(next((w/'export-later/files').rglob(name+'.md')).read_text().split('+++')[1])
vrec,rls,rel=meta('VREC-P3-001'),meta('RLS-P3-001'),meta('REL-P3-001')
assert vrec['commit']==rls['commit']=='f246727359acc7fb207ae3fbc85dd23bcd6d7b06'
assert rel['status']=='approved' and 'candidate_commit' not in rel
result={'trial':'claude-251','candidate':load(O/'candidate-30.json')['commit'],'contract':'VER-HAG-007','functional_result':'incomplete',
 'cases':{
 'NQ-01':{'result':'incomplete','review':'Packaged drafting/lifecycle/evidence references were read. Required later action sections and before-action prerequisites are not established by the read trace. REL was approved without a known candidate despite the new drafting guidance. The Cypher reading guide and its schema references were not read. Do not infer these reads from links or successful operations.'},
 'NQ-02':{'result':'pass','accepted_lifecycle_operations_replayed':10,'review':'Native authoring, test approvals/start, risk/decision, greeting assertion, handoff/completion, VREC verification and RLS release completed. Exact released replay matched all ten accepted operations. Both records bind the same actual disposable candidate; the prior WEX404 did not recur. This mechanical lifecycle result does not resolve the instruction-adherence finding.'},
 'NQ-03':{'result':'incomplete','successful_mcp_http_matches':6,'cypher_refusals':8,'review':'Out-of-scope handoff and stale-project refusal after a new context draft were observed, with fresh handoff recovery. Six tools returned successful matching reads. All eight Cypher calls were unsupported syntax and matched HTTP refusals. No successful Cypher read was demonstrated.'},
 'NQ-04':{'result':'incomplete','review':'Dropped reply was recovered by operation lookup. Changed content under the accepted risk key was refused. The original approval apply was called only once; subsequent lookups are not identical retries. The report claims a retry that is absent from the complete call trace.'},
 'NQ-05':{'result':'incomplete','native_exports_reconstructed':2,'review':'Both snapshots reconstructed with exact files, Git candidate objects and released validation. Monitored boundaries and inputs are unchanged. The report misattributes work start to the approval operation, claims an unobserved identical retry and counts six Cypher attempts where eight were observed. Preserve the report and issue an evidence-backed addendum.'}},
 'native_elapsed_seconds':session['elapsed_seconds'],'native_calls':load(O/'claude-251-summary.json')['native_calls'],'peak_input_context':load(O/'claude-251-summary.json')['peak_input_context'],'model_reported':'claude-opus-4-6',
 'test_candidate_P':vrec['commit'],'fixture_source_S':'5820415917e87b64d80bad2f7c39c6d18d692829',
 'interventions':'Setup and supplied synthetic decisions only; automatic reply drop. No proctor correction, mutation, command or interruption during this run.',
 'limits':['The native report is source evidence, not the qualification verdict.','No combined qualification or human verification acceptance.','Elapsed time is not a performance-improvement claim; performance work remains deferred.','No real release, public deployment, host-plugin update or authority cutover.']}
for name,value in [('independent-assessment.json',result),('native-call-index.json',{'trial':'claude-251','calls':calls,'complete':True,'omissions':'Private reasoning and non-tool messages excluded. Exact tool inputs and event lines retained.'})]:
 f=r/name;assert not f.exists();f.write_bytes((json.dumps(value,indent=2)+'\n').encode())
print(json.dumps({'lifecycle':'pass','overall':'incomplete','calls':len(calls),'cypher_refusals':8,'missing_identical_retry':True}))
