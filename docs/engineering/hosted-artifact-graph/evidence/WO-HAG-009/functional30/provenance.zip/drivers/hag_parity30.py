"""Immediate independent comparison of observed native Claude MCP reads."""
from pathlib import Path
import sys
W=Path(__file__).parent
source=(W/'hag_native_parity19.py').read_text().replace('hag-agent-qualification-execution-20261007','hag-claude-correction30-20261011')
source=source.replace("hosts={'codex':O/'codex/native03','claude':O/'claude/native02/work/sonnet01'}", "hosts={'claude-251':O/'claude-251/native'}")
source=source.replace('time.monotonic()+3800','time.monotonic()+3900')
sys.argv=[__file__,'full30']
exec(compile(source,'functional30-parity','exec'),{'__file__':__file__,'__name__':'__main__'})
