"""Independent verdict and review report from observed results."""
import json,hashlib,re
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'hag-claude-correction30-20261011';root=O/'claude-253';E=p.D/'evidence/WO-HAG-009/functional30'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
facts=load(root/'independent-observation.json');metrics=load(O/'claude-253-summary.json')
assert facts['successful_matching_tools']==['check','compare','cypher','impact','lineage','revision','work-context']
assert facts['initial_project_version']==facts['final_project_version']==27
assert facts['boundary']['equal'] and facts['complete_prior_input_integrity']['all_unchanged']
assert len(facts['retry_attempts'])==2 and len(facts['mutation_calls'])==2
assert any(x['original_exact_bytes'] and x['receipt_exact_match'] for x in facts['retry_attempts'])
assert any(x['same_key'] and not x['original_exact_bytes'] and x['error']['code']=='HAG_REMOTE_KEY_REUSE' for x in facts['retry_attempts'])
queries=[load(f) for f in (O/'native-parity-continueb30').glob('*cypher.json')]
assert len(queries)==12 and sum(x['http_status']==200 for x in queries)==1
success=next(x for x in queries if x['http_status']==200)
assert success['exact_match'] and success['native_result']['data']['rows']
assessment={'trial':'claude-253','candidate':load(O/'candidate-30.json')['commit'],'overall':'incomplete','kind':'Unassisted focused continuation from preserved project/context versions; not a fresh lifecycle pass','functional_results':{'NQ-03':'All seven read tools now have successful exact MCP/HTTP comparisons. Full-run scope/stale refusals remain separate evidence.','NQ-04':'Pass across the original dropped reply and this continuation: exact original request and receipt, no version increment, changed content under the same key refused.'},'remaining_findings':{'NQ-01':'Only setup/SKILL.md and setup/references/hosted-context.md were read in this continuation, plus delivered COMMUNICATION. No observed read of hosted-reads or the public Cypher references. The full run also lacked later action prerequisite reads and did not follow the new release-contract timing guidance.','NQ-05':['The addendum corrects the original false identical-retry claim and retains the original report, but does not correct work start being attributed to the approval operation.','It treats six original Cypher patterns as accurate; the complete trace has eight distinct queries. It says 181 original calls; the index has 185.','It infers that aliases are mandatory and relationships unsupported. The unchanged grammar permits optional aliases and public relationship paths; Revision exposes status. Failed guessed queries do not establish these broad restrictions.','The addendum omits three denied shell attempts and other tool/input failures captured by the independent summary. Its all-outcomes-complete claim does not close qualification.']},'source_review':{'server/hosted_artifact_graph/cypher.py':sha((p.R/'server/hosted_artifact_graph/cypher.py').read_bytes()),'tests/hosted_artifact_graph/test_runtime.py':sha((p.R/'tests/hosted_artifact_graph/test_runtime.py').read_bytes()),'method':'Read-only grammar/property and existing regression inspection; no new runtime scenario claimed.'},'observations':{'native_elapsed_seconds':facts['native_session']['elapsed_seconds'],'native_calls':metrics['native_calls'],'peak_input_context':metrics['peak_input_context'],'mcp_attempts':facts['parity_count'],'cypher_attempts':12,'cypher_successes':1,'input_files_unchanged':facts['complete_prior_input_integrity']['checked_files']},'limits':['All recorded refusals preserved. Three malformed MCP requests failed native tool validation before a domain result; corresponding HTTP invalid-request refusals are not exact successful response matches.','Successful compare is only a self-compare of context version 25. Full-run earlier/later export reconstruction remains the separate historical snapshot evidence.','No operator recovery command, query or mutation supplied during either native run. Failed prelaunch 252 is retained separately.','No verification acceptance, work-order completion, merge, release, deployment or host-plugin update.']}
f=root/'independent-assessment.json';assert not f.exists();f.write_bytes((json.dumps(assessment,indent=2)+'\n').encode())
text=(O/'report-draft.md').read_text()
text=text.replace('instruction adherence and successful Cypher use are not established.','instruction adherence and accurate final reporting are not established.')
text=text.replace('CONTINUATION_RESULT','''## Focused continuation: `claude-253`

The unchanged package and existing project were used for a separate native
session. It completed in **934.097 seconds (15m 34s)**, with **70 calls** and
**177,246 peak input tokens**. No query, corrective command or operator mutation
was supplied during the session.

- All seven MCP tools produced a successful response that matched an immediate
  independent HTTP read. The observer retained 23 attempts, including refusals.
  Cypher succeeded once out of 12 attempts and returned ten artifact identifiers.
  Compare succeeded only for the same context version on both sides.
- Claude resubmitted the original request bytes under `lc-transition-defs-002`.
  The complete result equals the original retained receipt. Project version
  stayed at 27. A changed reason under the same key returned
  `HAG_REMOTE_KEY_REUSE`, with no new effect.
- The addendum corrects the earlier false retry claim. It leaves other errors
  unresolved: work start was a separate `lc-start-001` operation; the original
  trace has 185 calls and eight distinct Cypher queries.
- The addendum incorrectly generalizes from refused queries: the grammar supports
  public relationship paths and optional aliases, and `Revision` exposes status.
  It also omits three denied shell attempts and other captured failures.

The continuation read only the setup skill and hosted-selection reference, plus
the explicitly supplied communication section. It did not read the required
hosted-read guide or public Cypher references. A successful guessed query does
not establish instruction discovery. **NQ-03 and NQ-04 now have the missing
functional evidence; NQ-01 and NQ-05 remain incomplete.**

Attempt `claude-252` failed before Claude launched: the proctor's historical
evidence index exceeded the existing 64 KiB lookup limit. Attempt 253 preserved
the evidence and used separate complete-evidence and instruction-lookup indexes.
The failure, corrected staging, and unchanged product limits are retained.''')
text=text.replace('CONTINUATION_LINKS','[Continuation visible transcript](claude-253-visible.md),\n+  [addendum as written by Claude](claude-253-report.md),\n+  [exact inventory](claude-253-inventory.json), and\n+  [bounded archive](claude-253-evidence.zip).'.replace('\n+','\n'))
text=text.replace('CONTINUATION_BOUNDARY','''The independent comparison found all 433 continuation input/evidence files
unchanged. Monitored host settings and the real checkout's tracked state were
unchanged during both native runs. The owned service and graph containers were
stopped afterward; their volumes remain preserved.

The next bounded correction should make the hosted-read guide a direct task
route and ground report statements in returned fields and canonical definitions.
Retest affected discovery/reporting behavior; do not rerun unchanged service
qualification or convert successful mechanics into an instruction-compliance pass.''')
E.mkdir(exist_ok=True)
f=E/'assessment.md';assert not f.exists();f.write_bytes(text.encode())
for trial in ['claude-251','claude-253']:
 (E/(trial+'-report.md')).write_bytes((O/trial/'native/work/native-report.md').read_bytes())
index=p.D/'README.md';text=index.read_text();start=text.index('## Latest functional qualification');end=text.index('## Authoring simplification in progress',start)
text=text[:start]+'''## Latest functional qualification

The [Claude correction assessment](evidence/WO-HAG-009/functional30/assessment.md)
records a complete synthetic release, ten independently replayed lifecycle
operations and two exact exports. A focused continuation confirmed all seven
read tools and the identical-retry/conflict checks. Claude still misses required
instruction reads and makes unsupported report claims; combined qualification
remains incomplete. Both original reports and failures are preserved.
The [earlier paired result](evidence/WO-HAG-009/functional29/assessment.md) retains
Codex's pass on its earlier candidate. Performance improvements remain deferred.

'''+text[end:];index.write_bytes(text.encode())
print(json.dumps({'functional_reads':'pass','retry':'pass','overall':'incomplete','remaining':['NQ-01','NQ-05']}))
