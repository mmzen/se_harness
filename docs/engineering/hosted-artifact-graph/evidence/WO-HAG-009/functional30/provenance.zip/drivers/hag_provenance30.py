"""Exact selected build/proctor evidence, with no credentials or raw provider events."""
import json,hashlib,zipfile,re
from pathlib import Path
import hag_efficiency_plan as p
W=p.W;O=W/'hag-claude-correction30-20261011';E=p.D/'evidence/WO-HAG-009/functional30'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
assert (O/'claude-251/native/session.json').exists()
E.mkdir(exist_ok=True);files={}
for n in ['hag_correction30.py','hag_full30.py','hag_full29.py','hag_full27.py','hag_native27.py','hag_parity30.py','hag_native_parity19.py','hag_watch30.py','hag_trace30.py','hag_full27_trace.py','hag_review30.py','hag_review28.py','hag_full27_review.py','hag_retain30.py','hag_full27_retain.py','hag_retain26.py','hag_provenance30.py','hag_efficiency_package03.py']:
 files['drivers/'+n]=(W/n).read_bytes()
for n in ['hag_assess30.py','hag_continue30.py','hag_continue30b.py','hag_parity30_continue.py','hag_parity30_continueb.py','hag_focus30_audit.py','hag_finish30.py','hag_publish30.py']:
 files['drivers/'+n]=(W/n).read_bytes()
for n in ['WO-HAG-009-context-resume252.json','WO-HAG-011-context-resume252.json']:
 files['checks/'+n]=(O/n).read_bytes()
for trial,names in [('claude-252',['prelaunch-failure.json','stage-evidence.json','native-selection.json','native-task.md','initial-status.json','initial-status-command.json','boundary-before-native.json','boundary-after-native.json','auth-review.json']),('claude-253',['auth-review.json','stage-evidence.json','native-selection.json','native-task.md','complete-inputs-inventory.json'])]:
 for n in names:files[trial+'/'+n]=(O/trial/n).read_bytes()
files['claude-252/original-inputs-inventory.json']=(O/'claude-252/native/inputs/inventory.json').read_bytes()
for n in ['claude-auth-review','claude-version','candidate-30','package-guidance-comparison','service-reuse-comparison','server-wheel-members','client-build-30','package-30','client-env-30','client-install-30','build30-replay','WO-HAG-009-context','WO-HAG-011-context']:
 files['checks/'+n+'.json']=(O/(n+'.json')).read_bytes()
for suffix in ['volume-absent','volume-create','source-stage','init','networks','up']:
 n='claude251-'+suffix+'.json';files['setup/'+n]=(O/n).read_bytes()
for n in ['combination','image-metadata','image-package','plugin-assembly','plugin-claude-inventory','plugin-codex-inventory','server-build','source-commit','source-status']:
 files['package/'+n+'.json']=(O/'package30'/(n+'.json')).read_bytes()
tokens=[x['token'].encode() for f in O.glob('*/credentials.json') for x in load(f)['principals']]
for n,b in files.items():
 assert not any(t in b for t in tokens),n
 assert not re.search(rb'sk-ant-(?:oat|ort|api)',b),n
archive=E/'provenance.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
index={'archive':archive.name,'sha256':sha(archive.read_bytes()),'files':[{'path':n,'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())],'limits':'No raw provider authentication response, private reasoning, credentials, account stores or full environment. Known test tokens checked absent. Source/focused checks and review retained separately at WO-HAG-011/release-guidance30.'}
(E/'provenance-inventory.json').write_bytes((json.dumps(index,indent=2)+'\n').encode());print(json.dumps({'files':len(files),'bytes':archive.stat().st_size}))
