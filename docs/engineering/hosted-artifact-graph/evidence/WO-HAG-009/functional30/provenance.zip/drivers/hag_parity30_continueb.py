"""Observe the corrected staging attempt without changing any request."""
from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_parity30_continue.py').read_text().replace('claude-252','claude-253').replace("'continue30'","'continueb30'")
exec(compile(source,'functional30-continuation-parity-b','exec'),{'__file__':__file__,'__name__':'__main__'})
