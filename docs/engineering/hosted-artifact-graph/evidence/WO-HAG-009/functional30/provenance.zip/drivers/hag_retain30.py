"""Retain actual native exchanges, omitting private reasoning and credentials."""
from pathlib import Path
import json,sys
W=Path(__file__).parent
source=(W/'hag_full27_retain.py').read_text().replace('hag-lifecycle-native27-20261010','hag-claude-correction30-20261011').replace('WO-HAG-009/lifecycle27','WO-HAG-009/functional30').replace('native-parity-*27','native-parity-*30')
source=source.replace("'costs.json'", "'boundary-comparison.json','costs.json'")
source=source.replace("'immutable-baseline-review.json'", "'immutable-baseline-review.json','native-call-index.json','complete-inputs-inventory.json','complete-inputs-integrity.json'")
exec(compile(source,'retain-functional30','exec'),{'__file__':str(W/'hag_full27_retain.py'),'__name__':'__main__'})
index=W/'hag221proposal/docs/engineering/hosted-artifact-graph/evidence/WO-HAG-009/functional30'/(sys.argv[1]+'-inventory.json')
index.write_bytes((json.dumps(json.loads(index.read_text()),indent=2)+'\n').encode())
