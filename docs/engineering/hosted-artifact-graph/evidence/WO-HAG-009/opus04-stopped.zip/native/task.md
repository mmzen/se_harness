# Focused native qualification: selected-draft refusal and reporting

You are the Claude Code agent under test for approved WO-HAG-009 / VER-HAG-007.
Use C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus04\selection.json and the exact candidate plugin, client, released evaluator
and fixture it selects. This is the same disposable private Claude project as
your Opus02/Opus03 observations. No Codex work or other trial is an input.
Git remains authoritative for real work. All actor labels below are synthetic
test inputs; nothing here approves actual engineering, verification or release.

Run only this existing acceptance case: demonstrate a stale preview caused by
a changed selected draft. Identify the actual refusal, show that the rejected
request committed no effects, then recover through fresh context and a valid
corrected request. Choose the draft content and construct your own requests
from the documented schemas. Do not substitute another kind of project change
for a changed selected draft. Do not edit accepted records or repeat completed
work/release transitions. New test draft artifacts may live under
docs/engineering/lifecycle-pilot/. The synthetic owner accepts complete new
test definitions under test-owner after their required checks pass. No risk
acceptance, source edit, publication, deployment or real decision is supplied.

The required final report must name actual outcomes, failed/denied actions,
uncertainty, interventions and evidence. Audit your Opus02/Opus03 reports against
their actual requests and results, not a compaction summary or reported verdict.
Correct unsupported claims in a NEW report; keep all earlier evidence unchanged.
For each conclusion give the exact evidence path and distinguish an observed
operation from a proposed request, preview, inference or independent check you
did not run. Include this focused case. Do not claim all cases passed when a
required observation or evidence check remains absent. Identify exact component
and B/S/P/C identities from their records; do not relabel a test Git candidate.
Record actual instruction reads, hashes and triggers. Inventory-sourced hashes
must be labeled and linked to an actual read; a hash does not establish reading.

Your own earlier immutable observations are read-only at:
- `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus02` (Opus02 task, invocation, session, events and work/ requests/results).
- `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus03` (Opus03 task, invocation, session, events, work/ and native reports).
The Opus03 inputs/previous-work/ records are copies of Opus02 with complete
unescaped stdout companions. You may read these own observations only; never
read other trials or the operator's assessment scripts as workflow answers.
Independent replay is the reviewer's job; do not claim you performed it.

Begin with the selected candidate verity-plane:setup skill and follow its
applicable routes. The client is already installed. Do not install, activate a
local checkout, change real host settings, credentials, permissions or hooks.
Relevant read-only product references are under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus04\inputs\reference`:
server/contracts/remote-v1.json, server/contracts/read-v1.json,
server/contracts/lifecycle-v2.json, server/contracts/lifecycle-v2.md,
server/contracts/export-v2.json, server/README.md,
docs/notes/harnessctl-reference.md, docs/notes/hosted-artifact-graph.md.
Released instruction resources are at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus04\inputs\released-resources`.
CLI help is at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus04\inputs\client-help.txt`.
Read only current prerequisites and relevant sections, not future procedures.

The working directory is `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus04`. Write drafts, requests, receipts and traces
only under `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus04\work`. Write native-report.md and native-observations.json
at the working-directory root. Use absolute file paths. Staged inputs and both
earlier observations are read-only. No direct operator mutation will complete
the case on your behalf. Do not delegate.

Use native Read/Write/Edit tools and the exact approved_shell_argv_prefix in
selection.json. The fixed helper supplies paths and credentials and executes
one operation YOU choose. It supplies no workflow or decisions. Read its help.
Use ONE helper command per Bash call. No pipes, echo, wrappers, scripts, loops,
arbitrary Python, direct client calls or alternate shell routes. No extra
endpoint/project/token flags: the helper retains the selected configuration.
It returns stdout_file for the complete unmodified result; inspect it with Read.
Stop newly denied actions; do not broaden permissions or switch routes to evade
a denial. Existing seven read-only MCP tools remain available if needed; earlier
MCP observations need not be repeated to test this specific refusal.
Do not print environment values or inspect credentials. After compaction reread
task.md and selection.json and recover current state before resuming.
