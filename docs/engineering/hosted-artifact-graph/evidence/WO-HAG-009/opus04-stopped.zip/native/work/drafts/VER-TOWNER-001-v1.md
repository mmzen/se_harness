+++
id = "VER-TOWNER-001"
type = "verification"
title = "Stale preview qualification test V1"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"

[relations]
verifies = ["REQ-P3-900"]
+++

# Stale preview qualification test V1

Synthetic test input for stale-draft refusal qualification.

## Independence

Expected text is fixed by REQ-P3-900, not candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-900 | test | greeting assertion V1 | Equals Hello rehearsal |
