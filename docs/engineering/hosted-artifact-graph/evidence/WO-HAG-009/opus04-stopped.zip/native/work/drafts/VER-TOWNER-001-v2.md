+++
id = "VER-TOWNER-001"
type = "verification"
title = "Stale preview qualification test V2"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"

[relations]
verifies = ["REQ-P3-900"]
+++

# Stale preview qualification test V2

Changed synthetic test input for stale-draft refusal qualification.
This revision has different content to invalidate the V1 preview digest.

## Independence

Expected text is fixed by REQ-P3-900, not candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-900 | test | greeting assertion V2 | Equals Hello rehearsal |
