import json
from pathlib import Path
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
r=h.O/'claude/native02/work/opus04/work'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
receipt=lambda n:json.loads(load(r/'receipts'/n)['stdout'])
request=lambda n:load(r/'requests'/n)
preview=receipt('006-transition-preview.json');revision=receipt('007-revise-v2.json')
stale=receipt('008-stale-apply.json');fresh=receipt('010-fresh-preview.json');accepted=receipt('011-correct-apply.json')
old_request=request('006-transition-preview.json');change=request('007-revise-v2.json');rejected=request('008-stale-apply.json')
assert preview['outcome']=='previewed' and revision['outcome']=='accepted'
assert change['artifact_id']=='VER-TOWNER-001' and change['operation']=='revise-artifact'
assert old_request['action']['assignments'][0]['artifact']==change['artifact_id']
assert change['expected_context_version']==old_request['expected_context_version']==2
assert revision['versions']['project']=={'before':32,'after':33}
assert revision['versions']['context']['before']==2 and revision['versions']['context']['after']==3
assert rejected['preview_digest']==preview['preview_digest']
assert rejected['expected_context_version']==2
assert stale['outcome']=='refused' and stale['error']['code']=='HAG_REMOTE_STALE_CONTEXT'
assert stale['files']==[] and stale['affected_artifacts']==[]
assert fresh['outcome']=='previewed' and accepted['outcome']=='accepted'
assert accepted['versions']['project']=={'before':33,'after':34}
assert accepted['versions']['context']['before']==3 and accepted['versions']['context']['after']==4
replay=load(Path(r'C:\Users\mathi\AppData\Local\Temp\hag-o04-replay-20261007/assessment.json'))
assert len(replay['cases'])==1 and replay['cases'][0]['outcome']=='passed'
h.write(h.O/'opus04-selected-draft-audit.json',{'case':'NQ-03 selected-draft stale preview and corrected recovery','outcome':'observed_and_independently_replayed',
 'artifact':change['artifact_id'],'preview_digest':preview['preview_digest'],'changed_revision_ids':revision['affected_revision_ids'],
 'versions':{'before_revision':32,'after_revision':33,'after_rejected_apply':33,'after_valid_apply':34,'context_before_revision':2,'context_after_revision':3,'context_after_valid_apply':4},
 'stale_result':{'error':stale['error'],'files':stale['files'],'affected_artifacts':stale['affected_artifacts']},
 'recovery_receipt':accepted['receipt_id'],'independent_case':{k:replay['cases'][0][k] for k in ('case','kind','operation_key','outcome','file_effects')},
 'replay_limit':'The generic whole-run assessor exits 1 at its final two-native-export assertion: this focused run has no new exports. Its single accepted action replay passed. Opus03 separately supplies the two independently reconstructed native exports. No whole-run pass is inferred from the partial assessor.',
 'evidence':[{'path':str(p),'sha256':h.sha(p.read_bytes())} for p in sorted(r.rglob('*.json')) if p.name in ('006-transition-preview.json','007-revise-v2.json','008-stale-apply.json','009-status.json','010-fresh-preview.json','011-correct-apply.json')]})
print(json.dumps({'selected_draft_changed':True,'stale_context_refused_without_effects':True,'corrected_apply_replayed':True,'overall_host_verdict':'await final report and complete trace assessment'}))
