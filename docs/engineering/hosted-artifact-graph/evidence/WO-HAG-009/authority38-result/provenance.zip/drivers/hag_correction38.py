"""One-file approval prerequisite pointer correction under WO-HAG-011."""
from pathlib import Path
import sys
W=Path(__file__).parent
source=(W/'hag_correction36.py').read_text()
source=source.replace('hag-procedure36-20261011','hag-authority38-20261012').replace('WO-HAG-011/procedure36','WO-HAG-011/authority38')
start=source.index('changed=');end=source.index('\n',start)
source=source[:start]+"changed=['plugins/verity-plane/common/skills/change/references/hosted-test-lifecycle.md']"+source[end:]
source=source.replace('28b9e95175945a2cf1d084470c24ca1f3cb0f8c8','83a0a016bf299d9ca60208a453fa8012d97b2e74')
source=source.replace(",'canonical-section-comparison'",'')
source=source.replace('Include canonical entry conditions in focused instruction reads','Name the complete required authority reading before hosted approval')
source=source.replace('hag36','hag38')
for a,b in [('scope36','scope38'),('preflight36','preflight38'),('candidate-36','candidate-38'),('build36','build38'),('package36','package38'),('client36','client38'),('native-procedure36','native-authority38'),("-36'","-38'")]:source=source.replace(a,b)
exec(compile(source,'authority38-control','exec'),{'__file__':str(W/'hag_correction36.py'),'__name__':'__main__'})
