"""Assess retained native observations; this is not an assurance decision."""
import base64, hashlib, json
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'hag-authority38-20261012';r=O/'claude-341';w=r/'native/work';E=p.D/'evidence/WO-HAG-009/authority38-result'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
def put(f,v):
    assert not f.exists(),f
    f.parent.mkdir(parents=True,exist_ok=True)
    f.write_bytes((v if isinstance(v,str) else json.dumps(v,indent=2)+'\n').encode())
facts=load(r/'review-facts.json');metrics=load(O/'claude-341-summary.json')
replay=load(r/'replay38/assessment.json');audit=load(r/'output-boundary-audit.json')
proof=load(r/'comparison-inputs.json');order=load(r/'approval-reading-order.json')
accepted=[x for x in facts['lifecycle_results'] if x['outcome']=='accepted']
assert len(accepted)==3 and len(replay['cases'])==3 and all(x['outcome']=='passed' for x in replay['cases'])
assert len(facts['parity'])==3 and all(x['exact_match'] and x['complete'] and x['status']==200 for x in facts['parity'])
assert order['read_before_first_approval_request'] and order['first_approval_request_event']==290
assert audit['monitored_repository_and_host_settings_equal'] and audit['staged_input_integrity']['all_unchanged'] and not audit['writes_outside_work']
assert metrics['native_calls']==101 and metrics['peak_input_context']==340733 and len(metrics['native_failures'])==8
assert not facts['session']['timed_out'] and (w/'native-report.md').exists() and (w/'native-observations.json').exists()
record=(w/'r29-assert-greeting').read_bytes();assert load(w/'r29-assert-greeting')['exit']==0
handoff=load(w/'requests/q33-apply-handoff.json')
assert base64.b64decode(handoff['action']['files'][0]['content_base64'])==record
assert handoff['action']['files'][0]['sha256']==hashlib.sha256(record).hexdigest()
stale=load(w/'r22-apply-approve-stale.stdout.txt');assert stale['error']['code']=='HAG_REMOTE_STALE_PROJECT'
bad=load(w/'r30-preview-handoff-out-of-scope.stdout.txt')
assert 'WEX201: changed path is outside execution scope: docs/notes/greeting-assertion.json' in json.dumps(bad)
good=load(w/'r33-apply-handoff.stdout.txt')
assert good['outcome']=='accepted' and good['versions']['project']=={'before':17,'after':18}
assert len(good['evaluator_output']['commands'][-1]['result']['scope']['changed_paths'])==9
refusals=load(r/'refused-request-receipts.json');assert len(refusals)==2 and all(x['status']==404 for x in refusals)
assert load(r/'independent-final-status.json')['project_version']==18
claims={
 'targeted_fix':'Successful AUTHORITY.md#delegation-and-separation read at event239 precedes first approval request at event290. The prior required-reading omission is corrected in this observation.',
 'functional_result':'Six new artifacts authored; combined six-artifact approval, start and handoff accepted. All three accepted operations independently replayed through released evaluator0.22.1. Exact assertion passed.',
 'stale_test_limit':'Old project/context versions and old preview digest were supplied after revising VER. HAG_REMOTE_STALE_PROJECT fired first. This run does not establish the outdated-preview-digest guard with current versions. Native report discloses this limit.',
 'scope':'Accepted handoff uses the original first-approval input head and complete nine-path comparison. No approved-scope widening or later base substituted.',
 'verification_content':'VER matches native Windows client Python, source SHA, equality-only assertion and captured command/output/timing fields. It distinguishes fixture source from later commit-bound verification. Handoff evidence bytes equal the actual assertion capture.',
 'no_effects':'Both original refused keys return404. Independent Cypher/HTTP comparison shows project15 after stale refusal and project17 after scope refusal. Accepted operations subsequently advance project15->16->17->18.',
 'reading_limits':'The successful required section read establishes delivery and ordering, not understanding or complete instruction compliance. All six authoring checklists were read. Missing concise-hosted-authoring reference was an unsuccessful optional route: hosted-drafts permits the selected tool index OR that reference. Tool index was read.',
 'report_precision':'Native report identifies qualification candidateee86a842550c19fb6a56913841757b42df9ecaec but elsewhere says implementation candidateC is not established. Actual C is independently known. CandidateP was not captured. Its own content-review wording does not make self-review independent.',
 'failures':'Eight failed items retained: five helper/input errors, one draft-open request for an absent work order, two intentional service refusals. Recovery does not erase these observations.',
 'claim_limit':'Targeted reading correction and accepted handoff do not complete NQ-01..05, required Opus4.6 authoring cases, paired-host qualification or actual work-order verification. No criterion is changed.'
}
put(r/'claim-audit.json',claims)
put(r/'independent-assessment.json',{
 'candidate':proof['candidate'],'trial':'claude-341',
 'outcome':'targeted authority discovery fixed; handoff accepted; stale preview-digest coverage and full qualification remain incomplete',
 'metrics':{k:metrics[k] for k in ['wall_seconds','native_calls','peak_input_context','model_turns']},
 'failed_tool_items':8,'accepted_operations':3,
 'independent_replay':{'all_three_passed':True,'state':replay['state'],'native_export_claim':False},
 'mcp_http_comparison':facts['parity'],'approval_reading_order':order,'claims':claims,'comparison_inputs':proof,
 'boundary':{'staged_files_unchanged':120,'native_write_requests':24,'outside_work':0,'command_captures':30,'monitored_repository_and_host_settings_equal':True},
 'interventions':'No supplied answers, corrective commands, changed permissions or operator graph mutations during native run. Read-only independent comparisons only.',
 'authority':'Synthetic test actions only. Actual WO-HAG-009/011 remain in_progress. No human verification, merge, release, deployment or criterion amendment.'})
put(E/'assessment.md',f'''# Approval instruction discovery: Opus 5.5 rerun

**The targeted reading omission is corrected in this run.** Claude read
`AUTHORITY.md#delegation-and-separation` before its first approval request.
It authored six artifacts, ran the greeting assertion and reached an accepted
handoff. All three accepted operations replayed successfully through released
evaluator 0.22.1.

**Qualification remains incomplete.** The stale request reached the project
version guard before the preview-digest guard. This run therefore does not
demonstrate rejection of an old preview digest with current versions. Full
paired-host scenarios were not run here.

Candidate: `{proof['candidate']}`. Trial: `claude-341`.
PR #543 remains draft, targeting `main`. Earlier evidence is preserved.

## Change and authority

Two rows in `plugins/verity-plane/common/skills/change/references/hosted-test-lifecycle.md`
now name the existing canonical delegation section beside decision rights.
Both approval-package review and application show their required reading together.
The change adds file pointers, without copying policy text or creating a second
workflow. No service, helper, schema, dependency, permission, decision right or
qualification criterion changed.

Existing WO-HAG-009/011 authority covers this correction and evidence. The
[implementation review](../../WO-HAG-011/authority38/review.md) retains the
bounded diff and local checks. No actual approval or start was repeated.

## Observed result

| Check | Independent observation |
| --- | --- |
| Required authority reading | Successful delegation section content return at event 239; first approval request at event 290 |
| Six artifacts | INT/CAP/REQ/SPEC/VER/WO-P3-001 authored; all six type checklists read |
| Verification content | Matches native Windows equality assertion, fixture digest and available evidence fields |
| Complete scope | Six formal files plus assertion and two generated handoff files; nine paths in final comparison |
| Greeting assertion | Passed in 0.077949 seconds; submitted evidence bytes equal the actual capture |
| Stale request | `HAG_REMOTE_STALE_PROJECT`; no current-run preview-digest-guard claim |
| Out-of-scope handoff | `QGP-G4I-PATHS` / `WEX201` refusal for `docs/notes/greeting-assertion.json`; approved evidence path then passed |
| Accepted lifecycle operations | Combined approval of six artifacts, work start, handoff; all three independently replayed |
| Cypher | Three complete native MCP responses exactly match independent HTTP replies |
| Refusal effects | Original refused operation keys return 404; independent reads confirm unchanged project versions until the next accepted mutation |
| Final test state | Project 18, context 16; WO-P3-001 remains `in_progress` with accepted handoff |
| Boundaries | All 120 staged inputs unchanged; 24 observed Write/Edit requests inside work/; 30 command captures; monitored repository and host settings unchanged |

The complete comparison starts at `234100a1501a042160c2f27a4f669ce0dbdf1f84`,
the first approval's input Git head. No later base or expanded approved scope
was used. The assertion checks existing greeting source; this diagnostic does
not claim new source implementation or a verification record.

No answers, prepared mutation requests, corrective commands, permission changes
or operator graph writes were supplied during the native run. Read-only
independent comparisons were separate. Only this trial's service and graph
containers were stopped afterward; their volumes remain.

## Remaining findings

1. **Preview-digest coverage is still missing from this run.** After changing
   VER, Claude supplied both old versions and an old digest. The version check
   refused first. Its report correctly acknowledges that the digest guard was
   not reached. The previous trial demonstrated that guard with the same
   service bytes; that historical observation is not a new native pass here.
2. **Six avoidable failed calls remain.** Five helper/input errors and one
   draft-open request for a work order absent from the baseline caused retries.
   The other two failed calls are deliberate refusal tests. All eight remain
   in the retained transcript and captures.
3. **Candidate wording remains inconsistent.** The native report identifies
   this qualification candidate but elsewhere marks implementation candidate C
   unknown. The exact C above is established independently. No candidate P was
   captured. The native agent's review of its own authored content also must
   not be treated as independent verification.

The agent unsuccessfully tried the concise-hosted-authoring reference. This
does not create another mandatory-reading failure: the applicable hosted-drafts
instruction permits the selected tool index **or** that reference. It read
the index. The failed access and retry cost remain evidence.

The successful delegation-section read proves content delivery and ordering;
it does not prove understanding or every other instruction obligation.

## Same-task comparison

| Metric | Previous Claude331 | Current Claude341 |
| --- | --- | --- |
| Model / CLI | Opus 5.5 / pinned 2.1.280 | Same |
| Native duration | 11:50 (710.395s) | 11:43 (703.218s) |
| Tool calls | 103 | 101 |
| Failed items, including negative tests | 7 | 8 |
| Peak input context | 305,803 tokens | 340,733 tokens |
| Accepted operations | 4: separate definition and WO approvals, start, handoff | 3: combined approval, start, handoff |
| Required delegation section | Skipped | Read before approval |
| Old preview digest with current versions | Guard reached | Not tested; earlier version guard reached |
| Complete scope and valid handoff | Passed | Passed |

These are single observations, not a controlled performance benchmark.
Context increased and total duration remains high. The 0.078-second assertion
is only one part of the 11:43 session. Setup, builds and independent review are
separate. Peak context uses the same provider-reported input/cache metric as
the earlier report; it is not total billed tokens. Broad performance work
remains deferred.

## Exact inputs and checks

The task, permissions and 20-minute limit match the prior run after disposable
path normalization. Of 120 staged inputs, 116 are byte-identical. The differences
are one guidance file, two project/component identity files and the client
wheel archive. All 127 client wheel members are byte-identical to the prior
wheel. The exact comparison passed before native launch.

The candidate was built twice with the pinned producer and installed. Plugin
packages contain its exact guidance. All 27 service wheel members and the
evaluator/runtime/database/protocol/dependency identities match the prior
package. Earlier service qualification is reused, not claimed as rerun. A live
authentication probe passed. No host CLI update occurred during this rerun.

Source suite: 1,339 tests, 24 reported skips, exit 0. Focused resource, native
and plugin checks, distribution checks and CLI smoke passed. Released
validation: 1,991 artifacts, zero errors, 63 existing warnings.

Before this update, applicable technical CI checks at review head `83a0a01`
passed; three conditional rehearsals were skipped. Harness validation remained
failed for unfinished qualification (`QGP-G4I-EVIDENCE`). New-head CI is reported
separately in the PR; local checks do not establish its result.

WO-HAG-009/010/011 remain in progress. Fresh checks for the selected WO-HAG-009/011
return `PROC-WO-IMPLEMENT / STEP-WO-IMPLEMENT-CHECK`. The synthetic WO's handoff
does not advance those real work orders. This diagnostic does not replace
NQ-01 through NQ-05, required Opus 4.6 authoring cases or paired Codex/Claude
qualification. No actual VREC, human verification, merge, release, deployment
or risk acceptance occurs. Git remains authoritative.

## Next work

Retain the current pass for the targeted reading fix. Complete the missing
preview-digest diagnostic under the existing contract, with the version guard
and digest guard assessed separately, then resume remaining qualification.
Do not weaken criteria or count the earlier guard as the intended digest check.

## Evidence

- [Visible transcript](claude-341-visible.md).
- [Native inventory](claude-341-inventory.json) and [archive](claude-341-evidence.zip):
  exact requests, results, authored files, reports, reading order, replay,
  refusal, parity and boundary observations.
- [Provenance inventory](provenance-inventory.json) and [archive](provenance.zip):
  exact build/setup/observer sources, comparisons and component identities.
- [Report checks](report-checks.zip) and [inventory](report-checks-inventory.json).

Private reasoning, provider/account logs, credentials and executables are
excluded. Historical evidence and exact retained bytes remain unchanged.
''')
readme=p.D/'README.md';s=readme.read_text();a=s.index('## Latest functional qualification');b=s.index('## Previous paired functional qualification',a)
s=s[:a]+'''## Latest functional qualification

The [approval instruction discovery rerun](evidence/WO-HAG-009/authority38-result/assessment.md)
uses candidate `ee86a842550c19fb6a56913841757b42df9ecaec` with Opus 5.5.
The required delegation section was read before approval. The run reached an
accepted handoff in 11:43; all three accepted operations independently replayed.
Its stale request reached the project-version guard, so preview-digest coverage
is not established for this run. Full paired-host qualification remains pending.
Peak input context is 340,733 tokens. PR #543 stays draft.

The [previous scope and verification planning run](evidence/WO-HAG-009/scope37-result/assessment.md),
[earlier Opus 5.5 comparison](evidence/WO-HAG-009/opus55-comparison/assessment.md)
and [Opus 4.6 entry-condition assessment](evidence/WO-HAG-009/procedure36-result/assessment.md)
retain their original failures and candidates. Formal qualification criteria
are unchanged; broad performance work remains deferred.

'''+s[b:];readme.write_bytes(s.encode())
put(O/'pr-note38.md','''Harness-Work-Orders: WO-HAG-009, WO-HAG-010, WO-HAG-011

## Current result

[Approval instruction discovery assessment](REPORT_URL) for implementation candidate ee86a842550c19fb6a56913841757b42df9ecaec; review head REVIEW_HEAD.

Two approval-reading rows now point directly to the existing delegation section. Fresh Opus 5.5 / pinned CLI 2.1.280 diagnostic confirms that section was read before approval. The greeting assertion and complete-scope handoff pass; all three accepted lifecycle operations independently replay. Three Cypher responses match HTTP exactly.

This remains unfinished qualification. The stale request reached HAG_REMOTE_STALE_PROJECT before the preview-digest guard. That guard was not established with current versions in this run. Required NQ-01..05, Opus 4.6 authoring cases and full paired-host qualification remain pending. Earlier failures are preserved. No criteria changed.

Native duration: 11:43; 101 calls; eight failed items (six avoidable, two intentional); 340,733 peak input context. Performance is not fixed. No runtime/service/helper/permission changes or native assistance.

Source suite: 1,339 tests, 24 reported skips, exit 0. Focused checks, distribution, smoke and exact two-producer build passed. Released validation: zero errors, 63 existing warnings. New-head CI is separate from these local observations.

## Delivery boundary

Keep PR #543 draft, codex/hosted-agent-qualification to main, with the complete original comparison base. WO-HAG-009/010/011 remain in_progress; QGP-G4I-EVIDENCE for unfinished qualification remains disclosed. Git remains authoritative. No actual verification, merge, release, deployment, host update or risk acceptance is granted. Authentication/database ACL implementation and broad performance changes remain deferred.

Next complete the missing digest-guard diagnostic under the existing contract, then resume qualification. Released next step: STEP-WO-IMPLEMENT-CHECK. This is an authorized unfinished-work review update.
''')
print('Independent assessment, report and discovery link written')
