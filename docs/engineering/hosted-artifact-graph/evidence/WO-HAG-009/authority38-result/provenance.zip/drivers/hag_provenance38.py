"""Retain exact bounded setup/build/observer evidence after the native run."""
import hashlib,json,re,zipfile
from pathlib import Path
import hag_efficiency_plan as p
O=p.W/'hag-authority38-20261012';E=p.D/'evidence/WO-HAG-009/authority38-result'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
assert (O/'claude-341/native/session.json').exists()
files={}
drivers=['hag_ordering38.py','hag_efficiency_plan.py','hag221_execute.py','hag_correction38.py','hag_correction36.py','hag_efficiency_package03.py','hag_package38_review.py','hag_package36_review.py','hag_full38.py','hag_full36.py','hag_full27.py','hag_native27.py','hag_focus36_task.txt','hag_native38_proof.py','hag_observe38.py','hag_parity36.py','hag_native_parity19.py','hag_review36.py','hag_full27_review.py','hag_trace36.py','hag_full27_trace.py','hag_full36_facts.py','hag_retain38.py','hag_retain36.py','hag_retain26.py','hag_watch36.py','hag_assess36.py','hag_provenance38.py']
drivers += ['hag_report38.py','hag_publish38.py','hag_publish28.py']
for name in drivers:files['drivers/'+name]=(p.W/name).read_bytes()
for name in ['candidate-38','package-guidance-comparison','service-reuse-comparison','server-wheel-members','client-build-38','build38-replay','package-38','client-env-38','client-install-38','context-WO-HAG-009','context-WO-HAG-011']:
 files['candidate/'+name+'.json']=(O/(name+'.json')).read_bytes()
for f in O.glob('claude341-*.json'):
 if 'live-probe' not in f.name:files['setup/'+f.name]=f.read_bytes()
files['comparison/comparison-inputs.json']=(O/'claude-341/comparison-inputs.json').read_bytes()
tokens=[x['token'].encode() for f in O.glob('*/credentials.json') for x in load(f)['principals']]
for name,raw in files.items():
 assert not any(t in raw for t in tokens),name
 assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
with zipfile.ZipFile(E/'provenance.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
index={'archive':'provenance.zip','sha256':sha((E/'provenance.zip').read_bytes()),'files':[{'path':n,'sha256':sha(b),'bytes':len(b)} for n,b in sorted(files.items())],'limits':'Exact bounded build, setup and observer sources. No raw provider logs, private reasoning, credentials, account stores, environments or executables. Test tokens checked absent. CLI identity links to the prior Opus5.5 comparison; no host update was performed for this rerun.'}
target=E/'provenance-inventory.json';assert not target.exists();target.write_bytes((json.dumps(index,indent=2)+'\n').encode());print(len(files),'files')
