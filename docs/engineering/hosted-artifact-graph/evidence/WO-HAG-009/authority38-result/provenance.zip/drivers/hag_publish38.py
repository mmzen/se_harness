"""Publish bounded implementation and evidence to the existing draft PR."""
from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_publish28.py').read_text()
source=source.replace('hag-hosted-next28-20261011','hag-authority38-20261012').replace('WO-HAG-009/diagnostic28','WO-HAG-009/authority38-result')
source=source.replace("C='dfcf1e976123836f00354a228c8e72a833f2e3cf';PRE='dd1c4730e7b4973fae87bc0a6b1c9a871f1219c7'", "C='ee86a842550c19fb6a56913841757b42df9ecaec';PRE='83a0a016bf299d9ca60208a453fa8012d97b2e74'")
for stem in ('report','evidence-commit','pr-note','pr-body','pr-event','check-pr','main-controls','source-controls','write-guard','push','pr-edit','published-readback','report-readback'):
 source=source.replace(stem+'28',stem+'38')
source=source.replace('pr-before-28.json','pr-before-38.json')
source=source.replace("body=body.replace('## Latest result\\n',note+'\\n## Previous full qualification result\\n',1)",'body=note')
source=source.replace('Retain focused Claude hosted lifecycle diagnostic and limitations','Retain approval authority discovery rerun and observed limits')
exec(compile(source,'scope37-publish','exec'),{'__file__':str(W/'hag_publish28.py'),'__name__':'__main__'})
