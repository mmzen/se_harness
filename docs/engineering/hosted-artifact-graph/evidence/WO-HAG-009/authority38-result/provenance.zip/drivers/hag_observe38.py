"""Reuse read-only native observers for scope37; no native guidance."""
from pathlib import Path
import sys
W=Path(__file__).parent;mode=sys.argv[1]
if mode in ('watch','trace','parity'):
 name={'watch':'hag_watch36.py','trace':'hag_trace36.py','parity':'hag_parity36.py'}[mode]
 sys.argv=[__file__,'claude-341' if mode=='trace' else '341']
elif mode in ('observe','replay','stop'):
 name='hag_review36.py';sys.argv=[__file__,'claude-341',mode]
elif mode=='facts':name='hag_full36_facts.py'
elif mode in ('audit','refusals'):name='hag_assess36.py'
else:raise ValueError(mode)
source=(W/name).read_text().replace('hag-procedure36-20261011','hag-authority38-20261012').replace('claude-311','claude-341')
for a,b in [('diagnostic36','diagnostic38'),('replay36','replay38'),('package36','package38'),('native-procedure36','native-authority38')]:source=source.replace(a,b)
exec(compile(source,'scope37-'+mode,'exec'),{'__file__':str(W/name),'__name__':'__main__'})
