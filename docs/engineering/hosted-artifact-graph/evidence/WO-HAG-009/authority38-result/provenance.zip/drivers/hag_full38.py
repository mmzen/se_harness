"""Same focused Opus 5.5 diagnostic with exact scope37 packaged guidance."""
from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_full36.py').read_text().replace('hag-procedure36-20261011','hag-authority38-20261012')
source=source.replace("else '311'", "else '341'")
for a,b in [('candidate-36','candidate-38'),('package36','package38'),('client36','client38'),('build36','build38'),('native-procedure36','native-authority38'),('hag-full36-','hag-full38-'),('10.231.92.0/22','10.231.100.0/22')]:source=source.replace(a,b)
marker='sys.argv=[__file__,actual,host,trial]'
source=source.replace(marker,"source=source.replace('claude-opus-4-6','claude-opus-5-5').replace(r'C:\\Users\\mathi\\.local\\bin\\claude.exe',str(W/'hag-opus55-availability-20261011/claude-2.1.280.exe'))\n"+marker)
exec(compile(source,'scope37-native','exec'),{'__file__':str(W/'hag_full36.py'),'__name__':'__main__'})
