"""Retain completed scope37 diagnostic with no raw reasoning or credentials."""
from pathlib import Path
import sys
W=Path(__file__).parent
source=(W/'hag_retain36.py').read_text().replace('hag-procedure36-20261011','hag-authority38-20261012').replace('WO-HAG-009/procedure36-result','WO-HAG-009/authority38-result')
source=source.replace("names=['initial-status.json'", "names=['comparison-inputs.json','approval-reading-order.json','initial-status.json'")
source=source.replace('replay36','replay38').replace("native-parity-*36", "native-parity-*38")
sys.argv=[__file__,'claude-341']
exec(compile(source,'scope37-retention','exec'),{'__file__':str(W/'hag_retain36.py'),'__name__':'__main__'})
