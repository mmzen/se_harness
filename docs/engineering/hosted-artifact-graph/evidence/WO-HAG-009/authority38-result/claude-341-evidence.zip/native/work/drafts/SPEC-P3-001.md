+++
id = "SPEC-P3-001"
type = "specification"
title = "Exact rehearsal greeting result"
status = "draft"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
# What an implementation must do to conform. The Explorer shows this summary under the title.
contract = "The fixture's greeting() function, called with no arguments, returns a value equal to exactly Hello rehearsal."

[relations]
specifies = ["REQ-P3-001"]
+++

# Specification: Exact rehearsal greeting result

Before approval, apply the shared design principle and `specification` checklist in
`docs/engineering/ARTIFACT_AUTHORING.md`.

Synthetic rehearsal input. The owner and decisions are test labels, not real
human decisions.

## In plain words

The existing greeting function must return one fixed text. Equality with that
text is the only conformance rule.

## Scope

This specification governs the return value of `greeting()` in
`src/greeting.py`. It leaves the check method, platform and evidence to
VER-P3-001. It prescribes no implementation mechanism.

## Terms

- **Fixture.** The rehearsal source snapshot at commit
  `5820415917e87b64d80bad2f7c39c6d18d692829`.

## Rules

**P3-GREET-001.** `greeting()`, called with no arguments, MUST return a value
equal to exactly `Hello rehearsal`: capital `H`, one space, lower-case
`rehearsal`, with no leading or trailing characters.

## Failure behaviour

| Trigger | Response | Diagnostic |
| --- | --- | --- |
| `greeting()` returns a value that is not equal to `Hello rehearsal` | The implementation does not conform to P3-GREET-001 | `none` |

## Examples

**Given** the fixture `src/greeting.py`, **when** the test operator calls
`greeting()`, **then** the result equals `Hello rehearsal` (P3-GREET-001).

**Given** a variant that returns `Hello Rehearsal`, **when** the result is
compared, **then** it does not conform to P3-GREET-001.

## Coverage

| Requirement | Rules |
| --- | --- |
| `REQ-P3-001` | P3-GREET-001 |

## Not decided here

- The Python type of the returned value. The selected check asserts equality
  only and makes no separate type assertion.
