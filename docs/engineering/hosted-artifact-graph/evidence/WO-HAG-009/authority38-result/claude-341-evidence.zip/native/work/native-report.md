# Native hosted procedure and refusal diagnostic — claude-341

Focused observation under WO-HAG-009/011 and VER-HAG-007. This is test data in
a private sandbox. Git remains authoritative. The diagnostic does not complete
NQ-01 through NQ-05. It does not verify real work or authorize a release.
`test-owner` and `test-executor` are synthetic fixture labels, not human
decisions.

## Outcome

- **Out-of-scope handoff refused (preview).** The released evaluator blocked the
  scope checkpoint. No effect occurred.
- **Stale preview refused (apply).** The service refused the apply after a
  selected draft changed. No effect occurred.
- **Valid handoff accepted** for WO-P3-001. The work order is still
  `in_progress`.
- **Not done:** completion (`implemented`), VREC, RLS, release contract, risk,
  export, publication and installation. No source change was made.

## Identities

| Item | Value | Evidence |
| --- | --- | --- |
| Endpoint / project | `http://127.0.0.1:27341` / `88e3de14-b006-4c1f-af12-7d3148b31d31` | `work/r01-status.stdout.txt` |
| Authority mode | `sandbox-projection`, `test_copy: true`, `rehearsal-only; Git remains authoritative` | same |
| Released evaluator | 0.22.1, archive `cb35c3c4…3053`, payload `0e7b7c2b…e7ff` | same; `inputs/evaluator.json` |
| Candidate client | 0.22.2, wheel `ada921b0…7150` (status, `identity` and combination agree) | `identity` output; `inputs/combination.json` |
| Qualification candidate | `ee86a842550c19fb6a56913841757b42df9ecaec` (status `components/source/candidate_commit`) | `work/r01-status.stdout.txt` |
| Plugin | claude 0.2.7, archive `b7a24380…c4f7` | same |
| Source fixture commit S | `5820415917e87b64d80bad2f7c39c6d18d692829`; `src/greeting.py` SHA-256 `dcbd486a…cab1` | `inputs/source-manifest.json`; read-text result |
| Imported baseline | `se-harness-artifact-baseline/v1:sha256:87d1cfb6…69cd` | `work/r02-import.stdout.txt` |
| Draft context | `b4f00ab7-45ac-4772-a8ca-e6ee80767f9e`, opened on WO-P3-900 | `work/r04-draft-open.stdout.txt` |
| Handoff base (retained) | `input_git_head` `234100a1501a042160c2f27a4f669ce0dbdf1f84` of the first accepted lifecycle mutation, key `c341-apply-approve-02` | `work/r25-apply-approve.stdout.txt` `/provenance` |
| Test Git candidate P | not established: no capture-verification was run | — |
| Implementation candidate C | not established | — |

## New definitions (domain `lifecycle-pilot`)

Created with `create-artifact`, then completed with `revise-artifact`. Drafts are
in `work/drafts/`. Each final draft revision was admissible with an empty
`incomplete` list. `content_review` was `not_assessed` for each one.

| ID | Final draft revision | Approved revision (context 15) |
| --- | --- | --- |
| INT-P3-001 | `sha256:f31751b7…fed30` (r11) | `sha256:7de1145c…cfba` |
| CAP-P3-001 | `sha256:aad77c95…a48d` (r12) | `sha256:dd90acb3…9de` |
| REQ-P3-001 | `sha256:9219c17f…2016` (r13) | `sha256:c8b85e5b…13cf` |
| SPEC-P3-001 | `sha256:f079e456…72b4` (r14) | `sha256:b3548400…caf98` |
| VER-P3-001 | `sha256:ad544ef0…c271` (r15), then `sha256:661278b0…8784` (r21) | `sha256:148f730d…dc94` |
| WO-P3-001 | `sha256:3c987c93…eacf` (r16) | `sha256:3b0ee1d4…aae5` (`in_progress`) |

**Content readiness: complete** against the type checklists (my independent
source-inspection review). The outcome, owner identity and assurance choice
came from the task. The check method and evidence path are planned choices
within the design scope, matched to `native-execution-tools.md`. The pass
condition (exit 0 with `exact greeting passed`, source digest `dcbd486a…`) is
assessed by planned case C1. The tool makes no type assertion, so the
specification and the verification contract do not claim one.
WO-P3-001 scope: the six definition files plus
`docs/engineering/lifecycle-pilot/evidence/WO-P3-001/greeting-assertion.json`.
`src/greeting.py` is excluded because no source modification is permitted.

## Lifecycle observations

| # | Request (key) | Outcome | Evidence | Note |
| --- | --- | --- | --- | --- |
| 1 | import `c341-import-01` | accepted, project 0→1 | `work/r02-import*` | Validation: 7 artifacts; advisory W-AUT-022 on imported SPEC-P3-900 (left unchanged) |
| 2 | draft-open WO-P3-910 `c341-open-01` | **refused** 404 `HAG_REMOTE_UNKNOWN_IDENTITY` "Work order is absent from the selected baseline." | `work/r03-draft-open*` | My incorrect input. No effect (no receipt). Reopened on WO-P3-900 (`c341-open-02`), accepted |
| 3 | inspect validate / check WO-P3-001 | inspected | `work/r18-*`, `work/r19-*` | Checkpoint-free context: `compliance.status` `not_assessable`, no gates. This is not a gate result |
| 4 | preview approval packet `c341-preview-approve-01` | previewed, digest `sha256:ba03da3c…5083`; transition gates pass | `work/r20-preview-approve*` | 6 assignments, actor `test-owner` |
| 5 | revise VER-P3-001 `c341-rev-ver-02` | accepted, project 14→15, context 12→13 | `work/r21-revise-ver-after-preview*` | The selected draft changed after preview 4 |
| 6 | apply stale preview `c341-apply-approve-stale-01` (versions 14/12, digest from 4) | **refused** 409 `HAG_REMOTE_STALE_PROJECT` "Expected project version is stale." | `work/r22-apply-approve-stale*` | Failed condition: the project version guard (expected 14, actual 15). No receipt, no affected revisions |
| 6a | Cypher (MCP) at context 13 | complete; all six proposals `draft`; project 15 | `work/r23-mcp-cypher-after-stale.json` | Unchanged effects confirmed |
| 7 | preview + apply approval `c341-preview-approve-02` / `c341-apply-approve-02` | previewed (`sha256:2437578d…1d89`, gates pass), then **accepted**; project 15→16 | `work/r24-*`, `work/r25-*` | All six artifacts `approved`. `input_git_head` 234100a1… retained |
| 8 | start: preflight, preview, apply (`c341-apply-start-01`) | preflight `ready: true`; gates pass; **accepted**, project 16→17 | `work/r26-*` to `work/r28-*` | WO-P3-001 `in_progress`, actor `test-executor` |
| 9 | VER-P3-001 case C1 `assert-greeting` | exit 0, stdout `exact greeting passed`; record SHA-256 `715e710b…0dc3` | `work/r29-assert-greeting` | Executed test on the native host with `client_python`. No Python version recorded |
| 10 | handoff preview to `docs/notes/greeting-assertion.json` `c341-preview-handoff-oos-01` | **refused** 422 `HAG_REMOTE_EVALUATOR_REFUSED` | `work/r30-preview-handoff-out-of-scope*` | Released evaluator blocked: `QGP-G4I-PATHS: WEX201: changed path is outside execution scope: docs/notes/greeting-assertion.json`; `mutation.writes` is empty; next step: escalate under `DR-REMEDIATION-SCOPE` |
| 10a | Cypher (MCP) at context 15 | complete; definitions `approved`, WO `in_progress`; project 17 | `work/r31-mcp-cypher-after-oos.json` | Unchanged effects confirmed |
| 11 | handoff preview + apply (in-scope path, base 234100a1…) | previewed (`sha256:a5e0ab9e…de2b`; handoff gates pass; 9 changed paths in scope), then **accepted**; project 17→18, context 15→16, receipt `sha256:616d52fb…da05` | `work/r32-*`, `work/r33-*` | Files: `greeting-assertion.json` (`715e710b…`), `WO-P3-001-handoff.md`, `handoff.json`. Output Git head `2202770c…` |

Meaningful Cypher read before lifecycle actions: `work/r17-mcp-cypher.json`
(context 12, complete). WO-P3-001 declares `implements`→REQ-P3-001,
`specifications`→SPEC-P3-001 and `verification`→VER-P3-001.

## Current state and next step

- **State:** WO-P3-001 `in_progress`. INT, CAP, REQ, SPEC and VER-P3-001 are
  `approved`. Project version 18, context version 16. Imported `-900` records
  are unchanged.
- **Next step (evaluator):** `STEP-WO-IMPLEMENT-PREVIEW`,
  `harnessctl transition . --set WO-P3-001=implemented --decision WO-P3-001=delegated-executor`.
  I did not run this step because the task forbids completing the work.

## Failures, refusals and uncertainties

- **Service refusals (3):** items 2, 6 and 10 above.
- **Helper or input errors (5, recovered):**
  - A `read-text` call on the missing file `client-help/draft-open.txt`.
  - Three `instructions` selectors outside the released-resource inventory
    (`docs/notes/harnessctl-reference.md`, the reference graph note and the
    reference `lifecycle-v2.md`). I located the two reference files with
    `find-file` and read them with native Read. I did not read
    `harnessctl-reference.md#concise-hosted-authoring`.
  - One `read-json` pointer that was not JSON-quoted.
- **Count method:** the counts come from `work/r34-observations`
  `/native_failures`, a snapshot taken before this report was written.
- **Possible design questions:**
  - The stale apply also had a changed preview binding (the VER revision). The
    service reported only the first guard failure, the project version. I did
    not observe whether a digest mismatch with current versions would give a
    different code.
  - Draft-open must name a work order that exists in the baseline. The context
    is therefore anchored on the imported WO-P3-900, which received no decision.
- **Verification limits:**
  - Case C1 ran against the fixture snapshot, not inside a verification
    candidate.
  - Commit-bound verification is still required and was not performed.
  - The record contains no Python version and makes no type assertion.
- **Instruction trace:** see `work/r34-observations` `/observed_content_reads`
  and `/file_reads`. Automatic instruction delivery was not qualified. The
  task and plugin entry were read explicitly.
