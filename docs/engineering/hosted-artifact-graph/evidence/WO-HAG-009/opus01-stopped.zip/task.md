# Native hosted-workflow qualification

The human approved WO-HAG-009 and VER-HAG-007. You are the native agent under test,
working only in the disposable private hosted project selected by C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus01\selection.json.
Complete the requested test independently using the actual candidate instructions,
documented closed schemas and observed results. Do not delegate to other agents.

The test outcome is an operator who can inspect the existing local fixture's
`greeting()` function and prove that it returns exactly `Hello rehearsal`, with a
complete exported engineering record of that test change. Git remains authoritative
for all real work. The service is a test copy; all actor labels and decisions here
are synthetic inputs with no real engineering or external authority.

The operator has staged the exact inputs inside this fresh test directory.
Read `inputs/`; write requests, results and exports under `work/`, plus the
two final report files at the root. The supplied source is an exact tracked
file snapshot; its Git source commit is recorded in selection.json.
No Git ownership override or source modification is permitted. Read the non-secret
selection file for the exact installed client, plugin resources, service endpoint,
project, source manifest, fixture source and credential environment-variable NAME.
Authentication is already configured in your process. Never print environment
values, inspect credential stores or credential files, or change account settings.
The endpoint may drop one accepted lifecycle reply as part of this test.

Use the selected candidate plugin's setup/change/evidence/orient guidance when it
applies. The operator has already installed the separate candidate client and
prepared a new schema-2 service. Setup means verify these supplied identities;
do not install software, alter the real host plugin or activate a different real
checkout. Automatic instruction injection is not a claim of this test. Keep a
file-read trace: exact paths/hashes and what triggered the reads.

Product reference files are read-only at
`C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\inputs\reference`:
`server/contracts/remote-v1.json`, `read-v1.json`, `lifecycle-v2.json`,
`lifecycle-v2.md`, `export-v2.json`, `server/README.md`, and
`docs/notes/harnessctl-reference.md`. Read only the relevant references and the captured actual CLI help at
`C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\inputs\client-help.txt`. Do not read or run the qualification walkthroughs, fixture authoring
functions, test drivers or earlier host transcripts to obtain completed requests.
The source manifest and the immutable source fixture itself are permitted inputs.

Author your own new definitions and work order for the greeting outcome, with
verification and a release contract for test version 0.0.1. Imported `-900` records
are immutable reference history; do not amend or apply decisions to them. All new
test artifacts may live in `docs/engineering/lifecycle-pilot/`; select narrow work
paths covering your new artifacts, `src/greeting.py` and your retained test evidence.
Construct your own requests and use their actual returned revisions and versions.
Do not hide the complete workflow in an end-to-end launcher. Small helpers for
encoding a single file/request or recording a single call are permitted; inspect
each result before deciding the next action.

The following synthetic inputs are supplied by the test owner: accept complete
test definitions; require commit-bound verification; approve the bounded test work
after its gates pass; choose mitigation for the test risk using that work; accept
the test VREC after its evidence passes; authorize the test release record after
its gates pass. Use `test-owner` for test definitions/work/decisions,
`test-executor` for execution, `quality-owner` for test verification and
`release-owner` for the test release. These inputs do not authorize anything in
the real repository or any push, tag, publication, installation or deployment.

Required observed outcomes:

- Identify the selected test context and exact evaluator. Distinguish context
  reporting from passed gates. Author, validate and exercise the full test
  lifecycle through work completion, test verification and test release assessment.
  Inspect the existing greeting source and retain the exact local assertion output.
  Record one test risk and its paired decision. No service endpoint runs source tests.
- Demonstrate an out-of-scope handoff refusal and a stale preview after a selected
  draft changes. Explain the actual refusals, show unchanged effects, then complete
  the valid work. A denial by the host permission system is different: stop that
  action and report it, without changing permissions or switching routes.
- Demonstrate uncertain-reply recovery, identical retry without a duplicate effect,
  and a changed request under an accepted key being refused. Retain enough exact
  requests and receipts for independent comparison.
- Use all seven configured read-only hag MCP tools on meaningful selected views.
  Preserve exact request/response inputs, completeness and continuation. Read any
  saved result where permitted. Do not interpret omitted content as a complete set.
- Export an earlier and a later immutable snapshot into separate new local
  destinations. The independent reviewer will reconstruct their Git history and
  check exact bytes and original test candidate bindings with released 0.22.1.

Retain requests, full results and commands under the current test directory. Write
`native-report.md` and `native-observations.json` with actual case outcomes, failures,
uncertainties, interventions, important IDs/views/keys, exported paths and evidence.
Do not invent a pass, use an opaque all-steps script, rewrite approved real artifacts,
or substitute candidate source for the released governor. If a runtime/protocol or
permission blocker prevents a required operation, retain the exact result and stop
that operation. Continue only independent allowed observations. Avoid retry loops.

## Session tool boundary

The human explicitly approved this session's scoped reads/writes, seven read-only
MCP tools, and the fixed one-call helper. Existing deny rules and normal checks
remain in force. Stop a newly denied action; do not change permission settings.

For shell operations use the fixed helper prefix below. Read its help and the
actual input/result files. Each call performs one operation chosen by you; it
provides no artifact content, lifecycle decision, sequence or recovery. Use native
Read/Write/Edit tools for files where available. Codex may use its ordinary
workspace tools under normal review. The helper's `identity`, `encode-file`,
`assert-greeting`, and `remote` subcommands are the available bounded operations.

```text
C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe -I C:/Users/mathi/Documents/Codex/2026-09-20/verity-plane-plugin-verity-plane-se/work/hag-agent-qualification-execution-20261007/claude/native02/inputs/native_call.py
```

Released instruction resources are staged at `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\inputs\released-resources`.

## Exact synthetic decision inputs

This is a fresh independent session. Do not read earlier sessions or their outputs.
The synthetic decision owner is `test-owner`. The supplied risk option is
`mitigate`, using the work order you author. Risk acceptance is not supplied.
The prepared test VREC owner and verification decision actor are `quality-owner`.
The prepared test RLS owner and release decision actor are `release-owner`.
The work execution actor is `test-executor`. These are fixture inputs, not real
human decisions. Preserve the supplied choices and identities.

This session uses Claude Opus 4.6. Its working directory is `C:\Users\mathi\Documents\Codex\2026-09-20\verity-plane-plugin-verity-plane-se\work\hag-agent-qualification-execution-20261007\claude\native02\work\opus01`.
