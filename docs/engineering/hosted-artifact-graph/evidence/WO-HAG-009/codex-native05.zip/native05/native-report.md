Native hosted-workflow qualification — native05, 2026-10-07

The local assertion proved that the immutable fixture's greeting() returns exactly **Hello rehearsal**. The synthetic engineering lifecycle completed: WO-NAT-001 is implemented, VREC-NAT-001 is verified, and RLS-NAT-001 is released for test version 0.0.1. Two immutable exports are retained with matching file and bundle hashes. Independent reconstruction and released-evaluator replay remain the reviewer's task; this report does not claim that replay passed.

[Machine-readable observations](native-observations.json) contain case outcomes, identities, final states, views, receipts and limitations. Full commands, exact requests and full results are retained in work/. This is a disposable private test copy. All decisions and actor labels are synthetic; Git remains authoritative for real work.

The selected service is http://127.0.0.1:50150, project 2fb54ebb-267a-4426-945c-1c82018027cb, schema revision 2, authority_mode sandbox-projection. Its component tuple matched combination sha256:72a748b863ede765136e7453ef11b314a2d283d72475d242e45dea592cb2ce91. The supplied client is 0.22.2, wheel SHA-256 95079598c5e533a4f51c61db96bdf6572d4a68bcf776c3ee3386462321c850dc; candidate Codex plugin is 0.2.7. Setup verified supplied identities without installing anything, modifying the real host plugin or activating another checkout. Only the credential environment-variable NAME was used; no values or credential stores were inspected.

The exact released evaluator is 0.22.1, archive SHA-256 cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053, payload SHA-256 0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff. Service readiness and checkpoint-free check output are context reporting. They were never treated as passed lifecycle gates. Actual gate results are in each preview/apply receipt; final validation is valid with zero errors, zero warnings and one untouched historical advisory (W-AUT-022 in SPEC-P3-900).

Candidate identities are distinct:

| Meaning | Identity |
|---|---|
| Implementation candidate C | 7f2a16e190de183a021adafbf0aa7838ddf7f40a |
| Immutable fixture source S | 5820415917e87b64d80bad2f7c39c6d18d692829 |
| Completed test candidate P | 87daba6465ccfa24c84d0d85c1ee10aa76141daf |
| Scope comparison base | e4296e700977995d65f1a7bf78f2dc3549ebed72 |
| Final context | eade861b-6a14-4cad-a388-c54a00516c1c, version 26, project 28 |

The selected candidate setup/change/evidence/orient instructions and relevant released resources were read explicitly. [File-read trace](work/file-read-trace.json) records exact paths, hashes and read triggers. No other agent was used. No walkthrough, fixture authoring function, test driver or earlier host transcript was read to obtain requests. Linked historical reports mentioned in the allowed product references were not opened. Automatic instruction injection is unobserved.

The source at inputs/source/src/greeting.py is:

```python
def greeting():
    return 'Hello rehearsal'
```

Its SHA-256 remained dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1. [Local assertion record](work/assertion.json) preserves the actual isolated Python command, source path, exit 0, stdout exactly `exact greeting passed\n`, and empty stderr. The assertion was executed locally through the fixed helper. No service endpoint ran source tests. The exported handoff includes that exact assertion record plus review evidence and generated handoff evidence.

Independent INT/CAP/REQ/SPEC/VER/WO/REL-NAT-001 definitions were authored for this outcome. The work scope explicitly lists the new artifacts, src/greeting.py and docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/. Commit-bound verification was required. Definitions and bounded work were accepted using test-owner; execution used test-executor. RISK-NAT-001 records the risk of treating a lifecycle receipt as source-test proof. DEC-NAT-001 selected exactly mitigate, actor test-owner, mitigated_by WO-NAT-001. The decision is decided and the risk remains mitigating; risk acceptance was not supplied or used.

Work approval, start, in-scope handoff and completion passed their selected gates. The work finished at P above. quality-owner prepared and verified VREC-NAT-001 against P and the retained evidence. release-owner prepared and assessed RLS-NAT-001 against approved REL-NAT-001 and verified VREC-NAT-001. The final release decision passed QG-G5-RELEASE-DECISION and QG-STRUCTURAL, including verified inclusion. The required tag field v0.0.1 is only a synthetic record label. No real Git tag, push, publication, installation or deployment occurred.

| Required boundary/recovery case | Actual observation and effects |
|---|---|
| Stale preview after selected draft change | The initial definitions preview used project 16/context 14. Revising SPEC-NAT-001 advanced to 17/15. Applying the old preview with its original guards returned HTTP 409 HAG_REMOTE_STALE_PROJECT. No revisions or files changed; subsequent inspection found the drafts at 17/15. A fresh preview then enabled valid approval. This is an observed stale-version refusal, not an isolated stale-digest guard test. |
| Out-of-scope handoff | docs/native05-outside.txt caused HTTP 422 HAG_REMOTE_EVALUATOR_REFUSED, WEX201 and failed QGP-G4I-PATHS. No accepted files/revisions; WO stayed in_progress and project stayed 22. The separately authored valid handoff then passed. |
| Uncertain accepted reply | native05-definitions-apply returned client exit 2, empty stdout and transport outcome unknown. Lookup of the original key recovered an accepted immutable receipt with project 17→18/context 15→16. |
| Identical retry | One retry reused the original request file, key and expected versions. Its entire canonical receipt equals the lookup receipt. Project stayed 18; no duplicate effect. |
| Changed request under accepted key | Changing the first transition reason under native05-definitions-apply returned HTTP 409 HAG_REMOTE_KEY_REUSE, with empty effects; project stayed 18. |

Recovery receipt: sha256:818d5af0e5cb8fa9b579f182197c898e22a57b1aabb79d8112da0824866322b4. Request digest: sha256:e79647de1ab48c34e9d92fcc150570a49a47afed9880e2a64326ebace877bd9e. Exact evidence: [original request](work/definitions-apply.request.json), [lost reply](work/definitions-apply.result.json), [lookup](work/definitions-lookup.result.json), [retry](work/definitions-retry.result.json), [conflicting request](work/definitions-key-conflict.request.json), [conflict result](work/definitions-key-conflict.result.json), [comparison audit](work/comparison-audit.json). Scope refusal is retained in [request](work/handoff-outside.request.json) and [result](work/handoff-outside.result.json); the stale refusal is retained in [request](work/definitions-stale-apply.request.json) and [result](work/definitions-stale-apply.result.json). These are service/evaluator refusals. No host permission denial occurred and no permissions were changed.

All seven configured read-only MCP tools were used on meaningful explicit views:

| Tool | Selected observation |
|---|---|
| work_context | Imported WO-P3-900 governing context, before independent authoring |
| revision | New intent template, paired risk/decision, and ready RLS exact revision documents |
| check | Implemented WO-NAT-001 at context 22; checkpoint-free context, not gate approval |
| compare | Earlier versus later immutable export baseline: only VREC-NAT-001 changed and RLS-NAT-001 was added |
| impact | REQ-NAT-001 dependent work, verification, release and risk/decision relationships |
| lineage | RLS-NAT-001 selected release/verification/work lineage |
| cypher | Bounded documented Revision query returned RLS-NAT-001 / released |

[Read index](work/mcp-read-index.json) retains every exact request/result path, view and completeness/continuation metadata. All ten responses report complete=true, continuation=null and no unresolved references. No partial or tool-managed saved-file response occurred; no omitted content was treated as a complete collection. Full saved local results were read. The bounded Cypher result proves only its selected query, not arbitrary database privileges.

| Export | Earlier | Later |
|---|---|---|
| Destination | [work/export-early](work/export-early/manifest.json) | [work/export-late](work/export-late/manifest.json) |
| Point in lifecycle | VREC ready, before verification decision | VREC verified and RLS released |
| Baseline | se-harness-artifact-baseline/v1:sha256:6d4d5b8b41a650237d97fddb24beb0c7413dc9c8c6b949b0092a2c0a20c7f8e4 | se-harness-artifact-baseline/v1:sha256:a99a9baa01630658725c33448fda508472d5f15a07da0e63468f8faf67546734 |
| Snapshot | sha256:e50d727f1fb7aa3b7e9c1ab07c59dfea5314325e29e35bec88c427f23c8c313f | sha256:a48777f4b6379d29a6dfde67975eb0d76761cfb14e4e27fde073187645294711 |
| Head | a541a21ced17e826007906459b2b8f04b047cbda | 1ba6eed8b9dd0f70ca95995b2d992a4f7c0badfa |
| Files | 27 | 29 |
| Git bundle SHA-256 | 5455aa6bf6fc30fe295abd45c2c86268f6821fc778e7d09b7a5a1e6c5608c72f | 28fcb4e59fe3bda82ac48a1d557dccd0cfc2dccb0fcef1fcf2435b55e54ebda8 |

Each destination contains files/, manifest.json and history.bundle. [Byte audit](work/export-byte-audit.json) verified every exported byte count and SHA-256 plus both bundles. Both manifests retain identical original candidate bindings, P and its 25-file map, evaluator identity and source S. [Reference history audit](work/reference-history-audit.json) confirms all seven imported -900 artifacts exactly match the supplied source in both exports. No decisions were applied to those records. The reviewer can reconstruct each separate Git history from its bundle and check P using released 0.22.1; the export client explicitly reports independent_replay not yet performed.

Additional failures and corrections are retained rather than hidden. The initial draft-open for nonexistent WO-NAT-001 returned 404 HAG_REMOTE_UNKNOWN_IDENTITY; a context anchored to existing WO-P3-900 then allowed new authoring without changing the reference work order. New draft coverage advisories were corrected before approval. One read-only directory lookup for released templates returned ENOENT. A local JavaScript object-reference comparison initially printed false for candidate equality; field inspection and canonical deep JSON comparison confirmed identical content, recorded in comparison-audit.json. No human intervention was requested during the trial.

The sidecars identify evaluator version 0.22.1 but have null archive/payload fields; the exact outer receipts and manifests bind both full hashes. Database-side read-only enforcement remains explicitly deferred as RISK-HAG-001. This native trial makes no production-readiness, real engineering approval, automatic injection or external delivery claim.

[Command index](work/commands-index.json) points to exact argv/cwd/exit/stdout/stderr records and request keys. [Final validation](work/validate-final.result.json) and [release receipt](work/release-apply.result.json) establish final state. The only remaining accountable review is independent reconstruction and evaluation of the retained exports, followed by the test owner's qualification decision.
