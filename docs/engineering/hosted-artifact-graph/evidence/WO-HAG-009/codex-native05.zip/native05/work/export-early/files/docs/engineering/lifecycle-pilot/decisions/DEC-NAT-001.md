+++
id = "DEC-NAT-001"
type = "decision"
title = "Answer to the threat A lifecycle receipt could be mistaken for source-test evidence"
status = "decided"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
kind = "question"
question = "How is the threat 'A lifecycle receipt could be mistaken for source-test evidence' answered: accept, avoid or mitigate?"
raised_by = "test-executor"
recommendation = "mitigate"

[[options]]
id = "accept"
label = "Accept the threat; record a residual and a revisit trigger."

[[options]]
id = "avoid"
label = "Avoid the threat by a design change recorded in an ADR or a decision."

[[options]]
id = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."

[relations]
concerns = ["RISK-NAT-001", "WO-NAT-001"]
blocks = ["WO-NAT-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-07T03:51:56Z"
reason = "Supplied synthetic choice: mitigate using WO-NAT-001 to retain independent local assertion and source-byte binding before assessment."

[[lifecycle_events]]
from = "open"
to = "decided"
decided_at = "2026-10-07T03:51:56Z"
decided_by = "test-owner"
reason = "Supplied synthetic choice: mitigate using WO-NAT-001 to retain independent local assertion and source-byte binding before assessment."
+++

# Decision: Answer to the threat A lifecycle receipt could be mistaken for source-test evidence

## Question

How is the threat 'A lifecycle receipt could be mistaken for source-test evidence' answered: accept, avoid or mitigate? The description and the threatened artifacts are on RISK-NAT-001.

## Options

- `accept`: Accept the threat; record a residual and a revisit trigger.
- `avoid`: Avoid the threat by a design change recorded in an ADR or a decision.
- `mitigate`: Mitigate the threat through a work order; the risk closes under verified coverage.

## Recommendation

The raiser recommends `mitigate`.

## Disposition

Written by `harnessctl decide`; do not edit by hand. Disposing this decision
moves RISK-NAT-001 to the state the chosen option names, in the same act.
