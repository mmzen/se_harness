+++
id = "REL-NAT-001"
type = "release_contract"
title = "Bound the private greeting test release"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"

[relations]
gates = ["WO-NAT-001"]
+++

# Bound the private greeting test release

Synthetic private test record. Git remains authoritative for real work.

## Release scope
Test version 0.0.1 contains only WO-NAT-001 and its verified engineering record. The record is private rehearsal data.

## Gates and evidence
Require implemented work, accepted VER-NAT-001 evidence, and a verified VREC from quality-owner bound to one exact disposable candidate P. release-owner prepares and assesses the RLS after its gates pass. Preserve P when later governance commits are added.

## Rollback
If the assertion, source hash, export integrity or candidate binding fails, withhold the test release assessment and retain the refusal. No deployed product exists to roll back. Preserve immutable snapshots for comparison.

## Authority limits
No real tag, publication, push, installation or deployment is authorized. The RLS tag is only a synthetic label for 0.0.1.
