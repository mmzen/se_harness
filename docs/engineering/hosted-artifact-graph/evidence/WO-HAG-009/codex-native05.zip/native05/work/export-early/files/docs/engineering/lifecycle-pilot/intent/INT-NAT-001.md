+++
id = "INT-NAT-001"
type = "intent"
title = "Prove the fixed greeting to the operator"
status = "approved"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
outcome = "The operator can inspect greeting() and its exact assertion with an exported engineering record."
[relations]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-07T03:48:25Z"
decided_by = "test-owner"
reason = "Supplied synthetic test-owner decision: accept complete greeting definitions within the private trial."
+++

# Prove the fixed greeting to the operator

Synthetic private test record. Git remains authoritative for real work.

## Problem
The operator has a source snapshot but needs a reviewable demonstration tied to the test history.

## Success measures
After this trial, the operator can inspect one assertion and both exported snapshots. Baseline: not measured.

## Limits
Only the disposable hosted project and immutable local greeting fixture. No source edits, real decisions or external delivery.
