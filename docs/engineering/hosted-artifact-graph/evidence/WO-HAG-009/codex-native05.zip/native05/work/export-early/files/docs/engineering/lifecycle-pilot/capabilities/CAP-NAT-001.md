+++
id = "CAP-NAT-001"
type = "capability"
title = "Inspect and reproduce the exact greeting"
status = "approved"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
ability = "The operator can inspect the fixed source and independently compare its return value with the required string."
[relations]
derives_from = ["INT-NAT-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-07T03:48:25Z"
decided_by = "test-owner"
reason = "Supplied synthetic test-owner decision: accept complete greeting definitions within the private trial."
+++

# Inspect and reproduce the exact greeting

Synthetic private test record. Git remains authoritative for real work.

## Capability
Given the supplied immutable snapshot, the operator can read greeting(), run one local assertion and inspect retained evidence.

## Boundary
The service records lifecycle evidence; it never executes the source test.
