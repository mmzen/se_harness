+++
id = "VREC-NAT-001"
type = "verification_record"
title = "Verification candidate for WO-NAT-001"
status = "ready"
owners = ["quality-owner"]
created = "2026-10-07"
updated = "2026-10-07"
commit = "87daba6465ccfa24c84d0d85c1ee10aa76141daf"
git_object_format = "sha1"
worktree_state = "clean"
prepared_at = "2026-10-07T03:54:42Z"
prepared_by = "quality-owner"
artifact_snapshot_sha256 = "377e085a5e15d959a2183410da47cd86b4b31d0e3dbfba2b345183102ac824ab"
evidence_paths = ["docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/WO-NAT-001-handoff.md", "docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/assertion.json", "docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/handoff.json", "docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/review.json"]
evaluator_evidence_path = "docs/engineering/lifecycle-pilot/evidence/VREC-NAT-001-evaluator.json"
evaluator_evidence_sha256 = "2762aeaa36f7fe172361be82edb9420da8a316d972c443f2f0a37bfc54d25bc6"

[relations]
verifies_work_order = ["WO-NAT-001"]
conforms_to = ["VER-NAT-001"]
+++

# Verification Record Candidate

This ready record binds retained evidence for `WO-NAT-001` to candidate commit `87daba6465ccfa24c84d0d85c1ee10aa76141daf`. Preparation uses each selected work order's recorded execution approval. An accountable assurance owner must review the evidence and transition the record to `verified`; this command did not approve, commit, tag, release, or publish anything.

The record is intentionally created after the candidate commit it names, avoiding self-referential commit metadata.
