+++
id = "SPEC-NAT-001"
type = "specification"
title = "Exact fixed-string return contract"
status = "approved"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
contract = "Read the supplied function and compare its no-argument return with a fixed literal."
[relations]
specifies = ["REQ-NAT-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-07T03:48:25Z"
decided_by = "test-owner"
reason = "Supplied synthetic test-owner decision: accept complete greeting definitions within the private trial."
+++

# Exact fixed-string return contract

Synthetic private test record. Git remains authoritative for real work.

## Rules

### Exact greeting
The supplied src/greeting.py function greeting() MUST return the Python string "Hello rehearsal" when called without arguments. Case, one internal space and absence of a trailing newline are significant.

### Exact evidence
The local assertion MUST compare with this literal, retain its actual result and preserve source bytes. An exception or mismatch fails verification. The hosted service MUST NOT be described as running this assertion.

## Example
Calling greeting() produces "Hello rehearsal". No additional behavior or architecture change is required. A direct equality test is sufficient for this fixed-string contract.

## Coverage
REQ-NAT-001 is covered by the Exact greeting and Exact evidence sections above.
