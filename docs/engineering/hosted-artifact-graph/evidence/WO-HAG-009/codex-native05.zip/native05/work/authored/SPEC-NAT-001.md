+++
id = "SPEC-NAT-001"
type = "specification"
title = "Exact fixed-string return contract"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
contract = "Read the supplied function and compare its no-argument return with a fixed literal."
[relations]
specifies = ["REQ-NAT-001"]
+++

# Exact fixed-string return contract

Synthetic private test record. Git remains authoritative for real work.

## Rules

### NAT-GREET-001
The supplied src/greeting.py function greeting() MUST return the Python string "Hello rehearsal" when called without arguments. Case, one internal space and absence of a trailing newline are significant.

### NAT-EVID-002
The local assertion MUST compare with this literal, retain its actual result and preserve source bytes. An exception or mismatch fails verification. The hosted service MUST NOT be described as running this assertion.

## Example
Calling greeting() produces "Hello rehearsal". No additional behavior or architecture change is required. A direct equality test is sufficient for this fixed-string contract.

## Coverage
| Requirement | Rules |
| --- | --- |
| REQ-NAT-001 | NAT-GREET-001, NAT-EVID-002 |
