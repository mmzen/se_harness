```toml
artifact = "WO-NAT-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "4960879150a6484222313b73618ef8da3649d7377562a52dc76a8258e8dcd7e8"
rebound_at = "2026-10-07T03:53:26Z"
```

# WO-NAT-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
