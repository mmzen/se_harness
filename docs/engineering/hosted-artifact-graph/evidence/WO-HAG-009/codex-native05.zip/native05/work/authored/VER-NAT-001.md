+++
id = "VER-NAT-001"
type = "verification"
title = "Verify greeting against the fixed literal"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"

[relations]
verifies = ["REQ-NAT-001"]
+++

# Verify greeting against the fixed literal

Synthetic private test record. Git remains authoritative for real work.

## Independence
Expected value "Hello rehearsal" comes from REQ-NAT-001 and SPEC-NAT-001, not the candidate result.

## Requirement-to-evidence matrix
| Requirement | Method | Case or evidence | Pass condition |
| --- | --- | --- | --- |
| REQ-NAT-001 | inspection | immutable src/greeting.py | Function has the specified no-argument fixed return; source SHA-256 stays dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1 |
| REQ-NAT-001 | test | evidence/WO-NAT-001/assertion.json | Local greeting() equals exactly Hello rehearsal and assertion exits zero |

## Procedure and platform
Use the approved Python 3.14 Windows native_call.py assert-greeting --record work/assertion.json on the selected immutable local fixture. Retain the helper command, runtime, exact source digest and complete output. Do not run tests on the service. Hosted lifecycle gates use released evaluator 0.22.1.

## Evidence retention
Retain the exact assertion under docs/engineering/lifecycle-pilot/evidence/WO-NAT-001/assertion.json and its review under the same directory. Bind verification to the service-generated disposable Git candidate P; preserve source fixture S separately.

## Assessment
An exception, mismatch or changed source fails. Missing output is unperformed. quality-owner assesses the test VREC only after its evidence passes.
