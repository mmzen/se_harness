+++
id = "CAP-NAT-001"
type = "capability"
title = "Inspect and reproduce the exact greeting"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
ability = "The operator can inspect the fixed source and independently compare its return value with the required string."
[relations]
derives_from = ["INT-NAT-001"]
+++

# Inspect and reproduce the exact greeting

Synthetic private test record. Git remains authoritative for real work.

## Capability
Given the supplied immutable snapshot, the operator can read greeting(), run one local assertion and inspect retained evidence.

## Boundary
The service records lifecycle evidence; it never executes the source test.
