+++
id = "REQ-NAT-001"
type = "requirement"
title = "Return exactly Hello rehearsal"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
statement = "Calling the immutable fixture greeting() with no arguments returns exactly the string Hello rehearsal."
verification_method = ["test", "inspection"]
priority = "must"
source = "Native hosted-workflow qualification request"
measure = "One exact equality assertion passes without changing the source."
[relations]
derives_from = ["CAP-NAT-001"]
+++

# Return exactly Hello rehearsal

Synthetic private test record. Git remains authoritative for real work.

## Acceptance
On the selected local snapshot, greeting() == "Hello rehearsal" must be true, including case and spacing and excluding a trailing newline. Retain the actual command, runtime, source digest and result in the exported engineering record.

## Failure
An exception, unequal string or changed source fails this test; do not repair the immutable fixture.
