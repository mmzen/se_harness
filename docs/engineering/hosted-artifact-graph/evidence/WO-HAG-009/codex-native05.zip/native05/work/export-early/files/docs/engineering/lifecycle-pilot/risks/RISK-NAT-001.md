+++
id = "RISK-NAT-001"
type = "risk"
title = "A lifecycle receipt could be mistaken for source-test evidence"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
description = "A passed hosted lifecycle gate does not execute greeting(). Without the independent local assertion an operator could accept an untested string or the wrong source bytes."
action = "Retain the local exact-equality result and source digest through WO-NAT-001 before verification."
raised_by = "test-executor"
likelihood = 2
impact = 3
score = 6

[relations]
threatens = ["WO-NAT-001"]
mitigated_by = ["WO-NAT-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-07T03:51:56Z"
reason = "Supplied synthetic choice: mitigate using WO-NAT-001 to retain independent local assertion and source-byte binding before assessment."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-07T03:50:55Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-07T03:51:56Z"
decided_by = "test-owner"
reason = "Supplied synthetic choice: mitigate using WO-NAT-001 to retain independent local assertion and source-byte binding before assessment."
+++

# Risk: A lifecycle receipt could be mistaken for source-test evidence

## Description

A passed hosted lifecycle gate does not execute greeting(). Without the independent local assertion an operator could accept an untested string or the wrong source bytes.

## Next action

Retain the local exact-equality result and source digest through WO-NAT-001 before verification.
