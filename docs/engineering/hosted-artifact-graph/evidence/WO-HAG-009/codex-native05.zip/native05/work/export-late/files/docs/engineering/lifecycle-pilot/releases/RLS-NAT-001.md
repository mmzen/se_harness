+++
id = "RLS-NAT-001"
type = "release_record"
title = "Release candidate 0.0.1"
status = "released"
owners = ["release-owner"]
created = "2026-10-07"
updated = "2026-10-07"
version = "0.0.1"
commit = "87daba6465ccfa24c84d0d85c1ee10aa76141daf"
git_object_format = "sha1"
prepared_at = "2026-10-07T03:56:25Z"
prepared_by = "release-owner"
evaluator_evidence_path = "docs/engineering/lifecycle-pilot/evidence/RLS-NAT-001-evaluator.json"
evaluator_evidence_sha256 = "1521d0f7b70cf50ac623f3fb80a2d95bdc28293681b809002573d3115629707c"
tag = "v0.0.1"

released_at = "2026-10-07T03:59:03Z"
authorized_by = "release-owner"
[relations]
satisfies = ["REL-NAT-001"]
includes_verification = ["VREC-NAT-001"]
releases_work = ["WO-NAT-001"]

[[lifecycle_events]]
from = "ready"
to = "released"
decided_at = "2026-10-07T03:59:03Z"
decided_by = "release-owner"
reason = "Supplied synthetic test release decision for version 0.0.1 after evidence and gates pass. Candidate 87daba6465ccfa24c84d0d85c1ee10aa76141daf, WO-NAT-001 and verified VREC-NAT-001 only. No tag, publication, installation or deployment authorized."
+++

# Release Record Candidate

This ready record proposes release `0.0.1` for `WO-NAT-001` from candidate commit `87daba6465ccfa24c84d0d85c1ee10aa76141daf`. An accountable release owner must review and transition it to `released`; this command did not approve, commit, tag, release, or publish anything.

The release candidate commit may precede the governance commit retaining this record. Any release tag must be created and checked by the authorized release process.
