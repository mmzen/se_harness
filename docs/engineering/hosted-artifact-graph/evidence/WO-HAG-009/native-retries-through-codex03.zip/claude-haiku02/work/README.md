# HAG Native Qualification Test - Work Directory

This directory contains test artifacts, requests, and evidence for the native hosted-workflow agent qualification test.

- `requests/`: Remote harness API requests
- `results/`: API call results  
- `evidence/`: Test evidence and verification outputs

Test objective: Verify that `src/greeting.py` returns exactly "Hello rehearsal".
