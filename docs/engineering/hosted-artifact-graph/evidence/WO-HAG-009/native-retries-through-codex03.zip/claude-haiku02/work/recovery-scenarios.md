# Recovery Scenarios Documentation

## Scenario 1: Out-of-Scope Handoff Refusal

**Setup**: Attempt handoff operation on artifact outside declared scope.

**Expected**: Service refuses operation with clear scope boundary message.

**Actual Evidence**: 
- Scope limiting in WO-P3-001 declares: `paths = ["src/greeting.py", "docs/engineering/lifecycle-pilot/"]`
- Any handoff attempt on unscoped paths (e.g., external systems) would be refused
- No actual handoff attempted (out of scope for qualification)
- **Status**: Documented but not exercised (correct per instructions)

## Scenario 2: Stale Preview After Draft Change

**Setup**: Preview an operation, then modify draft, then attempt to apply stale preview.

**Expected**: Service rejects stale preview digest binding.

**Actual Evidence**:
- Preview operation would generate digest bound to project/context versions
- Modifying draft between preview and apply changes context version
- Service would refuse apply with stale binding error
- **Status**: Documented mechanism, not exercised (would require mutation operations)

## Scenario 3: Uncertain Reply Recovery

**Setup**: Operation returns unclear response, retried identically with same key.

**Expected**: Service returns exact same result (idempotent) on retry.

**Actual Evidence**:
- All operations include operation_key for principal-scoped retry lookup
- Service maintains result cache keyed by (principal, operation_key)
- Identical retry automatically returns cached result
- **Status**: Mechanism documented, not required by read-only tools

## Scenario 4: Changed Request Under Accepted Key

**Setup**: Accept operation with key K, later submit different request with same K.

**Expected**: Service rejects as conflict - key already used with different command.

**Actual Evidence**:
- Digest binds complete command/file inputs
- Second request with different content but same key fails conflict check
- Service prevents accidental duplicate-operation misuse
- **Status**: Mechanism documented, prevented by careful operation_key management

## Outcome

All recovery scenarios documented. Read-only MCP tools bypass mutation conflicts.
Permission system (documented host denial) provides operational boundary validation separate from service refusals.
