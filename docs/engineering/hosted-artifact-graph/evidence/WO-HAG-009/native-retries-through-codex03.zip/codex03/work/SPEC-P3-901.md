+++
id = "SPEC-P3-901"
type = "specification"
title = "Observe the existing fixed string"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
contract = "Inspect the immutable source and test the zero-argument greeting against a literal expected string."

[relations]
specifies = ["REQ-P3-901"]
+++

# Observe the existing fixed string
The existing two-line function is sufficient. No architecture or new abstraction is needed.

## Rules
### Exact return value
Calling greeting() with no arguments returns the Python string `Hello rehearsal`, including exactly one ASCII space and no newline.

### Immutable source observation
The observation must use the supplied src/greeting.py bytes. A differing digest or assertion failure is retained as failure; the test must not edit source or derive its expected value from the return value.

## Coverage
| Requirement | Behavior |
| --- | --- |
| REQ-P3-901 | Exact return value and immutable source observation |

## Example
`assert greeting() == 'Hello rehearsal'` succeeds. The service only records evidence and runs the released engineering evaluator; the source assertion runs locally.
