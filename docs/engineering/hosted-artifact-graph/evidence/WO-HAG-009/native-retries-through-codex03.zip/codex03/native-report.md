# Native hosted-workflow qualification

The greeting proof, bounded work completion, and commit-bound verification passed. The overall qualification is **incomplete**: the test release authorization was refused because I prepared the release record with the wrong owner. The exact refusal and unchanged release state are retained. No successful release is claimed.

This run used only the selected disposable project `0c07f0af-551e-4962-9743-acf6f1656e42` at `http://127.0.0.1:57708`, in context `b5d03dd0-6016-42bd-a159-87c98141381a`. Final project/context versions are **27/25**. The service identifies itself as a schema-2 test copy using sandbox projection; Git remains authoritative. All actor labels and decisions are synthetic test inputs.

## Identities and instructions

The selected candidate client is **0.22.2**, candidate plugin **0.2.7**, and released evaluator **0.22.1**. The supplied combination and observed service components matched; selected plugin resources and client wheel hashes matched the supplied inventory. The evaluator archive SHA-256 is `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`; its payload SHA-256 is `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff`. See [identity comparison](work/identity-comparison.json) and [machine-readable observations](native-observations.json).

I explicitly read the selected candidate setup, change, evidence, and orient instructions, relevant staged released procedures, captured CLI help, and relevant closed contracts. Setup verified supplied identities; it did not install software or activate another real checkout. Automatic instruction injection is not qualified by this run. Exact read paths, hashes, triggers, and completeness qualifications are in the [file-read trace](work/file-read-trace.json).

Context reporting was kept separate from passed gates. In particular, the final read-only check identifies the next release decision but reports checkpoint-free compliance as `not_assessable`; that read is not evidence that release authorization passed.

## Source proof and engineering record

The immutable supplied source is [greeting.py](inputs/source/src/greeting.py), from source commit `5820415917e87b64d80bad2f7c39c6d18d692829`, with SHA-256 `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`. I inspected its existing function and ran the fixed local assertion helper. Its retained command evaluates `greeting()` and asserts equality to the independently written literal `Hello rehearsal`.

The [exact assertion receipt](work/assertion.json) records exit **0**, empty stderr, and stdout exactly:

```text
exact greeting passed
```

The receipt retains the trailing newline, exact executable, arguments, and working directory. No service endpoint ran the source test. No source file was modified. The retained assertion file SHA-256 is `14e94a078b52e5084fbeec432595698614f994d1ffe95ff12504d85fabaf83b4` and matches the bytes in both exports.

I authored new `INT-P3-901`, `CAP-P3-901`, `REQ-P3-901`, `SPEC-P3-901`, `VER-P3-901`, `REL-P3-901`, and `WO-P3-901`. The six definitions are approved, the work order is implemented, and `VREC-P3-901` is verified by `quality-owner`. The work paths were restricted to the selected new artifacts, `src/greeting.py`, and the work order's retained evidence directory, with generated record paths handled by the released workflow. `REL-P3-901` specifies test version **0.0.1**. Imported `-900` history remains byte-for-byte unchanged in both exports.

The source-attribution risk `RISK-P3-901` is `mitigating`; paired `DEC-P3-901` is `decided`, choosing `mitigate` under `test-owner` using `WO-P3-901`. The handoff and implementation gates passed. The original verification candidate is `de083d8e0b0029659e8c9750de70da8a7db5e38c`, bound to input hosted baseline `se-harness-artifact-baseline/v1:sha256:e74796e4ee4fa5288ade3ae1ff27f155619ba9d970c510717ece4f465e1f025c`. Both exports preserve that candidate. The retained handoff Git base is `7ef866fffef32cb1b5e098a51ac169ce4c31538c`; it covers approvals, risk decision, execution, and evidence, while initial draft preparation preceded it.

Final validation passed with **18 artifacts, zero errors, zero warnings**, and one existing advisory on immutable `SPEC-P3-900` (`W-AUT-022`). Full commands, requests, results, returned revisions, versions, and keys are indexed in [command receipts](work/command-receipt-index.json).

## Required refusal and recovery cases

| Case | Observed result and effects | Evidence |
| --- | --- | --- |
| Selected draft changed after preview | Changing `SPEC-P3-901` advanced versions from 16/14 to 17/15. Applying the old preview returned HTTP 409 `HAG_REMOTE_STALE_PROJECT`, with no effects. A fresh preview then passed. | [Refusal](work/023-stale-apply-result.json), [unchanged-state read](work/024-mcp-work-context.json), [fresh preview](work/025-definitions-preview-result.json) |
| Accepted reply lost | Definition apply returned transport uncertainty, exit 2 and empty stdout. Lookup of `native03-definitions-apply` showed the operation had been accepted exactly once, advancing 17/15 to 18/16. | [Exact request](work/026-definitions-apply-request.json), [transport result](work/026-definitions-apply-result.json), [lookup](work/027-operation-lookup-result.json) |
| Identical retry | Reusing the exact request and key returned the same accepted receipt, baseline, versions, and stdout bytes; no duplicate effect was observed. | [Retry](work/028-identical-retry-result.json), [comparison](work/retry-comparison.json) |
| Changed request under accepted key | Changing the reason under the same accepted key returned HTTP 409 `HAG_REMOTE_KEY_REUSE`, with no effects. | [Changed request](work/029-changed-key-request.json), [refusal](work/029-changed-key-result.json) |
| Out-of-scope handoff | Evidence proposed outside the work order's directory returned HTTP 422 `HAG_REMOTE_EVALUATOR_REFUSED`, `QGP-G4I-PATHS` / `WEX201`. No files or affected records were returned; versions remained 22/20. | [Request](work/040-outside-request.json), [refusal](work/040-outside-result.json), [subsequent read](work/041-mcp-impact.json) |
| Valid handoff | The same assertion bytes at the authorized evidence path passed scope, review, preparation, and Git handoff gates, then applied successfully. Work completion passed afterward. | [Preview](work/042-handoff-preview-result.json), [apply](work/043-handoff-apply-result.json), [completion](work/045-complete-apply-result.json) |

The accepted definition receipt is `sha256:c7aeb4df46635e8513e5fbc2379222cbcdf45a51ec8af459752f94be393342bc`; its request digest is `sha256:9274a41268ff25d935452df0ccd6b30aa894049eeac8502f44537e2fbefd3138`. Exact original and changed request hashes are retained in the comparison evidence. These were service/evaluator refusals, not host permission denials. No host permission denial occurred, and no permission settings were changed.

An earlier context-open attempt naming the not-yet-created `WO-P3-901` returned HTTP 404 `HAG_REMOTE_UNKNOWN_IDENTITY`. I then opened a drafting context referencing imported `WO-P3-900`; no imported record received a decision or amendment. See [initial refusal](work/003-open-result.json).

## Release assessment failure

Release preparation passed and created `RLS-P3-901` in `ready`, for version `0.0.1`, preserving the original verification candidate. I supplied **test-executor** as its preparation owner. That was an agent input error against the requested release-owner role. The resulting owners list contains only `test-executor`.

The subsequent preview using the required **release-owner** returned HTTP 422 `HAG_REMOTE_EVALUATOR_REFUSED`:

```text
WEX201: proposed final graph is invalid [E009]: field 'authorized_by' must identify one of the record owners
```

The [exact refused release result](work/054-release-preview-result.json), [prepared record read](work/053-mcp-release-revision.json), and [subsequent context check](work/055-mcp-check.json) retain the evidence. No release effect was applied; versions remained 27/25 and `RLS-P3-901` remains `ready`. I stopped the affected release mutation, retained the failure, and completed independent read and export observations. I did not substitute the execution actor as authorizer, rewrite the generated record, or invent an owner-amendment route absent from the supplied closed actions. A documented permitted resolution of the owner mismatch is required before another release mutation. No tag, push, publication, installation, or deployment occurred.

## Read tools and immutable exports

All seven configured read-only MCP tools were exercised on meaningful selected views: `check`, `compare`, `cypher`, `impact`, `lineage`, `revision`, and `work-context`. The **11 calls** retain exact requests and full responses in [the MCP index](work/mcp-index.json). Every response reported `complete: true`, null continuation, and no unresolved references. No saved-result notice occurred. No omitted content was treated as a complete set. Some large shell displays were truncated; full receipts remained on disk and relevant fields were reread.

| Snapshot | Destination | Git head | Files |
| --- | --- | --- | --- |
| Earlier, after capture and before verification acceptance | [export-early](work/export-early/manifest.json) | `1eb0d035f24ab30a6c957d38f16db3402ca463d7` | 26 |
| Later, after verification acceptance and release preparation | [export-late](work/export-late/manifest.json) | `b9203ed7664c8dcfcc1b189d45857ad8bfbd2193` | 28 |

Each separate destination contains `files/`, `history.bundle`, and `manifest.json`, with no incomplete marker. Every exported file's bytes and size match its manifest; both bundle hashes match. Bundle SHA-256 values are `48f289d94a3865957b3d2336d29f4ae2dbcf84d3d19d9ef403d9647d0ffebb4b` (earlier) and `4b73b691136276fdb7110922e7834d608717594ed29f250dee9b78497fa18174` (later). Snapshot IDs, baseline IDs, file checks, imported-history equality, assertion equality, and original candidate equality are retained in [observations](native-observations.json), [earlier byte checks](work/early-byte-check.json), [later byte checks](work/late-byte-check.json), and [export comparison](work/export-comparison.json).

The independent reviewer can reconstruct the exported Git histories and evaluate the original bindings using released **0.22.1**. I did not perform that independent reconstruction and do not claim it passed.

## Limitations and interventions

No human intervention was requested during the run, no delegation occurred, and no credential value or credential store/file was inspected. The credential variable name alone is recorded. No real repository source, Git history, account setting, or installed plugin was changed. Calls used the supplied one-operation helper; no opaque end-to-end launcher was authored.

The supplied implementation candidate identity was retained but its source was not independently inspected. The capture evaluator sidecar uses origin-version identity with null wheel/payload hashes; the later preparation sidecar uses full-payload identity matching released 0.22.1. Both are exported unchanged. The service status reports database read-only enforcement deferred under `RISK-HAG-001`. The verification text described the fixed Python 3.14 helper, while the assertion receipt records the actual separate candidate-environment Python used to run the assertion; that executable's exact runtime version was not separately measured.

The complete observed outcome, failures, boundaries, identifiers, evidence paths, and next decision are recorded in [native-observations.json](native-observations.json). The outstanding operation is successful test release authorization after a documented resolution of the preparation-owner mismatch.
