+++
id = "SPEC-P3-001"
type = "specification"
title = "Fixed rehearsal greeting contract"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
contract = "Return the fixed greeting string without external effects."

[relations]
specifies = ["REQ-P3-001"]
+++

# Fixed rehearsal greeting contract

Synthetic rehearsal input. This is not a real human decision.

## Scope

This specification governs the greeting() function return value only.

**P3-GREET-001.** The function greeting() MUST return the string `Hello rehearsal`.

**P3-GREET-002.** The function greeting() MUST NOT produce side effects.

## Coverage

| Requirement | Rules |
| --- | --- |
| REQ-P3-001 | P3-GREET-001, P3-GREET-002 |
