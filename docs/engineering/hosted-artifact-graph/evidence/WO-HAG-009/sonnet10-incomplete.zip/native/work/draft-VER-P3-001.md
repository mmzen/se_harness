+++
id = "VER-P3-001"
type = "verification"
title = "Assert greeting return value by direct comparison"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"

[relations]
verifies = ["REQ-P3-001"]
+++

# Assert greeting return value by direct comparison

Synthetic rehearsal input. This is not a real human decision.

## Independence

Expected value Hello rehearsal is fixed by REQ-P3-001, not candidate output.

## Requirement-to-evidence matrix

| Requirement | Method | Case | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-001 | test | exact greeting assertion | Equals Hello rehearsal |

Retain the actual assertion result in docs/engineering/lifecycle-pilot/evidence/WO-P3-001/assertion.json.
