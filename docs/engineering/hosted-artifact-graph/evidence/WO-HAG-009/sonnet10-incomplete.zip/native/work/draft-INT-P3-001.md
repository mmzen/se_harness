+++
id = "INT-P3-001"
type = "intent"
title = "Prove the greeting function returns Hello rehearsal"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
outcome = "The test executor observes greeting() returns exactly Hello rehearsal."

[relations]
+++

# Prove the greeting function returns Hello rehearsal

Synthetic rehearsal input. This is not a real human decision.

The test owner needs proof that the local fixture greeting() returns the exact text Hello rehearsal for the disposable lifecycle rehearsal. Success is an observed exact assertion and exported test evidence. No real product or release is involved.

## Baseline

not measured

## Success measure

assertion output equals Hello rehearsal

## Operating context

Disposable test copy; one qualification run.

## Out of scope

Real engineering records, real human decisions, external actions, or production deployment.
