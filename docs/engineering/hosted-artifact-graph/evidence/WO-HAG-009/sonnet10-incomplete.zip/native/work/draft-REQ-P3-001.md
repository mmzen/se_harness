+++
id = "REQ-P3-001"
type = "requirement"
title = "greeting() returns exactly Hello rehearsal"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
statement = "Calling greeting() returns the string Hello rehearsal."
verification_method = ["test"]
priority = "must"
source = "Synthetic Phase 3 qualification fixture"
measure = "Return value equals Hello rehearsal."

[relations]
derives_from = ["CAP-P3-001"]
+++

# greeting() returns exactly Hello rehearsal

Synthetic rehearsal input. This is not a real human decision.

## Acceptance

Calling greeting() with no arguments returns exactly `Hello rehearsal`. No other return value satisfies this requirement.

## Failure behavior

If greeting() returns any other value, the assertion fails.
