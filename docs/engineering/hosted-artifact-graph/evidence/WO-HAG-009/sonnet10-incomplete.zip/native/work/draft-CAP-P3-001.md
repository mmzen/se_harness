+++
id = "CAP-P3-001"
type = "capability"
title = "Assert the exact greeting return value"
status = "draft"
owners = ["test-owner"]
created = "2026-10-07"
updated = "2026-10-07"
ability = "Assert that greeting() returns exactly Hello rehearsal."

[relations]
derives_from = ["INT-P3-001"]
+++

# Assert the exact greeting return value

Synthetic rehearsal input. This is not a real human decision.

The test executor can directly invoke greeting() and compare its return value to the fixed string Hello rehearsal.
