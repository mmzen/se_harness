"""Retain C43 native qualification and the failed first focused diagnostic."""
import hashlib,json,re,sys,zipfile
from pathlib import Path
import hag_efficiency_plan as p
W=p.W;O=W/'h43';mode=sys.argv[1]
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
groups=[('f','WO-HAG-009','final43-result',['claude-401','codex-401']),('e','WO-HAG-011','focused43-result',['claude-411'])]
if mode=='scope':
 p.O=O
 for group,wo,name,trials in groups:
  names=['assessment.md','provenance.zip','provenance-inventory.json']+[t+s for t in trials for s in ('-evidence.zip','-visible.md','-inventory.json')]
  paths=[(p.D/'evidence'/wo/name/n).relative_to(p.R).as_posix() for n in names]
  v=p.gov(name+'-scope','check',p.R,'--artifact',wo,'--checkpoint','scope','--changes-complete',*[x for path in paths for x in ('--changed-path',path)],'--json')
  assert v['compliance']['status']=='pass';print(name,'scope pass',flush=True)
elif mode=='retain':
 for group,wo,name,trials in groups:
  assert json.loads(load(O/(name+'-scope.json'))['stdout'])['compliance']['status']=='pass'
  E=p.D/'evidence'/wo/name;E.mkdir(exist_ok=False)
  source=(W/'hag_retain36.py').read_text().replace('hag-procedure36-20261011','h43/'+group).replace('WO-HAG-009/procedure36-result',wo+'/'+name)
  source=source.replace('replay36','replay43').replace('native-parity-*36','native-parity-*43')
  source=source.replace("names=['initial-status.json'", "names=['input-fidelity.json','independent-final-reply.md','persisted-instruction-recovery.json','initial-status.json'")
  for trial in trials:
   sys.argv=[__file__,trial];exec(compile(source,'retain43','exec'),{'__file__':str(W/'hag_retain36.py'),'__name__':'__main__'})
  files={}
  for f in (O/group).glob('*.json'):
   if any(x in f.name for x in ('live-probe','version','auth')) and 'review' not in f.name:continue
   files['observations/'+f.name]=f.read_bytes()
  for f in O.glob('*.json'):
   if any(x in f.name for x in ('candidate-43','comparison','client-equality','build43-replay','ci43','integration-archive','resume-401','retained-archive-check')):files['candidate/'+f.name]=f.read_bytes()
  for name0 in ('hag_runs43.py','hag_full40.py','hag_eff41.py','hag_native26.py','hag_native27.py','hag_full27.py','hag221_execute.py','hag_efficiency_plan.py','hag_full43_probe.py','hag_eff43_probe.py','hag_review43.py','hag_full27_review.py','hag_trace43.py','hag_full27_trace.py','hag_facts43.py','hag_observe43.py','hag_input43.py','hag_full43_parity.py','hag_native_parity19.py','hag_retain43.py','hag_retain36.py','hag_retain26.py','hag_assess_full43.py','hag_read_recovery43.py'):
   files['drivers/'+name0]=(W/name0).read_bytes()
  tokens=[x['token'].encode() for f in (O/group).glob('*/credentials.json') for x in load(f)['principals']]
  for n,raw in files.items():
   assert not any(t in raw for t in tokens),n
   assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),n
  with zipfile.ZipFile(E/'provenance.zip','x',zipfile.ZIP_DEFLATED) as z:
   for n,raw in sorted(files.items()):z.writestr(n,raw)
  (E/'provenance-inventory.json').write_bytes((json.dumps({'archive':'provenance.zip','sha256':sha((E/'provenance.zip').read_bytes()),'files':[{'path':n,'bytes':len(raw),'sha256':sha(raw)} for n,raw in sorted(files.items())],'omissions':'No raw provider events, private reasoning, credential stores or test tokens. Native failures and observer results retained.'},indent=2)+'\n').encode())
  (E/'assessment.md').write_bytes((O/(name+'-assessment.md')).read_bytes())
else:raise ValueError(mode)
