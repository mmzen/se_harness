"""Fresh native trials on one exact candidate; unchanged accepted outcomes."""
import json,sys
from pathlib import Path
W=Path(__file__).parent;O=W/'h43';C=json.loads((O/'candidate-43.json').read_text())['commit']
group,mode,host=sys.argv[1:4]
if group=='full':
 source=(W/'hag_full40.py').read_text().replace('hag-final40-20261012','h43/f').replace('hag-authority38-20261012','h43').replace('361','401')
 for a,b in [('candidate-38','candidate-43'),('package38','package43'),('client38','client43'),('build38','build43'),('native-authority38','native-entry43'),('hag-final40-','hag-final43-'),('10.231.108.0/22','10.231.124.0/22')]:source=source.replace(a,b)
 sys.argv=[__file__,mode,host]
elif group=='eff':
 source=(W/'hag_eff41.py').read_text().replace('hag-eff41-20261012','h43/e').replace('hag-authority38-20261012','h43')
 for a,b in [('candidate-38','candidate-43'),('package38','package43'),('client38','client43'),('build38','build43'),('native-authority38','native-entry43'),('hag-eff41-','hag-eff43-'),('10.231.112.0/22','10.231.128.0/22'),('371','411'),('372','412'),('373','413'),('374','414')]:source=source.replace(a,b)
 source=source.replace('try:exec(','''source=source.replace("split('## Entry and tools'", "split('## Inputs and boundaries'")
try:exec(''')
 sys.argv=[__file__,mode,host,sys.argv[4]]
else:raise ValueError(group)
source=source.replace('ee86a842550c19fb6a56913841757b42df9ecaec',C).replace('dfeb5adf1f640dea48a53b7a446e49e93c31004a',C)
exec(compile(source,'native42-'+group,'exec'),{'__file__':str(W/'hag_full40.py' if group=='full' else W/'hag_eff41.py'),'__name__':'__main__'})
