"""Retain completed visible calls, receipts and exact read-parity observations."""
import json,sys,hashlib
from pathlib import Path
W=Path(__file__).parent;O=W/'h43/f';trial=sys.argv[1];r=O/trial;n=r/'native';w=n/'work'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
assert (n/'session.json').exists()
calls=[];writes=[]
for line,raw in enumerate((n/'events.jsonl').read_text(encoding='utf-8').splitlines(),1):
 try:e=json.loads(raw)
 except ValueError:continue
 if e.get('type')=='item.completed':
  item=e.get('item',{});typ=item.get('type')
  if typ=='command_execution':calls.append({'event_line':line,'tool':'Codex command','input':{'command':item.get('command')},'status':item.get('status'),'exit_code':item.get('exit_code')})
  elif typ=='mcp_tool_call':calls.append({'event_line':line,'tool':item.get('tool'),'input':item.get('arguments'),'status':item.get('status')})
  elif typ=='file_change':writes.append({'event_line':line,'changes':item.get('changes'),'status':item.get('status')})
 for b in e.get('message',{}).get('content',[]) if isinstance(e.get('message'),dict) else []:
  if b.get('type')=='tool_use':
   calls.append({'event_line':line,'tool':b['name'],'input':b['input']})
   if b['name'] in ('Write','Edit'):
    f=Path(b['input']['file_path']).resolve();writes.append({'event_line':line,'tool':b['name'],'path':str(f),'inside_work':f.is_relative_to(w.resolve())})
results=[];records=[]
for f in sorted(w.rglob('*')):
 if not f.is_file() or f.stat().st_size>8*1024*1024:continue
 try:v=load(f)
 except (ValueError,UnicodeError):continue
 if not isinstance(v,dict):continue
 if isinstance(v.get('argv'),list) and 'exit' in v:records.append({'file':f.relative_to(w).as_posix(),'argv':v['argv'],'exit':v['exit'],'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
 if not f.name.endswith('.stdout.txt'):continue
 actual=v.get('result',v)
 if not isinstance(actual,dict):continue
 if actual.get('schema')=='se-harness-lifecycle-result/v2':
  results.append({'file':f.relative_to(w).as_posix(),**{k:actual.get(k) for k in ['outcome','operation_key','receipt_id','preview_digest','request_digest','error','versions','affected_artifacts','baseline_id','provenance']},'evaluator_commands':[{'command':c.get('command'),'arguments':c.get('arguments'),'exit':c.get('exit')} for c in (actual.get('evaluator_output') or {}).get('commands',[])]})
parity=[load(f) for f in sorted((O/'native-parity-full43').glob('*'+trial+'*.json'))]
facts={'trial':trial,'session':load(n/'session.json'),'lifecycle_results':results,'command_records':records,'observed_write_requests':writes,'parity':[{'file':f.name,'tool':load(f)['tool'],'status':load(f).get('http_status'),'exact_match':load(f)['exact_match']} for f in sorted((O/'native-parity-full43').glob('*'+trial+'*.json'))]}
for name,value in [('review-facts.json',facts),('native-call-index.json',{'trial':trial,'calls':calls,'complete':trial.startswith('claude'),'omissions':'Private reasoning and non-tool messages excluded. Codex rows are observed completed items, not proof of complete attempted-call capture.'})]:
 f=r/name;assert not f.exists();f.write_bytes((json.dumps(value,indent=2)+'\n').encode())
print(json.dumps({'trial':trial,'calls_or_items':len(calls),'lifecycle_results':len(results),'parity':facts['parity']},indent=2))
