"""Independent C43 receipt/export assertions supporting the separate content review."""
import hashlib,json,sys,tomllib
from pathlib import Path
W=Path(__file__).parent;O=W/'h43/f';host=sys.argv[1];trial=host+'-401';r=O/trial;n=r/'native';w=n/'work'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
meta=lambda f:tomllib.loads(f.read_text().split('+++')[1])
replay=load(r/'replay43/assessment.json');summary=load(O/(trial+'-summary.json'))
assert len(replay['cases'])==12 and all(x['outcome']=='passed' for x in replay['cases'])
exports=[x for x in replay['exports'] if x['case'].startswith('native-')]
assert len(exports)==(2 if host=='claude' else 4)
parity=[load(f) for f in (O/'native-parity-full43').glob('*'+trial+'*.json')]
assert len(parity)==7 and all(x['exact_match'] and x['http_status']==200 for x in parity)
assert {x['tool'] for x in parity}=={'revision','work-context','compare','impact','lineage','check','cypher'}
assert all(x['native_result']['complete'] and x['native_result']['continuation'] is None for x in parity)
def result(prefix):
    files=list(w.glob(prefix+'*.stdout.txt'));assert len(files)==1,files
    return load(files[0])
lookup,retry,key,stale,outside,handoff=('27','28','29','24','45','47') if host=='claude' else ('22','23','24','18','41','43')
a=result(lookup);b=result(retry);assert a==b
assert result(key)['error']['code']=='HAG_REMOTE_KEY_REUSE'
assert result(stale)['error']['code']=='HAG_REMOTE_STALE_PROJECT'
if host=='codex':assert result('19')['error']['code']=='HAG_REMOTE_STALE_PREVIEW'
out=result(outside);assert out['outcome']=='refused' and not out['files'] and not out['affected_artifacts']
assert 'QGP-G4I-PATHS' in json.dumps(out) and 'WEX201' in json.dumps(out)
requests=list((w/'requests').glob(handoff+'*.json')) if host=='claude' else list(w.glob(handoff+'*-request.json'))
assert len(requests)==1,requests
assert load(requests[0])['action']['from_git']==a['provenance']['input_git_head']
final=next(w.glob('export-later*'))/'files/docs/engineering/lifecycle-pilot'
suffix='001' if host=='claude' else '901'
vrec=meta(final/'verification-records'/('VREC-P3-'+suffix+'.md'));rls=meta(final/'releases'/('RLS-P3-'+suffix+'.md'))
assert vrec['commit']==rls['commit'] and vrec['status']=='verified' and rls['status']=='released'
actors=[]
for f in final.rglob('*-'+suffix+'.md'):
    m=meta(f)
    for event in m.get('lifecycle_events',[]):
        target=event['to'];actor=event['decided_by'];expected=None
        if target=='approved':expected='test-owner'
        elif m['type']=='work_order' and target in ('in_progress','implemented'):expected='test-executor'
        elif m['type']=='verification_record' and target=='verified':expected='quality-owner'
        elif m['type']=='release_record' and target=='released':expected='release-owner'
        if expected:assert actor==expected,(m['id'],actor,expected)
        actors.append({'id':m['id'],'to':target,'actor':actor})
preserved=[];source=n/'inputs/source';originals=list(source.rglob('*-900.md'))+[source/'src/greeting.py']
for f in w.glob('export-*/manifest.json'):
    m=load(f);assert m['test_copy'] is True
    for original in originals:
        assert m['snapshot']['files'][original.relative_to(source).as_posix()]['sha256']==sha(original.read_bytes())
    preserved.append({'export':f.parent.relative_to(w).as_posix(),'original_files':len(originals)})
assert load(r/'input-integrity.json')['all_unchanged'] and load(r/'boundary-comparison.json')['equal']
assert load(n/'session.json')['exit']==0
report=(w/'native-report.md').read_text();assert 'replay' in report.lower() and ('8' in report or 'eight' in report)
value={'trial':trial,'candidate':'f0d042d69e025bdab284695e7e17667eeb38eaf3','overall':'pass','cases':{f'NQ-0{i}':'pass' for i in range(1,6)},'accepted_operations':12,'native_exports':len(exports),'mcp_calls':7,'mcp_exact':True,'test_candidate':vrec['commit'],'originals':preserved,'actors':actors,'metrics':{k:summary.get(k) for k in ('wall_seconds','native_calls','observed_tool_items','native_call_count_complete','peak_input_context')},'native_failed_items':len(summary['native_failures']),'content_review':{'method':'Manual comparison of authored records and final reports with supplied task, canonical type checklists, actual commands, complete captures and exported records. Receipt replay is a separate automated comparison.','outcome':'pass','observations':['New intent states the requested operator inspection outcome; imported history is acknowledged and preserved.','Verification expected text comes from the definitions. Local assertion capabilities and missing runtime-version field are accurately bounded.','Each generated risk/decision path is in work-order scope. REL definition approval uses supplied test-owner; release-owner is reserved for RLS.','Reports preserve recovered errors, intentional refusals, unknown reply and capture limitations; no independent replay or real release is claimed by the native agent.']},'interventions':{'corrective_prompts':0,'operator_workflow_mutations':0,'scripted_completion':False},'boundaries':{'staged_inputs_unchanged':True,'monitored_repository_and_settings_unchanged':True},'limits':['This is native qualification at C43, not final qualification of a later changed package.','Synthetic decisions and records grant no real assurance, merge, release, deployment or authority cutover.','Overlapping disposable sessions are not isolated performance benchmarks.','Explicit instruction reads do not qualify automatic startup or compaction delivery.','Codex reports observed completed items, not a complete attempted-call count; peak context is unavailable.']}
f=r/'independent-assessment.json';assert not f.exists();f.write_bytes((json.dumps(value,indent=2)+'\n').encode())
print(json.dumps({k:value[k] for k in ('trial','overall','cases','accepted_operations','native_exports','test_candidate')}))
