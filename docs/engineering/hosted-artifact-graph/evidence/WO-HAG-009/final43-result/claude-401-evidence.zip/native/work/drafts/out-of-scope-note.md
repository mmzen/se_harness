# Out-of-scope note

Deliberate test input for the out-of-scope handoff refusal. This path is not in WO-P3-001 scope.
