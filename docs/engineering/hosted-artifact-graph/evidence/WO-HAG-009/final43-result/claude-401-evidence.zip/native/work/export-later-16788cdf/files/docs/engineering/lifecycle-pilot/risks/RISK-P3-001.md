+++
id = "RISK-P3-001"
type = "risk"
title = "Greeting evidence not tied to the tested fixture bytes"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
description = "The local assertion runs on the native test host, not inside the test candidate checkout. If the retained evidence does not identify the tested src/greeting.py bytes, the test VREC could bind a candidate whose fixture differs from the bytes actually tested."
action = "Within WO-P3-001, retain the assert-greeting record, which runs only after the fixture digest matches the selected greeting_sha256, and keep src/greeting.py unchanged in the handoff."
raised_by = "test-executor"
likelihood = 2
impact = 3
score = 6

[relations]
threatens = ["WO-P3-001"]
mitigated_by = ["WO-P3-001"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-12T05:54:40Z"
reason = "Synthetic test-owner input: choose mitigation for the test risk using WO-P3-001."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-12T05:53:43Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-12T05:54:40Z"
decided_by = "test-owner"
reason = "Synthetic test-owner input: choose mitigation for the test risk using WO-P3-001."
+++

# Risk: Greeting evidence not tied to the tested fixture bytes

## Description

The local assertion runs on the native test host, not inside the test candidate checkout. If the retained evidence does not identify the tested src/greeting.py bytes, the test VREC could bind a candidate whose fixture differs from the bytes actually tested.

## Next action

Within WO-P3-001, retain the assert-greeting record, which runs only after the fixture digest matches the selected greeting_sha256, and keep src/greeting.py unchanged in the handoff.
