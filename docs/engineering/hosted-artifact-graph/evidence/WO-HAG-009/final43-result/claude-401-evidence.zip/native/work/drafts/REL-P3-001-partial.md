+++
id = "REL-P3-001"
type = "release_contract"
title = "Test release record 0.0.1 for the exact rehearsal greeting"
status = "draft"
owners = ["release-owner"]
created = "2026-10-12"
updated = "2026-10-12"
# Choose the final candidate and the work to release.
# `harnessctl release-unit . --from <tag> --to <commit>` gives advisory history.
candidate_commit = "<full commit id, 40 or 64 hex>"
previous_release_tag = "v<version>"

[relations]
gates = ["WO-P3-001"]
+++

# Release Contract: Test release record 0.0.1 for the exact rehearsal greeting

Synthetic rehearsal input for a disposable hosted test project. This contract
grants no real release, tag, publication, installation or deployment.

## Release unit

Test version `0.0.1` contains only WO-P3-001, verified by VER-P3-001. The
candidate commit is deferred: it will be the exact test candidate commit bound
by the final verified test VREC for WO-P3-001. There is no previous release.

## Required evidence

- One verified test VREC covering WO-P3-001 and VER-P3-001 at the candidate.
- The retained assertion record
  `docs/engineering/lifecycle-pilot/evidence/WO-P3-001/greeting-assertion.json`
  with exit status 0 and stdout `exact greeting passed`.

## Compatibility and migration

Not applicable. The fixture behavior does not change.

## Security and provenance

The released SE Harness 0.22.1 evaluator in the test service prepares and
checks the release record. Git remains authoritative for real work.

## Promotion policy

Prepare and record the test release record only. No tag creation, push,
publication, installation or deployment is permitted.

## Human approval triggers

`release-owner` (a synthetic test label) decides the test release record after
its gates pass. Changed inputs or scope need a new decision.

## Rollback criteria and procedure

Stop if the final candidate lacks complete verified coverage or release
approval. If export or replay of the test record fails, discard the disposable
test project; no external state needs rollback.

## Post-release observation window

Not applicable to this disposable test record.
