# Native hosted-workflow qualification report (claude-401)

All records are test data in a disposable hosted test copy. Actor labels
(`test-owner`, `test-executor`, `quality-owner`, `release-owner`) are synthetic
inputs and grant no real authority. Git remains authoritative. No push, tag
creation, publication, installation or deployment occurred.

## Outcome

The test operator can inspect `src/greeting.py` (`def greeting(): return 'Hello rehearsal'`,
SHA-256 `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`) and the
retained local assertion: exit 0, stdout `exact greeting passed`
(`work/42-assert-greeting`, record SHA-256 `6cde2095b351d0936be6c2b54e0a7eaae60852d5f358bbb108c6fbb4d7b189e8`).
The full test lifecycle completed: definitions approved, WO-P3-001 approved,
started, handed off and `implemented`; VREC-P3-001 `verified`; REL-P3-001 approved;
RLS-P3-001 (test version 0.0.1) `released` as a test record. Two immutable
snapshots were exported. Independent replay of the exports was **not** performed
by me; it is left to the reviewer.

The evaluator's current next step for RLS-P3-001 is `PROC-EXTERNAL-ACTION` /
`STEP-EXTERNAL-ACTION` (decision right `DR-EXTERNAL-ACTION`). No external-action
authority exists, so the work stops there.

## Selected context and identities

| Item | Value | Evidence |
| --- | --- | --- |
| Endpoint / project | `http://127.0.0.1:55308` / `4e5e400c-5add-431d-b214-13f80b9ae573` | `work/01-status` |
| Service | ready, `sandbox-projection`, schema revision 2, `test_copy: true`; all components equal `inputs/combination.json` | `work/01-status.stdout.txt` |
| Released evaluator (governor) | 0.22.1, archive `cb35c3c4…3053`, payload `0e7b7c2b…7ff` | `inputs/evaluator.json`, every result `/evaluator` |
| Candidate client | 0.22.2, wheel `667ba88f…dee7` | `identity` call |
| Source fixture commit S | `5820415917e87b64d80bad2f7c39c6d18d692829` | `inputs/source-manifest.json` |
| Imported baseline B0 | `…:sha256:0f1381a64266188515cbb53c97ae9ad6647a8d78d322dfebae6b45ee0058a8de` | `work/02-import` |
| Draft context | `80338d19-dab1-4c13-afc3-549605f49f1f` (opened against imported WO-P3-900 as anchor only) | `work/04-draft-open` |
| Test Git candidate P | `49b0be409a853f05653ec66a304f90a2f213c8fd` | `work/51-capture-apply.stdout.txt` `/provenance/candidates/0/test_candidate` |
| Actual implementation candidate C | `f0d042d69e025bdab284695e7e17667eeb38eaf3` (from `qualification_candidate` and `identity`) | `selection.json`, `identity` output |
| Final baseline | `…:sha256:16788cdf5db3b2e9a163c5b2b5d60ad2fddd5b11ecdcdd7f84b99dbe53763eda`, project v30 | `work/61-release-apply` |

Context reporting is separate from passed gates: `check` results for WO-P3-001
(`work/21-check-wo`) and the MCP `work-context`/`check` reads report
`compliance.status = not_assessable` with no gates. Gates were evaluated only in
the transition, handoff, capture and release previews/applies, each with
`compliance.status = pass` where cited.

## New artifacts (domain `lifecycle-pilot`)

INT-P3-001, CAP-P3-001, REQ-P3-001, SPEC-P3-001, VER-P3-001, WO-P3-001, REL-P3-001
(authored drafts, `work/drafts/`), RISK-P3-001 and DEC-P3-001 (raise-risk),
VREC-P3-001 and RLS-P3-001 (generated). Imported `-900` records were not revised
or decided. Draft validation reported no `incomplete` or `errors` for every final
revision; `content_review` is `not_assessed` by the evaluator. My separate content
review applied the released type checklists (intent, capability, requirement,
specification, verification, work_order, release_contract). Content readiness:
complete for the supplied outcome. The intent's success measure is my framing of
the task-supplied outcome; baseline recorded as `not measured`.

## Case results

| Case | Outcome | Evidence | Limit |
| --- | --- | --- | --- |
| Draft-open with new WO ID | refused `HAG_REMOTE_UNKNOWN_IDENTITY` (WO must exist in baseline); reopened against WO-P3-900 | `work/03-draft-open`, `work/04-draft-open` | Context anchor is the imported WO; WO-P3-900 itself unchanged |
| REL gates VER (template slot) | refused `HAG_REMOTE_INVALID_DRAFT`, E011 (`gates` accepts only work orders); corrected | `work/18-revise-rel-partial`, `work/19-revise-rel-partial` | Template shows `VER-xxx` in `gates` |
| Stale preview after draft change | preview `e097d608…` at 16/14; VER-P3-001 revised (→17/15); apply of that preview refused `HAG_REMOTE_STALE_PROJECT` (409), no artifacts/files; re-preview showed all five still `draft` | `work/22-…`, `work/23-…`, `work/24-…`, `work/25-…` (`/evaluator_output/commands/1/result/state`) | Refused at version guard before digest comparison |
| Definitions approval | accepted after recovery (see next row); receipt `sha256:23d6921a…` | `work/27-lookup-approve-defs` | — |
| Uncertain reply | apply `native401-approve-defs-apply-001` returned transport `unknown` (exit 2) | `work/26-approve-defs-apply` | Reply dropped by the test endpoint |
| Receipt lookup | `remote operation --key` → `accepted`, receipt `sha256:23d6921aa322e4674fa57f4665e082de53aaaec8e07192b77f8a88d3a50aebe8`, project 17→18 | `work/27-lookup-approve-defs` | — |
| Identical retry | same file `work/requests/26-approve-defs-apply.json`, same key → `accepted`, same receipt and revision IDs | `work/28-approve-defs-identical-retry` | — |
| No duplicate effect | status `project_version` 18 after retry | `work/30-status-after-retry` | — |
| Changed request, accepted key | one reason changed (`work/requests/29-…`) → refused `HAG_REMOTE_KEY_REUSE` (409) | `work/29-approve-defs-changed-same-key` | — |
| WO approval | accepted, gates QG-G3-WORK-AUTHORIZATION + assurance `required` pass; receipt `sha256:1058d2ec…` | `work/31-…`, `work/32-approve-wo-apply` | — |
| Start | preflight start `ready: true`; `in_progress` by `test-executor`; receipt `sha256:730db047…` | `work/33-…`, `work/35-start-apply` | — |
| Risk + decision | RISK-P3-001 raised with DEC-P3-001 (blocks WO-P3-001); `mitigate`, `mitigated_by` WO-P3-001, decided by `test-owner`; RISK → `mitigating`; receipts `sha256:cf914403…`, `sha256:64859f9a…` | `work/37-…`, `work/41-decide-apply` | Risk acceptance not supplied and not used |
| Out-of-scope handoff (1) | refused `HAG_REMOTE_PROTECTED_FIELD` (service file boundary: a `.md` under `docs/engineering/` treated as formal) | `work/44-handoff-out-of-scope-preview` | Not the scope gate |
| Out-of-scope handoff (2) | refused `HAG_REMOTE_EVALUATOR_REFUSED`: `QGP-G4I-PATHS: WEX201: changed path is outside execution scope: notes/out-of-scope-note.txt`; `mutation.writes: []`; WO still `in_progress`; no versions | `work/45-handoff-out-of-scope-preview` | — |
| Valid handoff | from_git `d3b597c0079f62a6bf1939b19f8e579d8bd031c7` (input head of first accepted lifecycle mutation); Git-derived change set all in scope; accepted, receipt `sha256:3e156a31…` | `work/46-…`, `work/47-handoff-apply` | — |
| Completion | `implemented` by `test-executor`; receipt `sha256:37bff485…` | `work/49-complete-apply` | — |
| VREC | captured by `quality-owner` at P; `verified` by `quality-owner`; receipts `sha256:3f3edb02…`, `sha256:8df1dbc7…` | `work/51-…`, `work/53-verify-apply`, `work/57-read-vrec` | Evidence is a native-host run on fixture bytes; P contains the same `src/greeting.py` digest |
| REL | completed with `candidate_commit` = VREC commit, approved by `test-owner`; receipt `sha256:d72ac3ad…` | `work/54-revise-rel`, `work/56-approve-rel-apply` | `previous_release_tag` omitted (no previous release) |
| RLS | prepared by `release-owner` (version 0.0.1, recorded tag value `v0.0.1`, no Git tag created); `released` by `release-owner`; receipts `sha256:b100c78f…`, `sha256:0b883e5a…` | `work/59-…`, `work/61-release-apply` | `tag` is required by the v2 schema; value chosen by me |
| MCP reads (7 tools) | all `complete: true`, `continuation: null`, no unresolved references, `se-harness-graph-read/v2`, `test_copy: true` | `work/mcp-reads.json` | Responses were inline; file holds exact requests and transcribed key fields, not byte copies |
| Export earlier | baseline `…b961d011…` (after WO approval) → `work/export-earlier-b961d011`, 19 files, snapshot `sha256:5c26246e…`, head `fb31fbd8…` | `work/64-export-earlier` | First attempt not sent (missing parent dir), `work/62-export-earlier` |
| Export later | baseline `…16788cdf…` → `work/export-later-16788cdf`, 28 files, snapshot `sha256:7997b9e4…`, head `9cadaf91…`, test candidate `49b0be40…` | `work/65-export-later`, manifest `/snapshot` | Independent replay not performed |

## Failures, gaps and interventions

- Captured native failures: 8 (observation snapshot `work/66-observations`, through
  that call): the six refusals above, the uncertain reply, and the unsent export.
  No host permission denial occurred. Later calls (report writes) are not counted.
- The service `check` action has no `--planned-path` option, so the released
  planned-path coverage view was not available before approval. I relied on the
  Git-derived handoff change set, which was fully in scope.
- The assertion record contains absolute host paths; it was retained unchanged.
- Uncertainty: whether the release `tag` value should have been supplied; it
  records a value only.

## File-read trace

Instruction discovery started at `inputs/plugin/verity-plane/skills/setup/SKILL.md`
(task.md instruction), then `setup/references/hosted-context.md` (hosted route),
`inputs/native-tools.md`, and per action: `change/references/hosted-drafts.md`,
`change/references/hosted-test-lifecycle.md`, `harness-orient/references/hosted-reads.md`,
`evidence/references/hosted-evidence.md`, `inputs/native-execution-tools.md`.
Released sections were read through the `instructions` reader with path and
SHA-256 in each result. References read: `lifecycle-v2.md`, `lifecycle-v2.json`,
`harnessctl-reference.md`, `server/README.md`, `export-v2.json`,
`docs/notes/hosted-artifact-graph.md` (before Cypher), schema view
`schemas/remote-v1/draft-open.json`. The exact read list with hashes is in
`work/66-observations` (`/file_reads`, `/observed_content_reads`).
