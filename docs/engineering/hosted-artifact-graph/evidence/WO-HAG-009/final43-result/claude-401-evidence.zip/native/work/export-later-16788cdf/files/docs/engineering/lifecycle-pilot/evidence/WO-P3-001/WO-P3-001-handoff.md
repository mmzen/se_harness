```toml
artifact = "WO-P3-001"
checkpoint = "handoff"
formal_snapshot_sha256 = "f5de5d5b67f43233ee40f4b5fe92f59dc12fe96c622889f9570d4ece5c211eba"
rebound_at = "2026-10-12T05:57:21Z"
```

# WO-P3-001 handoff evidence

Retained by `harnessctl evidence`; body content is owner-authored.
