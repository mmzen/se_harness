+++
id = "SPEC-P3-001"
type = "specification"
title = "Exact rehearsal greeting return value"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
# What an implementation must do to conform. The Explorer shows this summary under the title.
contract = "The fixture function greeting() returns the exact text Hello rehearsal, with no other effect."

[relations]
specifies = ["REQ-P3-001"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T05:50:27Z"
decided_by = "test-owner"
reason = "Synthetic test-owner input: accept complete test definitions."
+++

# Specification: Exact rehearsal greeting return value

Synthetic rehearsal input. This is not a real human decision.

## In plain words

The function `greeting()` in `src/greeting.py` takes no arguments and returns
the text `Hello rehearsal`.

## Scope

This specification governs the return value of `greeting()` in
`src/greeting.py`. The check method and evidence belong to the verification
contract.

## Terms

- **Fixture.** The existing local test source file `src/greeting.py`.

## Rules

**GRT-EXACT-001.** The implementation MUST return exactly `Hello rehearsal`
when `greeting()` is called with no arguments.

**GRT-EXACT-002.** The implementation MUST NOT add leading or trailing
characters, change letter case or produce external effects.

## Failure behaviour

| Trigger | Response | Diagnostic |
| --- | --- | --- |
| `greeting()` returns any value other than `Hello rehearsal` | The exact equality check fails and the work is not verified | none |

## Examples

**Given** the fixture `src/greeting.py`, **when** the test operator calls
`greeting()`, **then** the value equals `Hello rehearsal` (GRT-EXACT-001,
GRT-EXACT-002).

## Coverage

| Requirement | Rules |
| --- | --- |
| `REQ-P3-001` | GRT-EXACT-001, GRT-EXACT-002 |

## Not decided here

- The internal form of the implementation, provided the rules hold.
