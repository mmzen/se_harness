The requested disposable hosted test reached work completion, verified evidence, and a released test record for version 0.0.1. The local assertion proved that the inspected `greeting()` returns exactly `Hello rehearsal`. Independent reconstruction and replay of the exported Git history remains unperformed.

WO-P3-901 is `implemented` under test-executor; VREC-P3-901 is `verified` under quality-owner; RLS-P3-901 is `released` under release-owner. INT-P3-901, CAP-P3-901, REQ-P3-901, SPEC-P3-901, VER-P3-901 and REL-P3-901 are approved under the supplied test-owner input. DEC-P3-901 is decided with option `mitigate`; RISK-P3-901 remains `mitigating`, linked to WO-P3-901. These are synthetic test decisions with no real engineering or external authority.

The exact requests, command captures, original stdout/stderr, decoded documents and manifests remain in this work directory. [Structured observations](native-observations.json) contain operation keys, receipts, views, evaluator identities, case results and limits. [Retained lifecycle results](lifecycle-evidence.json) are parsed copies of inspected results; the original captures remain separately available through the [observation index](66-observation-index.json).

| Identity | Observed value |
| --- | --- |
| Project / endpoint | `0af0a081-bed7-461a-b3f0-a90b97188bf9` / `http://127.0.0.1:55306` |
| Context / final versions | `1193dc18-d656-44ee-ab98-a99a505f1df8`; project 29, context 27 |
| Hosted input baseline B | `se-harness-artifact-baseline/v1:sha256:23ee4ad664be49ea5ec672059b184fc541bc19634924fc4171e31bc8490e92be` |
| Source fixture commit S | `5820415917e87b64d80bad2f7c39c6d18d692829` |
| Test candidate P bound by VREC and RLS | `b1854c25399b4357ef67dc979370da8f3a9b99e1` |
| Actual implementation candidate C | `f0d042d69e025bdab284695e7e17667eeb38eaf3`, from selection.json /qualification_candidate |
| Client | 0.22.2; wheel SHA-256 `667ba88fcc928e76c0a43fd683deae76a9a9296f468ed07f6db7c5da1711dee7` |
| Released evaluator | 0.22.1; archive `cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053`; payload `0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff` |

The selected installed-client identity and service status matched the supplied combination. No installation or activation of a different real checkout occurred. Candidate source did not replace the released evaluator. The test records verify P; they do not verify C.

| Assessed case | Actual outcome and evidence | Limit |
| --- | --- | --- |
| Draft authoring and validation | Authored new definitions and bounded work; draft admission reported no incompleteness after content revisions. Reviewed content and links before approval. Original typed captures are indexed in 66-observation-index.json. | Template admission alone is not content review. Historical SPEC-P3-900 retains W-AUT-022. |
| Definition approval | `native-definitions-apply` and `native-rel-approve` accepted with passing transition gates; lifecycle-evidence.json /results/definitionsResult and /relApproved. | Definitions remain approved; no completion state was invented. |
| Work approval | `native-wo-approve-apply` accepted after passing gates; /results/woApproved. | Approval is separate from start. |
| Work start | `native-start-apply` accepted, WO became in_progress; /results/started. | Only the approved test scope was executed. |
| Exact greeting assertion | [assertion.json](assertion.json): exit 0, stdout `exact greeting passed\n`, empty stderr. | Local equality assertion only; no service endpoint ran source tests. |
| Risk disposition | `native-mitigate-apply` accepted for DEC-P3-901 with test-owner and mitigation by WO-P3-901; indexed original result and final exported records. | Mitigation is neither acceptance nor risk closure. |
| Stale version | [18-stale.json.stdout.txt](18-stale.json.stdout.txt): HAG_REMOTE_STALE_PROJECT, HTTP 409. | No receipt, affected artifacts or files; versions are null, not proof of equal numeric versions. |
| Stale preview after draft change | [19-stale-digest.json.stdout.txt](19-stale-digest.json.stdout.txt): HAG_REMOTE_STALE_PREVIEW, HTTP 409, after the WO scope revision. | No receipt, artifacts or files. A fresh preview was required. |
| Uncertain accepted reply | [21-risk-apply.json](21-risk-apply.json): transport outcome unknown, exit 2 for native-risk-apply. | That reply alone could not prove acceptance. |
| Receipt recovery | [22-risk-recovery.json](22-risk-recovery.json): lookup found accepted result. | A lookup is separate from a retry. |
| Identical retry | [23-risk-identical-retry.json](23-risk-identical-retry.json): argv resubmitted the same [request file](21-risk-apply-request.json); complete parsed result equals the lookup. | Original versions and output head were retained; no duplicate increment. |
| Changed request under accepted key | [24-changed-key-request.json](24-changed-key-request.json) changed the title only; [result](24-changed-key.json.stdout.txt) refused with HAG_REMOTE_KEY_REUSE, HTTP 409. | No accepted receipt or effects for the changed request. |
| Out-of-scope handoff | [41-outside.json.stdout.txt](41-outside.json.stdout.txt): HAG_REMOTE_EVALUATOR_REFUSED, HTTP 422; QGP-G4I-PATHS failed with WEX201 for `docs/engineering/lifecycle-pilot/evidence/outside/assertion.json`. | WO remained in_progress, mutation.writes, files and affected_artifacts were empty; outside file is absent from exports. |
| Valid handoff and completion | `native-handoff-apply` passed actual scope checks; `native-complete-apply` passed transition gates and made WO implemented; /results/handoff and /completed. | Evidence-generation context result is not_assessable; the separate scope checks passed. |
| Test verification | `native-capture-apply` prepared VREC ready; `native-verify-apply` passed transition gates and made it verified; /results/captured and /verified. | Preparation itself reported not_assessable, not a gate pass. |
| Release preparation | REL candidate and verified VREC candidate matched P; `native-release-prepare` created RLS ready; /results/releaseReady. | Preparation reported not_assessable. No Git tag was created. |
| Release decision | [63-release.json.stdout.txt](63-release.json.stdout.txt): ready -> released accepted with passing gates under release-owner. | WO and VREC were not transitioned automatically. |
| Earlier and later export | Both exports saved exact snapshots into separate new directories; manifests and bundles retained below. | Download/hash validation does not establish independent replay. |

The recovery receipt is `sha256:68baa5ec6416c5768846a9c077f8ebd1cade764e5fb5844d4fe763c80d2713b2`; request digest is `sha256:a1a619125179659a9187abb2aaff8e89e32ee22b3539036249cd90b0edffb2ab`. Lookup and identical resubmission both report project 15 -> 16, context 13 -> 14 and output head `7ae2f0704a866b27e0bb5e1de409e1260887ec6c`. The complete handoff comparison retained `30c43af6e984c5523996b8771965db5e39b9f8da`, the first accepted lifecycle mutation's input head, as recorded in [handoff-base.md](handoff-base.md). It was not replaced by the later start head.

All seven configured MCP read tools were exercised. Each saved file contains the exact request and full tool response. All responses reported complete=true, continuation=null and no unresolved references for their selected views.

| Tool / retained file | Selected view and observed content |
| --- | --- |
| [check](mcp-check.json) | DEC-P3-901 at context 14: open decision context; not_assessable, gates empty. |
| [work-context](mcp-work-context.json) | WO-P3-901 at context 15: five governing definitions, 11 scope paths, relevant DEC; context only, not_assessable. |
| [revision](mcp-revision.json) | Final baseline, exact released RLS revision and raw document. |
| [impact](mcp-impact.json) | Final baseline, REQ-P3-901 reverse reachability: eight related artifacts. |
| [lineage](mcp-lineage.json) | Final baseline, RLS links to REL, VREC, WO and VER. Recorded links do not add assurance. |
| [compare](mcp-compare.json) | Earlier to final baseline: REL-P3-901, VREC-P3-901 and RLS-P3-901 added; six relations added, none removed. |
| [cypher](mcp-cypher.json) | Final baseline, public Revision query returned RLS-P3-901 / released. Public representation was read before the query. |

The unchanged fixture has SHA-256 `dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1`. The local and exported assertion file has SHA-256 `2666d4bcdb4b7f650620e6d5cb516366ded8326730d8729cb20108e8bd14b7d0`. The final manifest retains these same hashes in the candidate provenance and final snapshot.

| Export | Immutable snapshot and evidence |
| --- | --- |
| [Earlier manifest](export-earlier/manifest.json) | 23 files; baseline `se-harness-artifact-baseline/v1:sha256:e45e3ffd81f1158f2c0420bb302ffc5037d551862b3ac3b77d86e9951fd4a013`; snapshot `sha256:64ef8b5b66b965e269f4253fe7e76e74494ed8f149fb656e8c26e5a7beb50440`; head P; [history.bundle](export-earlier/history.bundle) SHA-256 `a984e17fe0166a206954b81720158c937044480f0dc3f9def407a9ef5cf98efb`. |
| [Later manifest](export-later/manifest.json) | 28 files; baseline `se-harness-artifact-baseline/v1:sha256:84b76462bee64a0d06b2d3deddf869d31c3757bd94d17f31b9eb0692d26ec020`; snapshot `sha256:4189a9e8f1dd87c2d81f745c6b4b4c607883b4800d07cdd256d15d660a8717c9`; head `6bcc2a0ef45d0466c115fa02e27ae78e0facabe9`; [history.bundle](export-later/history.bundle) SHA-256 `4833db70ba6cf6a9b00f3e79d9e472eb109233953445ffeb7f7476543f50e666`. |

Intermediate exports in export-ready and export-release-ready allowed inspection of generated evaluator sidecars before the respective decisions. The VREC sidecar is an origin-version inspection with null archive/payload digests; the lifecycle envelope provides the full pinned evaluator identity. The RLS sidecar is a full-payload inspection with matching archive and payload hashes. The final VREC/RLS candidate remains P even though later governance commits retain their records and the release contract.

The [file-read trace](file-read-trace.json) preserves 85 captured successful content-read rows, exact paths/hashes, selected sections or offsets, and read triggers. The capture does not cover every JSON-pointer read or decoded typed-response document; their original captures retain the returned metadata. The first 4096 characters of harnessctl-reference.md were read, not the complete file. Explicit task delivery and explicit plugin reads do not establish automatic startup instruction delivery. After compaction, task.md was recovered with the prescribed bounded reader.

The final observation snapshot reports 229 observed tool items, eight native failure markers and five nonzero command captures. These are different measures; native_call_count_complete is false, and elapsed wall time/native-call totals are unavailable. Four recorded command failures are intentional service refusals above; the fifth is the recovered uncertain transport. Additional helper errors were an excessive initial read chunk and unsupported wildcard discovery. A later attempt to read the whole /command_records field returned non-JSON text beginning Traceback; JSON.parse failed with Unexpected token 'T'. The full underlying traceback was not surfaced, so its cause is unassessed. Selected bounded reads and the original evidence supported reporting. No host permission denial was observed. No permissions, credentials, ownership, software installation or real repository state were changed.

The helper's closed action schema does not expose planned-path check arguments. Planned scope was reviewed against the authored paths; actual complete scope and handoff checks passed. No new human intervention or agent delegation was used. The known imported advisory W-AUT-022 was retained without modifying the imported -900 records.

The final evaluator selects exactly `PROC-EXTERNAL-ACTION / STEP-EXTERNAL-ACTION`: reuse matching authority for an exact external action or obtain the missing grant from its accountable owner. This qualification authorizes no external action. The transition created no tag, publication or deployment, and `rehearsal-0.0.1` is record metadata only. The remaining independent reviewer task is to reconstruct the exported histories and check original candidate bindings with released 0.22.1.

