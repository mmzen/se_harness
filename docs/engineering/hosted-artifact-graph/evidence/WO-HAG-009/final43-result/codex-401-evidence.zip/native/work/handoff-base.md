Retained complete-work comparison base: `30c43af6e984c5523996b8771965db5e39b9f8da`.

Source: first accepted lifecycle operation `native-risk-apply`, recovered in `22-risk-recovery.json.stdout.txt`; receipt `sha256:68baa5ec6416c5768846a9c077f8ebd1cade764e5fb5844d4fe763c80d2713b2`.

The original reply was uncertain. This base is its actual `provenance.input_git_head`, not an unapplied preview or source fixture commit. It includes the authored draft files before all later approval and execution changes.
