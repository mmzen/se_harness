+++
id = "REQ-P3-901"
type = "requirement"
title = "Return the exact greeting for the operator test"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
statement = "Calling the selected fixture greeting() returns exactly Hello rehearsal."
verification_method = ["test"]
priority = "must"
source = "Native hosted-workflow qualification task"

[relations]
derives_from = ["CAP-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T05:50:54Z"
decided_by = "test-owner"
reason = "Supplied synthetic definition acceptance after complete content review and passing gates for the exact greeting test."
+++

# Return the exact greeting for the operator test

## Why

The operator needs a concrete behavior whose proof can be inspected in the exported engineering record.

## Acceptance

For a no-argument call to the selected fixture function, the returned value equals `Hello rehearsal` exactly. An unequal result or raised exception fails acceptance. This test adds no input variants or production operating guarantees.
