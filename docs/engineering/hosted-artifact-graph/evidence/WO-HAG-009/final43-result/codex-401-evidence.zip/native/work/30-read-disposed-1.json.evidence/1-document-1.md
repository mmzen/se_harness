+++
id = "RISK-P3-901"
type = "risk"
title = "Evidence could be bound to the wrong greeting source"
status = "mitigating"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
description = "An assertion result from a different fixture or later candidate could mislead the operator reviewing this test."
action = "Retain exact fixture digest and assertion bytes, then bind them to the service verification candidate through WO-P3-901."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-901"]
mitigated_by = ["WO-P3-901"]

[disposition]
option = "mitigate"
label = "Mitigate the threat through a work order; the risk closes under verified coverage."
decided_by = "test-owner"
decided_at = "2026-10-12T05:49:51Z"
reason = "The supplied test choice is mitigation through WO-P3-901, retaining exact fixture and assertion identities and commit-bound evidence."


[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-12T05:48:34Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."

[[lifecycle_events]]
from = "raised"
to = "mitigating"
decided_at = "2026-10-12T05:49:51Z"
decided_by = "test-owner"
reason = "The supplied test choice is mitigation through WO-P3-901, retaining exact fixture and assertion identities and commit-bound evidence."
+++

# Risk: Evidence could be bound to the wrong greeting source

## Description

An assertion result from a different fixture or later candidate could mislead the operator reviewing this test.

## Next action

Retain exact fixture digest and assertion bytes, then bind them to the service verification candidate through WO-P3-901.
