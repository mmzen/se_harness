+++
id = "REL-P3-901"
type = "release_contract"
title = "Exact greeting test record for version 0.0.1"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
candidate_commit = "b1854c25399b4357ef67dc979370da8f3a9b99e1"
[relations]
gates = ["WO-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T06:00:24Z"
decided_by = "test-owner"
reason = "Task supplies synthetic approval of complete test definitions. Reviewed exact verified candidate, sole WO coverage, version 0.0.1, retained evidence, rollback and record-only limits."
+++

# Release unit
Version 0.0.1 covers the disposable test record for WO-P3-901: inspect the existing greeting function and demonstrate that its return value equals exactly `Hello rehearsal`. The selected tag metadata is `rehearsal-0.0.1`; this record does not create a Git tag.

# Required evidence
VREC-P3-901 must be verified for the exact candidate above and cover exactly WO-P3-901. Retain VER-P3-901, the successful local assertion, unchanged fixture bytes, complete handoff, evaluator evidence, and the exported history bundle and manifest. Independent reviewer replay remains a separate later check.

# Compatibility and migration
No source or runtime behavior changes are included. No migration is required. The assertion demonstrates this fixture outcome only.

# Security and provenance
Use released evaluator 0.22.1 and retain its identity and receipts. Source tests run locally, not at the service endpoint. All actors and decisions are synthetic. This record confers no real engineering or external authority.

# Promotion policy
Prepare RLS-P3-901 with release-owner, version 0.0.1 and tag metadata rehearsal-0.0.1 after approved contract and verified coverage checks pass. Apply the supplied synthetic release decision only if the transition gates pass and the candidate and work set still match.

# Human approval triggers
The task supplies test-owner approval of complete definitions and release-owner authorization of the test release record after its gates pass. Any expanded scope, candidate change or real delivery action needs separate authority. This contract covers record-only assessment.

# Rollback criteria and procedure
If evidence hashes differ, the candidate binding changes or independent replay fails, stop relying on this test release record, preserve the original evidence, and report the discrepancy for a new bounded assessment.

# Post-release observation window
Inspect the final record and immutable export during this qualification. Record the independent replay result separately when the reviewer performs it; do not infer it from download success.

