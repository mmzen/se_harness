+++
id = "VER-P3-901"
type = "verification"
title = "Retain the exact local greeting assertion"
status = "approved"
owners = ["quality-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[relations]
verifies = ["REQ-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T05:50:54Z"
decided_by = "test-owner"
reason = "Supplied synthetic definition acceptance after complete content review and passing gates for the exact greeting test."
+++

# Retain the exact local greeting assertion

## Independence

The expected value `Hello rehearsal` comes from REQ-P3-901 and SPEC-P3-901 and the test owner input, never from candidate output. The synthetic quality-owner assesses evidence separately from test-executor execution.

## Requirement-to-evidence matrix

| Requirement | Method | Case/evidence | Pass condition |
| --- | --- | --- | --- |
| REQ-P3-901 | test | assert-greeting; docs/engineering/lifecycle-pilot/evidence/WO-P3-901/assertion.json | Exit 0 and exact stdout `exact greeting passed` from the no-argument equality assertion on the selected native Windows host. |

## Planned execution

After work starts, invoke the approved native_call.py helper with `assert-greeting --record` and the absolute new work/assertion.json destination under the selected native directory. It uses the selected client_python locally. The service never runs the source test. Retain command, working directory, exit, stdout, stderr and elapsed time. The helper supplies no runtime-version or separate type assertion.

Before execution, require source SHA-256 dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1 for src/greeting.py, from fixture commit 5820415917e87b64d80bad2f7c39c6d18d692829. A mismatch stops execution. A nonzero exit, exception or unequal result fails the check.

## Evidence retention and assessment

Upload exact retained assertion bytes at the matrix path through the authorized handoff. Released evaluator 0.22.1 captures the completed work and evidence into a commit-bound VREC prepared by quality-owner. Its candidate commit must be the actual service candidate, distinct from the fixture provenance commit. Retain both identities and two immutable exports. This proves the selected equality assertion only; production runtime behavior and real release authority are outside this test.
