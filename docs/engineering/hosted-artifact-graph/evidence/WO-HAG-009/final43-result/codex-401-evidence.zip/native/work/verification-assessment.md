REQ-P3-901 passes its sole equality criterion on the selected native Windows host: assertion.json records exit 0, stdout `exact greeting passed\n`, and empty stderr. The expected value was fixed by the user and approved definitions before execution.

The source inspected locally and in export-earlier/files/src/greeting.py has SHA-256 dcbd486a7e9993f4aac9824f5099957b1909e5f1fce3f0ccb81adf4b13cecab1. The local and exported assertion record both have SHA-256 2666d4bcdb4b7f650620e6d5cb516366ded8326730d8729cb20108e8bd14b7d0. This establishes the tested bytes carried into the current service snapshot. Capture will bind its actual candidate separately.

Review found no source change needed: the existing fixed return satisfies the contract. Definition, risk and decision writes serve this test record. The Git-derived handoff passed for all 11 changed paths from retained base 30c43af6e984c5523996b8771965db5e39b9f8da. The deliberately refused outside path is absent from the earlier export manifest. The release contract and records are subsequent governance work and remain deferred until the verified candidate exists.

No separate type assertion, Python version observation, server-side source test, independent Git replay, production assurance or real release is claimed.
