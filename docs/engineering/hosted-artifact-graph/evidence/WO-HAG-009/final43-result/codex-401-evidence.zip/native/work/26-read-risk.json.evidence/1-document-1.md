+++
id = "RISK-P3-901"
type = "risk"
title = "Evidence could be bound to the wrong greeting source"
status = "raised"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
description = "An assertion result from a different fixture or later candidate could mislead the operator reviewing this test."
action = "Retain exact fixture digest and assertion bytes, then bind them to the service verification candidate through WO-P3-901."
raised_by = "test-executor"

[relations]
threatens = ["WO-P3-901"]

[[lifecycle_events]]
from = "identified"
to = "raised"
decided_at = "2026-10-12T05:48:34Z"
decided_by = "test-executor"
reason = "Recorded by harnessctl raise-risk."
+++

# Risk: Evidence could be bound to the wrong greeting source

## Description

An assertion result from a different fixture or later candidate could mislead the operator reviewing this test.

## Next action

Retain exact fixture digest and assertion bytes, then bind them to the service verification candidate through WO-P3-901.
