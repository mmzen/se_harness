+++
id = "WO-P3-901"
type = "work_order"
title = "Prove and export the native greeting test"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"

[assurance]
commit_bound_verification = "required"
rationale = "The test verification and release decisions depend on these definitions, traceability and retained assertion evidence at one exact candidate."
decided_by = "test-owner"

[execution_scope]
paths = [
  "src/greeting.py",
  "docs/engineering/lifecycle-pilot/intent/INT-P3-901.md",
  "docs/engineering/lifecycle-pilot/capabilities/CAP-P3-901.md",
  "docs/engineering/lifecycle-pilot/requirements/REQ-P3-901.md",
  "docs/engineering/lifecycle-pilot/specifications/SPEC-P3-901.md",
  "docs/engineering/lifecycle-pilot/verification/VER-P3-901.md",
  "docs/engineering/lifecycle-pilot/work-orders/WO-P3-901.md",
  "docs/engineering/lifecycle-pilot/risks/RISK-P3-901.md",
  "docs/engineering/lifecycle-pilot/decisions/DEC-P3-901.md",
  "docs/engineering/lifecycle-pilot/release/REL-P3-901.md",
  "docs/engineering/lifecycle-pilot/evidence/WO-P3-901/"
]

[relations]
implements = ["REQ-P3-901"]
specifications = ["SPEC-P3-901"]
verification = ["VER-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T05:51:21Z"
decided_by = "test-owner"
reason = "Supplied approval of bounded test work with required commit-bound verification after scope and definition gates pass."
scope_paths = ["src/greeting.py", "docs/engineering/lifecycle-pilot/intent/INT-P3-901.md", "docs/engineering/lifecycle-pilot/capabilities/CAP-P3-901.md", "docs/engineering/lifecycle-pilot/requirements/REQ-P3-901.md", "docs/engineering/lifecycle-pilot/specifications/SPEC-P3-901.md", "docs/engineering/lifecycle-pilot/verification/VER-P3-901.md", "docs/engineering/lifecycle-pilot/work-orders/WO-P3-901.md", "docs/engineering/lifecycle-pilot/risks/RISK-P3-901.md", "docs/engineering/lifecycle-pilot/decisions/DEC-P3-901.md", "docs/engineering/lifecycle-pilot/release/REL-P3-901.md", "docs/engineering/lifecycle-pilot/evidence/WO-P3-901/"]
+++

# Prove and export the native greeting test

## Objective

Give the operator the existing greeting source, its exact equality assertion result, and a complete exported test engineering record.

## In scope

Author and approve the selected new test definitions, inspect the immutable fixture, execute its supplied local assertion, record one risk and paired mitigation decision, retain handoff evidence, complete work, and prepare commit-bound verification and test release assessment for 0.0.1. Exercise stale-preview, out-of-scope handoff and retry boundaries. Export two immutable snapshots.

## Out of scope

Changes to imported -900 records, local fixture source modification, real repository operations, installation, tags, push, publication and deployment.

## Authorized decision envelope

test-executor may perform bounded execution and record completion after passing checks. test-owner supplies definition, scope and mitigation decisions. quality-owner supplies verification preparation and acceptance; release-owner supplies release preparation and decision. All identities and decisions are synthetic inputs for this private test only.

## Constraints

Use released evaluator 0.22.1 and the selected candidate client. Keep source bytes immutable. Keep exact request bytes, receipts and the first accepted lifecycle input Git head for the full handoff comparison. Stop a host permission denial without changing routes.

## Expected change surface

Inspected src/greeting.py is the existing two-line fixed return and needs no edit. Inspected native execution guidance supplies its caller and exact equality assertion; no other callers, CI, packaging or product documentation need changes for this fixture-only proof. The five new definition files and this work order contain the authored contract and approval history. RISK-P3-901 and DEC-P3-901 retain the evidence-mismatch threat and supplied mitigation decision; confirm their exact output paths in the risk preview before approval. REL-P3-901 is deferred until the verified candidate is known. The evidence/WO-P3-901/ directory retains exact assertion bytes and generated handoff outputs for this work only. Future VREC and RLS destinations remain unallocated; direct verification/release relationship scope rules cover their actual prepared records and declared evaluator evidence, subject to inspecting returned paths.

The risk preview confirmed both exact risk and decision paths listed in execution_scope. Both records belong to this bounded work.

## Required verification and evidence to record

Execute VER-P3-901 using assert-greeting after start authorization. Retain work/assertion.json locally and identical bytes at docs/engineering/lifecycle-pilot/evidence/WO-P3-901/assertion.json. Retain passed handoff and evaluator results and bind them to the actual service candidate. No server endpoint executes source tests.

## Stop and escalate conditions

Stop dependent work on source digest mismatch, failed required gate, scope drift, unreadable required instructions, protocol failure or host permission denial. Reconcile an uncertain accepted operation with its original key before another write. No risk acceptance is authorized.

## Completion report format

Report completed behavior, exact assertion result, evaluator findings, candidate and evidence paths, observed boundary refusals and unchanged effects, limitations, and the next evaluator-selected accountable action. Retain native-report.md and native-observations.json under the selected work directory.
