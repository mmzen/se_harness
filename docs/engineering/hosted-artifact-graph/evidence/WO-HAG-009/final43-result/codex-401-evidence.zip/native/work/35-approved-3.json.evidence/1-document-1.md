+++
id = "SPEC-P3-901"
type = "specification"
title = "Exact no-argument greeting"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
contract = "The selected greeting() function returns exactly Hello rehearsal when called without arguments."

[relations]
specifies = ["REQ-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T05:50:54Z"
decided_by = "test-owner"
reason = "Supplied synthetic definition acceptance after complete content review and passing gates for the exact greeting test."
+++

# Exact no-argument greeting

## Scope and behavior

The selected existing `src/greeting.py` exposes `greeting()` with no arguments. Its result must equal `Hello rehearsal`, including case and spacing. Calling `greeting()` therefore supplies a direct checkable example for REQ-P3-901.

An exception or unequal value fails the test; no fallback value qualifies. Invalid argument calls are outside the agreed behavior. The existing fixed return is sufficient for this single outcome; no new mechanism, architecture or runtime dependency is needed.
