+++
id = "CAP-P3-901"
type = "capability"
title = "Inspect the fixture and its proof"
status = "approved"
owners = ["test-owner"]
created = "2026-10-12"
updated = "2026-10-12"
ability = "The test operator can inspect the fixed greeting and its retained equality assertion in the selected private test copy."

[relations]
derives_from = ["INT-P3-901"]

[[lifecycle_events]]
from = "draft"
to = "approved"
decided_at = "2026-10-12T05:50:54Z"
decided_by = "test-owner"
reason = "Supplied synthetic definition acceptance after complete content review and passing gates for the exact greeting test."
+++

# Inspect the fixture and its proof

The operator needs access to the existing source and an exact local assertion result linked to a complete test record. This ability applies only to this disposable native qualification. Requirements define the observable greeting; specifications define its interface; verification defines the check. No general greeting service or runtime extension is needed.
