"""Verify same task and permissions before the new guidance diagnostic."""
import hashlib,json,subprocess,zipfile
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-scope37-20261011';r=O/'claude-331';old=W/'hag-procedure36-20261011/claude-321'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
norm=lambda s:s.replace('hag-scope37-20261011','hag-procedure36-20261011').replace('claude-331','claude-321')
assert norm((r/'native-task.md').read_text())==(old/'native-task.md').read_text()
assert json.loads(norm((r/'permissions.json').read_text()))==load(old/'permissions.json')
c=load(O/'candidate-37.json')['commit'];stage=load(r/'stage-evidence.json');assert stage['candidate']==c
assert load(O/'package-guidance-comparison.json')['candidate']==c
om={x['relative']:x['sha256'] for x in load(old/'native/inputs/inventory.json')['files']}
nm={x['relative']:x['sha256'] for x in load(r/'native/inputs/inventory.json')['files']}
assert set(om)==set(nm)
different=[n for n in om if om[n]!=nm[n]]
expected=['plugin/verity-plane/skills/change/references/hosted-drafts.md','plugin/verity-plane/skills/change/references/hosted-test-lifecycle.md','native-tools.md','native-execution-tools.md','configuration.json','combination.json','se_harness-0.22.2-py3-none-any.whl']
assert set(different)==set(expected),different
wheel='se_harness-0.22.2-py3-none-any.whl'
with zipfile.ZipFile(old/'native/inputs'/wheel) as a,zipfile.ZipFile(r/'native/inputs'/wheel) as b:
 assert sorted(a.namelist())==sorted(b.namelist())
 members={name:hashlib.sha256(b.read(name)).hexdigest() for name in b.namelist()}
 assert all(a.read(name)==b.read(name) for name in members)
wheel_proof={'archive_bytes_equal':False,'all_member_bytes_equal':True,'members':members,'preparation_observation':'Initial comparison expected six differences and stopped before native launch. Inspection found a seventh archive-byte difference; every wheel member is byte-identical. The repeated proof adds this exact container-only difference without changing runtime inputs.'}
rows=[]
for name in ('native-tools.md','native-execution-tools.md'):
 raw=subprocess.check_output(['git','show',c+':tests/hosted_artifact_graph/'+name],cwd=W/'hag221proposal')
 assert raw==(r/'native/inputs'/name).read_bytes();rows.append({'path':name,'sha256':hashlib.sha256(raw).hexdigest(),'exact_candidate_bytes':True})
probe=load(O/'claude331-live-probe.json');v=json.loads(probe['stdout']);assert not v['is_error'] and list(v['modelUsage'])==['claude-opus-5-5']
proof={'candidate':c,'previous_candidate':'c526fcbe7ac59de9fd45cb8ae461cfb558aaf2b7','previous_trial':'claude-321','trial':'claude-331','model':'claude-opus-5-5','cli':'2.1.280','same_task_except_paths':True,'same_permissions_except_paths':True,'same_timeout_seconds':1200,'identical_input_files':len(om)-len(different),'different_files':different,'exact_staged_tool_documents':rows,'live_probe_passed':True,'limits':'Only four guidance files and new project/component identity differ. Model comparison is historical; this tests a new guidance candidate on the same Opus5.5 environment. No formal criterion changes or full qualification claimed.'}
proof['client_wheel_comparison']=wheel_proof
target=r/'comparison-inputs.json';assert not target.exists();target.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k!='client_wheel_comparison'},indent=2));print('All client wheel members are byte-identical:',len(members))
