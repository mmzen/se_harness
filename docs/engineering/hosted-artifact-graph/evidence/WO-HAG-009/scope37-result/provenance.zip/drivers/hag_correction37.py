"""Bounded scope-planning and executable-verification guidance correction."""
from pathlib import Path
import sys
W=Path(__file__).parent
source=(W/'hag_correction36.py').read_text()
source=source.replace('hag-procedure36-20261011','hag-scope37-20261011').replace('WO-HAG-011/procedure36','WO-HAG-011/scope37')
paths=['plugins/verity-plane/common/skills/change/references/hosted-drafts.md','plugins/verity-plane/common/skills/change/references/hosted-test-lifecycle.md','tests/hosted_artifact_graph/native-tools.md','tests/hosted_artifact_graph/native-execution-tools.md']
start=source.index('changed=');end=source.index('\n',start)
source=source[:start]+'changed='+repr(paths)+source[end:]
source=source.replace('28b9e95175945a2cf1d084470c24ca1f3cb0f8c8','176ca91c6c95b4f79219c26cd633d7a081a9a8dc')
source=source.replace(",'canonical-section-comparison'",'')
source=source.replace('Include canonical entry conditions in focused instruction reads','Align hosted scope and verification planning with available execution')
source=source.replace('hag36','hag37')
for a,b in [('scope36','scope37'),('preflight36','preflight37'),('candidate-36','candidate-37'),('build36','build37'),('package36','package37'),('client36','client37'),('native-procedure36','native-scope37'),("-36'","-37'")]:source=source.replace(a,b)
if sys.argv[1]=='focused-host':
 sys.argv[1]='focused';source=source.replace("('resources',", "('resources-host',")
if sys.argv[1]=='commit':
 source=source.replace("names=['resources',", "names=['resources-host',")
 source=source.replace("for name in names:z.write", "for name in [*names,'resources']:z.write")
 source=source.replace("for n in names]}", "for n in [*names,'resources']]}")
exec(compile(source,'scope37-control','exec'),{'__file__':str(W/'hag_correction36.py'),'__name__':'__main__'})
