"""Exact guidance and unchanged service-package comparison."""
from pathlib import Path
W=Path(__file__).parent
source=(W/'hag_package36_review.py').read_text().replace('hag-procedure36-20261011','hag-scope37-20261011')
source=source.replace('hag-claude-correction30-20261011','hag-procedure36-20261011')
for a,b in [('candidate-36','candidate-37'),('package36','package37'),('package30','package36'),('build36','build37'),('native-procedure36','native-scope37')]:source=source.replace(a,b)
source=source.replace("'evidence/references/hosted-evidence.md'", "'change/references/hosted-drafts.md'")
source=source.replace('WO-HAG-009/functional30/provenance.zip','WO-HAG-009/procedure36-result/provenance.zip')
exec(compile(source,'scope37-package-check','exec'),{'__file__':str(W/'hag_package36_review.py'),'__name__':'__main__'})
