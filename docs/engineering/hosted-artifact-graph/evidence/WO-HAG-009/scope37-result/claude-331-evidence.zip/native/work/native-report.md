# Native hosted procedure and refusal diagnostic (claude-331)

**Outcome:** WO-P3-901 is `in_progress` with an accepted handoff. The
evaluator's next step is a completion transition. This diagnostic did not
take that step, because the task forbids completing the work.

This is a focused observation under WO-HAG-009/011 and VER-HAG-007. It does
not complete NQ-01 through NQ-05. It verifies no real work and authorizes no
release. All decisions are synthetic fixture inputs (`test-owner`,
`test-executor`). They are not human decisions. Git remains authoritative.

## Selection and identities

| Item | Value | Evidence |
| --- | --- | --- |
| Project | `856bbc1a-064b-4c10-832d-20407cd8c5d6` at `http://127.0.0.1:27331` | `selection.json` |
| Authority mode | `sandbox-projection`, `test_copy: true`, ready | `work/01-status.stdout.txt` |
| Released evaluator | 0.22.1, archive `cb35c3c4…3053`, payload `0e7b7c2b…7e7ff` | `01-status`, every receipt |
| Candidate client | 0.22.2, wheel `d7b92f0f…6e6f`; equals the combination report | `identity` call, `inputs/combination.json` |
| Qualification candidate | `50a215cdf44b68637d4c5aa8ab1fbfcbbe0d611f`; equals status `/components/source/candidate_commit` | `01-status` |
| Source fixture commit S | `5820415917e87b64d80bad2f7c39c6d18d692829` | import and lifecycle provenance |
| Import baseline | `se-harness-artifact-baseline/v1:sha256:9490b674…d48ad38a` | `work/02-import.stdout.txt` |
| Hosted input baseline B of the handoff | `se-harness-artifact-baseline/v1:sha256:55130d75…f68606` | `work/33-handoff-apply.stdout.txt` `/provenance/input_baseline` |
| Handoff `from_git` base | `cda5640105abbeec60965c9a3624cdbc4d77c9b8` = `input_git_head` of the first accepted lifecycle mutation | `work/24-defs-apply.stdout.txt` |
| Test Git candidate P | unknown; no VREC was prepared | n/a |
| Implementation candidate C | unknown; no source change and no VREC | n/a |

Checkpoint-free context and gate results are separate. `draft-open`
(`04-draft-open`) and `validate` (`18-validate`) report context only; the
draft-open check returned compliance `not_assessable` with no gates.
Gate results came from the transition and handoff previews, listed below.

## New artifacts (context `20766c22-09ca-4345-8265-1cd4346927a8`)

INT-P3-901, CAP-P3-901, REQ-P3-901, SPEC-P3-901, VER-P3-901 and WO-P3-901
are under `docs/engineering/lifecycle-pilot/`. The submitted bytes are in
`work/drafts/`. The imported `-900` records were read for reference only and
did not change.

- **Content readiness:** complete against the type checklists, by source
  inspection of my own drafts. The evaluator reported `incomplete: []` and no
  errors for every draft, but it only checks template shape (`content_review: not_assessed`).
- REQ-P3-901 acceptance: `greeting()` returns exactly `Hello rehearsal`.
  SPEC-P3-901 rule GREET-RET-001. VER-P3-901 case GREET-T1 = the
  `assert-greeting` tool; pass = exit 0 and `exact greeting passed`.
- WO-P3-901 scope: the six new artifact files, `evidence/WO-P3-901/` and
  `src/greeting.py` (inspected/executed only; modification excluded by its
  decision envelope). `commit_bound_verification = "required"`, decided by `test-owner`.

## Assessed cases

| Case | Outcome | Evidence | Remaining limit |
| --- | --- | --- | --- |
| Status and identity match | matched combination | `01-status.stdout.txt` | none |
| Import | accepted, project 0→1 | `02-import` | one baseline advisory W-AUT-022 on imported SPEC-P3-900 |
| draft-open on new WO ID | **refused** by service, `HAG_REMOTE_UNKNOWN_IDENTITY` (404): work order absent from baseline | `03-draft-open` | recovered: reopened anchored on existing `WO-P3-900` (`04-draft-open`, accepted). WO-P3-900 itself unchanged |
| Create + revise six drafts | all accepted, no errors | `05`–`16` records | content review is mine, not the evaluator's |
| Cypher read (MCP) | complete, 3 rows: WO-P3-901 `implements` REQ-P3-901, `specifications` SPEC-P3-901, `verification` VER-P3-901 | `17-cypher-mcp.json` | transcribed by me from the MCP result; not a helper capture |
| Definitions approval preview 1 | previewed, gates pass, digest `sha256:e80db09a…2c58` | `19-defs-preview` | — |
| **Stale preview** | after VER-P3-901 was revised (`20-revise-ver`, rev `8ca9518c…`), apply with the old digest at the *current* versions (15/13) was **refused** by service, `HAG_REMOTE_STALE_PREVIEW` (409). Failed condition: the preview binding no longer matched the selected revisions; versions matched | `21-defs-apply-stale` | — |
| Unchanged effect after stale refusal | no receipt, no affected revisions; all 13 revisions still `draft`, project still 15 | `21-defs-apply-stale`, `22-cypher-after-stale.json` | Cypher evidence transcribed by me |
| Definitions approval | fresh preview `764f6bc5…`, gates pass, 5 file effects; applied, accepted, project 15→16 | `23-defs-preview`, `24-defs-apply` | synthetic decision |
| WO approval | gates pass (incl. QGS-ASSURANCE); accepted, project 16→17 | `25-`, `26-wo-approve-*` | synthetic decision |
| Start | preflight `ready: true`; preview pass; accepted as `test-executor`, project 17→18 | `27-`, `28-`, `29-start-*` | — |
| GREET-T1 assertion | exit 0, stdout `exact greeting passed`, 0.070922 s | `30-assert-greeting` | native Windows host via `client_python`; no Python version; equality only |
| **Out-of-scope handoff** | preview **refused** by released evaluator, `HAG_REMOTE_EVALUATOR_REFUSED`; blocker `QGP-G4I-PATHS: WEX201: changed path is outside execution scope: docs/engineering/lifecycle-pilot/evidence/greeting-assertion.json`; evaluator next: escalate under DR-REMEDIATION-SCOPE | `31-handoff-outscope-preview` | corrected the input path, did not widen scope |
| Unchanged effect after scope refusal | no receipt; the next preview was accepted at the same versions 18/16 | `32-handoff-preview` | — |
| Valid handoff | preview gates pass (9 changed paths in scope, evidence bound); applied, accepted, receipt `sha256:099d3bb5…4771`, project 18→19, context 16→17; files `evidence/WO-P3-901/{greeting-assertion.json, handoff.json, WO-P3-901-handoff.md}` | `32-`, `33-handoff-*` | — |

## Final state and next step

- WO-P3-901: `in_progress`. The five definitions are `approved`. Imported `-900`: `draft`.
- Evaluator next step (`33-handoff-apply`): `STEP-WO-IMPLEMENT-PREVIEW`,
  `harnessctl transition . --set WO-P3-901=implemented --decision WO-P3-901=delegated-executor`.
  I did not run it: the task forbids completing the work.
- Not done: completion, VREC, RLS, release contract, risks, export,
  publication, installation and real repository changes.

## Failures, denials and uncertainties

The observation snapshot (`34-observations`, 100 native calls at capture) lists
7 native tool errors. Two are the service refusals above (stale, out-of-scope),
and one is the draft-open refusal. Four are helper usage errors that I made
and recovered from: a guessed `client-help/draft-open.txt` path; two
`instructions` selectors outside the inventory (I then used native Read);
and one unquoted `read-json` pointer. No permission denial occurred.

- In the refused out-of-scope preview, `changed_paths` listed only the
  misplaced evidence file. The valid preview reported 9 changed paths. I did
  not establish why the two counts differ.
- Cypher evidence files `17-` and `22-` are my transcriptions of MCP results,
  not helper captures.
- Report writes after `34-observations` are not in that snapshot.

## Instruction-read trace

Task inputs: `task.md`, `selection.json`, `native-tools.md`,
`native-execution-tools.md`. Plugin: `setup/SKILL.md`,
`setup/references/hosted-context.md`, `change/references/hosted-drafts.md`,
`change/references/hosted-test-lifecycle.md`,
`harness-orient/references/hosted-reads.md`,
`evidence/references/hosted-evidence.md`. Released 0.22.1: DRAFT_DEFINITIONS.md
and DEFINE_CHANGE.md (full); ARTIFACT_AUTHORING.md (full); ARTIFACTS.md
#artifact-types/#artifact-locations; DEFINITION_LINKS.md#links-between-definitions;
DRAFT_WORK_ORDERS.md#procedure; WORK_AND_EVIDENCE.md #complete-work-scope,
#links-from-work-orders-wo, #assurance-classification, #generated-outputs;
AUTHORIZE_WORK.md #assess-the-proposed-artifact-package,
#apply-the-selected-transitions; AUTHORITY.md #decision-rights,
#authority-from-work-approval; EXECUTE_WORK.md #start-the-selected-work,
#retain-the-implementation-evidence; RESULTS.md#report-a-lifecycle-result.
Reference: `docs/notes/hosted-artifact-graph.md`, `server/contracts/lifecycle-v2.md`,
`lifecycle-v2.json`, `schemas/remote-v1/draft-open.json`. The captured trace
is in `34-observations` (`/observed_content_reads`, `file_reads`).
Not read: `AUTHORITY.md#delegation-and-separation` and
`RISKS_AND_DECISIONS.md#blocking-decisions`, named by AUTHORIZE_WORK
"Before this action". The second was not applicable (no open decision). The
first is a gap in my reading before approval.
