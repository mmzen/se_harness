+++
id = "WO-P3-901"
type = "work_order"
title = "<Bounded implementation objective>"
status = "draft"
owners = ["<engineering owner>"]
created = "2026-10-11"
updated = "2026-10-11"

[assurance]
commit_bound_verification = "<required or not_required>"
rationale = "<why future decisions do or do not require commit-bound assurance>"
decided_by = "<actual human who confirmed the assurance classification>"

[execution_scope]
paths = [
  "<exact/repository-relative/path>",
  "<repository-relative/component-prefix/>",
]

[relations]
implements = ["REQ-xxx"]
specifications = ["SPEC-xxx"]
verification = ["VER-xxx"]
+++

# Work Order: <title>

Before approval, apply the shared design principle and `work_order` checklist in
`docs/engineering/ARTIFACT_AUTHORING.md`.

## Lifecycle

Use `approved` to authorize bounded execution and `implemented` after the work and retained evidence are complete. Governance-only work normally stops at `implemented`. Use `verified` or `released` only when an eligible commit-bound VREC explicitly covers this work order under the repository's configured provenance policy.

Before approval, classify commit-bound verification explicitly. Use `required` when future engineering, assurance, operational, or release decisions will rely on the correctness of changed executable behavior, managed policy, CI, definitions, traceability, or other trusted engineering state. Use `not_required` only when the work solely records or transports an already authorized verification, release, supersession, publication, or deployment decision. Split mixed scope or use `required`; uncertainty requires escalation rather than an inferred default.

Before approval, replace every `[execution_scope].paths` placeholder. An entry
ending in `/` admits that directory and its descendants. Every other entry
admits one exact repository-relative path. Do not use absolute paths,
backslashes, wildcards, dot components, drive prefixes, URIs, or duplicate
case variants.

Approval authorizes routine execution through the single procedure in
`docs/engineering/harness/AUTHORITY.md#authority-from-work-approval`. The selected person or
agent can start, implement, check, record completion and prepare required
verification within this scope without separate permission for those steps.
Record completion only after the work and evidence are complete. Owner
acceptance and delivery remain distinct. Specify any authorized push/PR action
and destination in the decision envelope; do not imply merge or publication.

Add `architecture = ["ARCH-xxx", "ADR-xxx"]` under `[relations]` when architecture applies. The relation selects every applicable architecture plus every required deciding ADR. An ADR may be omitted only for a selected architecture whose accepted `decision_assessment` is `no_significant_decision`; every `adr_required` architecture needs at least one selected active ADR that decides it.

An architecture is applicable when it addresses an architecturally significant requirement implemented by this work order. Every selected architecture must conform to at least one of the selected specifications. Omit the `architecture` relation only when no active architecture addresses any implemented requirement. Routine requirements without an active `addresses` edge do not require fabricated architecture coverage. A present `architecture` relation must not be empty.

## Objective

## In scope

## Out of scope

## Authorized decision envelope

What may the implementation agent decide locally?

## Constraints

## Expected change surface

Inspect the affected implementation and supporting paths before approval,
using the selected released DRAFT_WORK_ORDERS.md procedure. Name each planned
path and its reason here. Include necessary tests, documentation and evidence.
Explain non-applicable areas and unresolved generated destinations briefly.
Use narrow existing component directories only when their scope is justified.
Keep the working inventory transient; this section retains the reviewed plan.

## Required verification

## Evidence to record

## Stop and escalate conditions

## Completion report format

State the completed behavior, actual checks, relevant limitations and next
accountable decision. Follow the installed workflow and shared approval rule;
do not require a separate owner completion decision for already approved work.
