+++
id = "SPEC-P3-901"
type = "specification"
title = "Exact fixture greeting value"
status = "draft"
owners = ["test-owner"]
created = "2026-10-11"
updated = "2026-10-11"
# What an implementation must do to conform. The Explorer shows this summary under the title.
contract = "The fixture greeting() in src/greeting.py returns the string Hello rehearsal exactly when called with no arguments."

[relations]
specifies = ["REQ-P3-901"]
+++

# Specification: Exact fixture greeting value

Before approval, apply the shared design principle and `specification` checklist in
`docs/engineering/ARTIFACT_AUTHORING.md`.

Synthetic rehearsal input. The owner `test-owner` is a fixture label, not a
real human decision.

## In plain words

`greeting()` must return `Hello rehearsal` with the same letters, case and
spacing.

## Scope

This specification governs the return value of `greeting()` in
`src/greeting.py`. The check method and evidence belong to VER-P3-901.

## Terms

- **Exact greeting.** The 15-character string `Hello rehearsal`: capital `H`,
  one space, lower-case `rehearsal`, no leading or trailing characters.

## Rules

**GREET-RET-001.** The implementation MUST return a value equal to the exact
greeting when `greeting()` is called with no arguments.

## Failure behaviour

| Trigger | Response | Diagnostic |
| --- | --- | --- |
| `greeting()` returns a value not equal to the exact greeting, or raises | The implementation does not conform to GREET-RET-001 | `none` |

## Examples

**Given** the selected fixture `src/greeting.py`, **when** `greeting()` is
called with no arguments, **then** the result equals `Hello rehearsal`
(GREET-RET-001).

**Given** a variant that returns `Hello rehearsal ` with a trailing space,
**when** `greeting()` is called, **then** it does not conform to GREET-RET-001.

## Coverage

| Requirement | Rules |
| --- | --- |
| `REQ-P3-901` | GREET-RET-001 |

## Not decided here

- The implementation technique; the existing fixture already defines it.
