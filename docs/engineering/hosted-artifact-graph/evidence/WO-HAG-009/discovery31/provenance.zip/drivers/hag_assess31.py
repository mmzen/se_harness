"""Independent assessment of the bounded diagnostic; not a lifecycle pass."""
import json,hashlib
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-claude-discovery31-20261011';r=O/'claude-261'
load=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
session=load(r/'native/session.json');summary=load(O/'claude-261-summary.json');reads=load(r/'instruction-read-trace.json')['reads']
parity=[load(f) for f in sorted((O/'native-parity-diagnostic31').glob('*.json'))]
assert session['exit']==0 and not session['timed_out']
assert len(parity)==7 and all(x['exact_match'] and x['http_status']==200 for x in parity)
assert {x['tool'] for x in parity}=={'revision','work-context','compare','impact','lineage','check','cypher'}
assert all(x['native_result']['complete'] and not x['native_result']['continuation'] and not x['native_result']['unresolved_references'] for x in parity)
assert load(r/'input-integrity.json')['all_unchanged'] and load(r/'boundary-comparison.json')['equal']
assert load(r/'initial-status.json')['project_version']==0 and load(r/'independent-final-status.json')['project_version']==1
calls=[]
for line,raw in enumerate((r/'native/events.jsonl').read_text().splitlines(),1):
 try:e=json.loads(raw)
 except ValueError:continue
 for b in e.get('message',{}).get('content',[]) if isinstance(e.get('message'),dict) else []:
  if b.get('type')=='tool_use':calls.append({'event_line':line,'tool':b['name'],'input':b['input']})
commands=[load(f) for f in (r/'native/work').glob('*.json') if f.name[:3].isdigit()]
assert not any('hosted-evidence.md' in x['path'] for x in reads)
result={'trial':'claude-261','candidate':load(O/'candidate-31.json')['commit'],'result':'incomplete','scope':'Focused read/discovery/report diagnostic only. No full NQ lifecycle claim.',
 'findings':{'reading':'The new direct hosted-read route was read before graph queries. Both public Cypher references were read. The required hosted-evidence.md route was not read before report construction.',
 'graph_reads':'All seven MCP tools returned successful complete results, each exactly matching independent HTTP. Cypher traversed DECLARES and returned three real work-order relations with aliases. Self-compare does not establish a non-empty diff.',
 'report':'The report correctly distinguishes the test boundary, successful reads, one failed native file read and absence of MCP/command failures. It no longer claims that relationships are unsupported or aliases mandatory. Its detailed snapshot count is qualified as pre-report. It does not identify C or link the exact public sources for general capability claims as the unread evidence guide requires.',
 'boundary':'Exactly one native import was accepted; final project version is 1. No lifecycle operation, draft context, export or additional mutation was attempted. Indexed inputs and monitored host/repository state are unchanged.'},
 'metrics':{'elapsed_seconds':session['elapsed_seconds'],'calls':summary['native_calls'],'peak_input_context':summary['peak_input_context']},
 'interventions':'Prelaunch filename and subnet-pool setup corrections retained separately. No hints, supplied query, workflow sequence or proctor mutation during the native session.',
 'next':'Do not launch full262. Add a direct reporting handoff to the read procedure, then repeat the focused diagnostic on its exact package.',
 'limits':['No completed WO, human verification, release or deployment.','Performance work remains deferred.','Earlier native reports and verdicts are unchanged.']}
for name,value in [('independent-assessment.json',result),('native-call-index.json',{'trial':'claude-261','calls':calls,'complete':True,'omissions':'Private reasoning and non-tool messages excluded.'})]:
 f=r/name;assert not f.exists();f.write_bytes((json.dumps(value,indent=2)+'\n').encode())
print(json.dumps({'result':'incomplete','seven_reads':'pass','remaining':'evidence-guide discovery before report'}))
