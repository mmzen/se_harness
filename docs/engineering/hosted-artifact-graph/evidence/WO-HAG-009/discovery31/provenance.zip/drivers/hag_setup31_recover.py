"""Resume setup after address-pool exhaustion, before any Docker write."""
import json,sys
from pathlib import Path
W=Path(__file__).parent;O=W/'hag-claude-discovery31-20261011';root=O/'claude-261'
note={'stage':'prelaunch setup','native_started':False,'failure':'The inspected 10.231.84.0/22 pool has no unused /28 pair. The assertion stopped before source volume or container creation.','recovery':'Retain existing project/config/credential files. Inspect current Docker subnets again and allocate an unused /28 pair from 10.231.88.0/22. Do not remove historical networks or volumes.'}
f=root/'prelaunch-failure.json';assert not f.exists();f.write_text(json.dumps(note,indent=2)+'\n')
source=(W/'hag_native27.py').read_text()
for a,b in [('hag-lifecycle-native27-20261010','hag-claude-discovery31-20261011'),('hag-lifecycle-correction27-20261010','hag-claude-discovery31-20261011'),('package27','package31'),('client27','client31'),('build27','build31'),('native-lifecycle27','native-discovery31'),('hag-full27-','hag-full31-'),('10.231.84.0/22','10.231.88.0/22')]:source=source.replace(a,b)
start=source.index(' root.mkdir(exist_ok=False)');end=source.index(' ids=subprocess.check_output',start)
source=source[:start]+''' config=json.loads((root/'configuration/config.json').read_text())
 compose=P/'candidate-source/server/compose.yaml'
 project='hag-full31-'+host+'-'+trial;volume=project+'-source';port=27000+int(trial)
 assert not (root/'network.json').exists() and not (root/'selection.json').exists()
'''+source[end:]
source=source.replace("host+trial+'-networks'","host+trial+'-networks-recovery'")
sys.argv=[__file__,'setup','claude','261']
exec(compile(source,'resumed-native31-setup','exec'),{'__file__':str(W/'hag_native27.py'),'__name__':'__main__'})
