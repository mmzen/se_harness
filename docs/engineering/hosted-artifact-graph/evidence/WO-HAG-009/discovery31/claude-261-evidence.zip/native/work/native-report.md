# Native MCP read-tool discovery report

Diagnostic under WO-HAG-009/011 and VER-HAG-007. This is not a full lifecycle
qualification. Git remains authoritative. All results are test data
(`test_copy: true`, `authority: rehearsal-only`).

## Environment

| Component | Identity |
| --- | --- |
| Project | `8c9e55aa-592b-4f31-a41d-d7c3551eb58d` |
| Authority mode | `sandbox-projection` |
| Client | 0.22.2, wheel SHA-256 `142d9491...ba159ae` |
| Evaluator | 0.22.1, archive SHA-256 `cb35c3c4...d863053` |
| Database | Memgraph 3.13.1 |
| Result schema | `se-harness-graph-read/v2` |
| Source commit | `5820415917e87b64d80bad2f7c39c6d18d692829` |
| Host | Claude (Opus 4.6), session `1afb8e73-0038-4f10-a7f4-f3a3c7d94259` |

All component identities in the status response match the combination report.

## Baseline import

The canonical source fixture was imported once with operation key
`import-baseline` at expected project version 0. The operation was accepted
(HTTP 200). Project version advanced from 0 to 1.

- Imported artifacts: 7 (CAP-P3-900, INT-P3-900, REL-P3-900, REQ-P3-900,
  SPEC-P3-900, VER-P3-900, WO-P3-900)
- Evaluator output: `valid: true`, 0 errors, 0 warnings, 1 advisory
- Advisory: `W-AUT-022` on SPEC-P3-900 (coverage row REQ-P3-900 names
  undefined rule P3-GREET-900, maintenance plane)
- Baseline ID:
  `se-harness-artifact-baseline/v1:sha256:008159cec4063332f6955d5b85ec65c2b73124058ca6ca38ce99e14f8fa5e5cd`
- Evidence: `work/002-import.json` and its `.evidence` directory

## MCP tool results

All seven read-only MCP tools were called against the imported baseline. Every
call returned `complete: true`, `continuation: null`, and zero
`unresolved_references`. Every response used schema `se-harness-graph-read/v2`
with `test_copy: true`.

### 1. revision

Read the stored revision for CAP-P3-900.

- **Outcome:** Success, complete
- **Revision ID:** `sha256:bb5ee22a...ba248126`
- **Returned:** Full envelope (artifact ID, document SHA-256, original path,
  declared relations, Git provenance) and base64-encoded document
- **Declared relations:** `derives_from: [INT-P3-900]`
- **Provenance:** Git, blob OID `e0fefd98...1d29e8e`, commit
  `5820415917e87b64d80bad2f7c39c6d18d692829`
- **Document digest:** `f00af6fe...fdc30bc0` (matches source manifest)

### 2. work-context

Read the work context for WO-P3-900.

- **Outcome:** Success, complete
- **Work order:** WO-P3-900 at revision `sha256:c493808c...c4711f0`
- **Governing artifacts (5):** CAP-P3-900, INT-P3-900, REQ-P3-900,
  SPEC-P3-900, VER-P3-900
- **Declared scope:** `docs/engineering/lifecycle-pilot/`, `src/greeting.py`
- **Dependencies:** none
- **Relevant decisions:** none
- **Evaluator output:** Present, `outcome: completed`,
  `compliance.status: not_assessable`, `WO-P3-900 is draft`
- **Instruction discovery:** `status: available`

### 3. compare

Compared the imported baseline against itself (identity comparison).

- **Outcome:** Success, complete
- **Changes:** 0 changes, 0 added relations, 0 removed relations
- **Evaluator output:** null (no evaluator invocation for identity comparison)

### 4. impact

Read the impact graph from root artifact REQ-P3-900.

- **Outcome:** Success, complete
- **Root:** REQ-P3-900
- **Reachable artifacts (4):** REL-P3-900, SPEC-P3-900, VER-P3-900, WO-P3-900
- **Relations (6):**
  - SPEC-P3-900 --specifies--> REQ-P3-900
  - VER-P3-900 --verifies--> REQ-P3-900
  - WO-P3-900 --implements--> REQ-P3-900
  - WO-P3-900 --specifications--> SPEC-P3-900
  - WO-P3-900 --verification--> VER-P3-900
  - REL-P3-900 --gates--> WO-P3-900
- **Evaluator output:** null

### 5. lineage

Read the verification/evidence lineage from root VER-P3-900.

- **Outcome:** Success, complete
- **Root:** VER-P3-900
- **Connected artifacts (1):** WO-P3-900
- **Relations (1):** WO-P3-900 --verification--> VER-P3-900
- **Evaluator output:** null
- **Note:** No VREC or evidence artifacts exist in this baseline, so the
  lineage is limited to the verification contract link.

### 6. check

Read the checkpoint-free check for WO-P3-900.

- **Outcome:** Success, complete
- **Evaluator output:** Present, `outcome: completed`,
  `compliance.status: not_assessable`
- **Scoped blockers:** 0
- **Repository blockers:** 0
- **Lifecycle state:** WO-P3-900 is `draft`
- **Instruction discovery:** Available, with procedure `PROC-FOCUS-SELECTED`

### 7. cypher

Executed a bounded Cypher query to read declared relations from WO-P3-900.

- **Query:**
  ```cypher
  MATCH (r:Revision)-[d:DECLARES]->(a:Artifact)
  WHERE r.artifact_id = $artifact
  RETURN r.artifact_id AS source, d.kind AS relation, a.artifact_id AS target
  LIMIT 10
  ```
- **Parameters:** `{"artifact": "WO-P3-900"}`
- **Outcome:** Success, complete
- **Columns:** `source`, `relation`, `target`
- **Rows (3):**

  | source | relation | target |
  | --- | --- | --- |
  | WO-P3-900 | implements | REQ-P3-900 |
  | WO-P3-900 | specifications | SPEC-P3-900 |
  | WO-P3-900 | verification | VER-P3-900 |

- **Evaluator output:** null
- **Column aliases:** The `RETURN ... AS alias` syntax was accepted and the
  response columns used the requested alias names.

## Relationship reads: documented support and observed behavior

The public read interface supports relationship reads through three mechanisms:

1. **Domain reads** (`impact`, `lineage`): These traverse the declared relations
   stored as DECLARES edges in the graph. Impact returns forward and reverse
   reachability from a root artifact within the depth budget. Lineage returns
   connected verification/evidence relations. Both resolve target revisions
   through the selected view. Relations are returned as typed edges with
   `source`, `kind`, and `target` bindings. The documented relation kinds
   observed in this fixture include `derives_from`, `specifies`, `implements`,
   `specifications`, `verification`, `verifies`, and `gates`.

2. **Comparison** (`compare`): Returns added and removed resolved relation
   triples between two views. Each triple is `(source revision, kind, target
   revision)`. This was confirmed to work with identity comparison (empty diff).

3. **Bounded Cypher** (`cypher`): Provides constrained exploration of the graph.
   The admitted form requires labelled nodes (`Artifact`, `Revision`), one
   `MATCH` or `OPTIONAL MATCH` path, optional parameterized property
   comparisons, `RETURN`, and a numeric `LIMIT`. The public surface exposes
   DECLARES edges with `kind` and `target_artifact_id` properties. This was
   confirmed to work with a relationship traversal query.

## Return-column aliases in Cypher

The Cypher tool supports return-column aliases through the standard Cypher
`RETURN expression AS alias` syntax. The query
`RETURN r.artifact_id AS source, d.kind AS relation, a.artifact_id AS target`
returned columns named `["source", "relation", "target"]`, confirming that
user-selected aliases appear in the response's `data.columns` array and each
row's positional values correspond to those named columns.

The documented admitted form does not support `WITH`, aggregation, unlabelled
nodes, or arbitrary database syntax. The service binds the selected project and
view; no explicit project filter is needed in the query. A rejected query is
retained with its exact refusal.

## Failures and limitations

- **File read failure (1):** An initial Read for
  `docs/notes/hosted-artifact-graph.md` targeted the `source/` directory, where
  the file does not exist. The file was located in the `reference/` directory
  and read successfully on the next attempt. This was an incorrect path
  selection, not a service failure.
- **Command failures:** 0
- **MCP tool failures:** 0
- **MCP tool refusals:** 0
- **Compare limitation:** Only one baseline exists in this project. The identity
  comparison confirmed the tool works but did not exercise a meaningful diff.
  A second view (draft context or frozen baseline) would be needed to observe
  non-empty changes.
- **Lineage limitation:** No VREC, RLS, or DEC artifacts exist in this
  fixture. The lineage result reflects only the work-order-to-verification link.
  A richer lineage response would require verification records.
- **Database read-only enforcement:** Remains deferred under RISK-HAG-001. This
  diagnostic used only the private public-data sandbox.

## Evidence records

| Record | Path |
| --- | --- |
| Status check | `work/001-status.json` |
| Import result | `work/002-import.json` |
| Import evidence | `work/002-import.json.evidence/` |
| Observations snapshot | `work/003-observations.json` |
| Structured observations | `work/native-observations.json` |

The observations snapshot at `work/003-observations.json` was captured before
this report was written. It contains 28 observed tool items, 2 command records
(both exit 0), and 1 native file read failure (the wrong-path Read described
above). The MCP tool results are retained in conversation context and
summarized above; they were not saved to separate record files because MCP
calls flow through the tool protocol, not the native command helper.

## Scope and authority

This report covers a focused read-tool discovery diagnostic. It does not
constitute a full lifecycle qualification. No drafts were created, no lifecycle
transitions were executed, no exports were performed, and no approval or
release authority was exercised. Git remains authoritative for the actual
repository.
