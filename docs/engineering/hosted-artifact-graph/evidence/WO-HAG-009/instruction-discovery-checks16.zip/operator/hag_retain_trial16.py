"""Create bounded, credential-checked archives in temporary review storage."""
import json,re,zipfile,sys
from pathlib import Path
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007';out=o/'review16';out.mkdir(exist_ok=True)
trial=sys.argv[1];generation={'opus06':'guidance15','opus07':'guidance16'}[trial]
r=o/'claude/native02/work'/trial;g=o/('claude-'+generation)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
assert (r/'session.json').exists()
secrets=[]
for p in o.glob('claude-guidance*/credentials.json'):
 secrets.extend(v['token'].encode() for v in load(p)['principals'])
files={}
for name in ('events.jsonl','stderr.txt','session.json','invocation.json','selection.json','task.md','reply-fault.json','native-report.md','native-observations.json','mcp.json','CLAUDE.md'):
 p=r/name
 if p.is_file():files['native/'+name]=p
for p in (r/'work').rglob('*'):
 if p.is_file():files['native/'+p.relative_to(r).as_posix()]=p
for p in (r/'inputs').rglob('*'):
 if p.is_file() and not p.name.endswith(('.whl','.pyc')):files['native/'+p.relative_to(r).as_posix()]=p
for name in ('selection.json','combination.json','stage-evidence.json','native-selection.json','native-task.md','permissions.json','correction-binding.json'):
 files['setup/'+name]=g/name
for pattern in (generation+'-state-*.json','claude-'+generation+'-version.json','claude-'+generation+'-auth-probe.json',trial+'-*.json'):
 for p in o.glob(pattern):files['checks/'+p.name]=p
for p in (o/('native-parity-'+generation)).glob('*.json'):files['independent-mcp/'+p.name]=p
replay=Path(r'C:\Users\mathi\AppData\Local\Temp')/('hag-'+trial+'-replay-20261007')
if replay.is_dir():
 for p in replay.glob('*.json'):files['independent-replay/'+p.name]=p
files['operator/native-reader.py']=o/('improve16-helper-before.py') if trial=='opus06' else h.R/'tests/hosted_artifact_graph/native_call.py'
for name in ('hag_native_'+generation+'.py','hag_finish_native'+generation[-2:]+'.py','hag_native_parity'+generation[-2:]+'.py'):
 files['operator/'+name]=h.W/name
archive=out/(trial+'-evidence.zip');inventory=[]
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(files.items()):
  assert not p.is_symlink(),p
  raw=p.read_bytes()
  assert not any(token in raw for token in secrets),name
  assert not re.search(rb'sk-ant-(?:oat|ort|api)',raw),name
  assert not any(part in ('.git','credentials.json') for part in Path(name).parts),name
  z.writestr(name,raw);inventory.append({'path':name,'bytes':len(raw),'sha256':h.sha(raw)})
h.write(out/(trial+'-inventory.json'),{'archive':archive.name,'bytes':archive.stat().st_size,'sha256':h.sha(archive.read_bytes()),'files':inventory,'redaction':'Native recorder redaction preserved. All retained bytes checked against known private test-project tokens and provider-token prefixes. Credentials, environments, wheels, copied .git directories and host profile contents excluded. Staged instruction/contract/fixture inputs are exact bounded test inputs.'})
print(json.dumps({'trial':trial,'files':len(inventory),'bytes':archive.stat().st_size}))
