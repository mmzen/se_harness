import json,os
from pathlib import Path
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007';o=h.O;out=o/'review16'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
trace=load(o/'claude-discovery-read-trace16.json')
for trial,generation in [('opus06','guidance15'),('opus07','guidance16')]:
 r=o/'claude/native02/work'/trial;g=o/('claude-'+generation)
 assert load(o/(generation+'-state-before.json'))==load(o/(generation+'-state-after.json'))
 selection=load(g/'selection.json');creds=load(g/'credentials.json')
 token=next(p['token'] for p in creds['principals'] if p['id']=='operator')
 env=dict(os.environ,HAG_NATIVE_TEST_TOKEN=token)
 base=[selection['client_python'],'-I','-m','se_harness','remote']
 opts=['--endpoint',selection['endpoint'],'--project',selection['project_id'],'--token-env','HAG_NATIVE_TEST_TOKEN','--json']
 status=h.run(trial+'-final-status',[*base,'status',*opts],env=env)
 receipts=[]
 for p in sorted((r/'work').glob('*.json')):
  v=load(p)
  if not isinstance(v,dict) or 'stdout' not in v:continue
  try:result=json.loads(v['stdout'])
  except ValueError:continue
  if not isinstance(result,dict) or result.get('outcome')!='accepted':continue
  key=result['operation_key'];lookup=h.run(trial+'-receipt-'+key,[*base,'operation','--key',key,*opts],env=env)
  assert lookup==result,(trial,key)
  receipts.append({'native_file':p.relative_to(r).as_posix(),'sha256':h.sha(p.read_bytes()),'key':key,'outcome':result['outcome'],'view':result.get('view'),'versions':result.get('versions'),'affected_artifacts':result.get('affected_artifacts'),'exact_lookup_match':True})
 reads=[x for x in trace['reads'] if x['trial']==trial]
 missing=not any(x['path'].replace('\\','/').endswith('/ARTIFACT_AUTHORING.md') and not x['returned_error'] for x in reads)
 events=[json.loads(x) for x in (r/'events.jsonl').read_text(encoding='utf-8').splitlines()]
 calls={};reader=[];draft_writes=[];lifecycle=[]
 for n,event in enumerate(events,1):
  for b in event.get('message',{}).get('content',[]) if isinstance(event.get('message'),dict) else []:
   if not isinstance(b,dict):continue
   if b.get('type')=='tool_use':
    calls[b['id']]={'line':n,'name':b['name'],'input':b['input']}
    if b['name']=='Write' and '/drafts/' in b['input'].get('file_path','').replace('\\','/'):draft_writes.append({'line':n,'path':b['input']['file_path']})
    if b['name']=='Bash' and ' rehearse' in b['input'].get('command',''):lifecycle.append({'line':n,'command':b['input']['command']})
   if b.get('type')=='tool_result':
    c=calls.get(b.get('tool_use_id'),{})
    if c.get('name')=='Bash' and ' read-json ' in c['input'].get('command','') and '--help' not in c['input']['command']:
     reader.append({'call':c,'result_line':n,'error':bool(b.get('is_error')),'returned_content':b.get('content')})
 assert not lifecycle
 if trial=='opus07':assert missing and len(draft_writes)==7 and any(x['key']=='revise-int-001' for x in receipts)
 v={'trial':trial,'outcome':'stopped_reader_platform_defect' if trial=='opus06' else 'failed_instruction_discovery','session':load(r/'session.json'),'stop':load(o/(trial+'-stop.json')),'source_candidate':load(g/'native-selection.json')['qualification_candidate'],'packaged_components':load(g/'combination.json'),'helper_binding':load(o/('improve15-helper-binding.json' if trial=='opus06' else 'improve16-helper-binding.json')),'status_after_stop':status,'receipt_lookups':receipts,'draft_content_writes':draft_writes,'required_authoring_read_missing':missing,'instruction_reads':[x for x in reads if '/skills/' in x['path'].replace('\\','/') or '/released-resources/' in x['path'].replace('\\','/')],'reader_attempts':reader,'successful_reader_values':sum(not x['error'] for x in reader),'actual_lifecycle_requests':lifecycle,'native_cases':{'NQ-01':'not completed; platform defect' if trial=='opus06' else 'fail: required authoring guidance not read before completing draft content','NQ-02':'partial drafts only; not qualified','NQ-03':'not run to completion; no seven-tool comparison','NQ-04':'not run; no reply dropped','NQ-05':'not run; no exports or final native report'},'real_repository_and_selected_host_settings_unchanged':True,'assessment_limits':['Operation receipt equality confirms recorded draft effects, not independent released lifecycle replay. No lifecycle operation was attempted.','No final actual VREC, completion, assurance decision, risk acceptance, merge or release.','Interrupted trials do not establish efficiency improvements against longer completed or timed-out trials.']}
 h.write(out/(trial+'-assessment.json'),v)
 print(json.dumps({'trial':trial,'outcome':v['outcome'],'accepted_receipts':len(receipts),'reader_successes':v['successful_reader_values']}))
