import json,subprocess,shlex
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
probe=h.O/'argv-probe16.py';h.write(probe,'import json,sys\nprint(json.dumps(sys.argv[1:]))\n')
arguments=['/versions','#/versions','#%2Fversions','"/versions"','json:/versions','--pointer=/versions','/versions/project']
command=' '.join(shlex.quote(x) for x in [h.HOST.as_posix(),'-I',probe.as_posix(),*arguments])
h.run('improve16-msys-forms',[r'C:\Program Files\Git\bin\bash.exe','--noprofile','--norc','-c',command])
print((h.O/'improve16-msys-forms.json').read_text())
