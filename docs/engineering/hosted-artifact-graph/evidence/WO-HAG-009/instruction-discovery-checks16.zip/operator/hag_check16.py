import json,os,shlex,sys
import hag221_execute as h
h.O=h.W/'hag-agent-qualification-execution-20261007'
if sys.argv[1]=='focused':
 h.run('improve16-reader-tests2',[h.HOST,'-X','utf8','-B','-m','unittest','discover','-s','tests/hosted_artifact_graph','-p','test_native_support.py'],cwd=h.R)
 d=h.O/'pointer16';d.mkdir(exist_ok=False)
 h.write(d/'selection.json',{});h.write(d/'receipt.json',{'outcome':'refused','a/b':{'~x':[None,False,'exact']}})
 argv=[h.HOST.as_posix(),'-I',(h.R/'tests/hosted_artifact_graph/native_call.py').as_posix(),'read-json',(d/'receipt.json').as_posix(),'--pointer',json.dumps('/a~1b/~0x/2')]
 v=h.run('improve16-msys-helper',[r'C:\Program Files\Git\bin\bash.exe','--noprofile','--norc','-c',' '.join(shlex.quote(x) for x in argv)],env=dict(os.environ,HAG_NATIVE_WORK_DIRECTORY=str(d),HAG_NATIVE_SELECTION=str(d/'selection.json')))
 assert v['pointer']=='/a~1b/~0x/2' and v['value']=='exact'
 h.run('improve16-diff-check2',['git','diff','--check'],cwd=h.R)
 h.run('improve16-stage',['git','add','--','tests/hosted_artifact_graph/native_call.py','tests/hosted_artifact_graph/test_native_support.py'],cwd=h.R)
 h.run('improve16-commit',['git','commit','-m','Preserve JSON pointers through Windows Bash in native tests'],cwd=h.R)
 h.write(h.O/'improve16-candidate.json',{'commit':h.git('rev-parse','HEAD'),'packaged_guidance_source':'8126918e7406b9630474f9c933bf66cb9eed6a29','changed':'Only native test reader and boundary tests; packaged runtime and guidance unchanged.'})
elif sys.argv[1]=='suite':
 h.run('improve16-source-suite',[h.HOST,'-X','utf8','-B','scripts/run_tests.py'],cwd=h.R,env=dict(os.environ,PYTHONUTF8='1'),timeout=1800)
 h.run('improve16-distributions',[h.HOST,'-X','utf8','-B','scripts/validate_release_distributions.py','--root','.'],cwd=h.R)
 h.run('improve16-cli-smoke',[h.HOST,'-X','utf8','-B','-m','se_harness','--help'],cwd=h.R)
