import json,collections
from pathlib import Path
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007';roots=o/'claude/native02/work'
rows=[]
for name in ('opus02','opus03','opus04','opus05','opus06','opus07'):
 r=roots/name;events=[json.loads(l) for l in (r/'events.jsonl').read_text(encoding='utf-8').splitlines() if l.strip()]
 calls=[];messages={};sizes=[];errors=[];compactions=[];peaks=[];reads=[]
 for n,e in enumerate(events,1):
  if e.get('type')=='system' and 'compact' in e.get('subtype',''):compactions.append({'line':n,'subtype':e.get('subtype'),'metadata':e.get('compact_metadata')})
  m=e.get('message',{})
  if not isinstance(m,dict):continue
  u=m.get('usage')
  if u:
   messages[m.get('id',str(n))]=u
   peaks.append(sum(u.get(k,0) for k in ('input_tokens','cache_creation_input_tokens','cache_read_input_tokens')))
  for b in m.get('content',[]):
   if not isinstance(b,dict):continue
   if b.get('type')=='tool_use':
    calls.append((n,b));
    if b['name']=='Read':reads.append(b['input'])
   if b.get('type')=='tool_result':
    content=b.get('content');sizes.append(len(content.encode()) if isinstance(content,str) else len(json.dumps(content,ensure_ascii=False).encode()))
    if b.get('is_error'):errors.append({'line':n,'content':str(content)[:250]})
 counter=collections.Counter(b['name'] for _,b in calls)
 selector=[(n,b['input']['command']) for n,b in calls if b['name']=='Bash' and ' read-json ' in b['input'].get('command','')]
 final=next((e for e in reversed(events) if e.get('type')=='result'),None)
 rows.append({'trial':name,'complete':(r/'session.json').exists(),'session':json.loads((r/'session.json').read_text()) if (r/'session.json').exists() else None,'tool_calls':counter,'json_field_reads':len(selector),'native_Read_calls':len(reads),'tool_result_bytes':sum(sizes),'largest_tool_result_bytes':max(sizes,default=0),'peak_observed_input_context_tokens':max(peaks,default=0),'automatic_compactions':compactions,'errors':errors,'host_final_usage':final.get('usage') if final else None,'host_total_cost_usd':final.get('total_cost_usd') if final else None})
value={'method':'Native event measurements. Context uses each message input+cache creation+cache read fields, not their sum across turns. Output text bytes are measured separately, not called tokens. Trials have different tasks and termination points; these are observations, not a controlled efficiency benchmark.','trials':rows}
h.write(o/'instruction-context-metrics16.json',value)
print(json.dumps([{k:x[k] for k in ('trial','complete','tool_calls','json_field_reads','peak_observed_input_context_tokens','tool_result_bytes','largest_tool_result_bytes')} for x in rows]))
