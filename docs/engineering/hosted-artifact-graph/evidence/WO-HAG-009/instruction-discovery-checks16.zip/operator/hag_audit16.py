import json,hashlib,subprocess,sys
from pathlib import Path
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007';r=o/'claude/native02/work/opus07'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
if sys.argv[1]=='runtime':
 old=load(o/'runtime-reuse-guidance04.json');before=old['previous_qualified_source'];now='8126918e7406b9630474f9c933bf66cb9eed6a29'
 values=[]
 for entry in old['unchanged_runtime_files']:
  a=h.blob(before,entry['path']);b=h.blob(now,entry['path']);assert a==b,entry['path']
  values.append({'path':entry['path'],'sha256':h.sha(b)})
 h.write(o/'runtime-reuse-guidance16.json',{'previous_qualified_source':before,'new_package_source':now,'unchanged_runtime_files':values,'combination':load(o/'claude-guidance16/combination.json'),'limit':'Runtime source equality preserves the existing Phase 3 service observations. Packaged plugin guidance and test helper changed; native instruction qualification must be rerun. Package bytes were rebuilt and have their own identities.'})
 print(json.dumps({'runtime_files_equal':len(values)}));raise SystemExit
events=[json.loads(l) for l in (r/'events.jsonl').read_text(encoding='utf-8').splitlines() if l.strip()]
calls={};reads=[];errors=[];outside=[];shell=[];results=[];compactions=[]
for n,event in enumerate(events,1):
 if event.get('type')=='system' and 'compact' in event.get('subtype',''):compactions.append({'line':n,'subtype':event['subtype'],'metadata':event.get('compact_metadata')})
 message=event.get('message',{})
 for b in message.get('content',[]) if isinstance(message,dict) else []:
  if not isinstance(b,dict):continue
  if b.get('type')=='tool_use':
   calls[b['id']]={'line':n,'name':b['name'],'input':b['input']}
   if b['name']=='Read':reads.append({'line':n,'id':b['id'],'path':b['input'].get('file_path'),'offset':b['input'].get('offset'),'limit':b['input'].get('limit')})
   if b['name']=='Skill':reads.append({'line':n,'id':b['id'],'skill':b['input'].get('skill')})
   if b['name']=='Bash':
    c=b['input'].get('command','');prefix='C:/Users/mathi/AppData/Local/Python/pythoncore-3.14-64/python.exe'
    ok=c.startswith((prefix,'"'+prefix+'"')) and ' -I ' in c and '/claude/native02/inputs/native_call.py' in c and not any(x in c for x in (' | ',' && ',';','\n'))
    shell.append({'line':n,'id':b['id'],'fixed_prefix_observed':ok,'command':c})
   if b['name'] in ('Write','Edit'):
    p=Path(b['input']['file_path'])
    if not p.is_relative_to(r/'work') and p not in (r/'native-report.md',r/'native-observations.json'):outside.append({'line':n,'path':str(p)})
  if b.get('type')=='tool_result':
   x=calls.get(b.get('tool_use_id'),{})
   if b.get('is_error'):errors.append({'line':n,'call':x,'content':str(b.get('content'))[:800]})
   for read in reads:
    if read['id']==b.get('tool_use_id'):read['returned_error']=bool(b.get('is_error'))
   if x.get('name')=='Bash':results.append({'line':n,'call_line':x['line'],'error':bool(b.get('is_error')),'content_preview':str(b.get('content'))[:300]})
v={'event_sha256':h.sha((r/'events.jsonl').read_bytes()),'event_lines':len(events),'reads':reads,'shell':shell,'errors':errors,'outside':outside,'compactions':compactions,'complete':(r/'session.json').exists()}
if sys.argv[1]=='save':h.write(o/'opus07-native-audit.json',v)
print(json.dumps({'complete':v['complete'],'reads':len(reads),'procedures':[(x['line'],Path(x.get('path','')).name) for x in reads if '/harness/' in x.get('path','').replace('\\','/')],'nonhelper':[x for x in shell if not x['fixed_prefix_observed']],'errors':errors[-2:],'outside':outside,'compactions':compactions,'shell_calls':len(shell)},ensure_ascii=False))
