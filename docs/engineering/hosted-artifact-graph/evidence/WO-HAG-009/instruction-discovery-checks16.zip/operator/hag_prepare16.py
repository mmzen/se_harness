import json
import hag221_execute as h
o=h.W/'hag-agent-qualification-execution-20261007'
p=(h.W/'hag_native_guidance15.py').read_text()
p=p.replace('guidance15','guidance16').replace('opus06','opus07').replace('18341','18351').replace('18342','18352')
p=p.replace('harness-hag:native-guidance16','harness-hag:native-guidance15')
h.write(h.W/'hag_native_guidance16.py',p)
p=(h.W/'hag_finish_native15.py').read_text().replace('guidance15','guidance16').replace('opus06','opus07').replace('improve15-candidate','improve16-candidate')
p=p.replace('Inspect helper-help.txt or its subcommand help.', 'Inspect helper-help.txt or its subcommand help. In Windows Bash, pass --pointer as a shell-quoted JSON string (the subcommand help shows the syntax); a raw leading slash is converted to a filesystem path by that shell.')
h.write(h.W/'hag_finish_native16.py',p)
for source,target in [('hag_native_parity15.py','hag_native_parity16.py'),('hag_native_progress15.py','hag_native_progress16.py'),('hag_audit15.py','hag_audit16.py')]:
 p=(h.W/source).read_text().replace('guidance15','guidance16').replace('opus06','opus07')
 h.write(h.W/target,p)
helper=o/'claude/native02/inputs/native_call.py';prior=helper.read_bytes()
assert not (o/'improve16-helper-before.py').exists()
h.write(o/'improve16-helper-before.py',prior);h.write(helper,(h.R/'tests/hosted_artifact_graph/native_call.py').read_bytes())
h.write(o/'improve16-helper-binding.json',{'before_sha256':h.sha(prior),'after_sha256':h.sha(helper.read_bytes()),'source_candidate':h.git('rev-parse','HEAD'),'packaged_source':'8126918e7406b9630474f9c933bf66cb9eed6a29','limit':'Only the native helper/test files changed after package build; package15 runtime and guidance are reused byte-for-byte. The prior helper is preserved and the previous native process has exited.'})
