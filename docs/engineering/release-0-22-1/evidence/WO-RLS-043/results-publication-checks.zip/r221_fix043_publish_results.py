"""Update only the authorized existing draft PR with retained observations."""
import json,subprocess,hashlib,zipfile,sys
import r221_session as s
s.OUT=s.WORK/'r221-fix043-20261005'
mode=sys.argv[1]
body='''Prepare evaluator 0.22.1 and plugin 0.2.6 with the two approved HAG evaluator corrections, the dashboard correction already on main, and the approved transition snapshot fix. The hosted service remains excluded.

Harness-Work-Orders: WO-RLS-040, WO-RLS-041, WO-RLS-043

**Preparation remains in progress; verification pending. Keep this PR draft.**

The correction retains absent evidence declared by an unrelated draft, rechecks it before apply, and preserves required evidence gates, path checks, exact selected writes and rollback. mmzen's correction approval and exact linked release-contract amendment are applied; the previous accepted bytes and history are preserved.

## Current review

- [Corrected qualification report](https://github.com/mmzen/se_harness/blob/codex/release-0-22-1/docs/engineering/release-0-22-1/evidence/WO-RLS-043/corrected-qualification-review.md).
- [Exact contract amendment](https://github.com/mmzen/se_harness/blob/codex/release-0-22-1/docs/engineering/release-0-22-1/evidence/WO-RLS-043/amendment.json).
- [Release preparation index](https://github.com/mmzen/se_harness/blob/codex/release-0-22-1/docs/engineering/release-0-22-1/README.md).

Corrected package source: `061307929c94314ccd2beb4a53f174e536fceba8`. Later review commits retain evidence only; they are not substituted for that tested source or claimed as a final release candidate.

Windows and Linux full-scale suites exit 0: 1,293 tests each, with 23 and 2 reported skips. Distribution, CLI, installed wheel/sdist probes, both HAG corrections, dashboard boundaries, pinned identical build replay, upgrade rehearsals and package staging pass. Actual Codex/Claude CLI startup, compaction, resume, selection boundaries and both-checkout work-to-delivery cycles pass. Independent checks confirm exact content, unchanged accepted definitions and drafts, and no remote publication. Failed attempts and recoveries remain retained.

CI at `82c8c5a78a5b44cfbafb4b96514ea4be83905e7f` passed. Manual rehearsal [37252846313](https://github.com/mmzen/se_harness/actions/runs/37252846313) passed all three selected jobs. Its release-record leg replays historical RLS-SEH-032. New review-head CI is reported by this PR; prior-head results do not replace it.

## Remaining criteria

- Codex Windows desktop delivery remains unverified; CLI evidence is not a substitute.
- Current PyPI account-side Trusted Publisher binding remains unconfirmed.
- The reviewed live pypi environment reviewer change needs separate authority; no provider setting changed.

Resolve those criteria, then finalize matching candidate/staging identities and the aggregate verification record. There is no final VREC or RLS yet. Human verification, merge, exact complete-release approval and adoption remain separate. No public release, marketplace, tags or provider settings changed. HAG PR #535 retains its original target and blockers.
'''
bodyfile=s.OUT/'results-pr-body.md'
event=s.OUT/'results-publication-event.json'
if mode=='prepare':
    assert not bodyfile.exists();bodyfile.write_text(body,encoding='utf-8',newline='\n')
    event.write_text(json.dumps({'pull_request':{'body':body}},indent=2)+'\n')
    assert (s.REPO/s.DOMAIN/'evidence/WO-RLS-043/corrected-qualification-review.md').is_file()
    s.gov('results-validation','validate')
    s.gov('results-pr-scope','check-pr','--event',event,'--from-git',s.BASE)
    s.gov('results-preaction','check','--artifact','WO-RLS-040','--checkpoint','pre-action','--from-git',s.BASE)
elif mode=='retain':
    dest=s.REPO/s.DOMAIN/'evidence/WO-RLS-043/results-publication-checks.zip';assert not dest.exists()
    paths=[s.OUT/(n+'.json') for n in ('results-validation','results-pr-scope','results-preaction','current-main-rules','current-main-ruleset','current-pypi-environment','current-pypi-branches')]
    paths+=[s.WORK/'r221_fix043_archive.py',s.WORK/'r221_fix043_report.py',s.WORK/'r221_fix043_publish_results.py']
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in paths:z.writestr(p.name,p.read_bytes())
    print(json.dumps({'path':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}))
elif mode=='commit':
    names=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=s.REPO,text=True).splitlines()
    names+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=s.REPO,text=True).splitlines()
    assert names and all(p.startswith(s.DOMAIN) for p in names),names
    s.gov('results-complete-pr-scope','check-pr','--event',event,'--from-git',s.BASE)
    s.gov('results-complete-preaction','check','--artifact','WO-RLS-040','--checkpoint','pre-action','--from-git',s.BASE)
    s.run('results-diff-check',['git','diff','--check'],cwd=s.REPO)
    s.run('results-stage',['git','add','--',s.DOMAIN],cwd=s.REPO)
    s.run('results-commit',['git','commit','-m','Retain corrected 0.22.1 qualification and native workflow evidence','-m','Harness-Work-Orders: WO-RLS-040, WO-RLS-041, WO-RLS-043'],cwd=s.REPO)
elif mode=='publish':
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s.REPO,text=True).strip()
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=s.REPO,text=True).strip()
    before,_=s.run('results-pr-before',['gh','pr','view','536','--repo','mmzen/se_harness','--json','headRefOid,headRefName,baseRefName,isDraft,state'])
    assert before['headRefOid']=='82c8c5a78a5b44cfbafb4b96514ea4be83905e7f' and before['headRefName']=='codex/release-0-22-1' and before['baseRefName']=='main' and before['isDraft'] and before['state']=='OPEN'
    changed=subprocess.check_output(['git','diff','--name-only',before['headRefOid'],head],cwd=s.REPO,text=True).splitlines()
    assert changed and all(p.startswith(s.DOMAIN) for p in changed),changed
    subprocess.run(['git','merge-base','--is-ancestor',before['headRefOid'],head],cwd=s.REPO,check=True)
    text=bodyfile.read_text().replace('/blob/codex/release-0-22-1/','/blob/'+head+'/')
    remote_body=s.OUT/'results-remote-body.md';assert not remote_body.exists();remote_body.write_text(text,encoding='utf-8',newline='\n')
    final_event=s.OUT/'results-final-publication-event.json';final_event.write_text(json.dumps({'pull_request':{'body':text}},indent=2)+'\n')
    s.gov('results-final-pr-scope','check-pr','--event',final_event,'--from-git',s.BASE)
    s.gov('results-final-preaction','check','--artifact','WO-RLS-040','--checkpoint','pre-action','--from-git',s.BASE)
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=s.REPO,text=True).strip()
    s.run('results-push',['git','push','origin',head+':refs/heads/codex/release-0-22-1'],cwd=s.REPO)
    s.run('results-update-pr',['gh','pr','edit','536','--repo','mmzen/se_harness','--body-file',remote_body])
    after,_=s.run('results-remote-readback',['gh','pr','view','536','--repo','mmzen/se_harness','--json','url,headRefOid,headRefName,baseRefName,isDraft,state,body,statusCheckRollup'])
    assert after['headRefOid']==head and after['isDraft'] and after['baseRefName']=='main' and after['body'].replace('\r\n','\n').strip()==text.strip()
    print(json.dumps({'head':head,'url':after['url'],'draft':after['isDraft']}))
else:raise SystemExit(mode)
