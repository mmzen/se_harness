"""Retain exact correction qualification evidence, never profiles or credentials."""
import hashlib,json,re,zipfile
from pathlib import Path
import r221_session as s
OUT=s.WORK/'r221-fix043-20261005'
dest=s.REPO/s.DOMAIN/'evidence/WO-RLS-043'
def archive(name,files):
    target=dest/name
    assert not target.exists()
    entries=[]
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(set(files)):
            raw=p.read_bytes()
            assert not re.search(rb'(?:sk-ant-|sk-proj-|Bearer\s+)[A-Za-z0-9_-]{16,}',raw),p
            member=p.relative_to(s.WORK).as_posix()
            z.writestr(member,raw)
            entries.append({'path':member,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    result={'archive':name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'entries':entries,'claim':'Actual correction qualification; no credentials, profile storage, final assurance or desktop results.'}
    (dest/(target.stem+'-index.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'archive':name,'bytes':target.stat().st_size,'entries':len(entries),'sha256':result['sha256']}))

mode=__import__('sys').argv[1]
if mode=='runtime':
    files=[p for p in OUT.glob('*.json') if not p.name.startswith(('plugin026','flow-'))]
    files += list((OUT/'windows-package').glob('correction-installed-*.json'))
    files += list((OUT/'windows-package').glob('upgrade-*/upgrade-rehearsal-result.json'))
    files += [s.WORK/n for n in ('r221_session.py','r221_fix043_run.py','r221_fix043_extra.py','r221_fix043_probe.py','r221_fix043_more.py','r221_checks.py','r221_packages.py','r221_windows_resume.py','r221_linux.py','r221_linux_wsl.py','r221_linux_resume.py','r221_topology.py')]
    archive('corrected-runtime.zip',files)
    for name in ('bundle.json','build-replay.json','topology-candidate-measure.json'):
        p=dest/('corrected-'+name);assert not p.exists();p.write_bytes((OUT/name).read_bytes())
elif mode=='native':
    for p in OUT.glob('plugin026*.json'):
        if p.name!='plugin026-native-inputs.json':assert json.loads(p.read_text())['passed'],p
    for folder,names in [('native-workflow',('successor','legacy')),('claude-workflow',('one','two'))]:
        for name in names:
            p=OUT/folder/(name+'-independent-assessment.json')
            assert json.loads(p.read_text())['passed'],p
        assert not list((OUT/folder).glob('*/pending-command.json'))
    files=[p for p in OUT.glob('plugin026*.json') if p.name!='plugin026-native-inputs.json']
    for folder in ('plugin026-trusted-native-codex-events','plugin026-boundaries-events','native-workflow','claude-workflow'):
        files += [p for p in (OUT/folder).rglob('*') if p.is_file() and p.suffix in ('.json','.jsonl','.md','.txt','.zip')]
    files += list(OUT.glob('flow-*.json'))
    files += [s.WORK/n for n in ('r221_fix043_native_prepare.py','r221_fix043_native_codex.py','r221_fix043_native_claude.py','r221_fix043_boundary_prepare.py','r221_fix043_boundaries_codex.py','r221_fix043_boundaries_claude.py','r221_fix043_context_bound.py','r221_fix043_flow_prepare.py','r221_fix043_claude_workflow.py','r221_fix043_codex_workflow.py','r221_fix043_walk_review.py','r221_proposal_assess.py','r221_workflow_assess.py') if (s.WORK/n).exists()]
    files += [s.WORK/'iar-demo-tools'/n for n in ('acceptance_native.py','run_demo.py')]
    files += [s.WORK/'r221_fix043_codex_second.txt']
    files += [s.WORK/'r221_fix043_more.py']
    archive('corrected-native.zip',files)
    for host in ('codex','claude'):
        p=dest/('corrected-'+host+'-assembly-inventory.json');assert not p.exists()
        p.write_bytes((OUT/f'plugin026-marketplace/packages/{host}/verity-plane/assembly-inventory.json').read_bytes())
    p=dest/'corrected-package-identity.json';assert not p.exists()
    p.write_bytes((OUT/'plugin026-marketplace/PACKAGE-IDENTITY.json').read_bytes())
else:raise SystemExit(mode)
