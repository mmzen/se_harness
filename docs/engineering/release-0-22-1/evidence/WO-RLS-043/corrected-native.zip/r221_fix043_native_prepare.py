import r221_session as session
session.OUT=session.WORK/'r221-fix043-20261005'
from r221_session import *
import base64

market=OUT/'plugin026-marketplace'
identity=json.loads((market/'PACKAGE-IDENTITY.json').read_text())
expected=dict(identity['evaluator']);expected['archive_name']=expected['archive']
inputs={h:base64.b64encode((market/'packages'/('verity-plane-'+h+'.zip')).read_bytes()).decode() for h in ('codex','claude')}
inputs.update(marketplace=json.loads((market/'.agents/plugins/marketplace.json').read_text()),expected=expected)
dest=OUT/'plugin026-native-inputs.json';assert not dest.exists();dest.write_text(json.dumps(inputs))
for host in ('codex','claude'):
    source=(WORK/('r221_native_'+host+'.py')).read_text()
    source=source.replace("OUT=WORK/'r221-session-20261004'", "OUT=WORK/'r221-fix043-20261005'")
    source=source.replace('89c69748fcc5fc2578acef5cbf48f0734ef1b732',identity['source']['revision'])
    source=source.replace("prefix='p026n-'", "prefix='p026f-'")
    # Give an actual automatic-compaction provider response enough time; the
    # prior run's 240-second timeout and later successful recovery stay retained.
    if host=='claude': source=source.replace('timeout=240','timeout=480')
    p=WORK/('r221_fix043_native_'+host+'.py');assert not p.exists()
    compile(source,str(p),'exec');p.write_text(source,encoding='utf-8',newline='\n')
    print(json.dumps({'host':host,'probe':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
