"""Disposable native workflow qualification; no product authority or publication."""
from pathlib import Path
import hashlib, importlib.util, json, os, shutil, subprocess, sys, time

WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(WORK/'iar-demo-tools'))
from acceptance_native import Codex, extract_codex, save
from run_demo import child_env
BASE = Path(json.loads((WORK/'iar-demo-tools/prepared-demo.json').read_text())['demo'])
ROOT = Path(r'C:\Users\mathi\AppData\Local\Temp\r221-fix043-flow')
OUT = WORK/'r221-fix043-20261005/native-workflow'
PY = r'C:\Users\mathi\AppData\Local\Python\pythoncore-3.14-64\python.exe'
GIT = r'C:\Program Files\Git\cmd\git.exe'
EXE = r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe'
ENV = child_env(BASE, 'codex')
DATA = Path(ENV['CODEX_HOME'])/'plugins/data/verity-plane-se-harness'
PLUGIN = Path(ENV['CODEX_HOME'])/'plugins/cache/se-harness/verity-plane/0.2.6'
MARKET = WORK/'r221-fix043-20261005/plugin026-marketplace'
REPO = WORK/'r221'

def call(label, argv, cwd=ROOT, env=None, expected=0):
    dest=OUT/(label+'.json'); assert not dest.exists(), dest
    p=subprocess.run([str(a) for a in argv], cwd=cwd, env=env or ENV,
        capture_output=True, text=True, encoding='utf-8', timeout=120)
    save(dest, {'argv':[str(a) for a in argv], 'cwd':str(cwd), 'exit_code':p.returncode,
        'stdout':p.stdout, 'stderr':p.stderr})
    print(json.dumps({'label':label,'exit_code':p.returncode}), flush=True)
    assert p.returncode==expected, p.stdout[-1800:]+p.stderr[-1800:]
    return p.stdout

def prepare():
    ROOT.mkdir(exist_ok=True); OUT.mkdir(exist_ok=True)
    spec=importlib.util.spec_from_file_location('fixture_artifacts', REPO/'tests/artifact_support.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    fixtures={}
    for name,source in [('successor','codex-cloned'),('legacy','old')]:
        repo=ROOT/name
        repo.mkdir()
        wheel=PLUGIN/'packages/se_harness-0.22.1-py3-none-any.whl'
        assert hashlib.sha256(wheel.read_bytes()).hexdigest()=='41aa3f93f126c1f7cbb9efb6b31d5bb3ad755358e37069699d21bfee9be39475'
        version='0.22.1'
        py=DATA/'evaluators'/version/hashlib.sha256(wheel.read_bytes()).hexdigest()/'Scripts/python.exe'
        assert py.is_file()
        args=[py,'-I','-m','se_harness','init',repo,'--project-name','Workflow qualification','--json']
        args+=['--integration','git']
        call(name+'-harness-init',args)
        ident=json.loads((repo/'.engineering-harness.lock').read_text())['evaluator']
        domain=repo/'docs/engineering/product'
        def artifact(aid,typ,folder,links,extra,body,status='approved'):
            text=mod.formal(aid,typ,status,links,extra)
            mod.write(domain/f'{folder}/{aid}.md',text+'\n'+body+'\n')
        artifact('INT-FLW-001','intent','intent',{},'', 'Disposable fixture only. Make small notes available to the fixture reader.')
        artifact('CAP-FLW-001','capability','capabilities',{'derives_from':['INT-FLW-001']},'', 'The fixture reader can read plain-text notes.')
        artifact('REQ-FLW-001','requirement','requirements',{'derives_from':['CAP-FLW-001']},
            'statement = "THE SYSTEM SHALL provide fixture notes with the exact text selected by the work order."\nverification_method = "automated-test"',
            'Accept when the selected note exists and its UTF-8 text matches the work-order acceptance text.')
        artifact('SPEC-FLW-001','specification','specifications',{'specifies':['REQ-FLW-001']},'',
            'Use plain UTF-8 files below notes/. No runtime, network, configuration or authority behavior changes.')
        artifact('ARCH-FLW-001','architecture','architecture',{'addresses':['REQ-FLW-001'],'conforms_to':['SPEC-FLW-001']},
            '[decision_assessment]\noutcome = "no_significant_decision"\ntriggers = []\nrationale = "Disposable plain-text note, no architecture change."\nassessed_by = "technical-owner"',
            'Retain the existing local filesystem layout.')
        artifact('VER-FLW-001','verification','verification',{'verifies':['REQ-FLW-001']},'',
            'Read the selected note as UTF-8 and assert exact equality with its work-order acceptance text. Retain command, output and exit code.')
        paths=['notes/note.txt','docs/engineering/product/work-orders/','docs/engineering/product/evidence/WO-FLW-001/']
        extra='evidence_paths = ["docs/engineering/product/evidence/WO-FLW-001/observations.md"]\n\n[assurance]\ncommit_bound_verification = "not_required"\nrationale = "Disposable explanatory note only, with exact text check; no product behavior or authority change."\ndecided_by = "engineering-owner"\n\n[execution_scope]\npaths = '+json.dumps(paths)
        artifact('WO-FLW-001','work_order','work-orders',{'implements':['REQ-FLW-001'],'specifications':['SPEC-FLW-001'],'architecture':['ARCH-FLW-001'],'verification':['VER-FLW-001']},extra,
            '## Fixture scope\n\nReplace notes/note.txt with exactly `after` followed by one LF. Retain the required check output under the declared evidence directory. The work-orders directory also covers transport of the separately prepared new draft; this grants no approval or implementation authority for that draft.\n\n## Simulated existing approval\n\nThis is synthetic fixture history for WO-RLS-041 qualification, not a real person or a product approval. The test scenario supplies existing approval by engineering-owner for this exact scope and not_required classification. Start, local edits, local commits, checks and completion are included. Push, PR, release and actual external actions are excluded.')
        wo=domain/'work-orders/WO-FLW-001.md'
        history='\n[[lifecycle_events]]\nfrom = "draft"\nto = "approved"\ndecided_at = "2026-09-30T00:00:00Z"\ndecided_by = "engineering-owner"\nreason = "Synthetic fixture approval, not production authority."\nscope_paths = '+json.dumps(paths)+'\n'
        wo.write_text(wo.read_text().replace('\n+++\n',history+'\n+++\n',1),encoding='utf-8',newline='\n')
        mod.write(repo/'notes/note.txt','before')
        mod.write(domain/'evidence/WO-FLW-001/observations.md', '# Fixture preparation\n\nExecution checks are pending.\n')
        if not (repo/'.gitattributes').exists():
            mod.write(repo/'.gitattributes','* -text\n')
        # Remote and commits remain local fixture data. No external push occurs.
        remote=ROOT/(name+'-remote.git')
        call(name+'-remote-init',[GIT,'init','--bare',remote])
        env=ENV.copy();env.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='safe.directory',GIT_CONFIG_VALUE_0=repo.as_posix())
        for label,args in [('init',['init','-b','main']),('config-name',['config','user.name','Fixture Executor']),('config-mail',['config','user.email','fixture@example.invalid']),('config-bytes',['config','core.autocrlf','false']),('remote',['remote','add','origin',str(remote)]),('stage',['add','--all']),('commit',['commit','-m','Synthetic workflow fixture baseline'])]:
            call(name+'-'+label,[GIT,'-C',repo,*args],env=env)
        commit=call(name+'-head',[GIT,'-C',repo,'rev-parse','HEAD'],env=env).strip()
        call(name+'-validate',[py,'-I','-m','se_harness','validate',repo,'--json'],env=env)
        call(name+'-check',[py,'-I','-m','se_harness','check',repo,'--artifact','WO-FLW-001','--json'],env=env)
        call(name+'-preflight',[py,'-I','-m','se_harness','preflight',repo,'--work-order','WO-FLW-001','--phase','start','--json'],env=env)
        fixtures[name]={'repo':str(repo),'python':str(py),'version':ident['version'],'baseline':commit,'destination':str(remote),'head_ref':'refs/heads/workflow-demo','base_ref':'refs/heads/main','synthetic_authority':True}
    save(OUT/'fixtures.json',fixtures)

def install(mode):
    state=OUT/'installed-before.json'
    if mode.startswith('install'):
        prior=json.loads(call('profile-before',[EXE,'plugin','list','--marketplace','se-harness','--json']))['installed']
        assert len(prior)==1;save(state,prior);market=MARKET
    else:
        prior=json.loads(state.read_text());market=prior[0]['marketplaceSource']['source']
    call('plugin-'+mode,[EXE,'-c','marketplaces.se-harness.source='+json.dumps(str(market)),'plugin','add','verity-plane@se-harness','--json'])
    if mode.startswith('install'):
        expected=MARKET/'packages/codex/verity-plane'
        assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashlib.sha256((PLUGIN/p.relative_to(expected)).read_bytes()).hexdigest() for p in expected.rglob('*') if p.is_file())
    else:
        restored=json.loads(call('profile-after',[EXE,'plugin','list','--marketplace','se-harness','--json']))['installed'];assert restored==prior

def native(phase):
    fixtures=json.loads((OUT/'fixtures.json').read_text())
    name='legacy' if phase.startswith('legacy') else 'successor'; f=fixtures[name]
    dest=OUT/phase;dest.mkdir(exist_ok=False)
    manifest={'demo':str(BASE),'host_executables':{'codex':EXE}}
    client=Codex(manifest,dest,review_commands=True)
    hooks=client.rpc('hooks/list',{'cwds':[str(ROOT)]})
    assert all(h['trustStatus']=='trusted' for row in hooks['data'] for h in row['hooks'] if h.get('pluginId')=='verity-plane@se-harness')
    save(dest/'hooks.json',hooks)
    def wait_turn(thread):
        deadline=time.monotonic()+1800
        while time.monotonic()<deadline:
            v=client.receive(max(.1,deadline-time.monotonic()))
            if v.get('method')=='turn/completed' and v.get('params',{}).get('threadId')==thread:
                assert v['params']['turn']['status']=='completed',v['params']['turn'].get('error')
                return
        raise TimeoutError('native walkthrough turn')
    client.wait_turn=wait_turn
    config={'marketplaces.se-harness.source':str(MARKET),'marketplaces.se-harness.source_type':'local','features.multi_agent':False,
        'sandbox_workspace_write.writable_roots':[str(ROOT),str(DATA)]}
    try:
        session=OUT/'session.json'
        if session.exists():
            thread=json.loads(session.read_text())['thread_id']
            client.rpc('thread/resume',{'threadId':thread,'cwd':str(ROOT),'excludeTurns':True,'sandbox':'workspace-write','config':config})
        else:
            result=client.rpc('thread/start',{'cwd':str(ROOT),'sandbox':'workspace-write','config':config})
            thread=result['thread']['id'];save(session,{'thread_id':thread})
        common=f'''Native CLI qualification of WO-RLS-041 in disposable fixtures only. No product checkout edits, real approvals, subagents, credential reads, saved host setting changes, external network actions, pushes or PRs. Host cwd remains {ROOT}. Use the newest plugin instructions and selected evaluator. Use Codex as the actual executor for start and completion. Keep an unconfirmed assurance classification as proposed prose, not a decided machine table. If Windows sandbox launch fails, request exact per-command escalation; the driver reviews commands individually. Do not request persistent rules. The synthetic fixture approvals are deliberate test inputs, not a real person's decision or production authority. Repository: {f['repo']}. Its private evaluator is {f['python']}, invoked with -I -m se_harness, from outside the repository. Use Git {GIT}; if Git safe.directory is needed, use a per-command -c safe.directory for this exact fixture. Fixture baseline {f['baseline']}. Do not alter accepted definitions. '''
        if phase.endswith('proposal'):
            prompt=common+f'''Activate this exact repository through the installed setup skill at {PLUGIN/'skills/setup/SKILL.md'}, using host session ID {thread} and private data {DATA}. Then follow the selected release's authoring procedure to prepare ONE NEW draft work order (do not change WO-FLW-001). Requested outcome: a future fixture reader gets notes/future.txt containing `planned` and one LF. Scope only that note, the new work-order record and its evidence directory. Reuse the existing accepted definitions when applicable. Read the discovered work-order template and authoring checklist. Use create-artifact dry-run then its allocated ID. Complete the draft and validate it. No implementation, approval or lifecycle transition of the new draft. Keep transient planning notes outside the repository. End with created ID/path, governing release, actual checks, and exact next human decision. A template alone is not a completed proposal.'''
        elif phase.endswith('execute'):
            prompt=common+f'''Continue the synthetic already-approved WO-FLW-001 to its permitted local implementation completion. The test's supplied existing approval is exactly the fixture's recorded scope and not_required assurance classification; this grants local execution and commits only. Follow fresh check, required discovered instructions, start/preflight/scope checks, implement notes/note.txt, retain the actual exact-text test result, complete Git-derived handoff and any permitted completion transition. Do not edit the other draft work order or seed definitions. Use baseline {f['baseline']} for the complete implementation diff. The separate new draft was prepared before implementation; account for its preparation separately without hiding actual paths or inventing authority. If that creates a real scope finding, report it and stop the affected action. Make a local candidate commit only for authorized execution paths. Retain the handoff JSON as docs/engineering/product/evidence/WO-FLW-001/handoff.json. Finally inspect the evaluator's next step and the delivery procedure. State exact candidate commit, destination {f['destination']}, proposed head {f['head_ref']} and base {f['base_ref']}, and the required human push/PR authority. Do not publish or claim verification acceptance. Return a concise structured report with evidence paths and blockers.'''
        else:
            prompt=common+Path(sys.argv[2]).read_text(encoding='utf-8')
        prompt+=' Keep the fixture draft concise: fill required content without repeating harness policy or test-host instructions. Reuse unchanged resource instructions already retained in context, but read the newly selected fixture records. These corrected fixtures use domain-coded IDs and have independently passed start preflight. Earlier invalid fixtures and their failures remain retained; do not modify them.'
        # "legacy" is only the second fixture's historical helper label here.
        # It selects 0.22.1 and starts approved; the proposal phase already selects it.
        client.phase=phase
        client.rpc('turn/start',{'threadId':thread,'cwd':str(ROOT),'input':[{'type':'text','text':prompt}]})
        client.wait_turn(thread)
        contexts,replies=extract_codex(client.events)
        save(dest/'report.json',{'phase':phase,'thread_id':thread,'surface':'Codex CLI app-server, desktop unverified','contexts':contexts,'replies':replies,'fixture':f})
        print(json.dumps({'phase':phase,'replies':replies}),flush=True)
    except Exception as exc:
        save(dest/'error.json',{'error':str(exc)});raise
    finally:client.close()

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='prepare':prepare()
    elif mode=='install-first':
        ROOT.mkdir(exist_ok=False); OUT.mkdir(exist_ok=False); install(mode)
    elif mode.startswith(('install','restore')):install(mode)
    else:native(mode)
