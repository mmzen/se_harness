"""Independent assessment of a disposable native draft, including requested scope."""
from pathlib import Path
import hashlib,json,subprocess,sys,tomllib
from r221_session import OUT
host,name,label=sys.argv[1:4]
folder=OUT/('native-workflow' if host=='codex' else 'claude-workflow')
f=json.loads((folder/'fixtures.json').read_text())[name];repo=Path(f['repo'])
path=repo/'docs/engineering/product/work-orders/WO-FLW-002.md'
raw=path.read_bytes();front=tomllib.loads(raw.decode().split('+++',2)[1])
expected={'notes/future.txt','docs/engineering/product/work-orders/WO-FLW-002.md','docs/engineering/product/evidence/WO-FLW-002/'}
checks={'draft':front['status']=='draft','no_lifecycle_decision':not front.get('lifecycle_events'),
 'future_absent':not(repo/'notes/future.txt').exists(),'exact_requested_scope':set(front['execution_scope']['paths'])==expected,
 'no_unconfirmed_machine_assurance':not front.get('assurance')}
dest=folder/(name+'-'+label+'-proposal-assessment.json');assert not dest.exists()
record={'host':host,'fixture':str(repo),'draft_sha256':hashlib.sha256(raw).hexdigest(),'front_matter':front,'checks':checks,'passed':all(checks.values()),
 'claim':'Independent draft-content observation, not a real human approval. Failure remains visible alongside any guided correction.'}
dest.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
