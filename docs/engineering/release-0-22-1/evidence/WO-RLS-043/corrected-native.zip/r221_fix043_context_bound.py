"""Observe exact packaged hook boundaries; adapter replay, not native-host evidence."""
from pathlib import Path
import hashlib,importlib.util,json,os,shutil,subprocess,sys,tempfile,uuid
from r221_session import WORK
OUT=WORK/'r221-fix043-20261005'

prior=json.loads((OUT/'plugin026-native-claude.json').read_text())
plugin=Path(prior['root'])/'package/verity-plane'
data=Path(prior['selection']['data'])
source=Path(prior['selection']['repository'])
hook=plugin/'scripts/inject_instructions.py'
spec=importlib.util.spec_from_file_location('qualified_context_hook',hook)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
session=str(uuid.uuid4())
root=Path(tempfile.mkdtemp(prefix='p026-bound-'))
base=root/'short';base.mkdir()
for name in ('.engineering-harness.toml','.engineering-harness.lock'):
    shutil.copyfile(source/name,base/name)
context=module.session_guidance('claude',session,data)+'\n'+module.repository_context(base,data)
units=len(context.encode('utf-16-le'))//2
record={'claim':'Exact installed adapter subprocess replay only; not an additional native host result.',
    'source_commit':'061307929c94314ccd2beb4a53f174e536fceba8','hook':str(hook),
    'hook_sha256':hashlib.sha256(hook.read_bytes()).hexdigest(),'baseline_units':units,'cases':[]}
dest=OUT/'plugin026-claude-context-bound.json';assert not dest.exists()
env=dict(os.environ,CLAUDE_PLUGIN_DATA=str(data))
for target in (units,10000,10001):
    path=base
    if target!=units:
        delta=target-units;assert delta>1,units
        # One extra path separator plus exact ASCII component lengths.
        while delta>0:
            size=min(100,delta-1);assert size>0
            path=path/('x'*size);delta-=size+1
        path.mkdir(parents=True,exist_ok=True)
        for name in ('.engineering-harness.toml','.engineering-harness.lock'):
            shutil.copyfile(source/name,path/name)
    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in path.iterdir() if p.is_file()}
    event={'hook_event_name':'SessionStart','source':'startup','session_id':session,'cwd':str(path)}
    argv=[sys.executable,'-I',str(hook),'--host','claude']
    result=subprocess.run(argv,input=json.dumps(event),cwd=root,env=env,capture_output=True,text=True,encoding='utf-8',timeout=30)
    delivered=json.loads(result.stdout)['hookSpecificOutput']['additionalContext']
    gap='instruction delivery is unavailable' in delivered
    case={'target_units':target,'path':str(path),'argv':argv,'cwd':str(root),'event':event,
          'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr,
          'delivery_gap':gap,'delivered_units':len(delivered.encode('utf-16-le'))//2,
          'root_files_unchanged':before=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in path.iterdir() if p.is_file()}}
    case['passed']=result.returncode==0 and case['root_files_unchanged'] and (not gap and case['delivered_units']==target if target<=10000 else gap and '10001 UTF-16 units' in delivered and 'no truncated policy was sent' in delivered and '# Engineering Harness' not in delivered)
    record['cases'].append(case)
    dest.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
record['passed']=all(c['passed'] for c in record['cases'])
dest.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'baseline_units':units,'cases':[{k:c[k] for k in ('target_units','delivery_gap','passed')} for c in record['cases']],'passed':record['passed']}))
assert record['passed']
