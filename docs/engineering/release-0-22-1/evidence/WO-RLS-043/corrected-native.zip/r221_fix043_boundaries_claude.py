"""Reuse the existing native probe for independent Claude session boundaries."""
from pathlib import Path
import datetime, hashlib, json, sys

WORK = Path(__file__).resolve().parent
source_path = WORK / 'r221_fix043_native_claude.py'
source = source_path.read_text(encoding='utf-8')
setup = source[:source.index("\ntry:\n    report['version']")]
sys.argv = [str(source_path), 'claude', 'boundaries-20261005']
ns = {'__file__': str(source_path), '__name__': 'claude_boundary_probe'}
exec(compile(setup, str(source_path), 'exec'), ns)
report = ns['report']
report['authorization'] = 'Human mmzen: Approve preparation and review publication. Candidate qualification under WO-RLS-041/VER-RLS-037; no release or adoption.'
report['probe_source_sha256'] = hashlib.sha256(source_path.read_bytes()).hexdigest()
native, run, assess, flush = (ns[k] for k in ('native', 'run', 'assess', 'flush'))
plugin, parent, root, env = (ns[k] for k in ('plugin', 'parent', 'root', 'env'))
repo = None
before = None
try:
    report['version'] = run('host-version', [ns['EXES']['claude']['executable'], '--version']).strip()
    a, ac, _ = native('A-bootstrap', 'What is 2 + 2? Answer briefly without tools.')
    b, bc, _ = native('B-bootstrap', 'What is 3 + 3? Answer briefly without tools.')
    assert a != b
    assert all(any('# Select the working repository' in c for c in contexts) for contexts in (ac, bc))
    declared = ns['re'].findall(r'(?m)^Plugin data: (.+)$', '\n'.join(ac))
    assert len(declared) == 1
    data = Path(declared[0])
    assert data.is_relative_to(Path(env['CLAUDE_CONFIG_DIR']) / 'plugins/data')
    repo, before = ns['prepare_and_activate'](a, data)
    legacy = parent / 'legacy'
    legacy.mkdir()
    old_wheel = WORK / 'plg030-public-inputs/se_harness-0.20.0-py3-none-any.whl'
    report['legacy_wheel_sha256'] = hashlib.sha256(old_wheel.read_bytes()).hexdigest()
    raw = run('prepare-legacy', [sys.executable, '-I', plugin / 'scripts/setup.py', '--target', legacy, '--data-root', data, '--wheel', old_wheel], allowed=(1, 2))
    found = ns['re'].search(r'^Evaluator Python: (.+)$', raw, ns['re'].M)
    assert found
    old_python = Path(found[1].strip())
    run('legacy-init', [old_python, '-I', '-m', 'se_harness', 'init', legacy, '--project-name', 'Legacy parallel fixture', '--json'])
    old_entry = (legacy / 'ENGINEERING_HARNESS.md').read_text(encoding='utf-8')
    old_digest = hashlib.sha256(old_entry.encode()).hexdigest()

    def activate(label, session, target=None):
        argv = [sys.executable, '-I', plugin / 'scripts/activate.py', '--host', 'claude', '--session-id', session, '--data-root', data]
        argv += ['--target', target] if target else ['--clear']
        return json.loads(run(label, argv))

    def turn(label, session, compact=False):
        prompt = '/compact' if compact else 'What is 4 + 4? Answer briefly without tools.'
        _, contexts, events = native(label, prompt, session)
        if compact:
            assert any(e.get('subtype') == 'compact_boundary' and e.get('compact_metadata', {}).get('trigger') == 'manual' for e in events)
        return contexts

    assert activate('B-select-legacy', b, legacy)['status'] == 'available'
    assess(turn('A-current-compaction', a, True))
    contexts = turn('B-legacy-compaction', b, True)
    assert any('Selected release: 0.20.0' in c and str(legacy) in c and old_digest in c and c.endswith(old_entry) for c in contexts)
    assert activate('B-switch-current', b, repo)['status'] == 'available'
    assess(turn('B-current-after-switch', b))
    assess(turn('A-unchanged-after-switch', a))
    activate('B-clear-selection', b)
    assert any('# Select the working repository' in c for c in turn('B-cleared', b))
    assess(turn('A-unchanged-after-clear', a))
    moved = repo.with_name('temporarily-unavailable')
    assert repo.resolve().is_relative_to(root.resolve()) and moved.resolve().is_relative_to(root.resolve()) and not moved.exists()
    repo.rename(moved)
    try:
        contexts = turn('A-missing-checkout', a)
        assert any('delivery is unavailable' in c for c in contexts)
        assert not any('Selected release: 0.20.0' in c for c in contexts)
    finally:
        moved.rename(repo)
    assess(turn('A-restored', a))
    report['passed'] = True
except Exception as exc:
    report['error'] = repr(exc)
finally:
    if repo is not None:
        after = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in repo.iterdir() if p.is_file()}
        report['repository_preserved'] = before == after
        if before != after:
            report['passed'] = False
    report['completed_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    flush()
print(json.dumps({'passed': report['passed'], 'error': report.get('error'), 'report': str(ns['dest'])}), flush=True)
raise SystemExit(0 if report['passed'] else 1)
