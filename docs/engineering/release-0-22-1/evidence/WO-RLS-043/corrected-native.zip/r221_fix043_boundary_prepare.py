from pathlib import Path
w=Path(__file__).resolve().parent
source=(w/'r221_boundaries_codex.py').read_text().replace("OUT=WORK/'r221-session-20261004'","OUT=WORK/'r221-fix043-20261005'")
target=w/'r221_fix043_boundaries_codex.py';assert not target.exists();target.write_text(source)
source=(w/'r221_boundaries_claude.py').read_text().replace('r221_native_claude.py','r221_fix043_native_claude.py').replace('boundaries-20261004','boundaries-20261005')
target=w/'r221_fix043_boundaries_claude.py';assert not target.exists();target.write_text(source)
source=(w/'r221_context_bound.py').read_text().replace('from r221_session import OUT',"from r221_session import WORK\nOUT=WORK/'r221-fix043-20261005'").replace('89c69748fcc5fc2578acef5cbf48f0734ef1b732',(w/'r221-fix043-20261005/candidate-source.txt').read_text().strip())
target=w/'r221_fix043_context_bound.py';assert not target.exists();target.write_text(source)
