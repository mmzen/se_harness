"""Independent readback of native fixture effects; never a production verdict."""
import hashlib,json,subprocess,sys,tomllib
from pathlib import Path
from r221_session import OUT
host,name=sys.argv[1:3]
folder='native-workflow' if host=='codex' else 'claude-workflow'
f=json.loads((OUT/folder/'fixtures.json').read_text())[name]
repo=Path(f['repo']);base=f.get('baseline');remote=f.get('destination',f.get('remote'))
dest=OUT/folder/(name+'-independent-assessment.json');assert not dest.exists()
commands=[]
def git(*args,binary=False):
    argv=['git','-C',str(repo),*args]
    p=subprocess.run(argv,capture_output=True)
    commands.append({'argv':argv,'exit_code':p.returncode,'stdout':p.stdout.decode('utf-8',errors='replace'),'stderr':p.stderr.decode('utf-8',errors='replace')})
    assert p.returncode==0,commands[-1]
    return p.stdout if binary else p.stdout.decode().strip()
def front(path):
    raw=path.read_bytes();text=raw.decode();return tomllib.loads(text.split('+++',2)[1]),hashlib.sha256(raw).hexdigest()
domain=repo/'docs/engineering/product'
wo,wo_digest=front(domain/'work-orders/WO-FLW-001.md')
draft,draft_digest=front(domain/'work-orders/WO-FLW-002.md')
files=git('diff','--name-only',base).splitlines()
paths=['notes/note.txt','docs/engineering/product/work-orders/','docs/engineering/product/evidence/WO-FLW-001/']
accepted={}
for p in domain.rglob('*.md'):
    if not p.read_bytes().startswith(b'+++') or p.parent.name=='work-orders':continue
    rel=p.relative_to(repo).as_posix()
    accepted[rel]=p.read_bytes()==git('show',base+':'+rel,binary=True)
checks={'note_exact':(repo/'notes/note.txt').read_bytes()==b'after\n','future_note_absent':not(repo/'notes/future.txt').exists(),'existing_work_implemented':wo['status']=='implemented','one_start':sum(e['to']=='in_progress' for e in wo.get('lifecycle_events',[]))==1,'one_completion':sum(e['to']=='implemented' for e in wo.get('lifecycle_events',[]))==1,'new_work_draft':draft['status']=='draft','new_work_not_approved':not draft.get('lifecycle_events'),'accepted_definitions_preserved':all(accepted.values()),'complete_diff_in_scope':all(any(p==s or (s.endswith('/') and p.startswith(s)) for s in paths) for p in files),'clean_worktree':not git('status','--porcelain'),'empty_local_remote':not git('ls-remote',remote),'no_verification_or_release_records':not list(domain.rglob('VREC-*.md')) and not list(domain.rglob('RLS-*.md'))}
head=git('rev-parse','HEAD')
record={'host':host,'fixture':f,'candidate':head,'checks':checks,'passed':all(checks.values()),'changed_paths':files,'definition_byte_comparisons':accepted,'work_order_sha256':wo_digest,'draft_sha256':draft_digest,'commands':commands,'claim':'Observed native fixture effects only. Synthetic fixture approval and local bare remote; no product authority or publication.'}
dest.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:record[k] for k in ('host','candidate','checks','passed')}))
assert record['passed']
