import r221_session as session
session.OUT=session.WORK/'r221-fix043-20261005'
from r221_session import *

old=WORK/'r221-session-20261004/claude-workflow'
dest=OUT/'claude-workflow';dest.mkdir(exist_ok=False)
native=json.loads((OUT/'plugin026-native-claude.json').read_text());assert native['passed']
digest=json.loads((OUT/'bundle.json').read_text())['wheel_sha256']
data=Path(native['selection']['data']);py=data/f'evaluators/0.22.1/{digest}/Scripts/python.exe';assert py.is_file()
fixtures=json.loads((old/'fixtures.json').read_text())
for name,f in fixtures.items():
    repo=Path(f['repo'])
    before={p.relative_to(repo).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in repo.rglob('*') if p.is_file() and '.git' not in p.relative_to(repo).parts}
    current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
    assert current==f['baseline'],(name,current)
    for suffix,extra in [('preview',[]),('apply',['--apply'])]:
        run('flow-'+name+'-upgrade-'+suffix,[py,'-I','-m','se_harness','upgrade',repo,*extra,'--json'])
    after={p.relative_to(repo).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in repo.rglob('*') if p.is_file() and '.git' not in p.relative_to(repo).parts}
    assert set(before)==set(after)
    changed=[p for p in before if before[p]!=after[p]]
    assert changed==['.engineering-harness.lock'],changed
    run('flow-'+name+'-stage',['git','add','--','.engineering-harness.lock'],cwd=repo)
    run('flow-'+name+'-commit',['git','commit','-m','Select corrected wheel in disposable qualification fixture'],cwd=repo)
    new=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
    assert subprocess.check_output(['git','diff','--name-only',current,new],cwd=repo,text=True).strip()=='.engineering-harness.lock'
    f.update(prior_baseline=current,baseline=new,baseline_preparation='Only the supported upgrade lock change is committed as disposable test setup. No formal artifact, draft declaration or note was changed. This is not a production comparison-base change.',before=before,after=after)
    run('flow-'+name+'-validate',[py,'-I','-m','se_harness','validate',repo,'--json'])
(dest/'fixtures.json').write_text(json.dumps(fixtures,indent=2)+'\n')
(dest/'session.json').write_bytes((old/'session.json').read_bytes())
source=(WORK/'r221_claude_workflow.py').read_text()
source=source.replace('from r221_session import WORK,OUT', "from r221_session import WORK\nOUT=WORK/'r221-fix043-20261005'")
source=source.replace('0a9f87f235839689dbbca3b10013b5df2a71dc134b53795248f78de8e1cfec49',digest)
source=source.replace("common=f'''", "common=f'''The native transition defect was corrected under WO-RLS-043. This continuation selects the rebuilt candidate, preserving the original failed draft and all its declared absent evidence. The test fixture baseline includes only the supported wheel-selection lock update; prior baseline and exact diff are retained by the parent test driver. Use Claude as the actual executor, not delegated-executor. ")
target=WORK/'r221_fix043_claude_workflow.py';assert not target.exists();compile(source,str(target),'exec');target.write_text(source,encoding='utf-8')
review=(WORK/'r221_walk_review.py').read_text().replace("OUT=WORK/'r221-session-20261004'", "OUT=WORK/'r221-fix043-20261005'")
# The existing review helper imports OUT; replace that import instead if present.
review=review.replace('from r221_session import WORK,OUT', "from r221_session import WORK\nOUT=WORK/'r221-fix043-20261005'")
target=WORK/'r221_fix043_walk_review.py';assert not target.exists();target.write_text(review,encoding='utf-8')
print(json.dumps({'fixtures':str(dest/'fixtures.json'),'driver':str(WORK/'r221_fix043_claude_workflow.py'),'candidate_wheel':digest}))
