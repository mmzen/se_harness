"""Actual Claude CLI workflow tests with individual tool approval, in disposable fixtures."""
from pathlib import Path
import datetime,hashlib,io,json,os,queue,subprocess,sys,threading,time,zipfile
from r221_session import WORK
OUT=WORK/'r221-fix043-20261005'
sys.path.insert(0,str(WORK/'iar-demo-tools'))
from run_demo import child_env

BASE=Path(json.loads((WORK/'iar-demo-tools/prepared-demo.json').read_text())['demo'])
ENV=child_env(BASE,'claude')
PRIOR=json.loads((OUT/'plugin026-native-claude.json').read_text())
PLUGIN=Path(PRIOR['root'])/'package/verity-plane'
DATA=Path(PRIOR['selection']['data'])
PY=DATA/'evaluators/0.22.1/41aa3f93f126c1f7cbb9efb6b31d5bb3ad755358e37069699d21bfee9be39475/Scripts/python.exe'
ROOT=Path(r'C:\Users\mathi\AppData\Local\Temp\r221-claude-flow')
DEST=OUT/'claude-workflow'
EXE=r'C:\Users\mathi\.local\bin\claude.exe'
GIT=r'C:\Program Files\Git\cmd\git.exe'
mode=sys.argv[1]

def save(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def call(label,args):
    r=subprocess.run(list(map(str,args)),cwd=ROOT,env=ENV,capture_output=True,text=True,encoding='utf-8',timeout=120)
    save(DEST/(label+'.json'),{'argv':list(map(str,args)),'cwd':str(ROOT),'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    assert r.returncode==0,(label,r.stdout[-1000:],r.stderr[-1000:])
    return r.stdout

if mode=='prepare':
    assert PY.is_file()
    ROOT.mkdir(exist_ok=False);DEST.mkdir(exist_ok=False)
    source=json.loads((OUT/'native-workflow/fixtures.json').read_text())['successor']
    fixtures={}
    for name in ('one','two'):
        repo=ROOT/name;repo.mkdir()
        args=[GIT,'-C',source['repo'],'archive','--format=zip',source['baseline']]
        result=subprocess.run(args,capture_output=True,check=True)
        with zipfile.ZipFile(io.BytesIO(result.stdout)) as z:
            assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
            z.extractall(repo)
        remote=ROOT/(name+'-remote.git')
        call(name+'-remote',[GIT,'init','--bare',remote])
        for label,a in [('init',['init','-b','main']),('name',['config','user.name','Fixture Executor']),('email',['config','user.email','fixture@example.invalid']),('bytes',['config','core.autocrlf','false']),('remote',['remote','add','origin',str(remote)]),('add',['add','.']),('commit',['commit','-m','Synthetic native Claude workflow fixture'])]:
            call(name+'-'+label,[GIT,'-C',repo,*a])
        baseline=call(name+'-head',[GIT,'-C',repo,'rev-parse','HEAD']).strip()
        call(name+'-validate',[PY,'-I','-m','se_harness','validate',repo,'--json'])
        fixtures[name]={'repo':str(repo),'baseline':baseline,'remote':str(remote),'source_baseline':source['baseline'],'archive_sha256':hashlib.sha256(result.stdout).hexdigest()}
    save(DEST/'fixtures.json',fixtures)
    print('Two independently validated synthetic fixtures prepared.')
    sys.exit()

phase=DEST/mode;phase.mkdir(exist_ok=False)
f=json.loads((DEST/'fixtures.json').read_text())['two' if mode.startswith('two') else 'one']
common=f'''The native transition defect was corrected under WO-RLS-043. This continuation selects the rebuilt candidate, preserving the original failed draft and all its declared absent evidence. The test fixture baseline includes only the supported wheel-selection lock update; prior baseline and exact diff are retained by the parent test driver. Use Claude as the actual executor, not delegated-executor. This is authorized native CLI qualification in a disposable fixture. No production repository edits, credentials, network actions, pushes, PRs, subagents, real human decisions or saved host settings. Cwd stays {ROOT}. Activate {f['repo']} using the installed plugin setup skill at {PLUGIN/'skills/setup/SKILL.md'} and the actual host session ID delivered by your hook; data {DATA}. Select its isolated candidate evaluator {PY}, invoked with -I -m se_harness from outside the checkout. Its existing WO-FLW-001 contains synthetic approval for local execution/commits only, with not_required assurance. This synthetic history is test input, never production authority. Preserve accepted definitions. Git is {GIT}; any safe.directory override must be per-command for this fixture. Baseline {f['baseline']}, local bare destination {f['remote']}, proposed head refs/heads/workflow-demo, base refs/heads/main. All tool permission requests are individually reviewed by the test driver. '''
if mode.endswith('refine'):
    prompt=common+'''Independent review found two issues in the existing unapproved WO-FLW-002: its work-orders/ prefix exceeds the requested single-record scope, and its proposed not_required classification does not match the installed rule for a new content change. Refine only this existing draft. Read the governing authoring instructions, use its exact record path, remove the unconfirmed machine assurance table and place a proposed required classification with rationale in prose for the human to decide. Preserve the absence of future.txt and all accepted records. Validate and report the actual results. Do not create another work order or invent a human decision. This guided correction is retained alongside the original attempt.'''
elif mode.endswith('proposal'):
    prompt=common+'''Follow the discovered authoring procedure to prepare ONE new draft work order for notes/future.txt with exact UTF-8 text planned followed by one LF. Scope only the note, its new work-order record and own evidence directory. Read the required template/checklist and governing fixture definitions. Use create-artifact dry-run and its returned ID. Complete and validate the draft, leaving it unapproved and future.txt absent. No invented assurance decision. Keep transient notes outside the repository. Report the actual release, ID/path, checks and next human decision.'''
else:
    prompt=common+'''Follow fresh check and the selected procedure to start and locally complete existing approved WO-FLW-001. Read required governing records; implement only notes/note.txt with after and one LF. Retain actual exact-byte verification and Git-derived handoff under docs/engineering/product/evidence/WO-FLW-001/, perform permitted completion, and make an authorized local commit. Include all changed paths against the supplied baseline; the existing work order permits transport of the separate draft without approving it. Preserve that draft. Do not invent scope or bypass gates. Inspect the delivery procedure and report the exact commit, destination, refs and required human publication authority. Stop before any push/PR. If blocked, retain and report the exact failure.'''
if mode.endswith('cycle'):
    prompt=common+'''First repeat the new-work proposal in this second checkout: use the selected authoring procedure and create-artifact preview to create ONE new draft for notes/future.txt with exact UTF-8 planned plus one LF. Limit proposed paths to that note, the exact new record and its own evidence directory. Reuse the retained authoring guidance where current. Keep any unconfirmed assurance classification as a proposal in prose, not a decided table. Validate it and leave it draft with future.txt absent. Then continue the separate already-approved WO-FLW-001 as follows. '''+prompt[len(common):]
# Native SDK permission callback transport, matching Anthropic's published SDK.
# https://github.com/anthropics/claude-agent-sdk-python/blob/main/src/claude_agent_sdk/types.py
argv=[EXE,'--print','--verbose','--input-format','stream-json','--output-format','stream-json','--include-hook-events','--tools','Read,Glob,Grep,Bash,PowerShell,Edit,Write','--strict-mcp-config','--permission-mode','manual','--permission-prompts','host','--permission-prompt-tool','stdio','--setting-sources','project','--settings','{}','--plugin-dir',str(PLUGIN),'--model','sonnet']
session=DEST/'session.json'
if session.exists():argv+=['--resume',json.loads(session.read_text())['session_id']]
save(phase/'invocation.json',{'argv':argv,'cwd':str(ROOT),'prompt':prompt,'fixture':f,'package_source':str(PLUGIN),'claim':'Actual Claude CLI only, desktop unverified.'})
p=subprocess.Popen(argv,cwd=ROOT,env=ENV,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',bufsize=1)
q=queue.Queue();err=[];replies=[]
def reader():
    for line in p.stdout:
        try:q.put(json.loads(line))
        except ValueError:q.put({'type':'capture_error','message':'Non-JSON native output'})
    q.put({'type':'eof'})
threading.Thread(target=reader,daemon=True).start()
threading.Thread(target=lambda:err.extend(p.stderr),daemon=True).start()
def send(value):p.stdin.write(json.dumps(value)+'\n');p.stdin.flush()
try:
    send({'type':'control_request','request_id':'qualification-initialize','request':{'subtype':'initialize','hooks':None}})
    init_deadline=time.monotonic()+60
    while time.monotonic()<init_deadline:
        e=q.get(timeout=max(.1,init_deadline-time.monotonic()))
        with (phase/'native-events.jsonl').open('a',encoding='utf-8') as out:out.write(json.dumps(e,ensure_ascii=False)+'\n')
        if e.get('type')=='control_response' and e.get('response',{}).get('request_id')=='qualification-initialize':
            assert e['response']['subtype']=='success',e
            break
        assert e.get('type')!='eof','Native initialization closed'
    else:raise TimeoutError('Native permission transport initialization')
    send({'type':'user','message':{'role':'user','content':prompt},'parent_tool_use_id':None})
    deadline=time.monotonic()+1800
    while time.monotonic()<deadline:
        e=q.get(timeout=max(.1,deadline-time.monotonic()))
        if e.get('type')=='eof':raise RuntimeError('Native stream closed before result')
        if e.get('session_id'):save(session,{'session_id':e['session_id']})
        if e.get('type')=='assistant':
            e['message']['content']=[x for x in e['message'].get('content',[]) if x.get('type') in ('text','tool_use')]
            replies += [x['text'] for x in e['message']['content'] if x.get('type')=='text']
        with (phase/'native-events.jsonl').open('a',encoding='utf-8') as out:out.write(json.dumps(e,ensure_ascii=False)+'\n')
        if e.get('type')=='control_request':
            digest=hashlib.sha256(json.dumps(e,sort_keys=True).encode()).hexdigest()
            save(phase/'pending-command.json',{'sha256':digest,'request':e})
            print('Native tool review needed: '+str(phase/'pending-command.json'),flush=True)
            decisionfile=phase/(digest+'.decision.json');until=time.monotonic()+300
            while not decisionfile.exists() and time.monotonic()<until:time.sleep(.2)
            if not decisionfile.exists():raise TimeoutError('Specific tool review')
            d=json.loads(decisionfile.read_text());assert d['sha256']==digest and d['decision'] in ('accept','decline')
            req=e['request'];assert req['subtype']=='can_use_tool',req['subtype']
            response={'behavior':'allow','updatedInput':req['input']} if d['decision']=='accept' else {'behavior':'deny','message':d['reason']}
            send({'type':'control_response','response':{'subtype':'success','request_id':e['request_id'],'response':response}})
            (phase/'pending-command.json').unlink()
        if e.get('type')=='result':
            save(phase/'report.json',{'result':e,'replies':replies});print(json.dumps({'result':e,'replies':replies}),flush=True)
            assert not e.get('is_error'),e
            break
    else:raise TimeoutError('Native workflow phase')
except Exception as exc:
    save(phase/'error.json',{'error':str(exc)});raise
finally:
    p.stdin.close()
    try:p.wait(timeout=15)
    except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=15)
    save(phase/'stderr.json',{'stderr':''.join(err),'exit_code':p.returncode})
