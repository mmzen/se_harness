import datetime
import hashlib
import json
import subprocess
import sys
from r221_session import REPO, OUT, DOMAIN, gov

HEAD = 'dbc0144e3830087f1d4c267e76322f6d0e92edf4'
FILES = ['work-orders/WO-RLS-043.md', 'verification/VER-RLS-004.md']
REQUEST = ('Approve WO-RLS-043 and VER-RLS-004 with required commit-bound verification, and explicitly authorize the manual linked amendment of REL-SEH-035 shown in PR #536? Covers the two-file transition correction, requalification, preservation of accepted release-contract bytes/history, and updates to the same review PR. Evaluator lacks supported amendment command. Human verification, merge, release, and acceptance of missing desktop/provider evidence remain separate.')
REASON = ('mmzen replied "I aaprove" to the exact correction and manual linked amendment request reviewed at '+HEAD+'. '+REQUEST+' This includes bounded review updates from codex/release-0-22-1 to mmzen/se_harness:main in draft PR #536. Only confirmed assurance metadata is added to the reviewed drafts before approval.')
def sha(b): return hashlib.sha256(b).hexdigest()
def save(path, data):
    assert not path.exists(), path
    path.write_text(json.dumps(data, indent=2)+'\n', encoding='utf-8')
def args():
    result=['transition']
    for ident in ['VER-RLS-004', 'WO-RLS-043']:
        result += ['--set', ident+'=approved', '--decision', ident+'=mmzen', '--reason', ident+'='+REASON]
    return result

if sys.argv[1] == 'preview':
    reviewed = {}
    for rel in FILES:
        p=REPO/DOMAIN/rel
        blob=subprocess.check_output(['git','show',HEAD+':'+DOMAIN+rel],cwd=REPO)
        # Git checkout CRLF is an encoding conversion; bind complete working bytes too.
        assert p.read_bytes().replace(b'\r\n', b'\n')==blob.replace(b'\r\n', b'\n'), rel
        reviewed[rel]={'git_blob_sha256':sha(blob),'working_sha256':sha(p.read_bytes())}
    p=REPO/DOMAIN/FILES[0]
    raw=p.read_bytes()
    assert b'[assurance]' not in raw
    newline=b'\r\n' if b'\r\n' in raw else b'\n'
    addition=newline.join([b'[assurance]',b'commit_bound_verification = "required"', b'rationale = "mmzen confirmed required commit-bound verification for the transition correction and changed release qualification."',b'decided_by = "mmzen"',b'',b'[execution_scope]'])
    p.write_bytes(raw.replace(b'[execution_scope]',addition,1))
    save(OUT/'fix043-approval-bindings.json',{'reviewed':reviewed,'inputs':{rel:sha((REPO/DOMAIN/rel).read_bytes()) for rel in FILES},'request':REQUEST,'response':'I aaprove','actor':'mmzen','review_commit':HEAD})
    gov('fix043-approval-preview',*args())
elif sys.argv[1] == 'apply':
    data=json.loads((OUT/'fix043-approval-bindings.json').read_text())
    for rel,digest in data['inputs'].items(): assert sha((REPO/DOMAIN/rel).read_bytes())==digest,rel
    gov('fix043-approval-apply',*args(),'--apply')
elif sys.argv[1] == 'amend':
    rel=REPO/DOMAIN/'releases/REL-SEH-035.md'
    if not rel.exists():
        matches=list((REPO/DOMAIN).rglob('REL-SEH-035.md'))
        assert len(matches)==1,matches
        rel=matches[0]
    before=rel.read_bytes()
    proposed=(OUT/'REL-SEH-035-proposed.md').read_bytes()
    assert sha(before)=='7249aa639db1cc412849fa2a54e8fe6135a8813fb4e9031295f1d1cebaa0ea4f'
    assert before==(OUT/'REL-SEH-035-before.txt').read_bytes()
    assert sha(proposed)=='c0c20d24e58b322d9304f52c830ea20022a6974122b78cf632a0abd2be0c9a99'
    dest=REPO/DOMAIN/'evidence/WO-RLS-043'
    dest.mkdir(exist_ok=True)
    prior=dest/'REL-SEH-035-accepted-before.txt'
    assert not prior.exists()
    prior.write_bytes(before)
    save(dest/'amendment.json',{'actor':'mmzen','response':'I aaprove','request':REQUEST,'review_commit':HEAD,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'mechanism':'Explicitly authorized manual linked amendment; released 0.22.0 has no supported revision command. Existing lifecycle history is preserved; no lifecycle event is invented.','path':rel.relative_to(REPO).as_posix(),'previous_path':prior.relative_to(REPO).as_posix(),'previous_sha256':sha(before),'replacement_sha256':sha(proposed)})
    rel.write_bytes(proposed)
    assert sha(rel.read_bytes())==sha(proposed)
    print(json.dumps({'amendment':str(rel),'sha256':sha(proposed),'previous':str(prior)}))
