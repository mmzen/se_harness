"""Qualification helpers for the corrected candidate; outside product checkout."""
from pathlib import Path
import sys
import r221_session as s
s.OUT=s.WORK/'r221-fix043-20261005'
mode=sys.argv[1]
if mode=='prepare-codex-driver':
    source=(s.WORK/'r221_native_workflow.py').read_text()
    source=source.replace('Temp\\r221-flow', 'Temp\\r221-fix043-flow')
    source=source.replace('r221-session-20261004/native-workflow','r221-fix043-20261005/native-workflow')
    source=source.replace('r221-session-20261004/plugin026-marketplace','r221-fix043-20261005/plugin026-marketplace')
    source=source.replace('0a9f87f235839689dbbca3b10013b5df2a71dc134b53795248f78de8e1cfec49','41aa3f93f126c1f7cbb9efb6b31d5bb3ad755358e37069699d21bfee9be39475')
    source=source.replace('If Windows sandbox launch fails,', 'Use Codex as the actual executor for start and completion. Keep an unconfirmed assurance classification as proposed prose, not a decided machine table. If Windows sandbox launch fails,')
    p=s.WORK/'r221_fix043_codex_workflow.py'
    assert not p.exists()
    p.write_text(source,encoding='utf-8')
elif mode in ('assess','proposal'):
    sys.argv=['assessment',*sys.argv[2:]]
    p=s.WORK/('r221_workflow_assess.py' if mode=='assess' else 'r221_proposal_assess.py')
    exec(compile(p.read_text(),str(p),'exec'))
elif mode=='topology':
    p=s.WORK/'r221_topology.py'
    exec(compile(p.read_text(),str(p),'exec'))
elif mode=='ci':
    for rid in ('37252125966','37252126010','37252126041','37252124049','37252126357','37252846313'):
        s.run('ci-final-'+rid,['gh','run','view',rid,'--repo','mmzen/se_harness','--json','status,conclusion,headSha,jobs,url,event,workflowName'])
    s.run('pr-ci-final',['gh','pr','view','536','--repo','mmzen/se_harness','--json','state,isDraft,headRefOid,baseRefName,statusCheckRollup,url'])
else:
    raise SystemExit(mode)
