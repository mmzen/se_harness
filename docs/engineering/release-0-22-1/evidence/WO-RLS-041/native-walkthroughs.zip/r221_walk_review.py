"""One exact native-test command review; no persistent permission rule."""
import json,sys
from pathlib import Path
base=Path(__file__).parent/'r221-session-20261004'
root=base/'claude-workflow'/sys.argv[1].split(':',1)[1] if sys.argv[1].startswith('claude:') else base/'native-workflow'/sys.argv[1]
p=json.loads((root/'pending-command.json').read_text())
assert p['sha256']==sys.argv[2]
out=root/(p['sha256']+'.decision.json')
assert not out.exists()
decision=sys.argv[4] if len(sys.argv)>4 else 'accept'
assert decision in ('accept','decline')
out.write_text(json.dumps({'sha256':p['sha256'],'decision':decision,'reason':sys.argv[3]},indent=2)+'\n',encoding='utf-8')
print(decision+' for the individually reviewed native test command.')
