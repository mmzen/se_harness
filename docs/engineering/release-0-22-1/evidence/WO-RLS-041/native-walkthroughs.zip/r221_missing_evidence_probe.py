"""Reproduce candidate refusal without transitions, editing test inputs or governing source."""
from pathlib import Path
import hashlib,json,platform,shutil,subprocess,sys,tempfile

source=Path(sys.argv[1]);dest=Path(sys.argv[2]);assert not dest.exists()
root=Path(tempfile.mkdtemp(prefix='r221-missing-'));repo=root/'repository'
shutil.copytree(source,repo,ignore=shutil.ignore_patterns('.git'))
def snapshot():
    return {p.relative_to(repo).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in repo.rglob('*') if p.is_file()}
before=snapshot();rows=[]
for args in [('identity',),('validate',str(repo)),('preflight',str(repo),'--work-order','WO-FLW-001','--phase','start'),('transition',str(repo),'--set','WO-FLW-001=in_progress','--decision','WO-FLW-001=Claude')]:
    argv=[sys.executable,'-I','-m','se_harness',*args,'--json']
    p=subprocess.run(argv,cwd=root,capture_output=True,text=True,encoding='utf-8',timeout=90)
    rows.append({'argv':argv,'cwd':str(root),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
after=snapshot()
record={'platform':platform.platform(),'python':sys.version,'source_fixture':str(source),'fixture':str(repo),
 'candidate_source':'89c69748fcc5fc2578acef5cbf48f0734ef1b732',
 'expected_wheel_sha256':'0a9f87f235839689dbbca3b10013b5df2a71dc134b53795248f78de8e1cfec49',
 'commands':rows,'before_sha256':before,'after_sha256':after,'all_files_unchanged':before==after,
 'draft_evidence_absent':not(repo/'docs/engineering/product/evidence/WO-FLW-002/observations.md').exists(),
 'defect_reproduced':rows[1]['exit_code']==0 and rows[2]['exit_code']==0 and rows[3]['exit_code']==1 and 'FileNotFoundError' in rows[3]['stderr'] and 'WO-FLW-002' in rows[3]['stderr'],
 'claim':'Actual installed-candidate preview failure; no apply or synthesized evidence. Not a passing qualification result.'}
dest.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:record[k] for k in ('platform','all_files_unchanged','draft_evidence_absent','defect_reproduced')}))
assert record['defect_reproduced'] and record['all_files_unchanged']
