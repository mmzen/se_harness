"""Apply only mmzen's actual bounded desktop omission decision."""
import hashlib,json,sys
import r221_session as s
s.OUT=s.WORK/'r221-continue-20261005'
review=json.loads((s.OUT/'desktop-proposal-reviewed.json').read_text())
reason='Human mmzen: "Accept the bounded desktop omission and risk". This answers the reviewed DEC-RLS-009/RISK-RLS-007 proposal for evaluator 0.22.1 and plugin 0.2.6 only. Continue qualification with Codex Windows desktop not run/unverified and its residual risk accepted. Retain all CLI, public-installation, commit-bound verification and release controls; no verification, merge, release or adoption is authorized. Reviewed decision SHA-256 '+review['decision_sha256']+'; reviewed risk SHA-256 '+review['risk_sha256']+'.'
args=['decide','--artifact','DEC-RLS-009','--option','accept','--decision','mmzen','--reason',reason,
    '--revisit','Before the next plugin release or before claiming Codex Windows desktop verified, whichever occurs first. Changed product scope or versions require renewed review.']
mode=sys.argv[1]
if mode in ('preview','apply'):
    for kind,subdir in [('decision','decisions'),('risk','risks')]:
        p=s.REPO/s.DOMAIN/subdir/(review[kind+'_id']+'.md')
        assert hashlib.sha256(p.read_bytes()).hexdigest()==review[kind+'_sha256']
    if mode=='apply':
        envelope=json.loads((s.OUT/'desktop-accept-preview.json').read_text())
        prior=json.loads(envelope['stdout'])
        assert '--apply' not in envelope['argv'] and envelope['exit_code']==0
        assert prior['operation']['outcome']=='completed'
        assert not prior['findings']['scoped_blockers'] and not prior['findings']['repository_blockers']
        assert prior['state']['after']==[{'id':'DEC-RLS-009','status':'decided'},{'id':'RISK-RLS-007','status':'accepted'}]
        assert {v['id'] for v in prior['mutation']['writes']}=={'DEC-RLS-009','RISK-RLS-007'}
    s.gov('desktop-accept-'+mode,*args,*(['--apply'] if mode=='apply' else []))
elif mode=='readback':
    s.gov('desktop-accepted-context','check','--artifact','DEC-RLS-009')
    s.gov('desktop-accepted-validation','validate')
    s.gov('desktop-accepted-wo041','check','--artifact','WO-RLS-041')
else:raise SystemExit(mode)
