"""Prepare only the requested desktop qualification deviation, not acceptance."""
import hashlib,json,sys,zipfile
import r221_session as s
s.OUT=s.WORK/'r221-continue-20261005'
args=['raise-risk','--domain','release-0-22-1',
    '--title','Unverified Codex Windows desktop for plugin 0.2.6',
    '--description','Codex Windows desktop instruction delivery and recovery have not been tested for plugin 0.2.6. Passing Codex and Claude CLI tests do not exclude a desktop-specific delivery or selection defect. mmzen cannot access the workstation and requested a deferral proposal for review; no omission has been accepted.',
    '--action','Keep Codex Windows desktop unverified in the release review and support claims. Obtain mmzen\'s explicit decision on this release-only omission. Qualify desktop before the next plugin release or before any verified-desktop claim, whichever occurs first.',
    '--owner','mmzen','--threatens','WO-RLS-041','--with-decision']
mode=sys.argv[1]
if mode=='preview':
    data,_=s.gov('desktop-risk-preview',*args,'--dry-run')
    print(json.dumps(data,indent=2))
elif mode=='create':
    data,_=s.gov('desktop-risk-create',*args)
    print(json.dumps(data,indent=2))
elif mode=='validate':
    s.gov('desktop-proposal-validation','validate')
    s.gov('desktop-proposal-decision-context','check','--artifact','DEC-RLS-009')
    review=s.REPO/s.DOMAIN/'evidence/WO-RLS-041/desktop-deferral-review.md'
    d=s.REPO/s.DOMAIN/'decisions/DEC-RLS-009.md'
    r=s.REPO/s.DOMAIN/'risks/RISK-RLS-007.md'
    binding={'decision_id':'DEC-RLS-009','decision_sha256':hashlib.sha256(d.read_bytes()).hexdigest(),
        'risk_id':'RISK-RLS-007','risk_sha256':hashlib.sha256(r.read_bytes()).hexdigest(),
        'review_sha256':hashlib.sha256(review.read_bytes()).hexdigest(),
        'request':'Accept DEC-RLS-009 and RISK-RLS-007 for evaluator 0.22.1/plugin 0.2.6 only: continue qualification with Codex Windows desktop not run/unverified and its residual risk accepted; retain all CLI, public installation, verification and release checks; revisit before the next plugin release or any verified-desktop claim, whichever occurs first.'}
    p=s.OUT/'desktop-proposal-reviewed.json';assert not p.exists();p.write_text(json.dumps(binding,indent=2)+'\n')
    files=sorted(s.OUT.glob('activation-*.json'))+[s.OUT/'provider-context.json',s.OUT/'provider-preaction.json',s.WORK/'r221_provider_activation.py']
    target=s.REPO/s.DOMAIN/'evidence/WO-RLS-040/provider-activation-observations.zip';assert not target.exists()
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in files:z.writestr(p.name,p.read_bytes())
    target=s.REPO/s.DOMAIN/'evidence/WO-RLS-041/desktop-proposal-preparation.zip';assert not target.exists()
    files=sorted(s.OUT.glob('desktop-*.json'))+[s.WORK/'r221_desktop_proposal.py']
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in files:z.writestr(p.name,p.read_bytes())
    print(json.dumps(binding,indent=2))
else:raise SystemExit(mode)
