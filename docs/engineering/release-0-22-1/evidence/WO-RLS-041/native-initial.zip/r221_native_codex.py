"""Temporary exact-wheel native probes; only disposable profiles and fixtures."""
from pathlib import Path
import sys,json,subprocess,hashlib,os,base64,zipfile,io,tempfile,re,datetime
WORK=Path(__file__).resolve().parent
OUT=WORK/'r221-session-20261004'
sys.path.insert(0,str(WORK/'iar-demo-tools'))
from run_demo import child_env
from acceptance_native import Codex,extract_codex,save
BASE=Path(json.loads((WORK/'iar-demo-tools/prepared-demo.json').read_text())['demo'])
EXES={'codex':{'executable':r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe'},'claude':{'executable':r'C:\Users\mathi\.local\bin\claude.exe'}}
EXES['codex']['executable']=r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe'
mode=sys.argv[1]
report={'host':mode,'claims':'Native CLI/app-server only; desktop remains unverified.','commands':[],'stages':[],'passed':False}
dest=OUT/('plugin026-trusted-native-'+mode+(('-'+sys.argv[2]) if len(sys.argv)>2 else '')+'.json');assert not dest.exists()
env=child_env(BASE,mode)
root=Path(tempfile.mkdtemp(prefix='p026n-'));parent=root/'w';parent.mkdir()
report['root']=str(root)
inputs=json.loads((OUT/'plugin026-native-inputs.json').read_text());expected=inputs['expected']
package=root/'package'
with zipfile.ZipFile(io.BytesIO(base64.b64decode(inputs[mode]))) as z:
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
    z.extractall(package)
plugin=package/'verity-plane';wheel=plugin/'packages'/expected['archive_name']
assert hashlib.sha256(wheel.read_bytes()).hexdigest()==expected['archive_sha256']
with zipfile.ZipFile(wheel) as z:
    n=next(n for n in z.namelist() if n.endswith('/ENGINEERING_HARNESS.md.tpl'))
    entry=z.read(n).decode().replace('{{PROJECT_NAME}}','Plugin qualification').replace('{{HARNESS_VERSION}}',expected['version'])
digest=hashlib.sha256(entry.encode()).hexdigest();report['entry_sha256']=digest;report['wheel']=expected
report['package_files']={p.relative_to(plugin).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in plugin.rglob('*') if p.is_file()}
def flush():save(dest,report)
def run(label,argv,allowed=(0,),use_env=env):
    argv=list(map(str,argv));r=subprocess.run(argv,cwd=parent,env=use_env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180)
    report['commands'].append({'label':label,'argv':argv,'cwd':str(parent),'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});flush()
    assert r.returncode in allowed,(label,r.stdout[-1200:],r.stderr[-1200:])
    return r.stdout
def assess(contexts):
    assert any(c.endswith(entry) and digest in c for c in contexts),[c[:180] for c in contexts]
def prepare_and_activate(session,data):
    remote=root/'source';remote.mkdir()
    raw=run('prepare-exact-evaluator',[sys.executable,'-I',plugin/'scripts/setup.py','--target',remote,'--data-root',data,'--wheel',wheel],allowed=(1,2))
    found=re.search(r'^Evaluator Python: (.+)$',raw,re.M);assert found
    py=Path(found[1].strip())
    run('fixture-init',[py,'-I','-m','se_harness','init',remote,'--project-name','Plugin qualification','--integration','git','--json'])
    for args in [['init'],['add','.'],['-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','-m','Disposable exact-wheel selection']]:
        run('fixture-git',['git','-C',remote,*args])
    repo=parent/'clone'
    run('clone-after-startup',['git','clone',remote,repo]);assert not (repo/'ENGINEERING_HARNESS.md').exists()
    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in repo.iterdir() if p.is_file()}
    activation=json.loads(run('activate-observed-session',[sys.executable,'-I',plugin/'scripts/activate.py','--host',mode,'--session-id',session,'--data-root',data,'--target',repo]))
    assert activation['status']=='available';assess([activation['content']])
    report['selection']={'session_id':session,'data':str(data),'repository':str(repo),'before':before}
    return repo,before
probe='Read-only native instruction delivery test. Do not call tools. Copy only the newest hook context as JSON: session_id, selected_checkout, harness_version, entry_sha256, final_heading, bootstrap, delivery_gap, may_implement=false. Delivery grants no lifecycle authority.'
if mode=='claude':
    probe='This is a connectivity check. Do not use tools. Reply with PROBE_COMPLETE.'
client=None;restore=None
try:
    report['version']=run('host-version',[EXES[mode]['executable'],'--version']).strip()
    if mode=='codex':
        exe=EXES[mode]['executable']
        installed=json.loads(run('installed-before',[exe,'plugin','list','--marketplace','se-harness','--json']))['installed']
        assert len(installed)==1 and installed[0]['pluginId']=='verity-plane@se-harness'
        restore=installed[0]['marketplaceSource']['source'];report['restore_marketplace']=restore
        market=root/'marketplace';(market/'.agents/plugins').mkdir(parents=True)
        import shutil
        shutil.copytree(plugin,market/'packages/codex/verity-plane')
        save(market/'.agents/plugins/marketplace.json',inputs['marketplace'])
        run('install-test-package',[exe,'-c','marketplaces.se-harness.source='+json.dumps(str(market)),'plugin','add','verity-plane@se-harness','--json'])
        cache=Path(env['CODEX_HOME'])/'plugins/cache/se-harness/verity-plane/0.2.6'
        assert all((cache/p).is_file() and hashlib.sha256((cache/p).read_bytes()).hexdigest()==h for p,h in report['package_files'].items())
        events=OUT/'plugin026-trusted-native-codex-events';events.mkdir()
        manifest={'demo':str(BASE),'host_executables':{'codex':exe}}
        client=Codex(manifest,events)
        config={'marketplaces.se-harness.source':str(market),'marketplaces.se-harness.source_type':'local','features.multi_agent':False}
        thread=client.rpc('thread/start',{'cwd':str(parent),'ephemeral':False,'sandbox':'read-only','approvalPolicy':'on-request','config':config})['thread']['id']
        def turn(phase):
            client.phase=phase;offset=len(client.events)
            client.rpc('turn/start',{'threadId':thread,'cwd':str(parent),'input':[{'type':'text','text':probe}]});client.wait_turn(thread)
            contexts,replies=extract_codex(client.events[offset:]);report['stages'].append({'phase':phase,'contexts':contexts,'replies':replies});flush()
            print(json.dumps({'host':mode,'phase':phase,'contexts':len(contexts)}),flush=True)
            return contexts
        contexts=turn('startup');assert any('# Select the working repository' in c for c in contexts)
        data=Path(env['CODEX_HOME'])/'plugins/data/verity-plane-se-harness'
        assert any(str(data) in c and thread in c for c in contexts)
        repo,before=prepare_and_activate(thread,data)
        client.phase='manual-compact';offset=len(client.events)
        client.rpc('thread/compact/start',{'threadId':thread});client.wait_turn(thread)
        contexts,_=extract_codex(client.events[offset:]);contexts+=turn('after-manual');assess(contexts)
        client.close();client=None
        resume=events/'resume';resume.mkdir();client=Codex(manifest,resume);client.phase='resume'
        client.rpc('thread/resume',{'threadId':thread,'cwd':str(parent),'excludeTurns':True,'config':config})
        contexts=turn('resumed');all_contexts,_=extract_codex(client.events);assess(all_contexts)
        client.close();client=None
        auto=events/'automatic';auto.mkdir();client=Codex(manifest,auto);client.phase='automatic-resume'
        client.rpc('thread/resume',{'threadId':thread,'cwd':str(parent),'excludeTurns':True,'config':dict(config,model_auto_compact_token_limit=1000)})
        contexts=turn('automatic');assess(contexts)
        assert any(e.get('notification',{}).get('params',{}).get('item',{}).get('type')=='contextCompaction' for e in client.events)
        report['automatic_compaction_observed']=True
    else:
        def claude(phase,session=None,auto=False):
            argv=[EXES[mode]['executable'],'--print','--verbose','--output-format','stream-json','--include-hook-events','--tools','','--strict-mcp-config','--permission-prompts','none','--setting-sources','project','--settings','{}','--plugin-dir',str(plugin),'--model','opus']
            if session:argv+=['--resume',session]
            argv+=['--','/compact' if phase=='manual-compact' else probe]
            local=dict(env)
            if auto:local.update(CLAUDE_AUTOCOMPACT_PCT_OVERRIDE='1',CLAUDE_CODE_AUTO_COMPACT_WINDOW='100000')
            r=subprocess.run(argv,cwd=parent,env=local,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=240)
            events=[];contexts=[];replies=[];ident=None
            for line in r.stdout.splitlines():
                try:e=json.loads(line)
                except ValueError:continue
                if e.get('session_id'):ident=e['session_id']
                if e.get('subtype')=='hook_response':
                    events.append(e)
                    try:c=json.loads(e.get('output','{}')).get('hookSpecificOutput',{}).get('additionalContext')
                    except ValueError:c=None
                    if c:contexts.append(c)
                if e.get('subtype')=='compact_boundary':events.append(e)
                if e.get('type')=='assistant':replies += [c['text'] for c in e.get('message',{}).get('content',[]) if c.get('type')=='text']
                if e.get('type')=='result':events.append({k:e.get(k) for k in ['type','subtype','is_error','result','session_id','usage']})
            report['stages'].append({'phase':phase,'argv':argv,'cwd':str(parent),'exit_code':r.returncode,'session_id':ident,'contexts':contexts,'replies':replies,'events':events,'stderr':r.stderr});flush()
            print(json.dumps({'host':mode,'phase':phase,'exit_code':r.returncode,'contexts':len(contexts)}),flush=True)
            assert r.returncode==0 and ident
            return ident,contexts,events
        session,contexts,_=claude('startup');assert any('# Select the working repository' in c for c in contexts)
        # Use the exact data root delivered by the native hook, not a guessed host identity.
        text='\n'.join(contexts)
        matches=re.findall(r'(?m)^.*(?:[Pp]lugin data|CLAUDE_PLUGIN_DATA|--data-root).*$' ,text)
        report['bootstrap_data_lines']=matches;flush()
        declared=re.findall(r'(?m)^Plugin data: (.+)$',text);assert len(declared)==1
        data=Path(declared[0])
        assert data.is_relative_to(Path(env['CLAUDE_CONFIG_DIR'])/'plugins/data') and session in text
        repo,before=prepare_and_activate(session,data)
        _,contexts,_=claude('resumed',session);assess(contexts)
        _,contexts,_=claude('manual-compact',session);assess(contexts)
        _,contexts,events=claude('automatic',session,True);assess(contexts)
        assert any(e.get('subtype')=='compact_boundary' and e.get('compact_metadata',{}).get('trigger')=='auto' for e in events)
        report['automatic_compaction_observed']=True
    assert before=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in repo.iterdir() if p.is_file()}
    report['repository_preserved']=True;report['passed']=True
except Exception as exc:
    report['error']=str(exc)
finally:
    if client:client.close()
    if restore:
        run('restore-test-profile-package',[EXES[mode]['executable'],'-c','marketplaces.se-harness.source='+json.dumps(restore),'plugin','add','verity-plane@se-harness','--json'])
        report['restored']=json.loads(run('installed-after',[EXES[mode]['executable'],'plugin','list','--marketplace','se-harness','--json']))['installed']
        assert report['restored']==installed
    flush()
print(json.dumps({'host':mode,'passed':report['passed'],'error':report.get('error'),'report':str(dest)}),flush=True)
raise SystemExit(0 if report['passed'] else 1)
