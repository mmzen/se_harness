from pathlib import Path
import hashlib,json,sys,datetime
WORK=Path(__file__).resolve().parent
source=WORK/'r221_native_claude.py';s=source.read_text();setup=s[:s.index("\ntry:\n    report['version']")]
setup=setup.replace('timeout=240','timeout=420')
sys.argv=[str(source),'claude','auto-recovery'];ns={'__file__':str(source),'__name__':'qualification_recovery'}
exec(compile(setup,str(source),'exec'),ns)
prior_path=ns['OUT']/'plugin026-native-claude.json';prior=json.loads(prior_path.read_text());root=Path(prior['root'])
ns.update(root=root,parent=root/'w',plugin=root/'package/verity-plane')
report=ns['report'];report.update(root=str(root),prior_report_sha256=hashlib.sha256(prior_path.read_bytes()).hexdigest(),recovery='Resume the actual timed-out session; preserve the original timeout. Observe native automatic compaction, never simulate an event.')
session=prior['selection']['session_id'];report['selection']=prior['selection']
try:
    for n,prompt in enumerate(['Explain in one short sentence why an average function must handle an empty list. Do not use tools.','What is 2 + 4? Answer briefly without tools.']):
        _,contexts,events=ns['native']('bounded-recovery-'+str(n+1),prompt,session)
        ns['assess'](contexts)
        if any(e.get('subtype')=='compact_boundary' and e.get('compact_metadata',{}).get('trigger')=='auto' for e in events):
            report['automatic_compaction_observed']=True
            _,contexts,_=ns['native']('resume-after-observed-auto','What is 3 + 5? Answer briefly without tools.',session)
            ns['assess'](contexts);report['passed']=True;break
    if not report['passed']:report['error']='No native automatic compaction event in the bounded recovery.'
except Exception as e:report['error']=repr(e)
finally:
    repo=Path(prior['selection']['repository']);after={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in repo.iterdir() if p.is_file()}
    report['repository_preserved']=after==prior['selection']['before'];report['passed']=report['passed'] and report['repository_preserved']
    report['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();ns['flush']()
print(json.dumps({'passed':report['passed'],'error':report.get('error'),'report':str(ns['dest'])}));raise SystemExit(0 if report['passed'] else 1)
