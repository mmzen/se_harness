from r221_session import *
s=(WORK/'rls032_native_boundaries.py').read_text()
s=s.replace("OUT=WORK/'reconcile-minimal-20261001'","OUT=WORK/'r221-session-20261004'")
s=s.replace("EXES=json.loads((OUT/'native-current-inventory.json').read_text())","EXES={'codex':{}}")
start=s.index("if mode=='inputs':");end=s.index("report={'host':mode",start);s=s[:start]+s[end:]
s=s.replace('rls032-','plugin026-').replace("'0.21.0'","expected['version']").replace('/0.2.4\'','/0.2.6\'')
s=s.replace("market=WORK/'plugin026-marketplace'","market=OUT/'plugin026-marketplace'")
s=s.replace("prefix='i30n-'","prefix='p026b-'")
p=WORK/'r221_boundaries_codex.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s)
s=(WORK/'claude025_followup_boundaries.py').read_text()
s=s.replace("'plugin025_native_claude.py'","'r221_native_claude.py'").replace('boundaries-20261003','boundaries-20261004')
s=s.replace('Human mmzen: Ok, go for the tests. Post-release observations only.','Human mmzen: Approve preparation and review publication. Candidate qualification under WO-RLS-041/VER-RLS-037; no release or adoption.')
p=WORK/'r221_boundaries_claude.py';assert not p.exists();compile(s,str(p),'exec');p.write_text(s)
