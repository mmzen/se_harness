from r221_session import *
program=r'''import hashlib,json,pathlib,zipfile,zlib,sys
p=pathlib.Path(sys.argv[1]);r=json.loads((p/'wsl-resumed.json').read_text());a=pathlib.Path(r['stage'])/'plugin-stage';b=p/'plugin026-marketplace'
ia=json.loads((a/'PACKAGE-IDENTITY.json').read_text());ib=json.loads((b/'PACKAGE-IDENTITY.json').read_text());diff=[k for k in ia['files'] if ia['files'][k]!=ib['files'][k]]
assert set(diff)=={'packages/verity-plane-codex.zip','packages/verity-plane-claude.zip'}
rows=[]
for name in diff:
 with zipfile.ZipFile(a/name) as za,zipfile.ZipFile(b/name) as zb:
  assert za.namelist()==zb.namelist()
  entries=[]
  for n in za.namelist():
   aa=za.getinfo(n);bb=zb.getinfo(n)
   assert za.read(n)==zb.read(n)
   fields=['date_time','compress_type','comment','extra','create_system','external_attr','flag_bits']
   assert all(getattr(aa,k)==getattr(bb,k) for k in fields)
   entries.append({'name':n,'sha256':hashlib.sha256(za.read(n)).hexdigest(),'linux_compressed_size':aa.compress_size,'windows_compressed_size':bb.compress_size})
  rows.append({'archive':name,'entries':entries})
result={'candidate':r['candidate'],'shared_contents_and_inventories_identical':True,'archive_bytes_identical':False,'differing_files':diff,'linux_python':sys.version,'linux_zlib':zlib.ZLIB_RUNTIME_VERSION,'archives':rows,'assessment':'Both platform builders and their own check-stage passed. Every expanded file and ZIP member byte and retained metadata matches. Compressed streams differ between runtimes. The exact Windows staged tree is selected for this preparation; no cross-runtime compressed-byte reproducibility claim. Existing publisher verifies the frozen Git blobs and digests without rebuilding ZIPs.','passed':True}
(p/'cross-platform-package-comparison.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='archives'}))
'''
run('cross-platform-package-comparison-command',[r'C:\Windows\System32\wsl.exe','-d','Ubuntu-24.04','--exec','python3','-c',program,'/mnt/c/'+OUT.as_posix()[3:]])
