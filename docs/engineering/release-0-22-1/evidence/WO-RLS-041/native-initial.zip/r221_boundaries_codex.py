"""Temporary exact-wheel native probes; only disposable profiles and fixtures."""
from pathlib import Path
import sys,json,subprocess,hashlib,os,base64,zipfile,io,tempfile,re,datetime
WORK=Path(__file__).resolve().parent
OUT=WORK/'r221-session-20261004'
sys.path.insert(0,str(WORK/'iar-demo-tools'))
from run_demo import child_env
from acceptance_native import Codex,extract_codex,save
BASE=Path(json.loads((WORK/'iar-demo-tools/prepared-demo.json').read_text())['demo'])
EXES={'codex':{}}
EXES['codex']['executable']=r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe'
mode=sys.argv[1]
report={'host':mode,'claims':'Native CLI/app-server only; desktop remains unverified.','commands':[],'stages':[],'passed':False}
dest=OUT/('plugin026-boundaries-native-'+mode+(('-'+sys.argv[2]) if len(sys.argv)>2 else '')+'.json');assert not dest.exists()
env=child_env(BASE,mode)
root=Path(tempfile.mkdtemp(prefix='p026b-'));parent=root/'w';parent.mkdir()
report['root']=str(root)
inputs=json.loads((OUT/'plugin026-native-inputs.json').read_text());expected=inputs['expected']
package=root/'package'
with zipfile.ZipFile(io.BytesIO(base64.b64decode(inputs[mode]))) as z:
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in z.namelist())
    z.extractall(package)
plugin=package/'verity-plane';wheel=plugin/'packages'/expected['archive_name']
assert hashlib.sha256(wheel.read_bytes()).hexdigest()==expected['archive_sha256']
with zipfile.ZipFile(wheel) as z:
    n=next(n for n in z.namelist() if n.endswith('/ENGINEERING_HARNESS.md.tpl'))
    entry=z.read(n).decode().replace('{{PROJECT_NAME}}','Plugin qualification').replace('{{HARNESS_VERSION}}',expected['version'])
digest=hashlib.sha256(entry.encode()).hexdigest();report['entry_sha256']=digest;report['wheel']=expected
report['package_files']={p.relative_to(plugin).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in plugin.rglob('*') if p.is_file()}
def flush():save(dest,report)
def run(label,argv,allowed=(0,),use_env=env):
    argv=list(map(str,argv));r=subprocess.run(argv,cwd=parent,env=use_env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=180)
    report['commands'].append({'label':label,'argv':argv,'cwd':str(parent),'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});flush()
    assert r.returncode in allowed,(label,r.stdout[-1200:],r.stderr[-1200:])
    return r.stdout
def assess(contexts):
    assert any(c.endswith(entry) and digest in c for c in contexts),[c[:180] for c in contexts]
def prepare_and_activate(session,data):
    remote=root/'source';remote.mkdir()
    raw=run('prepare-exact-evaluator',[sys.executable,'-I',plugin/'scripts/setup.py','--target',remote,'--data-root',data,'--wheel',wheel],allowed=(1,2))
    found=re.search(r'^Evaluator Python: (.+)$',raw,re.M);assert found
    py=Path(found[1].strip())
    run('fixture-init',[py,'-I','-m','se_harness','init',remote,'--project-name','Plugin qualification','--integration','git','--json'])
    for args in [['init'],['add','.'],['-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','-m','Disposable exact-wheel selection']]:
        run('fixture-git',['git','-C',remote,*args])
    repo=parent/'clone'
    run('clone-after-startup',['git','clone',remote,repo]);assert not (repo/'ENGINEERING_HARNESS.md').exists()
    before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in repo.iterdir() if p.is_file()}
    activation=json.loads(run('activate-observed-session',[sys.executable,'-I',plugin/'scripts/activate.py','--host',mode,'--session-id',session,'--data-root',data,'--target',repo]))
    assert activation['status']=='available';assess([activation['content']])
    report['selection']={'session_id':session,'data':str(data),'repository':str(repo),'before':before}
    return repo,before

probe='Read-only package qualification. Do not call tools. State the selected checkout, release and whether a delivery gap is reported in the newest hook context. Delivery grants no authority.'
client=None;restore=None
try:
    exe=EXES[mode]['executable'];report['version']=run('host-version',[exe,'--version']).strip()
    installed=json.loads(run('installed-before',[exe,'plugin','list','--marketplace','se-harness','--json']))['installed']
    assert len(installed)==1
    restore=installed[0]['marketplaceSource']['source']
    market=OUT/'plugin026-marketplace'
    run('install-exact-package',[exe,'-c','marketplaces.se-harness.source='+json.dumps(str(market)),'plugin','add','verity-plane@se-harness','--json'])
    cache=Path(env['CODEX_HOME'])/'plugins/cache/se-harness/verity-plane/0.2.6'
    assert all((cache/p).is_file() and hashlib.sha256((cache/p).read_bytes()).hexdigest()==h for p,h in report['package_files'].items())
    events=OUT/'plugin026-boundaries-events';events.mkdir()
    client=Codex({'demo':str(BASE),'host_executables':{'codex':exe}},events)
    hooks=client.rpc('hooks/list',{'cwds':[str(parent)]})
    assert all(h['trustStatus']=='trusted' for row in hooks['data'] for h in row['hooks'] if h.get('pluginId')=='verity-plane@se-harness')
    report['hooks']=hooks
    config={'marketplaces.se-harness.source':str(market),'marketplaces.se-harness.source_type':'local','features.multi_agent':False}
    def start():return client.rpc('thread/start',{'cwd':str(parent),'ephemeral':False,'sandbox':'read-only','approvalPolicy':'on-request','config':config})['thread']['id']
    def turn(thread,phase,compact=False):
        client.phase=phase; offset=len(client.events)
        if compact:
            client.rpc('thread/compact/start',{'threadId':thread});client.wait_turn(thread)
        client.rpc('turn/start',{'threadId':thread,'cwd':str(parent),'input':[{'type':'text','text':probe}]});client.wait_turn(thread)
        contexts,replies=extract_codex(client.events[offset:])
        report['stages'].append({'thread':thread,'phase':phase,'contexts':contexts,'replies':replies});flush()
        print(json.dumps({'phase':phase,'contexts':len(contexts)}),flush=True)
        return contexts
    a=start();b=start(); assert a!=b
    assert any('# Select the working repository' in c for c in turn(a,'A-bootstrap'))
    assert any('# Select the working repository' in c for c in turn(b,'B-bootstrap'))
    data=Path(env['CODEX_HOME'])/'plugins/data/verity-plane-se-harness'
    repo,before=prepare_and_activate(a,data)
    legacy=parent/'legacy';legacy.mkdir()
    old_wheel=WORK/'plg030-public-inputs/se_harness-0.20.0-py3-none-any.whl'
    raw=run('prepare-legacy',[sys.executable,'-I',plugin/'scripts/setup.py','--target',legacy,'--data-root',data,'--wheel',old_wheel],allowed=(1,2))
    found=re.search(r'^Evaluator Python: (.+)$',raw,re.M);assert found
    old_python=Path(found[1].strip())
    run('legacy-init',[old_python,'-I','-m','se_harness','init',legacy,'--project-name','Legacy parallel fixture','--json'])
    def activate(thread,target=None):
        args=[sys.executable,'-I',plugin/'scripts/activate.py','--host','codex','--session-id',thread,'--data-root',data]
        args+=['--target',target] if target else ['--clear']
        return json.loads(run('activate-'+thread,args))
    activate(b,legacy)
    assess(turn(a,'A-current-compact',True))
    assert any('Selected release: 0.20.0' in c and str(legacy) in c for c in turn(b,'B-legacy-compact',True))
    activate(b,repo)
    assess(turn(b,'B-switch-current',True));assess(turn(a,'A-unchanged-after-switch',True))
    activate(b)
    assert any('# Select the working repository' in c for c in turn(b,'B-cleared',True))
    assess(turn(a,'A-unchanged-after-clear',True))
    moved=repo.with_name('temporarily-unavailable');assert not moved.exists()
    assert repo.resolve().is_relative_to(root.resolve());repo.rename(moved)
    try:
        assert any('delivery is unavailable' in c for c in turn(a,'A-missing-checkout',True))
    finally:moved.rename(repo)
    assess(turn(a,'A-restored',True))
    assert before=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in repo.iterdir() if p.is_file()}
    report['repository_preserved']=True;report['passed']=True
except Exception as exc:report['error']=str(exc)
finally:
    if client:client.close()
    if restore:
        run('restore-test-profile-package',[EXES[mode]['executable'],'-c','marketplaces.se-harness.source='+json.dumps(restore),'plugin','add','verity-plane@se-harness','--json'])
        report['restored']=json.loads(run('installed-after',[EXES[mode]['executable'],'plugin','list','--marketplace','se-harness','--json']))['installed']
        assert report['restored']==installed
    flush()
print(json.dumps({'passed':report['passed'],'error':report.get('error'),'report':str(dest)}),flush=True)
raise SystemExit(0 if report['passed'] else 1)
