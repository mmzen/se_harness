from r221_session import *
import base64
market=OUT/'plugin026-marketplace'
identity=json.loads((market/'PACKAGE-IDENTITY.json').read_text())
expected=dict(identity['evaluator']);expected['archive_name']=expected['archive']
inputs={h:base64.b64encode((market/'packages'/('verity-plane-'+h+'.zip')).read_bytes()).decode() for h in ('codex','claude')}
inputs.update(marketplace=json.loads((market/'.agents/plugins/marketplace.json').read_text()),expected=expected)
(OUT/'plugin026-native-inputs.json').write_text(json.dumps(inputs))
for host in ('codex','claude'):
    source=WORK/('plugin025_native_'+host+'.py');s=source.read_text()
    s=s.replace("OUT=WORK/'release022'","OUT=WORK/'r221-session-20261004'")
    s=s.replace('plugin025','plugin026').replace('p025n-','p026n-').replace('/0.2.5\'','/0.2.6\'')
    s=s.replace('WO-RLS-035/VER-RLS-034','WO-RLS-041/VER-RLS-037')
    s=s.replace('abbec12ac5524c8adfb28693f846dd59de88f759',identity['source']['revision'])
    p=WORK/('r221_native_'+host+'.py');assert not p.exists()
    compile(s,str(p),'exec');p.write_text(s,encoding='utf-8',newline='\n')
    print(json.dumps({'host':host,'probe':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
