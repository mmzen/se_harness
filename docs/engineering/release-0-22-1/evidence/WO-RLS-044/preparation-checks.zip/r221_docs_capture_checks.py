"""Freshly assess the exact exported documentation candidate and retained checks."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
C,digest=sys.argv[1:];R=Path.cwd();E='docs/engineering/release-0-22-1/evidence/WO-RLS-044/'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==C
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert h(R/E/'implementation.json')==digest
receipt=json.loads((R/E/'implementation.json').read_bytes())
assert receipt['qualification']['source_suite_exit']==0 and receipt['qualification']['readme_words']==650
for item in receipt['changed_documents']:assert h(R/item['path'])==item['sha256'],item['path']
assert h(R/receipt['raw_checks']['path'])==receipt['raw_checks']['sha256']
env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1');env.pop('PYTHONPATH',None)
argv=[sys.executable,'-B','-X','utf8','-m','se_harness','qualify','complete-candidate','.', '--candidate-commit',C,'--json']
result=subprocess.run(argv,env=env,capture_output=True,text=True,encoding='utf-8',timeout=900)
out=Path(__file__).parent/'r221-docs044-20261005/capture-candidate-check.json';assert not out.exists()
out.write_text(json.dumps({'argv':argv,'cwd':str(R),'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr},indent=2)+'\n')
assert result.returncode==0,result.stdout+result.stderr
print(json.dumps({'documentation_candidate':C,'receipt_sha256':digest,'document_count':len(receipt['changed_documents']),'retained_source_suite':receipt['qualification'],'fresh_complete_candidate':json.loads(result.stdout),'binary_candidate_preserved':'4f640284ec496b88cd7aa4ba88ca537d9374a2f8','limits':'Documentation-only assessment; no human verification, rebuilt package or publication.'}))
