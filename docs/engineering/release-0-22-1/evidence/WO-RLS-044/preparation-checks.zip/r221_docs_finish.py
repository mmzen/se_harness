"""Retain, complete and capture the documentation-only outcome."""
import hashlib,json,re,subprocess,sys,tomllib,zipfile
import r221_session as s
s.OUT=s.WORK/'r221-docs044-20261005'
D=s.DOMAIN;E=D+'evidence/WO-RLS-044/';BASE='af27c2331741ae922276e50f9176d2a92743e053'
P=s.WORK/'r221-final-20261005/capture-source-env/Scripts/python.exe'
def git(*a):return subprocess.check_output(['git',*a],cwd=s.REPO,text=True).rstrip('\r\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(name):return json.loads((s.OUT/(name+'.json')).read_text(encoding='utf-8-sig'))
mode=sys.argv[1]
if mode=='retain':
    final=load('full-source-suite-corrected');assert final['exit_code']==0
    for name in ('progressive-documentation','refresh-guidance','public-onboarding-corrected-2','distribution-check','cli-help','formal-validation'):assert load(name)['exit_code']==0,name
    assert 'Ran 1293 tests' in final['stdout'] and 'skipped=23' in final['stdout']
    s.run('final-implementation-diff',['git','diff','--stat',BASE],cwd=s.REPO)
    s.run('final-implementation-patch',['git','diff',BASE,'--','README.md','docs/notes/plugin-installation-guide.md','docs/notes/plugin-marketplace-publication.md','plugins/verity-plane/codex/README.md','plugins/verity-plane/claude-code/README.md','release/plugin-marketplace/README.md'],cwd=s.REPO)
    s.gov('final-formal-validation','validate')
    ep=s.REPO/E; archive=ep/'checks.zip';assert not archive.exists()
    names=sorted(s.OUT.glob('*.json'))+[s.OUT/'manual-context-first.py',s.WORK/'r221_docs_checks.py',s.WORK/'r221_docs_execute.py']
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in names:z.write(p,p.name)
    inputs=json.loads((ep/'proposal-inputs.json').read_text())
    observed=load('manual-observations-corrected')
    result={'schema':'release-documentation-implementation/v1','work_order':'WO-RLS-044','verification':'VER-RLS-005','trusted_work_base':BASE,'full_pr_base':s.BASE,'approved_review':'57db794eb9d125c0a56d26e352f43c876954939a','human':'mmzen','response':'I alprou','qualification':{'focused_tests':44,'source_suite_tests':1293,'source_suite_skips':23,'source_suite_exit':0,'distribution_records':23,'cli_help':'passed','released_validation_errors':0,'readme_words':650},'changed_documents':[{'path':f['path'],'sha256':sha(s.REPO/f['path'])} for f in inputs['files']],'observations':observed,'raw_checks':{'path':E+'checks.zip','sha256':sha(archive)},'limits':['Documentation-only source correction; no rebuilt evaluator or plugin.','Package README snapshots retain their original preparation wording; current guides explain their historical context.','Codex Windows desktop remains unverified under DEC-RLS-009 / RISK-RLS-007.','No public 0.22.1/0.2.6 fresh/update tests, hosted-service verification, adoption, merge or release decision.']}
    (ep/'implementation.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    assessment='''# Documentation verification assessment

The six current source guides distinguish verified 0.22.1 / 0.2.6 qualification,
human release authority and actual public availability. The stable delivery index
points to separate observations without declaring unperformed work complete.
The release binary candidate remains `4f640284ec496b88cd7aa4ba88ca537d9374a2f8`.
This correction has its own later documentation candidate; it does not replace
VREC-SEH-033 or its bound archives and staged packages.

## Requirement assessment

| Requirement | Result | Evidence and assessment |
| --- | --- | --- |
| REQ-RLO-019 | Pass | Claims were compared with VREC-SEH-033, its qualification review, the named historical public receipts and provider readback. Versions and installation/work-order references match the selected release. Source links, new composed-source links and original staged README links pass. |
| REQ-RLO-020 | Pass | Authorization and public observations remain distinct. Dated earlier evidence is preserved. The desktop limitation and separate adoption/hosted scope remain explicit. There is no new public-install or complete-delivery claim. |

## Observed checks

- 20 progressive-documentation, 8 refresh-guidance and 16 onboarding tests pass.
- The full Windows source suite passes: 1,293 tests, 23 reported skips, exit 0.
- Distribution validation passes for 23 records; CLI help passes.
- Released 0.22.0 validation has zero errors and 63 repository warnings.
- All 69 original staged marketplace files still match their bound identities.
- The retained wheel and sdist still match RLS-SEH-033. No executable, manifest,
  template, workflow, dependency, package archive or inventory was changed.
- Publisher inspection confirms the frozen plan can select a separate documentation
  ancestor and checks the same file hashes at that commit, governance and current head.
  The executable plan is still to be frozen after this documentation verification.

## Failures and corrections retained

The first full suite failed the existing 650-word README bound at 685 words. An
intermediate shortening still had 656 words and failed the focused test. Only the
new release section was shortened further; the final 650-word version passes the
focused and full suites. The six other reviewed files remain byte-identical to
the proposal. No test or limit was weakened.

An extra inspection helper first treated two package-only skill links as source
links. The existing composed-source test passed; the helper was corrected to use
the intended source and composed contexts. The original failure and helper are
retained alongside the corrected inspection. This was not a repository defect.

## Scope, evidence and limits

The work baseline is `af27c2331741ae922276e50f9176d2a92743e053`, immediately before
this separately approved correction. The complete PR still uses main baseline
`82f5a0ed7438a73da8f03aee23ad02a9b8cc09e1` and all applicable work orders; no earlier
implementation is excluded from the PR assessment.

[Raw checks](checks.zip) preserve commands, runtimes, results, failures and helper
sources. [The implementation receipt](implementation.json) binds the exact seven
document hashes, archive hashes, scope and observed results.

Qualified package README snapshots remain unchanged and retain historical staging
wording. Current source guidance explains that distinction. These checks assess
source documentation, not new package bytes. Codex Windows desktop remains unverified
under accepted DEC-RLS-009 / RISK-RLS-007. No live public fresh/update or hosted tests
ran for this correction. Human verification and the complete-release decision are
still separate; this assessment makes neither decision.
'''
    (ep/'assessment.md').write_text(assessment,encoding='utf-8',newline='\n')
    p=s.REPO/D/'README.md';t=p.read_text()
    old='''The complete-delivery plan is not frozen yet. Its documentation review found
stale qualification/current-version statements that would become locked by the
plan. [WO-RLS-044 / VER-RLS-005](evidence/WO-RLS-044/review.md) propose a bounded,
independently verified source-documentation correction. Its exact patch is
unapplied. The already verified binary candidate and immutable staged packages
remain unchanged. The release decision is not being requested until those
documentation inputs and their required assurance are ready.'''
    assert old in t
    t=t.replace(old,'''The complete-delivery plan is not frozen yet. mmzen approved WO-RLS-044 and
VER-RLS-005 for the bounded source-documentation correction. The six guides and
stable delivery index are corrected and checked; the [assessment](evidence/WO-RLS-044/assessment.md)
retains the original failures, their fixes and the unchanged payload identities.
The required independent documentation verification is being prepared. The
already verified binary candidate and immutable staged packages remain unchanged.
The complete-release request follows that separate human verification.''')
    t=t.replace('a read-only\nready-record replay follows publication of this preparation review.','the [ready-record replay](evidence/WO-RLS-040/ready-record-replay-receipt.json)\npassed with two byte-identical builds of the bound candidate.')
    p.write_text(t,encoding='utf-8',newline='\n')
elif mode=='complete':
    assert load('review-preflight')['exit_code']==0
    assert load('handoff-check-corrected')['exit_code']==0
    args=['transition','--set','WO-RLS-044=implemented','--decision','WO-RLS-044=Codex','--reason','WO-RLS-044=The approved six source-documentation corrections and stable delivery index are complete. Focused and full Windows suites, distributions, CLI, released validation, links and exact package/archive preservation checks pass. Original README-bound and inspection-context failures and their corrections are retained under evidence/WO-RLS-044. This supplies no human verification, release, merge or adoption decision.']
    s.gov('completion-preview',*args);s.gov('completion-apply',*args,'--apply')
    s.gov('implemented-context','check','--artifact','WO-RLS-044')
elif mode=='commit':
    target=s.REPO/E/'completion-checks.zip';assert not target.exists()
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for name in ('review-preflight','handoff-check','handoff-evidence','handoff-check-corrected','completion-preview','completion-apply','implemented-context'):z.write(s.OUT/(name+'.json'),name+'.json')
    paths=json.loads((s.REPO/E/'implementation.json').read_text())['changed_documents']
    allowed=[p['path'] for p in paths]+[D]
    for row in git('status','--porcelain').splitlines():assert row[3:] in allowed or row[3:].startswith(D),row
    s.run('candidate-stage',['git','add','--',*allowed],cwd=s.REPO)
    s.run('candidate-diff-check',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'],cwd=s.REPO)
    s.run('candidate-commit',['git','commit','-m','Correct 0.22.1 release documentation before delivery plan freeze'],cwd=s.REPO)
    C=git('rev-parse','HEAD');assert not git('status','--porcelain')
    (s.OUT/'documentation-candidate.txt').write_text(C+'\n')
    print(json.dumps({'documentation_candidate':C,'binary_candidate_unchanged':'4f640284ec496b88cd7aa4ba88ca537d9374a2f8'}))
elif mode=='capture':
    C=(s.OUT/'documentation-candidate.txt').read_text().strip()
    assert git('rev-parse','HEAD')==C and not git('status','--porcelain')
    assert not git('log','--all','--format=','--name-only','--','**/VREC-RLS-003.md')
    evidence=[E+x for x in ('checks.zip','implementation.json','assessment.md','completion-checks.zip')]
    args=[s.GOV,'-I','-m','se_harness','capture-verification',s.REPO,'--id','VREC-RLS-003','--work-order','WO-RLS-044','--verification','VER-RLS-005','--owner','Codex','--domain','release-0-22-1','--candidate-commit',C]
    for path in evidence:args+=['--evidence',path]
    args+=['--json','--test-command',P,'-B','-X','utf8',s.WORK/'r221_docs_capture_checks.py',C,sha(s.REPO/E/'implementation.json')]
    s.run('capture-verification',args,timeout=1800)
    p=s.REPO/D/'verification-records/VREC-RLS-003.md';record=tomllib.loads(p.read_text().split('+++',2)[1])
    assert record['status']=='ready' and record['commit']==C
    s.gov('ready-verification-context','check','--artifact','VREC-RLS-003')
