"""Observed documentation checks; no lifecycle decisions."""
import hashlib,importlib.util,json,posixpath,re,subprocess,sys,tomllib
import r221_session as s
s.OUT=s.WORK/'r221-docs044-20261005';s.OUT.mkdir(exist_ok=True)
P=s.WORK/'r221-final-20261005/capture-source-env/Scripts/python.exe'
mode=sys.argv[1];R=s.REPO;D=s.DOMAIN
if mode=='focused':
    s.run('runtime-identity',[P,'-B','-X','utf8','-c','import sys,platform;print(sys.executable);print(sys.version);print(platform.platform())'])
    s.run('progressive-documentation',[P,'-B','-X','utf8','-m','unittest','discover','-s','tests','-p','test_progressive_documentation.py'],cwd=R)
    s.run('refresh-guidance',[P,'-B','-X','utf8','-m','unittest','discover','-s','tests/plugin_integration/package_assembly','-p','test_refresh_guidance.py'],cwd=R)
elif mode=='suite':
    s.run('full-source-suite',[P,'-B','-X','utf8','scripts/run_tests.py'],cwd=R,timeout=1800)
elif mode=='distribution':
    s.run('distribution-check',[P,'-B','-X','utf8','scripts/validate_release_distributions.py','--root','.'],cwd=R)
    s.run('cli-help',[P,'-B','-X','utf8','-m','se_harness','--help'],cwd=R)
    s.gov('formal-validation','validate')
elif mode=='manual':
    changed=subprocess.check_output(['git','diff','--name-only','af27c2331741ae922276e50f9176d2a92743e053'],cwd=R,text=True).splitlines()
    spec=importlib.util.spec_from_file_location('doccheck',R/'tests/plugin_integration/package_assembly/test_refresh_guidance.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    manifest=json.loads((R/D/'evidence/WO-RLS-044/proposal-inputs.json').read_text())
    sources=[f['path'] for f in manifest['files']]
    assert all(p in sources or p.startswith(D) for p in changed),changed
    files={p:(R/p).read_bytes() for p in sources}
    for source in sources:
        for link in re.findall(r'\[[^]]*\]\(([^)]+)\)',files[source].decode('utf-8')):
            if re.match(r'(?:https?://|mailto:|#)',link):continue
            p=posixpath.normpath(posixpath.join(posixpath.dirname(source),link.split('#')[0]))
            if (R/p).is_file():files[p]=(R/p).read_bytes()
    # Distribution README links are resolved in its composed distribution, below.
    source_paths=[p for p in sources if p!='release/plugin-marketplace/README.md']
    findings=m.link_findings(files,source_paths);assert not findings,findings
    stage=s.WORK/'r221-final-20261005/plugin026-marketplace'
    identity_path=R/D/'evidence/WO-RLS-040/final-package-identity.json'
    identity=json.loads(identity_path.read_bytes())
    h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    assert h(stage/'PACKAGE-IDENTITY.json')==h(identity_path)
    for p,digest in identity['files'].items():assert h(stage/p)==digest,p
    staged_files={p:(stage/p).read_bytes() for p in identity['files']}
    native_readmes=['README.md','packages/codex/verity-plane/README.md','packages/claude/verity-plane/README.md']
    findings=m.link_findings(staged_files,native_readmes);assert not findings,findings
    record=tomllib.loads((R/D/'releases/RLS-SEH-033.md').read_text().split('+++',2)[1])
    assert record['commit']=='4f640284ec496b88cd7aa4ba88ca537d9374a2f8' and record['status']=='ready'
    vrec=tomllib.loads((R/D/'verification-records/VREC-SEH-033.md').read_text().split('+++',2)[1])
    assert vrec['status']=='verified' and vrec['commit']==record['commit'] and vrec['verified_by']=='mmzen'
    # Confirm frozen-plan validation checks a distinct documentation ancestor
    # and the same hashes at documentation, governance and current revisions.
    publisher=(R/'.github/scripts/publish_release.py').read_text()
    assert 'doc_commit = surfaces["documentation"]["expected"]["commit"]' in publisher
    assert 'for ref in (doc_commit, plan.governance_commit, head):' in publisher
    assert '"merge-base", "--is-ancestor", doc_commit, plan.governance_commit' in publisher
    for f in manifest['files']:assert h(R/f['path'])==f['proposed_sha256'],f['path']
    result={'argv':[sys.executable,*sys.argv],'cwd':str(__import__('pathlib').Path.cwd()),'checker_sha256':h(__import__('pathlib').Path(__file__)),'changed_paths':changed,'source_paths':source_paths,'source_links':'passed','original_staged_readme_links':'passed','staged_files_byte_identical':len(identity['files'])+1,'package_identity_sha256':h(identity_path),'release_candidate':record['commit'],'release_record':record['id'],'release_state':record['status'],'verification_record':vrec['id'],'verification_state':vrec['status'],'reviewed_documentation_bytes_match':True,'separate_documentation_commit_supported':True,'live_public_readback':'not performed; belongs to WO-RLS-042','executable_changes':False}
    (s.OUT/'manual-observations.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
