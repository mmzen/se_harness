"""Execute the approved bounded documentation correction with retained observations."""
import hashlib,json,subprocess,sys,tomllib
import r221_session as s
s.OUT=s.WORK/'r221-docs044-20261005';s.OUT.mkdir(exist_ok=True)
D=s.DOMAIN;E=D+'evidence/WO-RLS-044/';BASE='af27c2331741ae922276e50f9176d2a92743e053'
WO=D+'work-orders/WO-RLS-044.md';VER=D+'verification/VER-RLS-005.md'
def git(*a):return subprocess.check_output(['git',*a],cwd=s.REPO,text=True).rstrip('\r\n')
def metadata(p):return tomllib.loads((s.REPO/p).read_text(encoding='utf-8').split('+++',2)[1])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
mode=sys.argv[1]
if mode=='inspect':
    d,_=s.gov('initial-context','check','--artifact','WO-RLS-044')
    print(json.dumps(d.get('context',{}).get('reading_manifest')))
elif mode=='approve':
    assert git('rev-parse','HEAD')==BASE and not git('status','--porcelain')
    inputs=json.loads((s.WORK/'r221-final-20261005/documentation-approval-inputs.json').read_text(encoding='utf-8-sig'))
    for path,digest in inputs['sha256'].items():assert sha(s.REPO/path)==digest,path
    for path in (WO,VER):assert metadata(path)['status']=='draft'
    p=s.REPO/WO;t=p.read_text(encoding='utf-8');assert '[assurance]' not in t
    t=t.replace('[execution_scope]','''[assurance]
commit_bound_verification = "required"
rationale = "mmzen confirmed required commit-bound verification because the complete-release decision depends on the accuracy of the corrected source documentation."
decided_by = "mmzen"

[execution_scope]''',1)
    p.write_text(t,encoding='utf-8',newline='\n')
    reason='mmzen replied "I alprou", understood in the immediately preceding approval request as approval of WO-RLS-044 and VER-RLS-005 with required commit-bound verification, reviewed in PR #536 at 57db794eb9d125c0a56d26e352f43c876954939a. This approves the six source-documentation corrections and stable delivery-evidence index, bounded checks and evidence, ordinary review updates from codex/release-0-22-1 to mmzen/se_harness:main, and the later separately supplied verification decision. It preserves verified candidate 4f640284ec496b88cd7aa4ba88ca537d9374a2f8 and all qualified package bytes. Human verification, merge and the exact complete-release decision remain separate. Reviewed hashes matched; only the confirmed assurance fields were added before approval.'
    args=['transition','--set','VER-RLS-005=approved','--set','WO-RLS-044=approved','--decision','VER-RLS-005=mmzen','--decision','WO-RLS-044=mmzen','--reason','VER-RLS-005='+reason,'--reason','WO-RLS-044='+reason]
    before={path:sha(s.REPO/path) for path in (WO,VER)}
    s.gov('approval-preview',*args)
    for path,digest in before.items():assert sha(s.REPO/path)==digest,path
    s.gov('approval-apply',*args,'--apply')
    for path in (WO,VER):assert metadata(path)['status']=='approved'
    s.gov('approved-context','check','--artifact','WO-RLS-044')
elif mode=='start':
    assert metadata(WO)['status']=='approved'
    s.gov('start-preflight','preflight','--work-order','WO-RLS-044','--phase','start')
    args=['transition','--set','WO-RLS-044=in_progress','--decision','WO-RLS-044=Codex']
    s.gov('start-preview',*args);s.gov('start-apply',*args,'--apply')
    assert metadata(WO)['status']=='in_progress'
    s.gov('started-context','check','--artifact','WO-RLS-044')
elif mode=='apply':
    assert metadata(WO)['status']=='in_progress'
    manifest=json.loads((s.REPO/E/'proposal-inputs.json').read_text())
    actual=git('diff','--name-only').splitlines()
    paths=sorted(set(actual+[f['path'] for f in manifest['files']]+[E+'checks.zip',E+'assessment.md',E+'implementation.json']))
    args=['check','--artifact','WO-RLS-044','--checkpoint','scope','--changes-complete']
    for path in paths:args+=['--changed-path',path]
    s.gov('implementation-scope',*args)
    for f in manifest['files']:
        p=s.REPO/f['path'];assert (sha(p) if p.exists() else None)==f['before_sha256'],f['path']
    patch=s.REPO/E/'proposed-documentation.patch'
    s.run('patch-check',['git','apply','--check',patch],cwd=s.REPO)
    s.run('patch-apply',['git','apply','--whitespace=nowarn',patch],cwd=s.REPO)
    for f in manifest['files']:assert sha(s.REPO/f['path'])==f['proposed_sha256'],f['path']
    s.run('implementation-diff',['git','diff','--stat',BASE],cwd=s.REPO)
    print(json.dumps({'applied':len(manifest['files']),'candidate_preserved':'4f640284ec496b88cd7aa4ba88ca537d9374a2f8'}))
