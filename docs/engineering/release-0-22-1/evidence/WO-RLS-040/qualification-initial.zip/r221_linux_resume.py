from r221_session import *
prior=json.loads((OUT/'wsl-qualification.json').read_text());stage=prior['stage']
def linux(p):return '/mnt/c/'+p.as_posix()[3:]
program=r'''import hashlib,json,os,pathlib,subprocess,sys
i=json.loads(sys.argv[1]);stage=pathlib.Path(i['stage']);source=stage/'source';py=stage/'current/bin/python';old=stage/'prior/bin/python';rows=[]
dest=pathlib.Path(i['output']);result={'candidate':i['candidate'],'stage':str(stage),'commands':rows,'passed':False,'previous':'wsl-qualification.json'}
def run(label,args,cwd=stage):
 p=subprocess.run(list(map(str,args)),cwd=cwd,capture_output=True,text=True,encoding='utf-8',timeout=1800)
 rows.append(dict(label=label,argv=list(map(str,args)),cwd=str(cwd),exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr));dest.write_text(json.dumps(result,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode:raise RuntimeError(label+': '+p.stderr[-1500:])
 return p
try:
 probe=stage/'draft-probe.py';s=(source/'docs/engineering/hosted-artifact-graph/evidence/WO-HAG-002/qualify_correction_wheel.py').read_text()
 s=s.replace('a.python.resolve().parent.parent','a.python.absolute().parent.parent').replace("str(base.parent / 'se_harness')","str(Path("+repr(str(source))+"))")
 probe.write_text(s)
 run('installed-draft-cli',[sys.executable,probe,'--python',py,'--wheel',i['wheel'],'--commit',i['candidate']])
 run('installed-topology',[py,'-I','-c',"import json;from se_harness.engine import dashboard_bundle as b;assert b.TOPOLOGY_ACCEPTANCE_BYTES==4194304;r=[b.topology_target_exceeded(v) for v in (4194303,4194304,4194305)];assert r==[False,False,True];print(json.dumps({'target':b.TOPOLOGY_ACCEPTANCE_BYTES,'results':r,'origin':b.__file__}))"])
 for f in ('tests/test_skill_ownership.py','tests/plugin_integration/test_simple_plugin.py'):
  os.environ['SE_HARNESS_TEST_PLUGIN_WHEEL']=i['wheel'];os.environ['SE_HARNESS_TEST_PLUGIN_PYTHON']=str(py)
  run('installed-'+pathlib.Path(f).stem,[py,'-I','-B',source/f,'-v'])
 for n in (1,2):run('upgrade-'+str(n),[py,'-B','-m','repository_tools.upgrade_rehearsal','--repository',source,'--predecessor-python',old,'--successor-python',py,'--output',stage/('upgrade-'+str(n)),'--workspace',stage,'--timings'],source)
 a=json.loads((stage/'upgrade-1/upgrade-rehearsal-result.json').read_text());b=json.loads((stage/'upgrade-2/upgrade-rehearsal-result.json').read_text());assert a['overall_result']==b['overall_result']=='pass' and a['semantic_sha256']==b['semantic_sha256'];result['upgrades']=[a,b]
 run('sdist-env',[sys.executable,'-m','venv',stage/'sdist-env']);bp=stage/'sdist-env/bin/python'
 run('sdist-tools',[bp,'-m','pip','install','--disable-pip-version-check','--only-binary=:all:','--require-hashes','-r',source/'release/build-toolchain.lock'])
 run('sdist-install',[bp,'-m','pip','install','--no-index','--no-deps','--no-build-isolation','--no-binary=se-harness','--find-links',pathlib.Path(i['wheel']).parent,'se-harness==0.22.1'])
 for cmd in ('init','doctor','validate'):run('sdist-'+cmd,[bp,'-I','-m','se_harness',cmd,stage/'sdist-fixture','--json'])
 args=['--repository',source,'--revision',i['candidate'],'--candidate-manifest',i['manifest'],'--expected-manifest-sha256',i['manifest_sha256'],'--expected-wheel-sha256',i['wheel_sha256'],'--wheel',i['wheel'],'--evaluator-python',old,'--output-directory',stage/'plugin-stage']
 for cmd in ('stage','check-stage'):run('plugin-'+cmd,[py,source/'scripts/build_plugin_marketplace.py',cmd,*args])
 identity=json.loads((stage/'plugin-stage/PACKAGE-IDENTITY.json').read_text());expected=json.loads(pathlib.Path(i['windows_identity']).read_text());assert identity==expected
 result['cross_platform_packages_identical']=True;result['passed']=True
except Exception as e:result['error']=repr(e)
dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'error':result.get('error')}));sys.exit(0 if result['passed'] else 1)
'''
mf=OUT/'bundle.json';wheel=OUT/'build/se_harness-0.22.1-py3-none-any.whl'
inputs={'candidate':prior['candidate'],'stage':stage,'output':linux(OUT/'wsl-resumed.json'),'manifest':linux(mf),'manifest_sha256':hashlib.sha256(mf.read_bytes()).hexdigest(),'wheel':linux(wheel),'wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'windows_identity':linux(OUT/'plugin026-marketplace/PACKAGE-IDENTITY.json')}
run('wsl-resume-launch',[r'C:\Windows\System32\wsl.exe','-d','Ubuntu-24.04','--exec','python3','-c',program,json.dumps(inputs)],timeout=3600,allow=(0,1))
