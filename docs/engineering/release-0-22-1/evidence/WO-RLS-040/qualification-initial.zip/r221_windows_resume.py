from r221_session import *
import os
root=OUT/'windows-package';py=root/'wheel-env/Scripts/python.exe'
os.environ.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true')
for i in (1,2):
    run('win-upgrade-longpaths-'+str(i),[PYTHON,'-B','-m','repository_tools.upgrade_rehearsal','--repository',REPO,'--predecessor-python',GOV,'--successor-python',py,'--output',root/('upgrade-longpaths-'+str(i)),'--workspace',root,'--timings'],cwd=REPO,timeout=1200)
a=json.loads((root/'upgrade-longpaths-1/upgrade-rehearsal-result.json').read_text());b=json.loads((root/'upgrade-longpaths-2/upgrade-rehearsal-result.json').read_text())
assert a['overall_result']==b['overall_result']=='pass' and a['semantic_sha256']==b['semantic_sha256']
for file in ['tests/test_skill_ownership.py','tests/plugin_integration/test_simple_plugin.py']:
    os.environ['SE_HARNESS_TEST_PLUGIN_WHEEL']=str(OUT/'build/se_harness-0.22.1-py3-none-any.whl')
    os.environ['SE_HARNESS_TEST_PLUGIN_PYTHON']=str(py)
    run('win-package-'+Path(file).stem,[py,'-I','-B',REPO/file,'-v'],cwd=root,timeout=900)
probe=root/'draft-probe.py'
s=(REPO/'docs/engineering/hosted-artifact-graph/evidence/WO-HAG-002/qualify_correction_wheel.py').read_text()
s=s.replace("str(base.parent / 'se_harness')","str(Path("+repr(str(REPO))+"))")
probe.write_text(s,encoding='utf-8')
run('win-draft-probe',[PYTHON,'-B',probe,'--python',py,'--wheel',OUT/'build/se_harness-0.22.1-py3-none-any.whl','--commit',(OUT/'candidate-source.txt').read_text().strip()],timeout=600)
program="import json; from se_harness.engine import dashboard_bundle as b; assert b.TOPOLOGY_ACCEPTANCE_BYTES==4194304; values=[b.topology_target_exceeded(v) for v in (4194303,4194304,4194305)]; assert values==[False,False,True]; print(json.dumps({'target':b.TOPOLOGY_ACCEPTANCE_BYTES,'boundary_results':values,'origin':b.__file__}))"
run('win-installed-topology-boundary',[py,'-I','-c',program])
