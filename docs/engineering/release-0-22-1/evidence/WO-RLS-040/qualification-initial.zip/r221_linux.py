from r221_session import *
DOCKER=Path(r'C:\Users\mathi\AppData\Local\Programs\DockerDesktop\resources\bin\docker.exe')
IMAGE='python@sha256:2856e6af199e8128161abd320575eb9b341f3b76f017b5d0c9cd364f60d8a050'
output=OUT/'linux-full'; output.mkdir(exist_ok=False)
program="""import os,shutil,subprocess,sys
shutil.copytree('/input','/output/repository',ignore=shutil.ignore_patterns('__pycache__','.test-timings.json'))
os.chdir('/output/repository')
print(sys.version,flush=True)
subprocess.run(['git','config','core.autocrlf','false'],check=True)
subprocess.run(['git','rev-parse','HEAD'],check=True)
raise SystemExit(subprocess.call([sys.executable,'-B','scripts/run_tests.py','--scale','full','--workers','4']))
"""
run('linux-full-source',[DOCKER,'run','--rm','--network','none','--mount',f'type=bind,source={REPO},target=/input,readonly','--mount',f'type=bind,source={output},target=/output','-e','PYTHONDONTWRITEBYTECODE=1',IMAGE,'python','-B','-c',program],timeout=1800,allow=(0,1))
