"""Prepare an unapplied release-input correction after the real preview refused."""
import difflib, hashlib, json, subprocess, sys, tomllib, zipfile
import r221_session as s
s.OUT=s.WORK/'r221-delivery-20261005'
H='81144fb1e468b7302d0523672c346618cfcc9171'
C='4f640284ec496b88cd7aa4ba88ca537d9374a2f8'
SHA='50c97db22f33cdcf0eb44b229b5e1ab7d5afca887cca6ffb4a9e380bc8c3641b'
R=s.DOMAIN+'releases/RLS-SEH-033.md';E=s.DOMAIN+'evidence/WO-RLS-040/'
probe=s.WORK/'r221-owner-proposal-probe'
def git(*a):return subprocess.check_output(['git',*a],cwd=s.REPO,text=True).rstrip('\r\n')
mode=sys.argv[1]
if mode in ('probe','probe-resume','probe-bytes','probe-export'):
    assert git('rev-parse','HEAD')==H and not git('status','--porcelain')
    assert json.loads((s.OUT/'release-preview.json').read_text())['exit_code']==1
    if mode=='probe':
        assert not probe.exists()
        s.run('owner-probe-clone',['git','clone','--shared','--no-checkout',s.REPO,probe])
        s.run('owner-probe-checkout',['git','checkout','--detach',H],cwd=probe)
    elif mode=='probe-resume':
        assert probe.resolve()==(s.WORK/'r221-owner-proposal-probe').resolve()
        assert json.loads((s.OUT/'owner-probe-checkout.json').read_text())['exit_code']==128
        assert not (s.OUT/'owner-proposal-result.json').exists()
        s.run('owner-probe-checkout-longpaths',['git','-c','core.longpaths=true','checkout','--force','--detach',H],cwd=probe)
    elif mode=='probe-bytes':
        assert probe.resolve()==(s.WORK/'r221-owner-proposal-probe').resolve()
        assert json.loads((s.OUT/'owner-probe-checkout-longpaths.json').read_text())['exit_code']==0
        assert not (s.OUT/'owner-proposal-result.json').exists()
        a=(s.REPO/R).read_bytes();b=(probe/R).read_bytes();assert a==b.replace(b'\r\n',b'\n')
        (s.OUT/'owner-probe-line-ending-diagnostic.json').write_text(json.dumps({'real_crlf':a.count(b'\r\n'),'probe_crlf':b.count(b'\r\n'),'normalized_equal':True,'recovery':'set core.autocrlf=false in the disposable clone only and rehydrate exact Git blobs'})+'\n')
        s.run('owner-probe-exact-byte-config',['git','config','--local','core.autocrlf','false'],cwd=probe)
        s.run('owner-probe-exact-byte-checkout',['git','-c','core.longpaths=true','checkout-index','--all','--force'],cwd=probe)
    else:
        assert probe.resolve()==(s.WORK/'r221-owner-proposal-probe').resolve()
        assert not (s.OUT/'owner-proposal-result.json').exists()
        archive=s.OUT/'owner-probe-exact-source.zip';assert not archive.exists()
        s.run('owner-probe-git-archive',['git','archive','--format=zip','--output',archive,H],cwd=s.REPO)
        count=0
        with zipfile.ZipFile(archive) as z:
            for item in z.infolist():
                target=(probe/item.filename).resolve();assert target.is_relative_to(probe.resolve())
                assert ((item.external_attr>>16)&0o170000)!=0o120000
                if item.is_dir():target.mkdir(parents=True,exist_ok=True)
                else:
                    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(item));count+=1
        (s.OUT/'owner-probe-export.json').write_text(json.dumps({'tracked_files':count,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'source_commit':H,'purpose':'restore exact Git-blob bytes in the disposable checkout; existing checked-out files alone were replaced'})+'\n')
    old=(s.REPO/R).read_bytes();assert old==(probe/R).read_bytes() and old.count(b'owners = ["Codex"]')==1
    new=old.replace(b'owners = ["Codex"]',b'owners = ["mmzen"]',1)
    (probe/R).write_bytes(new)
    patch=''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+R,tofile='b/'+R))
    (s.OUT/'release-owner-correction.patch').write_bytes(patch.encode())
    s.gov('owner-proposal-validation','validate',repo=probe)
    s.gov('owner-proposal-transition-preview','transition','--set','RLS-SEH-033=released','--decision','RLS-SEH-033=mmzen','--reason','RLS-SEH-033=Diagnostic preview of the proposed release-owner correction only. The real human already approved the unchanged complete-release plan; the ownership correction and new review base remain unapplied and await explicit review.',repo=probe)
    assert (probe/R).read_bytes()==new and (s.REPO/R).read_bytes()==old
    assert tomllib.loads(new.decode().split('+++',2)[1])['status']=='ready'
    result={'proposal':'unapplied','before_sha256':hashlib.sha256(old).hexdigest(),'after_sha256':hashlib.sha256(new).hexdigest(),'candidate_commit':C,'frozen_plan_sha256':SHA,'changed_field':'owners','old':['Codex'],'proposed':['mmzen'],'prepared_by':'Codex','real_repository_unchanged':True,'preview_only':True}
    (s.OUT/'owner-proposal-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
elif mode=='retain':
    assert git('rev-parse','HEAD')==H and not git('status','--porcelain')
    old=(s.OUT/'RLS-SEH-033-before.md').read_bytes();assert (s.REPO/R).read_bytes()==old
    for name in ('owner-proposal-validation','owner-proposal-transition-preview'):
        assert json.loads((s.OUT/(name+'.json')).read_text())['exit_code']==0
    patch=s.REPO/E/'release-owner-correction.patch';assert not patch.exists();patch.write_bytes((s.OUT/patch.name).read_bytes())
    target=s.REPO/E/'release-owner-correction-checks.zip';assert not target.exists()
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for name in ('release-context.json','release-preview.json','RLS-SEH-033-before.md','owner-probe-clone.json','owner-probe-checkout.json','owner-probe-checkout-longpaths.json','owner-probe-line-ending-diagnostic.json','owner-probe-exact-byte-config.json','owner-probe-exact-byte-checkout.json','owner-probe-git-archive.json','owner-probe-export.json','owner-proposal-validation.json','owner-proposal-transition-preview.json','owner-proposal-result.json'):
            z.write(s.OUT/name,name)
        z.write(s.WORK/'r221_owner_correction.py','r221_owner_correction.py')
    review=s.REPO/E/'release-owner-correction-review.md';assert not review.exists()
    review.write_text('''# Correct the release owner and continue the approved release

mmzen has approved the complete evaluator 0.22.1 / plugin 0.2.6 release under
RLS-SEH-033. That decision remains valid evidence. Applying it failed before
any write: released evaluator 0.22.0 returns `WEX201` / `E009` because the release
record has `owners = ["Codex"]`, while `authorized_by` must belong to that list.
The record remains **ready**. No merge or public release action occurred.
The earlier transition gate check passed, but it did not construct and validate
the proposed final record. The exact transition preview should have run before
the final approval request; that preparation omission is retained here.

## Exact correction

Change one line in [RLS-SEH-033](../../releases/RLS-SEH-033.md):

```diff
-owners = ["Codex"]
+owners = ["mmzen"]
```

Keep `prepared_by = "Codex"`. mmzen is the accountable release human; Codex
remains the actual preparation agent. Preserve status, lifecycle history,
candidate, distributions, relations, body and all bound evidence. The exact
[patch](release-owner-correction.patch) is unapplied in the real checkout.

This is a correction of a ready release input under the existing release
preparation scope, not a product or evaluator implementation. No new binary,
test change or replacement release record is proposed.

## Diagnosis and checks

The released `transition` command has no owner-binding or ownership-edit option.
The separately implemented HAG decision fix applies to `decide` question/deviation
dispositions, not to RLS authorization. Running unreleased source as governor or
recording Codex as the human release decision-maker would not be a valid recovery.

In a separate disposable checkout at the exact review head, the one-line proposal
passes released 0.22.0 validation and a **read-only** release transition preview
as mmzen. No transition was applied there. [Raw evidence](release-owner-correction-checks.zip)
includes the original failed real preview, unchanged original RLS bytes, exact
commands and the passing proposal preview. Disposable-checkout setup first met
Windows path-length and line-ending issues; the retained recovery enabled long
paths and restored exact Git-blob bytes before validation. This proves the proposed input removes
the observed owner mismatch; it does not supply authority to apply it.

## Bounded amendment to the existing approval

Approve only this ownership correction and the following review-base update.
After approval, make a separate correction commit containing only the RLS line
above, on top of this published proposal. The resulting full commit becomes the
new pre-decision review base. Preserve the already approved frozen plan bytes and
SHA-256 `'''+SHA+'''`.

The corrected review base consists only of the previously reviewed release,
these three proposal/evidence files and the exact owner correction. Compare that
derivation before binding it. Then re-preview and apply the existing complete-
release decision through released evaluator 0.22.0 as mmzen, append the normal
release event, and bind the same plan to that corrected review base. The existing
publisher must accept the decision-only diff from that base.

This is an explicit amendment of the reviewed RLS ownership/base, not a silent
change or a gate waiver. The existing complete-release grant continues for all
unchanged payloads, destinations, receipt paths, recovery conditions and public
checks. Candidate `'''+C+'''`, evaluator 0.22.1,
plugin 0.2.6, the desktop limitation and adoption exclusions are unchanged.
Do not ask again for the unchanged release/publication authority.

**Response requested:** “Approve the owner correction and continue.”
Until that response, preserve the real RLS as ready and keep PR #536 draft.
''',encoding='utf-8',newline='\n')
    s.gov('owner-proposal-real-validation','validate')
    assert (s.REPO/R).read_bytes()==old
elif mode=='publish':
    assert git('rev-parse','HEAD')==H
    paths={E+'release-owner-correction.patch',E+'release-owner-correction-checks.zip',E+'release-owner-correction-review.md'}
    assert set(x[3:] for x in git('status','--porcelain').splitlines())==paths
    assert (s.REPO/R).read_bytes()==(s.OUT/'RLS-SEH-033-before.md').read_bytes()
    s.run('owner-proposal-stage',['git','add','--',*sorted(paths)],cwd=s.REPO)
    s.run('owner-proposal-commit',['git','commit','-m','Review release-owner correction after blocked complete-release preview'],cwd=s.REPO)
    head=git('rev-parse','HEAD');(s.OUT/'owner-proposal-head.txt').write_text(head+'\n')
    pr,_=s.run('owner-proposal-pr-before',['gh','pr','view','536','--repo','mmzen/se_harness','--json','headRefOid,headRefName,baseRefName,isDraft,state,body'])
    assert pr['headRefOid']==H and pr['baseRefName']=='main' and pr['isDraft'] and pr['state']=='OPEN'
    body=pr['body'].replace('**VREC-SEH-033 and VREC-RLS-003 are verified by mmzen. RLS-SEH-033 is ready. The next decision is “Approve the complete release.” Keep this PR draft until that decision.**','**mmzen approved the complete release. Its transition preview was blocked by WEX201 / E009: the RLS preparation owner is Codex, but the actual release human is mmzen. RLS-SEH-033 remains ready. Keep this PR draft while the exact owner correction and review-base amendment are reviewed.**')
    body+='\n[One-line owner correction proposal](https://github.com/mmzen/se_harness/blob/'+head+'/'+E+'release-owner-correction-review.md). A disposable-checkout preview passes; the real RLS is unchanged. Existing complete-release approval is retained, not reapplied or broadened. No merge/publication occurred. The next response is **Approve the owner correction and continue**, covering only this explicit input/base amendment.\n'
    body=body.replace('No release decision, merge, version tag, GitHub/PyPI publication, public marketplace update, Pages deployment or latest/last promotion has occurred for 0.22.1 / 0.2.6. The requested final grant fixes all actions and recovery bounds; successful checks alone do not grant authority.','The human complete-release decision has been supplied, but its lifecycle transition is blocked by the owner mismatch described below. No merge, version tag, GitHub/PyPI publication, public marketplace update, Pages deployment or latest/last promotion has occurred for 0.22.1 / 0.2.6. The supplied grant is retained; successful checks alone do not grant authority.')
    bp=s.OUT/'owner-proposal-pr-body.md';bp.write_text(body,encoding='utf-8',newline='\n')
    event=s.OUT/'owner-proposal-pr-event.json';event.write_text(json.dumps({'pull_request':{'body':body}})+'\n')
    s.gov('owner-proposal-full-pr-check','check-pr','--event',event,'--from-git',s.BASE)
    s.run('owner-proposal-push',['git','push','origin',head+':refs/heads/codex/release-0-22-1'],cwd=s.REPO)
    s.run('owner-proposal-pr-update',['gh','pr','edit','536','--repo','mmzen/se_harness','--body-file',bp])
    d,_=s.run('owner-proposal-remote',['gh','pr','view','536','--repo','mmzen/se_harness','--json','headRefOid,baseRefName,isDraft,state,body'])
    assert d['headRefOid']==head and d['baseRefName']=='main' and d['isDraft'] and d['body'].strip()==body.strip()
    print(json.dumps({'review_commit':head,'rls_status':'ready','correction':'unapplied','release_approval':'retained','next':'explicit owner/base amendment'}))
