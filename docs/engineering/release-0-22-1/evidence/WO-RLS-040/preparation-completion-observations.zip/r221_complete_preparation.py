"""Complete only the approved preparation work after its actual handoff checks."""
import hashlib,json,subprocess,sys,zipfile
import r221_session as s
s.OUT=s.WORK/'r221-continue-20261005'
root=s.REPO/s.DOMAIN
ids=('WO-RLS-040','WO-RLS-041','WO-RLS-043')
event=s.OUT/'preparation-completion-pr-event.json'
reason='Codex records approved local preparation completion. Corrected source 061307929c94314ccd2beb4a53f174e536fceba8 passed retained Windows/Linux, installed-package and native CLI qualification. The checked 69-file marketplace child is prepared locally. Actual mmzen desktop omission/risk acceptance and exact provider activation are retained. Final committed-candidate capture and matching build/staging qualification follow separately; this supplies no verification, merge or release decision.'
args=['transition']
for aid in ids:args+=['--set',aid+'=implemented','--decision',aid+'=Codex','--reason',aid+'='+reason]
mode=sys.argv[1]
if mode=='handoff':
    event.write_text(json.dumps({'pull_request':{'body':'Harness-Work-Orders: '+', '.join(ids)}})+'\n')
    archived=root/'evidence/WO-RLS-040/pre-completion-packets.zip';assert not archived.exists()
    with zipfile.ZipFile(archived,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for aid in ids:
            for p in (root/'evidence'/aid).glob(aid+'-*.md'):z.writestr(p.relative_to(root).as_posix(),p.read_bytes())
    for aid in ids:
        s.gov('preparation-evidence-'+aid,'evidence','--artifact',aid,'--checkpoint','handoff')
        p=root/'evidence'/aid/(aid+'-handoff.md')
        header=p.read_text(encoding='utf-8').split('```',2)
        assert len(header)==3
        p.write_text('```'+header[1]+'''```

# Preparation handoff

The approved release inputs and corrected implementation are prepared. Actual
checks for source 061307929c94314ccd2beb4a53f174e536fceba8 are retained in
../WO-RLS-043/corrected-qualification-review.md and its immutable archives.
Windows/Linux source, installed packages, both HAG fixes, the original draft
transition defect, deterministic builds, upgrades and native CLI cycles pass.
Original failures and reported skips remain visible.

../WO-RLS-041/preparation-marketplace-commit.json records the checked ordinary
marketplace child and exact 69-file tree. It is local preparation, not a public
marketplace update. Final candidate capture must retain its own exact build,
staging identities and applicable checks; earlier tests are not relabelled.

../WO-RLS-041/desktop-deferral-review.md records mmzen's accepted DEC-RLS-009
and RISK-RLS-007. Codex Windows desktop remains not run / unverified for this
release. CLI/public-route checks and later human verification remain required.
../WO-RLS-040/provider-configuration-applied.json retains the separately
authorized exact GitHub activation and human PyPI binding confirmation.

This handoff supports implementation completion and final verification
preparation. It supplies no human verification, merge, release or adoption.
''',encoding='utf-8',newline='\n')
        s.gov('preparation-review-'+aid,'preflight','--work-order',aid,'--phase','review')
    s.gov('preparation-preaction-evidence','evidence','--artifact','WO-RLS-040','--checkpoint','pre-action')
    s.gov('preparation-union-handoff','check-pr','--event',event,'--from-git',s.BASE)
    s.gov('preparation-completion-preview',*args)
elif mode=='apply':
    prior=json.loads(json.loads((s.OUT/'preparation-completion-preview.json').read_text())['stdout'])
    assert prior['operation']['outcome']=='completed'
    assert not prior['findings']['scoped_blockers'] and not prior['findings']['repository_blockers']
    assert {v['id'] for v in prior['mutation']['writes']}==set(ids)
    s.gov('preparation-completion-apply',*args,'--apply')
    for aid in ids:s.gov('completed-context-'+aid,'check','--artifact',aid)
elif mode=='commit':
    archive=root/'evidence/WO-RLS-040/preparation-completion-observations.zip';assert not archive.exists()
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(s.OUT.glob('preparation-*.json')):z.writestr(p.name,p.read_bytes())
        for p in sorted(s.OUT.glob('completed-context-*.json')):z.writestr(p.name,p.read_bytes())
        for name in ('r221_complete_preparation.py','r221_readiness_closeout.py','r221_staging_commit.py'):
            p=s.WORK/name;z.writestr(p.name,p.read_bytes())
    p=root/'README.md';text=p.read_text(encoding='utf-8')
    text=text.replace('Status: **preparation approved by mmzen; qualification in progress**.','Status: **preparation implemented; final candidate verification pending**.')
    text=text.replace('Both work orders remain in progress.', 'WO-RLS-040/041/043 have implementation completion recorded; assurance remains pending.')
    text=text.replace('The work orders remain in progress until the required\nhandoff and completion checks pass.', 'The required handoff and completion checks passed; the work orders are\n`implemented`. Final candidate capture has not yet supplied human verification.')
    p.write_text(text,encoding='utf-8',newline='\n')
    s.gov('candidate-scope','check-pr','--event',event,'--from-git',s.BASE)
    s.gov('candidate-preaction','check','--artifact','WO-RLS-040','--checkpoint','pre-action','--from-git',s.BASE)
    names=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=s.REPO,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=s.REPO,text=True).splitlines()
    assert names and all(p.startswith(s.DOMAIN) for p in names),names
    s.run('candidate-stage',['git','add','--',s.DOMAIN],cwd=s.REPO)
    s.run('candidate-diff-check',['git','diff','--cached','--check'],cwd=s.REPO)
    s.run('candidate-commit',['git','commit','-m','Complete 0.22.1 preparation with accepted desktop limit','-m','Harness-Work-Orders: WO-RLS-040, WO-RLS-041, WO-RLS-043'],cwd=s.REPO)
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=s.REPO,text=True).strip()
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=s.REPO,text=True).strip()
    out=s.WORK/'r221-final-20261005';out.mkdir(exist_ok=False)
    (out/'candidate-source.txt').write_text(head+'\n')
    print(json.dumps({'final_candidate':head}))
else:raise SystemExit(mode)
