"""Retain the supplied desktop decision and current provider observations."""
import hashlib,json,zipfile,sys
import r221_session as s
s.OUT=s.WORK/'r221-continue-20261005'
root=s.REPO/s.DOMAIN
mode=sys.argv[1]
if mode=='retain':
    rows=['desktop-accept-preview','desktop-accept-apply','desktop-accepted-context','desktop-accepted-validation','desktop-accepted-wo041','recovered-wo041']
    dest=root/'evidence/WO-RLS-041/desktop-acceptance-observations.zip'
    assert not dest.exists()
    with zipfile.ZipFile(dest,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for name in rows:
            p=s.OUT/(name+'.json');z.writestr(p.name,p.read_bytes())
        p=s.WORK/'r221_accept_desktop.py';z.writestr(p.name,p.read_bytes())
    review=root/'evidence/WO-RLS-041/desktop-deferral-review.md'
    original=review.read_bytes()
    (s.OUT/'desktop-deferral-review-before-acceptance.md').write_bytes(original)
    text=original.decode('utf-8')
    text=text.replace('**Requested decision:** Accept DEC-RLS-009 and its paired RISK-RLS-007 for the\nevaluator 0.22.1 / plugin 0.2.6 release only.', '**Recorded decision:** mmzen accepted DEC-RLS-009 and its paired RISK-RLS-007\nfor evaluator 0.22.1 / plugin 0.2.6 only: "Accept the bounded desktop omission and risk".')
    text=text.replace('Your request to prepare\nthis proposal has not been recorded as acceptance.', 'The released 0.22.0 evaluator recorded the decision as `decided` and the paired\nrisk as `accepted`. Neither result claims a passing desktop test.')
    text=text.replace('| If accepted | Still required |','| Accepted boundary | Still required |')
    text=text.replace('The alternative is to keep qualification pending until the desktop tests pass.\nThe formal [decision](../../decisions/DEC-RLS-009.md) is open and its\n[risk](../../risks/RISK-RLS-007.md) is raised.', 'The formal [decision](../../decisions/DEC-RLS-009.md) is `decided`; its\n[risk](../../risks/RISK-RLS-007.md) is `accepted`. The [acceptance observations](desktop-acceptance-observations.zip)\nretain the exact preview, apply and readback. The original proposal remains in\n[its preparation archive](desktop-proposal-preparation.zip).')
    review.write_text(text,encoding='utf-8',newline='\n')
    overview=root/'README.md'
    text=overview.read_text(encoding='utf-8')
    text=text.replace('checks, and remaining desktop/provider criteria.', 'checks and the then-pending desktop/provider criteria. Those three readiness\nitems are now resolved as recorded below; the original report remains a historical snapshot.')
    pos=text.index('## Known dependencies')
    text=text[:pos]+'''## Desktop decision and provider readiness

mmzen accepted [DEC-RLS-009 and RISK-RLS-007](evidence/WO-RLS-041/desktop-deferral-review.md)
for this release only. Codex Windows desktop remains **not run / unverified**;
CLI evidence does not replace it. Revisit before the next plugin release or any
verified-desktop claim, whichever comes first. Required CLI and public-route
checks, human verification and the final complete-release decision remain intact.

The separately authorized [pypi environment change](evidence/WO-RLS-040/provider-configuration-applied.json)
removed only the required reviewer. Readback confirms main-only deployment,
main protections and workflow permissions are unchanged. mmzen confirmed the
four PyPI Trusted Publisher fields. This is human account-side confirmation,
not an authenticated PyPI read by the agent. No release was dispatched.

The next preparation work is the exact marketplace staging commit and final
candidate verification. The work orders remain in progress until the required
handoff and completion checks pass. This update supplies no verification,
merge, release or adoption decision.

'''+text[pos:]
    text=text.replace('Earlier\nrelease-specific omissions are not accepted for this release.', 'The bounded desktop omission for this release is recorded above; older\nrelease-specific omissions remain historical.')
    overview.write_text(text,encoding='utf-8',newline='\n')
    print(json.dumps({'decision':'DEC-RLS-009','risk':'RISK-RLS-007','archive_sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}))
elif mode=='checks':
    s.gov('readiness-retained-validation','validate')
    for aid in ('WO-RLS-040','WO-RLS-041','WO-RLS-043'):
        s.gov('readiness-context-'+aid,'check','--artifact',aid)
    s.run('marketplace-current',['git','ls-remote','origin','refs/heads/plugin-marketplace','refs/heads/codex/plugin-0-2-6-staging'],cwd=s.REPO)
else:raise SystemExit(mode)
