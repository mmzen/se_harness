"""Same checks in a clean runtime; retain the first runtime refusal unchanged."""
from pathlib import Path
p=Path(__file__).with_name('r221_final_capture_checks.py')
text=p.read_text().replace("'capture-candidate-check.json'", "'capture-candidate-check-clean.json'")
exec(compile(text,str(p),'exec'))
