"""Retry the unapplied capture with only its test-runtime defect corrected."""
from pathlib import Path
p=Path(__file__).with_name('r221_final_capture.py')
text=p.read_text().replace("s.PYTHON,'-B'", "s.OUT/'capture-source-env/Scripts/python.exe','-B'")
text=text.replace("'r221_final_capture_checks.py'", "'r221_final_capture_checks_clean.py'")
text=text.replace("s.run('final-capture'", "s.run('final-capture-clean'")
exec(compile(text,str(p),'exec'))
