"""Prepare the aggregate record using the selected released governor."""
import hashlib,json,subprocess,tomllib
import r221_session as s
s.OUT=s.WORK/'r221-final-20261005'
C=(s.OUT/'candidate-source.txt').read_text().strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s.REPO,text=True).strip()==C
assert not subprocess.check_output(['git','status','--porcelain'],cwd=s.REPO,text=True).strip()
assert not subprocess.check_output(['git','log','--all','--format=','--name-only','--','**/VREC-SEH-033.md'],cwd=s.REPO,text=True).strip()
work=['WO-HAG-002','WO-HAG-003','WO-DST-028','WO-RLS-040','WO-RLS-041','WO-RLS-043']
ver=['VER-HAG-002','VER-HAG-003','VER-DST-030','VER-RLS-036','VER-RLS-037','VER-RLS-004','VER-IAR-021']
declared=set()
for wid in work:
    paths=list((s.REPO/'docs/engineering').rglob(wid+'.md'));assert len(paths)==1
    data=tomllib.loads(paths[0].read_text().split('+++',2)[1]);assert data['status']=='implemented'
    declared.update(data['relations']['verification'])
assert declared==set(ver)
evidence=[s.DOMAIN+x for x in (
 'evidence/WO-RLS-040/provider-configuration-applied.json',
 'evidence/WO-RLS-040/provider-activation-observations.zip',
 'evidence/WO-RLS-040/preparation-completion-observations.zip',
 'evidence/WO-RLS-041/desktop-deferral-review.md',
 'evidence/WO-RLS-041/desktop-acceptance-observations.zip',
 'evidence/WO-RLS-043/corrected-qualification-review.md',
 'evidence/WO-RLS-043/corrected-runtime.zip',
 'evidence/WO-RLS-043/corrected-native.zip',
 'evidence/WO-RLS-043/amendment.json')]
for rel in evidence:assert (s.REPO/rel).is_file(),rel
receipt=s.OUT/'final-evidence-receipt.json';digest=hashlib.sha256(receipt.read_bytes()).hexdigest()
args=['capture-verification','--id','VREC-SEH-033','--owner','Codex','--domain','release-0-22-1','--candidate-commit',C]
for wid in work:args+=['--work-order',wid]
for vid in ver:args+=['--verification',vid]
for ev in evidence:args+=['--evidence',ev]
# Keep JSON before the remainder-style test-command.
args+=['--json','--test-command',s.PYTHON,'-B','-X','utf8',s.WORK/'r221_final_capture_checks.py',C,receipt,digest]
s.run('final-capture',[s.GOV,'-I','-m','se_harness',args[0],s.REPO,*args[1:]],timeout=3600)
