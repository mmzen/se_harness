import json
import subprocess
import sys
from r221_session import *

mode=sys.argv[1]
if mode=='normalize-and-commit':
    modified=subprocess.check_output(['git','diff','--name-only'],cwd=REPO,text=True).splitlines()
    targets=modified+[DOMAIN+'README.md',DOMAIN+'evidence/WO-RLS-040/approval.json',DOMAIN+'evidence/WO-RLS-040/integration.json']
    for p in targets:
        assert not p.startswith('docs/engineering/hosted-artifact-graph/'),p
        path=REPO/p
        raw=path.read_bytes()
        if b'\r\n' in raw: path.write_bytes(raw.replace(b'\r\n',b'\n'))
    run('whitespace-corrected',['git','diff','--check'],cwd=REPO)
    run('document-tests',[PYTHON,'-B','-X','utf8','-m','unittest','tests.test_progressive_documentation','tests.plugin_integration.package_assembly.test_refresh_guidance'],cwd=REPO,allow=(0,1))
elif mode=='commit':
    current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
    assert current==BASE
    # Approved formal files retain their complete CRLF bytes. Recognize CRLF
    # as a line ending for this diagnostic; retain all other whitespace checks.
    run('stage-inputs-final',['git','add','--all'],cwd=REPO)
    run('staged-edit-whitespace',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check','--','.',':(exclude)docs/engineering/hosted-artifact-graph/'],cwd=REPO)
    retained=json.loads((OUT/'transport-hag-bindings.json').read_text())['paths']
    for p,digest in retained.items():
        raw=subprocess.check_output(['git','show',':'+p],cwd=REPO)
        assert hashlib.sha256(raw).hexdigest()==digest,p
    run('commit-inputs',['git','commit','-m','Prepare isolated 0.22.1 evaluator and 0.2.6 plugin candidate'],cwd=REPO)
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
    (OUT/'candidate-source.txt').write_text(head+'\n')
    print(json.dumps({'candidate_source':head}))
elif mode=='windows':
    run('windows-full-source',[PYTHON,'-B','-X','utf8','scripts/run_tests.py','--scale','full'],cwd=REPO,timeout=1800,allow=(0,1))
elif mode=='distribution':
    run('distribution-checks',[PYTHON,'-B','-X','utf8','scripts/validate_release_distributions.py','--root','.'],cwd=REPO,timeout=900)
    run('cli-smoke',[PYTHON,'-B','-X','utf8','-m','se_harness','--help'],cwd=REPO)
elif mode=='build':
    head=(OUT/'candidate-source.txt').read_text().strip()
    run('pinned-build',[PYTHON,'-B','-X','utf8','-m','repository_tools.release_build','replay','--repository',REPO,'--commit',head,'--version','0.22.1','--output-directory',OUT/'build','--result',OUT/'build-replay.json'],cwd=REPO,timeout=1800)
