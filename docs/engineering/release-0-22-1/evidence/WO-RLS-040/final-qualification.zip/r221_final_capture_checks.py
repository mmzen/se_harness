"""Check immutable retained observations and freshly qualify the named checkout."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,zipfile

C,receipt_name,expected=sys.argv[1:]
p=Path(receipt_name);raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==expected
r=json.loads(raw);assert r['candidate']==C
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==C
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
for row in r['files']:
    raw=(p.parent/row['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==row['sha256'],row['path']
for archive in r['archives']:
    raw=(p.parent/archive['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==archive['sha256']
    with zipfile.ZipFile(p.parent/archive['path']) as z:
        for row in archive['entries']:
            assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
assert r['assessment']['required_automated_and_cli_checks_passed']
assert r['assessment']['desktop']=='not run / unverified; accepted release-only omission DEC-RLS-009 / RISK-RLS-007'
env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1')
env.pop('PYTHONPATH',None)
argv=[sys.executable,'-B','-X','utf8','-m','se_harness','qualify','complete-candidate','.', '--candidate-commit',C,'--json']
q=subprocess.run(argv,env=env,capture_output=True,text=True,encoding='utf-8',timeout=900)
record={'argv':argv,'cwd':str(Path.cwd()),'exit_code':q.returncode,'stdout':q.stdout,'stderr':q.stderr}
out=p.parent/'capture-candidate-check.json';assert not out.exists();out.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
assert q.returncode==0,q.stdout+q.stderr
print(json.dumps({'candidate':C,'retained_final_receipt_sha256':expected,'archive_digests':{a['path']:a['sha256'] for a in r['archives']},'assessment':r['assessment'],'fresh_complete_candidate':json.loads(q.stdout),'limits':'Evidence was collected at this exact candidate after it was committed. Its digest is bound by this test invocation and the generated VREC; the byte-identical receipt and raw archive are retained in the later review commit. Source-equivalent earlier native boundary/walkthrough evidence keeps its original identity. No human verification, release, desktop or hosted-service pass is supplied.'},sort_keys=True))
