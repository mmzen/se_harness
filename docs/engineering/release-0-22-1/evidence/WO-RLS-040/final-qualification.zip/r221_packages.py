from r221_session import *
import os

mode=sys.argv[1]
manifest=json.loads((OUT/'build-replay.json').read_text())['manifest']
C=manifest['commit']; wheel=OUT/'build'/manifest['wheel']; sdist=OUT/'build'/manifest['sdist']
assert hashlib.sha256(wheel.read_bytes()).hexdigest()==manifest['wheel_sha256']
assert hashlib.sha256(sdist.read_bytes()).hexdigest()==manifest['sdist_sha256']
if mode=='stage':
    mf=OUT/'bundle.json'
    assert not mf.exists()
    mf.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8',newline='\n')
    common=['--repository',REPO,'--revision',C,'--candidate-manifest',mf,'--expected-manifest-sha256',hashlib.sha256(mf.read_bytes()).hexdigest(),'--expected-wheel-sha256',manifest['wheel_sha256'],'--wheel',wheel,'--evaluator-python',GOV,'--output-directory',OUT/'plugin026-marketplace']
    for action in ('stage','check-stage'):
        run('plugin-'+action,[PYTHON,'-B','-X','utf8',REPO/'scripts/build_plugin_marketplace.py',action,*common],timeout=900)
elif mode=='windows':
    root=OUT/'windows-package';root.mkdir(exist_ok=False)
    py=root/'wheel-env/Scripts/python.exe';bp=root/'sdist-env/Scripts/python.exe'
    run('win-package-qualification',[GOV,'-I','-m','se_harness','qualify','candidate-package','--candidate-wheel',wheel,'--candidate-commit',C,'--candidate-wheel-sha256',manifest['wheel_sha256'],'--verifier-wheel-sha256','44543f242ed19bb30cfd65da415372a87508a6e439204d7f3e37f9f45aefe4e4','--checkout-root',REPO,'--output',root/'qualification.json','--json'],timeout=900)
    for kind,p in [('wheel',py),('sdist',bp)]:
        run('win-'+kind+'-venv',[PYTHON,'-m','venv',p.parent.parent])
        if kind=='sdist':
            run('win-sdist-tools',[p,'-m','pip','install','--disable-pip-version-check','--only-binary=:all:','--require-hashes','-r',REPO/'release/build-toolchain.lock'])
            run('win-sdist-install',[p,'-m','pip','install','--no-index','--no-deps','--no-build-isolation','--no-binary=se-harness','--find-links',OUT/'build','se-harness==0.22.1'],timeout=900)
        else: run('win-wheel-install',[p,'-m','pip','install','--no-index','--no-deps',wheel])
        run('win-'+kind+'-identity',[p,'-I','-m','se_harness','identity','--role','candidate-package','--expected-version','0.22.1','--expected-root',p.parent.parent,'--checkout-root',REPO,'--candidate-commit',C,'--require-isolated-python','--json'])
        for cmd in ('init','doctor','validate'):
            run('win-'+kind+'-'+cmd,[p,'-I','-m','se_harness',cmd,root/(kind+'-fixture'),'--json'])
    probe=REPO/'docs/engineering/hosted-artifact-graph/evidence/WO-HAG-003/installed_probe.py'
    run('win-decision-probe',[py,'-I',probe],timeout=600)
    for i in (1,2):
        run('win-upgrade-'+str(i),[PYTHON,'-B','-m','repository_tools.upgrade_rehearsal','--repository',REPO,'--predecessor-python',GOV,'--successor-python',py,'--output',root/('upgrade-'+str(i)),'--workspace',root,'--timings'],cwd=REPO,timeout=1200)
    a=json.loads((root/'upgrade-1/upgrade-rehearsal-result.json').read_text());b=json.loads((root/'upgrade-2/upgrade-rehearsal-result.json').read_text())
    assert a['overall_result']==b['overall_result']=='pass' and a['semantic_sha256']==b['semantic_sha256']
    for filename in ['tests/test_draft_validation.py','tests/test_relation_policy.py','tests/test_skill_ownership.py']:
        run('win-installed-'+Path(filename).stem,[py,'-I','-B',REPO/filename,'-v'],cwd=root,timeout=900)
    os.environ['SE_HARNESS_TEST_PLUGIN_WHEEL']=str(wheel)
    os.environ['SE_HARNESS_TEST_PLUGIN_PYTHON']=str(py)
    run('win-installed-simple-plugin',[py,'-I','-B',REPO/'tests/plugin_integration/test_simple_plugin.py','-v'],cwd=root,timeout=900)
