"""Qualify the final candidate in a fresh namespace without replacing prior results."""
import os,sys
import r221_session as s
s.OUT=s.WORK/'r221-final-20261005'
mode=sys.argv[1]
if mode in ('source','distribution','build','stage','windows','linux-prepare','linux-test'):
    text=(s.WORK/'r221_fix043_run.py').read_text(encoding='utf-8')
    text=text.replace("session.WORK/'r221-fix043-20261005'", "session.WORK/'r221-final-20261005'")
    sys.argv=[str(s.WORK/'r221_fix043_run.py'),mode]
    exec(compile(text,str(s.WORK/'r221_fix043_run.py'),'exec'),{'__name__':'__main__','__file__':str(s.WORK/'r221_fix043_run.py')})
elif mode in ('extra-windows','extra-linux'):
    text=(s.WORK/'r221_fix043_extra.py').read_text(encoding='utf-8')
    text=text.replace("session.WORK/'r221-fix043-20261005'", "session.WORK/'r221-final-20261005'")
    sys.argv=[str(s.WORK/'r221_fix043_extra.py'),mode.removeprefix('extra-')]
    exec(compile(text,str(s.WORK/'r221_fix043_extra.py'),'exec'),{'__name__':'__main__','__file__':str(s.WORK/'r221_fix043_extra.py')})
else:raise SystemExit(mode)
