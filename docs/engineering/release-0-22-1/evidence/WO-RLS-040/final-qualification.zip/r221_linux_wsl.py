from r221_session import *
mode=sys.argv[1]
C=(OUT/'candidate-source.txt').read_text().strip()
bundle=OUT/'linux-history.bundle'
wheel=OUT/'build/se_harness-0.22.1-py3-none-any.whl'
prior=Path(r'C:\Users\mathi\.codex\plugins\cache\se-harness\verity-plane\0.2.5\packages\se_harness-0.22.0-py3-none-any.whl')
def linux(p): return '/mnt/c/'+p.as_posix()[3:]
if mode=='prepare':
    run('linux-history-bundle',['git','bundle','create',bundle,'codex/release-0-22-1','--tags'],cwd=REPO)
elif mode=='test':
    program=r'''import hashlib,json,os,pathlib,platform,subprocess,sys,tempfile,time
i=json.loads(sys.argv[1]);stage=pathlib.Path(tempfile.mkdtemp(prefix='r221-'));source=stage/'source';rows=[]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1');env.pop('PYTHONPATH',None)
dest=pathlib.Path(i['output'])
result={'candidate':i['candidate'],'platform':platform.platform(),'python':sys.version,'commands':rows,'passed':False,'stage':str(stage)}
def run(label,args,cwd=stage):
 t=time.time();p=subprocess.run(list(map(str,args)),cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=1800)
 rows.append(dict(label=label,argv=list(map(str,args)),cwd=str(cwd),exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr,seconds=round(time.time()-t,2)))
 dest.write_text(json.dumps(result,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode:raise RuntimeError(label+': '+p.stderr[-1000:])
 return p
try:
 run('clone',['git','clone','--branch','codex/release-0-22-1',i['bundle'],source])
 run('tags',['git','fetch',i['bundle'],'refs/tags/*:refs/tags/*'],source)
 run('origin',['git','remote','set-url','origin','https://github.com/mmzen/se_harness.git'],source)
 assert run('head',['git','rev-parse','HEAD'],source).stdout.strip()==i['candidate']
 for name,w in [('current',i['wheel']),('prior',i['prior'])]:
  assert hashlib.sha256(pathlib.Path(w).read_bytes()).hexdigest()==i[name+'_sha256']
  run(name+'-venv',[sys.executable,'-m','venv',stage/name]);p=stage/name/'bin/python'
  run(name+'-install',[p,'-m','pip','install','--no-index','--no-deps',w])
 py=stage/'current/bin/python';old=stage/'prior/bin/python'
 run('source-full',[py,'-B','scripts/run_tests.py','--scale','full','--workers','4'],source)
 run('distribution',[py,'-B','scripts/validate_release_distributions.py','--root','.'],source)
 run('identity',[py,'-I','-m','se_harness','identity','--role','candidate-package','--expected-version','0.22.1','--expected-root',stage/'current','--checkout-root',source,'--candidate-commit',i['candidate'],'--require-isolated-python','--json'])
 for cmd in ('init','doctor','validate'):run('installed-'+cmd,[py,'-I','-m','se_harness',cmd,stage/'minimal','--json'])
 run('decision-probe',[py,'-I',source/'docs/engineering/hosted-artifact-graph/evidence/WO-HAG-003/installed_probe.py'])
 for f in ('tests/test_draft_validation.py','tests/test_relation_policy.py','tests/test_skill_ownership.py'):run('installed-'+pathlib.Path(f).stem,[py,'-I','-B',source/f,'-v'])
 env['SE_HARNESS_TEST_PLUGIN_WHEEL']=i['wheel'];env['SE_HARNESS_TEST_PLUGIN_PYTHON']=str(py)
 run('installed-simple-plugin',[py,'-I','-B',source/'tests/plugin_integration/test_simple_plugin.py','-v'])
 for n in (1,2):run('upgrade-'+str(n),[py,'-B','-m','repository_tools.upgrade_rehearsal','--repository',source,'--predecessor-python',old,'--successor-python',py,'--output',stage/('upgrade-'+str(n)),'--workspace',stage,'--timings'],source)
 a=json.loads((stage/'upgrade-1/upgrade-rehearsal-result.json').read_text());b=json.loads((stage/'upgrade-2/upgrade-rehearsal-result.json').read_text())
 assert a['overall_result']==b['overall_result']=='pass' and a['semantic_sha256']==b['semantic_sha256']
 result['upgrades']=[a,b];result['passed']=True
except Exception as e:result['error']=repr(e)
dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'passed':result['passed'],'error':result.get('error')}));sys.exit(0 if result['passed'] else 1)
'''
    inputs={'candidate':C,'bundle':linux(bundle),'wheel':linux(wheel),'prior':linux(prior),'current_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'prior_sha256':'44543f242ed19bb30cfd65da415372a87508a6e439204d7f3e37f9f45aefe4e4','output':linux(OUT/'wsl-qualification.json')}
    run('wsl-qualification-launch',[r'C:\Windows\System32\wsl.exe','-d','Ubuntu-24.04','--exec','python3','-c',program,json.dumps(inputs)],timeout=3600,allow=(0,1))
