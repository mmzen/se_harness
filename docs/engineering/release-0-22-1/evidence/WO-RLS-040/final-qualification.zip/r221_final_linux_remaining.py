"""Finish untouched checks; preserve successful checks and both fixture refusals."""
import json,sys
import r221_session as s
s.OUT=s.WORK/'r221-final-20261005'
prior=json.loads((s.OUT/'wsl-extra.json').read_text())
assert prior['candidate']==(s.OUT/'candidate-source.txt').read_text().strip()
assert [r['label'] for r in prior['commands'][:2]]==['installed-draft-cli','installed-topology']
assert all(r['exit_code']==0 for r in prior['commands'][:2])
src=s.WORK/'r221_fix043_extra.py'
text=src.read_text().replace("session.WORK/'r221-fix043-20261005'", "session.WORK/'r221-final-20261005'")
text=text.replace("fixture=Path(r'C:\\Users\\mathi\\AppData\\Local\\Temp\\r221-claude-flow\\one')", "fixture=OUT/'restored-before-fixture'")
text=text.replace('wsl-extra.json','wsl-extra-completed.json').replace('corrected-linux.json','corrected-linux-restored.json').replace("'wsl-extra-launch'","'wsl-extra-completed-launch'")
text=text.replace(" run('installed-draft-cli',[sys.executable,probe,'--python',py,'--wheel',i['wheel'],'--commit',i['candidate']])", " # Already passed at this exact candidate; preserved in wsl-extra.json.")
text=text.replace(" run('installed-topology',[py,'-I','-c',i['topology']])", " # Already passed at this exact candidate; preserved in wsl-extra.json.")
text=text.replace(" run('sdist-env'", " assert not (stage/'sdist-env').exists() and not (stage/'plugin-stage').exists()\n run('sdist-env'")
sys.argv=[str(src),'linux']
exec(compile(text,str(src),'exec'))
