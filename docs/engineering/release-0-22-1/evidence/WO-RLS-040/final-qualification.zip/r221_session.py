"""Transient release orchestration outside governed repositories."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

WORK=Path(__file__).resolve().parent
SOURCE=WORK/'hag'
REPO=WORK/'r221'
OUT=WORK/'r221-session-20261004'
GOV=Path(r'C:\Users\mathi\.codex\plugins\data\verity-plane-se-harness\evaluators\0.22.0\44543f242ed19bb30cfd65da415372a87508a6e439204d7f3e37f9f45aefe4e4\Scripts\python.exe')
PYTHON=Path(r'C:\Users\mathi\AppData\Local\Python\pythoncore-3.14-64\python.exe')
BASE='82f5a0ed7438a73da8f03aee23ad02a9b8cc09e1'
HAG_HEAD='64b4feb0cbaff06111876a1d4c0cc35a6c814415'
DOMAIN='docs/engineering/release-0-22-1/'
OUT.mkdir(exist_ok=True)

def run(name,args,cwd=WORK,timeout=900,allow=(0,)):
    path=OUT/(name+'.json')
    assert not path.exists(),path
    began=datetime.datetime.now(datetime.timezone.utc).isoformat()
    r=subprocess.run([str(x) for x in args],cwd=cwd,capture_output=True,encoding='utf-8',errors='replace',timeout=timeout)
    record={'argv':[str(x) for x in args],'cwd':str(cwd),'observed_at':began,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
    path.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    try: data=json.loads(r.stdout)
    except ValueError: data={}
    summary={k:data[k] for k in ('operation','state','findings','restitution','error_count','warning_count','errors') if k in data}
    if not summary: summary={'stdout':r.stdout[-1200:],'stderr':r.stderr[-1500:]}
    print(json.dumps({'name':name,'exit':r.returncode,'record':str(path),'summary':summary}),flush=True)
    assert r.returncode in allow,(name,r.returncode,r.stderr)
    return data,r

def gov(name,*args,repo=REPO,allow=(0,)):
    return run(name,[GOV,'-I','-m','se_harness',args[0],repo,*args[1:],'--json'],allow=allow)

if __name__=='__main__':
    if sys.argv[1]=='gov': gov(sys.argv[2],*sys.argv[3:])
