"""Freeze final evidence outside the clean candidate for committed capture."""
from pathlib import Path
import hashlib,json,re,zipfile
import r221_session as s
p=s.WORK/'r221-final-20261005';C=(p/'candidate-source.txt').read_text().strip()
def read(n):return json.loads((p/n).read_text(encoding='utf-8-sig'))
def wrapped(n):return json.loads(read(n)['stdout'])
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
m=read('bundle.json');assert m['commit']==C and m['version']=='0.22.1'
replay=read('build-replay.json');assert replay['state']=='exact'
ci=read('ci-manual-artifacts/qualification-candidate-'+C+'/release-build-replay.json')
assert ci['manifest']==m and ci['state']=='exact'
assert len(ci['builds'])==2
for k in ('wheel_sha256','sdist_sha256'):assert all(b[k]==m[k] for b in ci['builds']+replay['builds'])
pr=wrapped('ci-final.json');assert pr['headRefOid']==C and pr['baseRefName']=='main' and pr['isDraft']
assert all(x['status']=='COMPLETED' and x['conclusion'] in ('SUCCESS','SKIPPED') for x in pr['statusCheckRollup'])
manual=wrapped('manual-rehearsal-final.json');assert manual['headSha']==C and manual['conclusion']=='success'
assert all(j['conclusion']=='success' for j in manual['jobs'])
for n in ('windows-full-source.json','distribution-checks.json','cli-smoke.json','win-package-qualification.json','win-decision-probe.json','win-draft-cli.json','win-topology-boundary.json','win-upgrade-1.json','win-upgrade-2.json','win-installed-simple-plugin.json','win-installed-test_skill_ownership.json','win-corrected-transition-restored.json','plugin-stage.json','plugin-check-stage.json'):
    assert read(n)['exit_code']==0,n
for platform in ('wheel','sdist'):
    for cmd in ('install','identity','init','doctor','validate'):assert read(f'win-{platform}-{cmd}.json')['exit_code']==0
for n in ('wsl-qualification.json','wsl-extra-completed.json','corrected-windows-restored.json','corrected-linux-restored.json'):
    v=read(n);assert v['passed'] and v['candidate']==C,n
for r in read('wsl-extra.json')['commands'][:2]:assert r['exit_code']==0
for n in ('plugin026-trusted-native-codex.json','plugin026-native-claude.json'):
    v=read(n);assert v['passed'] and v['automatic_compaction_observed'] and v['repository_preserved']
    assert v['wheel']['candidate_commit']==C and v['wheel']['archive_sha256']==m['wheel_sha256']
assert read('plugin026-trusted-native-codex.json')['restored']
equiv=read('native-input-comparison.json');assert equiv['candidate']==C and equiv['wheel_members_identical']
stage=read('marketplace-staging.json');assert stage['candidate_commit']==C and stage['all_git_blob_bytes_match']
files=[f for f in p.glob('*.json') if f.name!='plugin026-native-inputs.json']
files += list((p/'windows-package').glob('correction-installed-*.json'))
files += list((p/'windows-package').glob('upgrade-*/upgrade-rehearsal-result.json'))
files += [f for f in (p/'ci-manual-artifacts').rglob('*') if f.is_file() and f.suffix in ('.json','.log')]
files += [f for f in (p/'plugin026-trusted-native-codex-events').rglob('*') if f.is_file() and f.suffix in ('.json','.jsonl','.txt')]
files += [p/'plugin026-marketplace/PACKAGE-IDENTITY.json']
files += [p/f'plugin026-marketplace/packages/{host}/verity-plane/assembly-inventory.json' for host in ('codex','claude')]
files += [s.WORK/n for n in ('r221_session.py','r221_final_run.py','r221_final_probe_recovery.py','r221_final_linux_remaining.py','r221_final_capture_checks.py','r221_final_receipt.py','r221_fix043_probe.py','r221_fix043_extra.py','r221_fix043_run.py','r221_checks.py','r221_packages.py','r221_linux_wsl.py','r221_final_native_prepare.py','r221_final_native_codex.py','r221_final_native_claude.py','r221_final_staging.py','r221_staging_commit.py','r221_topology.py')]
target=p/'final-qualification.zip';assert not target.exists();entries=[]
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for f in sorted(set(files)):
        raw=f.read_bytes();assert not re.search(rb'(?:sk-ant-|sk-proj-|Bearer\s+)[A-Za-z0-9_-]{16,}',raw),f
        name=f.relative_to(s.WORK).as_posix();z.writestr(name,raw)
        entries.append({'path':name,'bytes':len(raw),'sha256':sha(f)})
record={'candidate':C,'files':[{'path':f.relative_to(p).as_posix(),'sha256':sha(f)} for f in sorted(set(files)) if f.is_relative_to(p)],'archives':[{'path':target.name,'sha256':sha(target),'entries':entries}], 'assessment':{'required_automated_and_cli_checks_passed':True,'windows_source':'1293 tests; 23 reported skips; exit 0','linux_source':'1293 tests; 2 reported skips; exit 0','exact_builds':'two local and two GitHub pinned builds have identical wheel and sdist bytes','native':'fresh final-package Codex CLI 0.159.2 and Claude Code 2.1.273 startup/activation/resume/manual+automatic compaction passed','equivalence':'125 expanded wheel members and executable/resource host inputs match 061307929c94314ccd2beb4a53f174e536fceba8; earlier isolation and two-checkout walkthrough observations are retained at that original identity, not claimed rerun','desktop':'not run / unverified; accepted release-only omission DEC-RLS-009 / RISK-RLS-007','fixture_recoveries':'completed original fixture refused a second start; restored immutable pre-execution fixture passes both platforms. Duplicate Linux draft-probe setup also refused; original successful draft/topology probes reused, remaining checks completed. All failures retained.','public_delivery':'not performed; later WO-RLS-042 / VER-RLS-038','hosted_service':'not tested; excluded','release_readiness':'exact RLS, final plan and complete-release decision follow human verification; not executable-ready yet'},'marketplace':stage,'bundle':m,'ci_run':manual['url']}
dest=p/'final-evidence-receipt.json';assert not dest.exists();dest.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'receipt':str(dest),'sha256':sha(dest),'archive':sha(target),'entries':len(entries),'archive_bytes':target.stat().st_size}))
