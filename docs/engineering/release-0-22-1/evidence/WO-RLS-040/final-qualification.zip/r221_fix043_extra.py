import r221_session as session
session.OUT=session.WORK/'r221-fix043-20261005'
from r221_session import *

C=(OUT/'candidate-source.txt').read_text().strip()
wheel=OUT/'build/se_harness-0.22.1-py3-none-any.whl'
digest=hashlib.sha256(wheel.read_bytes()).hexdigest()
fixture=Path(r'C:\Users\mathi\AppData\Local\Temp\r221-claude-flow\one')
topology="import json;from se_harness.engine import dashboard_bundle as b;assert b.TOPOLOGY_ACCEPTANCE_BYTES==4194304;r=[b.topology_target_exceeded(v) for v in (4194303,4194304,4194305)];assert r==[False,False,True];print(json.dumps({'target':b.TOPOLOGY_ACCEPTANCE_BYTES,'results':r,'origin':b.__file__}))"
if sys.argv[1]=='windows':
    root=OUT/'windows-package';py=root/'wheel-env/Scripts/python.exe'
    probe=root/'draft-probe.py'
    source=(REPO/'docs/engineering/hosted-artifact-graph/evidence/WO-HAG-002/qualify_correction_wheel.py').read_text()
    source=source.replace("str(base.parent / 'se_harness')","str(Path("+repr(str(REPO))+"))")
    assert not probe.exists();probe.write_text(source,encoding='utf-8')
    run('win-draft-cli',[PYTHON,'-B',probe,'--python',py,'--wheel',wheel,'--commit',C],timeout=600)
    run('win-topology-boundary',[py,'-I','-c',topology])
    run('win-corrected-transition',[py,'-I',WORK/'r221_fix043_probe.py',fixture,OUT/'corrected-windows.json',C,digest],timeout=600)
else:
    linux=lambda p:'/mnt/c/'+p.as_posix()[3:]
    prior=json.loads((OUT/'wsl-qualification.json').read_text());assert prior['passed']
    program=r'''import hashlib,json,pathlib,subprocess,sys,zipfile,zlib
i=json.loads(sys.argv[1]);stage=pathlib.Path(i['stage']);source=stage/'source';py=stage/'current/bin/python';old=stage/'prior/bin/python';rows=[]
dest=pathlib.Path(i['output']);assert not dest.exists();result={'candidate':i['candidate'],'stage':str(stage),'commands':rows,'passed':False}
def run(label,args,cwd=stage):
 p=subprocess.run(list(map(str,args)),cwd=cwd,capture_output=True,text=True,encoding='utf-8',timeout=1800)
 rows.append(dict(label=label,argv=list(map(str,args)),cwd=str(cwd),exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr));dest.write_text(json.dumps(result,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode:raise RuntimeError(label+': '+p.stderr[-1500:]+p.stdout[-1500:])
 return p
try:
 probe=stage/'draft-probe.py';s=(source/'docs/engineering/hosted-artifact-graph/evidence/WO-HAG-002/qualify_correction_wheel.py').read_text()
 s=s.replace('a.python.resolve().parent.parent','a.python.absolute().parent.parent').replace("str(base.parent / 'se_harness')","str(Path("+repr(str(source))+"))")
 probe.write_text(s)
 run('installed-draft-cli',[sys.executable,probe,'--python',py,'--wheel',i['wheel'],'--commit',i['candidate']])
 run('installed-topology',[py,'-I','-c',i['topology']])
 run('corrected-transition',[py,'-I',i['probe'],i['fixture'],i['transition_result'],i['candidate'],i['wheel_sha256']])
 run('sdist-env',[sys.executable,'-m','venv',stage/'sdist-env']);bp=stage/'sdist-env/bin/python'
 run('sdist-tools',[bp,'-m','pip','install','--disable-pip-version-check','--only-binary=:all:','--require-hashes','-r',source/'release/build-toolchain.lock'])
 run('sdist-install',[bp,'-m','pip','install','--no-index','--no-deps','--no-build-isolation','--no-binary=se-harness','--find-links',pathlib.Path(i['wheel']).parent,'se-harness==0.22.1'])
 for cmd in ('init','doctor','validate'):run('sdist-'+cmd,[bp,'-I','-m','se_harness',cmd,stage/'sdist-fixture','--json'])
 args=['--repository',source,'--revision',i['candidate'],'--candidate-manifest',i['manifest'],'--expected-manifest-sha256',i['manifest_sha256'],'--expected-wheel-sha256',i['wheel_sha256'],'--wheel',i['wheel'],'--evaluator-python',old,'--output-directory',stage/'plugin-stage']
 for cmd in ('stage','check-stage'):run('plugin-'+cmd,[py,source/'scripts/build_plugin_marketplace.py',cmd,*args])
 a=stage/'plugin-stage';b=pathlib.Path(i['windows_stage']);ia=json.loads((a/'PACKAGE-IDENTITY.json').read_text());ib=json.loads((b/'PACKAGE-IDENTITY.json').read_text())
 differences=[k for k in ia['files'] if ia['files'][k]!=ib['files'][k]]
 assert set(differences)<= {'packages/verity-plane-codex.zip','packages/verity-plane-claude.zip'},differences
 archives=[]
 for name in ('packages/verity-plane-codex.zip','packages/verity-plane-claude.zip'):
  with zipfile.ZipFile(a/name) as za,zipfile.ZipFile(b/name) as zb:
   assert za.namelist()==zb.namelist()
   for n in za.namelist():
    assert za.read(n)==zb.read(n),n
    assert all(getattr(za.getinfo(n),k)==getattr(zb.getinfo(n),k) for k in ['date_time','compress_type','comment','extra','create_system','external_attr','flag_bits'])
   archives.append({'name':name,'member_count':len(za.namelist()),'expanded_bytes_identical':True})
 result.update(passed=True,archives=archives,compressed_archive_differences=differences,selected_public_tree='Exact Windows staging tree; each platform check-stage passes, expanded bytes and inventories match. No cross-runtime compressed-byte reproducibility claim.')
except Exception as e:result['error']=repr(e)
dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='commands'}));sys.exit(0 if result['passed'] else 1)
'''
    mf=OUT/'bundle.json'
    inputs={'candidate':C,'stage':prior['stage'],'output':linux(OUT/'wsl-extra.json'),'wheel':linux(wheel),'wheel_sha256':digest,'topology':topology,'probe':linux(WORK/'r221_fix043_probe.py'),'fixture':linux(fixture),'transition_result':linux(OUT/'corrected-linux.json'),'manifest':linux(mf),'manifest_sha256':hashlib.sha256(mf.read_bytes()).hexdigest(),'windows_stage':linux(OUT/'plugin026-marketplace')}
    run('wsl-extra-launch',[r'C:\Windows\System32\wsl.exe','-d','Ubuntu-24.04','--exec','python3','-c',program,json.dumps(inputs)],timeout=3600,allow=(0,1))
