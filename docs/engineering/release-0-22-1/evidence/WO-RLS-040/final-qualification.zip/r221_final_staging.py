"""Use the existing reviewed staging helper for the final candidate."""
from pathlib import Path
p=Path(__file__).with_name('r221_staging_commit.py')
text=p.read_text(encoding='utf-8')
text=text.replace("s.WORK/'r221-continue-20261005'", "s.WORK/'r221-final-20261005'")
text=text.replace("s.WORK/'r221-fix043-20261005'", "s.WORK/'r221-final-20261005'")
text=text.replace('061307929c94314ccd2beb4a53f174e536fceba8','4f640284ec496b88cd7aa4ba88ca537d9374a2f8')
text=text.replace("dest=s.REPO/s.DOMAIN/'evidence/WO-RLS-041/preparation-marketplace-commit.json'", "dest=s.OUT/'marketplace-staging.json'")
text=text.replace('preparation candidate, not final release binding','final candidate staged; verification and release decisions pending')
text=text.replace('Final candidate binding and matching staging must be checked again before aggregate verification. No verification or public publication is supplied.','Exact final candidate staging. Required qualification and human verification remain separate. No public publication is supplied.')
exec(compile(text,str(p),'exec'))
