"""Restore the immutable pre-execution fixture for the final regression probe."""
import hashlib,json,sys,zipfile
import r221_session as s
s.OUT=s.WORK/'r221-final-20261005'
prior=s.WORK/'r221-fix043-20261005/claude-workflow'
fixture=s.OUT/'restored-before-fixture'
C=(s.OUT/'candidate-source.txt').read_text().strip()
mode=sys.argv[1]
if mode=='prepare':
    assert not fixture.exists();fixture.mkdir()
    baseline=prior/'one-baseline-fixture.zip';final=prior/'one-final-fixture.zip'
    with zipfile.ZipFile(baseline) as z:
        assert all(not n.startswith('/') and '..' not in n.split('/') for n in z.namelist())
        z.extractall(fixture)
    draft='docs/engineering/product/work-orders/WO-FLW-002.md'
    with zipfile.ZipFile(final) as z:raw=z.read(draft)
    assert hashlib.sha256(raw).hexdigest()=='63e9d2834d5638016bcc97702b3e9828c0a2334380cee02fa12d0a5a78bd5a30'
    (fixture/draft).write_bytes(raw)
    assert 'status = "approved"' in (fixture/'docs/engineering/product/work-orders/WO-FLW-001.md').read_text()
    assert not (fixture/'docs/engineering/product/evidence/WO-FLW-002/observations.md').exists()
    record={'reason':'The original live native fixture had correctly reached implemented during its prior successful walkthrough. The first final probe tried to start that completed fixture and was correctly refused. Reconstruct the recorded approved baseline plus the exact originally untracked draft; do not edit lifecycle state or erase the failure.', 'baseline_archive_sha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'final_archive_sha256':hashlib.sha256(final.read_bytes()).hexdigest(),'draft_sha256':hashlib.sha256(raw).hexdigest(),'files':{p.relative_to(fixture).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in fixture.rglob('*') if p.is_file()}}
    (s.OUT/'regression-fixture-recovery.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
elif mode=='windows':
    wheel=s.OUT/'build/se_harness-0.22.1-py3-none-any.whl'
    s.run('win-corrected-transition-restored',[s.OUT/'windows-package/wheel-env/Scripts/python.exe','-I',s.WORK/'r221_fix043_probe.py',fixture,s.OUT/'corrected-windows-restored.json',C,hashlib.sha256(wheel.read_bytes()).hexdigest()],timeout=600)
elif mode=='linux':
    p=s.WORK/'r221_fix043_extra.py'
    text=p.read_text().replace("session.WORK/'r221-fix043-20261005'", "session.WORK/'r221-final-20261005'")
    text=text.replace("fixture=Path(r'C:\\Users\\mathi\\AppData\\Local\\Temp\\r221-claude-flow\\one')", "fixture=OUT/'restored-before-fixture'")
    text=text.replace('wsl-extra.json','wsl-extra-restored.json').replace('corrected-linux.json','corrected-linux-restored.json').replace("'wsl-extra-launch'","'wsl-extra-restored-launch'")
    sys.argv=[str(p),'linux'];exec(compile(text,str(p),'exec'))
else:raise SystemExit(mode)
