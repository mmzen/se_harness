"""Independent installed-wheel regression probe using the preserved native fixture."""
from pathlib import Path
import hashlib, json, platform, shutil, subprocess, sys, tempfile, tomllib

source=Path(sys.argv[1]);dest=Path(sys.argv[2]);candidate=sys.argv[3];digest=sys.argv[4]
assert not dest.exists()
root=Path(tempfile.mkdtemp(prefix='r221-corrected-'));repo=root/'repository'
shutil.copytree(source,repo,ignore=shutil.ignore_patterns('.git'))
rows=[]
result={'candidate':candidate,'wheel_sha256':digest,'source_fixture':str(source),'fixture':str(repo),
        'python':sys.version,'platform':platform.platform(),'commands':rows,'passed':False}
def snapshot():
    return {p.relative_to(repo).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in repo.rglob('*') if p.is_file()}
def run(*args):
    argv=[sys.executable,'-I','-m','se_harness',*map(str,args),'--json']
    p=subprocess.run(argv,cwd=root,capture_output=True,text=True,encoding='utf-8',timeout=120)
    rows.append({'argv':argv,'cwd':str(root),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    dest.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    assert p.returncode==0,(args,p.stdout[-2000:],p.stderr[-2000:])
    return json.loads(p.stdout)
try:
    identity=run('identity','--role','candidate-package','--expected-version','0.22.1','--expected-root',Path(sys.executable).absolute().parent.parent,'--checkout-root',source,'--candidate-commit',candidate,'--require-isolated-python')
    result['identity']=identity
    # Select the corrected wheel through the supported disposable-fixture
    # upgrade. Preserve every formal artifact, including the failing draft.
    old=snapshot();result['prior_fixture']=old
    run('upgrade',repo)
    assert snapshot()==old
    run('upgrade',repo,'--apply')
    before=snapshot();result['before']=before
    upgrade_changes=[p for p in old if old[p]!=before.get(p)]
    assert all(not p.startswith(('docs/engineering/', 'notes/')) for p in upgrade_changes),upgrade_changes
    result['upgrade_changes']=upgrade_changes
    draft=repo/'docs/engineering/product/work-orders/WO-FLW-002.md'
    metadata=tomllib.loads(draft.read_text(encoding='utf-8').split('+++',2)[1])
    assert metadata['status']=='draft'
    assert metadata['evidence_paths']==['docs/engineering/product/evidence/WO-FLW-002/observations.md']
    assert not (repo/metadata['evidence_paths'][0]).exists()
    run('validate',repo)
    preflight=run('preflight',repo,'--work-order','WO-FLW-001','--phase','start')
    assert preflight['ready']
    args=('transition',repo,'--set','WO-FLW-001=in_progress','--decision','WO-FLW-001=Claude')
    preview=run(*args);assert preview['operation']['outcome']=='completed'
    assert snapshot()==before
    applied=run(*args,'--apply');assert applied['operation']['outcome']=='completed'
    after=snapshot();result['after']=after
    changed=[p for p in before if before[p]!=after.get(p)]
    assert set(after)==set(before)
    assert changed==['docs/engineering/product/work-orders/WO-FLW-001.md'],changed
    assert not (repo/metadata['evidence_paths'][0]).exists()
    result.update(passed=True,changed=changed,draft_unchanged=True,missing_evidence_not_created=True)
except Exception as e:
    result['error']=repr(e)
finally:
    dest.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ('commands','before','after','identity')}))
assert result['passed']
