"""Reuse reviewed native probes with the final exact package inputs."""
import base64,hashlib,json,zipfile,subprocess
import r221_session as s
out=s.WORK/'r221-final-20261005'
old=s.WORK/'r221-fix043-20261005'
C=(out/'candidate-source.txt').read_text().strip()
market=out/'plugin026-marketplace'
identity=json.loads((market/'PACKAGE-IDENTITY.json').read_text())
assert identity['source']['revision']==C
prior=json.loads((old/'plugin026-marketplace/PACKAGE-IDENTITY.json').read_text())
newwheel=out/'build'/identity['evaluator']['archive']
oldwheel=old/'build'/prior['evaluator']['archive']
with zipfile.ZipFile(newwheel) as nz,zipfile.ZipFile(oldwheel) as oz:
    assert set(nz.namelist())==set(oz.namelist())
    changed=[p for p in nz.namelist() if nz.read(p)!=oz.read(p)]
    assert not changed,changed
    wheel_members={p:hashlib.sha256(nz.read(p)).hexdigest() for p in sorted(nz.namelist())}
assert identity['evaluator']['payload_sha256']==prior['evaluator']['payload_sha256']
hostfiles={}
for host in ('codex','claude'):
    a=market/'packages'/host/'verity-plane';b=old/'plugin026-marketplace/packages'/host/'verity-plane'
    aa={p.relative_to(a).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in a.rglob('*') if p.is_file()}
    bb={p.relative_to(b).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in b.rglob('*') if p.is_file()}
    assert aa.keys()==bb.keys()
    changed=[p for p in aa if aa[p]!=bb[p]]
    assert set(changed)<= {'assembly-inventory.json','packages/'+identity['evaluator']['archive']},changed
    hostfiles[host]={'changed_container_or_inventory_files':changed,'unchanged_host_files':{p:h for p,h in aa.items() if p not in changed}}
comparison={'candidate':C,'prior_tested_source':prior['source']['revision'],'wheel_members_identical':True,'wheel_members_sha256':wheel_members,'payload_sha256':identity['evaluator']['payload_sha256'],'host_files':hostfiles,'limits':'Prior native workflow and isolation observations retain their original package identities. Every executable/resource member and all host scripts, hooks, skills and manifests match. Fresh final-package startup/activation/compaction/resume is tested separately. No desktop test pass.'}
(out/'native-input-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n',encoding='utf-8')
expected=dict(identity['evaluator']);expected['archive_name']=expected['archive']
inputs={host:base64.b64encode((market/'packages'/('verity-plane-'+host+'.zip')).read_bytes()).decode() for host in ('codex','claude')}
inputs.update(marketplace=json.loads((market/'.agents/plugins/marketplace.json').read_text()),expected=expected)
(out/'plugin026-native-inputs.json').write_text(json.dumps(inputs),encoding='utf-8')
for host in ('codex','claude'):
    original=s.WORK/('r221_fix043_native_'+host+'.py')
    text=original.read_text(encoding='utf-8').replace("OUT=WORK/'r221-fix043-20261005'", "OUT=WORK/'r221-final-20261005'").replace('061307929c94314ccd2beb4a53f174e536fceba8',C).replace("prefix='p026f-'", "prefix='p026final-'")
    target=s.WORK/('r221_final_native_'+host+'.py');assert not target.exists()
    compile(text,str(target),'exec');target.write_text(text,encoding='utf-8',newline='\n')
print(json.dumps({'candidate':C,'wheel_members_identical':True,'member_count':len(wheel_members),'host_changes':{h:v['changed_container_or_inventory_files'] for h,v in hostfiles.items()}}))
