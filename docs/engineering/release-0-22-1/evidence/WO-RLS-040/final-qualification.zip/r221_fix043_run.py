"""Run approved release qualification in a new output namespace; preserve prior runs."""
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
import r221_session as session

session.OUT = session.WORK/'r221-fix043-20261005'
session.OUT.mkdir(exist_ok=True)
from r221_session import *

mode=sys.argv[1]
if mode == 'source':
    run('windows-full-source',[PYTHON,'-B','-X','utf8','scripts/run_tests.py','--scale','full'],cwd=REPO,timeout=2400,allow=(0,1))
elif mode == 'distribution':
    run('distribution-checks',[PYTHON,'-B','-X','utf8','scripts/validate_release_distributions.py','--root','.'],cwd=REPO,timeout=900)
    run('cli-smoke',[PYTHON,'-B','-X','utf8','-m','se_harness','--help'],cwd=REPO)
elif mode == 'commit':
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()=='dbc0144e3830087f1d4c267e76322f6d0e92edf4'
    status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=REPO,text=True)
    paths=[line[3:] for line in status.splitlines()]
    assert all(p in ('se_harness/workflow.py','tests/test_workflow_execution.py') or p.startswith(DOMAIN) for p in paths),paths
    run('stage-correction',['git','add','--',*paths],cwd=REPO)
    run('whitespace',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'],cwd=REPO)
    run('commit-correction',['git','commit','-m','Handle absent draft evidence in transition snapshots'],cwd=REPO)
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True).strip()
    (OUT/'candidate-source.txt').write_text(head+'\n')
    print(json.dumps({'candidate_source':head}))
elif mode in ('build','stage','windows','linux-prepare','linux-test'):
    if mode=='build': file='r221_checks.py';args=['build']
    elif mode in ('stage','windows'): file='r221_packages.py';args=[mode]
    else: file='r221_linux_wsl.py';args=[mode.removeprefix('linux-')]
    source=(WORK/file).read_text(encoding='utf-8')
    if mode=='windows':
        # The earlier run established that Git requires a per-process longpaths setting.
        os.environ.update(GIT_CONFIG_COUNT='1',GIT_CONFIG_KEY_0='core.longpaths',GIT_CONFIG_VALUE_0='true')
        source=source.replace("['tests/test_draft_validation.py','tests/test_relation_policy.py','tests/test_skill_ownership.py']", "['tests/test_skill_ownership.py']")
    if mode=='linux-test':
        # Modules importing tests.* are source-suite tests, not isolated-wheel probes.
        # The actual draft-validation CLI probe runs separately against the wheel.
        source=source.replace("('tests/test_draft_validation.py','tests/test_relation_policy.py','tests/test_skill_ownership.py')", "('tests/test_skill_ownership.py',)")
    sys.argv=[str(WORK/file),*args]
    exec(compile(source,str(WORK/file),'exec'),{'__name__':'__main__','__file__':str(WORK/file)})
else:
    raise ValueError(mode)
