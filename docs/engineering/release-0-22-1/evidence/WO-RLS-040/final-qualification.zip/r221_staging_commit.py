"""Create an exact ordinary marketplace child, without moving the public ref."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
import r221_session as s
s.OUT=s.WORK/'r221-continue-20261005'
prepared=s.WORK/'r221-fix043-20261005'
tree_dir=prepared/'plugin026-marketplace'
parent='7d30907f15bd7e06fb632e1ebf4e88e01b68726c'
identity=json.loads((tree_dir/'PACKAGE-IDENTITY.json').read_text())
assert identity['source']['revision']=='061307929c94314ccd2beb4a53f174e536fceba8'
dest=s.REPO/s.DOMAIN/'evidence/WO-RLS-041/preparation-marketplace-commit.json'
assert not dest.exists()
def git(*args,input=None,env=None):
    p=subprocess.run(['git',*map(str,args)],cwd=s.REPO,input=input,capture_output=True,env=env)
    if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace'))
    return p.stdout
s.run('marketplace-fetch-parent',['git','fetch','origin','refs/heads/plugin-marketplace'],cwd=s.REPO)
assert git('rev-parse','FETCH_HEAD').decode().strip()==parent
files={p.relative_to(tree_dir).as_posix():p for p in tree_dir.rglob('*') if p.is_file()}
assert set(files)==set(identity['files'])|{'PACKAGE-IDENTITY.json'}
for name,digest in identity['files'].items():assert hashlib.sha256(files[name].read_bytes()).hexdigest()==digest,name
index=s.OUT/'marketplace-preparation.index';assert not index.exists()
env=dict(os.environ,GIT_INDEX_FILE=str(index))
git('read-tree','--empty',env=env)
rows=[]
for name,p in sorted(files.items()):
    oid=git('hash-object','-w','--no-filters',p).decode().strip()
    rows.append(f'100644 {oid}\t{name}\n')
git('update-index','--index-info',input=''.join(rows).encode(),env=env)
tree=git('write-tree',env=env).decode().strip()
commit=git('commit-tree',tree,'-p',parent,input=b'Prepare qualified plugin 0.2.6 marketplace tree\n\nHarness-Work-Order: WO-RLS-041\n').decode().strip()
assert git('rev-list','--parents','-n','1',commit).decode().split()==[commit,parent]
assert set(git('ls-tree','-r','--name-only',commit).decode().splitlines())==set(files)
for name,p in files.items():assert git('show',commit+':'+name)==p.read_bytes(),name
record={'phase':'preparation candidate, not final release binding','candidate_commit':identity['source']['revision'],'marketplace_parent':parent,'marketplace_commit':commit,'marketplace_tree':tree,'package_identity_sha256':hashlib.sha256(files['PACKAGE-IDENTITY.json'].read_bytes()).hexdigest(),'file_count':len(files),'all_git_blob_bytes_match':True,'public_ref_changed':False,'staging_ref_pushed':False,'planned_staging_ref':'refs/heads/codex/plugin-0-2-6-staging','qualification_review':'docs/engineering/release-0-22-1/evidence/WO-RLS-043/corrected-qualification-review.md','limits':'Final candidate binding and matching staging must be checked again before aggregate verification. No verification or public publication is supplied.'}
dest.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
(s.OUT/'marketplace-preparation-commit.json').write_bytes(dest.read_bytes())
print(json.dumps(record,indent=2))
