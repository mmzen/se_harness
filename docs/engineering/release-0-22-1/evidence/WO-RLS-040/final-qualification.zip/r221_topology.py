from r221_session import *
prior=json.loads((OUT/'wsl-qualification.json').read_text());source=prior['stage']+'/source'
program=r'''import hashlib,json,pathlib,subprocess,zipfile
from tests.test_dashboard_webui import GENERATOR,ROOT
snapshot,validation,_=GENERATOR.generate_snapshot(ROOT);assert validation.valid
first=GENERATOR.build_dashboard_bundle(snapshot);second=GENERATOR.build_dashboard_bundle(snapshot);assert first==second
_,manifest,resources,observations=first;entry=manifest['entrypoints']['topology'];assert entry['bytes']<=4194304
amendment=ROOT/'docs/engineering/harness-distribution/evidence/WO-DST-028/amendment.json';a=json.loads(amendment.read_text());archive=amendment.parent/a['archive'];assert hashlib.sha256(archive.read_bytes()).hexdigest()==a['archive_sha256']
with zipfile.ZipFile(archive) as z:
 for row in a['revisions']:
  assert hashlib.sha256(z.read(row['predecessor_member'])).hexdigest()==row['predecessor_sha256']
  assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==row['revision_sha256']
print(json.dumps({'candidate':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'valid':validation.valid,'artifacts':len(snapshot['artifacts']),'relations':len(snapshot['relations']),'topology':entry,'target':4194304,'headroom':4194304-entry['bytes'],'repeated_bundles_identical':True,'preserved_predecessors':len(a['revisions']),'observations':observations}))
'''
run('topology-candidate-measure',[r'C:\Windows\System32\wsl.exe','-d','Ubuntu-24.04','--cd',source,'--exec',prior['stage']+'/current/bin/python','-B','-c',program],timeout=600)
