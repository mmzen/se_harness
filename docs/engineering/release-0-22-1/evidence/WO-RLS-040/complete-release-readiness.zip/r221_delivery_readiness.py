"""Read-only provider observations and bounded live CLI authentication probes."""
import concurrent.futures,datetime,json,os,subprocess,tempfile
from pathlib import Path
import r221_session as s
s.OUT=s.WORK/'r221-complete-plan-20261005'
def probe(host):
    env=os.environ.copy()
    profile=Path(r'C:\Users\mathi\AppData\Local\Temp\iar-instruction-demo-bztgja2p\profiles')/host/host
    assert profile.is_dir()
    cwd=Path(tempfile.mkdtemp(prefix='r221-auth-ready-'))
    prompt='Authentication connectivity check only. Reply with exactly AUTH_READY. Do not read files, use tools, or change anything.'
    if host=='codex':
        env['CODEX_HOME']=str(profile)
        args=[r'C:\Users\mathi\AppData\Local\OpenAI\Codex\bin\a51e250fa15c740a\codex.exe','exec','--ignore-user-config','--ephemeral','--skip-git-repo-check','--sandbox','read-only','--json',prompt]
    else:
        env['CLAUDE_CONFIG_DIR']=str(profile)
        args=[r'C:\Users\mathi\.local\bin\claude.exe','--safe-mode','--tools','','--strict-mcp-config','--no-session-persistence','--output-format','json','-p',prompt]
    path=s.OUT/(host+'-live-readiness.json');assert not path.exists()
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    r=subprocess.run(args,cwd=cwd,env=env,capture_output=True,encoding='utf-8',errors='replace',timeout=180)
    record={'observed_at':started,'argv':args,'cwd':str(cwd),'profile':str(profile),'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'scope':'Authentication readiness only; no plugin qualification or public-route claim.'}
    path.write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    passed=r.returncode==0 and 'AUTH_READY' in r.stdout
    if host=='claude':passed=passed and not json.loads(r.stdout).get('is_error',True)
    else:
        events=[json.loads(line) for line in r.stdout.splitlines() if line.strip()]
        passed=passed and any(x.get('type')=='turn.completed' for x in events)
    print(json.dumps({'host':host,'exit_code':r.returncode,'live_authentication':passed,'record':str(path)}),flush=True)
    return passed
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results=list(pool.map(probe,['codex','claude']))
assert all(results),'Required live authentication readiness failed; inspect retained results.'
for name,endpoint in [('pypi','environments/pypi'),('pypi-branches','environments/pypi/deployment-branch-policies'),('main-protection','rules/branches/main'),('marketplace-protection','rules/branches/plugin-marketplace'),('maintenance-protection','rules/branches/release%2F0.22'),('pages','pages'),('latest','releases/latest')]:
    s.run('provider-'+name,['gh','api','repos/mmzen/se_harness/'+endpoint])
s.run('provider-refs',['git','ls-remote','origin','refs/heads/main','refs/heads/release/0.22','refs/heads/plugin-marketplace','refs/heads/codex/plugin-0-2-6-staging','refs/tags/last','refs/tags/v0.22.1'],cwd=s.REPO)
