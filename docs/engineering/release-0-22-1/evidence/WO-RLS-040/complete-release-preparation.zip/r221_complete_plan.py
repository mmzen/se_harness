"""Prepare frozen supporting inputs; make no release or publication decision."""
import datetime,hashlib,importlib.util,json,subprocess,sys,tomllib,types,zipfile
import r221_session as s
s.OUT=s.WORK/'r221-complete-plan-20261005'
D=s.DOMAIN;E=D+'evidence/WO-RLS-040/';P=D+'evidence/WO-RLS-042/'
C='4f640284ec496b88cd7aa4ba88ca537d9374a2f8';DOC='dc3b6d39b3980299b5443e6036d3fe8aa34c4fa3'
V='febda5a5be9d484231a932f19111bec8ebf72f8d';OLD='abbec12ac5524c8adfb28693f846dd59de88f759'
def git(*a):return subprocess.check_output(['git',*a],cwd=s.REPO,text=True).rstrip('\r\n')
def blob(ref,path):return subprocess.check_output(['git','show',ref+':'+path],cwd=s.REPO)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(path,obj):
    p=s.REPO/path;assert not p.exists(),p
    p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
def observed(name):return json.loads(json.loads((s.OUT/(name+'.json')).read_text())['stdout'])
def meta(path):return tomllib.loads((s.REPO/path).read_text().split('+++',2)[1])
mode=sys.argv[1]
if mode=='prepare':
    assert git('rev-parse','HEAD')==V and not git('status','--porcelain')
    rls=meta(D+'releases/RLS-SEH-033.md');assert rls['status']=='ready' and rls['commit']==C
    ver=meta(D+'verification-records/VREC-SEH-033.md');assert ver['status']=='verified' and ver['commit']==C and ver['verified_by']=='mmzen'
    vd=meta(D+'verification-records/VREC-RLS-003.md');assert vd['status']=='verified' and vd['commit']==DOC and vd['verified_by']=='mmzen'
    dist=rls['distribution']
    refs=dict(line.split()[::-1] for line in json.loads((s.OUT/'provider-refs.json').read_text())['stdout'].splitlines())
    stage=json.loads((s.REPO/D/'evidence/WO-RLS-041/final-staging-review-publication.json').read_text())
    assert refs['refs/heads/main']==s.BASE and refs['refs/heads/plugin-marketplace']==stage['parent'] and refs['refs/heads/codex/plugin-0-2-6-staging']==stage['commit']
    assert refs['refs/heads/release/0.22']==refs['refs/tags/last']==OLD and 'refs/tags/v0.22.1' not in refs
    assert observed('provider-latest')['tag_name']=='v0.22.0'
    subprocess.run(['git','merge-base','--is-ancestor',OLD,C],cwd=s.REPO,check=True)
    rules=observed('provider-main-protection');assert any(x['type']=='required_status_checks' for x in rules)
    assert next(x for x in rules if x['type']=='pull_request')['parameters']['allowed_merge_methods']==['merge']
    for name in ('marketplace','maintenance'):assert {x['type'] for x in observed('provider-'+name+'-protection')}=={'deletion','non_fast_forward'}
    env=observed('provider-pypi');assert not any(x.get('reviewers') for x in env['protection_rules'] if x['type']=='required_reviewers')
    assert observed('provider-pypi-branches')['branch_policies'][0]['name']=='main'
    for host in ('codex','claude'):
        v=json.loads((s.OUT/(host+'-live-readiness.json')).read_text());assert v['exit_code']==0 and 'AUTH_READY' in v['stdout']
    # Publisher and plan checker are the already integrated trusted-main implementations.
    for path in ('.github/scripts/publish_release.py','scripts/check_release_delivery.py','.github/workflows/publish-pypi.yml'):
        assert blob(s.BASE,path)==blob(V,path),path
    archive=s.REPO/E/'complete-release-readiness.zip';assert not archive.exists()
    raw_names=['ready-release-context','ready-release-gates','codex-live-readiness','claude-live-readiness','provider-pypi','provider-pypi-branches','provider-main-protection','provider-marketplace-protection','provider-maintenance-protection','provider-pages','provider-latest','provider-refs']
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for n in raw_names:z.write(s.OUT/(n+'.json'),n+'.json')
        z.write(s.WORK/'r221_delivery_readiness.py','r221_delivery_readiness.py')
    readiness={'schema':'se-harness-complete-release-readiness/v1','candidate_commit':C,'verification_records':['VREC-SEH-033'],'qualification':'passed','controls_ready':True,'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'documentation':{'verification_record':'VREC-RLS-003','state':'verified','candidate_commit':DOC,'decision_commit':V,'note':'Independent source-documentation assurance; not added to binary release membership.'},
      'evidence':[{'path':path,'sha256':sha((s.REPO/path).read_bytes())} for path in (D+'verification-records/VREC-SEH-033.md',D+'verification-records/VREC-RLS-003.md',E+'final-evidence-receipt.json',E+'final-verification-review.md',E+'ready-record-replay-receipt.json',E+'provider-configuration-applied.json',E+'complete-release-readiness.zip',D+'evidence/WO-RLS-044/assessment.md')],
      'provider_controls':{'main':'PR plus validate; merge commits only; no bypass','pypi':'No separate reviewer; main-only deployment, OIDC and existing permissions preserved','trusted_publisher':'mmzen confirmed owner mmzen, repository se_harness, workflow publish-pypi.yml, environment pypi; human account-side confirmation, not an authenticated agent read','marketplace_and_maintenance':'Ordinary fast-forward; provider denies non-fast-forward and deletion','pages':'Existing GitHub Pages deployment and www.verityplane.ai domain unchanged'},
      'authentication':{'codex':'Live reply passed in existing disposable profile','claude-code':'Live reply passed in existing disposable profile','limit':'Point-in-time readiness; repeat before public tests if necessary. No credentials retained in this receipt.'},
      'limitations':['Codex Windows desktop is unverified under accepted DEC-RLS-009 / RISK-RLS-007; revisit before the next plugin release or verified-desktop claim.','Required public fresh/update routes run only after publication; local qualification is not public evidence.','No Hosted Artifact Graph service verification, repository adoption or hosted-pin amendment.','Immutable package READMEs retain historical preparation snapshots; corrected source guidance explains their use.'],
      'authority':'Prepared input for the later exact complete-release decision; this file authorizes nothing.'}
    write(E+'complete-release-readiness.json',readiness)
    identity_raw=blob(stage['commit'],'PACKAGE-IDENTITY.json');identity=json.loads(identity_raw)
    inv=identity['files']
    plan={'schema':'se-harness-delivery-plan/v2','release':{'contract':'REL-SEH-035','record':'RLS-SEH-033','version':'0.22.1','wheel_sha256':dist['wheel_sha256']},
      'review':{'by':'mmzen','reference':'PR #536 complete-release review; read complete-release-review.md in this same pre-approval commit. No decision until the matching human response. The immutable review commit binds both the plan and its execution/recovery instructions.'},'surfaces':[]}
    settings=[
      ('evaluator','https://pypi.org/project/se-harness/0.22.1/',{'record':'RLS-SEH-033','version':'0.22.1','wheel_sha256':dist['wheel_sha256']},['publisher','public_install'],
       'After the matching complete-release decision, integrate only the RLS decision into protected main via PR #536, advance release/0.22 ordinarily from '+OLD+' to '+C+' after its ancestry/readback checks, then dispatch publish-pypi.yml on main for RLS-SEH-033. Publish only its v0.22.1 archives to GitHub and PyPI; independently download and install the exact public wheel. Stop on changed refs, provider controls or archive mismatch; preserve completed immutable output and resume only missing effects.'),
      ('marketplace','https://github.com/mmzen/se_harness.git#plugin-marketplace',{'plugin_version':'0.2.6','source_commit':C,'evaluator_version':'0.22.1','wheel_sha256':dist['wheel_sha256'],'public_revision':stage['commit'],'codex_content_sha256':inv['packages/codex/verity-plane/assembly-inventory.json'],'claude-code_content_sha256':inv['packages/claude/verity-plane/assembly-inventory.json']},['assembly','qualification','public_ref'],
       'After public-wheel byte equality, promote exactly the staged ordinary child to plugin-marketplace. Run public fresh installation and update from plugin 0.2.5 on both Windows CLIs using the actual public ref. Retain command/result/content identities. No desktop pass is claimed. Stop on a changed parent, authentication failure or any unperformed/failed route; never force, rebuild or silently replace the selected bytes.'),
      ('documentation','https://github.com/mmzen/se_harness/tree/main',{'commit':DOC},['claims_review','links'],
       'Integrate the already verified source guides with protected PR #536 using the merge method and exact checked head. Compare every frozen file at the documentation commit, release-governance commit and current main. Preserve the unchanged packaged README snapshots and verify their links in package context. Later receipts cannot edit prose or hashes; changed guidance requires changed-scope review.'),
      ('demonstration','https://mmzen.github.io/se_harness/',{'governance_commit':'release-governance'},['deployment'],
       'Use the existing Pages workflow for the first protected-main commit containing the exact released RLS and approved delivery binding. Read back deployment provenance through the canonical URL and existing www.verityplane.ai destination. Do not change the domain or provider settings. A failed or unknown deployment remains pending; inspect before retry.'),
      ('release_markers','https://github.com/mmzen/se_harness',{'latest':'v0.22.1','last':C},['authorization','readback'],
       'Only after all required non-marker observations pass, promote latest from v0.22.0 to v0.22.1 and last from '+OLD+' to '+C+'. Use the existing serialized publisher and exact last lease. Stop on unexpected movement. Read back both targets, integrate the named JSON receipts via protected PRs, and produce the five-surface completion report. This is the sole explicitly permitted moving-tag operation; no immutable version tag may move.')]
    for name,destination,expected,observations,next_action in settings:
        surface={'id':name,'owner':'mmzen','disposition':'update','destination':destination,'work_reference':'WO-RLS-042','next_action':next_action,'expected':expected,'required_observations':observations}
        if name=='marketplace':surface['hosts']=['codex','claude-code']
        if name=='documentation':surface['work_reference']='WO-RLS-044; verified by VREC-RLS-003; public observations under WO-RLS-042'
        plan['surfaces'].append(surface)
    receipt_names=['observations.json','publisher.json','evaluator-public-install.json','marketplace-public-ref.json','codex-public-fresh.json','codex-public-update.json','claude-code-public-fresh.json','claude-code-public-update.json','documentation-observations.json','pages-observations.json','release-marker-receipt.json','delivery-result.json','maintenance-line.json','integration-receipts.json']
    doc_paths=['README.md','docs/notes/plugin-installation-guide.md','docs/notes/plugin-marketplace-publication.md',P+'README.md']
    plan['complete_release']={'repository':'mmzen/se_harness','candidate_commit':C,'actions':['release-integration','version-tag','github-release','pypi','maintenance-line','marketplace','documentation','pages','latest','last','receipts'],
      'marketplace':{'parent':stage['parent'],'commit':stage['commit'],'tree':stage['tree'],'identity_sha256':sha(identity_raw)},'markers':{'previous_latest':'v0.22.0','previous_last':OLD},
      'integration':{'decision_paths':[D+'releases/RLS-SEH-033.md'],'receipt_paths':[P+n for n in receipt_names]},
      'readiness':{'path':E+'complete-release-readiness.json','sha256':sha((s.REPO/E/'complete-release-readiness.json').read_bytes())},'observations':P+'observations.json','evidence_root':P.rstrip('/'),
      'documentation':{p:sha(blob(DOC,p)) for p in doc_paths}}
    for p,digest in plan['complete_release']['documentation'].items():assert sha(blob(V,p))==digest and sha((s.REPO/p).read_bytes())==digest
    write(E+'complete-release-plan.json',plan)
    print(json.dumps({'plan_sha256':sha((s.REPO/E/'complete-release-plan.json').read_bytes()),'readiness_sha256':plan['complete_release']['readiness']['sha256'],'state':'prepared; no release decision'}))
elif mode=='check':
    plan=json.loads((s.REPO/E/'complete-release-plan.json').read_text())
    spec=importlib.util.spec_from_file_location('r221_publish_checks',s.REPO/'.github/scripts/publish_release.py');pub=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pub;spec.loader.exec_module(pub)
    surfaces=pub.delivery.validate_plan(plan)
    rls=meta(D+'releases/RLS-SEH-033.md');d=rls['distribution']
    inputs=types.SimpleNamespace(candidate_commit=C,wheel_sha256=d['wheel_sha256'],version=rls['version'],wheel=d['wheel'])
    market=pub.verify_marketplace(s.REPO,inputs,plan)
    for path,digest in plan['complete_release']['documentation'].items():assert sha(blob(DOC,path))==digest and sha((s.REPO/path).read_bytes())==digest
    ready=json.loads((s.REPO/plan['complete_release']['readiness']['path']).read_text())
    assert ready['controls_ready'] is True and ready['qualification']=='passed' and ready['verification_records']==['VREC-SEH-033']
    for ev in ready['evidence']:assert sha((s.REPO/ev['path']).read_bytes())==ev['sha256'],ev['path']
    assert meta(D+'verification-records/VREC-RLS-003.md')['status']=='verified'
    print(json.dumps({'plan_sha256':sha((s.REPO/E/'complete-release-plan.json').read_bytes()),'surfaces':list(surfaces),'marketplace':market,'documentation':'all selected Git-blob hashes match','readiness':'evidence digests match; binary and documentation human verification recorded','governance_boundary':'No released RLS/binding is fabricated. Full resolver and bounded decision-diff check run only after the real human release decision and integration.'},indent=2))
