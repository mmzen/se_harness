"""Apply the explicitly authorized reviewer-only activation; retain readbacks."""
import datetime, hashlib, json, subprocess, sys
import r221_session as s
s.OUT=s.WORK/'r221-continue-20261005'
proposal_path=s.REPO/s.DOMAIN/'evidence/WO-RLS-040/provider-configuration-proposal.json'
proposal=json.loads(proposal_path.read_text())
assert hashlib.sha256(proposal_path.read_bytes()).hexdigest()=='dd3132e0653971edf203b9049899440913784d354a12fe051de07828570ae237'
mode=sys.argv[1]
def settings(env):
    rules=env['protection_rules']; reviewer=next((x for x in rules if x['type']=='required_reviewers'),{})
    assert all(x['type'] in ('required_reviewers','branch_policy','wait_timer') for x in rules),rules
    return {'wait_timer':next((x['wait_timer'] for x in rules if x['type']=='wait_timer'),0),
        'prevent_self_review':reviewer.get('prevent_self_review',False),
        'reviewers':[{'type':x['type'],'id':x['reviewer']['id']} for x in reviewer.get('reviewers',[])],
        'deployment_branch_policy':env['deployment_branch_policy']}
def api(name,path):return s.run(name,['gh','api',path])[0]
if mode=='prepare':
    s.gov('provider-context','check','--artifact','WO-RLS-040')
    s.gov('provider-preaction','check','--artifact','WO-RLS-040','--checkpoint','pre-action','--from-git',s.BASE)
    before=api('activation-before','repos/mmzen/se_harness/environments/pypi')
    branches=api('activation-branches-before','repos/mmzen/se_harness/environments/pypi/deployment-branch-policies')
    rules=api('activation-main-before','repos/mmzen/se_harness/rules/branches/main')
    permissions=api('activation-workflow-permissions-before','repos/mmzen/se_harness/actions/permissions/workflow')
    assert settings(before)==proposal['before']
    assert [(x['name'],x['type']) for x in branches['branch_policies']]==[('main','branch')]
    assert {'pull_request','required_status_checks','non_fast_forward','deletion'} <= {x['type'] for x in rules}
    authority={'human':'mmzen','question':'1/3 — Authorize the exact proposal in PR #536 to remove only the required reviewer from GitHub’s pypi environment in mmzen/se_harness, preserving main-only deployment and all other settings? Your previous approval excluded this configuration change.',
        'response':'Authorize the exact configuration change',
        'publisher_confirmation_question':'2/3 — Can you confirm that the se-harness project’s PyPI Publishing settings list GitHub owner mmzen, repository se_harness, workflow publish-pypi.yml, and environment pypi? No password or token is needed here.',
        'publisher_confirmation_response':'Confirmed—all four values match',
        'publisher_confirmation_source':'Human account-side confirmation in this conversation; the agent browser remained unauthenticated.',
        'reviewed_proposal_sha256':hashlib.sha256(proposal_path.read_bytes()).hexdigest(),
        'repository':'mmzen/se_harness','environment':'pypi','requested_change':'Remove only the required reviewer; preserve the main-only branch policy and all other controls.',
        'authority_limits':'No publication, release, merge, adoption or desktop-test acceptance.',
        'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    p=s.OUT/'activation-human-decision.json';assert not p.exists();p.write_text(json.dumps(authority,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    p=s.OUT/'activation-request.json';assert not p.exists();p.write_text(json.dumps(proposal['after'])+'\n',encoding='utf-8')
elif mode=='apply':
    authority=json.loads((s.OUT/'activation-human-decision.json').read_text());assert authority['response']=='Authorize the exact configuration change'
    # Re-observe immediately before mutation. A changed live configuration stops.
    before=api('activation-immediate-before','repos/mmzen/se_harness/environments/pypi')
    assert settings(before)==proposal['before']
    request=s.OUT/'activation-request.json';assert json.loads(request.read_text())==proposal['after']
    result,_=s.run('activation-put',['gh','api','--method','PUT','repos/mmzen/se_harness/environments/pypi','--input',request])
    assert settings(result)==proposal['after']
    after=api('activation-after','repos/mmzen/se_harness/environments/pypi')
    branches=api('activation-branches-after','repos/mmzen/se_harness/environments/pypi/deployment-branch-policies')
    rules=api('activation-main-after','repos/mmzen/se_harness/rules/branches/main')
    permissions=api('activation-workflow-permissions-after','repos/mmzen/se_harness/actions/permissions/workflow')
    read=lambda name:json.loads(json.loads((s.OUT/(name+'.json')).read_text())['stdout'])
    assert settings(after)==proposal['after']
    assert branches==read('activation-branches-before')
    assert rules==read('activation-main-before')
    assert permissions==read('activation-workflow-permissions-before')
    ignored={'protection_rules','updated_at'}
    assert {k:v for k,v in before.items() if k not in ignored}=={k:v for k,v in after.items() if k not in ignored}
    before_other=[v for v in before['protection_rules'] if v['type']!='required_reviewers']
    after_other=[v for v in after['protection_rules'] if v['type']!='required_reviewers']
    assert before_other==after_other
    receipt={'operation':'reviewer-only environment activation','status':'applied-and-read-back',
        'decision':authority,'before':settings(before),'after':settings(after),
        'unchanged':['main-only deployment branch policy','main rules','workflow default permissions','environment identity and admin-bypass setting','PyPI Trusted Publisher settings (not modified; confirmed by mmzen)'],
        'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'release_dispatched':False,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=s.REPO,text=True).strip()}
    target=s.REPO/s.DOMAIN/'evidence/WO-RLS-040/provider-configuration-applied.json';assert not target.exists()
    target.write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'status':receipt['status'],'receipt':str(target)}))
else:raise SystemExit(mode)
