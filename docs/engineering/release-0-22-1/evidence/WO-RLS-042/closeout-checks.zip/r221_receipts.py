"""Prepare and integrate only the frozen release's permitted JSON receipts."""
import datetime,hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
import r221_session as s
s.OUT=s.WORK/'r221-delivery-corrected-20261005';R=s.WORK/'r221receipts'
M=(s.OUT/'release-merge-head.txt').read_text().strip();C='4f640284ec496b88cd7aa4ba88ca537d9374a2f8'
SHA='50c97db22f33cdcf0eb44b229b5e1ab7d5afca887cca6ffb4a9e380bc8c3641b'
P=s.DOMAIN+'evidence/WO-RLS-042/';E=s.DOMAIN+'evidence/WO-RLS-040/'
binding={'release_record':'RLS-SEH-033','candidate_commit':C,'plan_sha256':SHA}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def raw(name):return read(s.OUT/(name+'.json'))
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def write(name,value):
    value={**binding,**value};assert all(value[k]==v for k,v in binding.items());p=R/P/name;p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8')
def ref(name):return [{'path':name,'sha256':hashlib.sha256((R/P/name).read_bytes()).hexdigest()}]
def embedded(p):
    b=(s.REPO/p).read_bytes();return {'path':p,'commit':M,'sha256':hashlib.sha256(b).hexdigest(),'content':json.loads(b) if p.endswith('.json') else b.decode()}
mode=sys.argv[1]
if mode=='prepare':
    assert not R.exists();s.run('receipts-clone',['git','-c','core.autocrlf=false','-c','core.longpaths=true','clone','--shared','--no-checkout',s.REPO,R])
    for key,value in [('core.autocrlf','false'),('core.longpaths','true')]:s.run('receipts-config-'+key,['git','config',key,value],cwd=R)
    s.run('receipts-checkout',['git','checkout','-b','codex/release-0-22-1-receipts',M],cwd=R)
    s.run('receipts-origin',['git','remote','set-url','origin','https://github.com/mmzen/se_harness.git'],cwd=R)
    assert not git('status','--porcelain')
    plan=read(R/E/'complete-release-plan.json');assert hashlib.sha256((R/E/'complete-release-plan.json').read_bytes()).hexdigest()==SHA
    release=embedded(s.DOMAIN+'releases/RLS-SEH-033.md')
    write('publisher.json',{'observed_at':now(),'workflow_url':'https://github.com/mmzen/se_harness/actions/runs/37285470260','released_record':release,'decision_envelope':read(s.OUT/'release-envelope.json'),'attempt1':{'status':raw('publisher-attempt1-final'),'marketplace_log':raw('marketplace-job-log-attempt1-raw'),'result':read(s.OUT/'publisher-attempt1/release-result.json')},'attempt2':{'status':raw('publisher-attempt2-final'),'completion_log':raw('publisher-attempt2-failed-log'),'result':read(s.OUT/'publisher-attempt2/release-result-RLS-SEH-033/release-result.json')},'recovery':'PyPI index did not expose the just-published release during attempt 1. Independent public archive downloads then passed. Retried only failed jobs; marketplace promotion succeeded. Marker phase correctly refused missing committed public observations. Public candidate verification and release approval unchanged.'})
    install=read(s.OUT/'evaluator-public/result.json');assert install['status']=='pass';write('evaluator-public-install.json',install)
    write('marketplace-public-ref.json',{'observed_at':now(),'status':'pass','readback':raw('public-ref-confirmed'),'publisher':read(s.OUT/'publisher-attempt2/marketplace-result-RLS-SEH-033/marketplace-result.json'),'assembly':embedded(E+'final-package-identity.json'),'qualification':{'readiness':embedded(E+'complete-release-readiness.json'),'binary_verification':embedded(s.DOMAIN+'verification-records/VREC-SEH-033.md'),'retained_evidence_index':embedded(E+'final-evidence-receipt.json')},'limitations':['Codex Windows desktop remains unverified under accepted DEC-RLS-009 / RISK-RLS-007.','Public routes exercise actual native installation/update, skill discovery and setup, not a desktop or live model session.']})
    routes=[]
    for host in ('codex','claude'):
        for kind in ('fresh','update'):
            route=read(s.OUT/f'public026/{kind}-{host}-route.json');setup=read(s.OUT/f'public026/{kind}-{host}-setup.json');assert route['status']==setup['status']=='pass'
            name=f'{route["host"]}-public-{kind}.json';v={'observed_at':now(),'status':'pass','native_route':route,'setup':setup,'runner_sources':{p:(s.WORK/p).read_text() for p in ('r221_public_routes.py','r221_public_setup.py')}}
            if kind=='update':v['baseline']=read(s.OUT/f'public026/baseline-{host}-route.json')
            write(name,v);summary={k:route[k] for k in ('host','kind','status','host_version','observed_at','source','revision','plugin_version','content_sha256','evaluator_version','wheel_sha256')}
            if kind=='update':summary.update({k:route[k] for k in ('starting_version','starting_source')})
            routes.append({**summary,'evidence':ref(name)})
    for outname,inname in [('documentation-observations.json','documentation-readback.json'),('pages-observations.json','pages-readback.json')]:
        v=read(s.OUT/inname);assert v['status']=='pass';write(outname,v)
    write('maintenance-line.json',{'observed_at':now(),'status':'pass','commands':[raw(n) for n in ('maintenance-before','maintenance-current-controls','maintenance-ancestry','maintenance-ordinary-push','maintenance-after','public-ref-confirmed')]})
    write('integration-receipts.json',{'observed_at':now(),'completed_release_integration':raw('merge-pr536-readback'),'governance_commit':M,'receipt_integration':'Prepared for protected receipt-only PR; not integrated at this observation.','assurance':'WO-RLS-042 post-publication verification remains separate; these observations do not verify a future formal VREC.'})
    mapping={'evaluator':{'publisher':'publisher.json','public_install':'evaluator-public-install.json'},'marketplace':{x:'marketplace-public-ref.json' for x in ('assembly','qualification','public_ref')},'documentation':{x:'documentation-observations.json' for x in ('claims_review','links')},'demonstration':{'deployment':'pages-observations.json'}}
    surfaces=[]
    for surf in plan['surfaces']:
        name=surf['id'];row={'id':name,'status':'pending' if name=='release_markers' else 'pass','observed_at':now(),'source':surf['destination'],'identity':dict(surf['expected']),'evidence':{}}
        if name=='release_markers':row.update(identity={'latest':'v0.22.0','last':'abbec12ac5524c8adfb28693f846dd59de88f759'},note='Markers unchanged until this exact public observation package is integrated and assessed.');row['evidence']={'authorization':ref('publisher.json'),'readback':ref('maintenance-line.json')}
        else:row['evidence']={k:ref(v) for k,v in mapping[name].items()}
        if name=='marketplace':row['routes']=routes
        if name=='demonstration':row['identity']['governance_commit']=M
        surfaces.append(row)
    write('observations.json',{'schema':'se-harness-delivery-observations/v1','observed_at':now(),'release':{'record':'RLS-SEH-033','status':'released','source':'https://github.com/mmzen/se_harness/blob/'+M+'/'+s.DOMAIN+'releases/RLS-SEH-033.md','observed_at':now(),'evidence':ref('publisher.json')},'surfaces':surfaces})
    spec=importlib.util.spec_from_file_location('delivery',R/'scripts/check_release_delivery.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    result,code=mod.assess(R/E/'complete-release-plan.json',R/P/'observations.json',R/P,governance_commit=M,before_markers=True);assert code==0 and result['status']=='ready_for_markers',result
    write('delivery-result.json',result)
    changed=git('ls-files','--others','--exclude-standard').splitlines();assert set(changed)<=set(plan['complete_release']['integration']['receipt_paths']);print(json.dumps({'files':len(changed),'status':result['status']}))
elif mode=='check-commit':
    s.gov('receipts-validate','validate',repo=R)
    paths=git('ls-files','--others','--exclude-standard').splitlines();args=[]
    for p in paths:args+=['--changed-path',p]
    s.gov('receipts-scope','check','--artifact','WO-RLS-042','--checkpoint','scope',*args,'--changes-complete',repo=R)
    s.run('receipts-diff-check',['git','diff','--check'],cwd=R)
    s.run('receipts-stage',['git','add','--',*paths],cwd=R)
    s.run('receipts-commit',['git','commit','-m','Retain public 0.22.1 and plugin 0.2.6 observations','-m','Harness-Work-Order: WO-RLS-042'],cwd=R)
    head=git('rev-parse','HEAD');(s.OUT/'receipt1-head.txt').write_text(head+'\n')
    s.run('receipts-integration-check',[s.PYTHON,'-B','-X','utf8',R/'.github/scripts/publish_release.py','check-integration','--repository',R,'--envelope',s.OUT/'release-envelope.json','--base',M,'--head',head,'--receipts'])
    body='The approved evaluator 0.22.1 and plugin 0.2.6 are public. This receipt-only change retains independent GitHub/PyPI archive checks, four public CLI fresh/update routes with evaluator setup, documentation and Pages readback. It preserves the initial PyPI indexing failure and the later successful marketplace retry.\n\nAll non-marker observations pass. Latest/last remain pending until this protected integration lets the existing publisher assess these exact receipts. No lifecycle records, source, frozen plan or payloads change. Codex Windows desktop remains unverified under accepted DEC-RLS-009 / RISK-RLS-007. WO-RLS-042 commit-bound assurance remains separate.\n\nThis integration uses the existing complete-release grant in RLS-SEH-033.\n\nHarness-Work-Order: WO-RLS-042\n'
    (s.OUT/'receipt1-pr-body.md').write_text(body);(s.OUT/'receipt1-pr-event.json').write_text(json.dumps({'pull_request':{'body':body}}))
    s.gov('receipts-check-pr','check-pr','--event',s.OUT/'receipt1-pr-event.json','--from-git',M,repo=R)
elif mode=='push':
    head=(s.OUT/'receipt1-head.txt').read_text().strip();assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
    _,remote=s.run('receipts-main-before',['git','ls-remote','origin','refs/heads/main'],cwd=R);assert remote.stdout.split()[0]==M
    s.gov('receipts-publish-gates','check','--artifact','RLS-SEH-033','--checkpoint','pre-action','--procedure','PROC-EXTERNAL-ACTION',repo=R)
    s.run('receipts-push',['git','push','-u','origin','HEAD:refs/heads/codex/release-0-22-1-receipts'],cwd=R)
    s.run('receipts-create-pr',['gh','pr','create','--repo','mmzen/se_harness','--base','main','--head','codex/release-0-22-1-receipts','--title','Retain public release 0.22.1 and plugin 0.2.6 observations','--body-file',s.OUT/'receipt1-pr-body.md'])
