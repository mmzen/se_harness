"""Protected receipt integrations and the existing marker continuation."""
import collections,datetime,hashlib,importlib.util,json,subprocess,sys,os
from pathlib import Path
import r221_session as s
s.OUT=s.WORK/'r221-delivery-corrected-20261005';R=s.WORK/'r221receipts'
P=s.DOMAIN+'evidence/WO-RLS-042/';E=s.DOMAIN+'evidence/WO-RLS-040/'
M=(s.OUT/'release-merge-head.txt').read_text().strip();C='4f640284ec496b88cd7aa4ba88ca537d9374a2f8';SHA='50c97db22f33cdcf0eb44b229b5e1ab7d5afca887cca6ffb4a9e380bc8c3641b'
binding={'release_record':'RLS-SEH-033','candidate_commit':C,'plan_sha256':SHA}
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p):return json.loads(Path(p).read_text())
def raw(name):return read(s.OUT/(name+'.json'))
def write(name,v):
    v={**v,**binding};(R/P/name).write_text(json.dumps(v,indent=2)+'\n')
def ref(name):return [{'path':name,'sha256':hashlib.sha256((R/P/name).read_bytes()).hexdigest()}]
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def ci(n,label):
    d,_=s.run(label,['gh','pr','view',n,'--repo','mmzen/se_harness','--json','headRefOid,baseRefName,headRefName,isDraft,state,statusCheckRollup,mergeStateStatus,mergeCommit,url']);print(json.dumps({'checks':dict(collections.Counter(x.get('conclusion') or x['status'] for x in d['statusCheckRollup']))}));return d
mode=sys.argv[1]
if mode=='ci':ci(sys.argv[2],'receipt-ci-'+sys.argv[2]+'-'+sys.argv[3])
elif mode=='merge':
    n,round=sys.argv[2:];head=(s.OUT/f'receipt{round}-head.txt').read_text().strip();base=M if round=='1' else (s.OUT/'receipt1-merge.txt').read_text().strip()
    p=ci(n,f'receipt{round}-merge-ci');assert p['headRefOid']==head and p['state']=='OPEN' and p['baseRefName']=='main' and not p['isDraft']
    checks=p['statusCheckRollup'];assert checks and all(x.get('conclusion') in ('SUCCESS','SKIPPED','NEUTRAL') for x in checks);assert any(x['name']=='validate' and x['conclusion']=='SUCCESS' for x in checks)
    _,r=s.run(f'receipt{round}-merge-main',['git','ls-remote','origin','refs/heads/main'],cwd=R);assert r.stdout.split()[0]==base
    rules,_=s.run(f'receipt{round}-merge-controls',['gh','api','repos/mmzen/se_harness/rules/branches/main']);assert any(x['type']=='pull_request' and x['parameters']['allowed_merge_methods']==['merge'] for x in rules)
    s.gov(f'receipt{round}-merge-gates','check','--artifact','RLS-SEH-033','--checkpoint','pre-action','--procedure','PROC-EXTERNAL-ACTION',repo=R)
    s.run(f'receipt{round}-merge-diff',[s.PYTHON,'-B','-X','utf8',R/'.github/scripts/publish_release.py','check-integration','--repository',R,'--envelope',s.OUT/'release-envelope.json','--base',base,'--head',head,'--receipts'])
    s.run(f'receipt{round}-merge',['gh','pr','merge',n,'--repo','mmzen/se_harness','--merge','--match-head-commit',head])
    p=ci(n,f'receipt{round}-merge-readback');assert p['state']=='MERGED';merged=p['mergeCommit']['oid'];(s.OUT/f'receipt{round}-merge.txt').write_text(merged+'\n')
    _,r=s.run(f'receipt{round}-main-readback',['git','ls-remote','origin','refs/heads/main'],cwd=R);assert r.stdout.split()[0]==merged
elif mode=='markers':
    assert (s.OUT/'receipt1-merge.txt').is_file()
    d,_=s.run('before-marker-resume-status',['gh','run','view','37285470260','--repo','mmzen/se_harness','--json','status,conclusion,jobs']);assert d['status']=='completed'
    assert all(j['conclusion']=='success' for j in d['jobs'] if j['name']!='Finish under the recorded complete-release approval')
    s.gov('marker-resume-gates','check','--artifact','RLS-SEH-033','--checkpoint','pre-action','--procedure','PROC-EXTERNAL-ACTION',repo=R)
    s.run('marker-resume-workflow',['gh','run','rerun','37285470260','--repo','mmzen/se_harness','--failed'])
elif mode=='final-report':
    merged=(s.OUT/'receipt2-merge.txt').read_text().strip()
    s.run('final-fetch-main',['git','fetch','origin','refs/heads/main:refs/remotes/origin/main'],cwd=R);assert git('rev-parse','origin/main')==merged
    previous=os.environ.get('GH_TOKEN')
    try:
        os.environ['GH_TOKEN']=subprocess.check_output(['gh','auth','token'],text=True).strip()
        s.run('final-complete-delivery-report',[s.PYTHON,'-B','-X','utf8',R/'.github/scripts/publish_release.py','continue-delivery','--repository',R,'--release-record','RLS-SEH-033','--stage','report','--output',s.OUT/'final-delivery-result.json'],timeout=900)
    finally:
        if previous is None:os.environ.pop('GH_TOKEN',None)
        else:os.environ['GH_TOKEN']=previous
    report=read(s.OUT/'final-delivery-result.json');assert report['status']=='complete'
    retained=read(R/P/'delivery-result.json');assert all(report[k]==v for k,v in retained.items() if k not in binding)
    d,_=s.run('before-final-workflow-resume',['gh','run','view','37285470260','--repo','mmzen/se_harness','--json','status,conclusion,jobs']);assert d['status']=='completed'
    s.gov('final-workflow-resume-gates','check','--artifact','RLS-SEH-033','--checkpoint','pre-action','--procedure','PROC-EXTERNAL-ACTION',repo=R)
    s.run('final-workflow-resume',['gh','run','rerun','37285470260','--repo','mmzen/se_harness','--failed'])
elif mode=='marker-receipts':
    base=(s.OUT/'receipt1-merge.txt').read_text().strip();assert not git('status','--porcelain')
    s.run('marker-fetch-main',['git','fetch','origin','refs/heads/main:refs/remotes/origin/main'],cwd=R);assert git('rev-parse','origin/main')==base
    s.run('marker-receipt-branch',['git','checkout','-b','codex/release-0-22-1-marker-receipts',base],cwd=R)
    status,_=s.run('publisher-attempt3-final',['gh','run','view','37285470260','--repo','mmzen/se_harness','--json','status,conclusion,jobs,url']);assert status['status']=='completed'
    s.run('publisher-attempt3-evidence',['gh','run','download','37285470260','--repo','mmzen/se_harness','--name','complete-delivery-RLS-SEH-033','--dir',s.OUT/'publisher-attempt3'])
    result=read(s.OUT/'publisher-attempt3/marker-result.json');assert result['latest']==result['last']=='exact' and result['applied'] is True and result['plan_sha256']==SHA
    latest,_=s.run('markers-latest-readback',['gh','api','repos/mmzen/se_harness/releases/latest']);assert latest['tag_name']=='v0.22.1' and not latest['draft'] and not latest['prerelease']
    _,r=s.run('markers-ref-readback',['git','ls-remote','origin','refs/tags/last','refs/tags/v0.22.1','refs/tags/v0.22.1^{}','refs/heads/plugin-marketplace','refs/heads/release/0.22'],cwd=R)
    refs={line.split()[1]:line.split()[0] for line in r.stdout.splitlines()};assert refs['refs/tags/last']==refs['refs/tags/v0.22.1^{}']==refs['refs/heads/release/0.22']==C;assert refs['refs/heads/plugin-marketplace']=='85ae003769f53908addbdcf46c820a8af530ac24'
    write('release-marker-receipt.json',{'observed_at':now(),'status':'pass','marker_result':result,'publisher_status':raw('publisher-attempt3-final'),'readbacks':[raw('markers-latest-readback'),raw('markers-ref-readback')],'authorization':read(s.OUT/'release-envelope.json'),'limitation':'Workflow marker writes succeeded. Its same-job report still reads the previously committed pending marker observation; this receipt updates that observation only after independent readback.'})
    obs=read(R/P/'observations.json');obs['observed_at']=now()
    for row in obs['surfaces']:
        if row['id']=='release_markers':
            row.update(status='pass',observed_at=now(),identity={'latest':'v0.22.1','last':C},evidence={k:ref('release-marker-receipt.json') for k in ('authorization','readback')});row.pop('note',None)
    write('observations.json',obs)
    integrations=read(R/P/'integration-receipts.json');integrations.update(observed_at=now(),public_observation_integration=raw('receipt1-merge-readback'),public_observation_merge=base,receipt_integration='Public observations integrated through PR #537. Marker receipt/report now prepared for its separately checked, protected receipt-only integration under the same unchanged grant.');write('integration-receipts.json',integrations)
    spec=importlib.util.spec_from_file_location('delivery',R/'scripts/check_release_delivery.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    result,code=mod.assess(R/E/'complete-release-plan.json',R/P/'observations.json',R/P,governance_commit=M);assert code==0 and result['status']=='complete',result;write('delivery-result.json',result)
    print(json.dumps({'status':result['status'],'surface_status':[{'id':r['id'],'status':r['status']} for r in result['surfaces']]}))
elif mode in ('marker-check-push','marker-resume-push'):
    base=(s.OUT/'receipt1-merge.txt').read_text().strip();paths=[P+x for x in ('release-marker-receipt.json','observations.json','integration-receipts.json','delivery-result.json')]
    if mode=='marker-check-push':
        s.gov('marker-receipts-validate','validate',repo=R)
        scope=[]
        for p in paths:scope+=['--changed-path',p]
        s.gov('marker-receipts-scope','check','--artifact','WO-RLS-042','--checkpoint','scope',*scope,'--changes-complete',repo=R)
        s.run('marker-receipts-add',['git','add','--',*paths],cwd=R);s.run('marker-receipts-diff-check',['git','diff','--cached','--check'],cwd=R)
    else:
        assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
        assert not git('diff','--name-only')
        s.run('marker-receipts-crlf-diff-check',['git','-c','core.whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol','diff','--cached','--check'],cwd=R)
    s.run('marker-receipts-commit',['git','commit','-m','Confirm complete 0.22.1 delivery and release markers','-m','Harness-Work-Order: WO-RLS-042'],cwd=R)
    head=git('rev-parse','HEAD');(s.OUT/'receipt2-head.txt').write_text(head+'\n')
    s.run('marker-receipts-integration',[s.PYTHON,'-B','-X','utf8',R/'.github/scripts/publish_release.py','check-integration','--repository',R,'--envelope',s.OUT/'release-envelope.json','--base',base,'--head',head,'--receipts'])
    body='The existing publisher promoted latest to v0.22.1 and last to approved candidate '+C+' after all non-marker observations passed. Independent readbacks now match every target. This receipt-only update records those results and the five-surface completion report under the unchanged RLS-SEH-033 grant.\n\nNo source, payload, formal lifecycle record or frozen plan changes. Codex Windows desktop remains unverified under accepted DEC-RLS-009 / RISK-RLS-007. WO-RLS-042 assurance remains separate.\n\nHarness-Work-Order: WO-RLS-042\n'
    (s.OUT/'receipt2-pr-body.md').write_text(body);(s.OUT/'receipt2-pr-event.json').write_text(json.dumps({'pull_request':{'body':body}}))
    s.gov('marker-receipts-check-pr','check-pr','--event',s.OUT/'receipt2-pr-event.json','--from-git',base,repo=R)
    s.gov('marker-receipts-publish-gates','check','--artifact','RLS-SEH-033','--checkpoint','pre-action','--procedure','PROC-EXTERNAL-ACTION',repo=R)
    s.run('marker-receipts-push',['git','push','-u','origin','HEAD:refs/heads/codex/release-0-22-1-marker-receipts'],cwd=R)
    s.run('marker-receipts-pr',['gh','pr','create','--repo','mmzen/se_harness','--base','main','--head','codex/release-0-22-1-marker-receipts','--title','Confirm complete 0.22.1 delivery and release markers','--body-file',s.OUT/'receipt2-pr-body.md'])
