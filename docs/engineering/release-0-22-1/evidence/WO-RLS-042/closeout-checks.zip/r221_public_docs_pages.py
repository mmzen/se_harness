"""Observe the frozen documentation and release-bound public Pages."""
import datetime,hashlib,importlib.util,json,posixpath,re,subprocess,urllib.request
import r221_session as s
s.OUT=s.WORK/'r221-delivery-corrected-20261005'
M=(s.OUT/'release-merge-head.txt').read_text().strip();C='4f640284ec496b88cd7aa4ba88ca537d9374a2f8'
plan=json.loads((s.REPO/s.DOMAIN/'evidence/WO-RLS-040/complete-release-plan.json').read_text())
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(ref,p):return subprocess.check_output(['git','show',ref+':'+p],cwd=s.REPO)
s.run('docs-fetch-main',['git','fetch','origin','refs/heads/main:refs/remotes/origin/main','refs/heads/plugin-marketplace:refs/remotes/origin/plugin-marketplace'],cwd=s.REPO)
head=subprocess.check_output(['git','rev-parse','origin/main'],cwd=s.REPO,text=True).strip();assert head==M
docs={'observed_at':now(),'public_main':head,'source_file_checks':[],'commands':[],'status':'pending'}
sources=list(plan['complete_release']['documentation'])
for p,expected in plan['complete_release']['documentation'].items():
    values={ref:sha(blob(ref,p)) for ref in ('dc3b6d39b3980299b5443e6036d3fe8aa34c4fa3',M,head)}
    assert set(values.values())=={expected},p
    docs['source_file_checks'].append({'path':p,'expected_sha256':expected,'observed':values})
spec=importlib.util.spec_from_file_location('links',s.REPO/'tests/plugin_integration/package_assembly/test_refresh_guidance.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
files={p:blob(head,p) for p in sources}
for source in sources:
    for link in re.findall(r'\[[^]]*\]\(([^)]+)\)',files[source].decode()):
        if re.match(r'(?:https?://|mailto:|#)',link):continue
        p=posixpath.normpath(posixpath.join(posixpath.dirname(source),link.split('#')[0]));files[p]=blob(head,p)
assert not mod.link_findings(files,sources)
new=plan['complete_release']['marketplace']['commit'];identity=json.loads(blob(new,'PACKAGE-IDENTITY.json'));package={p:blob(new,p) for p in identity['files']}
assert all(sha(b)==identity['files'][p] for p,b in package.items())
assert not mod.link_findings(package,['README.md','packages/codex/verity-plane/README.md','packages/claude/verity-plane/README.md'])
docs.update(status='pass',source_links='passed',public_package_links='passed',public_package_revision=new,public_package_file_count=len(package),claims_review='The four frozen source files match the independently verified documentation commit, release governance and current main. Guides distinguish prepared package snapshots, prior dated observations and current public receipt/identity checks. Public package README snapshots remain unchanged. No desktop or hosted service qualification is claimed.')
(s.OUT/'documentation-readback.json').write_text(json.dumps(docs,indent=2)+'\n')
pages={'status':'pending','observed_at':now(),'http':[],'manifests':[]}
for base in ('https://mmzen.github.io/se_harness/','https://www.verityplane.ai/'):
    observed={}
    for name in ('publication-manifest.json','index.html'):
        url=base+name
        with urllib.request.urlopen(url,timeout=120) as r:
            raw=r.read();pages['http'].append({'url':url,'resolved_url':r.url,'status':r.status,'sha256':sha(raw),'size':len(raw),'observed_at':now()})
        observed[name]=raw
    manifest=json.loads(observed['publication-manifest.json']);assert manifest['release_record']=='RLS-SEH-033' and manifest['candidate_commit']==C and manifest['governance_commit']==M
    assert manifest['published_dashboard_sha256']==sha(observed['index.html'])
    pages['manifests'].append({'source':base,'content':manifest})
pages.update(status='pass',release_record='RLS-SEH-033',candidate_commit=C,governance_commit=M)
(s.OUT/'pages-readback.json').write_text(json.dumps(pages,indent=2)+'\n')
print(json.dumps({'documentation':docs['status'],'pages':pages['status'],'governance_commit':M}))
