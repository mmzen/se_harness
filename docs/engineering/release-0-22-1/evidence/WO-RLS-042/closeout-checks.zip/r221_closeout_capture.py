"""Assess exact committed public-delivery receipts during verification capture."""
import hashlib,importlib.util,json,subprocess,sys,os
from pathlib import Path
candidate,expected=sys.argv[1:];repo=Path.cwd();P='docs/engineering/release-0-22-1/evidence/WO-RLS-042/'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==candidate
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert hashlib.sha256((repo/P/'delivery-result.json').read_bytes()).hexdigest()==expected
spec=importlib.util.spec_from_file_location('delivery',repo/'scripts/check_release_delivery.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
result,code=mod.assess(repo/'docs/engineering/release-0-22-1/evidence/WO-RLS-040/complete-release-plan.json',repo/P/'observations.json',repo/P,governance_commit='e0d50ec6255576e4b5517294c9c8bfc747b2a429')
assert code==0 and result['status']=='complete',result
for host in ('codex','claude-code'):
    for kind in ('fresh','update'):
        value=json.loads((repo/P/f'{host}-public-{kind}.json').read_text());assert value['native_route']['status']==value['setup']['status']=='pass'
        assert value['native_route']['all_installed_bytes_match'] and not value['native_route']['desktop_claim']
        if kind=='update':assert value['native_route']['starting_version']=='0.2.5' and value['baseline']['status']=='pass'
assert json.loads((repo/P/'evaluator-public-install.json').read_text())['qualification']['passed'] is True
env=dict(os.environ,PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1');env.pop('PYTHONPATH',None)
args=[sys.executable,'-B','-X','utf8','-m','se_harness','qualify','complete-candidate','.', '--candidate-commit',candidate,'--json']
q=subprocess.run(args,env=env,capture_output=True,text=True,encoding='utf-8',timeout=900)
out=Path(__file__).parent/'r221-delivery-corrected-20261005/closeout-candidate-check.json';assert not out.exists();out.write_text(json.dumps({'argv':args,'cwd':str(repo),'exit_code':q.returncode,'stdout':q.stdout,'stderr':q.stderr},indent=2)+'\n')
assert q.returncode==0,q.stdout+q.stderr
print(json.dumps({'candidate_commit':candidate,'delivery_report_sha256':expected,'delivery_status':result['status'],'surface_status':[{k:r[k] for k in ('id','status')} for r in result['surfaces']],'public_routes':4,'scope':'Fresh assessment of the exact committed retained observations; public network tests were performed and captured at their recorded times. No replay of publication and no new human verification decision.','limits':'Codex Windows desktop remains unverified under DEC-RLS-009 / RISK-RLS-007; hosted service and adoption excluded.'}))
