"""Retain independent public evaluator observations for the frozen release."""
import datetime, hashlib, json, subprocess, sys, urllib.request
from pathlib import Path
import r221_session as s
s.OUT=s.WORK/'r221-delivery-corrected-20261005'
out=s.OUT/'evaluator-public';out.mkdir(exist_ok=True)
dest=out/'result.json';assert not dest.exists()
resolved=json.loads((s.OUT/'resolved-release-plan.json').read_text())
report={'status':'pending','observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'http':[],'commands':[]}
def save():dest.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def get(url):
    with urllib.request.urlopen(url,timeout=120) as r:
        data=r.read();report['http'].append({'url':url,'resolved_url':r.url,'status':r.status,'sha256':hashlib.sha256(data).hexdigest(),'size':len(data),'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
    save();return data
def run(label,args):
    d,r=s.run('public-evaluator-'+label,args,timeout=900);report['commands'].append(json.loads((s.OUT/('public-evaluator-'+label+'.json')).read_text()));save();return d,r
meta=json.loads(get('https://pypi.org/pypi/se-harness/0.22.1/json'));report['pypi_metadata']=meta;save()
expected={'se_harness-0.22.1-py3-none-any.whl':'cb35c3c4eb51fe0fca575a9340b1cba6cd63b5f7133a0ebeb3fd32b4ed863053','se_harness-0.22.1.tar.gz':'beea95b6431ae35d383789181fc59d1aae80efdab70d517b2dedf8782dfdc240'}
public=out/'pypi';public.mkdir();github=out/'github';github.mkdir()
for name,sha in expected.items():
    entry=next(x for x in meta['urls'] if x['filename']==name);assert entry['digests']['sha256']==sha
    raw=get(entry['url']);assert hashlib.sha256(raw).hexdigest()==sha;(public/name).write_bytes(raw)
    provenance=json.loads(get(f'https://pypi.org/integrity/se-harness/0.22.1/{name}/provenance'));assert provenance['attestation_bundles'];report.setdefault('provenance',{})[name]=provenance;save()
run('github-download',['gh','release','download','v0.22.1','--repo','mmzen/se_harness','--dir',github,'--pattern','se_harness-0.22.1*'])
for name,sha in expected.items():assert hashlib.sha256((github/name).read_bytes()).hexdigest()==sha
report['archive_hashes']=expected;save()
env=out/'env';run('venv',[s.PYTHON,'-m','venv',env]);py=env/'Scripts/python.exe';wheel=public/'se_harness-0.22.1-py3-none-any.whl'
run('install',[py,'-I','-m','pip','install','--disable-pip-version-check','--no-index','--no-deps',wheel])
identity,_=run('identity',[py,'-I','-m','se_harness','identity','--role','released-evaluator','--expected-version','0.22.1','--expected-root',env,'--checkout-root',s.REPO,'--evaluator-payload-sha256','0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff','--evaluator-wheel-sha256',expected[wheel.name],'--require-isolated-python','--json']);assert identity['passed']
run('qualification',[py,'-I','-m','se_harness','qualify','public-install',s.REPO,'--release-record','RLS-SEH-033','--public-wheel',wheel,'--public-wheel-sha256',expected[wheel.name],'--payload-sha256','0e7b7c2bc10b06150c6c1ebe88d796d047f5d906bdfb5ef4e00914a56c79e7ff','--output',out/'qualification.json','--json'])
report.update(status='pass',identity=identity,qualification=json.loads((out/'qualification.json').read_text()),python=str(py));save()
