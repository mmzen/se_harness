"""Command line entry point for the single-profile engineering harness."""

from __future__ import annotations

from typing import Callable, Mapping

import argparse
import contextlib
import io
import json
import re
import sys
from pathlib import Path

from se_harness.integrity import IntegrityError, pretty_json_bytes, raw_sha256
from se_harness.workflow_contract import CHECKPOINT_ORDER, EVIDENCE_CHECKPOINTS
from se_harness import __version__
from se_harness.artifact_layout import create_artifact, scaffold_domain
from se_harness.engine import generate_harness_dashboard, inspect_engineering_artifacts, validate_engineering_artifacts
from se_harness.installer import (
    HarnessError,
    apply_changes,
    ensure_target,
    format_plan,
    plan_install,
)
from se_harness.github_ci import SelectionError, select_from_event
from se_harness.mutation_guard import MutationGuardError
from se_harness.preflight import inspect_installation, render_preflight, render_preflight_json, run_preflight
from se_harness.provenance import capture_verification, capture_committed_verification, prepare_release
from se_harness.risks import OPTION_TARGETS
from se_harness.release_qualification import (
    failed_qualification,
    qualify_candidate_package,
    qualify_complete_candidate,
    qualify_public_install,
    qualify_released_root,
    render_qualification,
    write_qualification_result,
)
from se_harness.runtime_identity import inspect_runtime_identity, render_runtime_identity
from se_harness.workflow_compliance import check_workflow, evidence_packet_path, write_evidence_packet
from se_harness.workflow_contract import ContractError
from se_harness.workflow_procedures import ProcedureError
from se_harness.workflow_result import (
    render_human as render_workflow_human_v2,
    render_json as render_workflow_json_v2,
)
from se_harness.workflow import (
    RepositoryWorkflowError,
    failed_result,
    project_selected,
    plan_transition,
    preparation_result,
)
from se_harness.codes import (
    CodedError,
    E_CIP_001,
    RELEASE_RECORD_REFUSALS,
    RQ001,
    RQ002,
    VERIFICATION_RECORD_REFUSALS,
    W013,
    WEX200,
    WEX201,
    WEX210,
    WEX_ECP_002,
    WEX_ECP_010,
    WEX_ECP_014,
    W_ADS_001,
)


COMMAND_RESULT_SCHEMA = "se-harness-command-result-v1"
#: A leading diagnostic code in a raised message (ECP-CLI-006): the code becomes the
#: result's code and the message is the remainder, so no line prints a code twice.
CODE_PREFIX = re.compile(r"^(WEX(?:-[A-Z]+)?-?\d{3}): (.*)$", re.S)


def _split_code(exc: object, default: str) -> tuple[str, str]:
    """The code and message of a refusal: its two attributes when it carries them (ECP-PRM-017),
    else the one split of its leading code, else the default and the whole text."""

    code = getattr(exc, "code", None)
    message = getattr(exc, "message", None)
    if isinstance(code, str) and code and isinstance(message, str):
        return code, message
    text = str(exc)
    match = CODE_PREFIX.match(text)
    if match:
        return match.group(1), match.group(2)
    return default, text


def _record_code(exc: HarnessError, refusals: Mapping[str, str]) -> tuple[str, str]:
    """The code of a refused record preparation: its cause class, or the code it carries (ECP-CLI-007)."""

    return _split_code(exc, refusals.get(str(getattr(exc, "cause", "state")), refusals["state"]))


def _command_result(command: str, outcome: str, **members: object) -> dict[str, object]:
    return {"schema": COMMAND_RESULT_SCHEMA, "command": command, "outcome": outcome, **members}


def _print_json(payload: object) -> None:
    print(json.dumps(payload, indent=2, sort_keys=True))


def _scan_repository(target: Path) -> bytes:
    indicators = {
        "Rust": ["Cargo.toml"],
        "Python": ["pyproject.toml", "requirements.txt", "setup.py"],
        "JavaScript/TypeScript": ["package.json", "tsconfig.json"],
        "Java/JVM": ["pom.xml", "build.gradle", "build.gradle.kts"],
        ".NET": ["*.sln", "*.csproj"],
        "Go": ["go.mod"],
    }
    detected: list[str] = []
    for label, patterns in indicators.items():
        if any(any(target.glob(pattern)) for pattern in patterns):
            detected.append(label)
    ci = []
    for candidate in (".github/workflows", ".gitlab-ci.yml", "azure-pipelines.yml"):
        if (target / candidate).exists():
            ci.append(candidate)
    lines = [
        "# Engineering Harness Adoption Report",
        "",
        "> Generated inventory only. This report does not approve or infer product intent, requirements, architecture, or release authority.",
        "",
        "## Observed repository signals",
        "",
        f"- Repository: `{target.name}`",
        f"- Detected ecosystems: {', '.join(detected) if detected else 'none detected'}",
        f"- Existing CI entry points: {', '.join(ci) if ci else 'none detected'}",
        "",
        "## Human decisions required",
        "",
        "1. Record build, test, verification, ownership, and boundary facts in the owner-controlled region of `AGENTS.md`.",
        "2. Name the accountable owners for product intent, engineering, assurance, release, and operations.",
        "3. Create and approve the first intent-to-verification artifact chain using `docs/engineering/templates/`.",
        "4. Select one bounded approved work order before implementation begins.",
        "5. Add repository-specific formatter, linter, test, security, build, release, and operating checks to the verification contract.",
        "",
    ]
    return "\n".join(lines).encode("utf-8")


def _install(args: argparse.Namespace) -> int:
    target = Path(args.target)
    # ECP-INS-002/003: the target's content selects the behaviour. An absent or
    # empty target receives the complete harness; a target with content keeps
    # its files, receives the bounded fragments and the adoption report.
    existing = target.exists() and any(target.iterdir())
    report = _scan_repository(target.resolve()) if existing else None
    changes, old_lock = plan_install(target, project_name=args.project_name, mode="init", adoption_report=report)
    listed = [{"action": item.action, "path": item.path} for item in changes]
    conflicts = [item.path for item in changes if item.action == "conflict"]
    if not args.json:
        print(format_plan(changes))
    if conflicts:
        if args.json:
            _print_json(_command_result("init", "failed", changes=listed, written=False, conflicts=conflicts))
        else:
            print("conflicts must be resolved before installation; no files were written")
            if ".github/workflows/engineering-harness.yml" in conflicts:
                print("preserve repository-specific CI under another workflow filename, then rerun installation")
        return 1
    if args.dry_run:
        if args.json:
            _print_json(_command_result("init", "completed", changes=listed, written=False))
        return 0
    apply_changes(target.resolve(), changes, old_lock, allow_updates=False)
    if args.json:
        _print_json(_command_result("init", "completed", changes=listed, written=True))
    else:
        print(f"installed se-harness {__version__} in {target.resolve()}")
    return 0


def _upgrade(args: argparse.Namespace) -> int:
    target = ensure_target(Path(args.target), must_exist=True)
    changes, old_lock = plan_install(target, project_name=None, mode="upgrade", replace_files=args.replace_file)
    listed = [{"action": item.action, "path": item.path} for item in changes]
    if not args.json:
        print(format_plan(changes))
    if not args.apply:
        if args.json:
            _print_json(_command_result("upgrade", "completed", changes=listed, written=False))
        return 0
    blocked = [item.path for item in changes if item.action == "customized"]
    if blocked:
        if args.json:
            _print_json(_command_result("upgrade", "failed", changes=listed, written=False, customized=blocked))
        else:
            print("customized files require manual review; no files were written:")
            for path in blocked:
                print(f"  {path}")
            if ".github/workflows/engineering-harness.yml" in blocked:
                print(
                    "preserve repository-specific CI in a separate workflow and restore the managed destination before retrying"
                )
        return 1
    apply_changes(
        target,
        changes,
        old_lock,
        allow_updates=True,
        evidence_output=Path(args.evidence_output) if args.evidence_output else None,
        replace_files=args.replace_file,
    )
    if args.json:
        _print_json(_command_result(
            "upgrade", "completed", changes=listed, written=True,
            evidence_output=args.evidence_output if args.evidence_output else None,
        ))
        return 0
    print(f"upgraded managed files to se-harness {__version__}")
    if args.evidence_output:
        print(f"retained evaluator-upgrade evidence at {args.evidence_output}")
    else:
        print("no transaction evidence retained; pass --evidence-output to keep it")
    return 0


def _skill_ownership(args: argparse.Namespace) -> int:
    from se_harness.skill_ownership import (
        apply_skill_ownership, plan_skill_ownership,
    )

    target = Path(args.target)
    plugin_root = Path(args.plugin_root) if args.plugin_root else None
    try:
        operation = apply_skill_ownership if args.apply else plan_skill_ownership
        result = operation(target, provider=args.provider, plugin_root=plugin_root)
    except (IntegrityError, HarnessError, OSError) as exc:
        result = _command_result(
            "skill-ownership", "failed", passed=False, error=str(exc),
            provider=args.provider,
        )
    if args.json:
        _print_json(result)
    else:
        print(f"skill ownership: {result['outcome']}")
        for change in result.get("changes", []):
            print(f"  {change}")
        for conflict in result.get("conflicts", []):
            print(f"  conflict: {conflict}")
        if result.get("error"):
            print(result["error"])
    return 0 if result.get("passed") else 1


def _run_engine(target: Path, entry: Callable[[list[str] | None], int], extra: list[str]) -> int:
    """ECP-ENG-003: run an engine entry module in-process on the target; its exit code is ours."""

    target = ensure_target(target, must_exist=True)
    return entry(["--root", str(target), *extra])


def _capture_engine(entry: Callable[[list[str] | None], int], argv: list[str]) -> tuple[int, str, str]:
    """Run an engine entry module in-process and capture what it prints."""

    stdout, stderr = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        code = entry(argv)
    return code, stdout.getvalue(), stderr.getvalue()


def _inspect_repository(args: argparse.Namespace) -> int:
    target = ensure_target(Path(args.target), must_exist=True)
    code, output, error = _capture_engine(
        inspect_engineering_artifacts.main,
        [
            "--root",
            str(target),
            *(["--json"] if args.json else []),
            *(["--vocabulary-threshold", str(args.vocabulary_threshold)] if getattr(args, "vocabulary_threshold", None) is not None else []),
        ],
    )
    if code == 0 and args.json:
        try:
            report = json.loads(output)
        except json.JSONDecodeError:
            pass
        else:
            report["mode"] = "repository_wide"
            report["selection"] = {"primary": None, "artifacts": []}
            output = pretty_json_bytes(report, ensure_ascii=False).decode("utf-8")
    elif code == 0:
        output = output.replace("Harness inspection", "Harness inspection (repository_wide)", 1)
    print(output, end="")
    if error:
        print(error, end="", file=sys.stderr)
    return code


def _doctor(args: argparse.Namespace) -> int:
    target = ensure_target(Path(args.target), must_exist=True)
    checks = inspect_installation(target, verify_payload=True)
    if not args.json:
        for check in checks:
            print(f"{'PASS' if check.passed else 'FAIL'} {check.name}: {check.detail}")
    # ECP-ENG-012: the layout pass alone yields W013; the graph passes do not run.
    warnings: list[dict[str, str]] = []
    for item in validate_engineering_artifacts.canonical_layout_diagnostics(target):
        if item.code == W013:
            warnings.append({"code": item.code, "path": item.path, "message": item.message})
            if not args.json:
                print(f"WARN {item.code}: {item.path}: {item.message}")
    passed = all(item.passed for item in checks)
    if args.json:
        _print_json(_command_result(
            "doctor", "completed" if passed else "failed",
            checks=[{"name": item.name, "passed": item.passed, "detail": item.detail} for item in checks],
            warnings=warnings,
        ))
    return 0 if passed else 1


def _dashboard(args: argparse.Namespace) -> int:
    extra = ["--output", args.output] if args.output else []
    if not args.json:
        return _run_engine(Path(args.target), generate_harness_dashboard.main, extra)
    target = ensure_target(Path(args.target), must_exist=True)
    code, _, error = _capture_engine(generate_harness_dashboard.main, ["--root", str(target), *extra])
    if code == 2:
        # ECP-COR-009: the engine could not run; its refusal is ours, exit 2 as in the human rendering.
        lines = [line for line in error.splitlines() if line.strip()]
        raise HarnessError(lines[-1] if lines else "dashboard generation refused")
    output = Path(args.output) if args.output else Path("target") / "harness-dashboard"
    if not output.is_absolute():
        output = target / output
    manifest = output / "dashboard-manifest.json"
    digest = raw_sha256(manifest.read_bytes()) if manifest.is_file() else None
    members: dict[str, object] = {"output": output.as_posix(), "manifest_sha256": digest}
    if code != 0:
        # ECP-COR-010: the engine's standard error travels with the failed result.
        members["error"] = error[-2000:]
    _print_json(_command_result("dashboard", "completed" if code == 0 else "failed", **members))
    return 0 if code == 0 else 1


def _preflight(args: argparse.Namespace) -> int:
    report = run_preflight(
        Path(args.target),
        work_order_id=args.work_order,
        phase=args.phase,
    )
    print(render_preflight_json(report) if args.json else render_preflight(report))
    return 0 if report.ready else 1


def _render_selected_result(result: dict, args: argparse.Namespace) -> str:
    return render_workflow_json_v2(result) if args.json else render_workflow_human_v2(result)


def _project(target: str, artifact: str | None, *, include_background: bool, json_output: bool) -> int:
    """The checkpoint-less projection with its execution context (ECP-ONE-001 to -003, ECP-CTX-001 to -003)."""

    try:
        result = project_selected(Path(target), artifact, include_background=include_background)
    except (HarnessError, ContractError, ProcedureError, ValueError) as exc:
        code, message = _split_code(exc, WEX210)
        result = failed_result("check", artifact, message, code=code, repository_blocker=isinstance(exc, RepositoryWorkflowError))
    print(render_workflow_json_v2(result) if json_output else render_workflow_human_v2(result), end="")
    return 0 if result["operation"]["outcome"] == "completed" else 1


def _check_projection(args: argparse.Namespace) -> int:
    """`check` without a checkpoint: the projection, no gate, no write (ECP-ONE-001 to -003)."""

    for option, value in (
        ("--target", args.target_state),
        ("--procedure", args.procedure),
        ("--changed-path", args.changed_path),
        ("--changes-complete", args.changes_complete),
        ("--change-manifest", args.change_manifest),
        ("--from-git", args.from_git),
        ("--pull-request-body", args.pull_request_body),
    ):
        if value:
            raise CodedError(WEX210, f"{option} requires --checkpoint")
    return _project(args.target, args.artifact, include_background=args.include_background, json_output=args.json)


def _check(args: argparse.Namespace) -> int:
    if args.checkpoint is None:
        return _check_projection(args)
    if args.artifact is None:
        # ECP-CTX-002: the default artifact belongs to the projection only.
        raise CodedError(WEX210, "--artifact is required with --checkpoint")
    if args.change_manifest and (args.changed_path or args.changes_complete):
        raise CodedError(WEX200, "--change-manifest is mutually exclusive with --changed-path and --changes-complete"
        )
    if args.from_git is not None and (args.changed_path or args.changes_complete or args.change_manifest):
        raise CodedError(WEX_ECP_002, "--from-git is mutually exclusive with --changed-path, --changes-complete and --change-manifest"
        )
    try:
        result = check_workflow(
            Path(args.target),
            artifact_id=args.artifact,
            checkpoint=args.checkpoint,
            procedure_id=args.procedure,
            changed_paths=[Path(value).as_posix() for value in (args.changed_path or [])],
            changes_complete=args.changes_complete,
            change_manifest=Path(args.change_manifest) if args.change_manifest else None,
            pull_request_body=Path(args.pull_request_body) if args.pull_request_body else None,
            target=args.target_state,
            from_git=args.from_git,
            # ECP-PRB-002 (amended), ECP-ENG-010: the completed Git-derived handoff result is
            # retained by the run that produced it, from the one validation it holds.
            retain_handoff=args.from_git is not None and args.checkpoint == "handoff",
        )
    except (HarnessError, ContractError, ProcedureError, ValueError) as exc:
        # ECP-COR-001: one splitter, so no line carries a code twice.
        code, message = _split_code(exc, WEX210)
        result = failed_result("check", args.artifact, message, code=code)
    print(render_workflow_json_v2(result) if args.json else render_workflow_human_v2(result), end="")
    return 0 if result["operation"]["outcome"] == "completed" else 1


def _evidence(args: argparse.Namespace) -> int:
    from datetime import datetime, timezone

    now = args.rebound_at or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        result = write_evidence_packet(
            Path(args.target), artifact_id=args.artifact, checkpoint=args.checkpoint, now=now,
        )
    except (HarnessError, ContractError, ProcedureError, ValueError) as exc:
        code, message = _split_code(exc, WEX_ECP_010)
        result = failed_result("evidence", args.artifact, message, code=code)
    print(_render_selected_result(result, args), end="")
    return 0 if result["operation"]["outcome"] == "completed" else 1


def _pr_body(args: argparse.Namespace) -> int:
    from se_harness.github_ci import render_pull_request_body
    from se_harness.repository_graph import artifact_catalog, validated_repository

    root = Path(args.target).resolve()
    _, report = validated_repository(root)
    primary = artifact_catalog(report).get(args.artifact)
    if primary is None:
        # ECP-COR-011, ECP-COR-012: a failed result on stdout, exit 1, as check and evidence;
        # the one splitter names the code, as on every other result path.
        code, message = _split_code(CodedError(WEX_ECP_014, f"unknown artifact ID: {args.artifact}"), WEX210)
        if args.json:
            _print_json(_command_result("pr-body", "failed", code=code, message=message))
        else:
            print(f"{code}: {message}")
        return 1
    try:
        body = render_pull_request_body(
            root, primary, packet_directory=evidence_packet_path(root, primary, "handoff").parent,
        )
    except SelectionError as exc:
        raise HarnessError(str(exc)) from exc
    if args.json:
        _print_json(_command_result("pr-body", "completed", body=body))
        return 0
    sys.stdout.buffer.write(body.encode("utf-8"))
    sys.stdout.flush()
    return 0


def _select_work_order(args: argparse.Namespace) -> int:
    try:
        value = select_from_event(Path(args.event), field=args.field)
    except SelectionError as exc:
        raise HarnessError(f"work-order selection: {exc}") from exc
    if args.json:
        _print_json(_command_result("select-work-order", "completed", field=args.field, value=value))
    else:
        print(value)
    return 0


def _check_pr(args: argparse.Namespace) -> int:
    from se_harness.github_ci import check_pull_request
    try:
        result = check_pull_request(Path(args.target), Path(args.event), args.from_git)
    except (HarnessError, SelectionError) as exc:
        raise HarnessError(f"pull-request check: {exc}") from exc
    if args.json:
        _print_json(_command_result("check-pr", "completed", **result))
    else:
        print("PR scope and handoff passed: " + ", ".join(result["work_orders"]))
    return 0


def _capture_verification(args: argparse.Namespace) -> int:
    try:
        # ECP-ENG-010: the one validation of this command, handed to the writer and the result.
        report = validate_engineering_artifacts.validate_repository(ensure_target(Path(args.target), must_exist=True))
        refresh_from = getattr(args, "refresh_from", None)
        if refresh_from:
            source = next((item for item in report.artifacts if item.artifact_id == refresh_from), None)
            if source is None or source.artifact_type != "verification_record":
                raise HarnessError(f"unknown verification record: {refresh_from}")
            args.work_order = source.relations.get("verifies_work_order", [])
            args.verification = source.relations.get("conforms_to", [])
            args.evidence = source.metadata.get("evidence_paths", [])
        if args.test_command and not args.candidate_commit:
            raise HarnessError("--test-command requires --candidate-commit")
        capture = capture_committed_verification if args.candidate_commit else capture_verification
        candidate_options = {"candidate_commit": args.candidate_commit, "test_command": args.test_command} if args.candidate_commit else {"report": report}
        output = capture(
            Path(args.target),
            record_id=args.record_id,
            work_order_ids=args.work_order,
            verification_ids=args.verification,
            evidence_paths=args.evidence,
            owner=args.owner,
            output=args.output,
            domain=args.domain,
            refresh_from=refresh_from,
            **candidate_options,
        )
        result = preparation_result(Path(args.target), args.record_id, "capture-verification", output, report)
    except (HarnessError, ContractError, ProcedureError, ValueError) as exc:
        if isinstance(exc, MutationGuardError):
            # ECP-CLI-004, ECP-COR-005: an environment refusal is not a result; main() exits 2.
            raise
        code, message = _record_code(exc, VERIFICATION_RECORD_REFUSALS)
        result = failed_result("capture-verification", args.record_id, message, code=code)
        print(_render_selected_result(result, args), end="")
        return 1
    print(_render_selected_result(result, args), end="")
    return 0


def _prepare_release(args: argparse.Namespace) -> int:
    try:
        # ECP-ENG-010: the one validation of this command, handed to the writer and the result.
        report = validate_engineering_artifacts.validate_repository(ensure_target(Path(args.target), must_exist=True))
        output = prepare_release(
            Path(args.target),
            record_id=args.record_id,
            release_contract_id=args.release_contract,
            verification_record_ids=args.verification_record,
            work_order_ids=args.work_order,
            version=args.release_version,
            authorized_by=args.owner,
            tag=args.tag,
            output=args.output,
            domain=args.domain,
            report=report,
        )
        result = preparation_result(Path(args.target), args.record_id, "prepare-release", output, report)
    except (HarnessError, ContractError, ProcedureError, ValueError) as exc:
        if isinstance(exc, MutationGuardError):
            # ECP-CLI-004, ECP-COR-005: an environment refusal is not a result; main() exits 2.
            raise
        code, message = _record_code(exc, RELEASE_RECORD_REFUSALS)
        result = failed_result("prepare-release", args.record_id, message, code=code)
        print(_render_selected_result(result, args), end="")
        return 1
    print(_render_selected_result(result, args), end="")
    return 0


def _assignments(values: list[str], label: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for value in values:
        if "=" not in value:
            raise HarnessError(f"{label} must use ID=VALUE")
        artifact_id, selected = value.split("=", 1)
        artifact_id = artifact_id.strip()
        selected = selected.strip()
        if not artifact_id or not selected:
            raise HarnessError(f"{label} must use a non-empty ID and value")
        if artifact_id in result:
            raise HarnessError(f"duplicate {label} for {artifact_id}")
        result[artifact_id] = selected
    return result


def _refusal_code(exc: Exception) -> str:
    """The identifier of the check that refused, else the operation's generic code (ECP-KRN-008)."""

    return str(getattr(exc, "predicate_id", "") or WEX201)


def _transition(args: argparse.Namespace) -> int:
    # ECP-COR-006: option syntax is parsed before any result exists; a fault is a usage refusal.
    transitions = _assignments(args.transitions, "--set")
    decisions = _assignments(args.decisions, "--decision")
    reasons = _assignments(args.reasons, "--reason")
    primary = sorted(transitions)[0] if transitions else None
    try:
        plan = plan_transition(
            Path(args.target),
            transitions,
            decisions,
            reasons,
            apply=args.apply,
        )
        result = plan.result
    except (HarnessError, ContractError, ProcedureError, ValueError) as exc:
        if isinstance(exc, MutationGuardError):
            # ECP-COR-005: the guard is an environment refusal; main() prints it and exits 2.
            raise
        code, message = _split_code(exc, _refusal_code(exc))
        result = failed_result(
            "transition",
            primary,
            message,
            code=code,
            repository_blocker=isinstance(exc, RepositoryWorkflowError),
        )
    print(_render_selected_result(result, args), end="")
    return 0 if result["operation"]["outcome"] == "completed" else 1


def _decide(args: argparse.Namespace) -> int:
    # SPEC-RSK-010 RSK-MGT-016: the disposition also moves the raised risks the
    # decision concerns, in the same act; a decision concerning none is disposed as before.
    from se_harness.risks import dispose_decision_with_risks

    try:
        plan = dispose_decision_with_risks(
            Path(args.target),
            args.artifact,
            option=args.option,
            actor=args.decision,
            reason=args.reason,
            defer=bool(args.defer),
            withdraw=bool(args.withdraw),
            scope=tuple(args.scope or ()),
            revisit=args.revisit,
            mitigated_by=tuple(args.mitigated_by or ()),
            avoided_by=tuple(args.avoided_by or ()),
            apply=bool(args.apply),
        )
        result = plan.result
    except (HarnessError, ContractError, ProcedureError, ValueError) as exc:
        if isinstance(exc, MutationGuardError):
            raise
        code, message = _split_code(exc, _refusal_code(exc))
        result = failed_result(
            "decide",
            args.artifact,
            message,
            code=code,
            repository_blocker=isinstance(exc, RepositoryWorkflowError),
        )
    print(_render_selected_result(result, args), end="")
    return 0 if result["operation"]["outcome"] == "completed" else 1


def _raise_risk(args: argparse.Namespace) -> int:
    # SPEC-RSK-010 RSK-MGT-009 and RSK-MGT-010: one act, or a refusal before any file
    # is written; a refusal is a HarnessError main() prints, exit 2.
    from se_harness.risks import raise_risk

    result = raise_risk(
        Path(args.target),
        domain=args.domain,
        title=args.title,
        stage=args.stage,
        category=args.category,
        description=args.description,
        action=args.action,
        likelihood=args.likelihood,
        impact=args.impact,
        threatens=tuple(args.threatens or ()),
        raised_by=args.raised_by,
        owners=tuple(args.owner or ()),
        artifact_id=args.artifact_id,
        with_decision=bool(args.with_decision),
        decision_id=args.decision_id,
        recommendation=args.recommend,
        dry_run=bool(args.dry_run),
    )
    if args.json:
        _print_json(_command_result(
            "raise-risk", "completed",
            changes=[{"action": change.action, "path": change.path} for change in result.changes],
            risk=result.risk_id, decision=result.decision_id, score=result.score, dry_run=bool(args.dry_run),
        ))
        return 0
    for change in result.changes:
        print(f"{change.action:8} {change.path}")
    print(f"{result.risk_id}: raised" + (f"; score {result.score}" if result.score is not None else ""))
    if result.decision_id is not None:
        print(f"{result.decision_id} blocks {', '.join(args.threatens)} until it is disposed with harnessctl decide")
    else:
        print("No blocking decision was requested; this risk does not stop work.")
    if args.dry_run:
        print("dry run: no files were written")
    return 0


def _risks(args: argparse.Namespace) -> int:
    # SPEC-RSK-010 RSK-MGT-033: a read-only listing; every field is rendered as text.
    from se_harness.risks import risks_threatening

    rows = risks_threatening(Path(args.target), args.artifact)
    if args.json:
        _print_json(_command_result("risks", "completed", artifact=args.artifact, risks=rows))
        return 0
    if not rows:
        print(f"no risk threatens {args.artifact} or its governing chain")
        return 0
    print(f"risks threatening {args.artifact} and its governing chain:")
    for row in rows:
        decision = row["decision"] or "none pending"
        print(f"- {row['id']} score {row['score']} {row['status']} ({row['stage']}, {row['category']}): threatens {', '.join(row['threatens'])}; decision {decision}")
    return 0


def _scaffold_domain(args: argparse.Namespace) -> int:
    changes = scaffold_domain(
        Path(args.target),
        domain=args.domain,
        title=args.title,
        dry_run=args.dry_run,
    )
    if args.json:
        _print_json(_command_result(
            "scaffold-domain", "completed",
            changes=[{"action": change.action, "path": change.path} for change in changes], dry_run=bool(args.dry_run),
        ))
        return 0
    for change in changes:
        print(f"{change.action:8} {change.path}")
    if args.dry_run:
        print("dry run: no files were written")
    else:
        print(f"canonical domain scaffold is available: docs/engineering/{args.domain}")
    return 0


def _create_artifact(args: argparse.Namespace) -> int:
    change = create_artifact(
        Path(args.target),
        domain=args.domain,
        artifact_type=args.artifact_type,
        artifact_id=args.artifact_id,
        dry_run=args.dry_run,
    )
    if args.json:
        members: dict[str, object] = {"changes": [{"action": change.action, "path": change.path}], "dry_run": bool(args.dry_run)}
        if change.allocated_id is not None:
            members["allocated_id"] = change.allocated_id
        _print_json(_command_result("create-artifact", "completed", **members))
        return 0
    print(f"{change.action:8} {change.path}")
    if change.allocated_id is not None:
        refs = ", ".join(change.allocation_refs) if change.allocation_refs else "no local ref"
        print(f"allocated {change.allocated_id}: the next-lower identifier was found on {refs}")
    if args.dry_run:
        print("dry run: no files were written")
    else:
        print("created an incomplete draft; complete accountable fields and run harnessctl validate before approval")
        if not args.quiet:
            from se_harness.artifact_layout import authoring_checklist

            bullets = authoring_checklist(Path(args.target), args.artifact_type)
            if bullets:
                print(f"authoring checklist for {args.artifact_type} (docs/engineering/ARTIFACT_AUTHORING.md):")
                for item in bullets:
                    print(f"- {item}")
    return 0


def _release_unit(args: argparse.Namespace) -> int:
    from se_harness.release_unit import (
        PACKAGED_SURFACE_PREFIXES,
        compare_with_contract,
        derive_release_unit,
        render_gates_toml,
        render_release_unit,
    )
    from se_harness.repository_graph import artifact_catalog, validated_repository

    root = Path(args.target)
    _, report = validated_repository(root)
    catalog = artifact_catalog(report)

    def lookup(work_order: str) -> tuple[str | None, bool | None]:
        artifact = catalog.get(work_order)
        if artifact is None:
            return None, None
        status = artifact.metadata.get("status")
        scope = artifact.metadata.get("execution_scope", {})
        paths = scope.get("paths", []) if isinstance(scope, dict) else []
        packaged = any(isinstance(item, str) and item.startswith(PACKAGED_SURFACE_PREFIXES) for item in paths)
        return (status if isinstance(status, str) else None), packaged

    unit = derive_release_unit(root, from_ref=args.from_ref, to_ref=args.to_ref, exempt=args.exempt or (), lookup=lookup)
    findings: list[str] = []
    if args.contract:
        contract = catalog.get(args.contract)
        if contract is None or contract.metadata.get("type") != "release_contract":
            raise HarnessError(f"{args.contract} is not a release contract in this repository")
        findings = compare_with_contract(unit, contract.metadata)
    if args.toml:
        print(render_gates_toml(unit), end="")
    elif args.json:
        value = unit.to_dict()
        if args.contract:
            value["contract"] = {"id": args.contract, "findings": findings}
        print(json.dumps(value, indent=2, sort_keys=True))
    else:
        print(render_release_unit(unit, findings if args.contract else None))
    return 0  # The census is advice; final verification and release approval remain mandatory.


def _identity(args: argparse.Namespace) -> int:
    report = inspect_runtime_identity(
        role=args.role,
        expected_version=args.expected_version,
        expected_root=Path(args.expected_root),
        checkout_root=Path(args.checkout_root) if args.checkout_root else None,
        candidate_commit=args.candidate_commit,
        evaluator_payload_sha256=args.evaluator_payload_sha256,
        evaluator_wheel_sha256=args.evaluator_wheel_sha256,
        entry_point=Path(args.entry_point) if args.entry_point else None,
        require_isolated_python=args.require_isolated_python,
        require_entry_point=args.require_entry_point,
    )
    if args.json:
        _print_json(report.to_dict())
    else:
        print(render_runtime_identity(report))
    return 0 if report.passed else 1


def _qualify(args: argparse.Namespace) -> int:
    operation = args.qualification_operation
    forbidden_roots: tuple[Path, ...] = ()
    try:
        if operation == "released-root":
            root = Path(args.target)
            forbidden_roots = (root.expanduser().resolve(),)
            result = qualify_released_root(root)
        elif operation == "complete-candidate":
            root = Path(args.target)
            forbidden_roots = (root.expanduser().resolve(),)
            result = qualify_complete_candidate(
                root,
                candidate_commit=args.candidate_commit,
            )
        elif operation == "candidate-package":
            checkout = Path(args.checkout_root) if args.checkout_root else None
            forbidden_roots = (checkout.expanduser().resolve(),) if checkout is not None else ()
            result = qualify_candidate_package(
                Path(args.candidate_wheel),
                candidate_commit=args.candidate_commit,
                candidate_wheel_sha256=args.candidate_wheel_sha256,
                verifier_wheel_sha256=args.verifier_wheel_sha256,
                checkout_root=checkout,
            )
        elif operation == "public-install":
            root = Path(args.target)
            forbidden_roots = (root.expanduser().resolve(),)
            result = qualify_public_install(
                root,
                release_record_id=args.release_record,
                public_wheel=Path(args.public_wheel),
                public_wheel_sha256=args.public_wheel_sha256,
                payload_sha256=args.payload_sha256,
            )
        else:
            raise HarnessError("qualification operation is unsupported")
    except (HarnessError, OSError, ValueError) as exc:
        result = failed_qualification(
            operation,
            code=RQ001,
            subject="qualification-input",
            message=str(exc),
        )

    if args.output:
        try:
            write_qualification_result(
                Path(args.output),
                result,
                forbidden_roots=forbidden_roots,
            )
        except HarnessError as exc:
            result = failed_qualification(
                operation,
                code=RQ002,
                subject="qualification-output",
                message=str(exc),
            )
    if args.json:
        print(result.canonical_bytes().decode("utf-8"), end="")
    else:
        print(render_qualification(result), end="")
    return 0 if result.passed else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="harnessctl", description="Install and operate the standard software-engineering harness.")
    parser.add_argument("--version", action="version", version=__version__)
    commands = parser.add_subparsers(dest="command", required=True)

    # ECP-INS-001: one installation command; its behaviour follows the target.
    init = commands.add_parser("init", help="install the standard harness into an absent, empty or existing repository")
    init.add_argument("target", nargs="?", default=".")
    init.add_argument("--project-name")
    init.add_argument("--dry-run", action="store_true", help="report the complete plan without writing")
    init.add_argument("--json", action="store_true", help="emit one se-harness-command-result-v1 object")
    init.set_defaults(handler=_install)
    validate = commands.add_parser("validate", help="validate the repository artifact graph")
    validate.add_argument("target", nargs="?", default=".")
    validate.add_argument("--json", action="store_true")
    validate.add_argument("--advisories", action="store_true", help="list the authoring advisories (W-AUT-*) after the warnings; --json always carries them")
    validate.set_defaults(
        handler=lambda args: _run_engine(
            Path(args.target),
            validate_engineering_artifacts.main,
            [*(["--json"] if args.json else []), *(["--advisories"] if args.advisories else [])],
        )
    )

    inspect = commands.add_parser("inspect", help="inspect repository-wide attention and lifecycle queues")
    inspect.add_argument("target", nargs="?", default=".")
    inspect.add_argument("--json", action="store_true")
    inspect.add_argument(
        "--vocabulary-threshold",
        type=int,
        default=None,
        help="occurrences from which a project term without a glossary entry is reported (30-100; default 50)",
    )
    inspect.set_defaults(handler=_inspect_repository)

    dashboard = commands.add_parser("dashboard", help="generate the repository Harness Explorer")
    dashboard.add_argument("target", nargs="?", default=".")
    dashboard.add_argument("--output")
    dashboard.add_argument("--json", action="store_true", help="emit one se-harness-command-result-v1 object")
    dashboard.set_defaults(handler=_dashboard)

    doctor = commands.add_parser("doctor", help="check an installed harness")
    doctor.add_argument("target", nargs="?", default=".")
    doctor.add_argument("--json", action="store_true", help="emit one se-harness-command-result-v1 object")
    doctor.set_defaults(handler=_doctor)

    ownership = commands.add_parser("skill-ownership", help="plan, apply, or restore explicit retained skill ownership")
    ownership.add_argument("target")
    ownership.add_argument("--provider", choices=("plugin", "repository"), required=True)
    ownership.add_argument("--plugin-root", help="installed plugin directory containing skills/")
    ownership.add_argument("--apply", action="store_true")
    ownership.add_argument("--json", action="store_true", help="emit one se-harness-command-result-v1 object")
    ownership.set_defaults(handler=_skill_ownership)

    preflight = commands.add_parser("preflight", help="check work-order implementation or review readiness")
    preflight.add_argument("target", nargs="?", default=".")
    preflight.add_argument("--work-order", required=True)
    preflight.add_argument("--phase", choices=("start", "review"), default="start")
    preflight.add_argument("--json", action="store_true")
    preflight.set_defaults(handler=_preflight)


    check = commands.add_parser(
        "check",
        help="project one selected WO, VREC, or RLS scope, or evaluate one of its checkpoints, and emit canonical restitution",
    )
    check.add_argument("target", nargs="?", default=".")
    check.add_argument(
        "--artifact",
        help="one selected WO, VREC, or RLS ID; without a checkpoint it defaults to the single in_progress work order",
    )
    check.add_argument(
        "--checkpoint", choices=CHECKPOINT_ORDER,  # ECP-PRM-012
        help="fixed stateless evaluation checkpoint; omitted, check projects the selected scope and evaluates no gate",
    )
    check.add_argument(
        "--include-background", action="store_true",
        help="with no checkpoint, list unrelated findings by category instead of one count",
    )
    check.add_argument(
        "--target", dest="target_state",
        help="target lifecycle state; required for and limited to the transition checkpoint",
    )
    check.add_argument(
        "--procedure",
        help="optional procedure override, limited to declared alternatives; otherwise selected automatically",
    )
    check.add_argument(
        "--changed-path", action="append", default=[],
        help="normalized repository-relative changed path; repeat for the declared set",
    )
    check.add_argument(
        "--changes-complete", action="store_true",
        help="assert that repeated changed paths are complete; this is evidence, not trusted proof",
    )
    check.add_argument(
        "--change-manifest",
        help="in-repository se-harness-change-set-v1 JSON; exclusive with changed-path options",
    )
    check.add_argument(
        "--from-git", metavar="BASE",
        help="derive the complete change set from Git against BASE; exclusive with the changed-path options",
    )
    check.add_argument(
        "--pull-request-body",
        help=f"UTF-8 pull-request body file; reports {W_ADS_001} when its work-order trailer carries a carriage return",
    )
    check.add_argument("--json", action="store_true", help="emit se-harness-workflow-result-v2 JSON")
    check.set_defaults(handler=_check)

    evidence = commands.add_parser("evidence", help="write or rebind one work order's evidence packet to the current formal snapshot")
    evidence.add_argument("target", nargs="?", default=".")
    evidence.add_argument("--artifact", required=True, help="the work order the packet is keyed by")
    evidence.add_argument("--checkpoint", required=True, choices=EVIDENCE_CHECKPOINTS)  # ECP-PRM-012
    evidence.add_argument("--rebound-at", help="RFC 3339 UTC timestamp to record; defaults to now")
    evidence.add_argument("--json", action="store_true", help="emit se-harness-workflow-result-v2 JSON")
    evidence.set_defaults(handler=_evidence)

    pr_body = commands.add_parser("pr-body", help="emit the LF-terminated pull-request body for one work order")
    pr_body.add_argument("target", nargs="?", default=".")
    pr_body.add_argument("--artifact", required=True, help="an approved or later work order")
    pr_body.add_argument("--json", action="store_true", help="emit one se-harness-command-result-v1 object carrying the body")
    pr_body.set_defaults(handler=_pr_body)

    transition = commands.add_parser("transition", help="plan or atomically apply explicit lifecycle transitions")
    transition.add_argument("target", nargs="?", default=".")
    transition.add_argument("--set", required=True, action="append", dest="transitions", help="explicit ID=STATUS transition; repeat for packets")
    transition.add_argument("--decision", required=True, action="append", dest="decisions", help="ID=ACTOR assertion; repeat for every selected artifact")
    transition.add_argument("--reason", action="append", default=[], dest="reasons", help="ID=TEXT reason; required for rejection, or use successor VREC ID for supersession")
    transition.add_argument("--apply", action="store_true", help="apply the exact validated transaction; default is read-only planning")
    transition.add_argument("--json", action="store_true")
    transition.set_defaults(handler=_transition)

    decide = commands.add_parser("decide", help="dispose one pending decision with a declared option, under DR-DECISION-DISPOSE")
    decide.add_argument("target", nargs="?", default=".")
    decide.add_argument("--artifact", required=True, help="the decision to dispose")
    decide.add_argument("--option", help="the declared option identifier that answers the decision")
    decide.add_argument("--decision", required=True, help="the accountable role disposing the decision")
    decide.add_argument("--reason", help="the verbatim answer; required")
    decide.add_argument("--defer", action="store_true", help="defer instead of deciding; needs --scope and --revisit")
    decide.add_argument("--scope", action="append", help="ARTIFACT-ID:FROM-TO transition a deferral admits; repeat per transition")
    decide.add_argument("--revisit", help="the release, date, or artifact state at which the decision is revisited; required for --defer and for accepting a deviation")
    decide.add_argument("--withdraw", action="store_true", help="withdraw the decision because the question no longer applies")
    decide.add_argument(
        "--mitigated-by", action="append", dest="mitigated_by",
        help="work order that reduces the raised risk this decision concerns; repeat per work order; the mitigate answer requires one",
    )
    decide.add_argument(
        "--avoided-by", action="append", dest="avoided_by",
        help="the ADR or decision recording the design change that avoids the raised risk; the avoid answer defaults to this decision",
    )
    decide.add_argument("--apply", action="store_true", help="apply the disposition; default is read-only planning")
    decide.add_argument("--json", action="store_true")
    decide.set_defaults(handler=_decide)

    raise_risk = commands.add_parser(
        "raise-risk",
        help="record a risk description, owner and next action; optionally request a blocking decision",
    )
    raise_risk.add_argument("target", nargs="?", default=".")
    raise_risk.add_argument("--domain", required=True, help="the engineering domain slug, or the identifier token of exactly one domain")
    raise_risk.add_argument("--title", required=True, help="the threat, as a noun phrase")
    raise_risk.add_argument("--stage", help="the stage the threat would damage")
    raise_risk.add_argument("--category")
    raise_risk.add_argument("--description", required=True, help="what could go wrong and why it matters")
    raise_risk.add_argument("--action", required=True, help="the next action the owner will take")
    raise_risk.add_argument("--likelihood", type=int, help="an integer from 1 to 5")
    raise_risk.add_argument("--impact", type=int, help="an integer from 1 to 5")
    raise_risk.add_argument("--threatens", action="append", help="an artifact the threat would damage; repeat per artifact")
    raise_risk.add_argument("--raised-by", default="operator", dest="raised_by", help="the actor or role recording the threat; no decision right is needed")
    raise_risk.add_argument("--owner", action="append", help="an owner of the risk; omitted, the owners of the threatened artifacts")
    raise_risk.add_argument("--id", dest="artifact_id", help="explicit RISK-DOMAIN-NNN; omitted, the lowest free identifier across every local ref is allocated")
    raise_risk.add_argument(
        "--with-decision", action="store_true", dest="with_decision",
        help="also write the open decision that blocks the threatened artifacts, with the options accept, avoid and mitigate",
    )
    raise_risk.add_argument("--decision-id", dest="decision_id", help="explicit DEC-DOMAIN-NNN for --with-decision")
    raise_risk.add_argument("--recommend", choices=tuple(OPTION_TARGETS), default="mitigate", help="the option the written decision recommends")
    raise_risk.add_argument("--dry-run", action="store_true", help="report the complete plan without writing")
    raise_risk.add_argument("--json", action="store_true", help="emit one se-harness-command-result-v1 object")
    raise_risk.set_defaults(handler=_raise_risk)

    risks = commands.add_parser("risks", help="list the risks threatening one artifact and its governing chain; writes nothing")
    risks.add_argument("target", nargs="?", default=".")
    risks.add_argument("--artifact", required=True, help="the artifact whose threats are listed")
    risks.add_argument("--json", action="store_true", help="emit one se-harness-command-result-v1 object")
    risks.set_defaults(handler=_risks)

    check_pr = commands.add_parser("check-pr", help="check a PR against its selected work orders and their combined scope")
    check_pr.add_argument("target", nargs="?", default=".")
    check_pr.add_argument("--event", required=True)
    check_pr.add_argument("--from-git", required=True)
    check_pr.add_argument("--json", action="store_true")
    check_pr.set_defaults(handler=_check_pr)

    select_work = commands.add_parser(
        "select-work-order",
        help="select one structured work-order field from a GitHub pull-request event",
    )
    select_work.add_argument("--event", required=True)
    select_work.add_argument(
        "--field", choices=("work-order", "work-orders", "restitution-digest"), default="work-order",
        help="declared field to select; restitution-digest prints empty text when absent",
    )
    select_work.add_argument("--json", action="store_true", help="emit one se-harness-command-result-v1 object")
    select_work.set_defaults(handler=_select_work_order)

    upgrade = commands.add_parser("upgrade", help="plan or apply safe harness upgrades")
    upgrade.add_argument("--replace-file", action="append", default=[], metavar="PATH", help="replace this editable seeded file with the current template; repeat for more files")
    upgrade.add_argument("target", nargs="?", default=".")
    upgrade.add_argument("--apply", action="store_true", help="apply safe changes; customized files remain untouched")
    upgrade.add_argument(
        "--evidence-output",
        help="optional repository JSON path below docs/engineering/.../evidence/ for the transaction evidence",
    )
    upgrade.add_argument("--json", action="store_true", help="emit one se-harness-command-result-v1 object")
    upgrade.set_defaults(handler=_upgrade)

    scaffold = commands.add_parser("scaffold-domain", help="safely create the canonical organization for one engineering domain")
    scaffold.add_argument("target", nargs="?", default=".")
    scaffold.add_argument("--domain", required=True)
    scaffold.add_argument("--title")
    scaffold.add_argument("--dry-run", action="store_true", help="report the complete plan without writing")
    scaffold.add_argument("--json", action="store_true", help="emit one se-harness-command-result-v1 object")
    scaffold.set_defaults(handler=_scaffold_domain)

    create = commands.add_parser("create-artifact", help="create one incomplete draft from the canonical artifact template")
    create.add_argument("target", nargs="?", default=".")
    create.add_argument("--domain", required=True)
    create.add_argument("--type", required=True, dest="artifact_type")
    create.add_argument("--id", dest="artifact_id", help="explicit identifier; omitted, the lowest free TYPE-DOMAIN-NNN across every local ref is allocated")
    create.add_argument("--dry-run", action="store_true", help="report the complete plan without writing")
    create.add_argument("--quiet", action="store_true", help="do not print the authoring checklist after creation")
    create.add_argument("--json", action="store_true", help="emit one se-harness-command-result-v1 object")
    create.set_defaults(handler=_create_artifact)

    release_unit = commands.add_parser(
        "release-unit", help="derive a release unit's work-order census from the commits between the previous release tag and a candidate commit"
    )
    release_unit.add_argument("target", nargs="?", default=".")
    release_unit.add_argument("--from", dest="from_ref", required=True, help="the previous release tag")
    release_unit.add_argument("--to", dest="to_ref", required=True, help="the candidate commit or ref")
    release_unit.add_argument("--exempt", action="append", help="full commit id on the first-parent path that carries no trailer by owner decision; repeatable")
    release_unit.add_argument("--contract", help="compare with a release contract; differences are advisory")
    release_unit.add_argument("--json", action="store_true", help="emit the canonical JSON census")
    release_unit.add_argument("--toml", action="store_true", help="emit only the gates array ready to paste into a contract")
    release_unit.set_defaults(handler=_release_unit)

    identity = commands.add_parser("identity", help="emit and verify one evaluator or candidate runtime identity")
    identity.add_argument("--role", required=True, choices=("released-evaluator", "candidate-source", "candidate-package"))
    identity.add_argument("--expected-version", required=True)
    identity.add_argument("--expected-root", required=True)
    identity.add_argument("--checkout-root")
    identity.add_argument("--candidate-commit")
    identity.add_argument("--evaluator-payload-sha256")
    identity.add_argument("--evaluator-wheel-sha256")
    identity.add_argument("--entry-point")
    identity.add_argument("--require-isolated-python", action="store_true")
    identity.add_argument("--require-entry-point", action="store_true")
    identity.add_argument("--json", action="store_true", help="emit the se-harness-runtime-identity-v4 object")
    identity.set_defaults(handler=_identity)

    qualify = commands.add_parser(
        "qualify",
        help="run one typed, provenance-bound release qualification operation",
    )
    qualification = qualify.add_subparsers(
        dest="qualification_operation",
        required=True,
    )

    def qualification_output(command: argparse.ArgumentParser) -> None:
        command.add_argument(
            "--output",
            help="external absent path for the canonical qualification result",
        )
        command.add_argument("--json", action="store_true")
        command.set_defaults(handler=_qualify)

    released_root = qualification.add_parser(
        "released-root",
        help="qualify a repository with the released evaluator that owns its root lock",
    )
    released_root.add_argument("target", nargs="?", default=".")
    qualification_output(released_root)

    complete_candidate = qualification.add_parser(
        "complete-candidate",
        help="qualify the complete candidate graph as candidate-controlled evidence",
    )
    complete_candidate.add_argument("target", nargs="?", default=".")
    complete_candidate.add_argument("--candidate-commit", required=True)
    qualification_output(complete_candidate)

    candidate_package = qualification.add_parser(
        "candidate-package",
        help="qualify an exact candidate wheel from an isolated released verifier",
    )
    candidate_package.add_argument("--candidate-wheel", required=True)
    candidate_package.add_argument("--candidate-commit", required=True)
    candidate_package.add_argument("--candidate-wheel-sha256", required=True)
    candidate_package.add_argument("--verifier-wheel-sha256", required=True)
    candidate_package.add_argument("--checkout-root")
    qualification_output(candidate_package)

    public_install = qualification.add_parser(
        "public-install",
        help="qualify an exact public wheel and the clean environment installed from it",
    )
    public_install.add_argument("target", nargs="?", default=".")
    public_install.add_argument("--release-record", required=True)
    public_install.add_argument("--public-wheel", required=True)
    public_install.add_argument("--public-wheel-sha256", required=True)
    public_install.add_argument("--payload-sha256", required=True)
    qualification_output(public_install)

    capture = commands.add_parser("capture-verification", help="prepare a ready commit-bound verification record")
    capture.add_argument("target", nargs="?", default=".")
    capture.add_argument("--id", required=True, dest="record_id")
    capture.add_argument("--work-order", required=True, action="append", help="work order to verify; repeat for aggregate candidates")
    capture.add_argument("--verification", required=True, action="append", help="applicable verification contract; repeat for aggregate candidates")
    capture.add_argument("--evidence", required=True, action="append", help="retained evidence path; repeat for aggregate candidates")
    capture.add_argument("--owner", default="quality-owner", help="preparation actor and record owner; does not verify the record")
    capture.add_argument("--output")
    capture.add_argument("--domain", help="place the record in an explicit engineering domain")
    capture.add_argument("--json", action="store_true", help="emit the canonical workflow result as JSON")
    capture.add_argument("--candidate-commit", help="test and capture this committed candidate in a temporary checkout")
    capture.add_argument("--test-command", nargs=argparse.REMAINDER, help="test command and arguments for --candidate-commit; put this option last")
    capture.set_defaults(handler=_capture_verification)

    refresh = commands.add_parser("refresh-verification", help="create a new ready record after an unchanged rebase; preserve the original")
    refresh.add_argument("target", nargs="?", default=".")
    refresh.add_argument("--from", required=True, dest="refresh_from", help="existing ready verification record ID")
    refresh.add_argument("--id", required=True, dest="record_id", help="new verification record ID")
    refresh.add_argument("--owner", default="quality-owner", help="preparation actor; does not verify either record")
    refresh.add_argument("--output")
    refresh.add_argument("--domain")
    refresh.add_argument("--json", action="store_true")
    refresh.set_defaults(handler=_capture_verification, candidate_commit=None, test_command=None)

    release = commands.add_parser("prepare-release", help="prepare a ready commit-bound release record")
    release.add_argument("target", nargs="?", default=".")
    release.add_argument("--id", required=True, dest="record_id")
    release.add_argument("--release-contract", required=True)
    release.add_argument("--verification-record", required=True, action="append", help="one verified final-candidate record covering all released work")
    release.add_argument("--work-order", required=True, action="append", help="released work order; repeat for aggregate releases")
    release.add_argument("--version", required=True, dest="release_version")
    release.add_argument("--owner", required=True, help="preparation actor and record owner; does not authorize the release")
    release.add_argument("--tag")
    release.add_argument("--output")
    release.add_argument("--domain", help="place the record in an explicit engineering domain")
    release.add_argument("--json", action="store_true", help="emit the canonical workflow result as JSON")
    release.set_defaults(handler=_prepare_release)
    return parser


def main(argv: list[str] | None = None) -> int:
    try:
        args = build_parser().parse_args(argv)
        return int(args.handler(args))
    except (
        ContractError,
        HarnessError,
        IntegrityError,
        ProcedureError,
    ) as exc:
        # ECP-COR-008: a refusal no handler converted; never a traceback.
        print(f"harnessctl: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
