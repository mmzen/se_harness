"""Canonical identity for one installed SE Harness evaluator payload."""

from __future__ import annotations

import importlib.metadata
import json
import re
import stat
import sysconfig
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import unquote, urlparse

from se_harness import __version__
from se_harness.integrity import canonical_json_bytes, raw_sha256, unique_object_hook


PAYLOAD_MANIFEST = "se-harness-installed-payload-v1"
MAX_FILE_BYTES = 16 * 1024 * 1024
MAX_FILE_COUNT = 4096
MAX_PAYLOAD_BYTES = 128 * 1024 * 1024
SHA256_PATTERN = re.compile(r"[0-9a-f]{64}")
WHEEL_PATTERN = re.compile(r"se_harness-(?P<version>[A-Za-z0-9_.!+]+)-py3-none-any\.whl")


class EvaluatorIdentityError(ValueError):
    """The installed evaluator payload cannot be identified safely."""


_unique_object = unique_object_hook(lambda key: EvaluatorIdentityError(f"installed evaluator PEP 610 metadata repeats field: {key}"))


@dataclass(frozen=True)
class InstalledEvaluatorIdentity:
    version: str
    payload_manifest: str
    payload_sha256: str
    archive_name: str | None = None
    archive_sha256: str | None = None

    def to_lock(self) -> dict[str, str | None]:
        # The lock's evaluator field set is canonical; an installation that
        # recorded no PEP 610 archive (an index install) carries the pair as
        # null rather than omitting it (SPEC-REB-012 rule 3).
        archive_known = self.archive_name is not None and self.archive_sha256 is not None
        return {
            "version": self.version,
            "payload_manifest": self.payload_manifest,
            "payload_sha256": self.payload_sha256,
            "archive_name": self.archive_name if archive_known else None,
            "archive_sha256": self.archive_sha256 if archive_known else None,
        }


def expected_wheel_name(version: str) -> str:
    return f"se_harness-{version.replace('-', '_')}-py3-none-any.whl"


def validate_wheel_name(name: str, version: str) -> bool:
    return WHEEL_PATTERN.fullmatch(name) is not None and name == expected_wheel_name(version)


def _template_root() -> Path:
    package_parent = Path(__file__).resolve().parent.parent
    candidates = (
        package_parent / "templates" / "repository" / "standard",
        Path(sysconfig.get_path("data"))
        / "share"
        / "se-harness"
        / "templates"
        / "repository"
        / "standard",
    )
    for candidate in candidates:
        if candidate.is_dir():
            return candidate.resolve()
    raise EvaluatorIdentityError("the standard evaluator templates could not be located")


def _payload_files() -> list[tuple[str, Path]]:
    roots = (
        ("se_harness", Path(__file__).resolve().parent),
        ("templates/repository/standard", _template_root()),
    )
    files: list[tuple[str, Path]] = []
    for prefix, root in roots:
        for path in root.rglob("*"):
            if path.is_symlink():
                raise EvaluatorIdentityError("the installed evaluator payload contains a symlink")
            if (
                not path.is_file()
                or "__pycache__" in path.parts
                or path.suffix.lower() in {".pyc", ".pyo"}
            ):
                continue
            relative = path.relative_to(root).as_posix()
            files.append((f"{prefix}/{relative}", path))
    files.sort(key=lambda item: item[0])
    if not files or len(files) > MAX_FILE_COUNT:
        raise EvaluatorIdentityError("the installed evaluator payload has an invalid file count")
    return files


def canonical_payload_manifest() -> bytes:
    entries: list[dict[str, Any]] = []
    total = 0
    for relative, path in sorted(_payload_files(), key=lambda item: item[0]):
        try:
            content = path.read_bytes()
        except OSError as exc:
            raise EvaluatorIdentityError(f"cannot read installed evaluator payload member: {relative}") from exc
        if len(content) > MAX_FILE_BYTES:
            raise EvaluatorIdentityError(f"installed evaluator payload member is too large: {relative}")
        total += len(content)
        if total > MAX_PAYLOAD_BYTES:
            raise EvaluatorIdentityError("the installed evaluator payload exceeds the byte limit")
        entries.append(
            {
                "bytes": len(content),
                "path": relative,
                "sha256": raw_sha256(content),
            }
        )
    value = {"files": entries, "schema": PAYLOAD_MANIFEST}
    return canonical_json_bytes(value, ensure_ascii=True)  # ECP-PRM-006, ECP-PRM-007: the same bytes


def installed_payload_sha256() -> str:
    return raw_sha256(canonical_payload_manifest())


def wheel_payload_sha256(wheel: Path, version: str) -> str:
    """Hash the installed logical payload represented by one exact wheel."""

    template_prefix = (
        f"se_harness-{version}.data/data/share/se-harness/templates/repository/standard/"
    )
    entries: list[dict[str, Any]] = []
    seen: set[str] = set()
    total = 0
    try:
        with zipfile.ZipFile(wheel) as archive:
            members = archive.infolist()
            if len(members) > MAX_FILE_COUNT * 4:
                raise EvaluatorIdentityError("evaluator wheel has too many members")
            for member in members:
                name = member.filename
                path = PurePosixPath(name)
                if (
                    not name
                    or "\\" in name
                    or path.is_absolute()
                    or any(part in {"", ".", ".."} for part in path.parts)
                    or name in seen
                ):
                    raise EvaluatorIdentityError("evaluator wheel contains an unsafe member")
                seen.add(name)
                if ((member.external_attr >> 16) & 0o170000) == stat.S_IFLNK:
                    raise EvaluatorIdentityError("evaluator wheel contains a symbolic link")
                if member.is_dir():
                    continue
                logical: str | None = None
                if name.startswith("se_harness/"):
                    logical = name
                elif name.startswith(template_prefix):
                    logical = "templates/repository/standard/" + name.removeprefix(
                        template_prefix
                    )
                if logical is None:
                    continue
                if member.file_size > MAX_FILE_BYTES:
                    raise EvaluatorIdentityError("evaluator wheel member is too large")
                content = archive.read(member)
                if len(content) != member.file_size:
                    raise EvaluatorIdentityError("evaluator wheel member size differs")
                total += len(content)
                if total > MAX_PAYLOAD_BYTES:
                    raise EvaluatorIdentityError("evaluator wheel payload exceeds the byte limit")
                entries.append(
                    {
                        "bytes": len(content),
                        "path": logical,
                        "sha256": raw_sha256(content),
                    }
                )
    except (OSError, RuntimeError, zipfile.BadZipFile) as exc:
        raise EvaluatorIdentityError("evaluator wheel is not a safe ZIP archive") from exc
    entries.sort(key=lambda item: str(item["path"]))
    logical_paths = [str(item["path"]) for item in entries]
    if (
        not entries
        or len(entries) > MAX_FILE_COUNT
        or len(set(logical_paths)) != len(logical_paths)
        or not any(path.startswith("se_harness/") for path in logical_paths)
        or not any(
            path.startswith("templates/repository/standard/")
            for path in logical_paths
        )
    ):
        raise EvaluatorIdentityError("evaluator wheel payload is incomplete or ambiguous")
    manifest = {
        "files": entries,
        "schema": PAYLOAD_MANIFEST,
    }
    return raw_sha256(canonical_json_bytes(manifest, ensure_ascii=True))


def _direct_url_archive() -> tuple[str, str] | None:
    try:
        distribution = importlib.metadata.distribution("se-harness")
    except importlib.metadata.PackageNotFoundError:
        return None
    distribution_root = Path(distribution.locate_file("")).resolve()
    try:
        Path(__file__).resolve().relative_to(distribution_root)
    except ValueError:
        return None
    raw = distribution.read_text("direct_url.json")
    if raw is None:
        return None
    try:
        value = json.loads(raw, object_pairs_hook=_unique_object)
    except json.JSONDecodeError as exc:
        raise EvaluatorIdentityError("installed evaluator has malformed PEP 610 metadata") from exc
    if not isinstance(value, dict) or "archive_info" not in value:
        return None
    archive = value.get("archive_info")
    url = value.get("url")
    if not isinstance(archive, dict) or not isinstance(url, str):
        raise EvaluatorIdentityError("installed evaluator has invalid PEP 610 archive metadata")
    hashes = archive.get("hashes")
    digest = hashes.get("sha256") if isinstance(hashes, dict) else None
    legacy_hash = archive.get("hash")
    legacy_digest = (
        legacy_hash.removeprefix("sha256=")
        if isinstance(legacy_hash, str) and legacy_hash.startswith("sha256=")
        else None
    )
    if digest is not None and legacy_digest is not None and digest != legacy_digest:
        raise EvaluatorIdentityError("installed evaluator PEP 610 SHA-256 values disagree")
    if digest is None:
        digest = legacy_digest
    if not isinstance(digest, str) or SHA256_PATTERN.fullmatch(digest) is None:
        raise EvaluatorIdentityError("installed evaluator PEP 610 metadata has no valid SHA-256")
    parsed = urlparse(url)
    name = Path(unquote(parsed.path)).name
    if not validate_wheel_name(name, __version__):
        raise EvaluatorIdentityError("installed evaluator PEP 610 wheel name is inconsistent with its version")
    return name, digest


def installed_evaluator_identity() -> InstalledEvaluatorIdentity:
    archive = _direct_url_archive()
    return InstalledEvaluatorIdentity(
        version=__version__,
        payload_manifest=PAYLOAD_MANIFEST,
        payload_sha256=installed_payload_sha256(),
        archive_name=archive[0] if archive is not None else None,
        archive_sha256=archive[1] if archive is not None else None,
    )
