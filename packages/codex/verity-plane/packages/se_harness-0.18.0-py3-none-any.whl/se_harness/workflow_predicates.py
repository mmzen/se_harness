"""The predicate seam (SPEC-ECP-024 ECP-ENG-019): the checkpoint context and the predicates that read the repository rather than the context alone.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from se_harness import front_matter
from se_harness.codes import CodedError, E_DCM_004, WEX200
from se_harness.installer import HarnessError, safe_destination
from se_harness.integrity import canonical_text
from se_harness.workflow_contract import Checkpoint
from se_harness.workflow_change_set import ChangeSet, normalize_path
from se_harness.workflow_evidence_packet import parse_evidence_header


@dataclass
class CheckpointContext:
    root: Path
    artifact: Any
    catalog: Mapping[str, Any]
    scoped_errors: list[dict[str, Any]]
    repository_errors: list[dict[str, Any]]
    unrelated_count: int
    declared_scope: tuple[str, ...]
    admitted_scope: tuple[str, ...]
    change_set: ChangeSet
    checkpoint: Checkpoint  # ECP-PRM-013
    formal_snapshot_sha256: str
    target: str | None = None
    #: ECP-ENG-010: the validation this checkpoint was built from, so no predicate validates again.
    report: Any = None


def review_evidence(context: CheckpointContext) -> tuple[str, str]:
    if context.artifact.artifact_type != "work_order":
        return "pass", "Work-order implementation evidence does not apply to this artifact type."
    # A work order can point directly at ordinary evidence files. No machine header
    # is required. Old generated packets remain readable through the path below.
    references = context.artifact.metadata.get("evidence_paths")
    if references is not None:
        if not isinstance(references, list) or not references:
            return "not_assessable", "evidence_paths must list at least one repository file."
        for reference in references:
            try:
                relative = normalize_path(reference)
                path = safe_destination(context.root, Path(relative))
                path.resolve(strict=True).relative_to(context.root.resolve())
                if not path.is_file() or not path.read_bytes().strip():
                    return "not_assessable", f"Evidence {relative} is missing or empty."
            except (HarnessError, OSError, ValueError) as exc:
                return "not_assessable", f"Cannot read evidence {reference!r}: {exc}"
        return "pass", "Retained evidence: " + ", ".join(references) + "."
    evidence_root = context.root / "docs" / "engineering"
    candidates = [
        path for path in evidence_root.rglob("*")
        if path.is_file()
        and "evidence" in path.parts
        and any(part.startswith(context.artifact.artifact_id) for part in path.parts[path.parts.index("evidence") + 1 :])
    ]
    # The handoff checkpoint is the one that retains evidence; a transition to
    # implemented accepts the handoff-bound document for the same snapshot, so
    # the transition can never pass on weaker evidence than check evaluated.
    checkpoint = "handoff" if context.checkpoint == "transition" else context.checkpoint
    for path in sorted(candidates):
        try:
            data = path.read_bytes()
        except OSError:
            continue
        relative = path.relative_to(context.root).as_posix()
        # ECP-EVD-005: the machine header is read through the TOML parser, never by
        # substring. A packet without one is not assessable (SPEC-AUT-004 AUT-WIN-007);
        # the substring grace of W-ECP-002 closed under WO-AUT-006.
        try:
            header, _ = parse_evidence_header(data)
        except HarnessError:
            continue
        if header is None:
            continue
        if (
            header["artifact"] == context.artifact.artifact_id
            and header["checkpoint"] == checkpoint
            and header["formal_snapshot_sha256"] == context.formal_snapshot_sha256
        ):
            return "pass", f"Fresh retained evidence is bound at {relative}."
    return "not_assessable", (
        f"No readable evidence for {context.artifact.artifact_id}, checkpoint {checkpoint}, "
        f"and formal snapshot {context.formal_snapshot_sha256} is available; write the header with "
        f"harnessctl evidence . --artifact {context.artifact.artifact_id} --checkpoint {checkpoint}."
    )


def pull_request_body_findings(root: Path, body_path: Path) -> list[str]:
    """Check that a supplied pull-request body is readable and selects one work order."""

    from se_harness.github_ci import MAX_EVENT_BYTES, SelectionError, select_work_orders

    try:
        with body_path.open("rb") as handle:
            raw = handle.read(MAX_EVENT_BYTES + 1)
    except OSError as exc:
        raise CodedError(WEX200, f"cannot read pull-request body: {exc}") from exc
    if len(raw) > MAX_EVENT_BYTES:
        raise CodedError(WEX200, "pull-request body exceeds the size limit")
    try:
        body = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise CodedError(WEX200, "pull-request body must be UTF-8") from exc
    try:
        select_work_orders(body)
    except SelectionError as exc:
        return [str(exc)]
    return []


_PLACEHOLDER = re.compile(r"<[A-Za-z][^>\n]{2,80}>")

_FENCE = re.compile(r"```.*?```", re.DOTALL)

_INLINE_CODE = re.compile(r"`[^`\n]*`")

_DECISION_LINE = re.compile(r"^-?\s*`?DEC-(?:[A-Z0-9]+-)*\d{3}`?(?:\s*\((?:open|deferred|decided|withdrawn)\))?\.?$")


def authoring_ready(artifact: Any, root: Path | None = None, catalog: Mapping[str, Any] | None = None) -> tuple[str, str]:
    """Refuse unfinished content or decisions; leave writing style to the author."""

    try:
        text = artifact.path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeError) as exc:
        return "not_assessable", f"{artifact.artifact_id} cannot be read: {exc}"
    prose = _INLINE_CODE.sub("", _FENCE.sub("", canonical_text(text)))  # ECP-PRM-010
    # the template's five shape comments live in the front matter; markdown headings stay
    split = front_matter.partition(prose)  # ECP-PRM-005: line-anchored on the normalized text
    if split is not None:
        head, body = split
        head = "\n".join(line for line in head.split("\n") if not line.lstrip().startswith("#"))
        prose = head + "\n+++\n" + body
    match = _PLACEHOLDER.search(prose)
    if match is not None:
        return "fail", f"{artifact.artifact_id} still carries the template placeholder {match.group(0)}."
    # the section is read with its inline code intact: the ids are written as `DEC-...`
    lines = _FENCE.sub("", canonical_text(text)).split("\n")
    for index, line in enumerate(lines):
        if line.strip() == "## Open decisions":
            body_lines = []
            for item in lines[index + 1:]:
                if item.startswith("## "):
                    break
                if item.strip():
                    body_lines.append(item.strip())
            body = body_lines[0] if body_lines else ""
            # SPEC-DCM-001 rule 11: the section reads None, or lists decision ids.
            if body not in {"None", "None."} and not all(_DECISION_LINE.fullmatch(line) for line in body_lines):
                return "fail", (
                    f"{E_DCM_004}: {artifact.artifact_id} has an open decision written as prose: {body[:120]} "
                    f"(the Open decisions section reads exactly None, or lists DEC- identifiers)"
                )
            break
    if artifact.artifact_type == "requirement":
        statement = artifact.metadata.get("statement")
        if not isinstance(statement, str) or not statement.strip():
            return "fail", f"{artifact.artifact_id} needs a non-empty statement."
        sections = front_matter.body_sections(artifact.body)
        acceptance = [sections.get("Examples"), sections.get("Acceptance"), sections.get("Acceptance criteria"),
                      artifact.metadata.get("measure"), artifact.metadata.get("verification_notes")]
        linked = [item.body for item in (catalog or {}).values()
                  if item.artifact_type == "verification" and artifact.artifact_id in item.relations.get("verifies", [])]
        if not any(isinstance(item, str) and item.strip() for item in acceptance + linked):
            return "fail", f"{artifact.artifact_id} needs an acceptance condition: add an example, measure, verification notes or a linked verification contract."
    return "pass", f"{artifact.artifact_id} has no unfinished content or unresolved decision text."



def blocking_decisions(catalog: Mapping[str, Any], artifact: Any, target: str | None) -> list[Any]:
    """Decisions that block `artifact` now (SPEC-DCM-001 rule 5).

    An `open` decision naming the artifact in `blocks` always blocks. A
    `deferred` one blocks unless its scope admits the requested transition;
    without a requested transition it does not block.
    """

    from se_harness.decisions import deferral_scope, scope_admits

    hits: list[Any] = []
    for candidate in catalog.values():
        if getattr(candidate, "artifact_type", None) != "decision":
            continue
        relations = candidate.relations if isinstance(getattr(candidate, "relations", None), Mapping) else {}
        blocked = relations.get("blocks", [])
        if not isinstance(blocked, list) or artifact.artifact_id not in blocked:
            continue
        if candidate.status == "open":
            hits.append(candidate)
        elif candidate.status == "deferred" and target is not None:
            if not scope_admits(deferral_scope(candidate), artifact.artifact_id, artifact.status, target):
                hits.append(candidate)
    return sorted(hits, key=lambda item: item.artifact_id)


def decision_gate_clear(context: CheckpointContext) -> tuple[str, str]:
    """QGP-*-DECISION: no open or unscoped deferred decision blocks the selected artifact."""

    from se_harness.decisions import declared_options, deciding_roles

    hits = blocking_decisions(context.catalog, context.artifact, context.target)
    if not hits:
        return "pass", f"No open decision blocks {context.artifact.artifact_id}."
    first = hits[0]
    question = str(first.metadata.get("question") or "").strip()
    options = "; ".join(f"{item['id']}: {item['label']}" for item in declared_options(first)) or "none declared"
    roles = ", ".join(sorted(deciding_roles(first, context.catalog))) or "the owner of the blocked artifact"
    return "fail", (
        f"{first.artifact_id} is {first.status} and blocks {context.artifact.artifact_id}: {question} "
        f"Options: {options}. Decider: {roles}. "
        f"Next: harnessctl decide . --artifact {first.artifact_id} --option OPTION-ID --decision ROLE --reason TEXT"
    )


def release_unit_ready(artifact: Any, root: Path, catalog: Mapping[str, Any]) -> tuple[str, str]:
    """Compatibility evaluator: trailer history informs the owner, not release authority."""
    return "pass", "Commit-trailer census is advisory. Approve release scope and verify the final candidate explicitly."
