"""Strict loaders and indexes for executable workflow policy."""

from __future__ import annotations

import functools
import json
import re
from dataclasses import dataclass
from pathlib import Path

from se_harness.integrity import unique_object_hook
from se_harness.codes import CodedError, WEX_ADS_001, WEX_ADS_003, WEX_ECP_030, WEX_ECP_031
from types import MappingProxyType
from typing import Any, Iterable, Mapping, Literal


WORKFLOW_SCHEMA = "se-harness-workflow-v4"
QUALITY_GATES_SCHEMA = "se-harness-quality-gates-v2"
#: Graph-structural transition checks (SPEC-ECP-005 Terms): properties of the
#: artifact graph shape alone, kept in Python and reported as predicates.
STRUCTURAL_CHECKS = frozenset({
    "QGS-EDGE",
    "QGS-ASSURANCE",
    "QGS-VREC-COVERAGE",
    "QGS-RLS-COVERAGE",
    "QGS-VERIFIED-INCLUSION",
    "QGS-SUCCESSOR",
})
BINDING_FIELDS = frozenset({"family", "target", "artifact_types", "predicates", "structural"})
STEP_KINDS = {"command", "decision", "reference"}
CORRECTIVE_KINDS = {"command", "escalation", "response"}
PARAMETER_CARDINALITIES = {"one", "zero_or_one", "one_or_more"}
PARAMETER_TYPES = {"artifact_id", "actor", "path", "path_list", "status", "text"}
#: ECP-PRM-012: the one definition of the checkpoint set; `cli.py` and `workflow_compliance.py` import it.
CHECKPOINT_ORDER: tuple[str, ...] = ("start", "pre-action", "transition", "handoff", "scope")
CHECKPOINTS = frozenset(CHECKPOINT_ORDER)
#: The checkpoints an evidence packet may be keyed by: every checkpoint but the scope projection.
EVIDENCE_CHECKPOINTS: tuple[str, ...] = CHECKPOINT_ORDER[:-1]
Checkpoint = Literal["start", "pre-action", "transition", "handoff", "scope"]
#: The prose a rule contributes to a schema-2 result (WO-ECP-005): what the
#: operation did and the lifecycle state it leaves. Every other restitution
#: field is derived from the bound procedure step.
RULE_RESTITUTION_FIELDS = frozenset({"done", "current_lifecycle_state"})
EVALUATORS = {
    "artifact_status",
    "authoring_ready",
    "release_unit_ready",
    "change_set_complete",
    "decision_gate_clear",
    "changed_paths_within_scope",
    "execution_scope_declared",
    "formal_graph_valid",
    "repository_integrity",
    "review_evidence_available",
    "review_preflight_ready",
    "start_preflight_ready",
}
_PLACEHOLDER = re.compile(r"\{([a-z][a-z0-9_]*)\}")
_ID_PATTERNS = {
    "workflow": re.compile(r"^WFL-[A-Z0-9-]+$"),
    "procedure": re.compile(r"^PROC-[A-Z0-9-]+$"),
    "step": re.compile(r"^STEP-[A-Z0-9-]+$"),
    "gate": re.compile(r"^QG-[A-Z0-9-]+$"),
    "predicate": re.compile(r"^QGP-[A-Z0-9-]+$"),
}
DEFINITION_TYPES = frozenset({
    "intent",
    "capability",
    "requirement",
    "specification",
    "architecture",
    "adr",
    "verification",
    "release_contract",
    "operating_contract",
})
LIFECYCLE_FAMILIES = frozenset(
    {"definition", "work_order", "verification_record", "release_record", "decision", "risk"}
)
#: ECP-ENG-007: the work-order states at or after implementation, defined once and checked
#: against the lifecycle registry at load (every state declared, the set closed under its edges).
IMPLEMENTED_OR_LATER_STATUSES = frozenset({"implemented", "verified", "released"})
LIFECYCLE_FIELDS = frozenset(
    {
        "transitions_to",
        "grants_authority",
        "reserves_version",
        "transitionable",
        "must_remain_visible",
        "predecessor_adapter",
    }
)
PREDECESSOR_ADAPTER_VALUES = frozenset({"none", "required"})
_STATE_NAME = re.compile(r"^[a-z][a-z0-9]*(?:_[a-z0-9]+)*$")
AGENTIC_OPERATION_FIELDS = frozenset(
    {
        "id",
        "decision_right",
        "current_status",
        "result_status",
        "gate_ids",
        "procedure_id",
        "mutation_operation",
    }
)
_DECISION_RIGHT = re.compile(r"^DR-[A-Z]+(?:-[A-Z]+)*$")
#: The family the delegation class binds (SPEC-ECP-006 ECP-DLG-001): a work order carries it.
DELEGATED_FAMILY = "work_order"
#: The closed set of predicate, gate and compliance statuses; `aggregation` orders it.
RESULT_STATUSES = frozenset({"pass", "fail", "not_assessable"})
class ContractError(RuntimeError):
    """Machine policy is malformed, ambiguous, or cannot resolve."""


class ContractRefusal(CodedError, ContractError):
    """A coded contract refusal the CLI labels (ECP-PRM-017): a `ContractError` that carries its code."""


def _section_refusal(detail: str) -> ContractError:
    """ECP-PRM-023: the one code a missing or malformed run-time contract section refuses with."""

    return ContractRefusal(WEX_ECP_031, detail)


@dataclass(frozen=True)
class DelegatedOperation:
    """One entry of `workflow_contract.json` `agentic_operations` (ECP-PRM-019).

    The JSON key keeps its schema-v4 name; the delegation class of `SPEC-ECP-006`
    reads the three delegated rights, their edges and their guard operations here.
    """

    id: str
    decision_right: str
    current_status: str
    result_status: str
    gate_ids: tuple[str, ...]
    procedure_id: str
    mutation_operation: str

    @property
    def transition(self) -> tuple[str, str, str] | None:
        """The lifecycle edge the right applies, or None when it applies none."""

        if self.current_status == self.result_status:
            return None
        return (DELEGATED_FAMILY, self.current_status, self.result_status)


def _runtime_section(contract: Mapping[str, Any], key: str, owner: str) -> object:
    if not isinstance(contract, Mapping) or key not in contract:
        raise _section_refusal(f"the {owner} contract declares no {key} section")
    return contract[key]


def _name(item: Mapping[str, Any], field: str, label: str, pattern: re.Pattern[str] | None = None) -> str:
    value = item.get(field)
    if not isinstance(value, str) or not value or (pattern is not None and not pattern.match(value)):
        raise _section_refusal(f"{label} has an invalid {field}")
    return value


def delegated_operations_of(workflow: Mapping[str, Any]) -> tuple[DelegatedOperation, ...]:
    """Read and validate `agentic_operations` (ECP-PRM-019, ECP-PRM-023).

    Every entry carries exactly the seven fields, names its own guard operation by
    its id, a decision right of the `DR-` grammar and two lifecycle state names;
    ids and rights are unique. A missing or malformed section refuses with
    `WEX-ECP-031` before any reader sees it.
    """

    raw = _runtime_section(workflow, "agentic_operations", "workflow")
    if not isinstance(raw, list) or not raw:
        raise _section_refusal("agentic_operations must be a non-empty array")
    operations: list[DelegatedOperation] = []
    for index, item in enumerate(raw):
        label = f"agentic_operations[{index}]"
        if not isinstance(item, Mapping) or set(item) != AGENTIC_OPERATION_FIELDS:
            raise _section_refusal(f"{label} must carry exactly {', '.join(sorted(AGENTIC_OPERATION_FIELDS))}")
        gate_ids = item.get("gate_ids")
        if not isinstance(gate_ids, list) or not gate_ids or not all(isinstance(gate, str) and gate for gate in gate_ids):
            raise _section_refusal(f"{label} has an invalid gate_ids")
        operation = DelegatedOperation(
            id=_name(item, "id", label),
            decision_right=_name(item, "decision_right", label, _DECISION_RIGHT),
            current_status=_name(item, "current_status", label, _STATE_NAME),
            result_status=_name(item, "result_status", label, _STATE_NAME),
            gate_ids=tuple(gate_ids),
            procedure_id=_name(item, "procedure_id", label),
            mutation_operation=_name(item, "mutation_operation", label),
        )
        if operation.mutation_operation != operation.id:
            raise _section_refusal(f"{label} must name its guard operation by its id")
        if any(known.id == operation.id or known.decision_right == operation.decision_right for known in operations):
            raise _section_refusal(f"{label} repeats an id or a decision right")
        operations.append(operation)
    return tuple(operations)


def restitution_fields_of(workflow: Mapping[str, Any]) -> tuple[str, ...]:
    """Read and validate `restitution_fields`, the schema-2 field set (ECP-PRM-020, ECP-PRM-023)."""

    raw = _runtime_section(workflow, "restitution_fields", "workflow")
    if not isinstance(raw, list) or not raw or not all(isinstance(item, str) and _STATE_NAME.match(item) for item in raw):
        raise _section_refusal("restitution_fields must be a non-empty array of field names")
    if len(set(raw)) != len(raw):
        raise _section_refusal("restitution_fields repeats a field")
    if "outcome" not in raw or not RULE_RESTITUTION_FIELDS.issubset(raw):
        raise _section_refusal("restitution_fields must carry outcome, done and current_lifecycle_state")
    return tuple(raw)


def aggregation_of(quality_gates: Mapping[str, Any]) -> tuple[str, ...]:
    """Read and validate `aggregation`, the status precedence, first wins (ECP-PRM-021, ECP-PRM-023)."""

    raw = _runtime_section(quality_gates, "aggregation", "quality-gate")
    if not isinstance(raw, list) or len(raw) != len(RESULT_STATUSES) or set(raw) != RESULT_STATUSES:
        raise _section_refusal(f"aggregation must order exactly {', '.join(sorted(RESULT_STATUSES))}")
    return tuple(raw)


@functools.lru_cache(maxsize=1)
def delegated_operations() -> tuple[DelegatedOperation, ...]:
    """The delegated operations of the installed workflow contract, read once."""

    return delegated_operations_of(load_workflow_contract())


@functools.lru_cache(maxsize=1)
def restitution_fields() -> tuple[str, ...]:
    """The schema-2 restitution field set of the installed workflow contract, read once."""

    return restitution_fields_of(load_workflow_contract())


@functools.lru_cache(maxsize=1)
def aggregation_order() -> tuple[str, ...]:
    """The status precedence of the installed quality-gate contract, read once."""

    return aggregation_of(load_quality_gate_contract())


@dataclass(frozen=True)
class LifecycleState:
    """Validated semantics for one state in one artifact family."""

    transitions_to: tuple[str, ...]
    grants_authority: bool
    reserves_version: bool
    transitionable: bool
    must_remain_visible: bool
    predecessor_adapter: str


LifecycleRegistry = Mapping[str, Mapping[str, LifecycleState]]


def validate_lifecycle_registry(workflow: Mapping[str, Any]) -> LifecycleRegistry:
    """Return the strict, immutable lifecycle index from workflow policy."""

    raw = workflow.get("lifecycles")
    if not isinstance(raw, Mapping) or set(raw) != LIFECYCLE_FAMILIES:
        raise ContractError("workflow lifecycles must declare exactly the six artifact families")
    families: dict[str, Mapping[str, LifecycleState]] = {}
    for family in sorted(LIFECYCLE_FAMILIES):
        raw_states = raw.get(family)
        if not isinstance(raw_states, Mapping) or not raw_states:
            raise ContractError(f"workflow lifecycle family {family} must contain states")
        states: dict[str, LifecycleState] = {}
        for state, raw_row in raw_states.items():
            if not isinstance(state, str) or _STATE_NAME.fullmatch(state) is None:
                raise ContractError(f"workflow lifecycle family {family} has invalid state {state!r}")
            if not isinstance(raw_row, Mapping) or set(raw_row) != LIFECYCLE_FIELDS:
                raise ContractError(f"workflow lifecycle {family}:{state} has invalid fields")
            targets = raw_row.get("transitions_to")
            if (
                not isinstance(targets, list)
                or not all(isinstance(target, str) and _STATE_NAME.fullmatch(target) for target in targets)
                or len(targets) != len(set(targets))
            ):
                raise ContractError(f"workflow lifecycle {family}:{state} has invalid transitions_to")
            boolean_fields = (
                "grants_authority",
                "reserves_version",
                "transitionable",
                "must_remain_visible",
            )
            if any(type(raw_row.get(field)) is not bool for field in boolean_fields):
                raise ContractError(f"workflow lifecycle {family}:{state} has a non-boolean property")
            adapter = raw_row.get("predecessor_adapter")
            if adapter not in PREDECESSOR_ADAPTER_VALUES:
                raise ContractError(f"workflow lifecycle {family}:{state} has invalid predecessor_adapter")
            if raw_row["transitionable"] != bool(targets):
                raise ContractError(
                    f"workflow lifecycle {family}:{state} transitionable disagrees with transitions_to"
                )
            if not raw_row["must_remain_visible"]:
                raise ContractError(f"workflow lifecycle {family}:{state} must remain visible")
            if family != "release_record" and raw_row["reserves_version"]:
                raise ContractError(f"workflow lifecycle {family}:{state} cannot reserve a release version")
            states[state] = LifecycleState(
                transitions_to=tuple(targets),
                grants_authority=raw_row["grants_authority"],
                reserves_version=raw_row["reserves_version"],
                transitionable=raw_row["transitionable"],
                must_remain_visible=raw_row["must_remain_visible"],
                predecessor_adapter=adapter,
            )
        for state, row in states.items():
            unknown = set(row.transitions_to) - set(states)
            if unknown:
                raise ContractError(
                    f"workflow lifecycle {family}:{state} targets unknown state {sorted(unknown)[0]}"
                )
        families[family] = MappingProxyType(states)
    work_order_states = families["work_order"]
    for state in sorted(IMPLEMENTED_OR_LATER_STATUSES):
        if state not in work_order_states:
            raise ContractError(f"workflow lifecycle work_order must declare the {state} state")
        if not set(work_order_states[state].transitions_to) <= IMPLEMENTED_OR_LATER_STATUSES:
            raise ContractError(f"workflow lifecycle work_order:{state} leaves the implemented-or-later states")
    return MappingProxyType(families)


def lifecycle_family(artifact_type: str) -> str:
    """The lifecycle family of an artifact type: its own for the five governed families, else definition."""

    return artifact_type if artifact_type in LIFECYCLE_FAMILIES and artifact_type != "definition" else "definition"


def load_lifecycle_registry(path: Path | None = None) -> LifecycleRegistry:
    """Load and validate the canonical lifecycle registry."""

    return validate_lifecycle_registry(load_workflow_contract(path))


_object = unique_object_hook(lambda key: ContractError(f"duplicate JSON key: {key}"))


def _load(path: Path, schema: str) -> dict[str, Any]:
    try:
        raw = path.read_bytes()
        if len(raw) > 2_000_000:
            raise ContractError(f"machine policy exceeds 2 MB: {path}")
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=_object)
    except ContractError:
        raise
    except (OSError, UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise ContractError(f"cannot load machine policy {path}: {exc}") from exc
    if not isinstance(value, dict) or value.get("schema") != schema:
        raise ContractError(f"{path} must use schema {schema}")
    return value


def load_workflow_contract(path: Path | None = None) -> dict[str, Any]:
    return _load(path or Path(__file__).with_name("workflow_contract.json"), WORKFLOW_SCHEMA)


def load_quality_gate_contract(path: Path | None = None) -> dict[str, Any]:
    # SPEC-AUT-004 AUT-WIN-009: any schema the loader does not accept meets the
    # loader's own error; the hint for the retired v1 schema closed under WO-AUT-006.
    return _load(path or Path(__file__).with_name("quality_gates_contract.json"), QUALITY_GATES_SCHEMA)


def effective_checkpoints(gate: Mapping[str, Any], predicate: Mapping[str, Any]) -> frozenset[str]:
    """A predicate's own `checkpoints` when declared, else its gate's (ECP-KRN-009)."""

    declared = predicate.get("checkpoints")
    if declared is None:
        return frozenset(str(item) for item in gate.get("checkpoints", ()))
    return frozenset(str(item) for item in declared)


def transition_binding(
    quality_gates: Mapping[str, Any], family: str, artifact_type: str, target: str
) -> tuple[list[str], list[str]]:
    """Return (predicate ids, structural check ids) bound to one lifecycle edge."""

    for binding in quality_gates.get("transition_bindings", []):
        if binding.get("family") != family or binding.get("target") != target:
            continue
        types = binding.get("artifact_types")
        if types is not None and artifact_type not in types:
            continue
        return [str(item) for item in binding.get("predicates", [])], [str(item) for item in binding.get("structural", [])]
    raise ContractRefusal(WEX_ECP_030, f"no transition binding for {family}:{artifact_type} -> {target}")


def _identifier(kind: str, value: object) -> str:
    if not isinstance(value, str) or _ID_PATTERNS[kind].fullmatch(value) is None:
        raise ContractError(f"invalid {kind} ID: {value!r}")
    return value


def _unique(items: Iterable[Mapping[str, Any]], kind: str) -> dict[str, Mapping[str, Any]]:
    result: dict[str, Mapping[str, Any]] = {}
    folded: dict[str, str] = {}
    for item in items:
        if not isinstance(item, Mapping):
            raise ContractError(f"{kind} registry entries must be objects")
        identifier = _identifier(kind, item.get("id"))
        key = identifier.casefold()
        if identifier in result or key in folded:
            raise ContractError(f"duplicate or case-ambiguous {kind} ID: {identifier}")
        result[identifier] = item
        folded[key] = identifier
    return result


def _strings(value: object, label: str) -> list[str]:
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise ContractError(f"{label} must be an array of strings")
    return value


def _validate_parameters(procedure: Mapping[str, Any]) -> set[str]:
    parameters = procedure.get("parameters")
    if not isinstance(parameters, list):
        raise ContractError(f"procedure {procedure.get('id')} parameters must be an array")
    names: set[str] = set()
    for parameter in parameters:
        if not isinstance(parameter, Mapping) or set(parameter) != {"name", "type", "cardinality", "source"}:
            raise ContractError(f"procedure {procedure.get('id')} has an invalid parameter")
        name = parameter.get("name")
        if not isinstance(name, str) or re.fullmatch(r"[a-z][a-z0-9_]*", name) is None or name in names:
            raise ContractError(f"procedure {procedure.get('id')} has a duplicate or invalid parameter")
        if parameter.get("type") not in PARAMETER_TYPES:
            raise ContractError(f"procedure {procedure.get('id')} parameter {name} has an unknown type")
        if parameter.get("cardinality") not in PARAMETER_CARDINALITIES:
            raise ContractError(f"procedure {procedure.get('id')} parameter {name} has an unknown cardinality")
        if not isinstance(parameter.get("source"), str) or not parameter["source"]:
            raise ContractError(f"procedure {procedure.get('id')} parameter {name} has no source")
        names.add(name)
    return names


def _validate_placeholders(value: object, parameters: set[str], label: str) -> None:
    if isinstance(value, str):
        unknown = set(_PLACEHOLDER.findall(value)) - parameters
        if unknown:
            raise ContractError(f"{label} has unknown placeholder(s): {', '.join(sorted(unknown))}")
    elif isinstance(value, list):
        for item in value:
            _validate_placeholders(item, parameters, label)


def _validate_corrective(
    step: Mapping[str, Any],
    gate_predicates: Mapping[str, list[str]],
    parameters: set[str],
    label: str,
) -> None:
    """Require one distinct corrective form per predicate of a gated command step (ADS-RST-001)."""

    expected = [
        predicate_id
        for gate_id in step.get("gate_ids", [])
        for predicate_id in gate_predicates.get(gate_id, [])
    ]
    corrective = step.get("corrective")
    if not expected:
        if corrective is not None:
            raise ContractRefusal(WEX_ADS_001, f"{label} declares corrective forms without gates")
        return
    if not isinstance(corrective, Mapping):
        raise ContractRefusal(WEX_ADS_001, f"{label} has no corrective forms for its gate predicates")
    if set(corrective) != set(expected):
        missing = sorted(set(expected) - set(corrective))
        extra = sorted(set(corrective) - set(expected))
        raise ContractRefusal(WEX_ADS_001, f"{label} corrective forms do not cover its predicates "
            f"(missing {missing}, extra {extra})"
        )
    for predicate_id, form in corrective.items():
        if not isinstance(form, Mapping) or form.get("kind") not in CORRECTIVE_KINDS:
            raise ContractRefusal(WEX_ADS_001, f"{label} corrective for {predicate_id} has an unknown kind")
        kind = form["kind"]
        if kind == "command":
            argv = form.get("argv")
            if set(form) != {"kind", "argv"} or not isinstance(argv, list) or not argv or not all(isinstance(item, str) for item in argv):
                raise ContractRefusal(WEX_ADS_001, f"{label} corrective command for {predicate_id} requires argv")
            _validate_placeholders(argv, parameters, f"{label} corrective {predicate_id}")
            if argv == step.get("argv"):
                raise ContractRefusal(WEX_ADS_001, f"{label} corrective for {predicate_id} repeats the evaluated command")
        elif kind == "escalation":
            right = form.get("decision_right")
            if set(form) != {"kind", "decision_right"} or not isinstance(right, str) or not right.startswith("DR-"):
                raise ContractRefusal(WEX_ADS_001, f"{label} corrective escalation for {predicate_id} needs a decision right")
        else:
            value = form.get("value")
            if set(form) != {"kind", "value"} or not isinstance(value, str) or not value.strip():
                raise ContractRefusal(WEX_ADS_001, f"{label} corrective response for {predicate_id} needs text")
            _validate_placeholders(value, parameters, f"{label} corrective {predicate_id}")


def _validate_procedures(
    workflow: Mapping[str, Any],
    gate_ids: set[str],
    gate_predicates: Mapping[str, list[str]] | None = None,
) -> dict[str, Mapping[str, Any]]:
    raw = workflow.get("procedures")
    if not isinstance(raw, list):
        raise ContractError("workflow procedures must be an array")
    procedures = _unique(raw, "procedure")
    references: dict[str, list[str]] = {identifier: [] for identifier in procedures}
    for procedure_id, procedure in procedures.items():
        parameters = _validate_parameters(procedure)
        steps = procedure.get("steps")
        if not isinstance(steps, list) or not steps or len(steps) > 64:
            raise ContractError(f"procedure {procedure_id} must contain 1 to 64 steps")
        step_ids: set[str] = set()
        for step in steps:
            if not isinstance(step, Mapping):
                raise ContractError(f"procedure {procedure_id} step must be an object")
            step_id = _identifier("step", step.get("id"))
            if step_id in step_ids:
                raise ContractError(f"procedure {procedure_id} has duplicate step {step_id}")
            step_ids.add(step_id)
            kind = step.get("kind")
            if kind not in STEP_KINDS:
                raise ContractError(f"procedure {procedure_id} step {step_id} has unknown kind")
            common = {"id", "kind", "gate_ids", "effects", "non_effects"}
            if kind == "command":
                allowed = common | {"argv", "corrective"}
                argv = step.get("argv")
                if not isinstance(argv, list) or not argv or not all(isinstance(item, str) for item in argv):
                    raise ContractError(f"procedure {procedure_id} command {step_id} requires argv")
                _validate_placeholders(argv, parameters, f"procedure {procedure_id} command {step_id}")
                _validate_corrective(
                    step, gate_predicates or {}, parameters, f"procedure {procedure_id} command {step_id}"
                )
            elif kind == "decision":
                allowed = common | {"decision_right", "role", "artifact", "outcomes", "response", "decision"}
                if not isinstance(step.get("decision_right"), str) or not str(step["decision_right"]).startswith("DR-"):
                    raise ContractError(f"procedure {procedure_id} decision {step_id} has no decision right")
                if not isinstance(step.get("role"), str) or not step["role"]:
                    raise ContractError(f"procedure {procedure_id} decision {step_id} has no role")
                outcomes = _strings(step.get("outcomes"), f"procedure {procedure_id} decision outcomes")
                if not outcomes:
                    raise ContractError(f"procedure {procedure_id} decision {step_id} has no outcomes")
                _validate_placeholders(step.get("artifact"), parameters, f"procedure {procedure_id} decision {step_id}")
                _validate_placeholders(step.get("response"), parameters, f"procedure {procedure_id} decision {step_id}")
            else:
                if "action_id" in step:
                    raise ContractError(
                        f"procedure {procedure_id} reference {step_id} declares action_id, "
                        "a withdrawn reference form; a reference step declares procedure_id only"
                    )
                target = step.get("procedure_id")
                if not isinstance(target, str):
                    raise ContractError(f"procedure {procedure_id} reference {step_id} must declare a procedure ID")
                allowed = common | {"procedure_id"}
                references[procedure_id].append(target)
            if not set(step).issubset(allowed) or not common.issubset(step) or (kind == "command" and "argv" not in step):
                raise ContractError(f"procedure {procedure_id} step {step_id} has invalid fields")
            for field in ("gate_ids", "effects", "non_effects"):
                values = _strings(step.get(field), f"procedure {procedure_id} step {step_id} {field}")
                if field == "gate_ids":
                    unknown = set(values) - gate_ids
                    if unknown:
                        raise ContractError(f"procedure {procedure_id} step {step_id} references unknown gate {sorted(unknown)[0]}")
                else:
                    _validate_placeholders(values, parameters, f"procedure {procedure_id} step {step_id} {field}")
    for source, targets in references.items():
        for target in targets:
            if target not in procedures:
                raise ContractError(f"procedure {source} references unknown procedure {target}")

    def visit(identifier: str, stack: tuple[str, ...]) -> None:
        if identifier in stack:
            raise ContractError("procedure reference cycle: " + " -> ".join((*stack, identifier)))
        if len(stack) >= 8:
            raise ContractError(f"procedure reference depth exceeds 8 at {identifier}")
        for target in references[identifier]:
            visit(target, (*stack, identifier))

    for procedure_id in procedures:
        visit(procedure_id, ())
    return procedures


def _validate_transition_bindings(
    workflow: Mapping[str, Any],
    quality_gates: Mapping[str, Any],
    gates: Mapping[str, Mapping[str, Any]],
    predicates: Mapping[str, Mapping[str, Any]],
) -> None:
    """Every lifecycle edge is bound to transition predicates or structural checks (ECP-KRN-009)."""

    raw = quality_gates.get("transition_bindings")
    if not isinstance(raw, list) or not raw:
        raise ContractRefusal(WEX_ECP_030, "quality-gate contract declares no transition bindings")
    owner: dict[str, str] = {}
    for gate_id, gate in gates.items():
        for predicate in gate["predicates"]:
            owner[str(predicate["id"])] = gate_id
    seen: set[tuple[str, str, str | None]] = set()
    bound: dict[tuple[str, str], set[str] | None] = {}
    for binding in raw:
        if not isinstance(binding, Mapping) or not {"family", "target", "predicates", "structural"}.issubset(binding) or not set(binding).issubset(BINDING_FIELDS):
            raise ContractRefusal(WEX_ECP_030, "transition binding has invalid fields")
        family = binding["family"]
        target = binding["target"]
        if family not in LIFECYCLE_FAMILIES or not isinstance(target, str) or _STATE_NAME.fullmatch(target) is None:
            raise ContractRefusal(WEX_ECP_030, f"transition binding names unknown family or state {family}:{target}")
        types = binding.get("artifact_types")
        if types is not None:
            types = _strings(types, f"transition binding {family}:{target} artifact_types")
            if family != "definition" or not set(types).issubset(DEFINITION_TYPES):
                raise ContractRefusal(WEX_ECP_030, f"transition binding {family}:{target} restricts artifact types it cannot")
        for predicate_id in _strings(binding["predicates"], f"transition binding {family}:{target} predicates"):
            gate_id = owner.get(predicate_id)
            if gate_id is None:
                raise ContractRefusal(WEX_ECP_030, f"transition binding {family}:{target} names unknown predicate {predicate_id}")
            if "transition" not in effective_checkpoints(gates[gate_id], predicates[predicate_id]):
                raise ContractRefusal(WEX_ECP_030, f"predicate {predicate_id} is bound to transition but does not declare that checkpoint")
        for structural in _strings(binding["structural"], f"transition binding {family}:{target} structural"):
            if structural not in STRUCTURAL_CHECKS:
                raise ContractRefusal(WEX_ECP_030, f"transition binding {family}:{target} names unknown structural check {structural}")
        key = (family, target, None if types is None else ",".join(sorted(types)))
        if key in seen:
            raise ContractRefusal(WEX_ECP_030, f"duplicate transition binding {family}:{target}")
        seen.add(key)
        covered = bound.setdefault((family, target), set())
        if types is None:
            bound[(family, target)] = None
        elif covered is not None:
            covered.update(types)
    registry = validate_lifecycle_registry(workflow)
    for family, states in registry.items():
        for source, row in states.items():
            for target in row.transitions_to:
                covered = bound.get((family, target), set())
                if covered is None:
                    continue
                if family != "definition" or not covered or not DEFINITION_TYPES.issubset(covered):
                    raise ContractRefusal(WEX_ECP_030, f"lifecycle edge {family}:{source} -> {target} has no transition binding"
                    )


def validate_contracts(
    workflow: Mapping[str, Any],
    quality_gates: Mapping[str, Any],
) -> tuple[dict[str, Mapping[str, Any]], dict[str, Mapping[str, Any]], dict[str, Mapping[str, Any]]]:
    allowed_workflow = {
        "schema", "normative_language", "restitution_fields", "agentic_operations", "lifecycles", "failure", "recommendations", "procedures"
    }
    if set(workflow) != allowed_workflow:
        raise ContractError("workflow contract contains unknown or missing top-level fields")
    restitution_fields_of(workflow)
    registry = validate_lifecycle_registry(workflow)
    if set(quality_gates) != {"schema", "aggregation", "gates", "transition_bindings"}:
        raise ContractError("quality-gate contract contains unknown or missing top-level fields")
    aggregation_of(quality_gates)
    gates_raw = quality_gates.get("gates")
    if not isinstance(gates_raw, list):
        raise ContractError("quality gates must be an array")
    gates = _unique(gates_raw, "gate")
    predicates: dict[str, Mapping[str, Any]] = {}
    for gate_id, gate in gates.items():
        if set(gate) != {"id", "checkpoints", "predicates"}:
            raise ContractError(f"gate {gate_id} has invalid fields")
        checkpoints = set(_strings(gate.get("checkpoints"), f"gate {gate_id} checkpoints"))
        if not checkpoints or not checkpoints.issubset(CHECKPOINTS):
            raise ContractError(f"gate {gate_id} has invalid checkpoints")
        raw_predicates = gate.get("predicates")
        if not isinstance(raw_predicates, list) or not raw_predicates:
            raise ContractError(f"gate {gate_id} has no predicates")
        local = _unique(raw_predicates, "predicate")
        for predicate_id, predicate in local.items():
            if predicate_id in predicates:
                raise ContractError(f"duplicate predicate ID: {predicate_id}")
            allowed = {"id", "evaluator", "required_evidence", "statuses", "checkpoints"}
            if not set(predicate).issubset(allowed) or not {"id", "evaluator", "required_evidence"}.issubset(predicate):
                raise ContractError(f"predicate {predicate_id} has invalid fields")
            if "checkpoints" in predicate:
                own = set(_strings(predicate["checkpoints"], f"predicate {predicate_id} checkpoints"))
                if not own or not own.issubset(checkpoints):
                    raise ContractError(f"predicate {predicate_id} declares checkpoints outside its gate")
            if predicate.get("evaluator") not in EVALUATORS:
                raise ContractError(f"predicate {predicate_id} has unknown evaluator")
            evidence = predicate.get("required_evidence")
            if not isinstance(evidence, list) or not evidence or not all(isinstance(item, Mapping) and item for item in evidence):
                raise ContractError(f"predicate {predicate_id} requires evidence descriptors")
            if "statuses" in predicate:
                _strings(predicate["statuses"], f"predicate {predicate_id} statuses")
            predicates[predicate_id] = predicate
    gate_predicates = {
        gate_id: [str(item["id"]) for item in gate["predicates"]] for gate_id, gate in gates.items()
    }
    _validate_transition_bindings(workflow, quality_gates, gates, predicates)
    procedures = _validate_procedures(workflow, set(gates), gate_predicates)
    delegated_states = registry.get(DELEGATED_FAMILY, {})
    for operation in delegated_operations_of(workflow):
        if operation.current_status not in delegated_states or operation.result_status not in delegated_states:
            raise _section_refusal(f"agentic operation {operation.id} names a status outside the {DELEGATED_FAMILY} lifecycle")
        edge = operation.transition
        if edge is not None and edge[2] not in delegated_states[edge[1]].transitions_to:
            raise _section_refusal(f"agentic operation {operation.id} names an edge the {DELEGATED_FAMILY} lifecycle lacks")
        if operation.procedure_id not in procedures:
            raise ContractError(f"workflow delegated operation references unknown procedure: {operation.id}")
        unknown_gates = set(operation.gate_ids) - set(gates)
        if unknown_gates:
            raise ContractError(f"workflow Phase 4 operation references unknown gate {sorted(unknown_gates)[0]}")
    rules_raw = workflow.get("recommendations")
    if not isinstance(rules_raw, list) or not rules_raw:
        raise ContractError("workflow recommendations must be a non-empty array")
    rules = _unique(rules_raw, "workflow")
    if list(rules)[-1] != "WFL-DEFAULT-REVIEW":
        raise ContractError("WFL-DEFAULT-REVIEW must be the final workflow rule")
    for rule_id, rule in [*rules.items(), (str(workflow.get("failure", {}).get("id")), workflow.get("failure", {}))]:
        if not isinstance(rule, Mapping):
            raise ContractError(f"workflow rule {rule_id} must be an object")
        procedure_id = rule.get("procedure_id")
        if procedure_id not in procedures:
            raise ContractError(f"workflow rule {rule_id} references unknown procedure {procedure_id}")
        unknown_gates = set(_strings(rule.get("gate_ids"), f"workflow rule {rule_id} gate_ids")) - set(gates)
        if unknown_gates:
            raise ContractError(f"workflow rule {rule_id} references unknown gate {sorted(unknown_gates)[0]}")
        alternatives = rule.get("alternative_procedure_ids", [])
        unknown_procedures = set(_strings(alternatives, f"workflow rule {rule_id} alternatives")) - set(procedures)
        if unknown_procedures:
            raise ContractError(f"workflow rule {rule_id} references unknown alternative {sorted(unknown_procedures)[0]}")
        restitution = rule.get("restitution")
        if not isinstance(restitution, Mapping) or set(restitution) != RULE_RESTITUTION_FIELDS:
            raise ContractError(f"workflow rule {rule_id} must declare restitution done and current_lifecycle_state")
        for field in RULE_RESTITUTION_FIELDS:
            _strings(restitution.get(field), f"workflow rule {rule_id} restitution {field}")
    return rules, procedures, gates


def load_validated_contracts() -> tuple[dict[str, Any], dict[str, Any], dict[str, Mapping[str, Any]], dict[str, Mapping[str, Any]], dict[str, Mapping[str, Any]]]:
    workflow = load_workflow_contract()
    quality = load_quality_gate_contract()
    rules, procedures, gates = validate_contracts(workflow, quality)
    return workflow, quality, rules, procedures, gates


OPERATING_CARD_LIMIT = 1024
OPERATING_CARD_PATH = "docs/engineering/OPERATING_CARD.md"
_CARD_STOP_CONDITIONS = (
    "managed integrity fails",
    "the selected graph is invalid or IDs collide",
    "no phase-eligible selected work order exists",
    "a required governing artifact or gate is missing",
    "a required check fails",
    "owner instructions conflict with the managed contract",
    "remediation would exceed the selected work order",
    "the action lacks its decision right or explicit authority",
)
_CARD_TRAPS = (
    "PRs name one `Harness-Work-Order` or comma-separated `Harness-Work-Orders`; CI checks the combined scope.",
    "A VREC or RLS binds an earlier commit; it lives in a later governance commit and is never rewritten.",
    "Artifact IDs are shared across branches and sessions; check every ref before numbering.",
    "An unchanged rebase permits `refresh-verification --from OLD --id NEW`; changed inputs need fresh tests.",
)


def render_operating_card(
    workflow: Mapping[str, Any] | None = None,
    quality_gates: Mapping[str, Any] | None = None,
) -> bytes:
    """Render the managed operating card from the machine contracts (ADS-RDM-002).

    The card is derived content: every line restates a contract value or a
    router rule. It is bounded to OPERATING_CARD_LIMIT bytes.
    """

    workflow = load_workflow_contract() if workflow is None else workflow
    quality_gates = load_quality_gate_contract() if quality_gates is None else quality_gates
    validate_contracts(workflow, quality_gates)
    lines = [
        "# Operating card",
        "",
        "Derived from `WORKFLOW.json` and `QUALITY_GATES.json`; `harnessctl` alone computes",
        "legality and the next step.",
        "",
        "## Stop when",
        "",
    ]
    lines.extend(f"- {item};" for item in _CARD_STOP_CONDITIONS)
    lines.extend(["", "Then report the failing rule, the unchanged state, and the corrective step.", "", "## Traps", ""])
    lines.extend(f"- {item}" for item in _CARD_TRAPS)
    lines.append("")
    rendered = "\n".join(lines).encode("utf-8")
    if len(rendered) > OPERATING_CARD_LIMIT:
        raise ContractRefusal(WEX_ADS_003, f"operating card is {len(rendered)} bytes; limit is {OPERATING_CARD_LIMIT}")
    return rendered


def contract_match(value: str, accepted: object) -> bool:
    return isinstance(accepted, list) and ("*" in accepted or value in accepted)


def select_rule(
    rules: Mapping[str, Mapping[str, Any]],
    primary: Any,
    *,
    related: Iterable[Any] = (),
    target: str | None = None,
) -> tuple[Mapping[str, Any], dict[str, str]]:
    status = target or primary.status
    context = {
        "artifact_id": primary.artifact_id,
        "status": status,
        "successor_id": "the declared successor",
    }
    successors = primary.relations.get("superseded_by", [])
    if isinstance(successors, list) and successors:
        context["successor_id"] = str(sorted(str(item) for item in successors)[0])
    related_items = sorted(related, key=lambda item: item.artifact_id)
    for rule in rules.values():
        selector = rule.get("selector")
        if not isinstance(selector, Mapping):
            raise ContractError(f"workflow rule {rule.get('id')} has an invalid selector")
        if not contract_match(primary.artifact_type, selector.get("artifact_types")):
            continue
        if not contract_match(status, selector.get("statuses")):
            continue
        assurance = selector.get("commit_bound_verification")
        if assurance is not None and primary.metadata.get("assurance", {}).get("commit_bound_verification") != assurance:
            continue
        related_type = selector.get("related_artifact_type")
        if related_type is not None:
            candidates = [
                item for item in related_items
                if item.artifact_type == related_type
                and contract_match(item.status, selector.get("related_statuses"))
            ]
            if not candidates:
                continue
            context["related_id"] = candidates[0].artifact_id
            context["related_status"] = candidates[0].status
        return rule, context
    raise ContractError(f"no workflow rule for {primary.artifact_type}:{status}")
